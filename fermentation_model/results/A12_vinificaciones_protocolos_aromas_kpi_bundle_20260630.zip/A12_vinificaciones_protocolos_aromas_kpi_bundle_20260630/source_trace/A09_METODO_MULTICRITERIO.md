# Metodo multicriterio

## Estado de implementacion

La decision multicriterio esta implementada a nivel metodologico y de reporterias, pero aun no es una decision final calibrada. El uso actual es seleccionar candidatos demostrativos y ordenar politicas bajo modelo nominal.

El esquema combina:

- filtros numericos obligatorios;
- filtros biologicos/operacionales;
- normalizacion de metricas;
- score ponderado provisional;
- sensibilidad cualitativa de pesos;
- seleccion de candidato MVP.

## Criterios

| criterio | sentido | metrica actual | comentario |
| --- | --- | --- | --- |
| Factibilidad numerica | gate | residual-feasible, trajectory-ready, solver status | Obligatorio para promocion MPCC |
| Productividad | minimizar | azucar terminal o exceso sobre target | Gate de 5 g/L no se usa como hard constraint en modelo nominal |
| Calidad aromatica | maximizar o target | isoamyl acetate terminal | `r_1862` corregido a isoamyl acetate |
| Nutrientes | minimizar | dosis FDA + ORG | Representa costo y carga operacional |
| Energia | minimizar | mean(((T-20)/5)^2) | Proxy provisional |
| Operabilidad | minimizar | smoothness, numero/magnitud de cambios | En diagnosticos se mantiene baja para no congelar controles |
| Robustez biologica | gate | estados no negativos, trayectoria plausible | Requiere revision de plots |

## Normalizacion

Para costos:

```text
z_i = (y_i - y_best) / (y_worst - y_best + eps)
```

Para beneficios:

```text
z_i = (y_best - y_i) / (y_best - y_worst + eps)
```

Para targets:

```text
z_i = abs(y_i - y_target) / scale
```

Para gates:

```text
gate = pass/fail
```

Los gates no se compensan con pesos. Un candidato que no es `trajectory_ready=true` puede reportarse como diagnostico, pero no se selecciona como protocolo MPCC promovible.

## Pesos provisionales recomendados para reporterias

Escenario balanceado:

| criterio | peso |
| --- | ---: |
| Productividad/azucar | 0.30 |
| Isoamyl acetate | 0.25 |
| Nutrientes | 0.20 |
| Energia | 0.15 |
| Operabilidad | 0.10 |

Escenario calidad:

| criterio | peso |
| --- | ---: |
| Productividad/azucar | 0.20 |
| Isoamyl acetate | 0.40 |
| Nutrientes | 0.15 |
| Energia | 0.15 |
| Operabilidad | 0.10 |

Escenario costo-operacion:

| criterio | peso |
| --- | ---: |
| Productividad/azucar | 0.20 |
| Isoamyl acetate | 0.20 |
| Nutrientes | 0.30 |
| Energia | 0.20 |
| Operabilidad | 0.10 |

Estos pesos no son economicos finales. Sirven para ordenar politicas mientras se obtiene calibracion experimental.

## Regla de decision

1. Descartar fallas de simulacion, estados negativos graves o politicas no operables.
2. Para MPCC, descartar candidatos no `residual_feasible` o no `trajectory_ready` si se busca promocion.
3. Calcular score normalizado para candidatos restantes.
4. Reportar top candidates por escenario de pesos.
5. Seleccionar protocolo demostrativo segun robustez numerica + interpretabilidad biologica + score.

## Sensibilidad

La sensibilidad de pesos observada es coherente:

- Si costo energetico y nutrientes pesan mucho, politicas frias/sin nutrientes se favorecen.
- Si productividad pesa mas, aparecen rampas calidas con FDA.
- Si calidad aromatica pesa mas, politicas calientes/nutriente split pueden mejorar acetate nominal, pero a mayor energia/costo.
- En MPCC, el gate numerico domina: un candidato con mejor costo pero `trajectory_ready=false` no debe promoverse.

## Resultado multicriterio actual

Para decision demostrativa MPCC, el candidato seleccionado es:

`funnel_s7b_repair_from_post_sugar_energy_nfe84`

Razon:

- Es `LOCALLY_SOLVED`.
- Es `residual_feasible=true`.
- Es `trajectory_ready=true`.
- Mueve temperatura, FDA y ORG de forma no microscopica.
- Usa un objetivo simplificado real: target de azucar alcanzable + energia.
- Tiene figuras y tablas reproducibles.

No es la politica final industrial. Es el candidato MVP mas defendible para demostrar que el framework permite optimizacion dinamica simultanea.

## Criterios de descarte actuales

- NSGA-II no implementado: no se puede declarar frente evolutivo final.
- Candidatos `Stage13` con `trajectory_ready=false`: diagnosticos, no promocion.
- `s7c_repair`: interesante por reduccion de nutrientes, pero descartado como seleccion principal porque no es residual-feasible ni trajectory-ready.
- Politicas secuenciales con timeout/failure: utiles para diagnostico de rigidez, no para seleccion final.
- Gate de sequedad 5 g/L: no usado como criterio duro porque el modelo nominal no lo alcanza a 168 h.
