# Metodologia y formulacion matematica

## 1. Modelo secuencial dFBA

El simulador secuencial integra estados dinamicos de fermentacion y, en cada tiempo, resuelve un problema FBA/metabolico condicionado por el estado y los controles.

Estados:

`x(t) in R^n`

Controles:

`u(t) = [T(t), FDA(t), ORG(t)]`

Parametros:

`p`

Flujos metabolicos:

`v(t) in R^m`

La dinamica se escribe como:

```text
dx/dt = f_kin(x, u, p) + B v
```

donde `f_kin` contiene la cinetica fermentativa y `B v` representa contribuciones metabolicas agregadas al balance dinamico.

En cada punto se resuelve:

```text
max_v     c' v
s.t.      S v = 0
          l(x,u,p) <= v <= q(x,u,p)
```

Los bounds `l` y `q` pueden depender de temperatura, nutrientes, azucares, nitrogeno y otros estados. Esto explica por que mover controles cambia tanto RHS como factibilidad de flujos.

## 2. Reformulacion KKT del FBA

Para incrustar el LP FBA dentro del NLP simultaneo se usan condiciones KKT.

Primal:

```text
S v = 0
l(x,u,p) <= v <= q(x,u,p)
```

Dual:

```text
alpha >= 0
beta  >= 0
```

Estacionariedad, con una convencion de signos generica:

```text
c - S' lambda - alpha + beta = 0
```

Complementariedad:

```text
alpha_i * (v_i - l_i(x,u,p)) = 0
beta_i  * (q_i(x,u,p) - v_i) = 0
```

En el MPCC se usa relajacion tipo Scholtes:

```text
0 <= alpha_i * (v_i - l_i) <= tau
0 <= beta_i  * (q_i - v_i) <= tau
```

El parametro `tau` permite resolver una sucesion de problemas suaves antes de apretar la complementariedad.

## 3. Discretizacion simultanea

El horizonte se discretiza con elementos finitos y collocation. Para cada elemento `k` y punto de collocation `j`:

```text
x_dot_{k,j} = f_kin(x_{k,j}, u_{k,j}, p) + B v_{k,j}
```

Restricciones de collocation:

```text
sum_r D_{j,r} x_{k,r} = h_k * x_dot_{k,j}
```

Continuidad:

```text
x_{k+1,0} = x_{k,end}
```

El NLP simultaneo contiene estados, flujos, duales, controles y slacks para todos los puntos.

## 4. Controles dinamicos

La politica se parametriza en grilla de 12 h:

```text
theta_T = [T_0, T_12, ..., T_168]
theta_FDA = [FDA_0, FDA_12, ..., FDA_168]
theta_ORG = [ORG_0, ORG_12, ..., ORG_168]
```

Las transiciones se aplican de forma suave, no como saltos. En forma generica:

```text
u(t) = u_a + (u_b - u_a) * sigma((t - t_switch) / width)
sigma(z) = 1 / (1 + exp(-z))
```

Bounds operacionales:

```text
15 <= T(t) <= 25
FDA(t) >= 0
ORG(t) >= 0
```

En etapas de liberacion progresiva se usan trust regions:

```text
theta_ref - delta <= theta <= theta_ref + delta
```

## 5. Nutrientes

FDA se usa como fuente inorganica. Definicion operativa:

```text
1 mg FDA -> 0.2 ppm YAN como amonio
```

El nutriente organico SpringFerm Xtrem se trata inicialmente como fuente organica agregada. Para MVP se usa equivalencia YAN provisional:

```text
20 ppm YAN a 20 g/hL
```

La composicion detallada queda documentada para una futura desagregacion por metabolitos, aminoacidos, lipidos y vitaminas.

## 6. Objetivo dinamico reformulado

La sequedad real `G+F <= 5 g/L` no es impuesta en el MVP porque el modelo nominal actual no la alcanza a 168 h. Se usa una familia de targets alcanzables:

```text
S_f = G(t_f) + F(t_f)
S_target = target de azucar alcanzable por el modelo nominal
```

Termino de azucar/productividad:

```text
J_sugar = (max(S_f - S_target, 0) / S_scale)^2
```

Productividad integral opcional:

```text
J_prod = (1/t_f) integral_0^tf max(G(t)+F(t)-S_gate, 0) / S_scale dt
```

Aroma:

```text
J_aroma = (max(A_target - A_f, 0) / A_scale)^2
```

o una funcion de desirability por ventana.

Nutrientes:

```text
J_nutrient = (sum FDA + sum ORG) / N_scale
```

Energia termica:

```text
J_energy = mean(((T_j - T_amb) / T_scale)^2)
```

Suavidad opcional:

```text
J_smooth = sum_j (T_{j+1} - T_j)^2 / T_smooth_scale
```

Objetivo total:

```text
min J = w_s J_sugar + w_a J_aroma + w_n J_nutrient
        + w_e J_energy + w_sm J_smooth + J_regularization
```

Durante diagnosticos, algunos pesos se anulan para aislar mecanismos. En el MVP promovible `s7b_repair`, el objetivo activo central fue target de azucar alcanzable + energia termica, con reparacion de un post-solve que ya habia movido controles.

## 7. Pipeline metodologico

1. Reducir y validar el modelo dFBA/KKT.
2. Simular secuencialmente politicas candidatas.
3. Construir semillas biologicamente plausibles.
4. Escalar horizonte MPCC: 72 h, 96 h, 144 h, 168 h.
5. Resolver fixed-control para sanear dinamica y collocation.
6. Aplicar homotopia/regularizacion para reducir defectos.
7. Liberar controles por familia: temperatura, FDA, ORG.
8. Combinar controles con trusts conservadores.
9. Introducir objetivo dinamico reformulado.
10. Capturar post-solve, reparar y promover solo si pasa residual-feasible y trajectory-ready.

## 8. Criterios numericos de promocion

Un candidato MPCC promovible debe cumplir:

```text
selected_candidate_residual_feasible = true
selected_candidate_trajectory_ready = true
solver_status aceptable, idealmente LOCALLY_SOLVED
sin promocion de un post-solve en restoration fallida
residuales RHS/collocation/continuity bajo tolerancias del pipeline
complementariedad compatible con tau declarado
controles dentro de bounds y trusts
```

Los candidatos que son solo `residual_feasible=true` pero `trajectory_ready=false` se mantienen como diagnosticos, no como handoff final.
