# Claims y limitaciones

## Claims que si estan respaldados

- Existe una formulacion dFBA/KKT/MPCC simultanea con estados dinamicos, flujos metabolicos, restricciones estequiometricas, bounds dinamicos, duales y complementariedad relajada tipo Scholtes.
- Se implementaron controles dinamicos de temperatura, FDA y nutriente organico en una grilla operacional de 12 h, con perfiles suaves.
- Se construyo un atlas secuencial h168 para comparar politicas temperatura-nutriente bajo modelo nominal.
- Se implementaron objetivos normalizados provisionales: productividad/azucar residual, isoamyl acetate, costo de nutrientes, proxy de energia termica y suavidad opcional.
- Se generaron frentes tipo Pareto y tablas de comparacion de politicas.
- Se obtuvo un candidato MPCC h168 promovible bajo el criterio numerico del pipeline:
  - `solver_status=LOCALLY_SOLVED`
  - `selected_candidate_source=post_solve_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=true`
  - movimiento de controles no microscopico.

## Claims parciales

- La decision multicriterio esta implementada como metodologia y aplicada de forma provisional sobre atlas, politicas y candidatos MPCC. No debe presentarse como decision industrial final.
- Los frentes tipo Pareto actuales provienen de atlas/barridos ponderados y casos MPCC simplificados. Son evidencia de tradeoff y metodologia, no un frente NSGA-II completo.
- La seleccion final actual es un candidato MVP demostrativo, no una recomendacion operacional calibrada para bodega.

## Claims que no deben hacerse

- No afirmar que NSGA-II ya esta integrado al MPCC. A la fecha del bundle, no lo esta.
- No afirmar que la politica MPCC es optima global. Es un candidato local, numericamente sano, bajo modelo nominal y objetivos provisionales.
- No afirmar sequedad enologica real a 168 h. El modelo nominal no alcanza el gate original de 5 g/L bajo las condiciones actuales; la sequedad se maneja como metrica/gate ajustable.
- No afirmar que los pesos economicos/sensoriales son definitivos. Son pesos de demostracion metodologica.
- No afirmar que isoamyl acetate ya esta calibrado sensorialmente. El identificador `r_1862` fue corregido a isoamyl acetate, pero el rango objetivo sigue siendo provisional.

## Limitaciones cientificas y numericas

- Modelo nominal no calibrado con la nueva campana experimental.
- No hay aun modulo L-G/volatilizacion de aromas activo en el MPCC.
- La energia termica se representa con un proxy cuadratico relativo a 20 C.
- La complementariedad se evalua bajo relajacion Scholtes, por ejemplo `tau=1e-3` en el funnel promovible.
- Los candidatos con `trajectory_ready=false` son diagnosticos numericos, no trayectorias biologicas promovibles.
- Las corridas MPCC son locales y sensibles a starts, trust regions, slacks, continuidad/collocation y bounds dinamicos.

## Uso correcto en el anexo

La forma mas solida de presentar el resultado es:

> Con modelo nominal y objetivos provisionales, el framework dFBA/KKT/MPCC permite construir, resolver y comparar politicas dinamicas temperatura-nutriente, con trazabilidad numerica y biologica. Se obtuvo un MVP promovible que demuestra movimiento real de controles. Cuando entre el modelo calibrado, el pipeline queda listo para recalcular politicas mas fidedignas e integrar busqueda evolutiva tipo NSGA-II.
