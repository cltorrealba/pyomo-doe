# Resultados y trazabilidad

## Resumen de etapas

| etapa | objetivo | resultado | evidencia |
| --- | --- | --- | --- |
| Semilla 72 h | Obtener handoff MPCC robusto | Semilla global 72 h tau 1.14e-3 residual-feasible y trajectory-ready | `fuentes/repro/SEED_POLISH_METHODOLOGY_UC_20260609.md` |
| Extension h168 | Extender simulacion/semilla a 168 h | Semilla fixed-control h168 usada como base numerica | `fuentes/repro/HANDOFF_GLOBAL168H_SEED_UC_20260609.md` |
| Atlas secuencial | Explorar sensibilidad de politicas | 13 politicas nominales, 8-9 aceptadas segun reporte/plots | `tablas/dynamic_control_objective_candidates.csv` |
| Stage12 Pareto local | Construir direccion ORG/FDA | Seleccion `stage12_orgplus_fda_reduced` como benchmark local | `fuentes/generated/stage12_pareto_summary.md` |
| Stage13 multiobjetivo | Probar maquinaria MPCC h168 | Residual-feasible pero no trajectory-ready; movimiento microscopico | `fuentes/repro/stage13_mvp_multiobjective_results_20260625.md` |
| Funnel MPCC | Liberacion progresiva y reparacion | Primer candidato h168 promovible con controles no microscopicos | `fuentes/repro/dynamic_control_release_funnel_mvp_20260629.md` |

## Atlas secuencial nominal

El atlas secuencial sirve como capa biologica de referencia. Permite comparar politicas sin cargar de inmediato toda la dificultad del MPCC simultaneo.

Resultados representativos:

| politica | interpretacion | azucar final g/L | isoamyl acetate g/L | nutrientes g/L | energia proxy |
| --- | --- | ---: | ---: | ---: | ---: |
| `flat22__none` | baseline nominal | 112.37 | 0.000353 | 0.0 | 0.160 |
| `ramp20_to25__none` | productividad termica sin nutrientes | 109.05 | 0.000343 | 0.0 | 0.346 |
| `ramp20_to25__fda_split_1p0_1p0_mid` | rampa + FDA split | 90.77 | 0.000366 | 2.0 | 0.346 |
| `ramp22_to25__fda_split_1p0_1p0_mid` | politica balanceada | 87.24 | 0.000387 | 2.0 | 0.525 |
| `ramp22_to25__fda_split_1p5_1p5_mid` | mejor azucar secuencial saludable | 79.95 | 0.000400 | 3.0 | 0.525 |
| `flat24__fda_split_1p0_1p0_mid` | mayor acetate secuencial saludable | 86.21 | 0.000404 | 2.0 | 0.640 |

Figuras:

- `figuras/nominal_mvp_sequential_tradeoff.svg`
- `figuras/total_sugar_by_policy.svg`
- `figuras/isoamyl_acetate_by_policy.svg`
- `figuras/temperature_control_by_policy.svg`
- `figuras/fda_cumulative_by_policy.svg`

## Frentes tipo Pareto

Los frentes actuales no son NSGA-II. Son frentes tipo Pareto derivados de:

- atlas secuencial;
- barridos de pesos;
- candidatos MPCC simplificados;
- comparacion de candidatos promovibles/no promovibles.

Figuras:

- `figuras/pareto_sugar_aroma.svg`
- `figuras/pareto_nutrient_aroma.svg`

Tabla principal:

- `tablas/simplified_mpcc_pareto_summary.csv`

## Resultado MPCC MVP

Caso principal:

`funnel_s7b_repair_from_post_sugar_energy_nfe84`

Ruta original:

`/home/cltorrealba/mpcc_runs/dynamic_control_release_funnel_20260628_main/funnel_s7b_repair_from_post_sugar_energy_nfe84/case`

Metricas:

| metrica | valor |
| --- | ---: |
| solver status | `LOCALLY_SOLVED` |
| primal status | `FEASIBLE_POINT` |
| selected source | `post_solve_values` |
| residual feasible | `true` |
| trajectory ready | `true` |
| azucar terminal | `157.8909487653 g/L` |
| isoamyl acetate terminal | `15.3310811044 mg/L` |
| energia termica proxy | `0.3946153846` |
| nutriente total | `3.2481711831 g/L` |
| max RHS residual | `8.48e-10` |
| max collocation residual | `1.12e-10` |
| max continuity residual | `1.12e-10` |
| max lower complementarity | `9.98e-4` bajo `tau=1e-3` |

Controles:

- Temperatura: slots libres bajan `0.5 C` respecto al perfil base.
- FDA:
  - 12 h: `1.5 -> 1.5547904605 g/L`
  - 84 h: `1.5 -> 1.6153368659 g/L`
  - delta total: `+0.1701273264 g/L`
- ORG:
  - 12 h: `0 -> 0.0380622113 g/L`
  - 84 h: `0 -> 0.0399816453 g/L`
  - delta total: `+0.0780438566 g/L`

Figura del candidato:

- `figuras/optimized_control_profiles.svg`
- `figuras/optimized_control_profiles.png`

## Comparacion de candidatos MPCC clave

| caso | solver | residual feasible | trajectory ready | azucar g/L | acetate mg/L | energia | nutrientes g/L |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
| `funnel_s1w_current_T_repair_from_post0p13_nfe84` | LOCALLY_SOLVED | true | true | 158.248 | 2.526 | 0.563 | 3.006 |
| `funnel_s1x_current_T_push_from_repaired0p15_nfe84` | LOCALLY_SOLVED | true | true | 158.249 | 2.779 | 0.589 | 3.014 |
| `funnel_s1y_current_T_push_from_repaired0p25_nfe84` | LOCALLY_SOLVED | true | true | 158.249 | 3.004 | 0.651 | 3.020 |
| `funnel_s7b_repair_from_post_sugar_energy_nfe84` | LOCALLY_SOLVED | true | true | 157.891 | 15.331 | 0.395 | 3.248 |
| `funnel_s7c_repair_from_post_sugar_nutrient_nfe84` | ITERATION_LIMIT | false | false | 158.212 | 8.416 | 0.442 | 2.600 |

Interpretacion:

- `s1w/s1x/s1y` demuestran que la reparacion y el empuje de temperatura pueden producir candidatos promovibles.
- `s7b_repair` es el MVP principal porque su movimiento viene de un objetivo simplificado real, no de recompensa directa al control.
- `s7c_repair` muestra el tradeoff deseado de menor nutriente, pero aun no pasa los gates numericos.

## Reproducibilidad

Archivos clave:

- `fuentes/config/dynamic_control_nominal_mvp_20260627.toml`
- `fuentes/repro/submit_cluster_uc_dynamic_control_release_funnel.sh`
- `fuentes/repro/dynamic_control_release_funnel_20260628.tsv`
- `fuentes/scripts/main_reduced_mpcc_fixed_control_policy_solve_attempt.jl`
- `fuentes/scripts/main_summarize_dynamic_control_simplified_mpcc_pareto.py`
- `fuentes/src/Simultaneous/reduced_dcdfba_collocation_nlp.jl`
- `fuentes/src/Optimization/dynamic_control_objective.jl`
- `fuentes/src/Optimization/dynamic_controls.jl`

Verificacion del bundle:

- `verificacion/MANIFEST.files.txt`
- `verificacion/MANIFEST.sha256`
- `verificacion/VERIFICACION_LOCAL.md`
