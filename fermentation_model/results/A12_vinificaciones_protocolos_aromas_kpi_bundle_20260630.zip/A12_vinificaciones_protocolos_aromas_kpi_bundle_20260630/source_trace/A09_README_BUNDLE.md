# Bundle A09 - Optimizacion dFBA/KKT, decision multicriterio y protocolos

Fecha de preparacion: 2026-06-29

Este bundle compacta la evidencia disponible para el Anexo A09:

`Optimizacion dFBA/KKT y NSGA-II (Actividad 4.5) y Decision multicriterio para protocolos de operacion (Actividad 4.6) + Seleccion y evaluacion de protocolos optimos (Actividad 4.7)`.

## Lectura recomendada

1. `documentos/ANEXO_A09_BORRADOR_TECNICO.md`: texto principal listo para adaptar al anexo.
2. `documentos/METODOLOGIA_FORMULACION.md`: formulacion matematica y pipeline metodologico.
3. `documentos/RESULTADOS_Y_TRAZABILIDAD.md`: resultados por etapa, con rutas a tablas y figuras.
4. `documentos/METODO_MULTICRITERIO.md`: criterios, normalizacion, pesos provisionales, sensibilidad y regla de decision.
5. `CLAIMS_Y_LIMITACIONES.md`: que queda demostrado, que queda parcial y que no debe sobredeclararse.

## Evidencia mas relevante

- `figuras/pareto_sugar_aroma.svg`: frente tipo Pareto MPCC simplificado, azucar residual versus isoamyl acetate.
- `figuras/pareto_nutrient_aroma.svg`: frente tipo Pareto MPCC simplificado, nutrientes versus isoamyl acetate.
- `figuras/control_movement_overview.svg`: resumen de movimiento de controles en el funnel MPCC.
- `figuras/optimized_control_profiles.svg`: perfiles optimizados del candidato MVP promovible.
- `figuras/nominal_mvp_sequential_tradeoff.svg`: comparacion secuencial de politicas nominales.
- `tablas/simplified_mpcc_pareto_summary.csv`: resumen principal del funnel MPCC h168.
- `tablas/dynamic_control_objective_candidates.csv`: atlas secuencial nominal h168.
- `tablas/dynamic_control_policy_selection.csv`: seleccion/revision de politicas candidatas.

## Elementos auxiliares

- `fuentes/repro/`: reportes metodologicos originales y bitacoras de etapas.
- `fuentes/generated/`: reportes generados desde corridas y resumenes.
- `fuentes/scripts/`: scripts de preparacion, submit, resumen y plotting.
- `fuentes/src/`: archivos fuente clave donde se implementan controles, objetivo dinamico y NLP simultaneo.
- `fuentes/config/`: configuracion nominal MVP y mapas de reacciones.
- `verificacion/`: manifiestos de archivos y hashes.

## Mensaje central defendible

Con el modelo nominal y objetivos provisionales, se construyo un pipeline que:

- genera politicas dinamicas temperatura-nutriente por simulacion secuencial;
- transforma politicas en starts/candidatos para MPCC simultaneo dFBA/KKT;
- evalua objetivos de productividad, aroma, nutrientes y energia;
- produce frentes tipo Pareto y reporterias reproducibles;
- obtuvo un primer candidato h168 MPCC `LOCALLY_SOLVED`, `residual_feasible=true` y `trajectory_ready=true` con controles no microscopicos.

NSGA-II no esta integrado aun en esta version. La evidencia actual corresponde a atlas secuencial, barridos ponderados, frentes tipo Pareto y MPCC simultaneo con liberacion progresiva de controles. El anexo debe declarar esta brecha y proponer NSGA-II como envoltorio de busqueda para la siguiente iteracion.
