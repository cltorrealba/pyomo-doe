# Bundle A12 - Vinificaciones, aromas y KPIs

Fecha: 2026-06-30 17:16

Este bundle compacta evidencia para el Anexo A12:

- Actividad 5.6: Vinificaciones con protocolos optimos y comerciales.
- Actividad 5.7: Analisis de marcadores aromaticos en vino y condensados.
- Actividad 5.8: Indicadores clave de eficiencia para politicas optimas y comerciales in vivo.

## Lectura recomendada

1. `A12_report.md`: reporte principal autocontenido.
2. `CLAIMS_Y_LIMITACIONES_A12.md`: que se puede declarar y que no.
3. `figures/fig01_a12_activity_status.png`: estado de avance por actividad.
4. `figures/fig02_model_validation_predicted_observed.png`: evidencia de validacion del modelo.
5. `figures/fig05_a09_preliminary_mpcc_tradeoff.png`: conexion con MPCC/A09.
6. `figures/fig06_aroma_parameter_reduction.png`: evidencia de diseno de aromas.

## Evidencia principal

- `tables/campaign_protocol.csv`: lotes y tratamientos propuestos.
- `tables/selected_campaign.csv`: campana MBDoE seleccionada.
- `tables/volume_policy.csv` y `tables/volume_audit.csv`: factibilidad operacional.
- `tables/aroma_selected.csv`: campana aromatica MBDoE.
- `tables/kpi_schema.csv`: KPIs de evaluacion in vivo.
- `templates/`: bitacora, QA/QC y schema de KPIs.

## Complementario

- `source_trace/`: reportes fuente A08/A09 y documentos metodologicos seleccionados.
- `figures/source_*`: figuras fuente copiadas desde A09 o diagnosticos del modelo.
- `tables/a09_*`: tablas resumidas del trabajo MPCC/KKT/MCDM.

El archivo zip queda junto a la carpeta del bundle.
