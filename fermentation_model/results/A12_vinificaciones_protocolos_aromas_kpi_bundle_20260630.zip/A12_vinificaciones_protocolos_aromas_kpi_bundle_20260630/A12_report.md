# A12 - Vinificaciones, aromas y KPIs in vivo

**Actividades:** 5.6, 5.7 y 5.8  
**Titulo integrado:** Vinificaciones con protocolos optimos y comerciales + analisis de marcadores aromaticos en vino y condensados + evaluacion de indicadores clave de eficiencia in vivo  
**Fecha de generacion:** 2026-06-30 17:16  
**Bundle:** `A12_vinificaciones_protocolos_aromas_kpi_bundle_20260630`

## 1. Proposito y criterio de reporte

Este bundle consolida la evidencia tecnica disponible para el Anexo A12. El objetivo es documentar el avance metodologico y experimental hacia la comparacion in vivo de protocolos optimos versus comerciales, incluyendo analisis de aromas y KPIs de eficiencia.

La diferencia clave respecto de un anexo experimental cerrado es que los protocolos optimos realistas aun no deben declararse finales. La razon tecnica es que el MPCC/dFBA/KKT disponible en A09 fue construido sobre modelo nominal y objetivos provisionales. Antes de ejecutar una comparacion in vivo definitiva, se requirio robustecer la calibracion del modelo de fermentacion, evaluar identificabilidad practica, incorporar glicerinol, biomasa muerta, CO2, estados secundarios y capa de aromas, y disenar una campana MBDoE que mejore la estimabilidad de parametros.

Por tanto, este anexo debe defender tres puntos:

1. Existe metodologia y software para generar politicas dinamicas optimas.
2. Existe una campana experimental operacionalizable para recalibrar y validar el gemelo antes de cerrar protocolos optimos.
3. La postergacion de la comparacion in vivo final no es una omision, sino una decision tecnica para evitar artefactos de optimizacion.

## 2. Estado de cumplimiento por actividad

| activity                                            | current_status                                                               | evidence_in_bundle                                                     | claim_level                                                                       |
|:----------------------------------------------------|:-----------------------------------------------------------------------------|:-----------------------------------------------------------------------|:----------------------------------------------------------------------------------|
| 5.6 Vinifications: optimal and commercial protocols | In progress / technically gated                                              | DOE operational protocol, volume audit, MPCC preliminary candidates    | Protocol design and readiness; not final in-vivo optimal-vs-commercial comparison |
| 5.7 Aroma markers in wine and condensates           | Analytical design and MBDoE completed; final campaign data pending           | Aroma DOE, target markers, terminal condensate balance, QA/QC template | Analytical plan and model-based prioritization; not final marker statistics       |
| 5.8 In-vivo KPI comparison                          | KPI framework prepared; experimental comparison pending calibrated protocols | KPI schema, MPCC preliminary objective metrics, DOE metrics            | Framework and preliminary model-based indicators; not final in-vivo KPI delta     |

Figura asociada: `figures/fig01_a12_activity_status.png`.

## 3. Evidencia fuente consolidada

La evidencia usada proviene de cuatro capas:

- Datos historicos y nuevos de mosto sintetico/natural procesados para calibracion ODE.
- Validacion independiente A08 del Gemelo Digital.
- Diseno experimental MBDoE operacionalizado para nuevos ensayos.
- Bundle A09 de optimizacion dFBA/KKT/MPCC/MCDM.

Archivos trazables se incluyen en `source_trace/`. Las tablas compactas estan en `tables/` y las figuras principales en `figures/`.

## 4. Modelo de simulacion fermentativa

El modelo operativo principal es un sistema ODE:

$$
x(t)=\left[X, X_d, N, G, F, E, Gly\right]^T
$$

con estados de biomasa viable, biomasa muerta, nitrogeno asimilable, glucosa, fructosa, etanol y glicerol. La dinamica es:

$$
\frac{dX}{dt}=(\mu-k_d)X+u_X(t)
$$

$$
\frac{dX_d}{dt}=k_dX
$$

$$
\frac{dN}{dt}=-q_N a_{\mu}(T)\frac{N}{N+K_N(T)}X+u_N(t)
$$

$$
\frac{dG}{dt}=-\left[q_{XG}a_{\mu}(T)\frac{N}{N+K_N(T)}
+q_{EG}a_{\beta}(T)\frac{G}{G+K_G(T)}I_E(E)
+m(T)\frac{G}{G+F}\right]X+u_G(t)
$$

$$
\frac{dF}{dt}=-\left[q_{XF}a_{\mu}(T)\frac{N}{N+K_N(T)}
+q_{EF}a_{\beta}(T)\frac{F}{F+K_F(T)}I_G(G)I_E(E)
+m(T)\frac{F}{G+F}\right]X+u_F(t)
$$

$$
\frac{dE}{dt}=(\beta_G+\beta_F)X+u_E(t)
$$

$$
\frac{dGly}{dt}=\left[\gamma_{G0}a_{\beta}(T)\frac{G}{G+K_G(T)}I_E(E)
+\gamma_{F0}a_{\beta}(T)\frac{F}{F+K_F(T)}I_G(G)I_E(E)\right]X
$$

con inhibiciones:

$$
I_E(E)=\frac{1}{1+i_E(T)E},\qquad I_G(G)=\frac{1}{1+i_G(T)G}
$$

Los pulsos operacionales se modelan como entradas suaves:

$$
u_j(t)=\sum_k \Delta C_{j,k}\frac{\exp[-((t-t_{j,k})/w)^2]}{\sqrt{\pi}w}
$$

## 5. Calibracion, validacion y estimabilidad

La calibracion se formulo como minimos cuadrados ponderados:

$$
\min_{\theta} J(\theta)=\sum_{b,i,k}\left(\frac{\hat{y}_{b,i}(t_k;\theta)-y_{b,i,k}}{\sigma_i(y_{b,i,k})}\right)^2
+\lambda\sum_{p\in P_R}\left[\log\left(\frac{\theta_p}{\theta_{p,ref}}\right)\right]^2
$$

donde:

$$
\sigma_i(y)=\max(\sigma_{i,floor},r_i|y|)
$$

La estimabilidad se evaluo con FIM, perfiles de likelihood y aproximacion bayesiana/Laplace:

$$
F(\theta)=S(\theta)^T W S(\theta),\qquad
LR_p(\theta_p)=J(\theta_p,\hat{\theta}_{-p})-J(\hat{\theta})
$$

El umbral usado fue:

$$
LR_p>\chi^2_{1,0.95}=3.841
$$

**Resumen de ajustes**

| fit                 |   n_batches | mediums           |   n_parameters |   final_wsse |   n_residuals |   wsse_per_residual |   l2_lambda |
|:--------------------|------------:|:------------------|---------------:|-------------:|--------------:|--------------------:|------------:|
| natural_reduced11   |           9 | natural           |             11 |        13410 |           608 |              22.055 |           0 |
| synthetic_reduced11 |          10 | synthetic         |             11 |        10720 |           542 |              19.786 |           0 |
| mixed_reduced11     |          19 | natural,synthetic |             11 |        27140 |          1150 |              23.599 |           0 |
| mixed_full17_l2     |          19 | natural,synthetic |             17 |        26130 |          1160 |              22.528 |           1 |

**Metricas de validacion sintetica**

_No data available._

Figura central de validacion: `figures/fig02_model_validation_predicted_observed.png`.

**Perfil likelihood**

| parameter   |   max_lr_stat |   crosses_left_95 |   crosses_right_95 |   profile_identifiable_95 |
|:------------|--------------:|------------------:|-------------------:|--------------------------:|
| mu0         |      1878.61  |                 0 |                  1 |                         0 |
| sN          |         5.95  |                 1 |                  0 |                         0 |
| qN          |      5840.91  |                 1 |                  1 |                         1 |
| qXG         |         0     |                 0 |                  0 |                         0 |
| qXF         |        17.857 |                 1 |                  0 |                         0 |
| betaG0      |         0     |                 0 |                  0 |                         0 |
| sG          |       105.519 |                 1 |                  0 |                         0 |
| betaF0      |       424.028 |                 1 |                  0 |                         0 |
| sF          |       531.035 |                 1 |                  0 |                         0 |
| qEG         |      3934.36  |                 1 |                  0 |                         0 |
| qEF         |      4017.49  |                 1 |                  0 |                         0 |
| iG          |       129.045 |                 0 |                  1 |                         0 |
| iE          |       228.244 |                 1 |                  0 |                         0 |
| Kd0         |       374.761 |                 1 |                  1 |                         1 |
| m0          |         0     |                 0 |                  0 |                         0 |
| gammaG0     |       246.7   |                 1 |                  1 |                         1 |
| gammaF0     |        14.155 |                 1 |                  1 |                         1 |

## 6. Modelo dFBA/KKT/MPCC y decision multicriterio

El trabajo A09 implemento una formulacion simultanea dFBA/KKT/MPCC. El simulador secuencial resuelve:

$$
\frac{dx}{dt}=f_{kin}(x,u,p)+Bv
$$

con un problema FBA local:

$$
\max_v c^Tv
$$

$$
S v=0,\qquad l(x,u,p)\leq v\leq q(x,u,p)
$$

La reformulacion KKT usa duales \alpha,\beta y estacionariedad:

$$
c-S^T\lambda-\alpha+\beta=0
$$

con complementariedad:

$$
\alpha_i(v_i-l_i)=0,\qquad \beta_i(q_i-v_i)=0
$$

En el MPCC se usa relajacion tipo Scholtes:

$$
0\leq \alpha_i(v_i-l_i)\leq \tau,\qquad
0\leq \beta_i(q_i-v_i)\leq \tau
$$

El objetivo dinamico A09 incluyo productividad/azucar residual, aroma, nutrientes, energia termica y suavidad:

$$
\min J=w_sJ_{sugar}+w_aJ_{aroma}+w_nJ_{nutrient}+w_eJ_{energy}+w_{sm}J_{smooth}
$$

El bundle A09 demostro que el pipeline puede generar candidatos dinamicos y frentes tipo Pareto, pero sus propios claims indican que no debe presentarse como decision industrial final ni optimo global. La politica MPCC promovible principal fue local, numericamente sana y generada bajo modelo nominal.

**Resultados A09 clave**

| categoria    | candidato_o_etapa                                 | estado                      |   azucar_final_g_L | isoamyl_acetate    | energia_proxy   |   nutriente_total_g_L | interpretacion                                        |   isoamyl_acetate_mg_l_interpreted |
|:-------------|:--------------------------------------------------|:----------------------------|-------------------:|:-------------------|:----------------|----------------------:|:------------------------------------------------------|-----------------------------------:|
| Secuencial   | flat22__none                                      | accepted                    |            112.371 | 0.000353 g/L       | 0.160           |                 0     | Baseline nominal                                      |                              0.353 |
| Secuencial   | ramp20_to25__fda_split_1p0_1p0_mid                | accepted                    |             90.768 | 0.000366 g/L       | 0.346           |                 2     | Rampa termica con FDA mejora azucar frente a baseline |                              0.366 |
| Secuencial   | ramp22_to25__fda_split_1p5_1p5_mid                | accepted                    |             79.955 | 0.000400 g/L       | 0.525           |                 3     | Menor azucar secuencial saludable observada           |                              0.4   |
| Secuencial   | flat24__fda_split_1p0_1p0_mid                     | accepted                    |             86.213 | 0.000404 g/L       | 0.640           |                 2     | Mayor isoamyl acetate secuencial saludable observada  |                              0.404 |
| MPCC Stage13 | balanced                                          | residual_feasible_not_ready |            158.715 | 0.022236 g/L proxy | NA              |                 0.136 | Maquinaria multiobjetivo funciono pero sin promotion  |                             22.236 |
| MPCC Funnel  | funnel_s1y_current_T_push_from_repaired0p25_nfe84 | promovible                  |            158.249 | 3.0038 mg/L        | 0.651           |                 3.02  | Control directo T con candidato sano                  |                              3.004 |
| MPCC Funnel  | funnel_s7b_repair_from_post_sugar_energy_nfe84    | promovible                  |            157.891 | 15.3311 mg/L       | 0.395           |                 3.248 | MVP principal con objetivo simplificado real          |                             15.331 |
| MPCC Funnel  | funnel_s7c_repair_from_post_sugar_nutrient_nfe84  | rechazado                   |            158.212 | 8.4159 mg/L        | 0.443           |                 2.6   | Tradeoff bajo nutriente aun no factible               |                              8.416 |

Figura asociada: `figures/fig05_a09_preliminary_mpcc_tradeoff.png`.

**Candidato MPCC MVP**

| case_id                                        | solver_status   | primal_status   | selected_candidate_source   |   selected_candidate_residual_feasible |   selected_candidate_trajectory_ready |   selected_candidate_terminal_state_values_available |   selected_candidate_terminal_glucose_g_L |   selected_candidate_terminal_fructose_g_L |   selected_candidate_terminal_total_sugar_g_L |   selected_candidate_terminal_isoamyl_acetate_g_L |   selected_candidate_terminal_isoamyl_alcohol_g_L |   post_solve_candidate_residual_feasible |   pre_solve_candidate_dynamic_control_values_captured |   post_solve_candidate_dynamic_control_values_captured |   post_solve_candidate_dynamic_control_delta_vs_pre_solve_available |   post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve |   post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve |   post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve |   candidate_residual_feasible |   dynamic_control_objective_enabled | dynamic_control_objective_mode   | dynamic_control_objective_resolved_target_state   | dynamic_control_objective_target_state_alias_policy   |   dynamic_control_objective_target_component_count | dynamic_control_objective_target_component_names   |   dynamic_control_objective_terminal_state_scale_g_L |   dynamic_control_objective_terminal_sugar_weight |   dynamic_control_objective_terminal_sugar_scale_g_L |   dynamic_control_objective_integrated_sugar_weight |   dynamic_control_objective_integrated_sugar_scale_g_L | dynamic_control_objective_integrated_sugar_config_policy   |   dynamic_control_objective_integrated_sugar_max_g_L | dynamic_control_objective_aroma_reward_policy   |   dynamic_control_objective_integrated_aroma_reward_terms | dynamic_control_objective_integrated_aroma_reward_policy   |   dynamic_control_objective_terminal_sugar_terms |   dynamic_control_objective_integrated_sugar_terms | dynamic_control_objective_integrated_sugar_policy   |   dynamic_control_objective_integrated_sugar_slack_count |   objective_value |   max_rhs_residual |   max_mass_balance_residual |   max_lower_bound_violation |   max_upper_bound_violation |   max_stationarity_residual |   max_lower_complementarity_residual |   max_upper_complementarity_residual |   max_collocation_integration_residual |   max_continuity_residual |   temperature_slot_count |   temperature_max_abs_delta |   temperature_optimized_sum |   temperature_post_solve_available |   temperature_post_solve_max_abs_delta |   temperature_post_solve_sum_delta |   temperature_post_solve_sum |   fda_slot_count |   fda_max_abs_delta |   fda_optimized_sum |   fda_post_solve_available |   fda_post_solve_max_abs_delta |   fda_post_solve_sum_delta |   fda_post_solve_sum |   organic_slot_count |   organic_max_abs_delta |   organic_optimized_sum |   organic_post_solve_available |   organic_post_solve_max_abs_delta |   organic_post_solve_sum_delta |   organic_post_solve_sum |
|:-----------------------------------------------|:----------------|:----------------|:----------------------------|---------------------------------------:|--------------------------------------:|-----------------------------------------------------:|------------------------------------------:|-------------------------------------------:|----------------------------------------------:|--------------------------------------------------:|--------------------------------------------------:|-----------------------------------------:|------------------------------------------------------:|-------------------------------------------------------:|--------------------------------------------------------------------:|--------------------------------------------------------------------------------:|----------------------------------------------------------------------:|--------------------------------------------------------------------------:|------------------------------:|------------------------------------:|:---------------------------------|:--------------------------------------------------|:------------------------------------------------------|---------------------------------------------------:|:---------------------------------------------------|-----------------------------------------------------:|--------------------------------------------------:|-----------------------------------------------------:|----------------------------------------------------:|-------------------------------------------------------:|:-----------------------------------------------------------|-----------------------------------------------------:|:------------------------------------------------|----------------------------------------------------------:|:-----------------------------------------------------------|-------------------------------------------------:|---------------------------------------------------:|:----------------------------------------------------|---------------------------------------------------------:|------------------:|-------------------:|----------------------------:|----------------------------:|----------------------------:|----------------------------:|-------------------------------------:|-------------------------------------:|---------------------------------------:|--------------------------:|-------------------------:|----------------------------:|----------------------------:|-----------------------------------:|---------------------------------------:|-----------------------------------:|-----------------------------:|-----------------:|--------------------:|--------------------:|---------------------------:|-------------------------------:|---------------------------:|---------------------:|---------------------:|------------------------:|------------------------:|-------------------------------:|-----------------------------------:|-------------------------------:|-------------------------:|
| funnel_s7b_repair_from_post_sugar_energy_nfe84 | LOCALLY_SOLVED  | FEASIBLE_POINT  | post_solve_values           |                                      1 |                                     1 |                                                    1 |                                    87.308 |                                     70.583 |                                       157.891 |                                             0.015 |                                             0.015 |                                        1 |                                                     1 |                                                      1 |                                                                   1 |                                                                       7.594e-06 |                                                                -0.045 |                                                                     0.045 |                             1 |                                   1 | aroma_nutrient_energy            | isoamyl_acetate                                   | exact_state_name                                      |                                                  1 | ['isoamyl_acetate']                                |                                                0.001 |                                                 0 |                                                  100 |                                                   0 |                                                    100 | excess_slack                                               |                                                    5 | terminal                                        |                                                         0 | disabled                                                   |                                                0 |                                                  0 | disabled                                            |                                                        0 |             9.865 |          8.476e-10 |                   6.003e-08 |                   5.556e-09 |                   5.559e-09 |                   1.642e-14 |                            0.0009982 |                            0.0009899 |                              1.118e-10 |                 1.118e-10 |                       14 |                         0.5 |                         322 |                                  1 |                                    0.5 |                                 -7 |                          322 |               13 |               0.115 |                3.17 |                          1 |                          0.115 |                       0.17 |                 3.17 |                   13 |                    0.04 |                   0.078 |                              1 |                               0.04 |                          0.078 |                    0.078 |

Figura fuente: `figures/source_a09_optimized_control_profiles.png`.

## 7. Protocolo experimental propuesto para A12

La campana experimental actual se estructura como 9 fermentaciones en 3 lotes de 3 reactores. No corresponde aun a la comparacion final "protocolo optimo vs comercial", sino a la campana necesaria para recalibrar y seleccionar con mayor confianza esos protocolos.

**Lotes y tratamientos propuestos**

|   campaign_order |   lot | start_datetime      | candidate                                | medium    | family                   |   horizon_h |
|-----------------:|------:|:--------------------|:-----------------------------------------|:----------|:-------------------------|------------:|
|                1 |     1 | 2026-06-15 08:00:00 | synthetic_lit_SM410_18C_highN_ester      | synthetic | literature_nitrogen_high |         216 |
|                2 |     1 | 2026-06-15 08:00:00 | synthetic_high_biomass_low_N_maintenance | synthetic | maintenance              |         216 |
|                3 |     1 | 2026-06-15 08:00:00 | synthetic_fructose_rich_glucose_pulse    | synthetic | sugar_separation         |         216 |
|                4 |     2 | 2026-06-29 08:00:00 | synthetic_glucose_rich_fructose_pulse    | synthetic | sugar_separation         |         216 |
|                5 |     2 | 2026-06-29 08:00:00 | synthetic_lit_SM410_24C_highN_strip      | synthetic | literature_temp_strip    |         168 |
|                6 |     2 | 2026-06-29 08:00:00 | synthetic_viable_biomass_step            | synthetic | biomass_input            |         216 |
|                7 |     3 | 2026-07-13 08:00:00 | synthetic_high_sugar_reference           | synthetic | synthetic_baseline       |         216 |
|                8 |     3 | 2026-07-13 08:00:00 | natural_glucose_pulse_after_growth       | natural   | natural_sugar_pulse      |         216 |
|                9 |     3 | 2026-07-13 08:00:00 | synthetic_fast_CO2_aroma_strip_highN     | synthetic | co2_aroma_loss           |         168 |

**Campana seleccionada por MBDoE**

|   campaign_order | candidate                                | family                   | medium    |   horizon_h |   campaign_logdet |   new_param_mean_var_reduction |   new_param_worst_var_reduction | rationale                                                                                          |
|-----------------:|:-----------------------------------------|:-------------------------|:----------|------------:|------------------:|-------------------------------:|--------------------------------:|:---------------------------------------------------------------------------------------------------|
|                1 | synthetic_lit_SM410_18C_highN_ester      | literature_nitrogen_high | synthetic |         216 |           148.181 |                          0.874 |                           0.533 | Literature SM410-like high YAN tests ester capacity and nitrogen-saturated aroma phase.            |
|                2 | synthetic_high_biomass_low_N_maintenance | maintenance              | synthetic |         216 |           163.487 |                          0.941 |                           0.756 | High biomass with low N creates low-growth sugar consumption windows for m0.                       |
|                3 | synthetic_fructose_rich_glucose_pulse    | sugar_separation         | synthetic |         216 |           170.612 |                          0.957 |                           0.819 | Fructose-rich run probes iG and fructose kinetic directions.                                       |
|                4 | synthetic_glucose_rich_fructose_pulse    | sugar_separation         | synthetic |         216 |           175.235 |                          0.969 |                           0.869 | High glucose plus fructose pulse separates glucose and fructose uptake/yield directions.           |
|                5 | synthetic_lit_SM410_24C_highN_strip      | literature_temp_strip    | synthetic |         168 |           178.598 |                          0.975 |                           0.899 | High YAN plus warm high-rate fermentation excites CO2 stripping and temperature-partition effects. |
|                6 | synthetic_viable_biomass_step            | biomass_input            | synthetic |         216 |           181.253 |                          0.978 |                           0.907 | Known viable biomass addition tests rate proportionality to X and supports yield separation.       |
|                7 | synthetic_high_sugar_reference           | synthetic_baseline       | synthetic |         216 |           183.6   |                          0.981 |                           0.92  | Synthetic high-sugar operating point close to the current synthetic dataset.                       |
|                8 | natural_glucose_pulse_after_growth       | natural_sugar_pulse      | natural   |         216 |           185.45  |                          0.982 |                           0.926 | Natural must with glucose perturbation to test sugar-transfer validity.                            |
|                9 | synthetic_fast_CO2_aroma_strip_highN     | co2_aroma_loss           | synthetic |         168 |           187.108 |                          0.984 |                           0.935 | High-rate fermentation excites CO2 stripping and liquid/condensate aroma split.                    |

El criterio principal fue D-optimalidad:

$$
\Phi_D(d)=\log\det(F(\theta,d)+\epsilon I)
$$

con criterios complementarios:

$$
\Phi_A(d)=tr(F^{-1})
$$

La politica con restriccion de volumen seleccionada fue `full14_small6`, que combina muestras completas y pequenas para mantener volumen final viable en reactores de 2 L.

**Benchmark de politicas de muestreo/volumen**

| policy         |   campaign_logdet |   campaign_min_relative_eigenvalue |   campaign_trace_inv |   new_param_mean_var_reduction |   new_param_worst_var_reduction | selected_candidates                                                                                                                                                                                                                                                                                                                         |
|:---------------|------------------:|-----------------------------------:|---------------------:|-------------------------------:|--------------------------------:|:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| full14_small6  |           187.108 |                          1.414e-06 |                2.225 |                          0.984 |                           0.935 | synthetic_lit_SM410_18C_highN_ester, synthetic_high_biomass_low_N_maintenance, synthetic_fructose_rich_glucose_pulse, synthetic_glucose_rich_fructose_pulse, synthetic_lit_SM410_24C_highN_strip, synthetic_viable_biomass_step, synthetic_high_sugar_reference, natural_glucose_pulse_after_growth, synthetic_fast_CO2_aroma_strip_highN   |
| full12_small8  |           181.978 |                          1.197e-06 |                2.862 |                          0.983 |                           0.931 | synthetic_lit_SM410_18C_highN_ester, synthetic_high_biomass_low_N_maintenance, synthetic_fructose_rich_glucose_pulse, synthetic_glucose_rich_fructose_pulse, synthetic_lit_SM410_24C_highN_strip, synthetic_viable_biomass_step, synthetic_high_sugar_reference, synthetic_fast_CO2_aroma_strip_highN, natural_glucose_pulse_after_growth   |
| full10_small10 |           179.137 |                          1.215e-06 |                2.959 |                          0.982 |                           0.924 | synthetic_lit_SM410_18C_highN_ester, synthetic_high_biomass_low_N_maintenance, synthetic_fructose_rich_glucose_pulse, synthetic_glucose_rich_fructose_pulse, synthetic_lit_SM410_24C_highN_strip, synthetic_viable_biomass_step, synthetic_high_sugar_reference, natural_glucose_pulse_after_growth, synthetic_lit_SM230_18C_midN_reference |

Figuras:

- `figures/fig03_doe_policy_benchmark.png`
- `figures/fig04_volume_audit.png`
- `figures/fig08_selected_campaign_designs_montage.png`

**Stocks y restricciones operacionales**

| channel   |   stock_concentration | unit                |   max_single_pulse_ml_target | comment                                                                                     |
|:----------|----------------------:|:--------------------|-----------------------------:|:--------------------------------------------------------------------------------------------|
| N         |                    20 | mg_N_per_mL         |                           15 | 20 mg YAN-N/mL gives 5-6 mL for a 50-60 mg/L pulse in 2 L.                                  |
| G         |                   700 | g_per_L             |                          125 | 700 g/L is concentrated and viscous but keeps 35 g/L in 2 L near 100 mL.                    |
| F         |                   700 | g_per_L             |                          125 | Use same concentration as glucose because fructose is treated as equivalent sugar.          |
| E         |                   789 | g_per_L             |                           80 | Pure ethanol basis; not used in selected hybrid campaign.                                   |
| X         |                   100 | g_dry_biomass_per_L |                           35 | Dry-biomass-equivalent concentrated slurry; verify viable cell concentration before dosing. |

## 8. Analisis de aromas, condensados y QA/QC

La capa de aromas considera, como minimo, etil acetato, isoamyl acetate y ethyl octanoate en el modelo, y deja trazabilidad para extender a bencil alcohol, benzaldehido, decanoato de etilo, hexil acetato, phenylethyl acetate y otros marcadores disponibles.

La formulacion usada separa:

- produccion liquida aparente dependiente de fase metabolica;
- perdida gas-liquido fijada por literatura/UNIFAC o surrogate validado;
- CO2 online como senal de tasa de fermentacion;
- condensado terminal como restriccion de cierre de masa, no como dinamica gas en linea.

El balance conceptual por aroma `a` es:

$$
\frac{dC_{a,L}}{dt}=r_{a,prod}(x,\theta_a,T)-r_{a,loss}(C_{a,L},T,F_{CO2})
$$

$$
\frac{dM_{a,cond}}{dt}=\eta_{trap}\,r_{a,loss}(C_{a,L},T,F_{CO2})V_L
$$

Los parametros de particion se fijan por literatura para evitar confundir equilibrio gas-liquido con sintesis biologica. Los parametros libres principales quedan asociados a sintesis por fase.

**Aroma DOE seleccionado**

|   campaign_order | candidate                           | family           |   horizon_h | temperature_c   | rationale                                                                                                       |   campaign_score |   campaign_logdet |   campaign_min_eigenvalue |   campaign_min_relative_eigenvalue |   campaign_condition_number |   campaign_trace |   campaign_trace_inv |   campaign_var_mu0 |   campaign_var_sN |   campaign_var_qN |   campaign_var_qXG |   campaign_var_qXF |   campaign_var_betaG0 |   campaign_var_sG |   campaign_var_betaF0 |   campaign_var_sF |   campaign_var_qEG |   campaign_var_qEF |   campaign_var_iG |   campaign_var_iE |   campaign_var_Kd0 |   campaign_var_m0 |   campaign_var_k_EA_growth |   campaign_var_k_EA_stationary |   campaign_var_k_IAA_growth |   campaign_var_k_IAA_stationary |   campaign_var_k_EO_growth |   campaign_var_k_EO_stationary |   var_ratio_mu0 |   var_reduction_mu0 |   var_ratio_sN |   var_reduction_sN |   var_ratio_qN |   var_reduction_qN |   var_ratio_qXG |   var_reduction_qXG |   var_ratio_qXF |   var_reduction_qXF |   var_ratio_betaG0 |   var_reduction_betaG0 |   var_ratio_sG |   var_reduction_sG |   var_ratio_betaF0 |   var_reduction_betaF0 |   var_ratio_sF |   var_reduction_sF |   var_ratio_qEG |   var_reduction_qEG |   var_ratio_qEF |   var_reduction_qEF |   var_ratio_iG |   var_reduction_iG |   var_ratio_iE |   var_reduction_iE |   var_ratio_Kd0 |   var_reduction_Kd0 |   var_ratio_m0 |   var_reduction_m0 |   var_ratio_k_EA_growth |   var_reduction_k_EA_growth |   var_ratio_k_EA_stationary |   var_reduction_k_EA_stationary |   var_ratio_k_IAA_growth |   var_reduction_k_IAA_growth |   var_ratio_k_IAA_stationary |   var_reduction_k_IAA_stationary |   var_ratio_k_EO_growth |   var_reduction_k_EO_growth |   var_ratio_k_EO_stationary |   var_reduction_k_EO_stationary |   mean_var_reduction |   worst_var_reduction |
|-----------------:|:------------------------------------|:-----------------|------------:|:----------------|:----------------------------------------------------------------------------------------------------------------|-----------------:|------------------:|--------------------------:|-----------------------------------:|----------------------------:|-----------------:|---------------------:|-------------------:|------------------:|------------------:|-------------------:|-------------------:|----------------------:|------------------:|----------------------:|------------------:|-------------------:|-------------------:|------------------:|------------------:|-------------------:|------------------:|---------------------------:|-------------------------------:|----------------------------:|--------------------------------:|---------------------------:|-------------------------------:|----------------:|--------------------:|---------------:|-------------------:|---------------:|-------------------:|----------------:|--------------------:|----------------:|--------------------:|-------------------:|-----------------------:|---------------:|-------------------:|-------------------:|-----------------------:|---------------:|-------------------:|----------------:|--------------------:|----------------:|--------------------:|---------------:|-------------------:|---------------:|-------------------:|----------------:|--------------------:|---------------:|-------------------:|------------------------:|----------------------------:|----------------------------:|--------------------------------:|-------------------------:|-----------------------------:|-----------------------------:|---------------------------------:|------------------------:|----------------------------:|----------------------------:|--------------------------------:|---------------------:|----------------------:|
|                1 | fructose_rich_iG_probe              | sugar_initial    |         192 | 18, 20, 24, 22  | Fructose-rich must plus glucose pulse separates fructose capacity from glucose inhibition iG.                   |          105.576 |           115.984 |                     1.289 |                          3.975e-06 |                      251600 |   477800         |                2.195 |          0.00055   |             0.116 |         0.0005653 |              0.235 |              0.327 |             0.002     |             0.011 |             0.002     |             0.025 |          0.003     |          0.003     |         0.018     |         0.005     |          0.011     |             0.627 |                      0.246 |                      0.001     |                       0.182 |                       0.0005089 |                      0.378 |                      0.001     |           0.277 |               0.723 |          0.698 |              0.302 |          0.352 |              0.648 |           0.175 |               0.825 |           0.222 |               0.778 |              0.14  |                  0.86  |          0.192 |              0.808 |              0.026 |                  0.974 |          0.344 |              0.656 |           0.223 |               0.777 |           0.027 |               0.973 |          0.04  |              0.96  |          0.194 |              0.806 |       0.031     |               0.969 |          0.183 |              0.817 |                   0.061 |                       0.939 |                   0.0003281 |                               1 |                    0.046 |                        0.954 |                    0.0001272 |                                1 |                   0.095 |                       0.905 |                   0.0002791 |                               1 |                0.842 |                 0.302 |
|                2 | cold_synthesis_hot_stripping        | aroma_partition  |         192 | 15, 16, 24, 25  | Low-temperature synthesis window followed by high-temperature stripping challenge.                              |          123.439 |           129.769 |                     1.893 |                          3.758e-06 |                      266100 |   738100         |                1.255 |          0.0003388 |             0.087 |         0.0003569 |              0.14  |              0.146 |             0.001     |             0.004 |             0.0009995 |             0.016 |          0.002     |          0.002     |         0.005     |         0.002     |          0.002     |             0.44  |                      0.122 |                      0.000702  |                       0.091 |                       0.000273  |                      0.19  |                      0.0006061 |           0.17  |               0.83  |          0.52  |              0.48  |          0.222 |              0.778 |           0.105 |               0.895 |           0.099 |               0.901 |              0.071 |                  0.929 |          0.076 |              0.924 |              0.014 |                  0.986 |          0.217 |              0.783 |           0.127 |               0.873 |           0.018 |               0.982 |          0.01  |              0.99  |          0.096 |              0.904 |       0.007     |               0.993 |          0.128 |              0.872 |                   0.031 |                       0.969 |                   0.0001755 |                               1 |                    0.023 |                        0.977 |                    6.824e-05 |                                1 |                   0.048 |                       0.952 |                   0.0001515 |                               1 |                0.906 |                 0.48  |
|                3 | low_temp_growth_separation_plus_co2 | legacy_plus      |         168 | 15, 17, 20, 22  | Previous robust N/T design, now measured with Xd and online CO2.                                                |          132.792 |           135.931 |                     5.167 |                          8.831e-06 |                      113200 |   892400         |                0.684 |          0.0002588 |             0.077 |         0.0002772 |              0.065 |              0.083 |             0.0008705 |             0.004 |             0.0006986 |             0.011 |          0.001     |          0.001     |         0.004     |         0.002     |          0.002     |             0.176 |                      0.076 |                      0.0005354 |                       0.058 |                       0.0002048 |                      0.121 |                      0.0004647 |           0.13  |               0.87  |          0.459 |              0.541 |          0.172 |              0.828 |           0.049 |               0.951 |           0.057 |               0.943 |              0.055 |                  0.945 |          0.068 |              0.932 |              0.01  |                  0.99  |          0.147 |              0.853 |           0.079 |               0.921 |           0.01  |               0.99  |          0.009 |              0.991 |          0.081 |              0.919 |       0.006     |               0.994 |          0.051 |              0.949 |                   0.019 |                       0.981 |                   0.0001338 |                               1 |                    0.014 |                        0.986 |                    5.12e-05  |                                1 |                   0.03  |                       0.97  |                   0.0001162 |                               1 |                0.931 |                 0.541 |
|                4 | combined_stress_long_horizon        | integrated       |         240 | 15, 22, 25, 18  | Broad stress/input design for integrated all-parameter information.                                             |          140.358 |           143.208 |                     5.79  |                          7.531e-06 |                      132800 |        1.173e+06 |                0.559 |          0.0002307 |             0.072 |         0.0002558 |              0.047 |              0.062 |             0.0007117 |             0.002 |             0.0006058 |             0.007 |          0.0008421 |          0.001     |         0.002     |         0.001     |          0.0005262 |             0.155 |                      0.061 |                      0.0003411 |                       0.046 |                       0.0001338 |                      0.097 |                      0.0002973 |           0.116 |               0.884 |          0.434 |              0.566 |          0.159 |              0.841 |           0.035 |               0.965 |           0.042 |               0.958 |              0.045 |                  0.955 |          0.044 |              0.956 |              0.008 |                  0.992 |          0.103 |              0.897 |           0.059 |               0.941 |           0.008 |               0.992 |          0.005 |              0.995 |          0.06  |              0.94  |       0.001     |               0.999 |          0.045 |              0.955 |                   0.015 |                       0.985 |                   8.529e-05 |                               1 |                    0.012 |                        0.988 |                    3.344e-05 |                                1 |                   0.024 |                       0.976 |                   7.432e-05 |                               1 |                0.942 |                 0.566 |
|                5 | yan_saturation_scan                 | saturation       |         144 | 15, 18, 22, 22  | Designed N ladder through low/intermediate YAN targets sN/qN separation.                                        |          145.705 |           145.211 |                     6.934 |                          8.593e-06 |                      116400 |        1.225e+06 |                0.492 |          0.0001427 |             0.048 |         0.0001773 |              0.046 |              0.059 |             0.0004592 |             0.002 |             0.000469  |             0.007 |          0.0005771 |          0.0008811 |         0.002     |         0.0008729 |          0.0004926 |             0.13  |                      0.058 |                      0.0003163 |                       0.043 |                       0.0001252 |                      0.092 |                      0.0002767 |           0.072 |               0.928 |          0.288 |              0.712 |          0.11  |              0.89  |           0.034 |               0.966 |           0.04  |               0.96  |              0.029 |                  0.971 |          0.042 |              0.958 |              0.006 |                  0.994 |          0.092 |              0.908 |           0.04  |               0.96  |           0.007 |               0.993 |          0.004 |              0.996 |          0.036 |              0.964 |       0.001     |               0.999 |          0.038 |              0.962 |                   0.014 |                       0.986 |                   7.907e-05 |                               1 |                    0.011 |                        0.989 |                    3.129e-05 |                                1 |                   0.023 |                       0.977 |                   6.919e-05 |                               1 |                0.958 |                 0.712 |
|                6 | glucose_rich_growth_yield           | sugar_initial    |         168 | 18, 22, 24, 20  | High glucose must isolates glucose growth/fermentation terms and tests fructose response after glucose history. |          150.62  |           149.394 |                     9.94  |                          9.926e-06 |                      100800 |        1.49e+06  |                0.393 |          0.0001183 |             0.045 |         0.000153  |              0.036 |              0.043 |             0.0003215 |             0.002 |             0.0003708 |             0.004 |          0.000455  |          0.0006565 |         0.001     |         0.0007258 |          0.0004641 |             0.09  |                      0.05  |                      0.0002713 |                       0.037 |                       0.0001084 |                      0.08  |                      0.0002375 |           0.06  |               0.94  |          0.269 |              0.731 |          0.095 |              0.905 |           0.027 |               0.973 |           0.029 |               0.971 |              0.02  |                  0.98  |          0.038 |              0.962 |              0.005 |                  0.995 |          0.051 |              0.949 |           0.032 |               0.968 |           0.005 |               0.995 |          0.003 |              0.997 |          0.03  |              0.97  |       0.001     |               0.999 |          0.026 |              0.974 |                   0.012 |                       0.988 |                   6.783e-05 |                               1 |                    0.009 |                        0.991 |                    2.709e-05 |                                1 |                   0.02  |                       0.98  |                   5.938e-05 |                               1 |                0.965 |                 0.731 |
|                7 | high_biomass_low_N_maintenance      | maintenance      |         168 | 16, 18, 20, 18  | High biomass and low N create low-growth sugar consumption windows for m0.                                      |          154.108 |           152.425 |                    12.039 |                          1.178e-05 |                       84860 |        1.546e+06 |                0.34  |          9.699e-05 |             0.044 |         0.0001144 |              0.031 |              0.034 |             0.0002523 |             0.002 |             0.0003095 |             0.004 |          0.0003408 |          0.0005358 |         0.001     |         0.0006938 |          0.0004505 |             0.077 |                      0.043 |                      0.000215  |                       0.032 |                       8.694e-05 |                      0.068 |                      0.000189  |           0.049 |               0.951 |          0.265 |              0.735 |          0.071 |              0.929 |           0.023 |               0.977 |           0.023 |               0.977 |              0.016 |                  0.984 |          0.036 |              0.964 |              0.004 |                  0.996 |          0.049 |              0.951 |           0.024 |               0.976 |           0.004 |               0.996 |          0.003 |              0.997 |          0.029 |              0.971 |       0.001     |               0.999 |          0.023 |              0.977 |                   0.011 |                       0.989 |                   5.375e-05 |                               1 |                    0.008 |                        0.992 |                    2.174e-05 |                                1 |                   0.017 |                       0.983 |                   4.725e-05 |                               1 |                0.969 |                 0.735 |
|                8 | ethanol_initial_challenge           | ethanol          |         192 | 18, 22, 25, 22  | Initial ethanol decouples ethanol inhibition iE from ethanol produced by fermentation.                          |          156.584 |           154.452 |                    13.874 |                          1.199e-05 |                       83380 |        1.727e+06 |                0.31  |          9.523e-05 |             0.041 |         0.0001115 |              0.027 |              0.029 |             0.0002134 |             0.002 |             0.000276  |             0.003 |          0.0002958 |          0.0004701 |         0.001     |         0.0005864 |          0.0003492 |             0.068 |                      0.04  |                      0.0001897 |                       0.03  |                       7.683e-05 |                      0.064 |                      0.0001671 |           0.048 |               0.952 |          0.246 |              0.754 |          0.069 |              0.931 |           0.02  |               0.98  |           0.02  |               0.98  |              0.013 |                  0.987 |          0.031 |              0.969 |              0.004 |                  0.996 |          0.045 |              0.955 |           0.021 |               0.979 |           0.004 |               0.996 |          0.003 |              0.997 |          0.024 |              0.976 |       0.0009812 |               0.999 |          0.02  |              0.98  |                   0.01  |                       0.99  |                   4.742e-05 |                               1 |                    0.008 |                        0.992 |                    1.921e-05 |                                1 |                   0.016 |                       0.984 |                   4.177e-05 |                               1 |                0.971 |                 0.754 |
|                9 | glucose_pulse_after_N_depletion     | pulse_separation |         192 | 17, 20, 24, 22  | Glucose pulse after likely N limitation separates fermentation/maintenance from growth uptake.                  |          158.589 |           155.98  |                    15.768 |                          1.296e-05 |                       77160 |        1.81e+06  |                0.282 |          9.284e-05 |             0.039 |         0.0001103 |              0.025 |              0.026 |             0.0001862 |             0.001 |             0.00023   |             0.003 |          0.0002493 |          0.0003733 |         0.0009746 |         0.0003886 |          0.0003413 |             0.054 |                      0.039 |                      0.0001731 |                       0.029 |                       7.03e-05  |                      0.062 |                      0.0001528 |           0.047 |               0.953 |          0.231 |              0.769 |          0.069 |              0.931 |           0.019 |               0.981 |           0.018 |               0.982 |              0.012 |                  0.988 |          0.023 |              0.977 |              0.003 |                  0.997 |          0.044 |              0.956 |           0.017 |               0.983 |           0.003 |               0.997 |          0.002 |              0.998 |          0.016 |              0.984 |       0.0009591 |               0.999 |          0.016 |              0.984 |                   0.01  |                       0.99  |                   4.327e-05 |                               1 |                    0.007 |                        0.993 |                    1.758e-05 |                                1 |                   0.015 |                       0.985 |                   3.82e-05  |                               1 |                0.974 |                 0.769 |

**Benchmark aroma D-opt**

| design                    |   n_experiments |   logdet |   min_relative_eigenvalue |   condition_number |   trace_inv |   mean_var_reduction |   worst_var_reduction | worst_parameter   |   sN_var_reduction |   qN_var_reduction |   mu0_var_reduction |   k_EA_growth_var_reduction |   k_IAA_growth_var_reduction |   k_EO_growth_var_reduction |
|:--------------------------|----------------:|---------:|--------------------------:|-------------------:|------------:|---------------------:|----------------------:|:------------------|-------------------:|-------------------:|--------------------:|----------------------------:|-----------------------------:|----------------------------:|
| hybrid_current            |               9 |   155.98 |                 1.296e-05 |              77160 |       0.282 |                0.974 |                 0.769 | sN                |              0.769 |              0.931 |               0.953 |                       0.99  |                        0.993 |                       0.985 |
| dopt_greedy               |               9 |   156.48 |                 1.174e-05 |              85170 |       0.292 |                0.967 |                 0.655 | sN                |              0.655 |              0.907 |               0.935 |                       0.991 |                        0.993 |                       0.985 |
| dopt_exchange_from_hybrid |               9 |   156.48 |                 1.174e-05 |              85170 |       0.292 |                0.967 |                 0.655 | sN                |              0.655 |              0.907 |               0.935 |                       0.991 |                        0.993 |                       0.985 |

**Reduccion esperada de varianza**

| parameter        | group        |   campaign_var_ratio |   campaign_var_reduction |
|:-----------------|:-------------|---------------------:|-------------------------:|
| mu0              | fermentation |            0.047     |                    0.953 |
| sN               | fermentation |            0.231     |                    0.769 |
| qN               | fermentation |            0.069     |                    0.931 |
| qXG              | fermentation |            0.019     |                    0.981 |
| qXF              | fermentation |            0.018     |                    0.982 |
| betaG0           | fermentation |            0.012     |                    0.988 |
| sG               | fermentation |            0.023     |                    0.977 |
| betaF0           | fermentation |            0.003     |                    0.997 |
| sF               | fermentation |            0.044     |                    0.956 |
| qEG              | fermentation |            0.017     |                    0.983 |
| qEF              | fermentation |            0.003     |                    0.997 |
| iG               | fermentation |            0.002     |                    0.998 |
| iE               | fermentation |            0.016     |                    0.984 |
| Kd0              | fermentation |            0.0009591 |                    0.999 |
| m0               | fermentation |            0.016     |                    0.984 |
| k_EA_growth      | synthesis    |            0.01      |                    0.99  |
| k_EA_stationary  | synthesis    |            4.327e-05 |                    1     |
| k_IAA_growth     | synthesis    |            0.007     |                    0.993 |
| k_IAA_stationary | synthesis    |            1.758e-05 |                    1     |
| k_EO_growth      | synthesis    |            0.015     |                    0.985 |
| k_EO_stationary  | synthesis    |            3.82e-05  |                    1     |

Figuras:

- `figures/fig06_aroma_parameter_reduction.png`
- `figures/fig07_aroma_doe_benchmark.png`
- `figures/source_aroma_eigen_spectrum.png`

**Plan QA/QC**

| qa_qc_item           | procedure                                                                    | acceptance_or_action                             |
|:---------------------|:-----------------------------------------------------------------------------|:-------------------------------------------------|
| chemical_calibration | external calibration curve plus internal standard where applicable           | R2 >= 0.99 or method SOP threshold               |
| blank_control        | solvent/process blank for aroma and condensate analysis                      | below LOQ or documented correction               |
| duplicate_sample     | at least one duplicate per analytical batch or critical timepoint            | RSD <= method threshold                          |
| spike_recovery       | matrix spike for representative wine/condensate                              | 70-130% unless method-specific criterion applies |
| mass_balance         | wine + condensate + residual/gas closure for target aromatics where possible | qualitative/quantitative closure reported        |
| sensor_qc            | CO2 zero/span check and timestamp synchronization                            | documented before/after run                      |
| sample_traceability  | reactor, lot, treatment, time, volume, preservative, storage                 | complete chain-of-custody fields                 |

## 9. KPIs de eficiencia para comparacion in vivo

Los KPIs preparados para A12 separan eficiencia fermentativa, eficiencia operacional, calidad quimica y retencion aromatica.

| kpi                      | definition                                    | unit          | interpretation                              |
|:-------------------------|:----------------------------------------------|:--------------|:--------------------------------------------|
| fermentation_time_h      | time to residual sugar gate or endpoint       | h             | shorter is better under quality constraints |
| final_residual_sugar_g_l | G+F at endpoint                               | g/L           | primary dryness/productivity metric         |
| ethanol_g_l              | ethanol at endpoint                           | g/L           | yield and product specification             |
| glycerol_g_l             | glycerol at endpoint                          | g/L           | quality/metabolic side product              |
| co2_cumulative_g         | integrated CO2 sensor signal                  | g or mol      | fermentation rate and mass balance          |
| yan_consumed_mg_l        | initial YAN minus terminal YAN                | mg/L          | nitrogen use efficiency                     |
| nutrient_added_mg_l      | sum of nitrogen additions                     | mg/L          | input cost/process intervention             |
| temperature_energy_proxy | mean squared deviation from ambient/reference | dimensionless | thermal operation cost                      |
| aroma_wine_ug_l          | target aroma concentration in wine            | ug/L          | chemical quality marker                     |
| aroma_condensate_ug      | terminal trapped aroma mass                   | ug            | volatilized-loss closure                    |
| aroma_retention_ratio    | wine mass / total produced mass               | dimensionless | aroma retention efficiency                  |
| volume_removed_ml        | liquid removed by samples                     | mL            | sampling burden/operational feasibility     |

La comparacion final debe reportarse por tratamiento, lote y replica:

$$
\Delta KPI = KPI_{optimal}-KPI_{commercial}
$$

con normalizacion multicriterio:

$$
z_j(d)=\frac{KPI_j(d)-KPI_j^{min}}{KPI_j^{max}-KPI_j^{min}}
$$

y score agregado:

$$
Score(d)=\sum_j w_j z_j(d)
$$

Los pesos deben quedar definidos antes de mirar resultados finales para evitar sesgo posterior.

## 10. Bitacoras, incidencias y datos crudos

Este bundle incluye plantillas en `templates/`:

- `execution_log_template.csv`
- `qaqc_plan.csv`
- `kpi_schema.csv`

El inventario de fuentes queda en:

| source                        | description                                           | role                                             | bundle_handling                             |
|:------------------------------|:------------------------------------------------------|:-------------------------------------------------|:--------------------------------------------|
| mosto_sintetico_vl3.xlsx      | historical/current synthetic must data                | used for calibration/validation                  | not copied; summarized by normalized tables |
| mosto_natural_xthiol.xlsx     | natural must transfer data                            | used for model comparison and transfer diagnosis | not copied; summarized by normalized tables |
| A09 bundle/PDF                | MPCC, KKT, MCDM and preliminary protocol optimization | cross-reference for optimal protocol work        | selected docs/tables/figures copied         |
| new in-vivo lot logs          | actual vinification execution records                 | pending ingestion                                | templates included                          |
| aroma wine/condensate reports | GC or equivalent analytical reports                   | pending ingestion                                | QA/QC and schema included                   |

Las fotos, cromatogramas/reportes analiticos originales, bitacoras firmadas y datos crudos de la nueva campana no se incluyen porque aun no estan cerrados en el repositorio actual. Deben anexarse en la version final posterior a ejecucion.

## 11. Interpretacion y decision tecnica

La decision recomendada es **no cerrar todavia protocolos optimos realistas para ejecucion comparativa final**. La evidencia justifica postergar la actividad in vivo final hasta completar:

1. Ingestion de datos reales del primer lote.
2. Recalibracion del modelo con tiempos, pulsos y condiciones iniciales ejecutadas.
3. Recalculo de FIM/perfiles para identificar parametros aun debiles.
4. Recalculo de politicas MPCC sobre el modelo calibrado.
5. Seleccion multicriterio congelada antes de ejecutar comparacion optimo vs comercial.

Esta decision evita que la optimizacion MPCC produzca artefactos derivados de parametros no identificables, estados secundarios mal ajustados o una capa aromatica aun no validada in vivo.

## 12. Conclusiones

- El Gemelo Digital ya cuenta con una base ODE calibrada/validada, diagnostico de estimabilidad y diseno MBDoE operacionalizable.
- El pipeline A09 demuestra capacidad de optimizacion dinamica dFBA/KKT/MPCC/MCDM, pero aun bajo modelo nominal.
- La campana propuesta de 9 fermentaciones es defendible como etapa de robustecimiento previo a A12 final.
- La actividad 5.7 queda metodologicamente cubierta por el plan de aromas, CO2 y condensado, aunque los resultados analiticos finales siguen pendientes.
- La actividad 5.8 queda cubierta como marco KPI y preparacion de comparacion; el resultado cuantitativo in vivo requiere ejecutar y cerrar la campana.

## 13. Contenido del bundle

- `A12_report.md`: este reporte principal.
- `README_BUNDLE.md`: guia de lectura.
- `CLAIMS_Y_LIMITACIONES_A12.md`: claims defendibles y no defendibles.
- `figures/`: figuras compactas de validacion, DOE, aromas y MPCC.
- `tables/`: tablas agregadas y schemas.
- `templates/`: bitacora, QA/QC y KPIs.
- `source_trace/`: documentos fuente A08/A09 y reportes tecnicos seleccionados.
