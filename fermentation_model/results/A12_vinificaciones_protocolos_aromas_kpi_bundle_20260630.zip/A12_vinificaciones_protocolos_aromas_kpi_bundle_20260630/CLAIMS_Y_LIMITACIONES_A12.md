# Claims y limitaciones A12

## Claims respaldados

- Se dispone de un pipeline de calibracion, validacion, estimabilidad y MBDoE para el modelo de fermentacion.
- Se dispone de una campana experimental operacionalizable de 9 fermentaciones, 3 lotes, con restriccion de volumen y muestreo.
- Se dispone de una formulacion MPCC/dFBA/KKT/MCDM preliminar documentada en A09.
- Se dispone de un plan de analisis de aromas en vino y condensado, con CO2 online y condensado terminal como cierre de masa parcial.
- Se dispone de schemas de KPI, QA/QC y bitacora para ejecutar A12 de forma trazable.

## Claims parciales

- Los protocolos optimos existen como candidatos metodologicos o preliminares, no como protocolos realistas finales.
- La comparacion optimo vs comercial esta disenada conceptualmente, pero no cerrada con resultados in vivo.
- La capa aromatica permite disenar experimentos y definir mediciones, pero aun no entrega estadistica final por tratamiento.

## Claims que no deben hacerse

- No afirmar que las vinificaciones A12 finales ya compararon protocolo optimo versus comercial.
- No afirmar que el candidato MPCC A09 es optimo global o recomendacion industrial final.
- No afirmar que los marcadores aromaticos en vino/condensado ya fueron estadisticamente comparados entre protocolos finales.
- No afirmar eficiencia in vivo superior hasta tener datos ejecutados, QA/QC aprobado y analisis estadistico.

## Mensaje defendible

El avance A12 queda tecnicamente respaldado como transicion desde optimizacion nominal hacia validacion experimental robusta. La postergacion del cierre in vivo final se justifica porque ejecutar protocolos optimos no recalibrados podria validar artefactos del modelo, no mejoras reales de proceso.
