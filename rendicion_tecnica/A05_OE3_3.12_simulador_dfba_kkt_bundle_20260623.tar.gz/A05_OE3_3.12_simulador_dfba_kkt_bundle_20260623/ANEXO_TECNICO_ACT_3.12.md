# Anexo tecnico - Actividad 3.12: Implementacion del simulador dFBA/KKT

## Identificacion

- Proyecto: `PI-4497`
- Instancia: `IA5`
- Actividad: `A05 / OE3 / 3.12`
- Anexo sugerido: `PI-4497_IA5_A05_Act-3.12_Simulador-dFBA-KKT.pdf`
- Repositorio fuente: `DC_dFVB_2026`
- Fecha de preparacion del bundle: `2026-06-23`

## Objetivo del anexo

Documentar la evidencia tecnica que respalda la implementacion del simulador
dFBA/KKT asociado al uso de MPCC para simulacion y optimizacion. El anexo
reune arquitectura de software, formulacion matematica, pruebas unitarias,
scripts reproducibles, resultados computacionales y bitacoras de ejecucion.

## Resumen ejecutivo de cumplimiento

La actividad se considera cubierta a nivel de evidencia tecnica porque el
repositorio contiene una implementacion modular en Julia para:

- carga y validacion de modelos metabolicos reducidos y completos;
- simulacion secuencial dFBA y rutas complementarias DFVB;
- formulacion KKT estructural para dFBA reducido;
- discretizacion por collocation para una formulacion directa DC-dFBA;
- filas MPCC de factibilidad primal, factibilidad de cotas, estacionariedad y
  complementariedad;
- relajacion de complementariedad tipo Scholtes;
- entrada controlada a Ipopt para problemas MPCC reducidos;
- diagnosticos de residual, viabilidad, sensibilidad de malla, continuacion,
  retry, terminacion y candidatos;
- scripts de ejecucion local/cluster y bitacoras de resultados;
- suite amplia de pruebas unitarias y contratos.

El cumplimiento recomendado para rendicion es `100%` respecto de la fila
solicitada, entendido como implementacion y documentacion tecnica del
simulador/formulacion y sus evidencias. La declaracion no debe interpretarse
como que toda optimizacion MPCC simultanea de largo horizonte ya produce una
trayectoria final validada biologicamente; varias campañas se documentan
explicitamente como diagnosticas.

## Arquitectura del simulador

El repositorio esta organizado como paquete Julia `FermentationDFBA`. La API
principal se centraliza en `src/FermentationDFBA.jl`, desde donde se exportan
tipos, constructores, validadores, simuladores, rutinas MPCC, diagnosticos y
exportadores.

Componentes principales:

- `src/IO`: carga de configuraciones, modelos reducidos/completos y artefactos
  DFVB.
- `src/Types`: contratos de datos para modelos metabolicos, mapas de reacciones
  y resultados de simulacion.
- `src/LP`: problemas FBA/DFVB en JuMP.
- `src/Sequential`: RHS y simuladores secuenciales dFBA/DFVB.
- `src/Kinetics`: cinetica estilo Zenteno y cotas dinamicas.
- `src/Optimization`: controles dinamicos de temperatura/nutrientes y objetivos
  para vino blanco/aromas/productividad.
- `src/Simultaneous`: collocation, KKT-dFBA, NLP y MPCC reducido.
- `src/Validation`: comparaciones, benchmarks, diagnosticos y barridos MPCC.
- `src/Performance`: benchmarks de persistencia/warm-start.
- `src/Visualization`: graficos SVG/plots sin dependencia pesada.

Dependencias tecnicas centrales:

- `JuMP`: modelamiento de LP/NLP/MPCC.
- `HiGHS`: solver LP requerido por defecto.
- `Ipopt`: solver NLP para smokes y solve-attempts MPCC.
- `MathOptInterface`: estados de solver y contratos.
- `OrdinaryDiffEq`: integracion ODE para simulacion secuencial.
- `CSV`, `DataFrames`, `TOML`: datos, tablas y metadata.

## Formulacion dFBA/KKT/MPCC

La formulacion implementada se basa en el modelo metabolico reducido y en una
discretizacion temporal por elementos finitos/collocation. A nivel conceptual,
para cada punto de collocation se imponen componentes de FBA y KKT:

```text
S v = 0
lb(x,t) <= v <= ub(x,t)
c + S'lambda + alpha_L + alpha_U = 0
(v - lb) * alpha_L = 0
(v - ub) * alpha_U = 0
dx/dt = f(x, v, u, t)
```

Donde:

- `S` es la matriz estequiometrica;
- `v` es el vector de flujos;
- `lb`, `ub` son cotas fijas o dinamicas dependientes del estado/tiempo;
- `lambda` son duales de balance de masa;
- `alpha_L`, `alpha_U` son duales de cotas inferior/superior;
- `u` representa controles dinamicos como temperatura, FDA y nutriente organico;
- las ecuaciones de estado se discretizan mediante collocation.

En el repositorio esto se evidencia en:

- `src/Simultaneous/kkt_dfba.jl`: scaffold KKT-dFBA reducido, dimensiones,
  roles de reaccion, contrato de oxigeno/carbohidratos y metadata.
- `src/Simultaneous/reduced_dcdfba_collocation_nlp.jl`: variables JuMP,
  constraints de collocation, RHS, factibilidad primal, factibilidad de cotas,
  estacionariedad, complementariedad, perfiles Ipopt, guardrails y solve
  attempts.
- `test/test_reduced_dcdfba_stationarity.jl`: pruebas de ecuaciones de
  estacionariedad.
- `test/test_reduced_dcdfba_complementarity.jl`: pruebas de productos de
  complementariedad exacta y relajacion Scholtes.
- `test/test_reduced_dcdfba_mpcc_smoke.jl`: contrato MPCC reducido y entrada
  controlada a solver.

## Evidencia de datos y contratos del modelo

El simulador trabaja con exportaciones MATLAB del modelo reducido y del modelo
completo. La arquitectura evita depender de indices fragiles y prioriza mapeo
por identificadores de reaccion. Las politicas relevantes quedan documentadas
en README y tests:

- modelo reducido: 1079 metabolitos y 1488 reacciones;
- estado dinamico dFBA: 19 estados;
- reaccion de biomasa: `r_2111`;
- glucosa: `r_1714`;
- fructosa: `r_1709`;
- etanol: `r_1761`;
- ATP maintenance: `r_4046`;
- proteina: `r_4047`;
- carbohidrato: `r_4048`;
- oxigeno `r_1992` ausente/deshabilitado en reducido;
- `r_0001` no se usa como oxigeno.

Estos puntos son relevantes para una rendicion tecnica porque muestran que la
implementacion cuida consistencia biologica/computacional y que no solo se
construyo un solver numerico abstracto.

## Pruebas unitarias y cobertura funcional

El bundle incluye copia de `test/`, con 84 archivos de prueba. La suite cubre:

- carga de modelos y contratos de dimensiones;
- FBA estatico reducido/completo;
- RHS dFBA/DFVB;
- simulacion secuencial;
- metricas y exportacion;
- collocation grid;
- scaffold KKT;
- RHS residuals;
- primal feasibility;
- bound feasibility;
- stationarity;
- complementarity;
- MPCC smoke;
- solve attempts;
- diagnosticos de candidatos;
- comparaciones secuenciales;
- benchmarks;
- scripts/entrypoints.

Para evidencia de anexo, las pruebas mas directamente asociadas a la actividad
3.12 son:

```text
test/test_collocation_grid.jl
test/test_kkt_dfba_scaffold.jl
test/test_reduced_dcdfba_collocation_nlp.jl
test/test_reduced_dcdfba_rhs_residuals.jl
test/test_reduced_dcdfba_primal_feasibility.jl
test/test_reduced_dcdfba_bound_feasibility.jl
test/test_reduced_dcdfba_stationarity.jl
test/test_reduced_dcdfba_complementarity.jl
test/test_reduced_dcdfba_mpcc_smoke.jl
test/test_reduced_dcdfba_mpcc_solve_attempt.jl
```

## Scripts reproducibles

El bundle incluye copia de `scripts/`, con 80 scripts. Los mas relevantes para
esta actividad son:

- `main_static_fba_reduced.jl`
- `main_simulate_reduced_dfba.jl`
- `main_export_reduced_dfba.jl`
- `main_compare_static_fba_full_reduced.jl`
- `main_compare_sequential_dfba_full_reduced.jl`
- `main_reduced_mpcc_fixed_control_policy_smoke.jl`
- `main_reduced_mpcc_fixed_control_policy_solve_attempt.jl`
- `main_reduced_mpcc_windowed_72h_attempt.jl`
- `main_reduced_mpcc_windowed_72h_simulation.jl`
- `main_reduced_mpcc_solver_termination_diagnostics.jl`
- `main_reduced_mpcc_iteration_limit_candidate_review.jl`
- `main_dynamic_control_objective_smoke.jl`
- `main_dynamic_control_liberated_spec.jl`
- `main_summarize_dynamic_control_mpcc_pilots.py`
- `main_compare_dynamic_control_mpcc_cases.py`

Estos scripts permiten reconstruir cargas, simulaciones, smokes, solve attempts,
diagnosticos y resumenes.

## Evidencia computacional y bitacoras

El bundle incluye todas las bitacoras Markdown de `repro/*.md` y la carpeta
`repro/generated/` completa. Estas bitacoras documentan:

- reglas de ejecucion en cluster UC;
- uso de Slurm;
- jobs asociados;
- parametros de solver;
- horizontes y mallas;
- configuraciones de complementarity/Scholtes;
- resultados de residual;
- decisiones de aceptacion/rechazo;
- limitaciones de cada etapa;
- rutas de salida y artefactos generados.

Bitacoras centrales:

- `DYNAMIC_CONTROL_MPCC_FIXED_SMOKE_20260610.md`
- `DYNAMIC_CONTROL_MPCC_FIXED_SOLVE_ATTEMPT_20260610.md`
- `DYNAMIC_CONTROL_MPCC_FIXED_TAIL_REPAIR_20260611.md`
- `dynamic_optimization_controls_20260609.md`
- `dynamic_control_mpcc_objective_pilot_20260615.md`
- `dynamic_control_staged_multistart_method_20260619.md`
- `dynamic_control_release_h168_method_20260622.md`
- `dynamic_control_homotopy_method_20260622.md`

## Resultados tecnicos destacados

1. Se implemento un paquete Julia modular para el simulador y la formulacion.
2. Se validaron contratos de modelo reducido con 1079 metabolitos, 1488
   reacciones y 19 estados dinamicos.
3. Se implemento simulacion secuencial dFBA y rutas complementarias DFVB.
4. Se implemento scaffold KKT-dFBA reducido con roles de reaccion y guardrails.
5. Se implemento NLP de collocation para DC-dFBA reducido.
6. Se implementaron filas de factibilidad primal `S*v = 0`.
7. Se implementaron filas de factibilidad de cotas y cotas dinamicas.
8. Se implementaron ecuaciones de estacionariedad KKT.
9. Se implementaron productos de complementariedad MPCC exactos y relajacion
   Scholtes.
10. Se implemento entrada controlada a Ipopt para smoke y solve attempts.
11. Se implementaron diagnosticos de residual, candidatos, trayectoria,
    viabilidad y terminacion.
12. Se implementaron scripts y flujos Slurm para ejecucion reproducible en
    cluster.
13. Se generaron bitacoras tecnicas con jobs, parametros y resultados.
14. Se generaron artefactos CSV/MD/SVG/PNG en `repro/generated/`.
15. Se establecieron limitaciones explicitas para no confundir diagnosticos con
    simulaciones cientificas finales.

## Casos de prueba y resultados de ejemplo

Ejemplos documentados en bitacoras:

- Smoke MPCC fijo 24 h con politica `cool18_warm22__springferm_early_0p4`,
  collocation starts, Scholtes y MA86.
- Solve-attempt MPCC reducido con diagnosticos de residual y candidatos.
- Reparacion tail/fixed-control, con identificacion de defectos acoplados
  estado-flujo-cotas.
- Continuacion y pilotos de objetivo dinamico 168 h.
- Staged multistart para controles dinamicos, con 29 corridas, 26
  residual-feasible y 0 trajectory-ready en el resumen generado.
- Comparaciones atlas/MPCC start quality y ramas de control.

## Rendimiento y tiempos de computo

La evidencia de rendimiento se cubre en dos niveles:

1. Benchmarks y guias de solver:
   - `docs/GUROBI_VS_HIGHS_BENCHMARK.md`
   - `src/Performance/`
   - `test/test_dfba_persistence_benchmark.jl`
   - `test/test_reduced_dfba_warm_start_benchmark.jl`

2. Bitacoras Slurm:
   - jobs con `--ntasks=1`, 8 CPU, `OPENBLAS_NUM_THREADS=1`, sin GPU;
   - uso de MA86/HSL cuando corresponde;
   - tiempos/cancelaciones/limitaciones explicitadas en `repro/*.md`.

## Declaracion recomendada para la rendicion

Se recomienda declarar la actividad 3.12 como cubierta al `100%` con la
siguiente justificacion:

> La implementacion del simulador dFBA/KKT se encuentra respaldada por una
> arquitectura modular en Julia, formulacion KKT/MPCC reducida, pruebas
> unitarias, scripts reproducibles, bitacoras de ejecucion en cluster y
> artefactos de resultados. La evidencia incluye componentes de simulacion
> secuencial, formulacion directa por collocation, factibilidad primal,
> factibilidad de cotas, estacionariedad, complementariedad, diagnosticos de
> solver y evaluacion de casos MPCC con controles dinamicos.

## Limitaciones tecnicas declaradas

Para mantener la rendicion tecnicamente robusta, se deben conservar estas
aclaraciones:

- La implementacion KKT/MPCC de objetivo principal corresponde al modelo dFBA
  reducido.
- La formulacion KKT-DFVB simultanea se mantiene diferida, aunque existen carga
  y simulacion/validacion DFVB secuencial/complementaria.
- Algunas corridas MPCC son diagnosticas y no deben presentarse como
  trayectoria cientifica final validada.
- En varias campañas se logro residual feasibility, pero no trajectory-ready.
- Los resultados de optimizacion dinamica extendida deben interpretarse como
  evidencia de metodologia, instrumentacion y diagnostico computacional.

## Conclusiones

El conjunto de archivos, pruebas y resultados incluidos permite sostener que la
actividad 3.12 cuenta con evidencia tecnica completa para rendicion. El
simulador dFBA/KKT/MPCC esta implementado en forma modular, auditable y
reproducible, con pruebas automatizadas y campañas computacionales documentadas.

La evidencia no se limita a codigo fuente: incluye contratos de datos, scripts,
bitacoras de cluster, diagnosticos numericos, artefactos tabulares y graficos,
lo que permite preparar un anexo tecnico consistente con la exigencia de
arquitectura, formulacion, version de repositorio, pruebas, rendimiento y casos
de prueba.

