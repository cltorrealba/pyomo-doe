# Claims recomendados y limitaciones

## Claim principal recomendado

La actividad 3.12 se encuentra cubierta al 100% como implementacion y evidencia
tecnica del simulador dFBA/KKT asociado a MPCC, porque el repositorio contiene:

- arquitectura modular del simulador;
- formulacion dFBA/KKT/MPCC reducida;
- componentes de collocation y constraints KKT;
- pruebas unitarias;
- scripts reproducibles;
- bitacoras de cluster;
- diagnosticos de solver;
- resultados y artefactos generados.

## Frase corta para tabla de rendicion

Implementacion documentada del simulador dFBA/KKT/MPCC reducido, con
arquitectura Julia, formulacion KKT, pruebas unitarias, scripts reproducibles,
diagnosticos computacionales y casos de prueba en cluster.

## Frase para evitar sobredimensionamiento

El anexo acredita implementacion, instrumentacion y validacion tecnica del
simulador/formulacion. Las campañas MPCC de largo horizonte se reportan como
diagnosticas cuando no alcanzan estado `trajectory-ready`; no se presentan como
validacion biologica final de una trayectoria optimizada.

## Limitaciones que conviene declarar

- El foco KKT/MPCC principal es dFBA reducido.
- La KKT-DFVB simultanea no se declara completa; DFVB existe como carga,
  simulacion secuencial y comparacion complementaria.
- La evidencia de control dinamico MPCC incluye pilotos, starts, solve-attempts,
  residual feasibility y diagnosticos, pero no todas las ramas son trayectorias
  finales.
- Los benchmarks son evidencia de rendimiento y reproducibilidad, no una
  publicacion formal de performance.

## Redaccion sugerida de cumplimiento 100%

Cumplimiento declarado: `100%`

Justificacion:

> Se implemento y documento el simulador dFBA/KKT en el repositorio, incluyendo
> arquitectura de software, formulacion KKT/MPCC reducida, integracion con
> solvers, pruebas unitarias, scripts reproducibles, bitacoras de ejecucion en
> cluster, diagnosticos de residual y casos de prueba. La evidencia cubre todos
> los criterios solicitados para la actividad: arquitectura, formulacion,
> version/repositorio, pruebas, rendimiento computacional y resultados.

