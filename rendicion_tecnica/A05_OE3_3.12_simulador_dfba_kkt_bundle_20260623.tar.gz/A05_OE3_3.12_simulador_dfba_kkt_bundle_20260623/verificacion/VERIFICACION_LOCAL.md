# Verificacion local

## Sub-suite recomendada

Comando:

```bash
julia --project -e 'using FermentationDFBA, Test; @testset "rendicion_mpcc_evidence_subset" begin include("test/test_kkt_dfba_scaffold.jl"); include("test/test_reduced_dcdfba_stationarity.jl"); include("test/test_reduced_dcdfba_complementarity.jl"); include("test/test_reduced_dcdfba_mpcc_smoke.jl"); end'
```

Esta sub-suite cubre:

- contrato KKT-dFBA reducido;
- stationarity KKT;
- complementarity MPCC;
- smoke MPCC reducido.

## Estado

Resultado registrado durante la preparacion del bundle:

```text
[ Info: Skipping guarded reduced MPCC solve smoke; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_SOLVE=1 to run it.
Test Summary:                  | Pass  Total     Time
rendicion_mpcc_evidence_subset |  402    402  2m00.4s
```

Interpretacion:

- La sub-suite representativa paso `402/402` pruebas.
- El smoke solve con llamada efectiva a Ipopt se omitio por diseno, porque es
  opt-in mediante `FERMENTATIONDFBA_TEST_REDUCED_MPCC_SOLVE=1`.
- El contrato MPCC, KKT scaffold, stationarity y complementarity si fueron
  validados localmente.
- Antes de ejecutar los tests, Julia precompilo el entorno por primera vez en
  esta sesion; esa etapa no debe confundirse con el tiempo de la sub-suite.

## Suite completa

Comando general:

```bash
julia --project -e 'using Pkg; Pkg.test()'
```

La suite completa puede ser mas costosa que la sub-suite de rendicion y debe
ejecutarse cuando el entorno tenga dependencias instanciadas y tiempo suficiente.
