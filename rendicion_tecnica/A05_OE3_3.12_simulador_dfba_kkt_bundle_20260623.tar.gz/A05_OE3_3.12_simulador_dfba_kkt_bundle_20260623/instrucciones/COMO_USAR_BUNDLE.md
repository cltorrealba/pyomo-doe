# Como usar este bundle para generar el anexo

## Entrada principal

Usar `ANEXO_TECNICO_ACT_3.12.md` como texto base del anexo. Ese archivo ya esta
redactado para funcionar como documento tecnico autocontenido.

## Flujo recomendado

1. Revisar `README_BUNDLE.md` para entender alcance y estructura.
2. Abrir `ANEXO_TECNICO_ACT_3.12.md`.
3. Ajustar portada, institucion, autores y formato si corresponde.
4. Insertar o anexar las tablas:
   - `tablas/MATRIZ_CUMPLIMIENTO.csv`
   - `tablas/INDICE_EVIDENCIAS.csv`
   - `tablas/RESUMEN_ARTEFACTOS.csv`
5. Si se requiere un PDF unico, convertir el Markdown con Pandoc.
6. Adjuntar `evidencias/` como respaldo digital o zip secundario.

## Comando sugerido con Pandoc

Desde la raiz del bundle:

```bash
pandoc ANEXO_TECNICO_ACT_3.12.md \
  --from markdown \
  --toc \
  --number-sections \
  -o PI-4497_IA5_A05_Act-3.12_Simulador-dFBA-KKT.pdf
```

Si no hay LaTeX disponible, generar primero DOCX:

```bash
pandoc ANEXO_TECNICO_ACT_3.12.md \
  --from markdown \
  --toc \
  --number-sections \
  -o PI-4497_IA5_A05_Act-3.12_Simulador-dFBA-KKT.docx
```

## Archivos que conviene citar en el PDF

- `evidencias/codigo/repo_docs_base/README.md`
- `evidencias/codigo/repo_docs_base/Project.toml`
- `evidencias/codigo/src/Simultaneous/kkt_dfba.jl`
- `evidencias/codigo/src/Simultaneous/reduced_dcdfba_collocation_nlp.jl`
- `evidencias/tests/test_kkt_dfba_scaffold.jl`
- `evidencias/tests/test_reduced_dcdfba_stationarity.jl`
- `evidencias/tests/test_reduced_dcdfba_complementarity.jl`
- `evidencias/tests/test_reduced_dcdfba_mpcc_smoke.jl`
- `evidencias/repro/DYNAMIC_CONTROL_MPCC_FIXED_SMOKE_20260610.md`
- `evidencias/repro/DYNAMIC_CONTROL_MPCC_FIXED_SOLVE_ATTEMPT_20260610.md`
- `evidencias/repro/DYNAMIC_CONTROL_MPCC_FIXED_TAIL_REPAIR_20260611.md`
- `evidencias/generated/dynamic_control_staged_multistart_20260619/summary.md`

## Recomendacion de redaccion para la rendicion

Usar un lenguaje de cumplimiento tecnico:

> Implementado y documentado, con evidencia de arquitectura, formulacion,
> pruebas y resultados computacionales.

Evitar:

> Trayectoria MPCC final optimizada y validada biologicamente.

La segunda frase seria mas fuerte que lo que los propios diagnosticos del repo
permiten defender.

