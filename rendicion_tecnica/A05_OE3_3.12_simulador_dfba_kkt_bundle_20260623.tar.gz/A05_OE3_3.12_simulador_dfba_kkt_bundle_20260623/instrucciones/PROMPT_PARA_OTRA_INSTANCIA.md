# Prompt sugerido para otra instancia

Usa este prompt si otra instancia debe tomar el bundle y generar el PDF/anexo
final.

```text
Estoy preparando una rendicion tecnica del proyecto PI-4497, IA5, actividad
A05/OE3/3.12: "Implementacion del simulador dFBA/KKT".

Trabaja sobre el bundle ubicado en:

rendicion/A05_OE3_3.12_simulador_dfba_kkt_bundle_20260623/

Objetivo:
Generar el anexo final `PI-4497_IA5_A05_Act-3.12_Simulador-dFBA-KKT.pdf`
a partir de `ANEXO_TECNICO_ACT_3.12.md`, incorporando las tablas de
`tablas/` y citando los archivos de `evidencias/`.

Criterio:
Apuntar a justificar 100% de cumplimiento de la actividad, entendido como
cobertura completa de arquitectura, formulacion dFBA/KKT/MPCC, repositorio,
version, pruebas unitarias, tiempos/rendimiento y casos de prueba.

Cuidado:
No sobredimensionar. La evidencia permite declarar implementacion y validacion
tecnica del simulador/formulacion. No declarar que existe una trayectoria MPCC
simultanea final validada biologicamente cuando los propios archivos indican
que varias corridas son diagnosticas y que algunas ramas no son
trajectory-ready.

Archivos clave:
- README_BUNDLE.md
- ANEXO_TECNICO_ACT_3.12.md
- CLAIMS_Y_LIMITACIONES.md
- tablas/MATRIZ_CUMPLIMIENTO.csv
- tablas/INDICE_EVIDENCIAS.csv
- evidencias/repro/*.md
- evidencias/generated/
- evidencias/codigo/src/Simultaneous/kkt_dfba.jl
- evidencias/codigo/src/Simultaneous/reduced_dcdfba_collocation_nlp.jl
- evidencias/tests/test_reduced_dcdfba_complementarity.jl
- evidencias/tests/test_reduced_dcdfba_stationarity.jl
- evidencias/tests/test_reduced_dcdfba_mpcc_smoke.jl

Entrega:
1. PDF o DOCX final.
2. Resumen ejecutivo de 1 pagina.
3. Tabla de cumplimiento.
4. Lista de anexos/evidencias incorporadas.
```

