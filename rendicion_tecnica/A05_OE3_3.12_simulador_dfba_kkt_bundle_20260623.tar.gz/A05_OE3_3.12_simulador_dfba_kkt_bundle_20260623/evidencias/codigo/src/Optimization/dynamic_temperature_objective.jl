import HiGHS
import OrdinaryDiffEq

const DYNAMIC_TEMPERATURE_OBJECTIVE_TYPE = "dynamic_temperature_sequential_objective"
const DYNAMIC_TEMPERATURE_ACCEPTED_TERMINATIONS = Set([
    "completed_tspan",
    "sugar_depletion_at_saved_time",
    "sugar_depletion_at_initial_time",
])

"""
    DynamicTemperatureObjectiveWeights(; kwargs...)

Weights for the first dynamic temperature-only objective. The objective is
minimized. By default it minimizes final total sugar and adds only health
penalties; ethanol reward and temperature regularization can be enabled through
nonnegative weights.
"""
struct DynamicTemperatureObjectiveWeights
    final_total_sugar_weight::Float64
    ethanol_reward_weight::Float64
    temperature_smoothness_weight::Float64
    temperature_move_weight::Float64
    reference_temperature_C::Float64
    negative_state_tolerance::Float64
    negative_state_penalty_weight::Float64
    incomplete_horizon_penalty_weight::Float64
    failure_penalty::Float64
end

function DynamicTemperatureObjectiveWeights(;
    final_total_sugar_weight::Real = 1.0,
    ethanol_reward_weight::Real = 0.0,
    temperature_smoothness_weight::Real = 0.0,
    temperature_move_weight::Real = 0.0,
    reference_temperature_C::Real = 20.0,
    negative_state_tolerance::Real = 1.0e-9,
    negative_state_penalty_weight::Real = 1.0e8,
    incomplete_horizon_penalty_weight::Real = 1.0e6,
    failure_penalty::Real = 1.0e9,
)::DynamicTemperatureObjectiveWeights
    final_sugar_weight = _dynamic_temperature_nonnegative_weight(
        final_total_sugar_weight,
        "final_total_sugar_weight",
    )
    ethanol_weight = _dynamic_temperature_nonnegative_weight(
        ethanol_reward_weight,
        "ethanol_reward_weight",
    )
    smoothness_weight = _dynamic_temperature_nonnegative_weight(
        temperature_smoothness_weight,
        "temperature_smoothness_weight",
    )
    move_weight = _dynamic_temperature_nonnegative_weight(
        temperature_move_weight,
        "temperature_move_weight",
    )
    reference_temperature = Float64(reference_temperature_C)
    isfinite(reference_temperature) || throw(
        ArgumentError("reference_temperature_C must be finite."),
    )
    negative_tolerance = _dynamic_temperature_nonnegative_weight(
        negative_state_tolerance,
        "negative_state_tolerance",
    )
    negative_weight = _dynamic_temperature_nonnegative_weight(
        negative_state_penalty_weight,
        "negative_state_penalty_weight",
    )
    incomplete_weight = _dynamic_temperature_nonnegative_weight(
        incomplete_horizon_penalty_weight,
        "incomplete_horizon_penalty_weight",
    )
    failure = _dynamic_temperature_nonnegative_weight(failure_penalty, "failure_penalty")

    return DynamicTemperatureObjectiveWeights(
        final_sugar_weight,
        ethanol_weight,
        smoothness_weight,
        move_weight,
        reference_temperature,
        negative_tolerance,
        negative_weight,
        incomplete_weight,
        failure,
    )
end

"""
    DynamicTemperatureObjectiveResult

Result of one temperature-control schedule evaluation against the sequential
DFBA simulator.
"""
struct DynamicTemperatureObjectiveResult
    objective_value::Float64
    feasible::Bool
    status::String
    terms::Dict{String, Float64}
    summary::Dict{String, Any}
    schedule::DynamicControlSchedule
    simulation::SimulationResult
    metadata::Dict{String, Any}
end

"""
    DynamicTemperaturePatternSearchResult

Derivative-free temperature-only search result. The search is intentionally
simple: it evaluates bounded coordinate moves on the 12 h temperature grid and
keeps the best improving schedule.
"""
struct DynamicTemperaturePatternSearchResult
    best_evaluation::DynamicTemperatureObjectiveResult
    candidate_table::DataFrame
    metadata::Dict{String, Any}
end

function dynamic_temperature_control_value_count(;
    horizon_h::Real = 168.0,
    control_interval_h::Real = 12.0,
)::Int
    return length(_default_transition_times(horizon_h, control_interval_h)) + 1
end

function expand_temperature_decision_values(
    decision_values_C::AbstractVector;
    horizon_h::Real = 168.0,
    control_interval_h::Real = 12.0,
    fixed_initial_temperature_C = nothing,
)::Vector{Float64}
    expected_count = dynamic_temperature_control_value_count(
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
    )
    values = Float64.(decision_values_C)
    if fixed_initial_temperature_C === nothing
        length(values) == expected_count || throw(
            ArgumentError(
                "Temperature decision vector must contain $expected_count values " *
                "for horizon_h=$(Float64(horizon_h)) and control_interval_h=$(Float64(control_interval_h)); " *
                "got $(length(values)).",
            ),
        )
        return values
    end

    length(values) == expected_count - 1 || throw(
        ArgumentError(
            "Temperature decision vector with fixed_initial_temperature_C must contain " *
            "$(expected_count - 1) free values; got $(length(values)).",
        ),
    )
    initial_temperature = Float64(fixed_initial_temperature_C)
    isfinite(initial_temperature) || throw(
        ArgumentError("fixed_initial_temperature_C must be finite when provided."),
    )
    return vcat([initial_temperature], values)
end

function temperature_control_schedule_from_values(
    temperature_values_C::AbstractVector;
    horizon_h::Real = 168.0,
    control_interval_h::Real = 12.0,
    temperature_transition_width_h::Real = 1.0,
    temperature_min_C::Real = 15.0,
    temperature_max_C::Real = 25.0,
)::DynamicControlSchedule
    values = expand_temperature_decision_values(
        temperature_values_C;
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
    )
    return reference_dynamic_control_schedule(
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        temperature_values_C = values,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        fda_doses_g_L = zeros(max(0, length(values) - 1)),
        organic_doses_g_L = zeros(max(0, length(values) - 1)),
    )
end

function dynamic_temperature_objective_terms(
    result::SimulationResult,
    schedule::DynamicControlSchedule;
    weights::DynamicTemperatureObjectiveWeights = DynamicTemperatureObjectiveWeights(),
    horizon_h::Real = result.time[end],
)::Dict{String, Float64}
    summary = summarize_simulation(result)
    return dynamic_temperature_objective_terms(
        summary,
        schedule;
        weights = weights,
        horizon_h = horizon_h,
    )
end

function dynamic_temperature_objective_terms(
    summary::AbstractDict,
    schedule::DynamicControlSchedule;
    weights::DynamicTemperatureObjectiveWeights = DynamicTemperatureObjectiveWeights(),
    horizon_h::Real,
)::Dict{String, Float64}
    horizon = Float64(horizon_h)
    isfinite(horizon) && horizon > 0.0 ||
        throw(ArgumentError("horizon_h must be finite and positive."))

    final_total_sugar = _dynamic_temperature_summary_float(summary, "final_total_sugar")
    ethanol_produced = _dynamic_temperature_summary_float(summary, "ethanol_produced")
    min_state_value = _dynamic_temperature_summary_float(summary, "min_state_value")
    final_time = _dynamic_temperature_summary_float(summary, "final_time")
    retcode = _dynamic_temperature_summary_string(summary, "retcode")
    termination_reason = _dynamic_temperature_summary_string(summary, "termination_reason")

    negative_excess = max(0.0, -min_state_value - weights.negative_state_tolerance)
    incomplete_gap = _dynamic_temperature_horizon_incomplete_gap(
        final_time,
        horizon,
        retcode,
        termination_reason,
    )
    temperature_jumps = diff(schedule.temperature_values_C)
    temperature_moves = schedule.temperature_values_C .- weights.reference_temperature_C
    failure = retcode == "Success" ? 0.0 : weights.failure_penalty

    return Dict{String, Float64}(
        "terminal_sugar" => weights.final_total_sugar_weight * final_total_sugar,
        "ethanol_reward" => -weights.ethanol_reward_weight * ethanol_produced,
        "temperature_smoothness" =>
            weights.temperature_smoothness_weight * sum(abs2, temperature_jumps),
        "temperature_move" => weights.temperature_move_weight * sum(abs2, temperature_moves),
        "negative_state_penalty" => weights.negative_state_penalty_weight * negative_excess^2,
        "incomplete_horizon_penalty" =>
            weights.incomplete_horizon_penalty_weight * incomplete_gap^2,
        "failure_penalty" => failure,
    )
end

function dynamic_temperature_objective_value(terms::AbstractDict)::Float64
    return sum(Float64(value) for value in values(terms))
end

function evaluate_dynamic_temperature_objective(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    temperature_values_C::AbstractVector;
    weights::DynamicTemperatureObjectiveWeights = DynamicTemperatureObjectiveWeights(),
    horizon_h::Real = 168.0,
    control_interval_h::Real = 12.0,
    temperature_transition_width_h::Real = 1.0,
    temperature_min_C::Real = 15.0,
    temperature_max_C::Real = 25.0,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    saveat = 1.0,
    algorithm = OrdinaryDiffEq.Tsit5(),
    reconstruct_fluxes::Bool = false,
    stop_on_sugar_depletion::Bool = true,
    sugar_depletion_tol::Real = 1.0e-6,
    progress_interval_seconds::Real = 0.0,
    max_rhs_calls = nothing,
    max_walltime_seconds = nothing,
)::DynamicTemperatureObjectiveResult
    schedule = temperature_control_schedule_from_values(
        temperature_values_C;
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
    )
    result = simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = (0.0, Float64(horizon_h)),
        params = params,
        dynamic_control_schedule = schedule,
        optimizer = optimizer,
        silent = silent,
        lp_atol = lp_atol,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        saveat = saveat,
        algorithm = algorithm,
        reconstruct_fluxes = reconstruct_fluxes,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
    )
    summary = summarize_simulation(result)
    terms = dynamic_temperature_objective_terms(
        summary,
        schedule;
        weights = weights,
        horizon_h = horizon_h,
    )
    objective_value = dynamic_temperature_objective_value(terms)
    feasible = _dynamic_temperature_objective_feasible(summary, weights, Float64(horizon_h))
    status = feasible ? "accepted" : "rejected"
    metadata = _dynamic_temperature_objective_metadata(
        schedule,
        weights;
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        saveat = saveat,
        reconstruct_fluxes = reconstruct_fluxes,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
    )
    metadata["objective_value"] = objective_value
    metadata["objective_status"] = status
    metadata["objective_feasible"] = feasible

    return DynamicTemperatureObjectiveResult(
        objective_value,
        feasible,
        status,
        terms,
        Dict{String, Any}(summary),
        schedule,
        result,
        metadata,
    )
end

function optimize_dynamic_temperature_pattern_search(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    weights::DynamicTemperatureObjectiveWeights = DynamicTemperatureObjectiveWeights(),
    horizon_h::Real = 168.0,
    control_interval_h::Real = 12.0,
    temperature_transition_width_h::Real = 1.0,
    temperature_min_C::Real = 15.0,
    temperature_max_C::Real = 25.0,
    reference_temperature_C::Real = 20.0,
    fixed_initial_temperature_C = 20.0,
    initial_temperature_values_C = nothing,
    initial_step_C::Real = 2.0,
    min_step_C::Real = 0.5,
    step_reduction::Real = 0.5,
    max_evaluations::Integer = 20,
    improvement_tol::Real = 1.0e-8,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    saveat = 1.0,
    algorithm = OrdinaryDiffEq.Tsit5(),
    reconstruct_fluxes::Bool = false,
    stop_on_sugar_depletion::Bool = true,
    sugar_depletion_tol::Real = 1.0e-6,
    progress_interval_seconds::Real = 0.0,
    max_rhs_calls = nothing,
    max_walltime_seconds = nothing,
)::DynamicTemperaturePatternSearchResult
    _dynamic_temperature_validate_search_controls(
        initial_step_C,
        min_step_C,
        step_reduction,
        max_evaluations,
        improvement_tol,
    )
    current_values = _dynamic_temperature_search_initial_values(
        initial_temperature_values_C;
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        reference_temperature_C = reference_temperature_C,
        fixed_initial_temperature_C = fixed_initial_temperature_C,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
    )
    free_indices = _dynamic_temperature_search_free_indices(
        length(current_values),
        fixed_initial_temperature_C,
    )
    isempty(free_indices) && error("Temperature pattern search requires at least one free control value.")

    cache = Dict{String, DynamicTemperatureObjectiveResult}()
    rows = NamedTuple[]
    accepted_candidate_ids = Set{String}()
    incumbent_candidate_ids = String[]

    function evaluate_candidate!(
        temperature_values_C::Vector{Float64},
        iteration::Int,
        move_index,
        move_direction::Int,
        step_C::Float64,
        label::AbstractString,
    )
        key = _dynamic_temperature_search_key(temperature_values_C)
        cached = haskey(cache, key)
        if !cached
            length(cache) < Int(max_evaluations) || return nothing
            cache[key] = evaluate_dynamic_temperature_objective(
                model,
                reaction_map,
                temperature_values_C;
                weights = weights,
                horizon_h = horizon_h,
                control_interval_h = control_interval_h,
                temperature_transition_width_h = temperature_transition_width_h,
                temperature_min_C = temperature_min_C,
                temperature_max_C = temperature_max_C,
                y0 = y0,
                params = params,
                optimizer = optimizer,
                silent = silent,
                lp_atol = lp_atol,
                ode_abstol = ode_abstol,
                ode_reltol = ode_reltol,
                saveat = saveat,
                algorithm = algorithm,
                reconstruct_fluxes = reconstruct_fluxes,
                stop_on_sugar_depletion = stop_on_sugar_depletion,
                sugar_depletion_tol = sugar_depletion_tol,
                progress_interval_seconds = progress_interval_seconds,
                max_rhs_calls = max_rhs_calls,
                max_walltime_seconds = max_walltime_seconds,
            )
        end
        evaluation = cache[key]
        candidate_id = "eval_" * lpad(string(length(rows) + 1), 4, '0') * "_" * String(label)
        push!(
            rows,
            _dynamic_temperature_pattern_search_row(
                candidate_id,
                iteration,
                move_index,
                move_direction,
                step_C,
                cached,
                temperature_values_C,
                evaluation,
            ),
        )
        return (candidate_id = candidate_id, values = copy(temperature_values_C), evaluation = evaluation)
    end

    initial = evaluate_candidate!(current_values, 0, missing, 0, 0.0, "initial")
    initial === nothing && error("Temperature pattern search could not evaluate the initial candidate.")
    current = initial
    push!(accepted_candidate_ids, current.candidate_id)
    push!(incumbent_candidate_ids, current.candidate_id)

    step = Float64(initial_step_C)
    iteration = 0
    while length(cache) < Int(max_evaluations) && step >= Float64(min_step_C) - 1.0e-12
        iteration += 1
        best_neighbor = current
        for index in free_indices
            length(cache) < Int(max_evaluations) || break
            for direction in (-1, 1)
                length(cache) < Int(max_evaluations) || break
                candidate_values = copy(current.values)
                candidate_values[index] = clamp(
                    candidate_values[index] + direction * step,
                    Float64(temperature_min_C),
                    Float64(temperature_max_C),
                )
                if isapprox(candidate_values[index], current.values[index]; atol = 1.0e-12, rtol = 0.0)
                    continue
                end
                label = "iter$(iteration)_i$(index)_$(direction < 0 ? "minus" : "plus")"
                candidate = evaluate_candidate!(
                    candidate_values,
                    iteration,
                    index,
                    direction,
                    step,
                    label,
                )
                candidate === nothing && break
                if _dynamic_temperature_search_better(
                    candidate.evaluation,
                    best_neighbor.evaluation;
                    improvement_tol = improvement_tol,
                )
                    best_neighbor = candidate
                end
            end
        end

        if best_neighbor.candidate_id != current.candidate_id
            current = best_neighbor
            push!(accepted_candidate_ids, current.candidate_id)
            push!(incumbent_candidate_ids, current.candidate_id)
        else
            step *= Float64(step_reduction)
        end
    end

    table = DataFrame(rows)
    if nrow(table) > 0
        table[!, "accepted_as_incumbent"] =
            [candidate_id in accepted_candidate_ids for candidate_id in table.candidate_id]
        table[!, "is_final_best"] =
            [candidate_id == current.candidate_id for candidate_id in table.candidate_id]
    end
    metadata = Dict{String, Any}(
        "search_type" => "dynamic_temperature_pattern_search",
        "objective_type" => DYNAMIC_TEMPERATURE_OBJECTIVE_TYPE,
        "horizon_h" => Float64(horizon_h),
        "control_interval_h" => Float64(control_interval_h),
        "temperature_value_count" => length(current.values),
        "free_temperature_indices" => copy(free_indices),
        "fixed_initial_temperature_C" => fixed_initial_temperature_C,
        "temperature_min_C" => Float64(temperature_min_C),
        "temperature_max_C" => Float64(temperature_max_C),
        "initial_step_C" => Float64(initial_step_C),
        "min_step_C" => Float64(min_step_C),
        "step_reduction" => Float64(step_reduction),
        "max_evaluations" => Int(max_evaluations),
        "unique_evaluations" => length(cache),
        "candidate_rows" => nrow(table),
        "accepted_candidate_ids" => incumbent_candidate_ids,
        "best_candidate_id" => current.candidate_id,
        "best_objective_value" => current.evaluation.objective_value,
        "best_feasible" => current.evaluation.feasible,
        "best_temperature_values_C" => copy(current.values),
        "best_final_total_sugar" => current.evaluation.summary["final_total_sugar"],
        "best_sugar_consumed" => current.evaluation.summary["sugar_consumed"],
        "best_final_ethanol" => current.evaluation.summary["final_ethanol"],
    )
    return DynamicTemperaturePatternSearchResult(current.evaluation, table, metadata)
end

function _dynamic_temperature_nonnegative_weight(value::Real, label::AbstractString)::Float64
    converted = Float64(value)
    isfinite(converted) && converted >= 0.0 || throw(
        ArgumentError("$label must be finite and nonnegative."),
    )
    return converted
end

function _dynamic_temperature_summary_float(summary::AbstractDict, key::AbstractString)::Float64
    haskey(summary, key) || throw(ArgumentError("Summary is missing key: $key"))
    value = Float64(summary[key])
    isfinite(value) || throw(ArgumentError("Summary key $key must be finite; got $(summary[key])."))
    return value
end

function _dynamic_temperature_summary_string(summary::AbstractDict, key::AbstractString)::String
    haskey(summary, key) || throw(ArgumentError("Summary is missing key: $key"))
    value = summary[key]
    value === nothing && return "nothing"
    value === missing && return "missing"
    return String(value)
end

function _dynamic_temperature_horizon_incomplete_gap(
    final_time::Real,
    horizon_h::Real,
    retcode::AbstractString,
    termination_reason::AbstractString,
)::Float64
    retcode == "Success" || return max(0.0, Float64(horizon_h) - Float64(final_time))
    termination_reason in DYNAMIC_TEMPERATURE_ACCEPTED_TERMINATIONS && return 0.0
    return max(0.0, Float64(horizon_h) - Float64(final_time))
end

function _dynamic_temperature_objective_feasible(
    summary::AbstractDict,
    weights::DynamicTemperatureObjectiveWeights,
    horizon_h::Real,
)::Bool
    retcode = _dynamic_temperature_summary_string(summary, "retcode")
    termination_reason = _dynamic_temperature_summary_string(summary, "termination_reason")
    min_state_value = _dynamic_temperature_summary_float(summary, "min_state_value")
    final_time = _dynamic_temperature_summary_float(summary, "final_time")
    incomplete_gap = _dynamic_temperature_horizon_incomplete_gap(
        final_time,
        horizon_h,
        retcode,
        termination_reason,
    )
    return retcode == "Success" &&
        termination_reason in DYNAMIC_TEMPERATURE_ACCEPTED_TERMINATIONS &&
        incomplete_gap == 0.0 &&
        min_state_value >= -weights.negative_state_tolerance
end

function _dynamic_temperature_objective_metadata(
    schedule::DynamicControlSchedule,
    weights::DynamicTemperatureObjectiveWeights;
    horizon_h::Real,
    control_interval_h::Real,
    temperature_transition_width_h::Real,
    temperature_min_C::Real,
    temperature_max_C::Real,
    saveat,
    reconstruct_fluxes::Bool,
    stop_on_sugar_depletion::Bool,
    sugar_depletion_tol::Real,
)::Dict{String, Any}
    return Dict{String, Any}(
        "objective_type" => DYNAMIC_TEMPERATURE_OBJECTIVE_TYPE,
        "objective_sense" => "minimize",
        "objective_primary_term" => "final_total_sugar",
        "horizon_h" => Float64(horizon_h),
        "control_interval_h" => Float64(control_interval_h),
        "temperature_value_count" => length(schedule.temperature_values_C),
        "temperature_values_C" => copy(schedule.temperature_values_C),
        "temperature_transition_count" => length(schedule.temperature_transition_times_h),
        "temperature_transition_times_h" => copy(schedule.temperature_transition_times_h),
        "temperature_transition_width_h" => Float64(temperature_transition_width_h),
        "temperature_min_C" => Float64(temperature_min_C),
        "temperature_max_C" => Float64(temperature_max_C),
        "saveat" => saveat,
        "reconstruct_fluxes" => reconstruct_fluxes,
        "stop_on_sugar_depletion" => stop_on_sugar_depletion,
        "sugar_depletion_tol" => Float64(sugar_depletion_tol),
        "final_total_sugar_weight" => weights.final_total_sugar_weight,
        "ethanol_reward_weight" => weights.ethanol_reward_weight,
        "temperature_smoothness_weight" => weights.temperature_smoothness_weight,
        "temperature_move_weight" => weights.temperature_move_weight,
        "reference_temperature_C" => weights.reference_temperature_C,
        "negative_state_tolerance" => weights.negative_state_tolerance,
        "negative_state_penalty_weight" => weights.negative_state_penalty_weight,
        "incomplete_horizon_penalty_weight" => weights.incomplete_horizon_penalty_weight,
        "failure_penalty" => weights.failure_penalty,
        "accepted_termination_reasons" => sort(collect(DYNAMIC_TEMPERATURE_ACCEPTED_TERMINATIONS)),
    )
end

function _dynamic_temperature_validate_search_controls(
    initial_step_C::Real,
    min_step_C::Real,
    step_reduction::Real,
    max_evaluations::Integer,
    improvement_tol::Real,
)
    initial_step = Float64(initial_step_C)
    minimum_step = Float64(min_step_C)
    reduction = Float64(step_reduction)
    tolerance = Float64(improvement_tol)
    isfinite(initial_step) && initial_step > 0.0 ||
        throw(ArgumentError("initial_step_C must be finite and positive."))
    isfinite(minimum_step) && minimum_step > 0.0 ||
        throw(ArgumentError("min_step_C must be finite and positive."))
    initial_step >= minimum_step ||
        throw(ArgumentError("initial_step_C must be >= min_step_C."))
    isfinite(reduction) && 0.0 < reduction < 1.0 ||
        throw(ArgumentError("step_reduction must be finite and in (0, 1)."))
    Int(max_evaluations) > 0 || throw(ArgumentError("max_evaluations must be positive."))
    isfinite(tolerance) && tolerance >= 0.0 ||
        throw(ArgumentError("improvement_tol must be finite and nonnegative."))
    return nothing
end

function _dynamic_temperature_search_initial_values(
    initial_temperature_values_C;
    horizon_h::Real,
    control_interval_h::Real,
    reference_temperature_C::Real,
    fixed_initial_temperature_C,
    temperature_min_C::Real,
    temperature_max_C::Real,
)::Vector{Float64}
    expected_count = dynamic_temperature_control_value_count(
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
    )
    tmin = Float64(temperature_min_C)
    tmax = Float64(temperature_max_C)
    reference_temperature = Float64(reference_temperature_C)
    isfinite(reference_temperature) || throw(
        ArgumentError("reference_temperature_C must be finite."),
    )
    if initial_temperature_values_C === nothing
        values = fill(clamp(reference_temperature, tmin, tmax), expected_count)
        if fixed_initial_temperature_C !== nothing
            fixed_initial = Float64(fixed_initial_temperature_C)
            isfinite(fixed_initial) || throw(
                ArgumentError("fixed_initial_temperature_C must be finite when provided."),
            )
            values[1] = clamp(fixed_initial, tmin, tmax)
        end
        return values
    end

    values = Float64.(initial_temperature_values_C)
    length(values) == expected_count || throw(
        ArgumentError(
            "initial_temperature_values_C must contain $expected_count values; got $(length(values)).",
        ),
    )
    all(isfinite, values) || throw(
        ArgumentError("initial_temperature_values_C must contain only finite values."),
    )
    all(value -> tmin <= value <= tmax, values) || throw(
        ArgumentError("initial_temperature_values_C must lie within [$tmin, $tmax] C."),
    )
    if fixed_initial_temperature_C !== nothing
        fixed_initial = Float64(fixed_initial_temperature_C)
        isfinite(fixed_initial) || throw(
            ArgumentError("fixed_initial_temperature_C must be finite when provided."),
        )
        isapprox(values[1], fixed_initial; atol = 1.0e-10, rtol = 1.0e-10) || throw(
            ArgumentError(
                "initial_temperature_values_C[1] must match fixed_initial_temperature_C.",
            ),
        )
    end
    return values
end

function _dynamic_temperature_search_free_indices(
    value_count::Integer,
    fixed_initial_temperature_C,
)::Vector{Int}
    count = Int(value_count)
    count > 0 || throw(ArgumentError("Temperature search value count must be positive."))
    return fixed_initial_temperature_C === nothing ? collect(1:count) : collect(2:count)
end

function _dynamic_temperature_search_key(values::AbstractVector)::String
    return join((string(round(Float64(value); digits = 10)) for value in values), ",")
end

function _dynamic_temperature_search_better(
    candidate::DynamicTemperatureObjectiveResult,
    incumbent::DynamicTemperatureObjectiveResult;
    improvement_tol::Real,
)::Bool
    return candidate.objective_value < incumbent.objective_value - Float64(improvement_tol)
end

function _dynamic_temperature_pattern_search_row(
    candidate_id::AbstractString,
    iteration::Integer,
    move_index,
    move_direction::Integer,
    step_C::Real,
    cached::Bool,
    temperature_values_C::AbstractVector,
    evaluation::DynamicTemperatureObjectiveResult,
)
    summary = evaluation.summary
    terms = evaluation.terms
    return (
        candidate_id = String(candidate_id),
        iteration = Int(iteration),
        move_index = move_index,
        move_direction = Int(move_direction),
        step_C = Float64(step_C),
        cached = cached,
        objective_value = evaluation.objective_value,
        feasible = evaluation.feasible,
        status = evaluation.status,
        retcode = string(get(summary, "retcode", missing)),
        termination_reason = string(get(summary, "termination_reason", missing)),
        final_time = Float64(get(summary, "final_time", NaN)),
        final_total_sugar = Float64(get(summary, "final_total_sugar", NaN)),
        sugar_consumed = Float64(get(summary, "sugar_consumed", NaN)),
        final_ethanol = Float64(get(summary, "final_ethanol", NaN)),
        ethanol_produced = Float64(get(summary, "ethanol_produced", NaN)),
        min_state_value = Float64(get(summary, "min_state_value", NaN)),
        has_negative_saved_states = Bool(get(summary, "has_negative_saved_states", false)),
        rhs_call_count = Int(get(summary, "rhs_call_count", 0)),
        total_lp_solve_count = Int(get(summary, "total_lp_solve_count", 0)),
        terminal_sugar_term = terms["terminal_sugar"],
        ethanol_reward_term = terms["ethanol_reward"],
        temperature_smoothness_term = terms["temperature_smoothness"],
        temperature_move_term = terms["temperature_move"],
        negative_state_penalty = terms["negative_state_penalty"],
        incomplete_horizon_penalty = terms["incomplete_horizon_penalty"],
        failure_penalty = terms["failure_penalty"],
        temperature_values_C = join(string.(Float64.(temperature_values_C)), ","),
    )
end
