import HiGHS
import OrdinaryDiffEq

const DYNAMIC_CONTROL_OBJECTIVE_TYPE = "dynamic_control_sequential_white_wine_objective"
const DYNAMIC_CONTROL_ACCEPTED_TERMINATIONS = Set([
    "completed_tspan",
    "sugar_depletion_at_saved_time",
    "sugar_depletion_at_initial_time",
])

"""
    AromaDesirabilityWindow

Triangular desirability window for a final aroma concentration. Values at
`preferred_g_L` score 1, values at `lower_g_L` or `upper_g_L` score 0, and
interior values are linearly interpolated. The default windows are first-pass
white-wine placeholders and should be recalibrated against experimental sensory
targets before being treated as final product specifications.
"""
struct AromaDesirabilityWindow
    state_name::String
    lower_g_L::Float64
    preferred_g_L::Float64
    upper_g_L::Float64
    weight::Float64
end

function AromaDesirabilityWindow(
    state_name::AbstractString,
    lower_g_L::Real,
    preferred_g_L::Real,
    upper_g_L::Real;
    weight::Real = 1.0,
)::AromaDesirabilityWindow
    lower = Float64(lower_g_L)
    preferred = Float64(preferred_g_L)
    upper = Float64(upper_g_L)
    converted_weight = Float64(weight)
    !isempty(strip(String(state_name))) || throw(
        ArgumentError("Aroma desirability state name cannot be empty."),
    )
    all(isfinite, (lower, preferred, upper, converted_weight)) || throw(
        ArgumentError("Aroma desirability window values must be finite."),
    )
    0.0 <= lower < preferred < upper || throw(
        ArgumentError("Aroma desirability window must satisfy 0 <= lower < preferred < upper."),
    )
    converted_weight >= 0.0 || throw(
        ArgumentError("Aroma desirability window weight must be nonnegative."),
    )
    return AromaDesirabilityWindow(String(state_name), lower, preferred, upper, converted_weight)
end

function default_white_wine_aroma_windows()::Vector{AromaDesirabilityWindow}
    return AromaDesirabilityWindow[
        AromaDesirabilityWindow("phenylethanol", 0.015, 0.040, 0.080; weight = 1.0),
        AromaDesirabilityWindow("isoamyl_alcohol", 0.030, 0.120, 0.300; weight = 0.7),
        AromaDesirabilityWindow("isobutanol", 0.010, 0.040, 0.120; weight = 0.5),
        AromaDesirabilityWindow("methionol", 0.0005, 0.0020, 0.0060; weight = 0.4),
        AromaDesirabilityWindow("tyrosol", 0.005, 0.020, 0.060; weight = 0.4),
        AromaDesirabilityWindow("ethyl_acetate", 0.020, 0.060, 0.150; weight = 0.8),
    ]
end

"""
    DynamicControlObjectiveWeights

Weights for the first white-wine dynamic-control objective. The objective is
minimized and combines a terminal dryness gate, productivity through the
time-integral of sugar excess above dryness, aroma desirability, a normalized
thermal-energy proxy, nutrient dose, smoothness, and numerical health
penalties. The legacy terminal residual-sugar term is retained for diagnostics
but has zero default weight. `terminal_sugar_feasibility_mode=:strict_dryness`
keeps dryness as part of `result.feasible`; `:numeric_health` is intended for
extended-horizon discovery, where dryness remains reported as a gate but does
not mark an otherwise healthy trajectory as failed.
"""
struct DynamicControlObjectiveWeights
    residual_sugar_target_g_L::Float64
    residual_sugar_weight::Float64
    terminal_sugar_gate_g_L::Float64
    terminal_sugar_feasibility_mode::Symbol
    productivity_sugar_excess_weight::Float64
    productivity_sugar_excess_scale_g_L::Float64
    fermentation_time_weight::Float64
    ethanol_reward_weight::Float64
    aroma_desirability_weight::Float64
    cooling_energy_weight::Float64
    thermal_energy_weight::Float64
    temperature_energy_scale_C::Float64
    fermentation_heat_weight::Float64
    cold_setpoint_weight::Float64
    downward_temperature_move_weight::Float64
    ambient_temperature_C::Float64
    fda_total_dose_weight::Float64
    organic_total_dose_weight::Float64
    nutrient_pulse_weight::Float64
    temperature_smoothness_weight::Float64
    temperature_move_weight::Float64
    reference_temperature_C::Float64
    negative_state_tolerance::Float64
    negative_state_penalty_weight::Float64
    incomplete_horizon_penalty_weight::Float64
    failure_penalty::Float64
    aroma_windows::Vector{AromaDesirabilityWindow}
end

function DynamicControlObjectiveWeights(;
    residual_sugar_target_g_L::Real = 5.0,
    residual_sugar_weight::Real = 0.0,
    terminal_sugar_gate_g_L::Real = 5.0,
    terminal_sugar_feasibility_mode::Union{Symbol, AbstractString} = :strict_dryness,
    productivity_sugar_excess_weight::Real = 1.0,
    productivity_sugar_excess_scale_g_L::Real = 150.0,
    fermentation_time_weight::Real = 0.0,
    ethanol_reward_weight::Real = 0.0,
    aroma_desirability_weight::Real = 10.0,
    cooling_energy_weight::Real = 0.0,
    thermal_energy_weight::Real = 0.1,
    temperature_energy_scale_C::Real = 5.0,
    fermentation_heat_weight::Real = 1.0,
    cold_setpoint_weight::Real = 0.02,
    downward_temperature_move_weight::Real = 0.1,
    ambient_temperature_C::Real = 20.0,
    fda_total_dose_weight::Real = 0.5,
    organic_total_dose_weight::Real = 0.5,
    nutrient_pulse_weight::Real = 0.1,
    temperature_smoothness_weight::Real = 0.02,
    temperature_move_weight::Real = 0.0,
    reference_temperature_C::Real = 20.0,
    negative_state_tolerance::Real = 1.0e-9,
    negative_state_penalty_weight::Real = 1.0e8,
    incomplete_horizon_penalty_weight::Real = 1.0e6,
    failure_penalty::Real = 1.0e9,
    aroma_windows::AbstractVector = default_white_wine_aroma_windows(),
)::DynamicControlObjectiveWeights
    windows = AromaDesirabilityWindow[]
    for window in aroma_windows
        window isa AromaDesirabilityWindow || throw(
            ArgumentError("aroma_windows entries must be AromaDesirabilityWindow values."),
        )
        push!(windows, window)
    end

    residual_target = _dynamic_control_nonnegative_weight(
        residual_sugar_target_g_L,
        "residual_sugar_target_g_L",
    )
    terminal_gate = _dynamic_control_nonnegative_weight(
        terminal_sugar_gate_g_L,
        "terminal_sugar_gate_g_L",
    )
    terminal_feasibility_mode =
        _dynamic_control_terminal_sugar_feasibility_mode(terminal_sugar_feasibility_mode)
    productivity_scale = _dynamic_control_positive_weight(
        productivity_sugar_excess_scale_g_L,
        "productivity_sugar_excess_scale_g_L",
    )
    temperature_energy_scale = _dynamic_control_positive_weight(
        temperature_energy_scale_C,
        "temperature_energy_scale_C",
    )
    ambient = Float64(ambient_temperature_C)
    reference = Float64(reference_temperature_C)
    all(isfinite, (ambient, reference)) || throw(
        ArgumentError("ambient_temperature_C and reference_temperature_C must be finite."),
    )

    return DynamicControlObjectiveWeights(
        residual_target,
        _dynamic_control_nonnegative_weight(residual_sugar_weight, "residual_sugar_weight"),
        terminal_gate,
        terminal_feasibility_mode,
        _dynamic_control_nonnegative_weight(
            productivity_sugar_excess_weight,
            "productivity_sugar_excess_weight",
        ),
        productivity_scale,
        _dynamic_control_nonnegative_weight(fermentation_time_weight, "fermentation_time_weight"),
        _dynamic_control_nonnegative_weight(ethanol_reward_weight, "ethanol_reward_weight"),
        _dynamic_control_nonnegative_weight(
            aroma_desirability_weight,
            "aroma_desirability_weight",
        ),
        _dynamic_control_nonnegative_weight(cooling_energy_weight, "cooling_energy_weight"),
        _dynamic_control_nonnegative_weight(thermal_energy_weight, "thermal_energy_weight"),
        temperature_energy_scale,
        _dynamic_control_nonnegative_weight(fermentation_heat_weight, "fermentation_heat_weight"),
        _dynamic_control_nonnegative_weight(cold_setpoint_weight, "cold_setpoint_weight"),
        _dynamic_control_nonnegative_weight(
            downward_temperature_move_weight,
            "downward_temperature_move_weight",
        ),
        ambient,
        _dynamic_control_nonnegative_weight(fda_total_dose_weight, "fda_total_dose_weight"),
        _dynamic_control_nonnegative_weight(
            organic_total_dose_weight,
            "organic_total_dose_weight",
        ),
        _dynamic_control_nonnegative_weight(nutrient_pulse_weight, "nutrient_pulse_weight"),
        _dynamic_control_nonnegative_weight(
            temperature_smoothness_weight,
            "temperature_smoothness_weight",
        ),
        _dynamic_control_nonnegative_weight(temperature_move_weight, "temperature_move_weight"),
        reference,
        _dynamic_control_nonnegative_weight(negative_state_tolerance, "negative_state_tolerance"),
        _dynamic_control_nonnegative_weight(
            negative_state_penalty_weight,
            "negative_state_penalty_weight",
        ),
        _dynamic_control_nonnegative_weight(
            incomplete_horizon_penalty_weight,
            "incomplete_horizon_penalty_weight",
        ),
        _dynamic_control_nonnegative_weight(failure_penalty, "failure_penalty"),
        windows,
    )
end

"""
    DynamicControlObjectiveResult

Result of one smooth temperature/FDA/organic schedule evaluation against the
sequential DFBA simulator.
"""
struct DynamicControlObjectiveResult
    objective_value::Float64
    feasible::Bool
    status::String
    terms::Dict{String, Float64}
    summary::Dict{String, Any}
    schedule::DynamicControlSchedule
    simulation::SimulationResult
    metadata::Dict{String, Any}
end

"""
    DynamicControlCandidateDesign

One candidate dynamic-control design for sequential exploration. Temperature
values are the 12 h-grid setpoints connected by smooth transitions. FDA and
organic doses are total product additions at the default addition times.
"""
struct DynamicControlCandidateDesign
    candidate_id::String
    profile_id::String
    nutrient_strategy_id::String
    temperature_values_C::Vector{Float64}
    fda_doses_g_L::Vector{Float64}
    organic_doses_g_L::Vector{Float64}
    metadata::Dict{String, Any}
end

"""
    DynamicControlSelectionCriteria

Post-evaluation gates for turning a DOE table into a short list for review.
All max thresholds accept `Inf`; gates are intentionally conservative and
auditable rather than a replacement for the scalar objective or Pareto table.
"""
struct DynamicControlSelectionCriteria
    final_total_sugar_max_g_L::Float64
    aroma_desirability_min_score::Float64
    cooling_energy_proxy_max::Float64
    nutrient_total_product_max_g_L::Float64
    max_negative_state_deficit::Float64
    shortlist_count::Int
    prefer_pareto::Bool
    require_feasible::Bool
end

function DynamicControlSelectionCriteria(;
    final_total_sugar_max_g_L::Real = Inf,
    aroma_desirability_min_score::Real = 0.0,
    cooling_energy_proxy_max::Real = Inf,
    nutrient_total_product_max_g_L::Real = Inf,
    max_negative_state_deficit::Real = 1.0e-8,
    shortlist_count::Integer = 5,
    prefer_pareto::Bool = true,
    require_feasible::Bool = true,
)::DynamicControlSelectionCriteria
    count = Int(shortlist_count)
    count > 0 || throw(ArgumentError("shortlist_count must be positive."))
    return DynamicControlSelectionCriteria(
        _dynamic_control_nonnegative_or_inf(
            final_total_sugar_max_g_L,
            "final_total_sugar_max_g_L",
        ),
        _dynamic_control_unit_interval_weight(
            aroma_desirability_min_score,
            "aroma_desirability_min_score",
        ),
        _dynamic_control_nonnegative_or_inf(
            cooling_energy_proxy_max,
            "cooling_energy_proxy_max",
        ),
        _dynamic_control_nonnegative_or_inf(
            nutrient_total_product_max_g_L,
            "nutrient_total_product_max_g_L",
        ),
        _dynamic_control_nonnegative_weight(
            max_negative_state_deficit,
            "max_negative_state_deficit",
        ),
        count,
        prefer_pareto,
        require_feasible,
    )
end

function DynamicControlCandidateDesign(;
    candidate_id::AbstractString,
    profile_id::AbstractString,
    nutrient_strategy_id::AbstractString,
    temperature_values_C::AbstractVector,
    fda_doses_g_L::AbstractVector,
    organic_doses_g_L::AbstractVector,
    metadata::AbstractDict = Dict{String, Any}(),
)::DynamicControlCandidateDesign
    id = strip(String(candidate_id))
    profile = strip(String(profile_id))
    nutrient_strategy = strip(String(nutrient_strategy_id))
    !isempty(id) || throw(ArgumentError("Dynamic-control candidate_id cannot be empty."))
    !isempty(profile) || throw(ArgumentError("Dynamic-control profile_id cannot be empty."))
    !isempty(nutrient_strategy) ||
        throw(ArgumentError("Dynamic-control nutrient_strategy_id cannot be empty."))
    temperatures = Float64.(temperature_values_C)
    fda = Float64.(fda_doses_g_L)
    organic = Float64.(organic_doses_g_L)
    !isempty(temperatures) ||
        throw(ArgumentError("Dynamic-control candidate must contain temperature values."))
    length(fda) == length(organic) || throw(
        ArgumentError("FDA and organic dose vectors must have the same length."),
    )
    all(isfinite, temperatures) || throw(
        ArgumentError("Dynamic-control temperature values must be finite."),
    )
    all(value -> isfinite(value) && value >= 0.0, fda) || throw(
        ArgumentError("Dynamic-control FDA doses must be finite and nonnegative."),
    )
    all(value -> isfinite(value) && value >= 0.0, organic) || throw(
        ArgumentError("Dynamic-control organic doses must be finite and nonnegative."),
    )
    meta = Dict{String, Any}(String(key) => value for (key, value) in metadata)
    return DynamicControlCandidateDesign(id, profile, nutrient_strategy, temperatures, fda, organic, meta)
end

"""
    dynamic_control_candidate_designs(; kwargs...)

Generate a first-pass white-wine design of experiments over smooth temperature
profiles and pump-like nutrient strategies. The defaults are deliberately
small and interpretable: they are meant to seed Pareto exploration before
moving to MPCC-embedded dynamic optimization.
"""
function dynamic_control_candidate_designs(;
    horizon_h::Real = 168.0,
    control_interval_h::Real = 12.0,
    temperature_min_C::Real = 15.0,
    temperature_max_C::Real = 25.0,
    temperature_profile_set::Union{Symbol, AbstractString} = :white_wine_first_pass,
    nutrient_strategy_set::Union{Symbol, AbstractString} = :white_wine_first_pass,
    max_candidates = nothing,
)::Vector{DynamicControlCandidateDesign}
    temperature_count = length(_default_transition_times(horizon_h, control_interval_h)) + 1
    addition_count = length(_default_addition_times(horizon_h, control_interval_h))
    profiles = _dynamic_control_temperature_profile_designs(
        temperature_count;
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        profile_set = temperature_profile_set,
    )
    strategies = _dynamic_control_nutrient_strategy_designs(
        addition_count;
        strategy_set = nutrient_strategy_set,
    )
    limit = _dynamic_control_candidate_limit(max_candidates)
    designs = DynamicControlCandidateDesign[]
    seen = Set{String}()

    profile_by_id = Dict(profile.profile_id => profile for profile in profiles)
    strategy_by_id = Dict(strategy.nutrient_strategy_id => strategy for strategy in strategies)
    for (profile_id, nutrient_strategy_id) in _dynamic_control_seed_candidate_pairs(
        temperature_profile_set,
        nutrient_strategy_set,
    )
        haskey(profile_by_id, profile_id) || continue
        haskey(strategy_by_id, nutrient_strategy_id) || continue
        _dynamic_control_push_candidate_design!(
            designs,
            seen,
            profile_by_id[profile_id],
            strategy_by_id[nutrient_strategy_id],
            limit,
        )
        length(designs) >= limit && return designs
    end

    for profile in profiles
        for strategy in strategies
            _dynamic_control_push_candidate_design!(designs, seen, profile, strategy, limit)
            length(designs) >= limit && return designs
        end
    end
    return designs
end

function dynamic_control_schedule_from_values(
    temperature_values_C::AbstractVector;
    horizon_h::Real = 168.0,
    control_interval_h::Real = 12.0,
    temperature_transition_width_h::Real = 1.0,
    temperature_min_C::Real = 15.0,
    temperature_max_C::Real = 25.0,
    fda_doses_g_L = nothing,
    organic_doses_g_L = nothing,
    addition_times_h = nothing,
    addition_transition_width_h::Real = 0.5,
    fda_nitrogen_fraction_gN_per_g::Real = FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G,
    fda_total_limit_g_L::Real = FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L,
    organic_total_limit_g_L::Real = Inf,
    organic_composition::OrganicNutrientComposition = springferm_xtrem_organic_composition(),
    volatilization_model::AbstractVolatilizationModel = NoVolatilizationModel(),
)::DynamicControlSchedule
    expected_count = length(_default_transition_times(horizon_h, control_interval_h)) + 1
    values = Float64.(temperature_values_C)
    length(values) == expected_count || throw(
        ArgumentError(
            "Temperature control vector must contain $expected_count values; got $(length(values)).",
        ),
    )
    addition_times = addition_times_h === nothing ?
        _default_addition_times(horizon_h, control_interval_h) :
        Float64.(addition_times_h)
    fda_doses = fda_doses_g_L === nothing ? zeros(length(addition_times)) : Float64.(fda_doses_g_L)
    organic_doses =
        organic_doses_g_L === nothing ? zeros(length(addition_times)) : Float64.(organic_doses_g_L)
    return reference_dynamic_control_schedule(
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        temperature_values_C = values,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        fda_doses_g_L = fda_doses,
        organic_doses_g_L = organic_doses,
        addition_times_h = addition_times,
        addition_transition_width_h = addition_transition_width_h,
        fda_nitrogen_fraction_gN_per_g = fda_nitrogen_fraction_gN_per_g,
        fda_total_limit_g_L = fda_total_limit_g_L,
        organic_total_limit_g_L = organic_total_limit_g_L,
        organic_composition = organic_composition,
        volatilization_model = volatilization_model,
    )
end

"""
    dynamic_control_apply_selection_gates!(table; criteria)

Add gate and shortlist columns to a dynamic-control DOE table. The function
expects the columns produced by `scripts/main_dynamic_control_objective_smoke.jl`
and mutates/returns the same `DataFrame`.
"""
function dynamic_control_apply_selection_gates!(
    table::DataFrame;
    criteria::DynamicControlSelectionCriteria = DynamicControlSelectionCriteria(),
)::DataFrame
    _dynamic_control_require_table_columns(
        table,
        [
            "candidate_id",
            "objective_value",
            "feasible",
            "final_total_sugar",
            "aroma_desirability_score",
            "nutrient_total_product_g_L",
            "min_state_value",
        ],
    )
    energy_column = "thermal_energy_proxy_unweighted" in names(table) ?
        "thermal_energy_proxy_unweighted" :
        "cooling_energy_proxy_unweighted"
    energy_column in names(table) || throw(
        ArgumentError(
            "Dynamic-control table requires thermal_energy_proxy_unweighted or cooling_energy_proxy_unweighted.",
        ),
    )
    productivity_column = "productivity_sugar_excess_auc_normalized" in names(table) ?
        "productivity_sugar_excess_auc_normalized" :
        "final_total_sugar"
    n = nrow(table)
    if n == 0
        _dynamic_control_empty_selection_columns!(table)
        return table
    end

    feasible = Bool.(table[!, "feasible"])
    final_sugar = Float64.(table[!, "final_total_sugar"])
    aroma_score = Float64.(table[!, "aroma_desirability_score"])
    energy_proxy = Float64.(table[!, energy_column])
    productivity_proxy = Float64.(table[!, productivity_column])
    nutrient_total = Float64.(table[!, "nutrient_total_product_g_L"])
    min_state = Float64.(table[!, "min_state_value"])
    negative_state_deficit = max.(0.0, .-min_state)

    gate_feasible = criteria.require_feasible ? feasible : trues(n)
    gate_sugar = [
        _dynamic_control_gate_leq(value, criteria.final_total_sugar_max_g_L) for
        value in final_sugar
    ]
    gate_aroma = [
        _dynamic_control_gate_geq(value, criteria.aroma_desirability_min_score) for
        value in aroma_score
    ]
    gate_energy = [
        _dynamic_control_gate_leq(value, criteria.cooling_energy_proxy_max) for
        value in energy_proxy
    ]
    gate_nutrient = [
        _dynamic_control_gate_leq(value, criteria.nutrient_total_product_max_g_L) for
        value in nutrient_total
    ]
    gate_state = [
        _dynamic_control_gate_leq(value, criteria.max_negative_state_deficit) for
        value in negative_state_deficit
    ]
    gate_pass =
        gate_feasible .& gate_sugar .& gate_aroma .& gate_energy .& gate_nutrient .& gate_state

    table[!, "gate_feasible_pass"] = gate_feasible
    table[!, "gate_final_sugar_pass"] = gate_sugar
    table[!, "gate_aroma_pass"] = gate_aroma
    table[!, "gate_energy_pass"] = gate_energy
    table[!, "gate_nutrient_pass"] = gate_nutrient
    table[!, "gate_state_pass"] = gate_state
    table[!, "negative_state_deficit"] = negative_state_deficit
    table[!, "gate_pass"] = gate_pass

    gate_indices = findall(gate_pass)
    basis = "gate_pass"
    if isempty(gate_indices)
        gate_indices = findall(feasible)
        basis = "feasible_fallback"
    end
    if isempty(gate_indices)
        gate_indices = collect(1:n)
        basis = "all_fallback"
    end
    if criteria.prefer_pareto && "pareto_candidate" in names(table)
        pareto_indices = [index for index in gate_indices if Bool(table[index, "pareto_candidate"])]
        if !isempty(pareto_indices)
            gate_indices = pareto_indices
            basis *= "_pareto"
        end
    end
    ranked_indices = sort(
        gate_indices;
        by = index -> (
            _dynamic_control_rank_value(table[index, "objective_value"]),
            _dynamic_control_rank_value(productivity_proxy[index]),
            _dynamic_control_rank_value(table[index, "final_total_sugar"]),
            -_dynamic_control_rank_value(table[index, "aroma_desirability_score"]),
            _dynamic_control_rank_value(energy_proxy[index]),
            _dynamic_control_rank_value(table[index, "nutrient_total_product_g_L"]),
        ),
    )
    selected_count = min(criteria.shortlist_count, length(ranked_indices))
    selected = falses(n)
    selection_rank = fill(0, n)
    selection_basis = fill("not_selected", n)
    for rank in 1:selected_count
        index = ranked_indices[rank]
        selected[index] = true
        selection_rank[index] = rank
        selection_basis[index] = basis
    end
    table[!, "selected_for_review"] = selected
    table[!, "selection_rank"] = selection_rank
    table[!, "selection_basis"] = selection_basis
    return table
end

function aroma_desirability_score(value_g_L::Real, window::AromaDesirabilityWindow)::Float64
    value = Float64(value_g_L)
    isfinite(value) || return 0.0
    value <= window.lower_g_L && return 0.0
    value >= window.upper_g_L && return 0.0
    if value <= window.preferred_g_L
        return (value - window.lower_g_L) / (window.preferred_g_L - window.lower_g_L)
    end
    return (window.upper_g_L - value) / (window.upper_g_L - window.preferred_g_L)
end

function aroma_desirability_score(
    result::SimulationResult,
    windows::AbstractVector{AromaDesirabilityWindow} = default_white_wine_aroma_windows(),
)::Float64
    isempty(windows) && return 1.0
    final_index = lastindex(result.time)
    total_weight = sum((window.weight for window in windows); init = 0.0)
    total_weight > 0.0 || return 1.0
    score = 0.0
    for window in windows
        index = _dynamic_control_state_index(result, window.state_name)
        score += window.weight * aroma_desirability_score(result.states[index, final_index], window)
    end
    return clamp(score / total_weight, 0.0, 1.0)
end

function dynamic_control_energy_proxy(
    result::SimulationResult,
    schedule::DynamicControlSchedule;
    ambient_temperature_C::Real = 20.0,
    fermentation_heat_weight::Real = 1.0,
    cold_setpoint_weight::Real = 0.02,
    downward_temperature_move_weight::Real = 0.1,
)::Float64
    length(result.time) >= 2 || return 0.0
    ambient = Float64(ambient_temperature_C)
    heat_weight = Float64(fermentation_heat_weight)
    cold_weight = Float64(cold_setpoint_weight)
    downward_weight = Float64(downward_temperature_move_weight)
    all(isfinite, (ambient, heat_weight, cold_weight, downward_weight)) || throw(
        ArgumentError("Energy proxy parameters must be finite."),
    )
    all(value -> value >= 0.0, (heat_weight, cold_weight, downward_weight)) || throw(
        ArgumentError("Energy proxy weights must be nonnegative."),
    )

    glucose_index = _dynamic_control_state_index(result, "glucose")
    fructose_index = _dynamic_control_state_index(result, "fructose")
    proxy = 0.0
    previous_temperature = dynamic_temperature_celsius(schedule, result.time[firstindex(result.time)])
    for k in (firstindex(result.time) + 1):lastindex(result.time)
        t0 = Float64(result.time[k - 1])
        t1 = Float64(result.time[k])
        dt = max(0.0, t1 - t0)
        sugar0 = result.states[glucose_index, k - 1] + result.states[fructose_index, k - 1]
        sugar1 = result.states[glucose_index, k] + result.states[fructose_index, k]
        sugar_consumed = max(0.0, sugar0 - sugar1)
        midpoint = 0.5 * (t0 + t1)
        temperature = dynamic_temperature_celsius(schedule, midpoint)
        proxy += heat_weight * sugar_consumed
        proxy += cold_weight * max(0.0, ambient - temperature) * dt
        proxy += downward_weight * max(0.0, previous_temperature - temperature)^2
        previous_temperature = temperature
    end
    return proxy
end

function dynamic_control_thermal_energy_proxy(
    schedule::DynamicControlSchedule;
    ambient_temperature_C::Real = 20.0,
    temperature_scale_C::Real = 5.0,
)::Float64
    ambient = Float64(ambient_temperature_C)
    scale = Float64(temperature_scale_C)
    isfinite(ambient) || throw(ArgumentError("ambient_temperature_C must be finite."))
    isfinite(scale) && scale > 0.0 ||
        throw(ArgumentError("temperature_scale_C must be finite and positive."))
    isempty(schedule.temperature_values_C) && return 0.0
    return sum(((value - ambient) / scale)^2 for value in schedule.temperature_values_C) /
           length(schedule.temperature_values_C)
end

function dynamic_control_time_to_sugar_threshold(
    result::SimulationResult;
    threshold_g_L::Real = 5.0,
)::Float64
    threshold = Float64(threshold_g_L)
    isfinite(threshold) && threshold >= 0.0 ||
        throw(ArgumentError("Sugar threshold must be finite and nonnegative."))
    glucose_index = _dynamic_control_state_index(result, "glucose")
    fructose_index = _dynamic_control_state_index(result, "fructose")
    times = Float64.(result.time)
    isempty(times) && return Inf
    sugar = Float64.(result.states[glucose_index, :] .+ result.states[fructose_index, :])
    sugar[firstindex(sugar)] <= threshold && return times[firstindex(times)]
    for index in (firstindex(times) + 1):lastindex(times)
        previous_sugar = sugar[index - 1]
        current_sugar = sugar[index]
        current_sugar <= threshold || continue
        previous_time = times[index - 1]
        current_time = times[index]
        if previous_sugar <= current_sugar
            return current_time
        end
        fraction = clamp((previous_sugar - threshold) / (previous_sugar - current_sugar), 0.0, 1.0)
        return previous_time + fraction * (current_time - previous_time)
    end
    return Inf
end

function dynamic_control_sugar_excess_auc(
    result::SimulationResult;
    threshold_g_L::Real = 5.0,
)::Float64
    threshold = Float64(threshold_g_L)
    isfinite(threshold) && threshold >= 0.0 ||
        throw(ArgumentError("Sugar threshold must be finite and nonnegative."))
    length(result.time) >= 2 || return 0.0
    glucose_index = _dynamic_control_state_index(result, "glucose")
    fructose_index = _dynamic_control_state_index(result, "fructose")
    total = 0.0
    for index in (firstindex(result.time) + 1):lastindex(result.time)
        t0 = Float64(result.time[index - 1])
        t1 = Float64(result.time[index])
        dt = max(0.0, t1 - t0)
        sugar0 = result.states[glucose_index, index - 1] + result.states[fructose_index, index - 1]
        sugar1 = result.states[glucose_index, index] + result.states[fructose_index, index]
        total += 0.5 * dt * (max(0.0, sugar0 - threshold) + max(0.0, sugar1 - threshold))
    end
    return total
end

function dynamic_control_objective_terms(
    result::SimulationResult,
    schedule::DynamicControlSchedule;
    weights::DynamicControlObjectiveWeights = DynamicControlObjectiveWeights(),
    horizon_h::Real = result.time[end],
)::Dict{String, Float64}
    summary = summarize_simulation(result)
    return dynamic_control_objective_terms(
        result,
        summary,
        schedule;
        weights = weights,
        horizon_h = horizon_h,
    )
end

function dynamic_control_objective_terms(
    result::SimulationResult,
    summary::AbstractDict,
    schedule::DynamicControlSchedule;
    weights::DynamicControlObjectiveWeights = DynamicControlObjectiveWeights(),
    horizon_h::Real,
)::Dict{String, Float64}
    horizon = Float64(horizon_h)
    isfinite(horizon) && horizon > 0.0 ||
        throw(ArgumentError("horizon_h must be finite and positive."))

    final_total_sugar = _dynamic_control_summary_float(summary, "final_total_sugar")
    ethanol_produced = _dynamic_control_summary_float(summary, "ethanol_produced")
    min_state_value = _dynamic_control_summary_float(summary, "min_state_value")
    final_total_sugar = _dynamic_control_summary_float(summary, "final_total_sugar")
    final_time = _dynamic_control_summary_float(summary, "final_time")
    retcode = _dynamic_control_summary_string(summary, "retcode")
    termination_reason = _dynamic_control_summary_string(summary, "termination_reason")

    residual_sugar_excess = max(0.0, final_total_sugar - weights.residual_sugar_target_g_L)
    sugar_excess_auc = dynamic_control_sugar_excess_auc(
        result;
        threshold_g_L = weights.terminal_sugar_gate_g_L,
    )
    normalized_productivity_excess =
        sugar_excess_auc / (horizon * weights.productivity_sugar_excess_scale_g_L)
    negative_excess = max(0.0, -min_state_value - weights.negative_state_tolerance)
    incomplete_gap = _dynamic_control_horizon_incomplete_gap(
        final_time,
        horizon,
        retcode,
        termination_reason,
    )
    failure = retcode == "Success" ? 0.0 : weights.failure_penalty
    temperature_jumps = diff(schedule.temperature_values_C)
    temperature_moves = schedule.temperature_values_C .- weights.reference_temperature_C
    fda_total = sum((event.total_product_g_L for event in schedule.fda_events); init = 0.0)
    organic_total = sum((event.total_product_g_L for event in schedule.organic_events); init = 0.0)
    nutrient_pulses =
        sum((event.total_product_g_L^2 for event in schedule.fda_events); init = 0.0) +
        sum((event.total_product_g_L^2 for event in schedule.organic_events); init = 0.0)
    aroma_score = aroma_desirability_score(result, weights.aroma_windows)
    thermal_energy_proxy = dynamic_control_thermal_energy_proxy(
        schedule;
        ambient_temperature_C = weights.ambient_temperature_C,
        temperature_scale_C = weights.temperature_energy_scale_C,
    )
    energy_proxy = dynamic_control_energy_proxy(
        result,
        schedule;
        ambient_temperature_C = weights.ambient_temperature_C,
        fermentation_heat_weight = weights.fermentation_heat_weight,
        cold_setpoint_weight = weights.cold_setpoint_weight,
        downward_temperature_move_weight = weights.downward_temperature_move_weight,
    )

    return Dict{String, Float64}(
        "residual_sugar_penalty" => weights.residual_sugar_weight * residual_sugar_excess^2,
        "productivity_sugar_excess_auc_penalty" =>
            weights.productivity_sugar_excess_weight * normalized_productivity_excess^2,
        "fermentation_time_penalty" => weights.fermentation_time_weight * final_time,
        "ethanol_reward" => -weights.ethanol_reward_weight * ethanol_produced,
        "aroma_desirability_penalty" => weights.aroma_desirability_weight * (1.0 - aroma_score)^2,
        "cooling_energy_proxy" => weights.cooling_energy_weight * energy_proxy,
        "thermal_energy_proxy" => weights.thermal_energy_weight * thermal_energy_proxy,
        "fda_total_dose_penalty" => weights.fda_total_dose_weight * fda_total,
        "organic_total_dose_penalty" => weights.organic_total_dose_weight * organic_total,
        "nutrient_pulse_penalty" => weights.nutrient_pulse_weight * nutrient_pulses,
        "temperature_smoothness" =>
            weights.temperature_smoothness_weight * sum(abs2, temperature_jumps),
        "temperature_move" => weights.temperature_move_weight * sum(abs2, temperature_moves),
        "negative_state_penalty" => weights.negative_state_penalty_weight * negative_excess^2,
        "incomplete_horizon_penalty" =>
            weights.incomplete_horizon_penalty_weight * incomplete_gap^2,
        "failure_penalty" => failure,
    )
end

function dynamic_control_objective_value(terms::AbstractDict)::Float64
    return sum(Float64(value) for value in values(terms))
end

function evaluate_dynamic_control_objective(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    schedule::DynamicControlSchedule;
    weights::DynamicControlObjectiveWeights = DynamicControlObjectiveWeights(),
    horizon_h::Real = 168.0,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    saveat = 1.0,
    algorithm = OrdinaryDiffEq.Tsit5(),
    reconstruct_fluxes::Bool = false,
    stop_on_sugar_depletion::Bool = true,
    sugar_depletion_tol::Real = 1.0e-6,
    progress_interval_seconds::Real = 0.0,
    max_rhs_calls = nothing,
    max_walltime_seconds = nothing,
)::DynamicControlObjectiveResult
    result = simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = (0.0, Float64(horizon_h)),
        params = params,
        dynamic_control_schedule = schedule,
        optimizer = optimizer,
        silent = silent,
        lp_atol = lp_atol,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        saveat = saveat,
        algorithm = algorithm,
        reconstruct_fluxes = reconstruct_fluxes,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
    )
    summary = summarize_simulation(result)
    terms = dynamic_control_objective_terms(
        result,
        summary,
        schedule;
        weights = weights,
        horizon_h = horizon_h,
    )
    objective_value = dynamic_control_objective_value(terms)
    feasible = _dynamic_control_objective_feasible(summary, weights, Float64(horizon_h))
    status = feasible ? "accepted" : "rejected"
    metadata = _dynamic_control_objective_metadata(
        schedule,
        weights;
        horizon_h = horizon_h,
        saveat = saveat,
        reconstruct_fluxes = reconstruct_fluxes,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
    )
    metadata["objective_value"] = objective_value
    metadata["objective_status"] = status
    metadata["objective_feasible"] = feasible
    metadata["aroma_desirability_score"] = aroma_desirability_score(result, weights.aroma_windows)
    metadata["time_to_terminal_sugar_gate_h"] = dynamic_control_time_to_sugar_threshold(
        result;
        threshold_g_L = weights.terminal_sugar_gate_g_L,
    )
    metadata["terminal_sugar_gate_pass"] =
        Float64(get(summary, "final_total_sugar", Inf)) <= weights.terminal_sugar_gate_g_L + 1.0e-12
    metadata["productivity_sugar_excess_auc_g_L_h"] = dynamic_control_sugar_excess_auc(
        result;
        threshold_g_L = weights.terminal_sugar_gate_g_L,
    )
    metadata["productivity_sugar_excess_auc_normalized"] =
        metadata["productivity_sugar_excess_auc_g_L_h"] /
        (Float64(horizon_h) * weights.productivity_sugar_excess_scale_g_L)
    metadata["thermal_energy_proxy_unweighted"] = dynamic_control_thermal_energy_proxy(
        schedule;
        ambient_temperature_C = weights.ambient_temperature_C,
        temperature_scale_C = weights.temperature_energy_scale_C,
    )
    metadata["cooling_energy_proxy_unweighted"] = dynamic_control_energy_proxy(
        result,
        schedule;
        ambient_temperature_C = weights.ambient_temperature_C,
        fermentation_heat_weight = weights.fermentation_heat_weight,
        cold_setpoint_weight = weights.cold_setpoint_weight,
        downward_temperature_move_weight = weights.downward_temperature_move_weight,
    )

    return DynamicControlObjectiveResult(
        objective_value,
        feasible,
        status,
        terms,
        Dict{String, Any}(summary),
        schedule,
        result,
        metadata,
    )
end

function evaluate_dynamic_control_objective(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    temperature_values_C::AbstractVector;
    horizon_h::Real = 168.0,
    control_interval_h::Real = 12.0,
    temperature_transition_width_h::Real = 1.0,
    temperature_min_C::Real = 15.0,
    temperature_max_C::Real = 25.0,
    fda_doses_g_L = nothing,
    organic_doses_g_L = nothing,
    addition_times_h = nothing,
    addition_transition_width_h::Real = 0.5,
    fda_nitrogen_fraction_gN_per_g::Real = FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G,
    fda_total_limit_g_L::Real = FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L,
    organic_total_limit_g_L::Real = Inf,
    organic_composition::OrganicNutrientComposition = springferm_xtrem_organic_composition(),
    volatilization_model::AbstractVolatilizationModel = NoVolatilizationModel(),
    kwargs...,
)::DynamicControlObjectiveResult
    schedule = dynamic_control_schedule_from_values(
        temperature_values_C;
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        fda_doses_g_L = fda_doses_g_L,
        organic_doses_g_L = organic_doses_g_L,
        addition_times_h = addition_times_h,
        addition_transition_width_h = addition_transition_width_h,
        fda_nitrogen_fraction_gN_per_g = fda_nitrogen_fraction_gN_per_g,
        fda_total_limit_g_L = fda_total_limit_g_L,
        organic_total_limit_g_L = organic_total_limit_g_L,
        organic_composition = organic_composition,
        volatilization_model = volatilization_model,
    )
    return evaluate_dynamic_control_objective(
        model,
        reaction_map,
        schedule;
        horizon_h = horizon_h,
        kwargs...,
    )
end

function _dynamic_control_nonnegative_weight(value::Real, label::AbstractString)::Float64
    converted = Float64(value)
    isfinite(converted) && converted >= 0.0 || throw(
        ArgumentError("$label must be finite and nonnegative."),
    )
    return converted
end

function _dynamic_control_positive_weight(value::Real, label::AbstractString)::Float64
    converted = Float64(value)
    isfinite(converted) && converted > 0.0 ||
        throw(ArgumentError("$label must be finite and positive."))
    return converted
end

function _dynamic_control_nonnegative_or_inf(value::Real, label::AbstractString)::Float64
    converted = Float64(value)
    ((isfinite(converted) && converted >= 0.0) || converted == Inf) || throw(
        ArgumentError("$label must be nonnegative or Inf."),
    )
    return converted
end

function _dynamic_control_unit_interval_weight(value::Real, label::AbstractString)::Float64
    converted = Float64(value)
    isfinite(converted) && 0.0 <= converted <= 1.0 || throw(
        ArgumentError("$label must be finite and in [0, 1]."),
    )
    return converted
end

function _dynamic_control_terminal_sugar_feasibility_mode(
    value::Union{Symbol, AbstractString},
)::Symbol
    mode = Symbol(lowercase(replace(strip(String(value)), '-' => '_')))
    mode in (:strict_dryness, :dryness_gate, :terminal_sugar_gate) && return :strict_dryness
    mode in (:numeric_health, :numerical_health, :diagnostic, :horizon_diagnostic) &&
        return :numeric_health
    throw(
        ArgumentError(
            "terminal_sugar_feasibility_mode must be :strict_dryness or :numeric_health; got $(String(value)).",
        ),
    )
end

function _dynamic_control_summary_float(summary::AbstractDict, key::AbstractString)::Float64
    haskey(summary, key) || throw(ArgumentError("Summary is missing key: $key"))
    value = Float64(summary[key])
    isfinite(value) || throw(ArgumentError("Summary key $key must be finite; got $(summary[key])."))
    return value
end

function _dynamic_control_summary_string(summary::AbstractDict, key::AbstractString)::String
    haskey(summary, key) || throw(ArgumentError("Summary is missing key: $key"))
    value = summary[key]
    value === nothing && return "nothing"
    value === missing && return "missing"
    return String(value)
end

function _dynamic_control_horizon_incomplete_gap(
    final_time::Real,
    horizon_h::Real,
    retcode::AbstractString,
    termination_reason::AbstractString,
)::Float64
    retcode == "Success" || return max(0.0, Float64(horizon_h) - Float64(final_time))
    termination_reason in DYNAMIC_CONTROL_ACCEPTED_TERMINATIONS && return 0.0
    return max(0.0, Float64(horizon_h) - Float64(final_time))
end

function _dynamic_control_objective_feasible(
    summary::AbstractDict,
    weights::DynamicControlObjectiveWeights,
    horizon_h::Real,
)::Bool
    retcode = _dynamic_control_summary_string(summary, "retcode")
    termination_reason = _dynamic_control_summary_string(summary, "termination_reason")
    min_state_value = _dynamic_control_summary_float(summary, "min_state_value")
    final_total_sugar = _dynamic_control_summary_float(summary, "final_total_sugar")
    final_time = _dynamic_control_summary_float(summary, "final_time")
    incomplete_gap = _dynamic_control_horizon_incomplete_gap(
        final_time,
        horizon_h,
        retcode,
        termination_reason,
    )
    numerically_feasible = retcode == "Success" &&
        termination_reason in DYNAMIC_CONTROL_ACCEPTED_TERMINATIONS &&
        incomplete_gap == 0.0 &&
        min_state_value >= -weights.negative_state_tolerance
    numerically_feasible || return false
    weights.terminal_sugar_feasibility_mode == :numeric_health && return true
    return final_total_sugar <= weights.terminal_sugar_gate_g_L + 1.0e-12
end

function _dynamic_control_objective_metadata(
    schedule::DynamicControlSchedule,
    weights::DynamicControlObjectiveWeights;
    horizon_h::Real,
    saveat,
    reconstruct_fluxes::Bool,
    stop_on_sugar_depletion::Bool,
    sugar_depletion_tol::Real,
)::Dict{String, Any}
    return Dict{String, Any}(
        "objective_type" => DYNAMIC_CONTROL_OBJECTIVE_TYPE,
        "objective_sense" => "minimize",
        "objective_primary_terms" => [
            "terminal_dryness_gate",
            "productivity_sugar_excess_auc",
            "aroma_desirability",
            "thermal_energy_proxy",
            "nutrient_dose",
        ],
        "objective_methodology_reference" =>
            "White-wine aroma-energy trade-off inspired by Yabo/Casenave/Mouret plus smooth operability constraints.",
        "horizon_h" => Float64(horizon_h),
        "temperature_values_C" => copy(schedule.temperature_values_C),
        "temperature_transition_times_h" => copy(schedule.temperature_transition_times_h),
        "temperature_transition_width_h" => schedule.temperature_transition_width_h,
        "temperature_min_C" => schedule.temperature_min_C,
        "temperature_max_C" => schedule.temperature_max_C,
        "fda_total_product_g_L" =>
            sum((event.total_product_g_L for event in schedule.fda_events); init = 0.0),
        "organic_total_product_g_L" =>
            sum((event.total_product_g_L for event in schedule.organic_events); init = 0.0),
        "fda_nitrogen_fraction_gN_per_g" => schedule.fda_nitrogen_fraction_gN_per_g,
        "organic_nitrogen_fraction_gN_per_g" =>
            schedule.organic_composition.nitrogen_fraction_gN_per_g,
        "organic_composition_metadata" => schedule.organic_composition.metadata,
        "volatilization_enabled" => !(schedule.volatilization_model isa NoVolatilizationModel),
        "saveat" => saveat,
        "reconstruct_fluxes" => reconstruct_fluxes,
        "stop_on_sugar_depletion" => stop_on_sugar_depletion,
        "sugar_depletion_tol" => Float64(sugar_depletion_tol),
        "residual_sugar_target_g_L" => weights.residual_sugar_target_g_L,
        "residual_sugar_weight" => weights.residual_sugar_weight,
        "terminal_sugar_gate_g_L" => weights.terminal_sugar_gate_g_L,
        "terminal_sugar_feasibility_mode" => String(weights.terminal_sugar_feasibility_mode),
        "productivity_sugar_excess_weight" => weights.productivity_sugar_excess_weight,
        "productivity_sugar_excess_scale_g_L" =>
            weights.productivity_sugar_excess_scale_g_L,
        "fermentation_time_weight" => weights.fermentation_time_weight,
        "ethanol_reward_weight" => weights.ethanol_reward_weight,
        "aroma_desirability_weight" => weights.aroma_desirability_weight,
        "cooling_energy_weight" => weights.cooling_energy_weight,
        "thermal_energy_weight" => weights.thermal_energy_weight,
        "temperature_energy_scale_C" => weights.temperature_energy_scale_C,
        "ambient_temperature_C" => weights.ambient_temperature_C,
        "fda_total_dose_weight" => weights.fda_total_dose_weight,
        "organic_total_dose_weight" => weights.organic_total_dose_weight,
        "nutrient_pulse_weight" => weights.nutrient_pulse_weight,
        "temperature_smoothness_weight" => weights.temperature_smoothness_weight,
        "temperature_move_weight" => weights.temperature_move_weight,
        "reference_temperature_C" => weights.reference_temperature_C,
        "negative_state_tolerance" => weights.negative_state_tolerance,
        "negative_state_penalty_weight" => weights.negative_state_penalty_weight,
        "incomplete_horizon_penalty_weight" => weights.incomplete_horizon_penalty_weight,
        "failure_penalty" => weights.failure_penalty,
        "aroma_windows" => [
            Dict{String, Any}(
                "state_name" => window.state_name,
                "lower_g_L" => window.lower_g_L,
                "preferred_g_L" => window.preferred_g_L,
                "upper_g_L" => window.upper_g_L,
                "weight" => window.weight,
            ) for window in weights.aroma_windows
        ],
        "accepted_termination_reasons" => sort(collect(DYNAMIC_CONTROL_ACCEPTED_TERMINATIONS)),
    )
end

function _dynamic_control_state_index(result::SimulationResult, name::AbstractString)::Int
    names = get(result.metadata, "state_names", DEFAULT_SIMULATION_STATE_NAMES)
    index = findfirst(==(String(name)), String.(names))
    index === nothing && error("State name not found in SimulationResult metadata: $(String(name)).")
    index <= size(result.states, 1) || error(
        "State index $index for $(String(name)) exceeds SimulationResult state dimension $(size(result.states, 1)).",
    )
    return index
end

function _dynamic_control_require_table_columns(table::DataFrame, columns::AbstractVector{<:AbstractString})
    for column in columns
        String(column) in names(table) ||
            throw(ArgumentError("Dynamic-control table is missing column: $(String(column))."))
    end
    return nothing
end

function _dynamic_control_empty_selection_columns!(table::DataFrame)
    table[!, "gate_feasible_pass"] = Bool[]
    table[!, "gate_final_sugar_pass"] = Bool[]
    table[!, "gate_aroma_pass"] = Bool[]
    table[!, "gate_energy_pass"] = Bool[]
    table[!, "gate_nutrient_pass"] = Bool[]
    table[!, "gate_state_pass"] = Bool[]
    table[!, "negative_state_deficit"] = Float64[]
    table[!, "gate_pass"] = Bool[]
    table[!, "selected_for_review"] = Bool[]
    table[!, "selection_rank"] = Int[]
    table[!, "selection_basis"] = String[]
    return table
end

function _dynamic_control_gate_leq(value::Real, threshold::Real)::Bool
    converted = Float64(value)
    isfinite(converted) || return false
    threshold == Inf && return true
    return converted <= Float64(threshold) + 1.0e-12
end

function _dynamic_control_gate_geq(value::Real, threshold::Real)::Bool
    converted = Float64(value)
    isfinite(converted) || return false
    return converted >= Float64(threshold) - 1.0e-12
end

function _dynamic_control_rank_value(value)::Float64
    converted = try
        Float64(value)
    catch
        Inf
    end
    isfinite(converted) || return Inf
    return converted
end

function _dynamic_control_profile_set_name(value::Union{Symbol, AbstractString})::Symbol
    return Symbol(lowercase(replace(strip(String(value)), '-' => '_')))
end

function _dynamic_control_temperature_profile_designs(
    value_count::Integer;
    temperature_min_C::Real,
    temperature_max_C::Real,
    profile_set::Union{Symbol, AbstractString},
)::Vector{NamedTuple}
    count = Int(value_count)
    count > 0 || throw(ArgumentError("Temperature profile value count must be positive."))
    set_name = _dynamic_control_profile_set_name(profile_set)
    set_name in (
        :white_wine_first_pass,
        :white_wine_168h_atlas,
        :atlas,
        :smoke,
        :horizon_frontier,
        :extended_horizon_frontier,
        :drytime_frontier,
        :horizon_fda_frontier,
        :extended_horizon_fda_frontier,
        :drytime_fda_frontier,
        :horizon_fda_soft_frontier,
        :extended_horizon_fda_soft_frontier,
        :drytime_fda_soft_frontier,
    ) || throw(
        ArgumentError("Unsupported dynamic-control temperature profile set: $(String(set_name))."),
    )
    tmin = Float64(temperature_min_C)
    tmax = Float64(temperature_max_C)
    profiles = NamedTuple[]
    if set_name in (:horizon_fda_frontier, :extended_horizon_fda_frontier, :drytime_fda_frontier)
        return [
            (
                profile_id = "flat25",
                temperature_values_C =
                    fill(_dynamic_control_clamped_temperature(25.0, tmin, tmax), count),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_horizon_fastest_isothermal",
                ),
            ),
            (
                profile_id = "flat24",
                temperature_values_C =
                    fill(_dynamic_control_clamped_temperature(24.0, tmin, tmax), count),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_horizon_hot_isothermal",
                ),
            ),
            (
                profile_id = "ramp24_to25",
                temperature_values_C =
                    _dynamic_control_linear_profile(count, 24.0, 25.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_horizon_hot_finish_ramp",
                ),
            ),
            (
                profile_id = "ramp22_to25",
                temperature_values_C =
                    _dynamic_control_linear_profile(count, 22.0, 25.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_horizon_productivity_ramp",
                ),
            ),
            (
                profile_id = "warm25_until168_cool22",
                temperature_values_C =
                    _dynamic_control_prefix_profile(count, min(count, 14), 25.0, 22.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_horizon_hot_core_moderate_finish",
                ),
            ),
        ]
    end
    if set_name in (
        :horizon_fda_soft_frontier,
        :extended_horizon_fda_soft_frontier,
        :drytime_fda_soft_frontier,
    )
        return [
            (
                profile_id = "flat22",
                temperature_values_C =
                    fill(_dynamic_control_clamped_temperature(22.0, tmin, tmax), count),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_soft_warm_isothermal",
                ),
            ),
            (
                profile_id = "flat24",
                temperature_values_C =
                    fill(_dynamic_control_clamped_temperature(24.0, tmin, tmax), count),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_soft_hot_isothermal",
                ),
            ),
            (
                profile_id = "ramp22_to25",
                temperature_values_C =
                    _dynamic_control_linear_profile(count, 22.0, 25.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_soft_productivity_ramp",
                ),
            ),
            (
                profile_id = "ramp20_to25",
                temperature_values_C =
                    _dynamic_control_linear_profile(count, 20.0, 25.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_soft_reference_warming_ramp",
                ),
            ),
            (
                profile_id = "warm25_until168_cool22",
                temperature_values_C =
                    _dynamic_control_prefix_profile(count, min(count, 14), 25.0, 22.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "fda_soft_hot_core_moderate_finish",
                ),
            ),
        ]
    end
    if set_name in (:horizon_frontier, :extended_horizon_frontier, :drytime_frontier)
        return [
            (
                profile_id = "flat25",
                temperature_values_C =
                    fill(_dynamic_control_clamped_temperature(25.0, tmin, tmax), count),
                metadata = Dict{String, Any}(
                    "profile_family" => "extended_horizon_fastest_isothermal",
                ),
            ),
            (
                profile_id = "flat24",
                temperature_values_C =
                    fill(_dynamic_control_clamped_temperature(24.0, tmin, tmax), count),
                metadata = Dict{String, Any}(
                    "profile_family" => "extended_horizon_hot_isothermal",
                ),
            ),
            (
                profile_id = "ramp22_to25",
                temperature_values_C =
                    _dynamic_control_linear_profile(count, 22.0, 25.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "extended_horizon_productivity_ramp",
                ),
            ),
            (
                profile_id = "ramp20_to25",
                temperature_values_C =
                    _dynamic_control_linear_profile(count, 20.0, 25.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "extended_horizon_reference_warming_ramp",
                ),
            ),
            (
                profile_id = "warm25_until72_cool22",
                temperature_values_C =
                    _dynamic_control_prefix_profile(count, min(count, 6), 25.0, 22.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "early_productivity_then_moderate_retention",
                ),
            ),
            (
                profile_id = "warm25_until168_cool20",
                temperature_values_C =
                    _dynamic_control_prefix_profile(count, min(count, 14), 25.0, 20.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "near_dry_productivity_then_cool_finish",
                ),
            ),
            (
                profile_id = "warm25_until72_cool18",
                temperature_values_C =
                    _dynamic_control_prefix_profile(count, min(count, 6), 25.0, 18.0, tmin, tmax),
                metadata = Dict{String, Any}(
                    "profile_family" => "aggressive_productivity_then_aroma_retention",
                ),
            ),
        ]
    end
    push!(
        profiles,
        (
            profile_id = "flat20",
            temperature_values_C = fill(_dynamic_control_clamped_temperature(20.0, tmin, tmax), count),
            metadata = Dict{String, Any}("profile_family" => "isothermal_reference"),
        ),
    )
    if set_name in (:white_wine_168h_atlas, :atlas)
        for value in (15.0, 18.0, 22.0, 25.0)
            push!(
                profiles,
                (
                    profile_id = "flat$(Int(round(value)))",
                    temperature_values_C =
                        fill(_dynamic_control_clamped_temperature(value, tmin, tmax), count),
                    metadata = Dict{String, Any}("profile_family" => "isothermal_atlas"),
                ),
            )
        end
    end
    push!(
        profiles,
        (
            profile_id = "cool18_warm22",
            temperature_values_C = _dynamic_control_prefix_profile(count, 1, 18.0, 22.0, tmin, tmax),
            metadata = Dict{String, Any}("profile_family" => "early_cool_then_warm"),
        ),
    )
    push!(
        profiles,
        (
            profile_id = "cool18x2_warm22",
            temperature_values_C = _dynamic_control_prefix_profile(count, 2, 18.0, 22.0, tmin, tmax),
            metadata = Dict{String, Any}("profile_family" => "extended_early_cool_then_warm"),
        ),
    )
    set_name == :smoke && return profiles

    append!(
        profiles,
        [
            (
                profile_id = "flat18",
                temperature_values_C =
                    fill(_dynamic_control_clamped_temperature(18.0, tmin, tmax), count),
                metadata = Dict{String, Any}("profile_family" => "cool_isothermal"),
            ),
            (
                profile_id = "flat22",
                temperature_values_C =
                    fill(_dynamic_control_clamped_temperature(22.0, tmin, tmax), count),
                metadata = Dict{String, Any}("profile_family" => "warm_isothermal"),
            ),
            (
                profile_id = "cool16_warm20",
                temperature_values_C =
                    _dynamic_control_prefix_profile(count, 2, 16.0, 20.0, tmin, tmax),
                metadata = Dict{String, Any}("profile_family" => "aroma_preserving_cool_start"),
            ),
            (
                profile_id = "ramp18_to22",
                temperature_values_C =
                    _dynamic_control_linear_profile(count, 18.0, 22.0, tmin, tmax),
                metadata = Dict{String, Any}("profile_family" => "smooth_warming_ramp"),
            ),
            (
                profile_id = "cool18_warm24_late",
                temperature_values_C =
                    _dynamic_control_two_stage_profile(count, 2, 18.0, 22.0, 24.0, tmin, tmax),
                metadata = Dict{String, Any}("profile_family" => "late_completion_push"),
            ),
        ],
    )
    if set_name in (:white_wine_168h_atlas, :atlas)
        append!(
            profiles,
            [
                (
                    profile_id = "warm24_cool18_late",
                    temperature_values_C =
                        _dynamic_control_two_stage_profile(count, max(1, count - 3), 24.0, 22.0, 18.0, tmin, tmax),
                    metadata = Dict{String, Any}(
                        "profile_family" => "productive_start_aroma_retention_finish",
                    ),
                ),
                (
                    profile_id = "ramp20_to25",
                    temperature_values_C =
                        _dynamic_control_linear_profile(count, 20.0, 25.0, tmin, tmax),
                    metadata = Dict{String, Any}("profile_family" => "productivity_warming_ramp"),
                ),
                (
                    profile_id = "ramp22_to18",
                    temperature_values_C =
                        _dynamic_control_linear_profile(count, 22.0, 18.0, tmin, tmax),
                    metadata = Dict{String, Any}("profile_family" => "aroma_retention_cooling_ramp"),
                ),
                (
                    profile_id = "warm25_until72_cool18",
                    temperature_values_C =
                        _dynamic_control_prefix_profile(count, min(count, 6), 25.0, 18.0, tmin, tmax),
                    metadata = Dict{String, Any}(
                        "profile_family" => "aggressive_productivity_then_cooling",
                    ),
                ),
                (
                    profile_id = "cool15_until24_warm22",
                    temperature_values_C =
                        _dynamic_control_prefix_profile(count, min(count, 2), 15.0, 22.0, tmin, tmax),
                    metadata = Dict{String, Any}(
                        "profile_family" => "cold_aroma_start_then_completion",
                    ),
                ),
            ],
        )
    end
    return profiles
end

function _dynamic_control_nutrient_strategy_designs(
    addition_count::Integer;
    strategy_set::Union{Symbol, AbstractString},
)::Vector{NamedTuple}
    count = Int(addition_count)
    count >= 0 || throw(ArgumentError("Nutrient addition count must be nonnegative."))
    set_name = _dynamic_control_profile_set_name(strategy_set)
    set_name in (
        :white_wine_first_pass,
        :white_wine_168h_atlas,
        :atlas,
        :smoke,
        :horizon_frontier,
        :extended_horizon_frontier,
        :drytime_frontier,
        :horizon_fda_frontier,
        :extended_horizon_fda_frontier,
        :drytime_fda_frontier,
        :horizon_fda_soft_frontier,
        :extended_horizon_fda_soft_frontier,
        :drytime_fda_soft_frontier,
    ) || throw(
        ArgumentError("Unsupported dynamic-control nutrient strategy set: $(String(set_name))."),
    )
    strategies = NamedTuple[]
    if set_name in (:horizon_fda_frontier, :extended_horizon_fda_frontier, :drytime_fda_frontier)
        mid_index = max(1, min(count, ceil(Int, 0.5 * max(count, 1))))
        late_index = max(1, min(count, ceil(Int, 0.75 * max(count, 1))))
        quarter_index = max(1, min(count, ceil(Int, 0.25 * max(count, 1))))
        three_quarter_index = max(1, min(count, ceil(Int, 0.75 * max(count, 1))))
        return [
            _dynamic_control_nutrient_strategy("none", zeros(count), zeros(count)),
            _dynamic_control_nutrient_strategy(
                "fda_early_3p0_limit",
                _dynamic_control_single_dose(count, 1, 3.0),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_early_2p5_late0p5",
                _dynamic_control_multi_dose(count, [(1, 2.5), (late_index, 0.5)]),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_split_1p5_1p5_mid",
                _dynamic_control_multi_dose(count, [(1, 1.5), (mid_index, 1.5)]),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_early2p0_mid1p0",
                _dynamic_control_multi_dose(count, [(1, 2.0), (mid_index, 1.0)]),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_early1p0_mid2p0",
                _dynamic_control_multi_dose(count, [(1, 1.0), (mid_index, 2.0)]),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_three_pulse_1p0",
                _dynamic_control_multi_dose(
                    count,
                    [(1, 1.0), (quarter_index, 1.0), (mid_index, 1.0)],
                ),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_quarter_split_0p75",
                _dynamic_control_multi_dose(
                    count,
                    [(1, 0.75), (quarter_index, 0.75), (mid_index, 0.75), (three_quarter_index, 0.75)],
                ),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_early_2p0",
                _dynamic_control_single_dose(count, 1, 2.0),
                zeros(count),
            ),
        ]
    end
    if set_name in (
        :horizon_fda_soft_frontier,
        :extended_horizon_fda_soft_frontier,
        :drytime_fda_soft_frontier,
    )
        mid_index = max(1, min(count, ceil(Int, 0.5 * max(count, 1))))
        quarter_index = max(1, min(count, ceil(Int, 0.25 * max(count, 1))))
        three_quarter_index = max(1, min(count, ceil(Int, 0.75 * max(count, 1))))
        return [
            _dynamic_control_nutrient_strategy("none", zeros(count), zeros(count)),
            _dynamic_control_nutrient_strategy(
                "fda_split_1p0_1p0_mid",
                _dynamic_control_multi_dose(count, [(1, 1.0), (mid_index, 1.0)]),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_split_1p5_1p5_mid",
                _dynamic_control_multi_dose(count, [(1, 1.5), (mid_index, 1.5)]),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_three_pulse_0p75",
                _dynamic_control_multi_dose(
                    count,
                    [(1, 0.75), (quarter_index, 0.75), (mid_index, 0.75)],
                ),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_quarter_split_0p5",
                _dynamic_control_multi_dose(
                    count,
                    [(1, 0.5), (quarter_index, 0.5), (mid_index, 0.5), (three_quarter_index, 0.5)],
                ),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_early_1p0",
                _dynamic_control_single_dose(count, 1, 1.0),
                zeros(count),
            ),
        ]
    end
    if set_name in (:horizon_frontier, :extended_horizon_frontier, :drytime_frontier)
        mid_index = max(1, min(count, ceil(Int, 0.5 * max(count, 1))))
        late_index = max(1, min(count, ceil(Int, 0.7 * max(count, 1))))
        return [
            _dynamic_control_nutrient_strategy("none", zeros(count), zeros(count)),
            _dynamic_control_nutrient_strategy(
                "springferm_early_1p0_stress",
                zeros(count),
                _dynamic_control_single_dose(count, 1, 1.0),
            ),
            _dynamic_control_nutrient_strategy(
                "springferm_split_0p5_0p5_mid",
                zeros(count),
                _dynamic_control_multi_dose(count, [(1, 0.5), (mid_index, 0.5)]),
            ),
            _dynamic_control_nutrient_strategy(
                "springferm_late_0p4",
                zeros(count),
                _dynamic_control_single_dose(count, late_index, 0.4),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_early_3p0_limit",
                _dynamic_control_single_dose(count, 1, 3.0),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_split_1p5_1p5_mid",
                _dynamic_control_multi_dose(count, [(1, 1.5), (mid_index, 1.5)]),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "mixed_early_fda2p0_org0p5_stress",
                _dynamic_control_single_dose(count, 1, 2.0),
                _dynamic_control_single_dose(count, 1, 0.5),
            ),
            _dynamic_control_nutrient_strategy(
                "mixed_split_fda1p0_org0p25_mid",
                _dynamic_control_multi_dose(count, [(1, 1.0), (mid_index, 1.0)]),
                _dynamic_control_multi_dose(count, [(1, 0.25), (mid_index, 0.25)]),
            ),
        ]
    end
    push!(strategies, _dynamic_control_nutrient_strategy("none", zeros(count), zeros(count)))
    push!(
        strategies,
        _dynamic_control_nutrient_strategy(
            "fda_early_1p0",
            _dynamic_control_single_dose(count, 1, 1.0),
            zeros(count),
        ),
    )
    push!(
        strategies,
        _dynamic_control_nutrient_strategy(
            "springferm_early_0p2",
            zeros(count),
            _dynamic_control_single_dose(count, 1, 0.2),
        ),
    )
    push!(
        strategies,
        _dynamic_control_nutrient_strategy(
            "mixed_early_fda0p5_org0p1",
            _dynamic_control_single_dose(count, 1, 0.5),
            _dynamic_control_single_dose(count, 1, 0.1),
        ),
    )
    set_name == :smoke && return strategies

    append!(
        strategies,
        [
            _dynamic_control_nutrient_strategy(
                "fda_early_2p0",
                _dynamic_control_single_dose(count, 1, 2.0),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "springferm_early_0p4",
                zeros(count),
                _dynamic_control_single_dose(count, 1, 0.4),
            ),
            _dynamic_control_nutrient_strategy(
                "fda_split_0p5_0p5",
                _dynamic_control_split_dose(count, 0.5, 0.5),
                zeros(count),
            ),
            _dynamic_control_nutrient_strategy(
                "springferm_split_0p1_0p1",
                zeros(count),
                _dynamic_control_split_dose(count, 0.1, 0.1),
            ),
            _dynamic_control_nutrient_strategy(
                "mixed_split_fda0p5_org0p1",
                _dynamic_control_split_dose(count, 0.25, 0.25),
                _dynamic_control_split_dose(count, 0.05, 0.05),
            ),
        ],
    )
    if set_name in (:white_wine_168h_atlas, :atlas)
        append!(
            strategies,
            [
                _dynamic_control_nutrient_strategy(
                    "fda_late_1p0",
                    _dynamic_control_single_dose(count, min(max(count, 1), 7), 1.0),
                    zeros(count),
                ),
                _dynamic_control_nutrient_strategy(
                    "fda_three_pulse_0p5",
                    _dynamic_control_multi_dose(count, [(1, 0.5), (3, 0.5), (7, 0.5)]),
                    zeros(count),
                ),
                _dynamic_control_nutrient_strategy(
                    "springferm_early_0p4",
                    zeros(count),
                    _dynamic_control_single_dose(count, 1, 0.4),
                ),
                _dynamic_control_nutrient_strategy(
                    "springferm_three_pulse_0p1",
                    zeros(count),
                    _dynamic_control_multi_dose(count, [(1, 0.1), (3, 0.1), (7, 0.1)]),
                ),
                _dynamic_control_nutrient_strategy(
                    "mixed_three_pulse_fda0p5_org0p1",
                    _dynamic_control_multi_dose(count, [(1, 0.5), (3, 0.5), (7, 0.5)]),
                    _dynamic_control_multi_dose(count, [(1, 0.1), (3, 0.1), (7, 0.1)]),
                ),
            ],
        )
    end
    return strategies
end

function _dynamic_control_seed_candidate_pairs(
    temperature_profile_set::Union{Symbol, AbstractString} = :white_wine_first_pass,
    nutrient_strategy_set::Union{Symbol, AbstractString} = :white_wine_first_pass,
)::Vector{Tuple{String, String}}
    profile_set_name = _dynamic_control_profile_set_name(temperature_profile_set)
    nutrient_set_name = _dynamic_control_profile_set_name(nutrient_strategy_set)
    if profile_set_name in (:horizon_fda_frontier, :extended_horizon_fda_frontier, :drytime_fda_frontier) ||
       nutrient_set_name in (:horizon_fda_frontier, :extended_horizon_fda_frontier, :drytime_fda_frontier)
        return [
            ("flat25", "fda_early_3p0_limit"),
            ("flat25", "fda_early_2p5_late0p5"),
            ("flat25", "fda_split_1p5_1p5_mid"),
            ("flat25", "fda_early2p0_mid1p0"),
            ("flat25", "fda_early1p0_mid2p0"),
            ("flat25", "fda_three_pulse_1p0"),
            ("flat25", "fda_quarter_split_0p75"),
            ("flat24", "fda_early_3p0_limit"),
            ("ramp24_to25", "fda_early_3p0_limit"),
            ("ramp22_to25", "fda_early_3p0_limit"),
            ("warm25_until168_cool22", "fda_early_3p0_limit"),
            ("flat25", "none"),
        ]
    end
    if profile_set_name in (
        :horizon_fda_soft_frontier,
        :extended_horizon_fda_soft_frontier,
        :drytime_fda_soft_frontier,
    ) ||
       nutrient_set_name in (
        :horizon_fda_soft_frontier,
        :extended_horizon_fda_soft_frontier,
        :drytime_fda_soft_frontier,
    )
        return [
            ("flat22", "none"),
            ("ramp20_to25", "none"),
            ("ramp20_to25", "fda_split_1p0_1p0_mid"),
            ("flat22", "fda_quarter_split_0p5"),
            ("flat22", "fda_early_1p0"),
            ("flat22", "fda_three_pulse_0p75"),
            ("flat22", "fda_split_1p0_1p0_mid"),
            ("ramp22_to25", "fda_quarter_split_0p5"),
            ("flat24", "fda_quarter_split_0p5"),
            ("warm25_until168_cool22", "fda_quarter_split_0p5"),
            ("ramp22_to25", "fda_split_1p0_1p0_mid"),
            ("flat24", "fda_split_1p0_1p0_mid"),
            ("ramp22_to25", "fda_split_1p5_1p5_mid"),
        ]
    end
    if profile_set_name in (:horizon_frontier, :extended_horizon_frontier, :drytime_frontier) ||
       nutrient_set_name in (:horizon_frontier, :extended_horizon_frontier, :drytime_frontier)
        return [
            ("flat25", "springferm_early_1p0_stress"),
            ("flat25", "springferm_split_0p5_0p5_mid"),
            ("flat25", "fda_early_3p0_limit"),
            ("flat25", "mixed_early_fda2p0_org0p5_stress"),
            ("ramp22_to25", "springferm_early_1p0_stress"),
            ("warm25_until168_cool20", "springferm_early_1p0_stress"),
            ("flat24", "springferm_early_1p0_stress"),
            ("warm25_until72_cool22", "springferm_split_0p5_0p5_mid"),
        ]
    end
    return [
        ("flat20", "none"),
        ("cool18_warm22", "none"),
        ("cool18_warm22", "fda_early_1p0"),
        ("cool18_warm22", "springferm_early_0p2"),
        ("cool18x2_warm22", "mixed_early_fda0p5_org0p1"),
        ("cool18x2_warm22", "springferm_early_0p2"),
        ("ramp18_to22", "springferm_early_0p2"),
        ("cool16_warm20", "none"),
    ]
end

function _dynamic_control_push_candidate_design!(
    designs::Vector{DynamicControlCandidateDesign},
    seen::Set{String},
    profile::NamedTuple,
    strategy::NamedTuple,
    limit::Int,
)
    length(designs) >= limit && return designs
    candidate_id = "$(profile.profile_id)__$(strategy.nutrient_strategy_id)"
    candidate_id in seen && return designs
    metadata = Dict{String, Any}(
        "temperature_profile" => profile.metadata,
        "nutrient_strategy" => strategy.metadata,
    )
    push!(
        designs,
        DynamicControlCandidateDesign(
            candidate_id = candidate_id,
            profile_id = profile.profile_id,
            nutrient_strategy_id = strategy.nutrient_strategy_id,
            temperature_values_C = profile.temperature_values_C,
            fda_doses_g_L = strategy.fda_doses_g_L,
            organic_doses_g_L = strategy.organic_doses_g_L,
            metadata = metadata,
        ),
    )
    push!(seen, candidate_id)
    return designs
end

function _dynamic_control_candidate_limit(max_candidates)::Int
    max_candidates === nothing && return typemax(Int)
    limit = Int(max_candidates)
    limit > 0 || throw(ArgumentError("max_candidates must be positive when provided."))
    return limit
end

function _dynamic_control_clamped_temperature(value::Real, tmin::Real, tmax::Real)::Float64
    return clamp(Float64(value), Float64(tmin), Float64(tmax))
end

function _dynamic_control_prefix_profile(
    count::Integer,
    prefix_count::Integer,
    prefix_temperature_C::Real,
    tail_temperature_C::Real,
    tmin::Real,
    tmax::Real,
)::Vector{Float64}
    n = Int(count)
    prefix = clamp(Int(prefix_count), 0, n)
    values = fill(_dynamic_control_clamped_temperature(tail_temperature_C, tmin, tmax), n)
    prefix > 0 && (values[1:prefix] .= _dynamic_control_clamped_temperature(prefix_temperature_C, tmin, tmax))
    return values
end

function _dynamic_control_linear_profile(
    count::Integer,
    start_temperature_C::Real,
    stop_temperature_C::Real,
    tmin::Real,
    tmax::Real,
)::Vector{Float64}
    n = Int(count)
    n > 0 || throw(ArgumentError("Linear temperature profile count must be positive."))
    n == 1 && return [_dynamic_control_clamped_temperature(start_temperature_C, tmin, tmax)]
    start = Float64(start_temperature_C)
    stop = Float64(stop_temperature_C)
    return [
        _dynamic_control_clamped_temperature(start + (stop - start) * (index - 1) / (n - 1), tmin, tmax)
        for index in 1:n
    ]
end

function _dynamic_control_two_stage_profile(
    count::Integer,
    first_stage_count::Integer,
    first_temperature_C::Real,
    middle_temperature_C::Real,
    final_temperature_C::Real,
    tmin::Real,
    tmax::Real,
)::Vector{Float64}
    n = Int(count)
    first_count = clamp(Int(first_stage_count), 0, n)
    values = fill(_dynamic_control_clamped_temperature(middle_temperature_C, tmin, tmax), n)
    first_count > 0 && (values[1:first_count] .= _dynamic_control_clamped_temperature(first_temperature_C, tmin, tmax))
    n >= 3 && (values[max(first_count + 1, n - 1):n] .= _dynamic_control_clamped_temperature(final_temperature_C, tmin, tmax))
    return values
end

function _dynamic_control_single_dose(count::Integer, index::Integer, dose_g_L::Real)::Vector{Float64}
    n = Int(count)
    doses = zeros(n)
    n == 0 && return doses
    doses[clamp(Int(index), 1, n)] = Float64(dose_g_L)
    return doses
end

function _dynamic_control_split_dose(
    count::Integer,
    first_dose_g_L::Real,
    second_dose_g_L::Real,
)::Vector{Float64}
    n = Int(count)
    doses = zeros(n)
    n == 0 && return doses
    doses[1] = Float64(first_dose_g_L)
    n >= 2 && (doses[min(n, 3)] += Float64(second_dose_g_L))
    return doses
end

function _dynamic_control_multi_dose(
    count::Integer,
    indexed_doses::AbstractVector{<:Tuple{<:Integer, <:Real}},
)::Vector{Float64}
    n = Int(count)
    doses = zeros(n)
    n == 0 && return doses
    for (index, dose) in indexed_doses
        doses[clamp(Int(index), 1, n)] += Float64(dose)
    end
    return doses
end

function _dynamic_control_nutrient_strategy(
    nutrient_strategy_id::AbstractString,
    fda_doses_g_L::AbstractVector,
    organic_doses_g_L::AbstractVector,
)::NamedTuple
    fda = Float64.(fda_doses_g_L)
    organic = Float64.(organic_doses_g_L)
    return (
        nutrient_strategy_id = String(nutrient_strategy_id),
        fda_doses_g_L = fda,
        organic_doses_g_L = organic,
        metadata = Dict{String, Any}(
            "fda_total_product_g_L" => sum(fda; init = 0.0),
            "organic_total_product_g_L" => sum(organic; init = 0.0),
            "fda_basis" => "FDA solution 10% w/w",
            "organic_basis" => "SpringFerm Xtrem g product/L",
        ),
    )
end
