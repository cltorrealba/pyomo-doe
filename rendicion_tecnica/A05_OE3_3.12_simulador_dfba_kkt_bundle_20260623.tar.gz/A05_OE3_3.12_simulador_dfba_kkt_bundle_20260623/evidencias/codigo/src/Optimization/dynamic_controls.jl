const DAP_MOLAR_MASS_G_MOL = 132.056
const N_MOLAR_MASS_G_MOL = 14.007
const FDA_DAP_NITROGEN_FRACTION = 2.0 * N_MOLAR_MASS_G_MOL / DAP_MOLAR_MASS_G_MOL
const OIV_DAP_MAX_G_L = 0.3
const FDA_SOLUTION_MASS_FRACTION = 0.10
const FDA_ACTIVE_YAN_FRACTION_GN_PER_G = 0.20
const FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G =
    FDA_SOLUTION_MASS_FRACTION * FDA_ACTIVE_YAN_FRACTION_GN_PER_G
const FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L = OIV_DAP_MAX_G_L / FDA_SOLUTION_MASS_FRACTION

const SPRINGFERM_XTREM_DRY_MATTER_FRACTION = 0.9431
const SPRINGFERM_XTREM_REAL_YAN_FRACTION_GN_PER_G =
    SPRINGFERM_XTREM_DRY_MATTER_FRACTION * 0.0415
const SPRINGFERM_XTREM_YAN_EQUIVALENT_FRACTION_GN_PER_G = 0.10

function fda_solution_nitrogen_fraction_gN_per_g(;
    solution_mass_fraction::Real = FDA_SOLUTION_MASS_FRACTION,
    active_yan_fraction_gN_per_g::Real = FDA_ACTIVE_YAN_FRACTION_GN_PER_G,
)::Float64
    solution_fraction = Float64(solution_mass_fraction)
    active_fraction = Float64(active_yan_fraction_gN_per_g)
    isfinite(solution_fraction) && 0.0 <= solution_fraction <= 1.0 || throw(
        ArgumentError("FDA solution mass fraction must be finite and in [0, 1]."),
    )
    isfinite(active_fraction) && active_fraction >= 0.0 || throw(
        ArgumentError("FDA active YAN fraction must be finite and nonnegative."),
    )
    return solution_fraction * active_fraction
end

function fda_solution_oiv_equivalent_limit_g_L(;
    active_product_limit_g_L::Real = OIV_DAP_MAX_G_L,
    solution_mass_fraction::Real = FDA_SOLUTION_MASS_FRACTION,
)::Float64
    active_limit = Float64(active_product_limit_g_L)
    solution_fraction = Float64(solution_mass_fraction)
    isfinite(active_limit) && active_limit >= 0.0 || throw(
        ArgumentError("Active FDA/DAP product limit must be finite and nonnegative."),
    )
    isfinite(solution_fraction) && solution_fraction > 0.0 || throw(
        ArgumentError("FDA solution mass fraction must be finite and positive."),
    )
    return active_limit / solution_fraction
end

"""
    OrganicNutrientComposition

Composition model for an organic nutrient product. `nitrogen_fraction_gN_per_g`
converts product dose in g/L into gN/L. The amino-acid fractions distribute
that organic nitrogen over the five tracked amino-acid states in
`ZENTENO_AMINO_ACID_ROLES` order. Auxiliary fractions are metadata hooks for
future lipids, vitamins, or sterol effects not yet represented in the 19-state
model.
"""
struct OrganicNutrientComposition
    nitrogen_fraction_gN_per_g::Float64
    amino_acid_nitrogen_fractions::Vector{Float64}
    auxiliary_fractions::Dict{String, Float64}
    metadata::Dict{String, Any}
end

function OrganicNutrientComposition(;
    nitrogen_fraction_gN_per_g::Real = 0.10,
    amino_acid_nitrogen_fractions::AbstractVector = fill(0.2, 5),
    auxiliary_fractions::AbstractDict = Dict{String, Float64}(),
    metadata::AbstractDict = Dict{String, Any}(),
)::OrganicNutrientComposition
    nitrogen_fraction = Float64(nitrogen_fraction_gN_per_g)
    isfinite(nitrogen_fraction) && nitrogen_fraction >= 0.0 ||
        throw(ArgumentError("Organic nutrient nitrogen fraction must be finite and nonnegative."))
    length(amino_acid_nitrogen_fractions) == 5 || throw(
        ArgumentError("Organic nutrient composition requires five amino-acid nitrogen fractions."),
    )
    fractions = Float64.(amino_acid_nitrogen_fractions)
    all(value -> isfinite(value) && value >= 0.0, fractions) || throw(
        ArgumentError("Amino-acid nitrogen fractions must be finite and nonnegative."),
    )
    total_fraction = sum(fractions)
    isapprox(total_fraction, 1.0; atol = 1.0e-10, rtol = 1.0e-10) || throw(
        ArgumentError(
            "Amino-acid nitrogen fractions must sum to 1.0; got $(total_fraction).",
        ),
    )
    aux = Dict(String(key) => Float64(value) for (key, value) in auxiliary_fractions)
    all(value -> isfinite(value) && value >= 0.0, values(aux)) || throw(
        ArgumentError("Organic nutrient auxiliary fractions must be finite and nonnegative."),
    )
    meta = Dict{String, Any}(String(key) => value for (key, value) in metadata)
    return OrganicNutrientComposition(nitrogen_fraction, fractions, aux, meta)
end

function default_organic_nutrient_composition()::OrganicNutrientComposition
    return OrganicNutrientComposition(
        metadata = Dict{String, Any}(
            "composition_status" => "placeholder_product_equivalent",
            "note" =>
                "Replace nitrogen_fraction_gN_per_g and amino-acid fractions with product data before scientific use.",
        ),
    )
end

"""
    springferm_xtrem_organic_composition(; nitrogen_basis=:yan_equivalent)

Return the first SpringFerm Xtrem composition used for white-wine dynamic
optimization. Doses are expressed as g product/L. `nitrogen_basis` may be
`:yan_equivalent`, using the product label value of 20 ppm YAN at 20 g/hL
(0.10 gN/g product), or `:real_yan`, using the analytical NNH3 + amino-N
fraction on dry matter (0.0415 * 0.9431 gN/g product).
"""
function springferm_xtrem_organic_composition(;
    nitrogen_basis::Union{Symbol, AbstractString} = :yan_equivalent,
)::OrganicNutrientComposition
    basis = Symbol(lowercase(replace(strip(String(nitrogen_basis)), '-' => '_')))
    nitrogen_fraction =
        basis == :yan_equivalent ? SPRINGFERM_XTREM_YAN_EQUIVALENT_FRACTION_GN_PER_G :
        basis == :real_yan ? SPRINGFERM_XTREM_REAL_YAN_FRACTION_GN_PER_G :
        throw(ArgumentError("SpringFerm nitrogen_basis must be yan_equivalent or real_yan."))

    tracked_free_aa_g_per_100g_product = Dict(
        "phenylalanine" => 1.30,
        "leucine" => 2.19,
        "valine" => 1.56,
        "methionine" => 0.0,
        "tyrosine" => 0.0,
    )
    tracked_masses = [
        tracked_free_aa_g_per_100g_product[role] for role in ZENTENO_AMINO_ACID_ROLES
    ]
    tracked_total = sum(tracked_masses)
    tracked_total > 0.0 || throw(ArgumentError("SpringFerm tracked amino-acid total is zero."))
    tracked_fractions = tracked_masses ./ tracked_total

    return OrganicNutrientComposition(
        nitrogen_fraction_gN_per_g = nitrogen_fraction,
        amino_acid_nitrogen_fractions = tracked_fractions,
        auxiliary_fractions = Dict(
            "dry_matter_fraction" => SPRINGFERM_XTREM_DRY_MATTER_FRACTION,
            "free_amino_acids_fraction_g_per_g_product" => 0.2224,
            "total_amino_acids_fraction_g_per_g_product" => 0.4623,
            "protein_peptides_fraction_g_per_g_dm" => 0.6537,
            "nucleotides_fraction_g_per_g_dm" => 0.0952,
            "fat_matter_fraction_g_per_g_dm" => 0.0148,
            "trehalose_fraction_g_per_g_dm" => 0.1001,
        ),
        metadata = Dict{String, Any}(
            "product" => "SpringFerm Xtrem",
            "composition_status" => "supplier_overview_and_user_provided_summary",
            "nitrogen_basis" => String(basis),
            "yan_equivalent_fraction_gN_per_g_product" =>
                SPRINGFERM_XTREM_YAN_EQUIVALENT_FRACTION_GN_PER_G,
            "real_yan_fraction_gN_per_g_product" => SPRINGFERM_XTREM_REAL_YAN_FRACTION_GN_PER_G,
            "yan_equivalent_reference" => "20 ppm YAN at 20 g/hL product",
            "amino_acid_fraction_basis" =>
                "tracked free amino-acid g/100 g product table normalized over model states",
            "tracked_free_amino_acids_g_per_100g_product" =>
                tracked_free_aa_g_per_100g_product,
            "missing_tracked_free_amino_acids" => ["methionine", "tyrosine"],
            "note" =>
                "Methionine and tyrosine were not present in the provided top free-AA table; their first-pass product fractions are zero until the full certificate is encoded.",
        ),
    )
end

"""
    SmoothDoseEvent

Smooth pump-like addition event. `total_product_g_L` is the total product dose
delivered by the event. `center_time_h` is the midpoint of the delivery sigmoid.
`transition_width_h` controls how quickly the cumulative dose moves from 0 to
the total dose; larger values represent slower pump additions.
"""
struct SmoothDoseEvent
    center_time_h::Float64
    total_product_g_L::Float64
    transition_width_h::Float64

    function SmoothDoseEvent(
        center_time_h::Real,
        total_product_g_L::Real,
        transition_width_h::Real,
    )
        center = Float64(center_time_h)
        dose = Float64(total_product_g_L)
        width = Float64(transition_width_h)
        isfinite(center) || throw(ArgumentError("Dose event center time must be finite."))
        isfinite(dose) && dose >= 0.0 ||
            throw(ArgumentError("Dose event product dose must be finite and nonnegative."))
        isfinite(width) && width > 0.0 ||
            throw(ArgumentError("Dose event transition width must be finite and positive."))
        return new(center, dose, width)
    end
end

abstract type AbstractVolatilizationModel end

struct NoVolatilizationModel <: AbstractVolatilizationModel end

"""
    VaporLiquidVolatilizationModel

Lightweight hook for a future liquid-vapor equilibrium loss model. The current
implementation is a first-order placeholder sink for the six aroma states,
parameterized by dimensionless partition coefficients, a gas-exchange rate, an
optional temperature Q10 factor, and an optional sugar-consumption stripping
multiplier. Set all coefficients or the gas-exchange rate to zero to disable
losses.
"""
struct VaporLiquidVolatilizationModel <: AbstractVolatilizationModel
    aroma_partition_coefficients::Vector{Float64}
    gas_exchange_rate_h_inv::Float64
    temperature_reference_C::Float64
    temperature_q10::Float64
    sugar_stripping_multiplier_per_g_L_h::Float64
    metadata::Dict{String, Any}
end

function VaporLiquidVolatilizationModel(;
    aroma_partition_coefficients::AbstractVector = zeros(6),
    gas_exchange_rate_h_inv::Real = 0.0,
    temperature_reference_C::Real = 20.0,
    temperature_q10::Real = 1.0,
    sugar_stripping_multiplier_per_g_L_h::Real = 0.0,
    metadata::AbstractDict = Dict{String, Any}(),
)::VaporLiquidVolatilizationModel
    length(aroma_partition_coefficients) == 6 || throw(
        ArgumentError("Volatilization model requires six aroma partition coefficients."),
    )
    coefficients = Float64.(aroma_partition_coefficients)
    all(value -> isfinite(value) && value >= 0.0, coefficients) || throw(
        ArgumentError("Aroma partition coefficients must be finite and nonnegative."),
    )
    rate = Float64(gas_exchange_rate_h_inv)
    isfinite(rate) && rate >= 0.0 ||
        throw(ArgumentError("Gas-exchange rate must be finite and nonnegative."))
    reference_temperature = Float64(temperature_reference_C)
    isfinite(reference_temperature) || throw(
        ArgumentError("Volatilization reference temperature must be finite."),
    )
    q10 = Float64(temperature_q10)
    isfinite(q10) && q10 > 0.0 ||
        throw(ArgumentError("Volatilization temperature_q10 must be finite and positive."))
    sugar_multiplier = Float64(sugar_stripping_multiplier_per_g_L_h)
    isfinite(sugar_multiplier) && sugar_multiplier >= 0.0 || throw(
        ArgumentError(
            "Volatilization sugar stripping multiplier must be finite and nonnegative.",
        ),
    )
    meta = Dict{String, Any}(String(key) => value for (key, value) in metadata)
    return VaporLiquidVolatilizationModel(
        coefficients,
        rate,
        reference_temperature,
        q10,
        sugar_multiplier,
        meta,
    )
end

"""
    white_wine_first_pass_volatilization_model(; kwargs...)

Return a disabled-by-default-compatible first-pass aroma stripping model for
white-wine dynamic-control exploration. The model is phenomenological: losses
scale with liquid aroma concentration, a temperature Q10 factor, and a simple
sugar-consumption activity proxy. It is intended for sensitivity/DOE ranking,
not as a calibrated L-G equilibrium model.
"""
function white_wine_first_pass_volatilization_model(;
    gas_exchange_rate_h_inv::Real = 0.02,
    temperature_reference_C::Real = 20.0,
    temperature_q10::Real = 2.0,
    sugar_stripping_multiplier_per_g_L_h::Real = 0.02,
)::VaporLiquidVolatilizationModel
    return VaporLiquidVolatilizationModel(
        aroma_partition_coefficients = [0.20, 0.15, 0.20, 0.10, 0.05, 0.35],
        gas_exchange_rate_h_inv = gas_exchange_rate_h_inv,
        temperature_reference_C = temperature_reference_C,
        temperature_q10 = temperature_q10,
        sugar_stripping_multiplier_per_g_L_h = sugar_stripping_multiplier_per_g_L_h,
        metadata = Dict{String, Any}(
            "model_status" => "first_pass_uncalibrated_aroma_stripping_proxy",
            "aroma_state_order" => [
                "phenylethanol",
                "isoamyl_alcohol",
                "isobutanol",
                "methionol",
                "tyrosol",
                "ethyl_acetate",
            ],
            "loss_law" =>
                "k_gas * partition_coeff * C_liq * Q10^((T-Tref)/10) * (1 + sugar_multiplier * sugar_consumption_rate)",
        ),
    )
end

"""
    DynamicControlSchedule

Smooth dynamic-control schedule for early optimization work. Temperature is
represented by piecewise target values connected by logistic transitions.
Nutrient additions are represented as smooth cumulative pump events.
"""
struct DynamicControlSchedule
    temperature_transition_times_h::Vector{Float64}
    temperature_values_C::Vector{Float64}
    temperature_transition_width_h::Float64
    temperature_min_C::Float64
    temperature_max_C::Float64
    fda_events::Vector{SmoothDoseEvent}
    organic_events::Vector{SmoothDoseEvent}
    fda_nitrogen_fraction_gN_per_g::Float64
    fda_total_limit_g_L::Float64
    organic_total_limit_g_L::Float64
    organic_composition::OrganicNutrientComposition
    volatilization_model::AbstractVolatilizationModel
    metadata::Dict{String, Any}
end

"""
    DynamicControlDecisionSpec

Finite-dimensional decision scaffold for the first simultaneous dynamic-control
work. It records the 12 h-grid temperature and nutrient slots that may be freed
later in the MPCC, with starts, bounds, and local trust-region radii. The spec
does not add JuMP variables or solve anything by itself; it is an auditable
bridge between fixed schedules and embedded control variables.
"""
struct DynamicControlDecisionSpec
    horizon_h::Float64
    control_interval_h::Float64
    temperature_transition_width_h::Float64
    addition_transition_width_h::Float64
    temperature_min_C::Float64
    temperature_max_C::Float64
    temperature_transition_times_h::Vector{Float64}
    addition_times_h::Vector{Float64}
    temperature_start_C::Vector{Float64}
    temperature_lower_C::Vector{Float64}
    temperature_upper_C::Vector{Float64}
    temperature_free::Vector{Bool}
    temperature_trust_region_C::Float64
    fda_start_g_L::Vector{Float64}
    fda_lower_g_L::Vector{Float64}
    fda_upper_g_L::Vector{Float64}
    fda_free::Vector{Bool}
    fda_trust_region_g_L::Float64
    fda_nitrogen_fraction_gN_per_g::Float64
    fda_total_limit_g_L::Float64
    organic_start_g_L::Vector{Float64}
    organic_lower_g_L::Vector{Float64}
    organic_upper_g_L::Vector{Float64}
    organic_free::Vector{Bool}
    organic_trust_region_g_L::Float64
    organic_total_limit_g_L::Float64
    organic_composition::OrganicNutrientComposition
    volatilization_model::AbstractVolatilizationModel
    metadata::Dict{String, Any}
end

function DynamicControlSchedule(;
    temperature_transition_times_h::AbstractVector = Float64[],
    temperature_values_C::AbstractVector = [20.0],
    temperature_transition_width_h::Real = 1.0,
    temperature_min_C::Real = 15.0,
    temperature_max_C::Real = 25.0,
    fda_events::AbstractVector = SmoothDoseEvent[],
    organic_events::AbstractVector = SmoothDoseEvent[],
    fda_nitrogen_fraction_gN_per_g::Real = FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G,
    fda_total_limit_g_L::Real = FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L,
    organic_total_limit_g_L::Real = Inf,
    organic_composition::OrganicNutrientComposition = springferm_xtrem_organic_composition(),
    volatilization_model::AbstractVolatilizationModel = NoVolatilizationModel(),
    metadata::AbstractDict = Dict{String, Any}(),
)::DynamicControlSchedule
    transition_times = Float64.(temperature_transition_times_h)
    all(isfinite, transition_times) || throw(
        ArgumentError("Temperature transition times must be finite."),
    )
    issorted(transition_times) && all(diff(transition_times) .> 0.0) || throw(
        ArgumentError("Temperature transition times must be strictly increasing."),
    )
    values = Float64.(temperature_values_C)
    length(values) == length(transition_times) + 1 || throw(
        ArgumentError(
            "Temperature values length must equal transition count + 1. " *
            "Got $(length(values)) values and $(length(transition_times)) transitions.",
        ),
    )
    width = Float64(temperature_transition_width_h)
    isfinite(width) && width > 0.0 ||
        throw(ArgumentError("Temperature transition width must be finite and positive."))
    tmin = Float64(temperature_min_C)
    tmax = Float64(temperature_max_C)
    isfinite(tmin) && isfinite(tmax) && tmin < tmax ||
        throw(ArgumentError("Temperature bounds must be finite with min < max."))
    all(value -> isfinite(value) && tmin <= value <= tmax, values) || throw(
        ArgumentError("Temperature target values must be finite and within [$tmin, $tmax] C."),
    )
    fda = SmoothDoseEvent[]
    for event in fda_events
        event isa SmoothDoseEvent || throw(
            ArgumentError("fda_events entries must be SmoothDoseEvent values."),
        )
        push!(fda, event)
    end
    organic = SmoothDoseEvent[]
    for event in organic_events
        event isa SmoothDoseEvent || throw(
            ArgumentError("organic_events entries must be SmoothDoseEvent values."),
        )
        push!(organic, event)
    end
    fda_fraction = Float64(fda_nitrogen_fraction_gN_per_g)
    isfinite(fda_fraction) && fda_fraction >= 0.0 ||
        throw(ArgumentError("FDA nitrogen fraction must be finite and nonnegative."))
    fda_limit = Float64(fda_total_limit_g_L)
    (isfinite(fda_limit) || isinf(fda_limit)) && fda_limit >= 0.0 ||
        throw(ArgumentError("FDA total limit must be nonnegative, finite or Inf."))
    organic_limit = Float64(organic_total_limit_g_L)
    (isfinite(organic_limit) || isinf(organic_limit)) && organic_limit >= 0.0 ||
        throw(ArgumentError("Organic total limit must be nonnegative, finite or Inf."))
    total_fda = sum((event.total_product_g_L for event in fda); init = 0.0)
    total_organic = sum((event.total_product_g_L for event in organic); init = 0.0)
    total_fda <= fda_limit + 1.0e-12 || throw(
        ArgumentError("Total FDA dose $(total_fda) g/L exceeds limit $(fda_limit) g/L."),
    )
    total_organic <= organic_limit + 1.0e-12 || throw(
        ArgumentError(
            "Total organic nutrient dose $(total_organic) g/L exceeds limit $(organic_limit) g/L.",
        ),
    )
    meta = Dict{String, Any}(String(key) => value for (key, value) in metadata)
    meta["fda_reference"] = get(
        meta,
        "fda_reference",
        "FDA solution at 10% w/w; 1 g solution/L contributes 0.02 gN/L as ammonium-equivalent YAN.",
    )
    meta["organic_reference"] = get(
        meta,
        "organic_reference",
        "Product-specific placeholder; replace with supplier or regulatory data.",
    )
    return DynamicControlSchedule(
        transition_times,
        values,
        width,
        tmin,
        tmax,
        fda,
        organic,
        fda_fraction,
        fda_limit,
        organic_limit,
        organic_composition,
        volatilization_model,
        meta,
    )
end

function _smooth_sigmoid(x::Real)::Float64
    value = Float64(x)
    value >= 40.0 && return 1.0
    value <= -40.0 && return 0.0
    return 1.0 / (1.0 + exp(-value))
end

function _smooth_step(t::Real, center_time_h::Real, width_h::Real)::Float64
    return _smooth_sigmoid((Float64(t) - Float64(center_time_h)) / Float64(width_h))
end

function dynamic_temperature_celsius(schedule::DynamicControlSchedule, t::Real)::Float64
    value = schedule.temperature_values_C[1]
    for (index, transition_time) in enumerate(schedule.temperature_transition_times_h)
        delta = schedule.temperature_values_C[index + 1] - schedule.temperature_values_C[index]
        value += delta * _smooth_step(t, transition_time, schedule.temperature_transition_width_h)
    end
    return clamp(value, schedule.temperature_min_C, schedule.temperature_max_C)
end

function dynamic_temperature_kelvin(schedule::DynamicControlSchedule, t::Real)::Float64
    return dynamic_temperature_celsius(schedule, t) + 273.15
end

function zenteno_parameters_with_temperature(
    params::ZentenoKineticParameters,
    temperature_K::Real,
)::ZentenoKineticParameters
    temperature = Float64(temperature_K)
    isfinite(temperature) && temperature > 0.0 ||
        throw(ArgumentError("Temperature must be finite and positive in Kelvin."))
    kwargs = Dict{Symbol, Any}(
        field => getfield(params, field) for field in fieldnames(ZentenoKineticParameters)
    )
    kwargs[:temperature_K] = temperature
    return ZentenoKineticParameters(; kwargs...)
end

function dynamic_zenteno_parameters(
    schedule::DynamicControlSchedule,
    t::Real;
    base_params::ZentenoKineticParameters = default_zenteno_parameters(),
)::ZentenoKineticParameters
    return zenteno_parameters_with_temperature(base_params, dynamic_temperature_kelvin(schedule, t))
end

function smooth_dose_cumulative_g_L(event::SmoothDoseEvent, t::Real)::Float64
    return event.total_product_g_L * _smooth_step(t, event.center_time_h, event.transition_width_h)
end

function smooth_dose_rate_g_L_h(event::SmoothDoseEvent, t::Real)::Float64
    sigma = _smooth_step(t, event.center_time_h, event.transition_width_h)
    return event.total_product_g_L * sigma * (1.0 - sigma) / event.transition_width_h
end

function _smooth_events_cumulative(events::Vector{SmoothDoseEvent}, t::Real)::Float64
    return sum((smooth_dose_cumulative_g_L(event, t) for event in events); init = 0.0)
end

function _smooth_events_rate(events::Vector{SmoothDoseEvent}, t::Real)::Float64
    return sum((smooth_dose_rate_g_L_h(event, t) for event in events); init = 0.0)
end

function dynamic_control_values(schedule::DynamicControlSchedule, t::Real)::NamedTuple
    fda_product_cumulative = _smooth_events_cumulative(schedule.fda_events, t)
    organic_product_cumulative = _smooth_events_cumulative(schedule.organic_events, t)
    fda_product_rate = _smooth_events_rate(schedule.fda_events, t)
    organic_product_rate = _smooth_events_rate(schedule.organic_events, t)
    return (
        time_h = Float64(t),
        temperature_C = dynamic_temperature_celsius(schedule, t),
        temperature_K = dynamic_temperature_kelvin(schedule, t),
        fda_product_cumulative_g_L = fda_product_cumulative,
        fda_product_rate_g_L_h = fda_product_rate,
        fda_nitrogen_cumulative_gN_L =
            fda_product_cumulative * schedule.fda_nitrogen_fraction_gN_per_g,
        fda_nitrogen_rate_gN_L_h =
            fda_product_rate * schedule.fda_nitrogen_fraction_gN_per_g,
        organic_product_cumulative_g_L = organic_product_cumulative,
        organic_product_rate_g_L_h = organic_product_rate,
        organic_nitrogen_cumulative_gN_L =
            organic_product_cumulative * schedule.organic_composition.nitrogen_fraction_gN_per_g,
        organic_nitrogen_rate_gN_L_h =
            organic_product_rate * schedule.organic_composition.nitrogen_fraction_gN_per_g,
    )
end

function sample_dynamic_control_schedule(
    schedule::DynamicControlSchedule;
    start_h::Real = 0.0,
    stop_h::Real = 168.0,
    dt_h::Real = 0.25,
)::Vector
    start_time = Float64(start_h)
    stop_time = Float64(stop_h)
    dt = Float64(dt_h)
    isfinite(start_time) && isfinite(stop_time) && stop_time >= start_time ||
        throw(ArgumentError("Schedule sample interval requires finite stop_h >= start_h."))
    isfinite(dt) && dt > 0.0 || throw(ArgumentError("Schedule sample dt_h must be positive."))

    count = floor(Int, (stop_time - start_time) / dt)
    times = [start_time + index * dt for index in 0:count]
    if isempty(times) || times[end] < stop_time - 1.0e-10
        push!(times, stop_time)
    end
    return [dynamic_control_values(schedule, time) for time in times]
end

function dynamic_control_rhs_rates(
    schedule::DynamicControlSchedule,
    t::Real,
    y::AbstractVector;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sugar_consumption_rate_g_L_h::Real = 0.0,
)::NamedTuple
    length(y) == 19 || throw(ArgumentError("Expected 19-state vector, got $(length(y))."))
    values = dynamic_control_values(schedule, t)
    amino_acid_nitrogen_rates =
        values.organic_nitrogen_rate_gN_L_h .*
        schedule.organic_composition.amino_acid_nitrogen_fractions
    amino_acid_state_rates = amino_acid_nitrogen_rates ./ params.MW_N
    aroma_loss_rates = volatilization_aroma_loss_rates(
        schedule.volatilization_model,
        view(y, 14:19);
        temperature_C = values.temperature_C,
        sugar_consumption_rate_g_L_h = sugar_consumption_rate_g_L_h,
    )
    return (
        free_nitrogen_rate_gN_L_h = values.fda_nitrogen_rate_gN_L_h,
        organic_nitrogen_rate_gN_L_h = values.organic_nitrogen_rate_gN_L_h,
        amino_acid_nitrogen_rates_gN_L_h = amino_acid_nitrogen_rates,
        amino_acid_state_rates_per_h = amino_acid_state_rates,
        aroma_loss_rates_g_L_h = aroma_loss_rates,
    )
end

function apply_dynamic_control_rhs_rates!(
    du::AbstractVector,
    y::AbstractVector,
    schedule::DynamicControlSchedule,
    t::Real;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
)::NamedTuple
    length(du) == 19 || throw(ArgumentError("Expected 19-state derivative vector, got $(length(du))."))
    sugar_consumption_rate =
        max(0.0, -Float64(du[3])) + max(0.0, -Float64(du[4]))
    rates = dynamic_control_rhs_rates(
        schedule,
        t,
        y;
        params = params,
        sugar_consumption_rate_g_L_h = sugar_consumption_rate,
    )
    du[2] += rates.free_nitrogen_rate_gN_L_h
    du[9:13] .+= rates.amino_acid_state_rates_per_h
    du[14:19] .-= rates.aroma_loss_rates_g_L_h
    return rates
end

function dynamic_nutrient_addition_delta(
    schedule::DynamicControlSchedule,
    t0::Real,
    t1::Real;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
)::NamedTuple
    Float64(t1) >= Float64(t0) || throw(ArgumentError("Nutrient addition interval requires t1 >= t0."))
    fda_product_delta =
        _smooth_events_cumulative(schedule.fda_events, t1) -
        _smooth_events_cumulative(schedule.fda_events, t0)
    organic_product_delta =
        _smooth_events_cumulative(schedule.organic_events, t1) -
        _smooth_events_cumulative(schedule.organic_events, t0)
    fda_nitrogen_delta = fda_product_delta * schedule.fda_nitrogen_fraction_gN_per_g
    organic_nitrogen_delta =
        organic_product_delta * schedule.organic_composition.nitrogen_fraction_gN_per_g
    amino_acid_nitrogen_delta =
        organic_nitrogen_delta .* schedule.organic_composition.amino_acid_nitrogen_fractions
    amino_acid_state_delta = amino_acid_nitrogen_delta ./ params.MW_N
    return (
        fda_product_delta_g_L = fda_product_delta,
        organic_product_delta_g_L = organic_product_delta,
        free_nitrogen_delta_gN_L = fda_nitrogen_delta,
        organic_nitrogen_delta_gN_L = organic_nitrogen_delta,
        amino_acid_nitrogen_delta_gN_L = amino_acid_nitrogen_delta,
        amino_acid_state_delta = amino_acid_state_delta,
    )
end

function apply_dynamic_nutrient_addition(
    y::AbstractVector,
    schedule::DynamicControlSchedule,
    t0::Real,
    t1::Real;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
)::Vector{Float64}
    length(y) == 19 || throw(ArgumentError("Expected 19-state vector, got $(length(y))."))
    updated = Float64.(copy(y))
    delta = dynamic_nutrient_addition_delta(schedule, t0, t1; params = params)
    updated[2] += delta.free_nitrogen_delta_gN_L
    updated[9:13] .+= delta.amino_acid_state_delta
    return updated
end

function dynamic_control_penalty(
    schedule::DynamicControlSchedule;
    fda_weight::Real = 1.0,
    organic_weight::Real = 1.0,
    temperature_smoothness_weight::Real = 0.0,
)::Float64
    fda_total = sum((event.total_product_g_L for event in schedule.fda_events); init = 0.0)
    organic_total = sum((event.total_product_g_L for event in schedule.organic_events); init = 0.0)
    temperature_jumps = diff(schedule.temperature_values_C)
    return Float64(fda_weight) * fda_total +
        Float64(organic_weight) * organic_total +
        Float64(temperature_smoothness_weight) * sum(abs2, temperature_jumps)
end

function volatilization_aroma_loss_rates(
    ::NoVolatilizationModel,
    aroma_concentrations::AbstractVector;
    kwargs...,
)::Vector{Float64}
    length(aroma_concentrations) == 6 || throw(
        ArgumentError("Volatilization loss rates require six aroma concentrations."),
    )
    return zeros(6)
end

function volatilization_aroma_loss_rates(
    model::VaporLiquidVolatilizationModel,
    aroma_concentrations::AbstractVector;
    temperature_C::Real = model.temperature_reference_C,
    sugar_consumption_rate_g_L_h::Real = 0.0,
)::Vector{Float64}
    length(aroma_concentrations) == 6 || throw(
        ArgumentError("Volatilization loss rates require six aroma concentrations."),
    )
    aromas = max.(0.0, Float64.(aroma_concentrations))
    temperature = Float64(temperature_C)
    isfinite(temperature) || throw(ArgumentError("Volatilization temperature must be finite."))
    sugar_rate = Float64(sugar_consumption_rate_g_L_h)
    isfinite(sugar_rate) && sugar_rate >= 0.0 || throw(
        ArgumentError("Sugar-consumption stripping rate must be finite and nonnegative."),
    )
    temperature_factor =
        model.temperature_q10^((temperature - model.temperature_reference_C) / 10.0)
    sugar_factor = 1.0 + model.sugar_stripping_multiplier_per_g_L_h * sugar_rate
    return model.gas_exchange_rate_h_inv .*
           model.aroma_partition_coefficients .*
           aromas .*
           temperature_factor .*
           sugar_factor
end

function _default_transition_times(horizon_h::Real, control_interval_h::Real)::Vector{Float64}
    horizon = Float64(horizon_h)
    interval = Float64(control_interval_h)
    isfinite(horizon) && horizon > 0.0 || throw(ArgumentError("Horizon must be positive."))
    isfinite(interval) && interval > 0.0 || throw(ArgumentError("Control interval must be positive."))
    transition_count = max(0, ceil(Int, horizon / interval) - 1)
    return [interval * index for index in 1:transition_count]
end

function _default_addition_times(horizon_h::Real, control_interval_h::Real)::Vector{Float64}
    transition_times = _default_transition_times(horizon_h, control_interval_h)
    return transition_times
end

"""
    reference_dynamic_control_schedule(; kwargs...)

Build a smooth 12 h-grid control schedule for development. The default schedule
is a flat 20 C profile with zero nutrient additions, an OIV-equivalent FDA
limit expressed as `3.0 g/L` of 10% FDA solution, and configurable organic
nutrient composition.
"""
function reference_dynamic_control_schedule(;
    horizon_h::Real = 168.0,
    control_interval_h::Real = 12.0,
    temperature_values_C = nothing,
    temperature_transition_width_h::Real = 1.0,
    temperature_min_C::Real = 15.0,
    temperature_max_C::Real = 25.0,
    fda_doses_g_L = nothing,
    organic_doses_g_L = nothing,
    addition_times_h = nothing,
    addition_transition_width_h::Real = 0.5,
    fda_nitrogen_fraction_gN_per_g::Real = FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G,
    fda_total_limit_g_L::Real = FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L,
    organic_total_limit_g_L::Real = Inf,
    organic_composition::OrganicNutrientComposition = springferm_xtrem_organic_composition(),
    volatilization_model::AbstractVolatilizationModel = NoVolatilizationModel(),
)::DynamicControlSchedule
    transition_times = _default_transition_times(horizon_h, control_interval_h)
    values = temperature_values_C === nothing ?
        fill(20.0, length(transition_times) + 1) :
        Float64.(temperature_values_C)
    addition_times = addition_times_h === nothing ?
        _default_addition_times(horizon_h, control_interval_h) :
        Float64.(addition_times_h)
    fda_doses = fda_doses_g_L === nothing ? zeros(length(addition_times)) : Float64.(fda_doses_g_L)
    organic_doses =
        organic_doses_g_L === nothing ? zeros(length(addition_times)) : Float64.(organic_doses_g_L)
    length(fda_doses) == length(addition_times) || throw(
        ArgumentError("FDA dose vector length must match addition time vector length."),
    )
    length(organic_doses) == length(addition_times) || throw(
        ArgumentError("Organic dose vector length must match addition time vector length."),
    )
    fda_events = [
        SmoothDoseEvent(time, dose, addition_transition_width_h) for
        (time, dose) in zip(addition_times, fda_doses) if dose > 0.0
    ]
    organic_events = [
        SmoothDoseEvent(time, dose, addition_transition_width_h) for
        (time, dose) in zip(addition_times, organic_doses) if dose > 0.0
    ]
    return DynamicControlSchedule(
        temperature_transition_times_h = transition_times,
        temperature_values_C = values,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        fda_events = fda_events,
        organic_events = organic_events,
        fda_nitrogen_fraction_gN_per_g = fda_nitrogen_fraction_gN_per_g,
        fda_total_limit_g_L = fda_total_limit_g_L,
        organic_total_limit_g_L = organic_total_limit_g_L,
        organic_composition = organic_composition,
        volatilization_model = volatilization_model,
        metadata = Dict{String, Any}(
            "schedule_type" => "reference_dynamic_control_schedule",
            "horizon_h" => Float64(horizon_h),
            "control_interval_h" => Float64(control_interval_h),
            "temperature_profile" => "smooth_piecewise_logistic",
            "addition_profile" => "smooth_pump_logistic_cumulative",
            "fda_limit_basis" => "OIV_DAP_MAX_G_L converted to 10% FDA solution g/L",
            "fda_product_basis" => "FDA solution 10% w/w",
        ),
    )
end

function _dynamic_control_schedule_horizon(
    schedule::DynamicControlSchedule,
    fallback::Real,
)::Float64
    value = get(schedule.metadata, "horizon_h", fallback)
    horizon = Float64(value)
    isfinite(horizon) && horizon > 0.0 ||
        throw(ArgumentError("Dynamic-control decision horizon must be finite and positive."))
    return horizon
end

function _dynamic_control_schedule_interval(
    schedule::DynamicControlSchedule,
    fallback::Real,
)::Float64
    value = get(schedule.metadata, "control_interval_h", fallback)
    interval = Float64(value)
    isfinite(interval) && interval > 0.0 ||
        throw(ArgumentError("Dynamic-control decision interval must be finite and positive."))
    return interval
end

function _dynamic_control_slot_mask(
    count::Int,
    indices;
    default_all::Bool,
    label::AbstractString,
)::Vector{Bool}
    count >= 0 || throw(ArgumentError("$label slot count must be nonnegative."))
    if indices === nothing
        return fill(default_all, count)
    end
    mask = falses(count)
    for index in indices
        converted = Int(index)
        1 <= converted <= count || throw(
            ArgumentError("$label free index $converted is outside 1:$count."),
        )
        mask[converted] = true
    end
    return mask
end

function _dynamic_control_dose_vector_from_events(
    events::Vector{SmoothDoseEvent},
    addition_times_h::AbstractVector{<:Real};
    tolerance::Real = 1.0e-8,
)::Vector{Float64}
    times = Float64.(addition_times_h)
    doses = zeros(Float64, length(times))
    tol = Float64(tolerance)
    for event in events
        distances = abs.(times .- event.center_time_h)
        isempty(distances) && throw(
            ArgumentError(
                "Cannot map nutrient event at $(event.center_time_h) h because the decision spec has no addition slots.",
            ),
        )
        index = argmin(distances)
        distances[index] <= tol || throw(
            ArgumentError(
                "Nutrient event at $(event.center_time_h) h does not match a decision addition slot.",
            ),
        )
        doses[index] += event.total_product_g_L
    end
    return doses
end

function _dynamic_control_trust_bounds(
    starts::AbstractVector{<:Real},
    free::AbstractVector{Bool},
    trust_radius::Real,
    global_lower::Real,
    global_upper::Real,
    label::AbstractString,
)::Tuple{Vector{Float64}, Vector{Float64}}
    values = Float64.(starts)
    length(values) == length(free) ||
        throw(ArgumentError("$label start/free lengths do not match."))
    trust = Float64(trust_radius)
    isfinite(trust) && trust >= 0.0 ||
        throw(ArgumentError("$label trust region must be finite and nonnegative."))
    lower_limit = Float64(global_lower)
    upper_limit = Float64(global_upper)
    ((isfinite(lower_limit) || isinf(lower_limit)) &&
     (isfinite(upper_limit) || isinf(upper_limit)) &&
     lower_limit <= upper_limit) ||
        throw(ArgumentError("$label global bounds must satisfy lower <= upper."))
    lower = similar(values)
    upper = similar(values)
    for index in eachindex(values)
        value = values[index]
        isfinite(value) || throw(ArgumentError("$label start values must be finite."))
        if free[index]
            lower[index] = max(lower_limit, value - trust)
            upper[index] = min(upper_limit, value + trust)
        else
            lower[index] = value
            upper[index] = value
        end
        lower[index] <= value <= upper[index] || throw(
            ArgumentError("$label start value at slot $index is outside its trust bounds."),
        )
    end
    return lower, upper
end

"""
    dynamic_control_decision_spec(schedule; kwargs...)

Build a trust-region control-decision scaffold from a fixed
`DynamicControlSchedule`. Temperature values and FDA/organic dose slots keep the
fixed schedule as starts; selected slots can be marked free through 1-based
`temperature_free_indices` and `addition_free_indices`.
"""
function dynamic_control_decision_spec(
    schedule::DynamicControlSchedule;
    horizon_h = get(schedule.metadata, "horizon_h", 168.0),
    control_interval_h = get(schedule.metadata, "control_interval_h", 12.0),
    temperature_free_indices = nothing,
    addition_free_indices = nothing,
    temperature_trust_region_C::Real = 0.5,
    fda_trust_region_g_L::Real = 0.25,
    organic_trust_region_g_L::Real = 0.05,
    metadata::AbstractDict = Dict{String, Any}(),
)::DynamicControlDecisionSpec
    horizon = _dynamic_control_schedule_horizon(schedule, horizon_h)
    interval = _dynamic_control_schedule_interval(schedule, control_interval_h)
    transition_times = _default_transition_times(horizon, interval)
    addition_times = _default_addition_times(horizon, interval)
    length(schedule.temperature_values_C) == length(transition_times) + 1 || throw(
        ArgumentError(
            "Schedule temperature value count does not match decision horizon/interval.",
        ),
    )
    isapprox(
        schedule.temperature_transition_times_h,
        transition_times;
        atol = 1.0e-8,
        rtol = 1.0e-10,
    ) || throw(
        ArgumentError("Schedule temperature transition times do not match decision slots."),
    )

    temperature_free = _dynamic_control_slot_mask(
        length(schedule.temperature_values_C),
        temperature_free_indices;
        default_all = true,
        label = "temperature",
    )
    addition_free = _dynamic_control_slot_mask(
        length(addition_times),
        addition_free_indices;
        default_all = true,
        label = "nutrient addition",
    )
    temperature_lower, temperature_upper = _dynamic_control_trust_bounds(
        schedule.temperature_values_C,
        temperature_free,
        temperature_trust_region_C,
        schedule.temperature_min_C,
        schedule.temperature_max_C,
        "temperature",
    )
    fda_start = _dynamic_control_dose_vector_from_events(schedule.fda_events, addition_times)
    organic_start =
        _dynamic_control_dose_vector_from_events(schedule.organic_events, addition_times)
    fda_lower, fda_upper = _dynamic_control_trust_bounds(
        fda_start,
        addition_free,
        fda_trust_region_g_L,
        0.0,
        schedule.fda_total_limit_g_L,
        "FDA dose",
    )
    organic_lower, organic_upper = _dynamic_control_trust_bounds(
        organic_start,
        addition_free,
        organic_trust_region_g_L,
        0.0,
        schedule.organic_total_limit_g_L,
        "organic dose",
    )
    meta = Dict{String, Any}(String(key) => value for (key, value) in metadata)
    meta["control_liberation_policy"] = get(
        meta,
        "control_liberation_policy",
        "trust_region_slots_from_fixed_dynamic_control_schedule",
    )
    meta["fully_simultaneous_controls"] = get(meta, "fully_simultaneous_controls", false)
    meta["mpcc_embedding_ready"] = get(meta, "mpcc_embedding_ready", false)
    events = vcat(schedule.fda_events, schedule.organic_events)
    addition_width = isempty(events) ? 0.5 : minimum(event.transition_width_h for event in events)
    return DynamicControlDecisionSpec(
        horizon,
        interval,
        schedule.temperature_transition_width_h,
        addition_width,
        schedule.temperature_min_C,
        schedule.temperature_max_C,
        transition_times,
        addition_times,
        copy(schedule.temperature_values_C),
        temperature_lower,
        temperature_upper,
        temperature_free,
        Float64(temperature_trust_region_C),
        fda_start,
        fda_lower,
        fda_upper,
        copy(addition_free),
        Float64(fda_trust_region_g_L),
        schedule.fda_nitrogen_fraction_gN_per_g,
        schedule.fda_total_limit_g_L,
        organic_start,
        organic_lower,
        organic_upper,
        copy(addition_free),
        Float64(organic_trust_region_g_L),
        schedule.organic_total_limit_g_L,
        schedule.organic_composition,
        schedule.volatilization_model,
        meta,
    )
end

function _dynamic_control_check_values_within_bounds(
    values::AbstractVector{<:Real},
    lower::AbstractVector{<:Real},
    upper::AbstractVector{<:Real},
    label::AbstractString,
)::Vector{Float64}
    converted = Float64.(values)
    length(converted) == length(lower) == length(upper) || throw(
        ArgumentError("$label value and bound lengths do not match."),
    )
    for index in eachindex(converted)
        value = converted[index]
        isfinite(value) || throw(ArgumentError("$label value at slot $index is not finite."))
        lower[index] - 1.0e-12 <= value <= upper[index] + 1.0e-12 || throw(
            ArgumentError(
                "$label value at slot $index=$value is outside [$(lower[index]), $(upper[index])].",
            ),
        )
    end
    return converted
end

"""
    dynamic_control_schedule_from_decision_spec(spec; kwargs...)

Reconstruct a smooth `DynamicControlSchedule` from candidate decision values.
By default this returns the fixed start schedule encoded in `spec`.
"""
function dynamic_control_schedule_from_decision_spec(
    spec::DynamicControlDecisionSpec;
    temperature_values_C = spec.temperature_start_C,
    fda_doses_g_L = spec.fda_start_g_L,
    organic_doses_g_L = spec.organic_start_g_L,
)::DynamicControlSchedule
    temperatures = _dynamic_control_check_values_within_bounds(
        temperature_values_C,
        spec.temperature_lower_C,
        spec.temperature_upper_C,
        "temperature",
    )
    fda = _dynamic_control_check_values_within_bounds(
        fda_doses_g_L,
        spec.fda_lower_g_L,
        spec.fda_upper_g_L,
        "FDA dose",
    )
    organic = _dynamic_control_check_values_within_bounds(
        organic_doses_g_L,
        spec.organic_lower_g_L,
        spec.organic_upper_g_L,
        "organic dose",
    )
    sum(fda) <= spec.fda_total_limit_g_L + 1.0e-12 || throw(
        ArgumentError("FDA dose vector exceeds total limit $(spec.fda_total_limit_g_L)."),
    )
    sum(organic) <= spec.organic_total_limit_g_L + 1.0e-12 || throw(
        ArgumentError(
            "Organic dose vector exceeds total limit $(spec.organic_total_limit_g_L).",
        ),
    )
    return reference_dynamic_control_schedule(
        horizon_h = spec.horizon_h,
        control_interval_h = spec.control_interval_h,
        temperature_values_C = temperatures,
        temperature_transition_width_h = spec.temperature_transition_width_h,
        temperature_min_C = spec.temperature_min_C,
        temperature_max_C = spec.temperature_max_C,
        fda_doses_g_L = fda,
        organic_doses_g_L = organic,
        addition_times_h = spec.addition_times_h,
        addition_transition_width_h = spec.addition_transition_width_h,
        fda_nitrogen_fraction_gN_per_g = spec.fda_nitrogen_fraction_gN_per_g,
        fda_total_limit_g_L = spec.fda_total_limit_g_L,
        organic_total_limit_g_L = spec.organic_total_limit_g_L,
        organic_composition = spec.organic_composition,
        volatilization_model = spec.volatilization_model,
    )
end

function dynamic_control_decision_table(spec::DynamicControlDecisionSpec)::DataFrame
    rows = Vector{NamedTuple}()
    temperature_times = vcat(0.0, spec.temperature_transition_times_h)
    for index in eachindex(spec.temperature_start_C)
        push!(
            rows,
            (
                variable_name = "temperature_C[$index]",
                family = "temperature",
                slot_index = index,
                time_h = temperature_times[index],
                start_value = spec.temperature_start_C[index],
                lower_bound = spec.temperature_lower_C[index],
                upper_bound = spec.temperature_upper_C[index],
                free = spec.temperature_free[index],
                trust_region = spec.temperature_trust_region_C,
                unit = "degC",
            ),
        )
    end
    for index in eachindex(spec.fda_start_g_L)
        push!(
            rows,
            (
                variable_name = "fda_g_L[$index]",
                family = "fda",
                slot_index = index,
                time_h = spec.addition_times_h[index],
                start_value = spec.fda_start_g_L[index],
                lower_bound = spec.fda_lower_g_L[index],
                upper_bound = spec.fda_upper_g_L[index],
                free = spec.fda_free[index],
                trust_region = spec.fda_trust_region_g_L,
                unit = "g_product_per_L",
            ),
        )
        push!(
            rows,
            (
                variable_name = "organic_g_L[$index]",
                family = "organic",
                slot_index = index,
                time_h = spec.addition_times_h[index],
                start_value = spec.organic_start_g_L[index],
                lower_bound = spec.organic_lower_g_L[index],
                upper_bound = spec.organic_upper_g_L[index],
                free = spec.organic_free[index],
                trust_region = spec.organic_trust_region_g_L,
                unit = "g_product_per_L",
            ),
        )
    end
    return DataFrame(rows)
end
