import HiGHS
import MathOptInterface as MOI

"""
    DFBARHSResult

Result container for a single sequential DFBA right-hand-side
evaluation. This is not an ODE integration result.
"""
struct DFBARHSResult
    dy::Vector{Float64}
    state::ZentenoState
    bounds::ZentenoDynamicBounds
    fba::FBAResult
    fluxes_by_rxn::Dict{String, Float64}
    mode::Symbol
    metadata::Dict{String, Any}
end

"""
    DFBAContext

Typed configuration for ODE-compatible sequential DFBA RHS calls.
Only `nonoptimal_policy = :error` is supported in this commit because
`compute_dfba_rhs` throws on non-optimal FBA solves.
`lp_reuse=true` enables an opt-in persistent JuMP/HiGHS LP cache for reduced
DFBA RHS calls; `lp_primal_start=true` additionally applies the previous flux
solution as a primal start when available. `lp_basis_warm_start=true` applies
the previous HiGHS simplex basis before the next persistent LP solve.
`dynamic_control_schedule` optionally supplies smooth temperature, nutrient,
and volatilization controls for each RHS time.
"""
struct DFBAContext
    model::MetabolicModel
    reaction_map::ReactionMap
    params::ZentenoKineticParameters
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule}
    optimizer::Any
    silent::Bool
    atol::Float64
    nonoptimal_policy::Symbol
    lp_reuse::Bool
    lp_primal_start::Bool
    lp_basis_warm_start::Bool
    lp_simplex_strategy::String
    fba_variant::String
    quadratic_penalty::Float64
    l1_penalty::Float64
    lp_cache::Any
    lp_reuse_build_elapsed_seconds::Float64
    lp_reuse_update_elapsed_seconds::Base.RefValue{Float64}
    lp_reuse_solve_elapsed_seconds::Base.RefValue{Float64}
    lp_reuse_warm_start_applied_count::Base.RefValue{Int}
    lp_reuse_basis_warm_start_applied_count::Base.RefValue{Int}
    lp_reuse_basis_warm_start_failed_count::Base.RefValue{Int}
    lp_reuse_basis_capture_count::Base.RefValue{Int}
    lp_reuse_simplex_iterations::Base.RefValue{Int}
end

function DFBAContext(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    dynamic_control_schedule = nothing,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1.0e-8,
    nonoptimal_policy::Symbol = :error,
    lp_reuse::Bool = false,
    lp_primal_start::Bool = false,
    lp_reuse_highs_solver::AbstractString = "simplex",
    lp_basis_warm_start::Bool = false,
    lp_simplex_strategy::AbstractString = "default",
    fba_variant::AbstractString = "fba",
    quadratic_penalty::Real = 0.0,
    l1_penalty::Real = 0.0,
)
    converted_atol = Float64(atol)
    isfinite(converted_atol) && converted_atol > 0.0 ||
        error("DFBAContext atol must be finite and positive, got $atol.")
    nonoptimal_policy == :error || error(
        "Unsupported DFBAContext nonoptimal_policy: $nonoptimal_policy. Only :error is supported.",
    )
    lp_reuse || !lp_primal_start || error("DFBAContext lp_primal_start=true requires lp_reuse=true.")
    lp_reuse || !lp_basis_warm_start || error("DFBAContext lp_basis_warm_start=true requires lp_reuse=true.")
    normalized_dynamic_control_schedule = _normalize_dfba_dynamic_control_schedule(dynamic_control_schedule)
    normalized_fba_variant = _normalize_dfba_fba_variant(fba_variant)
    qp_penalty = normalized_fba_variant == "qpfba" ?
        _validate_qp_regularized_fba_penalty(quadratic_penalty) :
        0.0
    l1_regularization_penalty = normalized_fba_variant == "l1pfba" ?
        _validate_l1_regularized_fba_penalty(l1_penalty) :
        0.0
    normalized_fba_variant == "qpfba" && lp_basis_warm_start && error(
        "DFBAContext lp_basis_warm_start=true is not supported for qpfba.",
    )

    effective_simplex_strategy = lp_basis_warm_start ?
        _reduced_dfba_lp_effective_basis_simplex_strategy(lp_simplex_strategy) :
        _reduced_dfba_warm_start_simplex_strategy_label(lp_simplex_strategy)
    base_optimizer = normalized_fba_variant == "qpfba" ? _qp_regularized_fba_optimizer(optimizer) : optimizer
    effective_lp_reuse_highs_solver = normalized_fba_variant == "qpfba" ? "default" : lp_reuse_highs_solver
    lp_optimizer = lp_reuse ?
        _reduced_dfba_warm_start_optimizer(
            base_optimizer,
            effective_lp_reuse_highs_solver;
            highs_simplex_strategy = effective_simplex_strategy,
        ) :
        base_optimizer
    lp_cache = lp_reuse ?
        _build_reusable_reduced_dfba_lp(
            model,
            reaction_map;
            optimizer = lp_optimizer,
            silent = silent,
            basis_warm_start = lp_basis_warm_start,
            fba_variant = normalized_fba_variant,
            quadratic_penalty = qp_penalty,
            l1_penalty = l1_regularization_penalty,
        ) :
        nothing
    lp_reuse_build_elapsed_seconds = lp_cache === nothing ? 0.0 : lp_cache.build_elapsed_seconds

    return DFBAContext(
        model,
        reaction_map,
        params,
        normalized_dynamic_control_schedule,
        lp_optimizer,
        silent,
        converted_atol,
        nonoptimal_policy,
        lp_reuse,
        lp_primal_start,
        lp_basis_warm_start,
        effective_simplex_strategy,
        normalized_fba_variant,
        qp_penalty,
        l1_regularization_penalty,
        lp_cache,
        lp_reuse_build_elapsed_seconds,
        Ref(0.0),
        Ref(0.0),
        Ref(0),
        Ref(0),
        Ref(0),
        Ref(0),
        Ref(0),
    )
end

function _normalize_dfba_dynamic_control_schedule(dynamic_control_schedule)::Union{Nothing, DynamicControlSchedule}
    dynamic_control_schedule === nothing && return nothing
    dynamic_control_schedule isa DynamicControlSchedule || error(
        "dynamic_control_schedule must be nothing or a DynamicControlSchedule.",
    )
    return dynamic_control_schedule
end

function _dfba_effective_params(
    params::ZentenoKineticParameters,
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule},
    t,
)::ZentenoKineticParameters
    dynamic_control_schedule === nothing && return params
    return dynamic_zenteno_parameters(dynamic_control_schedule, t; base_params = params)
end

function _dfba_context_params_at_time(context::DFBAContext, t)::ZentenoKineticParameters
    return _dfba_effective_params(context.params, context.dynamic_control_schedule, t)
end

function _reduced_dfba_lp_effective_basis_simplex_strategy(lp_simplex_strategy::AbstractString)::String
    normalized = _reduced_dfba_warm_start_simplex_strategy_label(lp_simplex_strategy)
    return normalized == "default" ? "primal" : normalized
end

function _normalize_dfba_fba_variant(fba_variant::AbstractString)::String
    normalized = lowercase(strip(String(fba_variant)))
    normalized in ("", "fba", "lp") && return "fba"
    normalized in ("qpfba", "qp_fba", "qp_regularized_fba", "quadratic_regularized_fba") && return "qpfba"
    normalized in ("l1pfba", "l1_pfba", "l1_regularized_fba", "linear_regularized_fba") && return "l1pfba"
    error("Unsupported DFBA FBA variant: $fba_variant. Use fba, qpfba, or l1pfba.")
end

"""
    compute_dfba_rhs(model, reaction_map, y; params=default_zenteno_parameters(), optimizer=HiGHS.Optimizer, silent=true, atol=1e-8)

Compute one sequential DFBA right-hand-side evaluation for a 19-state
Zenteno fermentation vector. Dynamic bounds and weighted FBA objectives are
computed from the supplied state, then a single LP is solved. This function
does not integrate the ODE system.
"""
function compute_dfba_rhs(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    y::AbstractVector;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1.0e-8,
    fba_variant::AbstractString = "fba",
    quadratic_penalty::Real = 0.0,
    l1_penalty::Real = 0.0,
)::DFBARHSResult
    state = zenteno_state_from_vector(y)
    _assert_dfba_oxygen_not_r0001(reaction_map)
    bounds = zenteno_dynamic_bounds(model, reaction_map, state, params)
    updated_model = apply_dynamic_bounds(model, bounds)
    normalized_fba_variant = _normalize_dfba_fba_variant(fba_variant)
    fba = if normalized_fba_variant == "qpfba"
        solve_qp_regularized_fba(
            updated_model;
            objective_weights = bounds.objective_weights,
            quadratic_penalty = quadratic_penalty,
            optimizer = optimizer,
            silent = silent,
            atol = atol,
        )
    elseif normalized_fba_variant == "l1pfba"
        solve_l1_regularized_fba(
            updated_model;
            objective_weights = bounds.objective_weights,
            l1_penalty = l1_penalty,
            optimizer = optimizer,
            silent = silent,
            atol = atol,
        )
    else
        solve_fba(
            updated_model;
            objective_weights = bounds.objective_weights,
            optimizer = optimizer,
            silent = silent,
            atol = atol,
        )
    end

    _assert_dfba_fba_optimal(fba)
    return _dfba_rhs_result_from_fba(updated_model, reaction_map, state, bounds, fba, params)
end

function _assert_dfba_fba_optimal(fba::FBAResult)
    fba.status == MOI.OPTIMAL && return nothing
    _dfba_accept_qpfba_near_optimal(fba) && return nothing

    primal_status = get(fba.metadata, "primal_status", "unknown")
    dual_status = get(fba.metadata, "dual_status", "unknown")
    error(
        "Sequential DFBA RHS FBA solve did not terminate as optimal. " *
        "Status: $(fba.status), primal_status: $primal_status, dual_status: $dual_status, " *
        "mass_balance_residual: $(fba.mass_balance_residual), " *
        "max_lower_bound_violation: $(fba.max_lower_bound_violation), " *
        "max_upper_bound_violation: $(fba.max_upper_bound_violation).",
    )
end

function _dfba_accept_qpfba_near_optimal(fba::FBAResult)::Bool
    get(fba.metadata, "fba_variant", "fba") == "qpfba" || return false
    fba.status == MOI.OTHER_ERROR || return false
    primal_status = get(fba.metadata, "primal_status", nothing)
    dual_status = get(fba.metadata, "dual_status", nothing)
    primal_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT) || return false
    dual_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT) || return false
    return fba.mass_balance_residual <= 1.0e-4 &&
        fba.max_lower_bound_violation <= 1.0e-4 &&
        fba.max_upper_bound_violation <= 1.0e-4
end

function _dfba_rhs_status_string(fba::FBAResult)::String
    if _dfba_accept_qpfba_near_optimal(fba)
        return "$(fba.status)_accepted_qpfba_near_optimal"
    else
        return string(fba.status)
    end
end

function _dfba_rhs_result_from_fba(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    state::ZentenoState,
    bounds::ZentenoDynamicBounds,
    fba::FBAResult,
    params::ZentenoKineticParameters,
)::DFBARHSResult
    biomass_id = _dfba_required_core_reaction_id(reaction_map, "biomass_growth")
    glucose_id = _dfba_required_core_reaction_id(reaction_map, "glucose_exchange")
    fructose_id = _dfba_required_core_reaction_id(reaction_map, "fructose_exchange")
    ethanol_id = _dfba_required_core_reaction_id(reaction_map, "ethanol_exchange")
    atp_id = _dfba_required_core_reaction_id(reaction_map, "atp_maintenance")
    protein_id = _dfba_required_core_reaction_id(reaction_map, "protein_exchange")
    carbohydrate_id = _dfba_required_core_reaction_id(reaction_map, "carbohydrate_exchange")
    amino_acid_ids = [
        _dfba_required_group_role_id(reaction_map.amino_acids, role, "amino_acids") for
        role in ZENTENO_AMINO_ACID_ROLES
    ]
    aroma_ids = [
        _dfba_required_group_role_id(reaction_map.aromas, role, "aromas") for
        role in ZENTENO_AROMA_ROLES
    ]
    nitrogen_ids = String.(params.nitrogen_source_ids)

    rhs_reaction_ids = _dfba_rhs_reaction_ids(
        [
            biomass_id,
            glucose_id,
            fructose_id,
            ethanol_id,
            atp_id,
            protein_id,
            carbohydrate_id,
        ],
        nitrogen_ids,
        amino_acid_ids,
        aroma_ids,
        collect(keys(bounds.objective_weights)),
    )
    fluxes_by_rxn = _collect_fluxes_by_rxn(model, fba, rhs_reaction_ids)

    flux(rxn_id) = fluxes_by_rxn[rxn_id]

    v_obj = flux(biomass_id)
    v_glu = flux(glucose_id)
    v_fru = flux(fructose_id)
    v_eth = flux(ethanol_id)
    v_prot = flux(protein_id)
    vn_eff = [flux(rxn_id) for rxn_id in nitrogen_ids]
    v_aa = [flux(rxn_id) for rxn_id in amino_acid_ids]
    v_aromas = [flux(rxn_id) for rxn_id in aroma_ids]

    cX = state.biomass
    cProt = state.protein
    cCarb = state.carbohydrate
    Xa = params.XA_FRACTION * cX

    dy = zeros(19)
    dy[1] = bounds.mode == :growth ? v_obj * cX : 0.0
    dy[2] = bounds.mode == :growth ?
        sum(vn_eff .* params.nitrogen_atom_counts .* params.MW_N .* cX) :
        0.0
    dy[3] = -params.MW_GLU * max(0.0, -v_glu) * cX
    dy[4] = -params.MW_FRU * max(0.0, -v_fru) * cX
    dy[5] = params.MW_ETH * max(0.0, v_eth) * cX
    dy[6] = 0.0
    dy[7] =
        max(0.0, v_obj) * cX * params.PROT_CONTENT_0 -
        cProt * params.K_DEATH +
        Xa * max(0.0, v_prot) -
        params.TURNOVER_LAMBDA * cProt
    dy[8] = max(0.0, v_obj) * cX * params.CARB_CONTENT_0 - cCarb * params.K_DEATH

    if bounds.mode == :growth
        dy[9:13] .= cX .* v_aa
    else
        dy[9:13] .= 0.0
    end

    dy[14:19] .= params.aroma_molecular_weights .* max.(0.0, v_aromas) .* cX

    oxygen_metadata = _dfba_oxygen_metadata(model)
    metadata = Dict{String, Any}(
        "objective_type" => get(fba.metadata, "objective_type", "unknown"),
        "n_objective_terms" => get(fba.metadata, "n_objective_terms", length(bounds.objective_weights)),
        "fba_variant" => get(fba.metadata, "fba_variant", "fba"),
        "quadratic_penalty" => get(fba.metadata, "quadratic_penalty", 0.0),
        "l1_penalty" => get(fba.metadata, "l1_penalty", 0.0),
        "mass_balance_residual" => fba.mass_balance_residual,
        "max_lower_bound_violation" => fba.max_lower_bound_violation,
        "max_upper_bound_violation" => fba.max_upper_bound_violation,
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "rhs_units_note" => "Mixed units follow the current MATLAB RHS contract.",
        "rhs_temperature_K" => params.temperature_K,
        "rhs_temperature_C" => params.temperature_K - 273.15,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "rhs_reaction_ids" => rhs_reaction_ids,
    )
    merge!(metadata, bounds.metadata)
    merge!(metadata, oxygen_metadata)

    return DFBARHSResult(dy, state, bounds, fba, fluxes_by_rxn, bounds.mode, metadata)
end

"""
    dfba_rhs!(du, u, context, t)

ODE-compatible sequential DFBA right-hand-side wrapper. This performs
one RHS evaluation only; it does not integrate the ODE system.
"""
function dfba_rhs!(
    du::AbstractVector,
    u::AbstractVector,
    context::DFBAContext,
    t,
)
    length(du) == 19 || error("DFBA RHS output vector must have length 19, got $(length(du)).")
    length(u) == 19 || error("DFBA RHS state vector must have length 19, got $(length(u)).")

    effective_params = _dfba_context_params_at_time(context, t)
    result = if context.lp_reuse
        rhs_result, timings = _compute_reusable_reduced_dfba_rhs!(
            context.lp_cache,
            u;
            params = effective_params,
            lp_atol = context.atol,
            primal_start = context.lp_primal_start,
            basis_warm_start = context.lp_basis_warm_start,
        )
        context.lp_reuse_update_elapsed_seconds[] += Float64(timings.update_elapsed_seconds)
        context.lp_reuse_solve_elapsed_seconds[] += Float64(timings.solve_elapsed_seconds)
        if timings.warm_start_applied
            context.lp_reuse_warm_start_applied_count[] += 1
        end
        if timings.basis_warm_start_applied
            context.lp_reuse_basis_warm_start_applied_count[] += 1
        end
        if timings.basis_warm_start_failed
            context.lp_reuse_basis_warm_start_failed_count[] += 1
        end
        if timings.basis_capture_succeeded
            context.lp_reuse_basis_capture_count[] += 1
        end
        simplex_iterations = get(rhs_result.fba.metadata, "simplex_iterations", missing)
        if simplex_iterations isa Real && isfinite(Float64(simplex_iterations))
            context.lp_reuse_simplex_iterations[] += Int(simplex_iterations)
        end
        rhs_result
    else
        compute_dfba_rhs(
            context.model,
            context.reaction_map,
            u;
            params = effective_params,
            optimizer = context.optimizer,
            silent = context.silent,
            atol = context.atol,
            fba_variant = context.fba_variant,
            quadratic_penalty = context.quadratic_penalty,
            l1_penalty = context.l1_penalty,
        )
    end
    du .= result.dy
    if context.dynamic_control_schedule !== nothing
        apply_dynamic_control_rhs_rates!(
            du,
            u,
            context.dynamic_control_schedule,
            t;
            params = effective_params,
        )
    end
    return nothing
end

function _dfba_flux_value(model::MetabolicModel, fba::FBAResult, rxn_id::AbstractString)::Float64
    cleaned_id = strip(String(rxn_id))
    has_reaction(model, cleaned_id) ||
        error("Missing required sequential DFBA RHS reaction ID in model $(model.model_id): $cleaned_id")
    length(fba.fluxes) == length(model.rxn_ids) || error(
        "FBA flux vector length $(length(fba.fluxes)) does not match $(length(model.rxn_ids)) reactions.",
    )
    return fba.fluxes[reaction_index(model, cleaned_id)]
end

function _collect_fluxes_by_rxn(
    model::MetabolicModel,
    fba::FBAResult,
    rxn_ids::AbstractVector{<:AbstractString},
)::Dict{String, Float64}
    fluxes = Dict{String, Float64}()
    for rxn_id in rxn_ids
        cleaned_id = strip(String(rxn_id))
        cleaned_id == "r_1992" && continue
        fluxes[cleaned_id] = _dfba_flux_value(model, fba, cleaned_id)
    end
    return fluxes
end

function _assert_dfba_oxygen_not_r0001(reaction_map::ReactionMap)
    oxygen_id = get(reaction_map.core, "oxygen_exchange", "")
    disabled_oxygen_id = get(reaction_map.disabled_reactions, "oxygen_exchange", "")
    if strip(oxygen_id) == "r_0001" || strip(disabled_oxygen_id) == "r_0001"
        error("Sequential DFBA RHS oxygen_exchange must not map to r_0001.")
    end
    return nothing
end

function _dfba_oxygen_metadata(model::MetabolicModel)::Dict{String, Any}
    oxygen_id = "r_1992"
    if !has_reaction(model, oxygen_id)
        return Dict{String, Any}(
            "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
            "oxygen_exchange_reaction_id" => oxygen_id,
            "oxygen_exchange_present" => false,
            "oxygen_exchange_closed" => missing,
            "oxygen_exchange_lb" => missing,
            "oxygen_exchange_ub" => missing,
        )
    end

    index = reaction_index(model, oxygen_id)
    oxygen_lb = model.lb[index]
    oxygen_ub = model.ub[index]
    oxygen_closed = iszero(oxygen_lb) && iszero(oxygen_ub)
    policy = oxygen_closed ?
        "forced_zero_present_r_1992_closed_by_bounds" :
        "forced_zero_present_r_1992_not_closed_by_bounds"

    return Dict{String, Any}(
        "oxygen_derivative_policy" => policy,
        "oxygen_exchange_reaction_id" => oxygen_id,
        "oxygen_exchange_present" => true,
        "oxygen_exchange_closed" => oxygen_closed,
        "oxygen_exchange_lb" => oxygen_lb,
        "oxygen_exchange_ub" => oxygen_ub,
    )
end

function _dfba_required_core_reaction_id(reaction_map::ReactionMap, role::AbstractString)::String
    return _dfba_required_group_role_id(reaction_map.core, role, "core")
end

function _dfba_required_group_role_id(
    group::Dict{String, String},
    role::AbstractString,
    group_name::AbstractString,
)::String
    role_key = String(role)
    haskey(group, role_key) || error("Missing required $group_name reaction-map role: $role_key")
    rxn_id = strip(group[role_key])
    isempty(rxn_id) && error("Reaction-map role $role_key in $group_name has an empty reaction ID.")
    return rxn_id
end

function _dfba_rhs_reaction_ids(rxn_groups::AbstractVector...)
    rxn_ids = String[]
    for group in rxn_groups
        append!(rxn_ids, String.(group))
    end
    filter!(rxn_id -> strip(rxn_id) != "r_1992", rxn_ids)
    return sort(collect(Set(String.(strip.(rxn_ids)))))
end
