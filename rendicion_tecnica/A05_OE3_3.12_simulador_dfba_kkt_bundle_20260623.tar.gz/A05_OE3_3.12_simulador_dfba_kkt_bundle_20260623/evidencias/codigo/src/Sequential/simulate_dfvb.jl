const DFVB_SIMULATION_BIOLOGICAL_INTERPRETATION_NOTE =
    "Short sequential DFVB ODE smoke only: this integrates the current dFBA RHS formulas using fluxes reconstructed from dynamic DFVB alpha-space LP solves; it is not KKT/MPCC, direct collocation, or MATLAB DFVB trajectory validation."

"""
    simulate_dfvb(model, reaction_map, artifacts; kwargs...)

Run a short sequential DFVB ODE smoke simulation. Each RHS evaluation delegates
to `dfvb_rhs!`, which solves one dynamic DFVB alpha-space LP through
`compute_dfvb_rhs`. Saved-state alpha reconstruction is enabled by default and
stores active-alpha trajectories as `n_alpha x n_time` in
`SimulationResult.alphas`.
"""
function simulate_dfvb(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    artifacts::DFVBArtifacts;
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    tspan::Tuple{Float64, Float64} = (0.0, 0.25),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    use_active_alpha::Bool = true,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    saveat = 0.25,
    algorithm = OrdinaryDiffEq.Tsit5(),
    nonnegative::Bool = true,
    stop_on_sugar_depletion::Bool = true,
    sugar_depletion_tol::Real = 1.0e-6,
    reconstruct_fluxes::Bool = false,
    reconstruct_alphas::Bool = true,
    nonoptimal_policy::Symbol = :error,
)::SimulationResult
    simulation_start_time = Base.time()
    _validate_reduced_dfba_simulation_inputs(
        y0,
        tspan,
        lp_atol,
        ode_abstol,
        ode_reltol,
        sugar_depletion_tol,
        nonnegative,
    )
    solve_dt = _dfba_solve_dt(false, nothing, saveat)

    context = DFVBContext(
        model,
        reaction_map,
        artifacts;
        params = params,
        use_active_alpha = use_active_alpha,
        optimizer = optimizer,
        silent = silent,
        atol = lp_atol,
        nonoptimal_policy = nonoptimal_policy,
    )

    initial_state = Float64.(copy(y0))
    rhs_call_count = Ref(0)
    rhs_elapsed_seconds = Ref(0.0)

    function instrumented_dfvb_rhs!(du, u, context, t)
        rhs_call_count[] += 1
        rhs_elapsed_seconds[] += @elapsed dfvb_rhs!(du, u, context, t)
        return nothing
    end

    if stop_on_sugar_depletion && initial_state[3] + initial_state[4] <= Float64(sugar_depletion_tol)
        time = [tspan[1]]
        states = reshape(initial_state, 19, 1)
        reconstruction = nothing
        history_reconstruction_elapsed_seconds = @elapsed begin
            reconstruction = reconstruct_alphas || reconstruct_fluxes ?
                _reconstruct_dfvb_history(
                    model,
                    reaction_map,
                    artifacts,
                    states;
                    params = params,
                    use_active_alpha = use_active_alpha,
                    optimizer = optimizer,
                    silent = silent,
                    lp_atol = lp_atol,
                    reconstruct_fluxes = reconstruct_fluxes,
                    reconstruct_alphas = reconstruct_alphas,
                    skip_sugar_depleted_states = true,
                    sugar_depletion_tol = sugar_depletion_tol,
                ) :
                _empty_dfvb_history(artifacts; use_active_alpha = use_active_alpha)
        end
        metadata = _build_dfvb_simulation_metadata(
            model,
            artifacts,
            reconstruction,
            states;
            use_active_alpha = use_active_alpha,
            retcode = "NotRun",
            algorithm = algorithm,
            tspan = tspan,
            saveat = saveat,
            adaptive = false,
            dt = solve_dt,
            stop_on_sugar_depletion = stop_on_sugar_depletion,
            sugar_depletion_tol = sugar_depletion_tol,
            nonnegative = nonnegative,
            reconstruct_fluxes = reconstruct_fluxes,
            reconstruct_alphas = reconstruct_alphas,
            termination_reason = "sugar_depletion_at_initial_time",
            termination_time = time[end],
        )
        _add_dfvb_runtime_metadata!(
            metadata;
            simulation_start_time = simulation_start_time,
            ode_solve_elapsed_seconds = 0.0,
            rhs_elapsed_seconds = rhs_elapsed_seconds[],
            rhs_call_count = rhs_call_count[],
            history_reconstruction_elapsed_seconds = history_reconstruction_elapsed_seconds,
            saved_state_reconstruction_solve_count = reconstruction.saved_state_reconstruction_solve_count,
            reconstruct_fluxes = reconstruct_fluxes,
            reconstruct_alphas = reconstruct_alphas,
        )
        return SimulationResult(
            time,
            states;
            fluxes = reconstruction.fluxes,
            alphas = reconstruction.alphas,
            metadata = metadata,
        )
    end

    prob = OrdinaryDiffEq.ODEProblem(instrumented_dfvb_rhs!, initial_state, tspan, context)
    sol = nothing
    ode_solve_elapsed_seconds = @elapsed begin
        sol = _solve_dfba_ode(
            prob,
            algorithm;
            ode_abstol = ode_abstol,
            ode_reltol = ode_reltol,
            saveat = saveat,
            adaptive = false,
            dt = solve_dt,
        )
    end

    time = Float64.(sol.t)
    states = _saved_states_matrix(sol.u)
    termination_reason = "completed_tspan"
    if stop_on_sugar_depletion
        depleted_index = _first_saved_sugar_depletion_index(states, sugar_depletion_tol)
        if depleted_index !== nothing
            time = time[1:depleted_index]
            states = states[:, 1:depleted_index]
            termination_reason = "sugar_depletion_at_saved_time"
        end
    end

    reconstruction = nothing
    history_reconstruction_elapsed_seconds = @elapsed begin
        reconstruction = reconstruct_alphas || reconstruct_fluxes ?
            _reconstruct_dfvb_history(
                model,
                reaction_map,
                artifacts,
                states;
                params = params,
                use_active_alpha = use_active_alpha,
                optimizer = optimizer,
                silent = silent,
                lp_atol = lp_atol,
                reconstruct_fluxes = reconstruct_fluxes,
                reconstruct_alphas = reconstruct_alphas,
                skip_sugar_depleted_states = stop_on_sugar_depletion,
                sugar_depletion_tol = sugar_depletion_tol,
            ) :
            _empty_dfvb_history(artifacts; use_active_alpha = use_active_alpha)
    end
    metadata = _build_dfvb_simulation_metadata(
        model,
        artifacts,
        reconstruction,
        states;
        use_active_alpha = use_active_alpha,
        retcode = string(sol.retcode),
        algorithm = algorithm,
        tspan = tspan,
        saveat = saveat,
        adaptive = false,
        dt = solve_dt,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
        nonnegative = nonnegative,
        reconstruct_fluxes = reconstruct_fluxes,
        reconstruct_alphas = reconstruct_alphas,
        termination_reason = termination_reason,
        termination_time = time[end],
    )
    _add_dfvb_runtime_metadata!(
        metadata;
        simulation_start_time = simulation_start_time,
        ode_solve_elapsed_seconds = ode_solve_elapsed_seconds,
        rhs_elapsed_seconds = rhs_elapsed_seconds[],
        rhs_call_count = rhs_call_count[],
        history_reconstruction_elapsed_seconds = history_reconstruction_elapsed_seconds,
        saved_state_reconstruction_solve_count = reconstruction.saved_state_reconstruction_solve_count,
        reconstruct_fluxes = reconstruct_fluxes,
        reconstruct_alphas = reconstruct_alphas,
    )

    return SimulationResult(
        time,
        states;
        fluxes = reconstruction.fluxes,
        alphas = reconstruction.alphas,
        metadata = metadata,
    )
end

function _reconstruct_dfvb_history(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    artifacts::DFVBArtifacts,
    states::AbstractMatrix;
    params::ZentenoKineticParameters,
    use_active_alpha::Bool,
    optimizer,
    silent::Bool,
    lp_atol::Real,
    reconstruct_fluxes::Bool,
    reconstruct_alphas::Bool,
    skip_sugar_depleted_states::Bool = false,
    sugar_depletion_tol::Real = 0.0,
)
    alpha_ids = _dfvb_alpha_ids(artifacts, use_active_alpha)
    n_alpha = length(alpha_ids)
    flux_rxn_ids = reconstruct_fluxes ? _dfvb_simulation_flux_rxn_ids(reaction_map, params) : String[]
    n_fluxes = length(flux_rxn_ids)
    n_time = size(states, 2)
    alphas = reconstruct_alphas ? Matrix{Float64}(undef, n_alpha, n_time) : nothing
    fluxes = reconstruct_fluxes ? Matrix{Float64}(undef, n_fluxes, n_time) : nothing
    mode_history = Vector{Symbol}(undef, n_time)
    rhs_status_history = Vector{String}(undef, n_time)
    mass_balance_residuals = Vector{Float64}(undef, n_time)
    max_lower_bound_violations = Vector{Float64}(undef, n_time)
    max_upper_bound_violations = Vector{Float64}(undef, n_time)
    policy_metadata = _dfvb_simulation_policy_metadata(model, artifacts; use_active_alpha = use_active_alpha)
    saved_state_reconstruction_solve_count = 0

    for k in 1:n_time
        if skip_sugar_depleted_states && states[3, k] + states[4, k] <= Float64(sugar_depletion_tol)
            reconstruct_alphas && (alphas[:, k] .= NaN)
            reconstruct_fluxes && (fluxes[:, k] .= NaN)
            mode_history[k] = :sugar_depleted
            rhs_status_history[k] = "NOT_EVALUATED_SUGAR_DEPLETION"
            mass_balance_residuals[k] = NaN
            max_lower_bound_violations[k] = NaN
            max_upper_bound_violations[k] = NaN
            continue
        end

        saved_state_reconstruction_solve_count += 1
        rhs_result = compute_dfvb_rhs(
            model,
            reaction_map,
            artifacts,
            view(states, :, k);
            params = params,
            use_active_alpha = use_active_alpha,
            optimizer = optimizer,
            silent = silent,
            atol = lp_atol,
        )

        if reconstruct_alphas
            length(rhs_result.alpha) == n_alpha || error(
                "DFVB saved-state alpha length $(length(rhs_result.alpha)) does not match expected $n_alpha.",
            )
            alphas[:, k] .= rhs_result.alpha
        end
        if reconstruct_fluxes
            for (i, rxn_id) in enumerate(flux_rxn_ids)
                fluxes[i, k] = rhs_result.fluxes_by_rxn[rxn_id]
            end
        end
        mode_history[k] = rhs_result.mode
        rhs_status_history[k] = string(rhs_result.dfvb.status)
        mass_balance_residuals[k] = rhs_result.dfvb.mass_balance_residual
        max_lower_bound_violations[k] = rhs_result.dfvb.max_lower_bound_violation
        max_upper_bound_violations[k] = rhs_result.dfvb.max_upper_bound_violation
        policy_metadata = _dfvb_simulation_policy_metadata(rhs_result)
    end

    return (
        fluxes = fluxes,
        flux_rxn_ids = flux_rxn_ids,
        alphas = alphas,
        alpha_ids = reconstruct_alphas ? alpha_ids : String[],
        mode_history = mode_history,
        rhs_status_history = rhs_status_history,
        mass_balance_residuals = mass_balance_residuals,
        max_lower_bound_violations = max_lower_bound_violations,
        max_upper_bound_violations = max_upper_bound_violations,
        policy_metadata = policy_metadata,
        saved_state_reconstruction_solve_count = saved_state_reconstruction_solve_count,
    )
end

function _empty_dfvb_history(
    artifacts::DFVBArtifacts;
    use_active_alpha::Bool,
)
    return (
        fluxes = nothing,
        flux_rxn_ids = String[],
        alphas = nothing,
        alpha_ids = String[],
        mode_history = Symbol[],
        rhs_status_history = String[],
        mass_balance_residuals = Float64[],
        max_lower_bound_violations = Float64[],
        max_upper_bound_violations = Float64[],
        policy_metadata = _dfvb_simulation_policy_metadata(nothing, artifacts; use_active_alpha = use_active_alpha),
        saved_state_reconstruction_solve_count = 0,
    )
end

function _dfvb_simulation_flux_rxn_ids(
    reaction_map::ReactionMap,
    params::ZentenoKineticParameters,
)::Vector{String}
    core_ids = [
        _dfvb_rhs_required_core_reaction_id(reaction_map, "biomass_growth"),
        _dfvb_rhs_required_core_reaction_id(reaction_map, "glucose_exchange"),
        _dfvb_rhs_required_core_reaction_id(reaction_map, "fructose_exchange"),
        _dfvb_rhs_required_core_reaction_id(reaction_map, "ethanol_exchange"),
        _dfvb_rhs_required_core_reaction_id(reaction_map, "oxygen_exchange"),
        _dfvb_rhs_required_core_reaction_id(reaction_map, "atp_maintenance"),
        _dfvb_rhs_required_core_reaction_id(reaction_map, "protein_exchange"),
        _dfvb_rhs_required_core_reaction_id(reaction_map, "carbohydrate_exchange"),
    ]
    amino_acid_ids = [
        _dfvb_rhs_required_group_role_id(reaction_map.amino_acids, role, "amino_acids") for
        role in ZENTENO_AMINO_ACID_ROLES
    ]
    aroma_ids = [
        _dfvb_rhs_required_group_role_id(reaction_map.aromas, role, "aromas") for
        role in ZENTENO_AROMA_ROLES
    ]

    return _stable_flux_reaction_ids(
        core_ids,
        params.nitrogen_source_ids,
        amino_acid_ids,
        aroma_ids;
        include_oxygen = true,
    )
end

function _build_dfvb_simulation_metadata(
    model::MetabolicModel,
    artifacts::DFVBArtifacts,
    reconstruction,
    states::AbstractMatrix;
    use_active_alpha::Bool,
    retcode::AbstractString,
    algorithm,
    tspan::Tuple{Float64, Float64},
    saveat,
    adaptive::Bool,
    dt,
    stop_on_sugar_depletion::Bool,
    sugar_depletion_tol::Real,
    nonnegative::Bool,
    reconstruct_fluxes::Bool,
    reconstruct_alphas::Bool,
    termination_reason::AbstractString,
    termination_time::Real,
)::Dict{String, Any}
    _validate_dfvb_history_consistency(reconstruction, states, reconstruct_fluxes, reconstruct_alphas)
    negative_diagnostics = _negative_state_diagnostics(states)
    alpha_scope = use_active_alpha ? "active" : "full"
    alpha_ids = reconstruct_alphas ? reconstruction.alpha_ids : String[]
    metadata = Dict{String, Any}(
        "model_id" => model.model_id,
        "artifact_id" => artifacts.paths.artifact_id,
        "model_scope" => "dfvb",
        "simulation_type" => "sequential_dfvb",
        "method" => "dfvb",
        "state_names" => copy(REDUCED_DFBA_STATE_NAMES),
        "flux_rxn_ids" => reconstruction.flux_rxn_ids,
        "mode_history" => reconstruction.mode_history,
        "rhs_status_history" => reconstruction.rhs_status_history,
        "mass_balance_residuals" => reconstruction.mass_balance_residuals,
        "max_lower_bound_violations" => reconstruction.max_lower_bound_violations,
        "max_upper_bound_violations" => reconstruction.max_upper_bound_violations,
        "retcode" => retcode,
        "algorithm" => String(nameof(typeof(algorithm))),
        "tspan" => tspan,
        "saveat" => saveat,
        "adaptive" => adaptive,
        "dt" => dt,
        "stop_on_sugar_depletion" => stop_on_sugar_depletion,
        "sugar_depletion_tol" => Float64(sugar_depletion_tol),
        "nonnegative" => nonnegative,
        "termination_reason" => String(termination_reason),
        "termination_time" => Float64(termination_time),
        "min_state_value" => negative_diagnostics.min_state_value,
        "has_negative_saved_states" => negative_diagnostics.has_negative_saved_states,
        "negative_state_policy" =>
            "Initial states are validated when nonnegative=true; robust nonnegative enforcement is deferred.",
        "negative_state_min_by_state" => negative_diagnostics.min_by_state,
        "negative_state_locations" => negative_diagnostics.locations,
        "n_saved_points" => size(states, 2),
        "n_fluxes" => length(reconstruction.flux_rxn_ids),
        "use_active_alpha" => use_active_alpha,
        "alpha_scope" => alpha_scope,
        "alpha_source" => reconstruct_alphas ? "reconstructed_saved_states" : "not_reconstructed",
        "alpha_ids" => alpha_ids,
        "n_alphas" => reconstruct_alphas ? length(alpha_ids) : 0,
        "reconstruct_alphas" => reconstruct_alphas,
        "reconstruct_fluxes" => reconstruct_fluxes,
        "alpha_orientation" => "n_alpha x n_time",
        "history_reconstruction_policy" => reconstruct_alphas || reconstruct_fluxes ?
            "Saved-state DFVB alpha, flux, and diagnostic reconstruction used one LP per non-depleted saved state." :
            "Saved-state DFVB alpha, flux, and diagnostic reconstruction was skipped; history vectors are empty.",
        "sugar_depleted_rhs_status" => "NOT_EVALUATED_SUGAR_DEPLETION",
        "sugar_depleted_flux_policy" =>
            "Fluxes, alphas, and diagnostics are NaN when RHS is not evaluated at sugar-depleted saved states.",
        "biological_interpretation_note" => DFVB_SIMULATION_BIOLOGICAL_INTERPRETATION_NOTE,
        "dfvb_rhs_implemented" => true,
        "dfvb_ode_implemented" => true,
        "kkt_mpcc_collocation_implemented" => false,
    )
    merge!(metadata, Dict{String, Any}(reconstruction.policy_metadata))
    return metadata
end

function _validate_dfvb_history_consistency(
    reconstruction,
    states::AbstractMatrix,
    reconstruct_fluxes::Bool,
    reconstruct_alphas::Bool,
)
    n_time = size(states, 2)
    if !reconstruct_fluxes
        reconstruction.fluxes === nothing || error("Skipped DFVB flux reconstruction must not store fluxes.")
        isempty(reconstruction.flux_rxn_ids) || error("Skipped DFVB flux reconstruction must not report flux IDs.")
    else
        reconstruction.fluxes !== nothing || error("DFVB flux reconstruction must store fluxes.")
        size(reconstruction.fluxes) == (length(reconstruction.flux_rxn_ids), n_time) || error(
            "DFVB reconstructed flux history must be n_fluxes x n_time.",
        )
    end
    if !reconstruct_alphas
        reconstruction.alphas === nothing || error("Skipped DFVB alpha reconstruction must not store alphas.")
        isempty(reconstruction.alpha_ids) || error("Skipped DFVB alpha reconstruction must not report alpha IDs.")
    else
        reconstruction.alphas !== nothing || error("DFVB alpha reconstruction must store alphas.")
        size(reconstruction.alphas) == (length(reconstruction.alpha_ids), n_time) || error(
            "DFVB reconstructed alpha history must be n_alpha x n_time.",
        )
    end
    if reconstruct_fluxes || reconstruct_alphas
        length(reconstruction.mode_history) == n_time || error("DFVB mode history length does not match saved states.")
        length(reconstruction.rhs_status_history) == n_time ||
            error("DFVB RHS status history length does not match saved states.")
        length(reconstruction.mass_balance_residuals) == n_time ||
            error("DFVB mass-balance residual history length does not match saved states.")
        length(reconstruction.max_lower_bound_violations) == n_time ||
            error("DFVB lower-bound violation history length does not match saved states.")
        length(reconstruction.max_upper_bound_violations) == n_time ||
            error("DFVB upper-bound violation history length does not match saved states.")
    else
        isempty(reconstruction.mode_history) || error("Skipped DFVB reconstruction must have empty mode history.")
        isempty(reconstruction.rhs_status_history) || error(
            "Skipped DFVB reconstruction must have empty RHS status history.",
        )
        isempty(reconstruction.mass_balance_residuals) || error(
            "Skipped DFVB reconstruction must have empty mass-balance residual history.",
        )
        isempty(reconstruction.max_lower_bound_violations) || error(
            "Skipped DFVB reconstruction must have empty lower-bound violation history.",
        )
        isempty(reconstruction.max_upper_bound_violations) || error(
            "Skipped DFVB reconstruction must have empty upper-bound violation history.",
        )
    end
    return nothing
end

function _add_dfvb_runtime_metadata!(
    metadata::Dict{String, Any};
    simulation_start_time::Real,
    ode_solve_elapsed_seconds::Real,
    rhs_elapsed_seconds::Real,
    rhs_call_count::Integer,
    history_reconstruction_elapsed_seconds::Real,
    saved_state_reconstruction_solve_count::Integer,
    reconstruct_fluxes::Bool,
    reconstruct_alphas::Bool,
)
    rhs_lp_solve_count = Int(rhs_call_count)
    saved_solve_count = Int(saved_state_reconstruction_solve_count)
    metadata["simulation_elapsed_seconds"] = max(0.0, Base.time() - Float64(simulation_start_time))
    metadata["ode_solve_elapsed_seconds"] = max(0.0, Float64(ode_solve_elapsed_seconds))
    metadata["rhs_elapsed_seconds"] = max(0.0, Float64(rhs_elapsed_seconds))
    metadata["history_reconstruction_elapsed_seconds"] =
        max(0.0, Float64(history_reconstruction_elapsed_seconds))
    metadata["rhs_call_count"] = Int(rhs_call_count)
    metadata["rhs_lp_solve_count"] = rhs_lp_solve_count
    metadata["saved_state_reconstruction_solve_count"] = saved_solve_count
    metadata["alpha_reconstruction_solve_count"] = reconstruct_alphas ? saved_solve_count : 0
    metadata["flux_reconstruction_solve_count"] = reconstruct_fluxes ? saved_solve_count : 0
    metadata["total_lp_solve_count"] = rhs_lp_solve_count + saved_solve_count
    metadata["reconstruct_fluxes"] = reconstruct_fluxes
    metadata["reconstruct_alphas"] = reconstruct_alphas
    return metadata
end

function _dfvb_simulation_policy_metadata(
    model,
    artifacts::DFVBArtifacts;
    use_active_alpha::Bool,
)::Dict{String, Any}
    return Dict{String, Any}(
        "oxygen_reaction_id" => "r_1992",
        "oxygen_exchange_reaction_id" => "r_1992",
        "oxygen_derivative_policy" => "forced_zero_dfvb_r1992",
        "oxygen_policy_note" => "DFVB simulation forces dy[6] = 0.0; r_1992 is the oxygen reaction ID and r_0001 is not oxygen.",
        "r0001_used_as_oxygen" => false,
        "indices_reacciones_used" => false,
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "use_active_alpha" => use_active_alpha,
        "exchange_partition_note" => DFVB_ARTIFACT_EXCHANGE_PARTITION_NOTE,
        "oxygen_mapping_note" => DFVB_ARTIFACT_OXYGEN_MAPPING_NOTE,
    )
end

function _dfvb_simulation_policy_metadata(rhs_result::DFVBRHSResult)::Dict{String, Any}
    keys_to_copy = (
        "oxygen_reaction_id",
        "oxygen_exchange_reaction_id",
        "oxygen_derivative_policy",
        "oxygen_policy_note",
        "oxygen_flux_r_1992",
        "r0001_flux",
        "r0001_used_as_oxygen",
        "indices_reacciones_used",
        "carbohydrate_derivative_policy",
        "objective_value_is_not_biomass_flux",
    )
    return Dict{String, Any}(key => rhs_result.metadata[key] for key in keys_to_copy)
end
