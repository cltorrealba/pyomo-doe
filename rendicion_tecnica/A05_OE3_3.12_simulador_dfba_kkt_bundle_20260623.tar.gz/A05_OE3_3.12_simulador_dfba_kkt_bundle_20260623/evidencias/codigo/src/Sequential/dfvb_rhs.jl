import HiGHS
import MathOptInterface as MOI

const DFVB_RHS_BIOLOGICAL_INTERPRETATION_NOTE =
    "One-step DFVB RHS smoke only: this applies the current dFBA RHS formulas to fluxes reconstructed from a dynamic DFVB alpha-space LP; this result is not an ODE integration and does not validate dynamic DFVB physiology."

"""
    DFVBRHSResult

Result container for a single sequential DFVB right-hand-side evaluation.
This is not an ODE integration result.
"""
struct DFVBRHSResult
    dy::Vector{Float64}
    state::ZentenoState
    bounds::ZentenoDynamicBounds
    dfvb::StaticDFVBResult
    fluxes_by_rxn::Dict{String, Float64}
    alpha::Vector{Float64}
    alpha_ids::Vector{String}
    mode::Symbol
    metadata::Dict{String, Any}
end

"""
    DFVBContext

Typed configuration for ODE-compatible sequential DFVB RHS calls. Only
`nonoptimal_policy = :error` is supported because `compute_dfvb_rhs` throws on
non-optimal DFVB LP solves.
"""
struct DFVBContext
    model::MetabolicModel
    reaction_map::ReactionMap
    artifacts::DFVBArtifacts
    params::ZentenoKineticParameters
    use_active_alpha::Bool
    optimizer::Any
    silent::Bool
    atol::Float64
    nonoptimal_policy::Symbol
end

function DFVBContext(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    artifacts::DFVBArtifacts;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    use_active_alpha::Bool = true,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1.0e-8,
    nonoptimal_policy::Symbol = :error,
)
    converted_atol = Float64(atol)
    isfinite(converted_atol) && converted_atol > 0.0 ||
        error("DFVBContext atol must be finite and positive, got $atol.")
    nonoptimal_policy == :error || error(
        "Unsupported DFVBContext nonoptimal_policy: $nonoptimal_policy. Only :error is supported.",
    )

    return DFVBContext(
        model,
        reaction_map,
        artifacts,
        params,
        use_active_alpha,
        optimizer,
        silent,
        converted_atol,
        nonoptimal_policy,
    )
end

"""
    compute_dfvb_rhs(model, reaction_map, artifacts, y; params=default_zenteno_parameters(), use_active_alpha=true, optimizer=HiGHS.Optimizer, silent=true, atol=1e-8)

Compute one sequential DFVB right-hand-side evaluation for a 19-state
Zenteno fermentation vector. Dynamic bounds and weighted DFVB objectives are
computed from the supplied state, then a single alpha-space LP is solved and
fluxes are reconstructed. This function does not integrate an ODE system.
"""
function compute_dfvb_rhs(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    artifacts::DFVBArtifacts,
    y::AbstractVector;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    use_active_alpha::Bool = true,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1.0e-8,
)::DFVBRHSResult
    state = zenteno_state_from_vector(y)
    _assert_dfvb_oxygen_not_r0001(reaction_map)
    bounds = zenteno_dynamic_bounds(model, reaction_map, state, params)
    dfvb = solve_dynamic_dfvb_lp(
        model,
        reaction_map,
        artifacts,
        y;
        params = params,
        use_active_alpha = use_active_alpha,
        optimizer = optimizer,
        silent = silent,
        atol = atol,
    )

    if dfvb.status != MOI.OPTIMAL
        error(
            "Sequential DFVB RHS LP solve did not terminate as optimal. " *
            "Status: $(dfvb.status), primal_status: $(dfvb.primal_status), dual_status: $(dfvb.dual_status).",
        )
    end

    biomass_id = _dfvb_rhs_required_core_reaction_id(reaction_map, "biomass_growth")
    glucose_id = _dfvb_rhs_required_core_reaction_id(reaction_map, "glucose_exchange")
    fructose_id = _dfvb_rhs_required_core_reaction_id(reaction_map, "fructose_exchange")
    ethanol_id = _dfvb_rhs_required_core_reaction_id(reaction_map, "ethanol_exchange")
    atp_id = _dfvb_rhs_required_core_reaction_id(reaction_map, "atp_maintenance")
    protein_id = _dfvb_rhs_required_core_reaction_id(reaction_map, "protein_exchange")
    carbohydrate_id = _dfvb_rhs_required_core_reaction_id(reaction_map, "carbohydrate_exchange")
    amino_acid_ids = [
        _dfvb_rhs_required_group_role_id(reaction_map.amino_acids, role, "amino_acids") for
        role in ZENTENO_AMINO_ACID_ROLES
    ]
    aroma_ids = [
        _dfvb_rhs_required_group_role_id(reaction_map.aromas, role, "aromas") for
        role in ZENTENO_AROMA_ROLES
    ]
    nitrogen_ids = String.(params.nitrogen_source_ids)

    rhs_reaction_ids = _dfvb_rhs_reaction_ids(
        model,
        [
            biomass_id,
            glucose_id,
            fructose_id,
            ethanol_id,
            atp_id,
            protein_id,
            carbohydrate_id,
        ],
        nitrogen_ids,
        amino_acid_ids,
        aroma_ids,
        collect(keys(bounds.objective_weights)),
    )
    fluxes_by_rxn = _collect_dfvb_fluxes_by_rxn(model, dfvb, rhs_reaction_ids)
    flux(rxn_id) = fluxes_by_rxn[rxn_id]

    v_obj = flux(biomass_id)
    v_glu = flux(glucose_id)
    v_fru = flux(fructose_id)
    v_eth = flux(ethanol_id)
    v_prot = flux(protein_id)
    vn_eff = [flux(rxn_id) for rxn_id in nitrogen_ids]
    v_aa = [flux(rxn_id) for rxn_id in amino_acid_ids]
    v_aromas = [flux(rxn_id) for rxn_id in aroma_ids]

    cX = state.biomass
    cProt = state.protein
    cCarb = state.carbohydrate
    Xa = params.XA_FRACTION * cX

    dy = zeros(19)
    dy[1] = bounds.mode == :growth ? v_obj * cX : 0.0
    dy[2] = bounds.mode == :growth ?
        sum(vn_eff .* params.nitrogen_atom_counts .* params.MW_N .* cX) :
        0.0
    dy[3] = -params.MW_GLU * max(0.0, -v_glu) * cX
    dy[4] = -params.MW_FRU * max(0.0, -v_fru) * cX
    dy[5] = params.MW_ETH * max(0.0, v_eth) * cX
    dy[6] = 0.0
    dy[7] =
        max(0.0, v_obj) * cX * params.PROT_CONTENT_0 -
        cProt * params.K_DEATH +
        Xa * max(0.0, v_prot) -
        params.TURNOVER_LAMBDA * cProt
    dy[8] = max(0.0, v_obj) * cX * params.CARB_CONTENT_0 - cCarb * params.K_DEATH

    if bounds.mode == :growth
        dy[9:13] .= cX .* v_aa
    else
        dy[9:13] .= 0.0
    end

    dy[14:19] .= params.aroma_molecular_weights .* max.(0.0, v_aromas) .* cX

    metadata = _dfvb_rhs_metadata(
        model,
        dfvb,
        fluxes_by_rxn,
        rhs_reaction_ids,
        bounds;
        use_active_alpha = use_active_alpha,
    )

    return DFVBRHSResult(
        dy,
        state,
        bounds,
        dfvb,
        fluxes_by_rxn,
        copy(dfvb.alpha),
        copy(dfvb.alpha_ids),
        bounds.mode,
        metadata,
    )
end

"""
    dfvb_rhs!(du, u, context, t)

ODE-compatible sequential DFVB right-hand-side wrapper. This performs one RHS
evaluation only; it does not integrate the ODE system.
"""
function dfvb_rhs!(
    du::AbstractVector,
    u::AbstractVector,
    context::DFVBContext,
    t,
)
    length(du) == 19 || error("DFVB RHS output vector must have length 19, got $(length(du)).")
    length(u) == 19 || error("DFVB RHS state vector must have length 19, got $(length(u)).")

    result = compute_dfvb_rhs(
        context.model,
        context.reaction_map,
        context.artifacts,
        u;
        params = context.params,
        use_active_alpha = context.use_active_alpha,
        optimizer = context.optimizer,
        silent = context.silent,
        atol = context.atol,
    )
    du .= result.dy
    return nothing
end

function _dfvb_rhs_flux_value(model::MetabolicModel, dfvb::StaticDFVBResult, rxn_id::AbstractString)::Float64
    cleaned_id = strip(String(rxn_id))
    has_reaction(model, cleaned_id) ||
        error("Missing required sequential DFVB RHS reaction ID in model $(model.model_id): $cleaned_id")
    length(dfvb.fluxes) == length(model.rxn_ids) || error(
        "DFVB flux vector length $(length(dfvb.fluxes)) does not match $(length(model.rxn_ids)) reactions.",
    )
    return dfvb.fluxes[reaction_index(model, cleaned_id)]
end

function _collect_dfvb_fluxes_by_rxn(
    model::MetabolicModel,
    dfvb::StaticDFVBResult,
    rxn_ids::AbstractVector{<:AbstractString},
)::Dict{String, Float64}
    fluxes = Dict{String, Float64}()
    for rxn_id in rxn_ids
        cleaned_id = strip(String(rxn_id))
        fluxes[cleaned_id] = _dfvb_rhs_flux_value(model, dfvb, cleaned_id)
    end
    return fluxes
end

function _dfvb_rhs_required_core_reaction_id(reaction_map::ReactionMap, role::AbstractString)::String
    return _dfvb_rhs_required_group_role_id(reaction_map.core, role, "core")
end

function _dfvb_rhs_required_group_role_id(
    group::Dict{String, String},
    role::AbstractString,
    group_name::AbstractString,
)::String
    role_key = String(role)
    haskey(group, role_key) || error("Missing required $group_name reaction-map role: $role_key")
    rxn_id = strip(group[role_key])
    isempty(rxn_id) && error("Reaction-map role $role_key in $group_name has an empty reaction ID.")
    return rxn_id
end

function _dfvb_rhs_reaction_ids(
    model::MetabolicModel,
    rxn_groups::AbstractVector...,
)
    rxn_ids = String[]
    for group in rxn_groups
        append!(rxn_ids, String.(group))
    end
    push!(rxn_ids, "r_1992")
    has_reaction(model, "r_0001") && push!(rxn_ids, "r_0001")
    return sort(collect(Set(String.(strip.(rxn_ids)))))
end

function _dfvb_rhs_metadata(
    model::MetabolicModel,
    dfvb::StaticDFVBResult,
    fluxes_by_rxn::Dict{String, Float64},
    rhs_reaction_ids::Vector{String},
    bounds::ZentenoDynamicBounds;
    use_active_alpha::Bool,
)::Dict{String, Any}
    biomass_flux = fluxes_by_rxn["r_2111"]
    oxygen_flux = get(fluxes_by_rxn, "r_1992", missing)
    r0001_flux = get(fluxes_by_rxn, "r_0001", missing)

    return Dict{String, Any}(
        "rhs_type" => "dfvb",
        "problem_type" => "dfvb_rhs",
        "model_scope" => "matlab_full_dfvb_export",
        "model_id" => model.model_id,
        "mode" => String(bounds.mode),
        "use_active_alpha" => use_active_alpha,
        "alpha_scope" => use_active_alpha ? "active" : "full",
        "n_alpha" => length(dfvb.alpha),
        "alpha_ids" => copy(dfvb.alpha_ids),
        "dfvb_status" => dfvb.status,
        "dfvb_primal_status" => dfvb.primal_status,
        "dfvb_dual_status" => dfvb.dual_status,
        "dfvb_objective_value" => dfvb.objective_value,
        "dfvb_objective_type" => get(dfvb.metadata, "objective_type", "unknown"),
        "dfvb_objective_term_count" => get(dfvb.metadata, "n_objective_terms", length(bounds.objective_weights)),
        "objective_value_is_not_biomass_flux" => true,
        "biomass_flux_r_2111" => biomass_flux,
        "oxygen_reaction_id" => "r_1992",
        "oxygen_exchange_reaction_id" => "r_1992",
        "oxygen_derivative_policy" => "forced_zero_dfvb_r1992",
        "oxygen_policy_note" => "DFVB RHS forces dy[6] = 0.0; r_1992 is the oxygen reaction ID and r_0001 is not oxygen.",
        "oxygen_flux_r_1992" => oxygen_flux,
        "r0001_flux" => r0001_flux,
        "r0001_used_as_oxygen" => false,
        "indices_reacciones_used" => false,
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "rhs_units_note" => "Mixed units follow the current MATLAB RHS contract.",
        "rhs_reaction_ids" => rhs_reaction_ids,
        "mass_balance_residual" => dfvb.mass_balance_residual,
        "max_lower_bound_violation" => dfvb.max_lower_bound_violation,
        "max_upper_bound_violation" => dfvb.max_upper_bound_violation,
        "biological_interpretation_note" => DFVB_RHS_BIOLOGICAL_INTERPRETATION_NOTE,
        "dfvb_rhs_implemented" => true,
        "dfvb_ode_implemented" => true,
        "kkt_mpcc_collocation_implemented" => false,
    )
end
