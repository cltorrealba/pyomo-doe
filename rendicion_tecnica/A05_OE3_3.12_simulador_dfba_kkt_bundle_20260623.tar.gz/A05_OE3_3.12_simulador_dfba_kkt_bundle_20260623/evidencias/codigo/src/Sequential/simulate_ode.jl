import HiGHS
import OrdinaryDiffEq

const REDUCED_DFBA_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

const REDUCED_DFBA_EXPERIMENTAL_LP_REUSE_ERROR =
    "DFBA ODE simulation lp_reuse=true is experimental because persistent LP reuse can " *
    "select different degenerate optima and materially change adaptive trajectories. Use the default " *
    "lp_reuse=false path for scientific simulations, or set allow_experimental_lp_reuse=true only for " *
    "controlled diagnostics."

const REDUCED_DFBA_RHS_FAILURE_DIAGNOSTICS_ENV =
    "DFBA_REDUCED_DFBA_RHS_FAILURE_DIAGNOSTICS"

"""
    simulate_reduced_dfba(model, reaction_map; kwargs...)

Run a sequential reduced DFBA ODE simulation. Each RHS evaluation delegates to
`dfba_rhs!`, which solves one JuMP/HiGHS LP through `compute_dfba_rhs`.
When `reconstruct_fluxes=false`, saved-state flux and diagnostic
reconstruction is skipped and `SimulationResult.fluxes === nothing`.
When `dynamic_control_schedule` is supplied, RHS evaluations use the schedule's
time-dependent temperature and smooth pump-addition rates.
By default each RHS evaluation rebuilds its LP. Persistent LP reuse remains
available for RHS diagnostics, but ODE simulation requires
`allow_experimental_lp_reuse=true` when `lp_reuse=true` because trajectory
equivalence is not currently validated for adaptive integration.
"""
function simulate_reduced_dfba(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    tspan::Tuple{Float64, Float64} = (0.0, 72.0),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    dynamic_control_schedule = nothing,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    saveat = 1.0,
    algorithm = nothing,
    adaptive::Bool = true,
    dt = nothing,
    nonnegative::Bool = true,
    stop_on_sugar_depletion::Bool = true,
    sugar_depletion_tol::Real = 1.0e-6,
    reconstruct_fluxes::Bool = true,
    lp_reuse::Bool = false,
    lp_primal_start::Bool = false,
    lp_reuse_highs_solver::AbstractString = "simplex",
    lp_basis_warm_start::Bool = false,
    lp_simplex_strategy::AbstractString = "default",
    allow_experimental_lp_reuse::Bool = false,
    fba_variant::AbstractString = "fba",
    quadratic_penalty::Real = 0.0,
    l1_penalty::Real = 0.0,
    model_scope::AbstractString = "reduced",
    progress_interval_seconds::Real = 0.0,
    max_rhs_calls = nothing,
    max_walltime_seconds = nothing,
)::SimulationResult
    simulation_start_time = Base.time()
    normalized_model_scope = _normalize_dfba_model_scope(model_scope)
    _validate_reduced_dfba_simulation_inputs(
        y0,
        tspan,
        lp_atol,
        ode_abstol,
        ode_reltol,
        sugar_depletion_tol,
        nonnegative,
    )
    lp_reuse || !lp_primal_start || error("simulate_reduced_dfba lp_primal_start=true requires lp_reuse=true.")
    lp_reuse || !lp_basis_warm_start ||
        error("simulate_reduced_dfba lp_basis_warm_start=true requires lp_reuse=true.")
    _assert_reduced_dfba_lp_reuse_allowed(lp_reuse, allow_experimental_lp_reuse)

    context = DFBAContext(
        model,
        reaction_map;
        params = params,
        dynamic_control_schedule = dynamic_control_schedule,
        optimizer = optimizer,
        silent = silent,
        atol = lp_atol,
        nonoptimal_policy = :error,
        lp_reuse = lp_reuse,
        lp_primal_start = lp_primal_start,
        lp_reuse_highs_solver = lp_reuse_highs_solver,
        lp_basis_warm_start = lp_basis_warm_start,
        lp_simplex_strategy = lp_simplex_strategy,
        fba_variant = fba_variant,
        quadratic_penalty = quadratic_penalty,
        l1_penalty = l1_penalty,
    )

    initial_state = Float64.(copy(y0))
    ode_algorithm = algorithm === nothing ?
        OrdinaryDiffEq.Rodas5P(autodiff = OrdinaryDiffEq.AutoFiniteDiff()) :
        algorithm
    solve_dt = _dfba_solve_dt(adaptive, dt, saveat)
    _validate_dfba_runtime_controls(
        progress_interval_seconds,
        max_rhs_calls,
        max_walltime_seconds,
    )
    initial_sugar = initial_state[3] + initial_state[4]
    rhs_call_count = Ref(0)
    rhs_elapsed_seconds = Ref(0.0)
    flux_reconstruction_solve_count = Ref(0)
    last_progress_time = Ref(simulation_start_time)

    function instrumented_rhs!(du, u, context, t)
        rhs_call_count[] += 1
        _assert_dfba_runtime_limits!(
            rhs_call_count[],
            t;
            simulation_start_time = simulation_start_time,
            max_rhs_calls = max_rhs_calls,
            max_walltime_seconds = max_walltime_seconds,
        )
        if stop_on_sugar_depletion && _reduced_dfba_total_sugar(u) <= Float64(sugar_depletion_tol)
            fill!(du, 0.0)
            return nothing
        end
        try
            rhs_elapsed_seconds[] += @elapsed dfba_rhs!(du, u, context, t)
        catch err
            _maybe_print_dfba_rhs_failure_diagnostics(
                err,
                u,
                t;
                model_scope = normalized_model_scope,
                rhs_call_count = rhs_call_count[],
            )
            rethrow()
        end
        _maybe_print_dfba_progress!(
            last_progress_time,
            t;
            model_scope = normalized_model_scope,
            final_time = tspan[2],
            simulation_start_time = simulation_start_time,
            rhs_call_count = rhs_call_count[],
            progress_interval_seconds = progress_interval_seconds,
        )
        return nothing
    end

    if stop_on_sugar_depletion && initial_sugar <= Float64(sugar_depletion_tol)
        time = [tspan[1]]
        states = reshape(initial_state, 19, 1)
        reconstruction = nothing
        history_reconstruction_elapsed_seconds = @elapsed begin
            reconstruction = reconstruct_fluxes ?
                _reconstruct_reduced_dfba_history(
                    model,
                    reaction_map,
                    states;
                    time = time,
                    params = params,
                    dynamic_control_schedule = dynamic_control_schedule,
                    optimizer = context.optimizer,
                    silent = silent,
                    lp_atol = lp_atol,
                    skip_sugar_depleted_states = true,
                    sugar_depletion_tol = sugar_depletion_tol,
                    solve_counter = flux_reconstruction_solve_count,
                    model_scope = normalized_model_scope,
                    fba_variant = context.fba_variant,
                    quadratic_penalty = context.quadratic_penalty,
                    l1_penalty = context.l1_penalty,
                ) :
                _empty_dfba_history(model)
        end
        metadata = _build_reduced_dfba_metadata(
            reconstruction,
            states;
            model_scope = normalized_model_scope,
            retcode = "NotRun",
            algorithm = ode_algorithm,
            tspan = tspan,
            saveat = saveat,
            adaptive = adaptive,
            dt = solve_dt,
            stop_on_sugar_depletion = stop_on_sugar_depletion,
            sugar_depletion_tol = sugar_depletion_tol,
            nonnegative = nonnegative,
            termination_reason = "sugar_depletion_at_initial_time",
            termination_time = time[end],
            lp_reuse = lp_reuse,
            lp_primal_start = lp_primal_start,
            lp_reuse_highs_solver = context.fba_variant == "qpfba" ? "default" : lp_reuse_highs_solver,
            lp_basis_warm_start = lp_basis_warm_start,
            lp_simplex_strategy = context.lp_simplex_strategy,
            allow_experimental_lp_reuse = allow_experimental_lp_reuse,
            fba_variant = context.fba_variant,
            quadratic_penalty = context.quadratic_penalty,
            l1_penalty = context.l1_penalty,
            dynamic_control_schedule = dynamic_control_schedule,
        )
        _add_reduced_dfba_runtime_metadata!(
            metadata;
            simulation_start_time = simulation_start_time,
            ode_solve_elapsed_seconds = 0.0,
            rhs_elapsed_seconds = rhs_elapsed_seconds[],
            rhs_call_count = rhs_call_count[],
            history_reconstruction_elapsed_seconds = history_reconstruction_elapsed_seconds,
            flux_reconstruction_solve_count = flux_reconstruction_solve_count[],
            reconstruct_fluxes = reconstruct_fluxes,
            dfba_context = context,
        )
        return SimulationResult(time, states; fluxes = reconstruction.fluxes, metadata = metadata)
    end

    prob = OrdinaryDiffEq.ODEProblem(instrumented_rhs!, initial_state, tspan, context)
    sol = nothing
    ode_solve_elapsed_seconds = @elapsed begin
        sol = _solve_dfba_ode(
            prob,
            ode_algorithm;
            ode_abstol = ode_abstol,
            ode_reltol = ode_reltol,
            saveat = saveat,
            adaptive = adaptive,
            dt = solve_dt,
        )
    end

    time = Float64.(sol.t)
    states = _saved_states_matrix(sol.u)
    termination_reason = "completed_tspan"

    if stop_on_sugar_depletion
        depleted_index = _first_saved_sugar_depletion_index(states, sugar_depletion_tol)
        if depleted_index !== nothing
            time = time[1:depleted_index]
            states = states[:, 1:depleted_index]
            termination_reason = "sugar_depletion_at_saved_time"
        end
    end

    reconstruction = nothing
    history_reconstruction_elapsed_seconds = @elapsed begin
        reconstruction = reconstruct_fluxes ?
            _reconstruct_reduced_dfba_history(
                model,
                reaction_map,
                states;
                time = time,
                params = params,
                dynamic_control_schedule = dynamic_control_schedule,
                optimizer = context.optimizer,
                silent = silent,
                lp_atol = lp_atol,
                skip_sugar_depleted_states = stop_on_sugar_depletion,
                sugar_depletion_tol = sugar_depletion_tol,
                solve_counter = flux_reconstruction_solve_count,
                model_scope = normalized_model_scope,
                fba_variant = context.fba_variant,
                quadratic_penalty = context.quadratic_penalty,
                l1_penalty = context.l1_penalty,
            ) :
            _empty_dfba_history(model)
    end
    metadata = _build_reduced_dfba_metadata(
        reconstruction,
        states;
        model_scope = normalized_model_scope,
        retcode = string(sol.retcode),
        algorithm = ode_algorithm,
        tspan = tspan,
        saveat = saveat,
        adaptive = adaptive,
        dt = solve_dt,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
        nonnegative = nonnegative,
        termination_reason = termination_reason,
        termination_time = time[end],
        lp_reuse = lp_reuse,
        lp_primal_start = lp_primal_start,
        lp_reuse_highs_solver = context.fba_variant == "qpfba" ? "default" : lp_reuse_highs_solver,
        lp_basis_warm_start = lp_basis_warm_start,
        lp_simplex_strategy = context.lp_simplex_strategy,
        allow_experimental_lp_reuse = allow_experimental_lp_reuse,
        fba_variant = context.fba_variant,
        quadratic_penalty = context.quadratic_penalty,
        l1_penalty = context.l1_penalty,
        dynamic_control_schedule = dynamic_control_schedule,
    )
    _add_reduced_dfba_runtime_metadata!(
        metadata;
        simulation_start_time = simulation_start_time,
        ode_solve_elapsed_seconds = ode_solve_elapsed_seconds,
        rhs_elapsed_seconds = rhs_elapsed_seconds[],
        rhs_call_count = rhs_call_count[],
        history_reconstruction_elapsed_seconds = history_reconstruction_elapsed_seconds,
        flux_reconstruction_solve_count = flux_reconstruction_solve_count[],
        reconstruct_fluxes = reconstruct_fluxes,
        dfba_context = context,
    )

    return SimulationResult(time, states; fluxes = reconstruction.fluxes, metadata = metadata)
end

"""
    simulate_full_dfba(model, reaction_map; kwargs...)

Run a short sequential full DFBA ODE smoke simulation. This wrapper delegates
to `simulate_reduced_dfba` with `model_scope = "full"`, a short default
horizon, `Tsit5`, and `reconstruct_fluxes = false`.
"""
function simulate_full_dfba(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    tspan::Tuple{Float64, Float64} = (0.0, 0.25),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    dynamic_control_schedule = nothing,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    saveat = 0.25,
    algorithm = OrdinaryDiffEq.Tsit5(),
    adaptive::Bool = true,
    dt = nothing,
    nonnegative::Bool = true,
    stop_on_sugar_depletion::Bool = true,
    sugar_depletion_tol::Real = 1.0e-6,
    reconstruct_fluxes::Bool = false,
    lp_reuse::Bool = false,
    lp_primal_start::Bool = false,
    lp_reuse_highs_solver::AbstractString = "simplex",
    lp_basis_warm_start::Bool = false,
    lp_simplex_strategy::AbstractString = "default",
    allow_experimental_lp_reuse::Bool = false,
    fba_variant::AbstractString = "fba",
    quadratic_penalty::Real = 0.0,
    l1_penalty::Real = 0.0,
    progress_interval_seconds::Real = 0.0,
    max_rhs_calls = nothing,
    max_walltime_seconds = nothing,
)::SimulationResult
    return simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = tspan,
        params = params,
        dynamic_control_schedule = dynamic_control_schedule,
        optimizer = optimizer,
        silent = silent,
        lp_atol = lp_atol,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        saveat = saveat,
        algorithm = algorithm,
        adaptive = adaptive,
        dt = dt,
        nonnegative = nonnegative,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
        reconstruct_fluxes = reconstruct_fluxes,
        lp_reuse = lp_reuse,
        lp_primal_start = lp_primal_start,
        lp_reuse_highs_solver = lp_reuse_highs_solver,
        lp_basis_warm_start = lp_basis_warm_start,
        lp_simplex_strategy = lp_simplex_strategy,
        allow_experimental_lp_reuse = allow_experimental_lp_reuse,
        fba_variant = fba_variant,
        quadratic_penalty = quadratic_penalty,
        l1_penalty = l1_penalty,
        model_scope = "full",
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
    )
end

"""
    simulate_ode(args...; kwargs...)

Alias for `simulate_reduced_dfba`. `simulate_reduced_dfba` is the preferred
public API for the sequential reduced DFBA simulator.
"""
function simulate_ode(args...; kwargs...)
    return simulate_reduced_dfba(args...; kwargs...)
end

function _normalize_dfba_model_scope(model_scope::AbstractString)::String
    normalized = lowercase(strip(String(model_scope)))
    normalized in ("reduced", "full") || error(
        "Unsupported DFBA simulation model_scope: $model_scope. Use \"reduced\" or \"full\".",
    )
    return normalized
end

function _validate_reduced_dfba_simulation_inputs(
    y0::AbstractVector,
    tspan::Tuple{Float64, Float64},
    lp_atol::Real,
    ode_abstol::Real,
    ode_reltol::Real,
    sugar_depletion_tol::Real,
    nonnegative::Bool,
)
    length(y0) == 19 || error("Expected a 19-element initial DFBA state vector, got $(length(y0)).")
    all(value -> isfinite(Float64(value)), y0) || error("Initial DFBA state vector must contain only finite values.")
    if nonnegative && any(Float64.(y0) .< 0.0)
        error("Initial DFBA state vector must be nonnegative when nonnegative=true.")
    end

    tspan[2] > tspan[1] || error("DFBA simulation tspan must satisfy tspan[2] > tspan[1].")
    _validate_finite_positive(lp_atol, "lp_atol")
    _validate_finite_positive(ode_abstol, "ode_abstol")
    _validate_finite_positive(ode_reltol, "ode_reltol")

    converted_sugar_tol = Float64(sugar_depletion_tol)
    isfinite(converted_sugar_tol) && converted_sugar_tol >= 0.0 ||
        error("sugar_depletion_tol must be finite and nonnegative, got $sugar_depletion_tol.")

    return nothing
end

function _validate_finite_positive(value::Real, label::AbstractString)
    converted = Float64(value)
    isfinite(converted) && converted > 0.0 || error("$label must be finite and positive, got $value.")
    return nothing
end

function _assert_reduced_dfba_lp_reuse_allowed(lp_reuse::Bool, allow_experimental_lp_reuse::Bool)
    if lp_reuse && !allow_experimental_lp_reuse
        error(REDUCED_DFBA_EXPERIMENTAL_LP_REUSE_ERROR)
    end
    return nothing
end

function _dfba_solve_dt(adaptive::Bool, dt, saveat)
    if adaptive
        if dt === nothing
            return nothing
        end
        converted_dt = Float64(dt)
        isfinite(converted_dt) && converted_dt > 0.0 || error("dt must be finite and positive, got $dt.")
        return converted_dt
    end

    candidate_dt = dt === nothing ? saveat : dt
    candidate_dt isa Real || error("Fixed-step DFBA simulation requires scalar numeric dt or saveat.")
    converted_dt = Float64(candidate_dt)
    isfinite(converted_dt) && converted_dt > 0.0 || error("Fixed-step DFBA simulation dt must be finite and positive.")
    return converted_dt
end

function _validate_dfba_runtime_controls(
    progress_interval_seconds::Real,
    max_rhs_calls,
    max_walltime_seconds,
)
    progress_interval = Float64(progress_interval_seconds)
    isfinite(progress_interval) && progress_interval >= 0.0 ||
        error("progress_interval_seconds must be finite and nonnegative.")
    if max_rhs_calls !== nothing
        max_rhs_calls isa Integer || error("max_rhs_calls must be an integer or nothing.")
        Int(max_rhs_calls) > 0 || error("max_rhs_calls must be positive when provided.")
    end
    if max_walltime_seconds !== nothing
        walltime_limit = Float64(max_walltime_seconds)
        isfinite(walltime_limit) && walltime_limit > 0.0 ||
            error("max_walltime_seconds must be finite and positive when provided.")
    end
    return nothing
end

function _assert_dfba_runtime_limits!(
    rhs_call_count::Integer,
    t;
    simulation_start_time::Real,
    max_rhs_calls,
    max_walltime_seconds,
)
    if max_rhs_calls !== nothing && rhs_call_count > Int(max_rhs_calls)
        error("DFBA simulation exceeded max_rhs_calls=$(Int(max_rhs_calls)) at t=$(Float64(t)).")
    end
    if max_walltime_seconds !== nothing
        elapsed = Base.time() - Float64(simulation_start_time)
        if elapsed > Float64(max_walltime_seconds)
            error(
                "DFBA simulation exceeded max_walltime_seconds=$(Float64(max_walltime_seconds)) " *
                "at t=$(Float64(t)) with rhs_call_count=$(Int(rhs_call_count)).",
            )
        end
    end
    return nothing
end

function _reduced_dfba_failure_diagnostics_enabled()::Bool
    value = lowercase(strip(get(ENV, REDUCED_DFBA_RHS_FAILURE_DIAGNOSTICS_ENV, "false")))
    return value in ("1", "true", "yes", "on")
end

function _reduced_dfba_state_value(u, index::Integer)::Float64
    return index <= length(u) ? Float64(u[index]) : NaN
end

function _reduced_dfba_total_sugar(u)::Float64
    return _reduced_dfba_state_value(u, 3) + _reduced_dfba_state_value(u, 4)
end

function _maybe_print_dfba_rhs_failure_diagnostics(
    err,
    u,
    t;
    model_scope::AbstractString,
    rhs_call_count::Integer,
)
    _reduced_dfba_failure_diagnostics_enabled() || return nothing

    finite_values = Float64[]
    negative_count = 0
    first_negative_state = "none"
    for (index, value_raw) in enumerate(u)
        value = Float64(value_raw)
        isfinite(value) || continue
        push!(finite_values, value)
        if value < 0.0
            negative_count += 1
            if first_negative_state == "none"
                first_negative_state = index <= length(REDUCED_DFBA_STATE_NAMES) ?
                    REDUCED_DFBA_STATE_NAMES[index] :
                    "state_$index"
            end
        end
    end

    glucose = _reduced_dfba_state_value(u, 3)
    fructose = _reduced_dfba_state_value(u, 4)
    total_sugar = _reduced_dfba_total_sugar(u)
    min_state = isempty(finite_values) ? NaN : minimum(finite_values)
    max_state = isempty(finite_values) ? NaN : maximum(finite_values)
    println(
        stderr,
        "DFBA RHS failure diagnostics | model_scope=$(String(model_scope)) | " *
        "t=$(Float64(t)) h | rhs_call_count=$(Int(rhs_call_count)) | " *
        "biomass=$(_reduced_dfba_state_value(u, 1)) | " *
        "nitrogen=$(_reduced_dfba_state_value(u, 2)) | " *
        "glucose=$glucose | fructose=$fructose | total_sugar=$total_sugar | " *
        "ethanol=$(_reduced_dfba_state_value(u, 5)) | oxygen=$(_reduced_dfba_state_value(u, 6)) | " *
        "protein=$(_reduced_dfba_state_value(u, 7)) | min_state=$min_state | max_state=$max_state | " *
        "negative_state_count=$negative_count | first_negative_state=$first_negative_state | " *
        "error_type=$(typeof(err))",
    )
    flush(stderr)
    return nothing
end

function _maybe_print_dfba_progress!(
    last_progress_time::Base.RefValue{Float64},
    t;
    model_scope::AbstractString,
    final_time::Real,
    simulation_start_time::Real,
    rhs_call_count::Integer,
    progress_interval_seconds::Real,
)
    interval = Float64(progress_interval_seconds)
    interval > 0.0 || return nothing
    now = Base.time()
    now - last_progress_time[] >= interval || return nothing
    elapsed = now - Float64(simulation_start_time)
    println(
        stderr,
        "DFBA progress | model_scope=$(String(model_scope)) | t=$(Float64(t)) / $(Float64(final_time)) h | " *
        "rhs_call_count=$(Int(rhs_call_count)) | elapsed_seconds=$(round(elapsed; digits = 3))",
    )
    flush(stderr)
    last_progress_time[] = now
    return nothing
end

function _solve_dfba_ode(
    prob,
    ode_algorithm;
    ode_abstol::Real,
    ode_reltol::Real,
    saveat,
    adaptive::Bool,
    dt,
)
    if dt === nothing
        return OrdinaryDiffEq.solve(
            prob,
            ode_algorithm;
            abstol = Float64(ode_abstol),
            reltol = Float64(ode_reltol),
            saveat = saveat,
            adaptive = adaptive,
        )
    end

    return OrdinaryDiffEq.solve(
        prob,
        ode_algorithm;
        abstol = Float64(ode_abstol),
        reltol = Float64(ode_reltol),
        saveat = saveat,
        adaptive = adaptive,
        dt = Float64(dt),
    )
end

function _saved_states_matrix(saved_states)::Matrix{Float64}
    isempty(saved_states) && error("ODE solver returned no saved states.")
    return hcat((Float64.(state) for state in saved_states)...)
end

function _dfba_reconstruction_time_values(time, n_time::Integer)::Vector{Float64}
    count = Int(n_time)
    count > 0 || error("Reduced DFBA reconstruction requires at least one saved state.")
    if time === nothing
        return zeros(count)
    end
    values = Float64.(time)
    length(values) == count || error(
        "Reduced DFBA reconstruction time length $(length(values)) does not match saved states $count.",
    )
    all(isfinite, values) || error("Reduced DFBA reconstruction times must be finite.")
    return values
end

function _first_saved_sugar_depletion_index(states::AbstractMatrix, sugar_depletion_tol::Real)
    threshold = Float64(sugar_depletion_tol)
    for k in axes(states, 2)
        if states[3, k] + states[4, k] <= threshold
            return k
        end
    end
    return nothing
end

function _reconstruct_reduced_dfba_history(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    states::AbstractMatrix;
    time = nothing,
    params::ZentenoKineticParameters,
    dynamic_control_schedule = nothing,
    optimizer,
    silent::Bool,
    lp_atol::Real,
    skip_sugar_depleted_states::Bool = false,
    sugar_depletion_tol::Real = 0.0,
    solve_counter = nothing,
    model_scope::AbstractString = "reduced",
    fba_variant::AbstractString = "fba",
    quadratic_penalty::Real = 0.0,
    l1_penalty::Real = 0.0,
)
    normalized_model_scope = _normalize_dfba_model_scope(model_scope)
    normalized_dynamic_control_schedule = _normalize_dfba_dynamic_control_schedule(dynamic_control_schedule)
    flux_rxn_ids = _dfba_flux_rxn_ids(reaction_map, params, normalized_model_scope)
    n_fluxes = length(flux_rxn_ids)
    n_time = size(states, 2)
    normalized_dynamic_control_schedule === nothing || time !== nothing || error(
        "Reduced DFBA reconstruction with dynamic_control_schedule requires saved time values.",
    )
    time_values = _dfba_reconstruction_time_values(time, n_time)
    fluxes = Matrix{Float64}(undef, n_fluxes, n_time)
    mode_history = Vector{Symbol}(undef, n_time)
    rhs_status_history = Vector{String}(undef, n_time)
    mass_balance_residuals = Vector{Float64}(undef, n_time)
    max_lower_bound_violations = Vector{Float64}(undef, n_time)
    max_upper_bound_violations = Vector{Float64}(undef, n_time)
    policy_metadata = _dfba_simulation_policy_metadata(model)

    for k in 1:n_time
        if skip_sugar_depleted_states && states[3, k] + states[4, k] <= Float64(sugar_depletion_tol)
            fluxes[:, k] .= NaN
            mode_history[k] = :sugar_depleted
            rhs_status_history[k] = "NOT_EVALUATED_SUGAR_DEPLETION"
            mass_balance_residuals[k] = NaN
            max_lower_bound_violations[k] = NaN
            max_upper_bound_violations[k] = NaN
            continue
        end

        solve_counter !== nothing && (solve_counter[] += 1)
        effective_params = _dfba_effective_params(
            params,
            normalized_dynamic_control_schedule,
            time_values[k],
        )
        rhs_result = compute_dfba_rhs(
            model,
            reaction_map,
            view(states, :, k);
            params = effective_params,
            optimizer = optimizer,
            silent = silent,
            atol = lp_atol,
            fba_variant = fba_variant,
            quadratic_penalty = quadratic_penalty,
            l1_penalty = l1_penalty,
        )

        for (i, rxn_id) in enumerate(flux_rxn_ids)
            fluxes[i, k] = _dfba_reconstructed_flux_value(model, rhs_result, rxn_id)
        end

        mode_history[k] = rhs_result.mode
        rhs_status_history[k] = _dfba_rhs_status_string(rhs_result.fba)
        mass_balance_residuals[k] = rhs_result.fba.mass_balance_residual
        max_lower_bound_violations[k] = rhs_result.fba.max_lower_bound_violation
        max_upper_bound_violations[k] = rhs_result.fba.max_upper_bound_violation
        policy_metadata = _dfba_simulation_policy_metadata(rhs_result)
    end

    return (
        fluxes = fluxes,
        flux_rxn_ids = flux_rxn_ids,
        mode_history = mode_history,
        rhs_status_history = rhs_status_history,
        mass_balance_residuals = mass_balance_residuals,
        max_lower_bound_violations = max_lower_bound_violations,
        max_upper_bound_violations = max_upper_bound_violations,
        policy_metadata = policy_metadata,
    )
end

function _empty_dfba_history(model::MetabolicModel)
    return (
        fluxes = nothing,
        flux_rxn_ids = String[],
        mode_history = Symbol[],
        rhs_status_history = String[],
        mass_balance_residuals = Float64[],
        max_lower_bound_violations = Float64[],
        max_upper_bound_violations = Float64[],
        policy_metadata = _dfba_simulation_policy_metadata(model),
    )
end

function _negative_state_diagnostics(states::AbstractMatrix)
    min_by_state = [minimum(view(states, i, :)) for i in axes(states, 1)]
    locations = Tuple{Int, Int}[]
    for j in axes(states, 2), i in axes(states, 1)
        if states[i, j] < 0.0
            push!(locations, (i, j))
        end
    end

    return (
        min_state_value = minimum(min_by_state),
        min_by_state = Float64.(min_by_state),
        locations = locations,
        has_negative_saved_states = !isempty(locations),
    )
end

function _validate_reduced_dfba_history_consistency(reconstruction, states::AbstractMatrix)
    n_time = size(states, 2)
    n_fluxes = length(reconstruction.flux_rxn_ids)

    if reconstruction.fluxes === nothing
        n_fluxes == 0 || error("Skipped reduced DFBA reconstruction must not report flux reaction IDs.")
        isempty(reconstruction.mode_history) || error("Skipped reduced DFBA reconstruction must have empty mode history.")
        isempty(reconstruction.rhs_status_history) || error(
            "Skipped reduced DFBA reconstruction must have empty RHS status history.",
        )
        isempty(reconstruction.mass_balance_residuals) || error(
            "Skipped reduced DFBA reconstruction must have empty mass-balance residual history.",
        )
        isempty(reconstruction.max_lower_bound_violations) || error(
            "Skipped reduced DFBA reconstruction must have empty lower-bound violation history.",
        )
        isempty(reconstruction.max_upper_bound_violations) || error(
            "Skipped reduced DFBA reconstruction must have empty upper-bound violation history.",
        )
        return nothing
    end

    size(reconstruction.fluxes) == (n_fluxes, n_time) || error(
        "Reduced DFBA reconstructed flux history must be n_fluxes x n_time. " *
        "Got $(size(reconstruction.fluxes)) for $n_fluxes fluxes and $n_time saved states.",
    )
    length(reconstruction.mode_history) == n_time || error(
        "Reduced DFBA mode history length $(length(reconstruction.mode_history)) does not match $n_time saved states.",
    )
    length(reconstruction.rhs_status_history) == n_time || error(
        "Reduced DFBA RHS status history length $(length(reconstruction.rhs_status_history)) does not match $n_time saved states.",
    )
    length(reconstruction.mass_balance_residuals) == n_time || error(
        "Reduced DFBA mass-balance residual history length $(length(reconstruction.mass_balance_residuals)) does not match $n_time saved states.",
    )
    length(reconstruction.max_lower_bound_violations) == n_time || error(
        "Reduced DFBA lower-bound violation history length $(length(reconstruction.max_lower_bound_violations)) does not match $n_time saved states.",
    )
    length(reconstruction.max_upper_bound_violations) == n_time || error(
        "Reduced DFBA upper-bound violation history length $(length(reconstruction.max_upper_bound_violations)) does not match $n_time saved states.",
    )

    return nothing
end

function _build_reduced_dfba_metadata(
    reconstruction,
    states::AbstractMatrix;
    model_scope::AbstractString,
    retcode::AbstractString,
    algorithm,
    tspan::Tuple{Float64, Float64},
    saveat,
    adaptive::Bool,
    dt,
    stop_on_sugar_depletion::Bool,
    sugar_depletion_tol::Real,
    nonnegative::Bool,
    termination_reason::AbstractString,
    termination_time::Real,
    lp_reuse::Bool,
    lp_primal_start::Bool,
    lp_reuse_highs_solver::AbstractString,
    lp_basis_warm_start::Bool,
    lp_simplex_strategy::AbstractString,
    allow_experimental_lp_reuse::Bool,
    fba_variant::AbstractString,
    quadratic_penalty::Real,
    l1_penalty::Real,
    dynamic_control_schedule = nothing,
)::Dict{String, Any}
    _validate_reduced_dfba_history_consistency(reconstruction, states)
    negative_diagnostics = _negative_state_diagnostics(states)
    policy_metadata = Dict{String, Any}(reconstruction.policy_metadata)

    metadata = Dict{String, Any}(
        "model_scope" => _normalize_dfba_model_scope(model_scope),
        "state_names" => copy(REDUCED_DFBA_STATE_NAMES),
        "flux_rxn_ids" => reconstruction.flux_rxn_ids,
        "mode_history" => reconstruction.mode_history,
        "rhs_status_history" => reconstruction.rhs_status_history,
        "mass_balance_residuals" => reconstruction.mass_balance_residuals,
        "max_lower_bound_violations" => reconstruction.max_lower_bound_violations,
        "max_upper_bound_violations" => reconstruction.max_upper_bound_violations,
        "retcode" => retcode,
        "algorithm" => String(nameof(typeof(algorithm))),
        "tspan" => tspan,
        "saveat" => saveat,
        "adaptive" => adaptive,
        "dt" => dt,
        "stop_on_sugar_depletion" => stop_on_sugar_depletion,
        "sugar_depletion_tol" => Float64(sugar_depletion_tol),
        "nonnegative" => nonnegative,
        "termination_reason" => String(termination_reason),
        "termination_time" => Float64(termination_time),
        "min_state_value" => negative_diagnostics.min_state_value,
        "has_negative_saved_states" => negative_diagnostics.has_negative_saved_states,
        "negative_state_policy" =>
            "Initial states are validated when nonnegative=true; robust nonnegative enforcement is deferred.",
        "negative_state_min_by_state" => negative_diagnostics.min_by_state,
        "negative_state_locations" => negative_diagnostics.locations,
        "n_saved_points" => size(states, 2),
        "n_fluxes" => length(reconstruction.flux_rxn_ids),
        "lp_reuse" => lp_reuse,
        "fba_variant" => String(fba_variant),
        "quadratic_penalty" => Float64(quadratic_penalty),
        "l1_penalty" => Float64(l1_penalty),
        "lp_primal_start" => lp_primal_start,
        "lp_basis_warm_start" => lp_basis_warm_start,
        "lp_reuse_highs_solver" => String(lp_reuse_highs_solver),
        "lp_simplex_strategy" => String(lp_simplex_strategy),
        "lp_reuse_strategy" => lp_reuse ? "persistent_model" : "cold_rebuild",
        "lp_warm_start_strategy" => _reduced_dfba_lp_warm_start_strategy(
            lp_primal_start,
            lp_basis_warm_start,
        ),
        "lp_reuse_scope" => lp_reuse ?
            "Persistent JuMP/HiGHS LP is used for RHS evaluations; saved-state history reconstruction still uses explicit per-state LP solves." :
            "Persistent LP reuse is disabled; RHS evaluations rebuild one LP per call.",
        "allow_experimental_lp_reuse" => allow_experimental_lp_reuse,
        "experimental_lp_reuse" => lp_reuse,
        "trajectory_equivalence_checked" => false,
        "trajectory_equivalence_passed" => false,
        "scientific_output_equivalent" => !lp_reuse,
        "lp_reuse_validity_note" => lp_reuse ?
            "Persistent reduced DFBA LP reuse is an experimental ODE diagnostic path and is not currently validated as trajectory-equivalent." :
            "Default reduced DFBA ODE simulation rebuilds one LP per RHS evaluation and remains the scientific reference path.",
        "lp_reuse_history_reconstruction_policy" => reconstruction.fluxes === nothing ?
            "Saved-state flux reconstruction skipped." :
            "Saved-state flux reconstruction uses explicit per-state LP solves, not the RHS persistent LP cache.",
        "history_reconstruction_policy" => reconstruction.fluxes === nothing ?
            "Saved-state flux and diagnostic reconstruction was skipped; history vectors are empty." :
            "Saved-state flux and diagnostic reconstruction was evaluated with one LP per non-depleted saved state.",
        "sugar_depleted_rhs_status" => "NOT_EVALUATED_SUGAR_DEPLETION",
        "sugar_depleted_flux_policy" =>
            "Fluxes and diagnostics are NaN when RHS is not evaluated at sugar-depleted saved states.",
    )
    merge!(metadata, _dfba_dynamic_control_metadata(dynamic_control_schedule))
    merge!(metadata, policy_metadata)
    return metadata
end

function _dfba_dynamic_control_metadata(dynamic_control_schedule)::Dict{String, Any}
    schedule = _normalize_dfba_dynamic_control_schedule(dynamic_control_schedule)
    if schedule === nothing
        return Dict{String, Any}(
            "dynamic_control_schedule_enabled" => false,
            "dynamic_control_policy" => "disabled_static_temperature_no_additions",
            "dynamic_control_temperature_profile" => "static_params_temperature_K",
            "dynamic_control_temperature_transition_count" => 0,
            "dynamic_control_temperature_transition_width_h" => missing,
            "dynamic_control_temperature_min_C" => missing,
            "dynamic_control_temperature_max_C" => missing,
            "dynamic_control_fda_event_count" => 0,
            "dynamic_control_organic_event_count" => 0,
            "dynamic_control_fda_total_product_g_L" => 0.0,
            "dynamic_control_organic_total_product_g_L" => 0.0,
            "dynamic_control_fda_total_limit_g_L" => missing,
            "dynamic_control_organic_total_limit_g_L" => missing,
            "dynamic_control_penalty" => 0.0,
            "dynamic_control_volatilization_enabled" => false,
        )
    end

    fda_total = sum((event.total_product_g_L for event in schedule.fda_events); init = 0.0)
    organic_total = sum((event.total_product_g_L for event in schedule.organic_events); init = 0.0)
    return Dict{String, Any}(
        "dynamic_control_schedule_enabled" => true,
        "dynamic_control_policy" => "smooth_logistic_temperature_and_pump_additions",
        "dynamic_control_temperature_profile" => "smooth_piecewise_logistic",
        "dynamic_control_temperature_transition_count" => length(schedule.temperature_transition_times_h),
        "dynamic_control_temperature_transition_width_h" => schedule.temperature_transition_width_h,
        "dynamic_control_temperature_min_C" => schedule.temperature_min_C,
        "dynamic_control_temperature_max_C" => schedule.temperature_max_C,
        "dynamic_control_fda_event_count" => length(schedule.fda_events),
        "dynamic_control_organic_event_count" => length(schedule.organic_events),
        "dynamic_control_fda_total_product_g_L" => fda_total,
        "dynamic_control_organic_total_product_g_L" => organic_total,
        "dynamic_control_fda_total_limit_g_L" => schedule.fda_total_limit_g_L,
        "dynamic_control_organic_total_limit_g_L" => schedule.organic_total_limit_g_L,
        "dynamic_control_penalty" => dynamic_control_penalty(schedule),
        "dynamic_control_volatilization_enabled" => !(schedule.volatilization_model isa NoVolatilizationModel),
    )
end

function _add_reduced_dfba_runtime_metadata!(
    metadata::Dict{String, Any};
    simulation_start_time::Real,
    ode_solve_elapsed_seconds::Real,
    rhs_elapsed_seconds::Real,
    rhs_call_count::Integer,
    history_reconstruction_elapsed_seconds::Real,
    flux_reconstruction_solve_count::Integer,
    reconstruct_fluxes::Bool,
    dfba_context = nothing,
)
    rhs_lp_solve_count = Int(rhs_call_count)
    flux_solve_count = Int(flux_reconstruction_solve_count)
    metadata["simulation_elapsed_seconds"] = max(0.0, Base.time() - Float64(simulation_start_time))
    metadata["ode_solve_elapsed_seconds"] = max(0.0, Float64(ode_solve_elapsed_seconds))
    metadata["rhs_elapsed_seconds"] = max(0.0, Float64(rhs_elapsed_seconds))
    metadata["history_reconstruction_elapsed_seconds"] =
        max(0.0, Float64(history_reconstruction_elapsed_seconds))
    metadata["rhs_call_count"] = Int(rhs_call_count)
    metadata["rhs_lp_solve_count"] = rhs_lp_solve_count
    metadata["flux_reconstruction_solve_count"] = flux_solve_count
    metadata["total_lp_solve_count"] = rhs_lp_solve_count + flux_solve_count
    metadata["reconstruct_fluxes"] = reconstruct_fluxes
    metadata["lp_reuse_build_elapsed_seconds"] =
        dfba_context === nothing ? 0.0 : max(0.0, Float64(dfba_context.lp_reuse_build_elapsed_seconds))
    metadata["lp_reuse_update_elapsed_seconds"] =
        dfba_context === nothing ? 0.0 : max(0.0, Float64(dfba_context.lp_reuse_update_elapsed_seconds[]))
    metadata["lp_reuse_solve_elapsed_seconds"] =
        dfba_context === nothing ? 0.0 : max(0.0, Float64(dfba_context.lp_reuse_solve_elapsed_seconds[]))
    metadata["lp_reuse_warm_start_applied_count"] =
        dfba_context === nothing ? 0 : Int(dfba_context.lp_reuse_warm_start_applied_count[])
    metadata["lp_reuse_basis_warm_start_applied_count"] =
        dfba_context === nothing ? 0 : Int(dfba_context.lp_reuse_basis_warm_start_applied_count[])
    metadata["lp_reuse_basis_warm_start_failed_count"] =
        dfba_context === nothing ? 0 : Int(dfba_context.lp_reuse_basis_warm_start_failed_count[])
    metadata["lp_reuse_basis_capture_count"] =
        dfba_context === nothing ? 0 : Int(dfba_context.lp_reuse_basis_capture_count[])
    metadata["lp_reuse_simplex_iterations"] =
        dfba_context === nothing ? 0 : Int(dfba_context.lp_reuse_simplex_iterations[])
    metadata["qpfba_persistent_fallback_count"] = (
        dfba_context === nothing || dfba_context.lp_cache === nothing ||
        !hasproperty(dfba_context.lp_cache, :qpfba_persistent_fallback_count)
    ) ? 0 : Int(dfba_context.lp_cache.qpfba_persistent_fallback_count[])
    return metadata
end

function _reduced_dfba_lp_warm_start_strategy(primal_start::Bool, basis_warm_start::Bool)::String
    if primal_start && basis_warm_start
        return "basis_and_primal_start"
    elseif basis_warm_start
        return "basis_warm_start"
    elseif primal_start
        return "primal_start"
    else
        return "none"
    end
end

function _dfba_flux_rxn_ids(
    reaction_map::ReactionMap,
    params::ZentenoKineticParameters,
    model_scope::AbstractString,
)::Vector{String}
    normalized_model_scope = _normalize_dfba_model_scope(model_scope)
    core_ids = [
        _dfba_required_core_reaction_id(reaction_map, "biomass_growth"),
        _dfba_required_core_reaction_id(reaction_map, "glucose_exchange"),
        _dfba_required_core_reaction_id(reaction_map, "fructose_exchange"),
        _dfba_required_core_reaction_id(reaction_map, "ethanol_exchange"),
        _dfba_required_core_reaction_id(reaction_map, "atp_maintenance"),
        _dfba_required_core_reaction_id(reaction_map, "protein_exchange"),
        _dfba_required_core_reaction_id(reaction_map, "carbohydrate_exchange"),
    ]
    if normalized_model_scope == "full"
        push!(core_ids, _dfba_required_core_reaction_id(reaction_map, "oxygen_exchange"))
    end
    amino_acid_ids = [
        _dfba_required_group_role_id(reaction_map.amino_acids, role, "amino_acids") for
        role in ZENTENO_AMINO_ACID_ROLES
    ]
    aroma_ids = [
        _dfba_required_group_role_id(reaction_map.aromas, role, "aromas") for
        role in ZENTENO_AROMA_ROLES
    ]

    return _stable_flux_reaction_ids(
        core_ids,
        params.nitrogen_source_ids,
        amino_acid_ids,
        aroma_ids;
        include_oxygen = normalized_model_scope == "full",
    )
end

function _stable_flux_reaction_ids(rxn_groups::AbstractVector...; include_oxygen::Bool = false)
    rxn_ids = String[]
    seen = Set{String}()
    for group in rxn_groups
        for rxn_id in group
            cleaned_id = strip(String(rxn_id))
            if cleaned_id == "r_0001" || cleaned_id in seen
                continue
            end
            if cleaned_id == "r_1992" && !include_oxygen
                continue
            end
            push!(seen, cleaned_id)
            push!(rxn_ids, cleaned_id)
        end
    end
    return rxn_ids
end

function _dfba_reconstructed_flux_value(
    model::MetabolicModel,
    rhs_result::DFBARHSResult,
    rxn_id::AbstractString,
)::Float64
    cleaned_id = strip(String(rxn_id))
    if haskey(rhs_result.fluxes_by_rxn, cleaned_id)
        return rhs_result.fluxes_by_rxn[cleaned_id]
    elseif cleaned_id == "r_1992"
        return _dfba_flux_value(model, rhs_result.fba, cleaned_id)
    end
    error("Missing reconstructed DFBA flux for reaction ID: $cleaned_id")
end

function _dfba_simulation_policy_metadata(model::MetabolicModel)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
    merge!(metadata, _dfba_oxygen_metadata(model))
    return metadata
end

function _dfba_simulation_policy_metadata(rhs_result::DFBARHSResult)::Dict{String, Any}
    keys_to_copy = (
        "oxygen_derivative_policy",
        "oxygen_exchange_reaction_id",
        "oxygen_exchange_present",
        "oxygen_exchange_closed",
        "oxygen_exchange_lb",
        "oxygen_exchange_ub",
        "carbohydrate_derivative_policy",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
    )
    return Dict{String, Any}(key => rhs_result.metadata[key] for key in keys_to_copy)
end
