const SEQUENTIAL_MODEL_COMPARISON_PLOT_WIDTH = 1080
const SEQUENTIAL_MODEL_COMPARISON_REDUCED_COLOR = "#2563eb"
const SEQUENTIAL_MODEL_COMPARISON_FULL_COLOR = "#d97706"
const SEQUENTIAL_MODEL_COMPARISON_DFVB_COLOR = "#0f766e"
const SEQUENTIAL_MODEL_COMPARISON_MATLAB_COLOR = "#7c3aed"
const SEQUENTIAL_MODEL_COMPARISON_SECONDARY_COLOR = "#64748b"
const SEQUENTIAL_MODEL_COMPARISON_CORE_STATES = ["biomass", "glucose", "fructose", "ethanol", "oxygen"]
const SEQUENTIAL_MODEL_COMPARISON_RMSE_STATES = [
    "biomass",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "carbohydrate",
]
const SEQUENTIAL_MODEL_COMPARISON_RUNTIME_METRICS = [
    "simulation_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
]

"""
    write_sequential_model_comparison_plots(comparison, output_dir; overwrite=false)

Write dependency-free SVG plots for a consolidated state-only sequential
DFBA/DFVB comparison.
"""
function write_sequential_model_comparison_plots(
    comparison::SequentialModelComparisonResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Sequential model comparison plot output_dir exists and is not a directory: $output_path")
    end
    mkpath(output_path)

    paths = Dict{String, String}(
        "core_states" => joinpath(output_path, "sequential_model_core_states.svg"),
        "state_rmse" => joinpath(output_path, "sequential_model_state_rmse.svg"),
        "runtime_counters" => joinpath(output_path, "sequential_model_runtime_counters.svg"),
    )
    for path in values(paths)
        _prepare_sequential_model_plot_output_path(path, overwrite)
    end

    write(paths["core_states"], _sequential_model_core_states_svg(comparison))
    write(paths["state_rmse"], _sequential_model_state_rmse_svg(comparison))
    write(paths["runtime_counters"], _sequential_model_runtime_counters_svg(comparison))
    return paths
end

function _prepare_sequential_model_plot_output_path(path::AbstractString, overwrite::Bool)
    if isfile(path) && !overwrite
        error("Sequential model comparison plot output file already exists and overwrite=false: $(String(path))")
    end
    return nothing
end

function _sequential_model_core_states_svg(comparison::SequentialModelComparisonResult)::String
    table = comparison.aligned_timeseries_table
    time = _sequential_model_plot_numeric_column(table, "time")
    width = SEQUENTIAL_MODEL_COMPARISON_PLOT_WIDTH
    panel_height = 124
    top = 62
    bottom = 44
    height = top + bottom + panel_height * length(SEQUENTIAL_MODEL_COMPARISON_CORE_STATES)
    panel_left = 106.0
    panel_right = 44.0
    plot_width = width - panel_left - panel_right

    io = IOBuffer()
    _write_sequential_model_svg_header(io, width, height)
    _write_sequential_model_text(
        io,
        width / 2,
        30,
        "Consolidated sequential DFBA/DFVB core states";
        anchor = "middle",
        class = "title",
    )
    _write_sequential_model_legend(io, width - 260, 22)

    for (panel_index, state_name) in enumerate(SEQUENTIAL_MODEL_COMPARISON_CORE_STATES)
        columns = _sequential_model_state_columns(state_name)
        all(column -> column in names(table), values(columns)) || continue
        reduced = _sequential_model_plot_numeric_column(table, columns.reduced)
        full = _sequential_model_plot_numeric_column(table, columns.full)
        julia_dfvb = _sequential_model_plot_numeric_column(table, columns.julia_dfvb)
        matlab = _sequential_model_plot_numeric_column(table, columns.matlab)
        values_for_limits = vcat(reduced, full, julia_dfvb, matlab)
        panel = (
            left = panel_left,
            top = Float64(top + (panel_index - 1) * panel_height),
            plot_width = plot_width,
            plot_height = panel_height - 36.0,
        )
        x_min, x_max = _sequential_model_expanded_limits(minimum(time), maximum(time))
        y_min, y_max = _sequential_model_expanded_limits(minimum(values_for_limits), maximum(values_for_limits))
        x_scale(value) = panel.left + (value - x_min) / (x_max - x_min) * panel.plot_width
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height

        _write_sequential_model_panel_axes(io, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
        _write_sequential_model_text(io, panel.left - 10, panel.top + 16, state_name; anchor = "end", class = "small-label")
        _write_sequential_model_polyline(io, time, reduced, x_scale, y_scale, SEQUENTIAL_MODEL_COMPARISON_REDUCED_COLOR)
        _write_sequential_model_polyline(io, time, full, x_scale, y_scale, SEQUENTIAL_MODEL_COMPARISON_FULL_COLOR)
        _write_sequential_model_polyline(io, time, julia_dfvb, x_scale, y_scale, SEQUENTIAL_MODEL_COMPARISON_DFVB_COLOR)
        _write_sequential_model_polyline(io, time, matlab, x_scale, y_scale, SEQUENTIAL_MODEL_COMPARISON_MATLAB_COLOR)
    end

    _write_sequential_model_text(io, width / 2, height - 16, "time (h)"; anchor = "middle", class = "axis-label")
    _write_sequential_model_svg_footer(io)
    return String(take!(io))
end

function _sequential_model_state_rmse_svg(comparison::SequentialModelComparisonResult)::String
    table = comparison.state_metrics_table
    row_indices = [
        findfirst(==(state_name), String.(table[!, "state_name"])) for
        state_name in SEQUENTIAL_MODEL_COMPARISON_RMSE_STATES
    ]
    filter!(!isnothing, row_indices)
    isempty(row_indices) && error("Sequential model RMSE plot requires at least one selected state.")

    labels = String.(table[row_indices, "state_name"])
    metrics = [
        ("rmse_reduced_vs_full", SEQUENTIAL_MODEL_COMPARISON_REDUCED_COLOR),
        ("rmse_julia_dfvb_vs_full", SEQUENTIAL_MODEL_COMPARISON_DFVB_COLOR),
        ("rmse_julia_dfvb_vs_matlab", SEQUENTIAL_MODEL_COMPARISON_MATLAB_COLOR),
    ]
    values = [
        _sequential_model_plot_numeric_column(table[row_indices, :], metric) for
        (metric, _) in metrics
    ]

    width = SEQUENTIAL_MODEL_COMPARISON_PLOT_WIDTH
    height = 450
    panel = (
        left = 92.0,
        top = 70.0,
        plot_width = width - 136.0,
        plot_height = height - 150.0,
    )
    max_value = maximum(vcat(values...))
    y_min, y_max = _sequential_model_expanded_limits(0.0, max(max_value, eps(Float64)))
    y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height
    zero_y = y_scale(0.0)
    group_width = panel.plot_width / length(labels)
    series_width = min(18.0, group_width / (length(metrics) + 1.0))

    io = IOBuffer()
    _write_sequential_model_svg_header(io, width, height)
    _write_sequential_model_text(io, width / 2, 28, "State RMSE diagnostics"; anchor = "middle", class = "title")
    _write_sequential_model_metric_legend(io, width - 300, 42, metrics)
    _write_sequential_model_y_axis(io, panel, y_min, y_max, y_scale)

    for (i, label) in enumerate(labels)
        group_center = panel.left + (i - 0.5) * group_width
        for (j, ((_, color), series_values)) in enumerate(zip(metrics, values))
            value = series_values[i]
            x = group_center + (j - (length(metrics) + 1) / 2) * series_width - series_width / 2
            y = y_scale(value)
            height_value = max(1.0, zero_y - y)
            println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - height_value; digits = 2))\" width=\"$(round(series_width; digits = 2))\" height=\"$(round(height_value; digits = 2))\" fill=\"$color\" />")
        end
        _write_sequential_model_text(
            io,
            group_center,
            zero_y + 18,
            _sequential_model_clip_label(label, 18);
            anchor = "middle",
            class = "tick",
        )
    end
    _write_sequential_model_text(io, width / 2, height - 18, "state"; anchor = "middle", class = "axis-label")
    _write_sequential_model_rotated_text(io, 18, panel.top + panel.plot_height / 2, "RMSE", -90.0; class = "axis-label")
    _write_sequential_model_svg_footer(io)
    return String(take!(io))
end

function _sequential_model_runtime_counters_svg(comparison::SequentialModelComparisonResult)::String
    summary = comparison.summary_table
    width = SEQUENTIAL_MODEL_COMPARISON_PLOT_WIDTH
    panel_height = 132
    top = 78
    bottom = 36
    height = top + bottom + panel_height * length(SEQUENTIAL_MODEL_COMPARISON_RUNTIME_METRICS)
    panel_left = 154.0
    panel_width = width - panel_left - 54.0
    sources = [
        ("reduced_dfba", SEQUENTIAL_MODEL_COMPARISON_REDUCED_COLOR),
        ("full_dfba", SEQUENTIAL_MODEL_COMPARISON_FULL_COLOR),
        ("julia_dfvb", SEQUENTIAL_MODEL_COMPARISON_DFVB_COLOR),
    ]

    io = IOBuffer()
    _write_sequential_model_svg_header(io, width, height)
    _write_sequential_model_text(io, width / 2, 28, "Sequential model runtime counters"; anchor = "middle", class = "title")
    _write_sequential_model_text(
        io,
        width / 2,
        52,
        "matlab_dfvb_baseline is artifact-only; runtime counters are not applicable.";
        anchor = "middle",
        class = "small-label",
    )
    _write_sequential_model_source_legend(io, width - 280, 70, sources)

    for (panel_index, metric) in enumerate(SEQUENTIAL_MODEL_COMPARISON_RUNTIME_METRICS)
        metric_values = [
            _sequential_model_summary_metric(summary, source, metric) for
            (source, _) in sources
        ]
        panel = (
            left = panel_left,
            top = Float64(top + (panel_index - 1) * panel_height),
            plot_width = panel_width,
            plot_height = panel_height - 38.0,
        )
        max_value = max(maximum(metric_values), eps(Float64))
        y_min, y_max = _sequential_model_expanded_limits(0.0, max_value)
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height
        zero_y = y_scale(0.0)
        group_width = panel.plot_width / length(sources)
        bar_width = min(76.0, group_width * 0.32)

        _write_sequential_model_y_axis(io, panel, y_min, y_max, y_scale)
        _write_sequential_model_text(io, panel.left - 12, panel.top + 16, metric; anchor = "end", class = "small-label")
        for (i, ((source, color), value)) in enumerate(zip(sources, metric_values))
            x = panel.left + (i - 0.5) * group_width - bar_width / 2
            _write_sequential_model_bar(io, x, bar_width, zero_y, y_scale, value, color, source)
        end
    end

    _write_sequential_model_svg_footer(io)
    return String(take!(io))
end

function _sequential_model_state_columns(state_name::AbstractString)
    prefix = lowercase(String(state_name))
    return (
        reduced = "$(prefix)_reduced_dfba",
        full = "$(prefix)_full_dfba",
        julia_dfvb = "$(prefix)_julia_dfvb",
        matlab = "$(prefix)_matlab_dfvb",
    )
end

function _sequential_model_plot_numeric_column(table::DataFrame, column::AbstractString)::Vector{Float64}
    column in names(table) || error("Sequential model comparison plot table is missing column $(String(column)).")
    return _dfvb_matlab_numeric_vector(table[!, column], String(column))
end

function _sequential_model_summary_metric(summary::DataFrame, source::AbstractString, column::AbstractString)::Float64
    row_index = findfirst(==(String(source)), String.(summary[!, "source"]))
    row_index === nothing && error("Sequential model comparison summary is missing source $(String(source)).")
    value = summary[row_index, column]
    (value === missing || value === nothing) && return 0.0
    return Float64(value)
end

function _write_sequential_model_bar(io::IO, x, bar_width, zero_y, y_scale, value, color, label)
    y = y_scale(value)
    height_value = max(1.0, zero_y - y)
    println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - height_value; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(height_value; digits = 2))\" fill=\"$color\" />")
    _write_sequential_model_text(
        io,
        x + bar_width / 2,
        zero_y + 18,
        _sequential_model_clip_label(label, 18);
        anchor = "middle",
        class = "tick",
    )
    _write_sequential_model_text(
        io,
        x + bar_width / 2,
        y - 7,
        _sequential_model_format_value(value);
        anchor = "middle",
        class = "small-label",
    )
    return nothing
end

function _write_sequential_model_polyline(io::IO, times, values, x_scale, y_scale, color)
    points = join(
        ["$(round(x_scale(times[i]); digits = 2)),$(round(y_scale(values[i]); digits = 2))" for i in eachindex(times)],
        " ",
    )
    println(io, "<polyline class=\"series\" fill=\"none\" stroke=\"$color\" points=\"$points\" />")
    return nothing
end

function _write_sequential_model_panel_axes(io::IO, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
    for i in 0:2
        x_value = x_min + i * (x_max - x_min) / 2
        x = x_scale(x_value)
        println(io, "<line class=\"grid\" x1=\"$(round(x; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(x; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
        _write_sequential_model_text(io, x, panel.top + panel.plot_height + 16, _sequential_model_format_value(x_value); anchor = "middle", class = "tick")
    end
    for i in 0:2
        y_value = y_min + i * (y_max - y_min) / 2
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_sequential_model_text(io, panel.left - 8, y + 4, _sequential_model_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _write_sequential_model_y_axis(io::IO, panel, y_min, y_max, y_scale)
    for i in 0:3
        y_value = y_min + i * (y_max - y_min) / 3
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_sequential_model_text(io, panel.left - 8, y + 4, _sequential_model_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _write_sequential_model_legend(io::IO, x, y)
    entries = [
        ("reduced_dfba", SEQUENTIAL_MODEL_COMPARISON_REDUCED_COLOR),
        ("full_dfba", SEQUENTIAL_MODEL_COMPARISON_FULL_COLOR),
        ("julia_dfvb", SEQUENTIAL_MODEL_COMPARISON_DFVB_COLOR),
        ("matlab_dfvb_baseline", SEQUENTIAL_MODEL_COMPARISON_MATLAB_COLOR),
    ]
    _write_sequential_model_source_legend(io, x, y, entries)
    return nothing
end

function _write_sequential_model_source_legend(io::IO, x, y, entries)
    for (i, (label, color)) in enumerate(entries)
        item_y = y + (i - 1) * 18.0
        println(io, "<line x1=\"$(round(Float64(x); digits = 2))\" y1=\"$(round(item_y; digits = 2))\" x2=\"$(round(Float64(x + 24); digits = 2))\" y2=\"$(round(item_y; digits = 2))\" stroke=\"$color\" stroke-width=\"2.8\" />")
        _write_sequential_model_text(io, x + 32, item_y + 4, label; class = "tick")
    end
    return nothing
end

function _write_sequential_model_metric_legend(io::IO, x, y, entries)
    for (i, (label, color)) in enumerate(entries)
        item_y = y + (i - 1) * 18.0
        println(io, "<rect x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(item_y - 9; digits = 2))\" width=\"16\" height=\"10\" fill=\"$color\" />")
        _write_sequential_model_text(io, x + 24, item_y, label; class = "tick")
    end
    return nothing
end

function _sequential_model_expanded_limits(min_value::Real, max_value::Real)
    lo = Float64(min_value)
    hi = Float64(max_value)
    if lo == hi
        delta = max(1.0, abs(lo) * 0.05)
        return lo - delta, hi + delta
    end
    padding = 0.08 * (hi - lo)
    return lo - padding, hi + padding
end

function _write_sequential_model_svg_header(io::IO, width::Int, height::Int)
    println(io, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
    println(io, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$width\" height=\"$height\" viewBox=\"0 0 $width $height\">")
    println(io, "<style>")
    println(io, "text { font-family: Arial, sans-serif; fill: #1f2937; }")
    println(io, ".title { font-size: 18px; font-weight: 700; }")
    println(io, ".axis-label { font-size: 12px; }")
    println(io, ".tick { font-size: 11px; fill: #4b5563; }")
    println(io, ".small-label { font-size: 10px; fill: #4b5563; }")
    println(io, ".grid { stroke: #e5e7eb; stroke-width: 1; }")
    println(io, ".axis { stroke: #374151; stroke-width: 1.2; }")
    println(io, ".series { stroke-width: 2.2; stroke-linejoin: round; stroke-linecap: round; }")
    println(io, "</style>")
    println(io, "<rect x=\"0\" y=\"0\" width=\"$width\" height=\"$height\" fill=\"#ffffff\" />")
    return nothing
end

function _write_sequential_model_svg_footer(io::IO)
    println(io, "</svg>")
    return nothing
end

function _write_sequential_model_text(
    io::IO,
    x,
    y,
    text::AbstractString;
    anchor::AbstractString = "start",
    class::AbstractString = "tick",
)
    println(io, "<text class=\"$class\" x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(Float64(y); digits = 2))\" text-anchor=\"$anchor\">$(_sequential_model_xml_escape(text))</text>")
    return nothing
end

function _write_sequential_model_rotated_text(
    io::IO,
    x,
    y,
    text::AbstractString,
    angle::Real;
    class::AbstractString = "tick",
)
    x_value = round(Float64(x); digits = 2)
    y_value = round(Float64(y); digits = 2)
    println(io, "<text class=\"$class\" x=\"$x_value\" y=\"$y_value\" text-anchor=\"end\" transform=\"rotate($(round(Float64(angle); digits = 2)) $x_value $y_value)\">$(_sequential_model_xml_escape(text))</text>")
    return nothing
end

function _sequential_model_format_value(value::Real)::String
    converted = Float64(value)
    if converted == 0.0
        return "0.0"
    elseif abs(converted) >= 1000 || abs(converted) < 0.001
        return string(round(converted; sigdigits = 3))
    end
    return string(round(converted; digits = 4))
end

function _sequential_model_clip_label(label::AbstractString, max_chars::Integer)::String
    text = String(label)
    length(text) <= max_chars && return text
    return first(text, max_chars - 1) * "..."
end

function _sequential_model_xml_escape(text::AbstractString)::String
    escaped = replace(String(text), "&" => "&amp;")
    escaped = replace(escaped, "<" => "&lt;")
    escaped = replace(escaped, ">" => "&gt;")
    escaped = replace(escaped, "\"" => "&quot;")
    return replace(escaped, "'" => "&apos;")
end
