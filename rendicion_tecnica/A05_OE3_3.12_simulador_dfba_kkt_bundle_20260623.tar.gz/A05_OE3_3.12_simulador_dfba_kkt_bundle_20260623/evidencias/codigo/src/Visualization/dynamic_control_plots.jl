const DYNAMIC_CONTROL_PARETO_PLOT_SPECS = (
    sugar_aroma = (
        filename = "pareto_final_sugar_vs_aroma.svg",
        x_column = "final_total_sugar",
        y_column = "aroma_desirability_score",
        title = "Final sugar vs aroma desirability",
        x_label = "final total sugar (g/L)",
        y_label = "aroma desirability score",
    ),
    sugar_energy = (
        filename = "pareto_final_sugar_vs_energy.svg",
        x_column = "final_total_sugar",
        y_column = "cooling_energy_proxy_unweighted",
        title = "Final sugar vs cooling-energy proxy",
        x_label = "final total sugar (g/L)",
        y_label = "cooling-energy proxy",
    ),
    sugar_nutrient = (
        filename = "pareto_final_sugar_vs_nutrient.svg",
        x_column = "final_total_sugar",
        y_column = "nutrient_total_product_g_L",
        title = "Final sugar vs nutrient dose",
        x_label = "final total sugar (g/L)",
        y_label = "total nutrient product (g/L)",
    ),
    productivity_aroma = (
        filename = "pareto_productivity_vs_aroma.svg",
        x_column = "productivity_sugar_excess_auc_normalized",
        y_column = "aroma_desirability_score",
        title = "Productivity sugar-excess AUC vs aroma desirability",
        x_label = "normalized sugar-excess AUC",
        y_label = "aroma desirability score",
    ),
    productivity_thermal = (
        filename = "pareto_productivity_vs_thermal_energy.svg",
        x_column = "productivity_sugar_excess_auc_normalized",
        y_column = "thermal_energy_proxy_unweighted",
        title = "Productivity sugar-excess AUC vs thermal energy",
        x_label = "normalized sugar-excess AUC",
        y_label = "thermal-energy proxy",
    ),
)

"""
    write_dynamic_control_schedule_plots(schedule, output_dir; kwargs...)

Write SVG plots for a smooth dynamic-control schedule: temperature, cumulative
nutrient additions, and pump rates.
"""
function write_dynamic_control_schedule_plots(
    schedule::DynamicControlSchedule,
    output_dir::AbstractString;
    start_h::Real = 0.0,
    stop_h::Real = 168.0,
    dt_h::Real = 0.5,
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    mkpath(output_path)
    table = DataFrame(
        sample_dynamic_control_schedule(
            schedule;
            start_h = start_h,
            stop_h = stop_h,
            dt_h = dt_h,
        ),
    )
    paths = Dict{String, String}()
    paths["temperature"] = write_trajectory_plot(
        table,
        joinpath(output_path, "control_temperature.svg");
        variables = ["temperature_C"],
        time_column = "time_h",
        title = "Dynamic temperature control",
        y_label = "temperature (C)",
        overwrite = overwrite,
    )
    paths["nutrient_cumulative"] = write_trajectory_plot(
        table,
        joinpath(output_path, "control_nutrient_cumulative.svg");
        variables = [
            "fda_product_cumulative_g_L",
            "organic_product_cumulative_g_L",
            "fda_nitrogen_cumulative_gN_L",
            "organic_nitrogen_cumulative_gN_L",
        ],
        time_column = "time_h",
        title = "Cumulative nutrient additions",
        y_label = "cumulative addition",
        overwrite = overwrite,
    )
    paths["nutrient_rates"] = write_trajectory_plot(
        table,
        joinpath(output_path, "control_nutrient_rates.svg");
        variables = [
            "fda_product_rate_g_L_h",
            "organic_product_rate_g_L_h",
            "fda_nitrogen_rate_gN_L_h",
            "organic_nitrogen_rate_gN_L_h",
        ],
        time_column = "time_h",
        title = "Nutrient pump rates",
        y_label = "addition rate",
        overwrite = overwrite,
    )
    return paths
end

"""
    write_dynamic_control_candidate_plots(evaluation, output_dir; kwargs...)

Write trajectory and control-profile plots for one evaluated dynamic-control
candidate.
"""
function write_dynamic_control_candidate_plots(
    evaluation::DynamicControlObjectiveResult,
    output_dir::AbstractString;
    candidate_id::AbstractString = "",
    horizon_h::Real = evaluation.summary["final_time"],
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    mkpath(output_path)
    paths = Dict{String, String}()
    trajectory_paths = write_default_trajectory_plots(
        evaluation.simulation,
        joinpath(output_path, "trajectory");
        overwrite = overwrite,
    )
    for (key, path) in trajectory_paths
        paths["trajectory_$key"] = path
    end
    schedule_paths = write_dynamic_control_schedule_plots(
        evaluation.schedule,
        joinpath(output_path, "schedule");
        start_h = 0.0,
        stop_h = Float64(horizon_h),
        overwrite = overwrite,
    )
    for (key, path) in schedule_paths
        paths["schedule_$key"] = path
    end
    if !isempty(strip(String(candidate_id)))
        write(joinpath(output_path, "candidate_id.txt"), String(candidate_id) * "\n")
        paths["candidate_id"] = joinpath(output_path, "candidate_id.txt")
    end
    return paths
end

"""
    write_dynamic_control_pareto_plots(candidate_table, output_dir; kwargs...)

Write simple SVG scatter plots for DOE/Pareto inspection. Selected candidates
are highlighted and labelled when `selected_for_review`/`selection_rank`
columns are present.
"""
function write_dynamic_control_pareto_plots(
    candidate_table::DataFrame,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    mkpath(output_path)
    paths = Dict{String, String}()
    for key in keys(DYNAMIC_CONTROL_PARETO_PLOT_SPECS)
        spec = getproperty(DYNAMIC_CONTROL_PARETO_PLOT_SPECS, key)
        if !(spec.x_column in names(candidate_table)) || !(spec.y_column in names(candidate_table))
            continue
        end
        path = joinpath(output_path, spec.filename)
        _write_dynamic_control_scatter_plot(
            candidate_table,
            path;
            x_column = spec.x_column,
            y_column = spec.y_column,
            title = spec.title,
            x_label = spec.x_label,
            y_label = spec.y_label,
            overwrite = overwrite,
        )
        paths[String(key)] = path
    end
    return paths
end

function _write_dynamic_control_scatter_plot(
    table::DataFrame,
    path::AbstractString;
    x_column::AbstractString,
    y_column::AbstractString,
    title::AbstractString,
    x_label::AbstractString,
    y_label::AbstractString,
    overwrite::Bool,
    width::Integer = DEFAULT_TRAJECTORY_PLOT_WIDTH,
    height::Integer = DEFAULT_TRAJECTORY_PLOT_HEIGHT,
)::String
    plot_path = normpath(String(path))
    _prepare_plot_output_path(plot_path, overwrite)
    _validate_dynamic_control_scatter_columns(table, x_column, y_column)
    svg = _dynamic_control_scatter_svg(
        table,
        x_column,
        y_column;
        title = title,
        x_label = x_label,
        y_label = y_label,
        width = Int(width),
        height = Int(height),
    )
    write(plot_path, svg)
    return plot_path
end

function _validate_dynamic_control_scatter_columns(
    table::DataFrame,
    x_column::AbstractString,
    y_column::AbstractString,
)
    nrow(table) > 0 || error("Dynamic-control Pareto plot requires at least one row.")
    for column in ("candidate_id", x_column, y_column)
        String(column) in names(table) ||
            error("Dynamic-control Pareto plot table is missing column: $(String(column)).")
    end
    return nothing
end

function _dynamic_control_scatter_svg(
    table::DataFrame,
    x_column::AbstractString,
    y_column::AbstractString;
    title::AbstractString,
    x_label::AbstractString,
    y_label::AbstractString,
    width::Int,
    height::Int,
)::String
    xs = Float64.(table[!, x_column])
    ys = Float64.(table[!, y_column])
    all(isfinite, xs) || error("Dynamic-control Pareto x values must be finite.")
    all(isfinite, ys) || error("Dynamic-control Pareto y values must be finite.")
    x_min, x_max = _expanded_limits(minimum(xs), maximum(xs))
    y_min, y_max = _expanded_limits(minimum(ys), maximum(ys))
    layout = _plot_layout(width, height)
    x_scale(value) = layout.left + (value - x_min) / (x_max - x_min) * layout.plot_width
    y_scale(value) = layout.top + (y_max - value) / (y_max - y_min) * layout.plot_height

    io = IOBuffer()
    _write_svg_header(io, width, height)
    _write_text(io, width / 2, 26, title; anchor = "middle", class = "title")
    _write_axes(io, layout, x_min, x_max, y_min, y_max, x_scale, y_scale)
    _write_text(io, width / 2, height - 18, x_label; anchor = "middle", class = "axis-label")
    _write_rotated_text(io, 18, layout.top + layout.plot_height / 2, y_label)

    has_pareto = "pareto_candidate" in names(table)
    has_selected = "selected_for_review" in names(table)
    has_rank = "selection_rank" in names(table)
    for index in 1:nrow(table)
        candidate_id = String(table[index, "candidate_id"])
        selected = has_selected && Bool(table[index, "selected_for_review"])
        pareto = has_pareto && Bool(table[index, "pareto_candidate"])
        color = selected ? "#d62728" : pareto ? "#1f77b4" : "#7a7f87"
        radius = selected ? 5.4 : pareto ? 4.4 : 3.5
        x = round(x_scale(xs[index]); digits = 2)
        y = round(y_scale(ys[index]); digits = 2)
        println(
            io,
            "<circle cx=\"$x\" cy=\"$y\" r=\"$radius\" fill=\"$color\" opacity=\"0.88\"><title>$(_xml_escape(candidate_id))</title></circle>",
        )
        if selected
            rank_text = has_rank ? string(Int(table[index, "selection_rank"])) : "*"
            _write_text(io, x + 7, y - 7, rank_text; class = "tick")
        end
    end
    _write_text(io, layout.left + 12, layout.top + 18, "red: selected, blue: Pareto"; class = "tick")
    _write_svg_footer(io)
    return String(take!(io))
end
