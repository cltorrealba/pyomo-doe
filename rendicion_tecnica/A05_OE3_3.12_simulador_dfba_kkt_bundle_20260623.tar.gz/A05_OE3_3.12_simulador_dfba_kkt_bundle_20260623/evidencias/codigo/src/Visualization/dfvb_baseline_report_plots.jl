const DFVB_BASELINE_REPORT_PLOT_WIDTH = 980
const DFVB_BASELINE_REPORT_CORE_STATES = ["biomass", "glucose", "fructose", "ethanol", "oxygen"]
const DFVB_BASELINE_REPORT_ALPHA_RANGE_TOP_N = 20
const DFVB_BASELINE_REPORT_LINE_COLORS = ["#2563eb", "#059669", "#d97706", "#dc2626", "#7c3aed"]
const DFVB_BASELINE_REPORT_BAR_COLOR = "#475569"
const DFVB_BASELINE_REPORT_ALPHA_BAR_COLOR = "#0f766e"

"""
    write_dfvb_baseline_report_plots(report, output_dir; overwrite=false)

Write dependency-free SVG plots for a MATLAB DFVB baseline trajectory report.
"""
function write_dfvb_baseline_report_plots(
    report::DFVBBaselineReport,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("DFVB baseline report plot output_dir exists and is not a directory: $output_path")
    end
    mkpath(output_path)

    paths = Dict{String, String}(
        "core_states" => joinpath(output_path, "dfvb_baseline_core_states.svg"),
        "state_ranges" => joinpath(output_path, "dfvb_baseline_state_ranges.svg"),
        "alpha_ranges" => joinpath(output_path, "dfvb_baseline_alpha_ranges.svg"),
    )
    for path in values(paths)
        _prepare_dfvb_baseline_report_plot_path(path, overwrite)
    end

    write(paths["core_states"], _dfvb_baseline_report_core_states_svg(report))
    write(paths["state_ranges"], _dfvb_baseline_report_state_ranges_svg(report))
    write(paths["alpha_ranges"], _dfvb_baseline_report_alpha_ranges_svg(report))
    return paths
end

function _prepare_dfvb_baseline_report_plot_path(path::AbstractString, overwrite::Bool)
    if isfile(path) && !overwrite
        error("DFVB baseline report plot output file already exists and overwrite=false: $(String(path))")
    end
    return nothing
end

function _dfvb_baseline_report_core_states_svg(report::DFVBBaselineReport)::String
    table = report.state_timeseries
    time = _dfvb_baseline_report_numeric_column(table, "time")
    width = DFVB_BASELINE_REPORT_PLOT_WIDTH
    panel_height = 122
    top = 58
    bottom = 44
    height = top + bottom + panel_height * length(DFVB_BASELINE_REPORT_CORE_STATES)
    panel_left = 96.0
    panel_right = 36.0
    plot_width = width - panel_left - panel_right

    io = IOBuffer()
    _write_dfvb_baseline_report_svg_header(io, width, height)
    _write_dfvb_baseline_report_text(io, width / 2, 30, "MATLAB DFVB baseline core states"; anchor = "middle", class = "title")
    _write_dfvb_baseline_report_text(io, width - 38, 30, "source: MATLAB export"; anchor = "end", class = "small-label")

    for (panel_index, state_name) in enumerate(DFVB_BASELINE_REPORT_CORE_STATES)
        state_name in names(table) || continue
        values = _dfvb_baseline_report_numeric_column(table, state_name)
        panel = (
            left = panel_left,
            top = Float64(top + (panel_index - 1) * panel_height),
            plot_width = plot_width,
            plot_height = panel_height - 34.0,
        )
        x_min, x_max = _dfvb_baseline_report_expanded_limits(minimum(time), maximum(time))
        y_min, y_max = _dfvb_baseline_report_expanded_limits(minimum(values), maximum(values))
        x_scale(value) = panel.left + (value - x_min) / (x_max - x_min) * panel.plot_width
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height

        color = DFVB_BASELINE_REPORT_LINE_COLORS[mod1(panel_index, length(DFVB_BASELINE_REPORT_LINE_COLORS))]
        _write_dfvb_baseline_report_panel_axes(io, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
        _write_dfvb_baseline_report_text(io, panel.left - 10, panel.top + 16, state_name; anchor = "end", class = "small-label")
        _write_dfvb_baseline_report_polyline(io, time, values, x_scale, y_scale, color)
    end

    _write_dfvb_baseline_report_text(io, width / 2, height - 16, "time (h)"; anchor = "middle", class = "axis-label")
    _write_dfvb_baseline_report_svg_footer(io)
    return String(take!(io))
end

function _dfvb_baseline_report_state_ranges_svg(report::DFVBBaselineReport)::String
    table = report.state_summary
    labels = String.(table[!, "state_name"])
    values = Float64.(table[!, "range"])
    width = DFVB_BASELINE_REPORT_PLOT_WIDTH
    height = 470
    panel = (
        left = 84.0,
        top = 58.0,
        plot_width = width - 118.0,
        plot_height = height - 170.0,
    )
    return _dfvb_baseline_report_bar_svg(
        labels,
        values,
        "MATLAB DFVB baseline state ranges",
        "state",
        "range",
        DFVB_BASELINE_REPORT_BAR_COLOR,
        width,
        height,
        panel;
        max_label_chars = 18,
        rotate_labels = true,
    )
end

function _dfvb_baseline_report_alpha_ranges_svg(report::DFVBBaselineReport)::String
    table = report.alpha_summary
    active_rows = findall(==("active"), String.(table[!, "alpha_scope"]))
    isempty(active_rows) && error("DFVB baseline alpha range plot requires active alpha summary rows.")
    active_ranges = abs.(Float64.(table[active_rows, "range"]))
    order = sortperm(active_ranges; rev = true)
    selected_count = min(length(order), DFVB_BASELINE_REPORT_ALPHA_RANGE_TOP_N)
    selected_rows = active_rows[order[1:selected_count]]
    labels = [
        "$(String(table[row, "local_alpha_id"])) -> $(String(table[row, "source_alpha_id"]))" for
        row in selected_rows
    ]
    values = Float64.(table[selected_rows, "range"])
    width = DFVB_BASELINE_REPORT_PLOT_WIDTH
    height = 500
    panel = (
        left = 92.0,
        top = 58.0,
        plot_width = width - 126.0,
        plot_height = height - 195.0,
    )
    return _dfvb_baseline_report_bar_svg(
        labels,
        values,
        "MATLAB DFVB baseline top active alpha ranges",
        "active alpha mapping",
        "range",
        DFVB_BASELINE_REPORT_ALPHA_BAR_COLOR,
        width,
        height,
        panel;
        max_label_chars = 24,
        rotate_labels = true,
    )
end

function _dfvb_baseline_report_bar_svg(
    labels::Vector{String},
    values::Vector{Float64},
    title::AbstractString,
    x_label::AbstractString,
    y_label::AbstractString,
    color::AbstractString,
    width::Int,
    height::Int,
    panel;
    max_label_chars::Int,
    rotate_labels::Bool,
)::String
    length(labels) == length(values) || error("DFVB baseline bar plot label/value length mismatch.")
    !isempty(labels) || error("DFVB baseline bar plot requires at least one value.")
    y_min, y_max = _dfvb_baseline_report_expanded_limits(0.0, max(maximum(abs.(values)), eps(Float64)))
    y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height
    zero_y = y_scale(0.0)
    group_width = panel.plot_width / length(labels)
    bar_width = min(44.0, group_width * 0.54)

    io = IOBuffer()
    _write_dfvb_baseline_report_svg_header(io, width, height)
    _write_dfvb_baseline_report_text(io, width / 2, 30, String(title); anchor = "middle", class = "title")
    _write_dfvb_baseline_report_y_axis(io, panel, y_min, y_max, y_scale)

    for (i, label) in enumerate(labels)
        x = panel.left + (i - 0.5) * group_width - bar_width / 2
        value = abs(values[i])
        y = y_scale(value)
        height_value = max(1.0, zero_y - y)
        println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - height_value; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(height_value; digits = 2))\" fill=\"$color\" />")
        _write_dfvb_baseline_report_text(io, x + bar_width / 2, y - 7, _dfvb_baseline_report_format_value(value); anchor = "middle", class = "small-label")
        clipped_label = _dfvb_baseline_report_clip_label(label, max_label_chars)
        if rotate_labels
            _write_dfvb_baseline_report_rotated_text(io, x + bar_width / 2, zero_y + 22, clipped_label, -38.0; class = "tick")
        else
            _write_dfvb_baseline_report_text(io, x + bar_width / 2, zero_y + 18, clipped_label; anchor = "middle", class = "tick")
        end
    end

    _write_dfvb_baseline_report_text(io, width / 2, height - 18, String(x_label); anchor = "middle", class = "axis-label")
    _write_dfvb_baseline_report_rotated_text(io, 18, panel.top + panel.plot_height / 2, String(y_label), -90.0; class = "axis-label")
    _write_dfvb_baseline_report_svg_footer(io)
    return String(take!(io))
end

function _dfvb_baseline_report_numeric_column(table::DataFrame, column::AbstractString)::Vector{Float64}
    column in names(table) || error("DFVB baseline plot table is missing column $(String(column)).")
    return _dfvb_baseline_numeric_vector(table[!, column], String(column))
end

function _write_dfvb_baseline_report_polyline(io::IO, times, values, x_scale, y_scale, color)
    points = join(
        ["$(round(x_scale(times[i]); digits = 2)),$(round(y_scale(values[i]); digits = 2))" for i in eachindex(times)],
        " ",
    )
    println(io, "<polyline class=\"series\" fill=\"none\" stroke=\"$color\" points=\"$points\" />")
    return nothing
end

function _write_dfvb_baseline_report_panel_axes(io::IO, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
    for i in 0:2
        x_value = x_min + i * (x_max - x_min) / 2
        x = x_scale(x_value)
        println(io, "<line class=\"grid\" x1=\"$(round(x; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(x; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
        _write_dfvb_baseline_report_text(io, x, panel.top + panel.plot_height + 16, _dfvb_baseline_report_format_value(x_value); anchor = "middle", class = "tick")
    end
    for i in 0:2
        y_value = y_min + i * (y_max - y_min) / 2
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_dfvb_baseline_report_text(io, panel.left - 8, y + 4, _dfvb_baseline_report_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _write_dfvb_baseline_report_y_axis(io::IO, panel, y_min, y_max, y_scale)
    for i in 0:3
        y_value = y_min + i * (y_max - y_min) / 3
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_dfvb_baseline_report_text(io, panel.left - 8, y + 4, _dfvb_baseline_report_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _dfvb_baseline_report_expanded_limits(min_value::Real, max_value::Real)
    lo = Float64(min_value)
    hi = Float64(max_value)
    if lo == hi
        delta = max(1.0, abs(lo) * 0.05)
        return lo - delta, hi + delta
    end
    padding = 0.08 * (hi - lo)
    return lo - padding, hi + padding
end

function _write_dfvb_baseline_report_svg_header(io::IO, width::Int, height::Int)
    println(io, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
    println(io, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$width\" height=\"$height\" viewBox=\"0 0 $width $height\">")
    println(io, "<style>")
    println(io, "text { font-family: Arial, sans-serif; fill: #1f2937; }")
    println(io, ".title { font-size: 18px; font-weight: 700; }")
    println(io, ".axis-label { font-size: 12px; }")
    println(io, ".tick { font-size: 10px; fill: #4b5563; }")
    println(io, ".small-label { font-size: 10px; fill: #4b5563; }")
    println(io, ".grid { stroke: #e5e7eb; stroke-width: 1; }")
    println(io, ".axis { stroke: #374151; stroke-width: 1.2; }")
    println(io, ".series { stroke-width: 2.1; stroke-linejoin: round; stroke-linecap: round; }")
    println(io, "</style>")
    println(io, "<rect x=\"0\" y=\"0\" width=\"$width\" height=\"$height\" fill=\"#ffffff\" />")
    return nothing
end

function _write_dfvb_baseline_report_svg_footer(io::IO)
    println(io, "</svg>")
    return nothing
end

function _write_dfvb_baseline_report_text(
    io::IO,
    x,
    y,
    text::AbstractString;
    anchor::AbstractString = "start",
    class::AbstractString = "tick",
)
    println(io, "<text class=\"$class\" x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(Float64(y); digits = 2))\" text-anchor=\"$anchor\">$(_dfvb_baseline_report_xml_escape(text))</text>")
    return nothing
end

function _write_dfvb_baseline_report_rotated_text(
    io::IO,
    x,
    y,
    text::AbstractString,
    angle::Real;
    class::AbstractString = "tick",
)
    x_value = round(Float64(x); digits = 2)
    y_value = round(Float64(y); digits = 2)
    println(io, "<text class=\"$class\" x=\"$x_value\" y=\"$y_value\" text-anchor=\"end\" transform=\"rotate($(round(Float64(angle); digits = 2)) $x_value $y_value)\">$(_dfvb_baseline_report_xml_escape(text))</text>")
    return nothing
end

function _dfvb_baseline_report_format_value(value::Real)::String
    converted = Float64(value)
    if converted == 0.0
        return "0.0"
    elseif abs(converted) >= 1000 || abs(converted) < 0.001
        return string(round(converted; sigdigits = 3))
    end
    return string(round(converted; digits = 4))
end

function _dfvb_baseline_report_clip_label(label::AbstractString, max_chars::Integer)::String
    text = String(label)
    length(text) <= max_chars && return text
    return first(text, max_chars - 1) * "..."
end

function _dfvb_baseline_report_xml_escape(text::AbstractString)::String
    escaped = replace(String(text), "&" => "&amp;")
    escaped = replace(escaped, "<" => "&lt;")
    escaped = replace(escaped, ">" => "&gt;")
    escaped = replace(escaped, "\"" => "&quot;")
    return replace(escaped, "'" => "&apos;")
end
