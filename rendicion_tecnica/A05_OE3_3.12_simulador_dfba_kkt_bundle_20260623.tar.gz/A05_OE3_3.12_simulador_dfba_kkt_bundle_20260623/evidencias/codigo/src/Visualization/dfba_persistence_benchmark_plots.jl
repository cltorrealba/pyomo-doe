const DFBA_PERSISTENCE_PLOT_WIDTH = 1040
const DFBA_PERSISTENCE_SCENARIO_STYLES = [
    ("full_dfba_cold", "full cold", "#334155"),
    ("full_dfba_persistent", "full persistent", "#d97706"),
    ("reduced_dfba_persistent", "reduced persistent", "#2563eb"),
]
const DFBA_PERSISTENCE_CORE_PLOT_STATES = ["biomass", "total_sugar", "ethanol", "oxygen"]
const DFBA_PERSISTENCE_RUNTIME_PLOT_METRICS = [
    "benchmark_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
]
const DFBA_PERSISTENCE_DIFFERENCE_PLOT_METRICS = [
    "max_abs_state_difference_vs_full_cold",
    "state_rmse_vs_full_cold",
]
const DFBA_PERSISTENCE_FINAL_STATE_PLOT_METRICS = [
    "final_biomass",
    "final_total_sugar",
    "final_ethanol",
]

"""
    write_dfba_persistence_benchmark_plots(result, output_dir; overwrite=false)

Write dependency-free SVG plots for the full-vs-reduced DFBA persistence
benchmark.
"""
function write_dfba_persistence_benchmark_plots(
    result::DFBAPersistenceBenchmarkResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("DFBA persistence benchmark plot output_dir exists and is not a directory: $output_path")
    end
    mkpath(output_path)

    paths = Dict{String, String}(
        "core_states" => joinpath(output_path, "dfba_persistence_core_states.svg"),
        "state_differences" => joinpath(output_path, "dfba_persistence_state_differences.svg"),
        "runtime_counters" => joinpath(output_path, "dfba_persistence_runtime_counters.svg"),
        "final_states" => joinpath(output_path, "dfba_persistence_final_states.svg"),
    )
    for path in values(paths)
        _prepare_dfba_persistence_plot_output_path(path, overwrite)
    end

    write(paths["core_states"], _dfba_persistence_core_states_svg(result))
    write(paths["state_differences"], _dfba_persistence_summary_bars_svg(
        result.summary_table,
        DFBA_PERSISTENCE_DIFFERENCE_PLOT_METRICS,
        "DFBA persistence state differences vs full cold",
    ))
    write(paths["runtime_counters"], _dfba_persistence_summary_bars_svg(
        result.summary_table,
        DFBA_PERSISTENCE_RUNTIME_PLOT_METRICS,
        "DFBA persistence runtime counters",
    ))
    write(paths["final_states"], _dfba_persistence_summary_bars_svg(
        result.summary_table,
        DFBA_PERSISTENCE_FINAL_STATE_PLOT_METRICS,
        "DFBA persistence final states",
    ))
    return paths
end

function _prepare_dfba_persistence_plot_output_path(path::AbstractString, overwrite::Bool)
    if isfile(path) && !overwrite
        error("DFBA persistence benchmark plot output file already exists and overwrite=false: $(String(path))")
    end
    return nothing
end

function _dfba_persistence_core_states_svg(result::DFBAPersistenceBenchmarkResult)::String
    table = result.aligned_timeseries_table
    time = _dfba_persistence_plot_numeric_column(table, "time")
    width = DFBA_PERSISTENCE_PLOT_WIDTH
    panel_height = 134
    top = 62
    bottom = 46
    height = top + bottom + panel_height * length(DFBA_PERSISTENCE_CORE_PLOT_STATES)
    layout = (
        left = 108.0,
        right = 44.0,
        plot_width = width - 108.0 - 44.0,
    )

    io = IOBuffer()
    _write_dfba_persistence_svg_header(io, width, height)
    _write_dfba_persistence_text(io, width / 2, 30, "DFBA persistence dynamic trajectories"; anchor = "middle", class = "title")
    _write_dfba_persistence_legend(io, width - 260, 30)

    x_min, x_max = _dfba_persistence_expanded_limits(minimum(time), maximum(time))
    for (panel_index, state_name) in enumerate(DFBA_PERSISTENCE_CORE_PLOT_STATES)
        panel = (
            left = layout.left,
            top = Float64(top + (panel_index - 1) * panel_height),
            plot_width = layout.plot_width,
            plot_height = panel_height - 36.0,
        )
        scenario_series = [
            (scenario_id, label, color, _dfba_persistence_plot_state_series(table, state_name, scenario_id)) for
            (scenario_id, label, color) in DFBA_PERSISTENCE_SCENARIO_STYLES
        ]
        y_values = reduce(vcat, [series for (_, _, _, series) in scenario_series])
        y_min, y_max = _dfba_persistence_expanded_limits(minimum(y_values), maximum(y_values))
        x_scale(value) = panel.left + (value - x_min) / (x_max - x_min) * panel.plot_width
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height

        _write_dfba_persistence_panel_axes(io, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
        _write_dfba_persistence_text(io, panel.left - 10, panel.top + 16, state_name; anchor = "end", class = "small-label")
        for (_, _, color, values) in scenario_series
            _write_dfba_persistence_polyline(io, time, values, x_scale, y_scale, color)
        end
    end

    _write_dfba_persistence_text(io, width / 2, height - 16, "time (h)"; anchor = "middle", class = "axis-label")
    _write_dfba_persistence_svg_footer(io)
    return String(take!(io))
end

function _dfba_persistence_summary_bars_svg(
    summary::DataFrame,
    metrics::AbstractVector{<:AbstractString},
    title::AbstractString,
)::String
    width = DFBA_PERSISTENCE_PLOT_WIDTH
    panel_height = 148
    top = 62
    bottom = 38
    height = top + bottom + panel_height * length(metrics)
    panel_left = 190.0
    panel_width = width - panel_left - 48.0

    io = IOBuffer()
    _write_dfba_persistence_svg_header(io, width, height)
    _write_dfba_persistence_text(io, width / 2, 30, title; anchor = "middle", class = "title")
    _write_dfba_persistence_legend(io, width - 260, 30)

    for (panel_index, metric) in enumerate(metrics)
        values = [
            _dfba_persistence_summary_metric(summary, scenario_id, metric) for
            (scenario_id, _, _) in DFBA_PERSISTENCE_SCENARIO_STYLES
        ]
        y_min, y_max = _dfba_persistence_expanded_limits(0.0, max(maximum(values), eps(Float64)))
        panel = (
            left = panel_left,
            top = Float64(top + (panel_index - 1) * panel_height),
            plot_width = panel_width,
            plot_height = panel_height - 42.0,
        )
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height
        zero_y = y_scale(0.0)

        _write_dfba_persistence_y_axis(io, panel, y_min, y_max, y_scale)
        _write_dfba_persistence_text(io, panel.left - 12, panel.top + 16, metric; anchor = "end", class = "small-label")

        group_width = panel.plot_width / length(values)
        bar_width = min(78.0, group_width * 0.36)
        for (i, ((_, label, color), value)) in enumerate(zip(DFBA_PERSISTENCE_SCENARIO_STYLES, values))
            x = panel.left + (i - 0.5) * group_width - bar_width / 2
            _write_dfba_persistence_bar(io, x, bar_width, zero_y, y_scale, value, color, label)
        end
    end

    _write_dfba_persistence_svg_footer(io)
    return String(take!(io))
end

function _dfba_persistence_plot_state_series(
    table::DataFrame,
    state_name::AbstractString,
    scenario_id::AbstractString,
)::Vector{Float64}
    if state_name == "total_sugar"
        glucose = _dfba_persistence_plot_numeric_column(table, "glucose_$(String(scenario_id))")
        fructose = _dfba_persistence_plot_numeric_column(table, "fructose_$(String(scenario_id))")
        return glucose .+ fructose
    end
    return _dfba_persistence_plot_numeric_column(table, "$(String(state_name))_$(String(scenario_id))")
end

function _dfba_persistence_plot_numeric_column(table::DataFrame, column::AbstractString)::Vector{Float64}
    column in names(table) || error("DFBA persistence benchmark plot table is missing column $(String(column)).")
    values = Float64.(table[!, column])
    all(isfinite, values) || error("DFBA persistence benchmark plot column $(String(column)) contains non-finite values.")
    return values
end

function _dfba_persistence_summary_metric(
    summary::DataFrame,
    scenario_id::AbstractString,
    column::AbstractString,
)::Float64
    column in names(summary) || error("DFBA persistence benchmark summary is missing column $(String(column)).")
    row_index = findfirst(==(String(scenario_id)), String.(summary[!, "scenario_id"]))
    row_index === nothing && error("DFBA persistence benchmark summary is missing scenario $(String(scenario_id)).")
    value = Float64(summary[row_index, column])
    isfinite(value) || error("DFBA persistence benchmark summary column $(String(column)) contains a non-finite value.")
    return value
end

function _write_dfba_persistence_polyline(io::IO, times, values, x_scale, y_scale, color::AbstractString)
    points = join(
        ["$(round(x_scale(times[i]); digits = 2)),$(round(y_scale(values[i]); digits = 2))" for i in eachindex(times)],
        " ",
    )
    println(io, "<polyline class=\"series\" fill=\"none\" stroke=\"$(String(color))\" points=\"$points\" />")
    return nothing
end

function _write_dfba_persistence_bar(io::IO, x, bar_width, zero_y, y_scale, value, color, label)
    y = y_scale(value)
    height_value = max(1.0, zero_y - y)
    println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - height_value; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(height_value; digits = 2))\" fill=\"$(String(color))\" />")
    _write_dfba_persistence_text(io, x + bar_width / 2, zero_y + 18, String(label); anchor = "middle", class = "tick")
    _write_dfba_persistence_text(io, x + bar_width / 2, y - 7, _dfba_persistence_format_value(value); anchor = "middle", class = "small-label")
    return nothing
end

function _write_dfba_persistence_panel_axes(io::IO, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
    for i in 0:3
        x_value = x_min + i * (x_max - x_min) / 3
        x = x_scale(x_value)
        println(io, "<line class=\"grid\" x1=\"$(round(x; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(x; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
        _write_dfba_persistence_text(io, x, panel.top + panel.plot_height + 16, _dfba_persistence_format_value(x_value); anchor = "middle", class = "tick")
    end
    for i in 0:2
        y_value = y_min + i * (y_max - y_min) / 2
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_dfba_persistence_text(io, panel.left - 8, y + 4, _dfba_persistence_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _write_dfba_persistence_y_axis(io::IO, panel, y_min, y_max, y_scale)
    for i in 0:3
        y_value = y_min + i * (y_max - y_min) / 3
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_dfba_persistence_text(io, panel.left - 8, y + 4, _dfba_persistence_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _write_dfba_persistence_legend(io::IO, x, y)
    for (i, (_, label, color)) in enumerate(DFBA_PERSISTENCE_SCENARIO_STYLES)
        item_y = y + (i - 1) * 18.0
        println(io, "<line x1=\"$(round(Float64(x); digits = 2))\" y1=\"$(round(item_y; digits = 2))\" x2=\"$(round(Float64(x + 24); digits = 2))\" y2=\"$(round(item_y; digits = 2))\" stroke=\"$(String(color))\" stroke-width=\"2.8\" />")
        _write_dfba_persistence_text(io, x + 32, item_y + 4, String(label); class = "tick")
    end
    return nothing
end

function _dfba_persistence_expanded_limits(min_value::Real, max_value::Real)
    lo = Float64(min_value)
    hi = Float64(max_value)
    if lo == hi
        delta = max(1.0, abs(lo) * 0.05)
        return lo - delta, hi + delta
    end
    padding = 0.08 * (hi - lo)
    return lo - padding, hi + padding
end

function _dfba_persistence_format_value(value::Real)::String
    x = Float64(value)
    if x == 0.0
        return "0"
    elseif abs(x) >= 1000 || abs(x) < 0.001
        return string(round(x; sigdigits = 3))
    elseif abs(x) < 1
        return string(round(x; digits = 4))
    else
        return string(round(x; digits = 3))
    end
end

function _write_dfba_persistence_svg_header(io::IO, width::Int, height::Int)
    println(io, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$width\" height=\"$height\" viewBox=\"0 0 $width $height\">")
    println(io, "<style>")
    println(io, "text { font-family: Arial, sans-serif; fill: #111827; }")
    println(io, ".title { font-size: 18px; font-weight: 700; }")
    println(io, ".axis-label { font-size: 12px; font-weight: 600; }")
    println(io, ".small-label { font-size: 11px; font-weight: 600; }")
    println(io, ".tick { font-size: 10px; fill: #374151; }")
    println(io, ".grid { stroke: #d1d5db; stroke-width: 1; }")
    println(io, ".axis { stroke: #4b5563; stroke-width: 1.2; }")
    println(io, ".series { stroke-width: 2.4; }")
    println(io, "</style>")
    println(io, "<rect x=\"0\" y=\"0\" width=\"$width\" height=\"$height\" fill=\"#ffffff\" />")
    return nothing
end

function _write_dfba_persistence_svg_footer(io::IO)
    println(io, "</svg>")
    return nothing
end

function _write_dfba_persistence_text(
    io::IO,
    x,
    y,
    text::AbstractString;
    anchor::AbstractString = "start",
    class::AbstractString = "",
)
    class_attr = isempty(class) ? "" : " class=\"$(String(class))\""
    println(io, "<text$class_attr x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(Float64(y); digits = 2))\" text-anchor=\"$(String(anchor))\">$(_dfba_persistence_escape_svg_text(text))</text>")
    return nothing
end

function _dfba_persistence_escape_svg_text(text::AbstractString)::String
    return replace(String(text), "&" => "&amp;", "<" => "&lt;", ">" => "&gt;", "\"" => "&quot;")
end
