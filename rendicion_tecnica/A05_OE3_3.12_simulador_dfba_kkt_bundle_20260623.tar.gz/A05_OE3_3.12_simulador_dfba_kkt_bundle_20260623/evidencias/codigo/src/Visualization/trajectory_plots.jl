const DEFAULT_TRAJECTORY_PLOT_WIDTH = 900
const DEFAULT_TRAJECTORY_PLOT_HEIGHT = 420
const DEFAULT_TRAJECTORY_PLOT_COLORS = [
    "#1f77b4",
    "#d62728",
    "#2ca02c",
    "#9467bd",
    "#ff7f0e",
    "#17becf",
    "#8c564b",
    "#e377c2",
]

const DEFAULT_TRAJECTORY_PLOT_GROUPS = (
    biomass_ethanol = (
        filename = "biomass_ethanol.svg",
        title = "Biomass and ethanol trajectories",
        y_label = "concentration",
        variables = ["biomass", "ethanol"],
    ),
    sugars = (
        filename = "sugars.svg",
        title = "Sugar trajectories",
        y_label = "concentration",
        variables = ["glucose", "fructose", "total_sugar"],
    ),
    nitrogen_reserves = (
        filename = "nitrogen_reserves.svg",
        title = "Nitrogen, protein, and carbohydrate trajectories",
        y_label = "concentration",
        variables = ["nitrogen", "protein", "carbohydrate"],
    ),
    aroma_products = (
        filename = "aroma_products.svg",
        title = "Aroma product trajectories",
        y_label = "concentration",
        variables = [
            "phenylethanol",
            "isoamyl_alcohol",
            "isobutanol",
            "methionol",
            "tyrosol",
            "ethyl_acetate",
        ],
    ),
)

"""
    write_trajectory_plot(result, path; variables, kwargs...)

Write a basic SVG line plot for selected state trajectories in a
`SimulationResult`. The function does not require plotting package
dependencies.
"""
function write_trajectory_plot(
    result::SimulationResult,
    path::AbstractString;
    variables::AbstractVector{<:AbstractString},
    title::AbstractString = "Trajectory plot",
    y_label::AbstractString = "value",
    overwrite::Bool = false,
    width::Integer = DEFAULT_TRAJECTORY_PLOT_WIDTH,
    height::Integer = DEFAULT_TRAJECTORY_PLOT_HEIGHT,
)::String
    states = _states_table_with_total_sugar(simulation_states_table(result))
    return write_trajectory_plot(
        states,
        path;
        variables = variables,
        title = title,
        y_label = y_label,
        overwrite = overwrite,
        width = width,
        height = height,
    )
end

"""
    write_trajectory_plot(states, path; variables, kwargs...)

Write a basic SVG line plot from a `DataFrame` that contains a `time` column
and the requested trajectory columns.
"""
function write_trajectory_plot(
    states::DataFrame,
    path::AbstractString;
    variables::AbstractVector{<:AbstractString},
    time_column::AbstractString = "time",
    title::AbstractString = "Trajectory plot",
    y_label::AbstractString = "value",
    overwrite::Bool = false,
    width::Integer = DEFAULT_TRAJECTORY_PLOT_WIDTH,
    height::Integer = DEFAULT_TRAJECTORY_PLOT_HEIGHT,
)::String
    plot_path = normpath(String(path))
    _prepare_plot_output_path(plot_path, overwrite)
    prepared_states = _states_table_with_total_sugar(states)
    _validate_plot_columns(prepared_states, time_column, variables)
    svg = _trajectory_svg(
        prepared_states,
        time_column,
        variables;
        title = title,
        y_label = y_label,
        width = Int(width),
        height = Int(height),
    )
    write(plot_path, svg)
    return plot_path
end

"""
    write_default_trajectory_plots(result, output_dir; overwrite=false)

Write a small set of SVG trajectory plots from a `SimulationResult` and return
their paths keyed by plot role.
"""
function write_default_trajectory_plots(
    result::SimulationResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    states = _states_table_with_total_sugar(simulation_states_table(result))
    diagnostics = simulation_diagnostics_table(result)
    return _write_default_trajectory_plots(
        states,
        diagnostics,
        output_dir;
        overwrite = overwrite,
    )
end

"""
    write_exported_trajectory_plots(export_dir; output_dir=joinpath(export_dir, "plots"), overwrite=false)

Write basic SVG trajectory plots from an exported simulation report directory
containing `states.csv` and optionally `diagnostics.csv`.
"""
function write_exported_trajectory_plots(
    export_dir::AbstractString;
    output_dir::AbstractString = joinpath(String(export_dir), "plots"),
    overwrite::Bool = false,
)::Dict{String, String}
    export_path = normpath(String(export_dir))
    states_path = joinpath(export_path, "states.csv")
    isfile(states_path) || error("Exported simulation states.csv not found: $states_path")

    states = _states_table_with_total_sugar(DataFrame(CSV.File(states_path)))
    diagnostics_path = joinpath(export_path, "diagnostics.csv")
    diagnostics = isfile(diagnostics_path) ? DataFrame(CSV.File(diagnostics_path)) : nothing
    return _write_default_trajectory_plots(
        states,
        diagnostics,
        output_dir;
        overwrite = overwrite,
    )
end

function _write_default_trajectory_plots(
    states::DataFrame,
    diagnostics,
    output_dir::AbstractString;
    overwrite::Bool,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    mkpath(output_path)
    paths = Dict{String, String}()

    for key in keys(DEFAULT_TRAJECTORY_PLOT_GROUPS)
        group = getproperty(DEFAULT_TRAJECTORY_PLOT_GROUPS, key)
        available_variables = [variable for variable in group.variables if variable in names(states)]
        isempty(available_variables) && continue
        plot_path = joinpath(output_path, group.filename)
        paths[String(key)] = write_trajectory_plot(
            states,
            plot_path;
            variables = available_variables,
            title = group.title,
            y_label = group.y_label,
            overwrite = overwrite,
        )
    end

    if diagnostics !== nothing && _has_nonmissing_mode_history(diagnostics)
        mode_path = joinpath(output_path, "mode_timeline.svg")
        paths["mode_timeline"] = write_mode_timeline_plot(diagnostics, mode_path; overwrite = overwrite)
    end

    return paths
end

"""
    write_mode_timeline_plot(diagnostics, path; kwargs...)

Write a basic SVG timeline for saved simulation modes from a diagnostics table.
"""
function write_mode_timeline_plot(
    diagnostics::DataFrame,
    path::AbstractString;
    time_column::AbstractString = "time",
    mode_column::AbstractString = "mode",
    title::AbstractString = "Mode timeline",
    overwrite::Bool = false,
    width::Integer = DEFAULT_TRAJECTORY_PLOT_WIDTH,
    height::Integer = 260,
)::String
    plot_path = normpath(String(path))
    _prepare_plot_output_path(plot_path, overwrite)
    _validate_plot_columns(diagnostics, time_column, [mode_column])
    svg = _mode_timeline_svg(
        diagnostics,
        time_column,
        mode_column;
        title = title,
        width = Int(width),
        height = Int(height),
    )
    write(plot_path, svg)
    return plot_path
end

function _prepare_plot_output_path(path::AbstractString, overwrite::Bool)
    parent = dirname(String(path))
    !isempty(parent) && mkpath(parent)
    if isfile(path) && !overwrite
        error("Trajectory plot output file already exists and overwrite=false: $(String(path))")
    end
    return nothing
end

function _states_table_with_total_sugar(states::DataFrame)::DataFrame
    table = copy(states)
    if "glucose" in names(table) && "fructose" in names(table) && !("total_sugar" in names(table))
        table[!, "total_sugar"] = Float64.(table[!, "glucose"]) .+ Float64.(table[!, "fructose"])
    end
    return table
end

function _validate_plot_columns(table::DataFrame, time_column::AbstractString, variables::AbstractVector{<:AbstractString})
    time_column in names(table) || error("Trajectory plot table is missing time column: $(String(time_column))")
    isempty(variables) && error("Trajectory plot requires at least one variable.")
    for variable in variables
        variable in names(table) || error("Trajectory plot table is missing variable column: $(String(variable))")
    end
    return nothing
end

function _trajectory_svg(
    table::DataFrame,
    time_column::AbstractString,
    variables::AbstractVector{<:AbstractString};
    title::AbstractString,
    y_label::AbstractString,
    width::Int,
    height::Int,
)::String
    width > 200 || error("Trajectory plot width must be greater than 200, got $width.")
    height > 160 || error("Trajectory plot height must be greater than 160, got $height.")

    times = Float64.(table[!, time_column])
    isempty(times) && error("Trajectory plot table must contain at least one time point.")
    all(isfinite, times) || error("Trajectory plot time values must be finite.")

    series = [(label = String(variable), values = Float64.(table[!, variable])) for variable in variables]
    for item in series
        length(item.values) == length(times) || error("Trajectory plot series length mismatch for $(item.label).")
        all(isfinite, item.values) || error("Trajectory plot values for $(item.label) must be finite.")
    end

    x_min, x_max = _expanded_limits(minimum(times), maximum(times))
    values = reduce(vcat, [collect(item.values) for item in series])
    y_min, y_max = _expanded_limits(minimum(values), maximum(values))
    layout = _plot_layout(width, height)

    x_scale(value) = layout.left + (value - x_min) / (x_max - x_min) * layout.plot_width
    y_scale(value) = layout.top + (y_max - value) / (y_max - y_min) * layout.plot_height

    io = IOBuffer()
    _write_svg_header(io, width, height)
    _write_text(io, width / 2, 26, title; anchor = "middle", class = "title")
    _write_axes(io, layout, x_min, x_max, y_min, y_max, x_scale, y_scale)
    _write_text(io, width / 2, height - 18, "time (h)"; anchor = "middle", class = "axis-label")
    _write_rotated_text(io, 18, layout.top + layout.plot_height / 2, y_label)

    for (i, item) in enumerate(series)
        color = DEFAULT_TRAJECTORY_PLOT_COLORS[mod1(i, length(DEFAULT_TRAJECTORY_PLOT_COLORS))]
        points = join(["$(round(x_scale(times[j]); digits = 2)),$(round(y_scale(item.values[j]); digits = 2))" for j in eachindex(times)], " ")
        println(io, "<polyline class=\"series\" fill=\"none\" stroke=\"$color\" points=\"$points\" />")
    end
    _write_legend(io, series, layout, width)
    _write_svg_footer(io)
    return String(take!(io))
end

function _mode_timeline_svg(
    table::DataFrame,
    time_column::AbstractString,
    mode_column::AbstractString;
    title::AbstractString,
    width::Int,
    height::Int,
)::String
    times = Float64.(table[!, time_column])
    modes = [_mode_string(value) for value in table[!, mode_column]]
    valid = [(time = times[i], mode = modes[i]) for i in eachindex(times) if modes[i] !== nothing]
    isempty(valid) && error("Mode timeline plot requires at least one non-missing mode.")
    all(isfinite, [item.time for item in valid]) || error("Mode timeline time values must be finite.")

    unique_modes = unique([item.mode for item in valid])
    x_min, x_max = _expanded_limits(minimum([item.time for item in valid]), maximum([item.time for item in valid]))
    layout = _plot_layout(width, height)
    band_height = layout.plot_height / max(1, length(unique_modes))
    x_scale(value) = layout.left + (value - x_min) / (x_max - x_min) * layout.plot_width

    mode_index = Dict(mode => i for (i, mode) in enumerate(unique_modes))
    io = IOBuffer()
    _write_svg_header(io, width, height)
    _write_text(io, width / 2, 26, title; anchor = "middle", class = "title")
    _write_text(io, width / 2, height - 18, "time (h)"; anchor = "middle", class = "axis-label")
    println(io, "<line class=\"axis\" x1=\"$(layout.left)\" y1=\"$(layout.top + layout.plot_height)\" x2=\"$(layout.left + layout.plot_width)\" y2=\"$(layout.top + layout.plot_height)\" />")

    for (i, mode) in enumerate(unique_modes)
        y = layout.top + (i - 0.5) * band_height
        _write_text(io, layout.left - 8, y + 4, mode; anchor = "end", class = "tick")
    end

    for (i, item) in enumerate(valid)
        next_time = i < length(valid) ? valid[i + 1].time : item.time
        x1 = x_scale(item.time)
        x2 = x_scale(next_time)
        if x2 <= x1
            x2 = min(layout.left + layout.plot_width, x1 + 8.0)
        end
        band_index = mode_index[item.mode]
        y = layout.top + (band_index - 1) * band_height + 5
        color = DEFAULT_TRAJECTORY_PLOT_COLORS[mod1(band_index, length(DEFAULT_TRAJECTORY_PLOT_COLORS))]
        println(io, "<rect class=\"mode\" x=\"$(round(x1; digits = 2))\" y=\"$(round(y; digits = 2))\" width=\"$(round(x2 - x1; digits = 2))\" height=\"$(round(max(4.0, band_height - 10); digits = 2))\" fill=\"$color\" />")
    end
    _write_svg_footer(io)
    return String(take!(io))
end

function _has_nonmissing_mode_history(diagnostics::DataFrame)::Bool
    "mode" in names(diagnostics) || return false
    return any(value -> _mode_string(value) !== nothing, diagnostics[!, "mode"])
end

function _mode_string(value)
    if value === missing || value === nothing
        return nothing
    end
    text = strip(String(value))
    isempty(text) && return nothing
    return text
end

function _expanded_limits(min_value::Real, max_value::Real)
    lo = Float64(min_value)
    hi = Float64(max_value)
    if lo == hi
        delta = max(1.0, abs(lo) * 0.05)
        return lo - delta, hi + delta
    end
    padding = 0.05 * (hi - lo)
    return lo - padding, hi + padding
end

function _plot_layout(width::Int, height::Int)
    left = 86.0
    right = 26.0
    top = 48.0
    bottom = 64.0
    return (
        left = left,
        right = right,
        top = top,
        bottom = bottom,
        plot_width = width - left - right,
        plot_height = height - top - bottom,
    )
end

function _write_svg_header(io::IO, width::Int, height::Int)
    println(io, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
    println(io, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$width\" height=\"$height\" viewBox=\"0 0 $width $height\">")
    println(io, "<style>")
    println(io, "text { font-family: Arial, sans-serif; fill: #202124; }")
    println(io, ".title { font-size: 18px; font-weight: 700; }")
    println(io, ".axis-label { font-size: 12px; }")
    println(io, ".tick { font-size: 11px; fill: #4f5661; }")
    println(io, ".grid { stroke: #d9dde3; stroke-width: 1; }")
    println(io, ".axis { stroke: #333842; stroke-width: 1.2; }")
    println(io, ".series { stroke-width: 2.2; stroke-linejoin: round; stroke-linecap: round; }")
    println(io, ".mode { opacity: 0.8; }")
    println(io, "</style>")
    println(io, "<rect x=\"0\" y=\"0\" width=\"$width\" height=\"$height\" fill=\"#ffffff\" />")
    return nothing
end

function _write_svg_footer(io::IO)
    println(io, "</svg>")
    return nothing
end

function _write_axes(io::IO, layout, x_min, x_max, y_min, y_max, x_scale, y_scale)
    for i in 0:4
        x_value = x_min + i * (x_max - x_min) / 4
        x = x_scale(x_value)
        println(io, "<line class=\"grid\" x1=\"$(round(x; digits = 2))\" y1=\"$(layout.top)\" x2=\"$(round(x; digits = 2))\" y2=\"$(layout.top + layout.plot_height)\" />")
        _write_text(io, x, layout.top + layout.plot_height + 18, _format_tick(x_value); anchor = "middle", class = "tick")

        y_value = y_min + i * (y_max - y_min) / 4
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(layout.left)\" y1=\"$(round(y; digits = 2))\" x2=\"$(layout.left + layout.plot_width)\" y2=\"$(round(y; digits = 2))\" />")
        _write_text(io, layout.left - 8, y + 4, _format_tick(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(layout.left)\" y1=\"$(layout.top + layout.plot_height)\" x2=\"$(layout.left + layout.plot_width)\" y2=\"$(layout.top + layout.plot_height)\" />")
    println(io, "<line class=\"axis\" x1=\"$(layout.left)\" y1=\"$(layout.top)\" x2=\"$(layout.left)\" y2=\"$(layout.top + layout.plot_height)\" />")
    return nothing
end

function _write_legend(io::IO, series, layout, width::Int)
    legend_x = min(width - 220.0, layout.left + 16.0)
    legend_y = layout.top + 14.0
    for (i, item) in enumerate(series)
        color = DEFAULT_TRAJECTORY_PLOT_COLORS[mod1(i, length(DEFAULT_TRAJECTORY_PLOT_COLORS))]
        y = legend_y + (i - 1) * 18.0
        println(io, "<line x1=\"$legend_x\" y1=\"$y\" x2=\"$(legend_x + 22)\" y2=\"$y\" stroke=\"$color\" stroke-width=\"2.5\" />")
        _write_text(io, legend_x + 28, y + 4, item.label; class = "tick")
    end
    return nothing
end

function _write_text(
    io::IO,
    x,
    y,
    text::AbstractString;
    anchor::AbstractString = "start",
    class::AbstractString = "tick",
)
    println(io, "<text class=\"$class\" x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(Float64(y); digits = 2))\" text-anchor=\"$anchor\">$(_xml_escape(text))</text>")
    return nothing
end

function _write_rotated_text(io::IO, x, y, text::AbstractString)
    println(io, "<text class=\"axis-label\" x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(Float64(y); digits = 2))\" text-anchor=\"middle\" transform=\"rotate(-90 $(round(Float64(x); digits = 2)) $(round(Float64(y); digits = 2)))\">$(_xml_escape(text))</text>")
    return nothing
end

function _format_tick(value::Real)::String
    converted = Float64(value)
    if abs(converted) >= 1000 || (abs(converted) < 0.001 && converted != 0.0)
        return string(round(converted; sigdigits = 3))
    end
    return string(round(converted; digits = 3))
end

function _xml_escape(text::AbstractString)::String
    escaped = replace(String(text), "&" => "&amp;")
    escaped = replace(escaped, "<" => "&lt;")
    escaped = replace(escaped, ">" => "&gt;")
    escaped = replace(escaped, "\"" => "&quot;")
    return replace(escaped, "'" => "&apos;")
end
