const SEQUENTIAL_DFBA_COMPARISON_PLOT_WIDTH = 980
const SEQUENTIAL_DFBA_COMPARISON_REDUCED_COLOR = "#2563eb"
const SEQUENTIAL_DFBA_COMPARISON_FULL_COLOR = "#d97706"
const SEQUENTIAL_DFBA_COMPARISON_DIFF_COLOR = "#64748b"
const SEQUENTIAL_DFBA_CORE_PLOT_STATES = ["biomass", "glucose", "fructose", "ethanol", "oxygen"]
const SEQUENTIAL_DFBA_RMSE_PLOT_STATES = ["biomass", "glucose", "fructose", "ethanol", "oxygen", "carbohydrate"]
const SEQUENTIAL_DFBA_RUNTIME_PLOT_METRICS = [
    "simulation_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
]

"""
    write_sequential_dfba_comparison_plots(comparison, output_dir; overwrite=false)

Write dependency-free SVG plots for a sequential full-vs-reduced DFBA state
comparison.
"""
function write_sequential_dfba_comparison_plots(
    comparison::SequentialDFBAComparisonResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Sequential DFBA comparison plot output_dir exists and is not a directory: $output_path")
    end
    mkpath(output_path)

    paths = Dict{String, String}(
        "core_states" => joinpath(output_path, "sequential_dfba_core_states.svg"),
        "state_rmse" => joinpath(output_path, "sequential_dfba_state_rmse.svg"),
        "runtime_counters" => joinpath(output_path, "sequential_dfba_runtime_counters.svg"),
    )
    for path in values(paths)
        _prepare_sequential_dfba_plot_output_path(path, overwrite)
    end

    write(paths["core_states"], _sequential_dfba_core_states_svg(comparison))
    write(paths["state_rmse"], _sequential_dfba_state_rmse_svg(comparison))
    write(paths["runtime_counters"], _sequential_dfba_runtime_counters_svg(comparison))
    return paths
end

function _prepare_sequential_dfba_plot_output_path(path::AbstractString, overwrite::Bool)
    if isfile(path) && !overwrite
        error("Sequential DFBA comparison plot output file already exists and overwrite=false: $(String(path))")
    end
    return nothing
end

function _sequential_dfba_core_states_svg(comparison::SequentialDFBAComparisonResult)::String
    time = comparison.reduced_result.time
    state_names = String.(comparison.metadata["state_names"])
    width = SEQUENTIAL_DFBA_COMPARISON_PLOT_WIDTH
    panel_height = 120
    top = 54
    bottom = 44
    height = top + bottom + panel_height * length(SEQUENTIAL_DFBA_CORE_PLOT_STATES)
    layout = (
        left = 92.0,
        right = 34.0,
        plot_width = width - 92.0 - 34.0,
    )

    io = IOBuffer()
    _write_sequential_dfba_svg_header(io, width, height)
    _write_sequential_dfba_text(io, width / 2, 28, "Sequential DFBA core state comparison"; anchor = "middle", class = "title")
    _write_sequential_dfba_legend(io, width - 230, 30)

    for (panel_index, state_name) in enumerate(SEQUENTIAL_DFBA_CORE_PLOT_STATES)
        state_index = findfirst(==(state_name), state_names)
        state_index === nothing && continue
        panel_top = top + (panel_index - 1) * panel_height
        panel = (
            left = layout.left,
            top = Float64(panel_top),
            plot_width = layout.plot_width,
            plot_height = panel_height - 32.0,
        )
        reduced = collect(view(comparison.reduced_result.states, state_index, :))
        full = collect(view(comparison.full_result.states, state_index, :))
        y_values = vcat(reduced, full)
        x_min, x_max = _sequential_dfba_expanded_limits(minimum(time), maximum(time))
        y_min, y_max = _sequential_dfba_expanded_limits(minimum(y_values), maximum(y_values))
        x_scale(value) = panel.left + (value - x_min) / (x_max - x_min) * panel.plot_width
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height

        _write_sequential_dfba_panel_axes(io, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
        _write_sequential_dfba_text(io, panel.left - 10, panel.top + 15, state_name; anchor = "end", class = "small-label")
        _write_sequential_dfba_polyline(io, time, reduced, x_scale, y_scale, SEQUENTIAL_DFBA_COMPARISON_REDUCED_COLOR)
        _write_sequential_dfba_polyline(io, time, full, x_scale, y_scale, SEQUENTIAL_DFBA_COMPARISON_FULL_COLOR)
    end

    _write_sequential_dfba_text(io, width / 2, height - 16, "time (h)"; anchor = "middle", class = "axis-label")
    _write_sequential_dfba_svg_footer(io)
    return String(take!(io))
end

function _sequential_dfba_state_rmse_svg(comparison::SequentialDFBAComparisonResult)::String
    table = comparison.state_metrics_table
    row_indices = [
        findfirst(==(state_name), String.(table[!, "state_name"])) for
        state_name in SEQUENTIAL_DFBA_RMSE_PLOT_STATES
    ]
    filter!(!isnothing, row_indices)
    isempty(row_indices) && error("Sequential DFBA RMSE plot requires at least one selected state.")

    labels = String.(table[row_indices, "state_name"])
    values = Float64.(table[row_indices, "relative_rmse"])
    width = SEQUENTIAL_DFBA_COMPARISON_PLOT_WIDTH
    height = 420
    panel = (
        left = 92.0,
        top = 54.0,
        plot_width = width - 126.0,
        plot_height = height - 134.0,
    )
    y_min, y_max = _sequential_dfba_expanded_limits(0.0, max(maximum(values), eps(Float64)))
    y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height
    zero_y = y_scale(0.0)

    io = IOBuffer()
    _write_sequential_dfba_svg_header(io, width, height)
    _write_sequential_dfba_text(io, width / 2, 28, "Sequential DFBA relative RMSE by state"; anchor = "middle", class = "title")
    _write_sequential_dfba_y_axis(io, panel, y_min, y_max, y_scale)
    group_width = panel.plot_width / length(labels)
    bar_width = min(58.0, group_width * 0.46)
    for (i, label) in enumerate(labels)
        x = panel.left + (i - 0.5) * group_width - bar_width / 2
        y = y_scale(values[i])
        height_value = max(1.0, zero_y - y)
        println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - height_value; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(height_value; digits = 2))\" fill=\"$SEQUENTIAL_DFBA_COMPARISON_DIFF_COLOR\" />")
        _write_sequential_dfba_text(io, x + bar_width / 2, zero_y + 18, label; anchor = "middle", class = "tick")
        _write_sequential_dfba_text(io, x + bar_width / 2, y - 7, _sequential_dfba_format_value(values[i]); anchor = "middle", class = "small-label")
    end
    _write_sequential_dfba_text(io, width / 2, height - 18, "state"; anchor = "middle", class = "axis-label")
    _write_sequential_dfba_rotated_text(io, 18, panel.top + panel.plot_height / 2, "relative RMSE")
    _write_sequential_dfba_svg_footer(io)
    return String(take!(io))
end

function _sequential_dfba_runtime_counters_svg(comparison::SequentialDFBAComparisonResult)::String
    summary = comparison.summary_table
    width = SEQUENTIAL_DFBA_COMPARISON_PLOT_WIDTH
    panel_height = 130
    top = 54
    bottom = 36
    height = top + bottom + panel_height * length(SEQUENTIAL_DFBA_RUNTIME_PLOT_METRICS)
    panel_left = 116.0
    panel_width = width - panel_left - 54.0

    io = IOBuffer()
    _write_sequential_dfba_svg_header(io, width, height)
    _write_sequential_dfba_text(io, width / 2, 28, "Sequential DFBA runtime counters"; anchor = "middle", class = "title")
    _write_sequential_dfba_legend(io, width - 230, 30)

    for (panel_index, metric) in enumerate(SEQUENTIAL_DFBA_RUNTIME_PLOT_METRICS)
        reduced_value = Float64(_sequential_dfba_summary_metric(summary, "reduced", metric))
        full_value = Float64(_sequential_dfba_summary_metric(summary, "full", metric))
        panel = (
            left = panel_left,
            top = Float64(top + (panel_index - 1) * panel_height),
            plot_width = panel_width,
            plot_height = panel_height - 38.0,
        )
        y_min, y_max = _sequential_dfba_expanded_limits(0.0, max(reduced_value, full_value, eps(Float64)))
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height
        zero_y = y_scale(0.0)

        _write_sequential_dfba_y_axis(io, panel, y_min, y_max, y_scale)
        _write_sequential_dfba_text(io, panel.left - 12, panel.top + 16, metric; anchor = "end", class = "small-label")

        group_width = panel.plot_width / 2
        bar_width = min(82.0, group_width * 0.34)
        _write_sequential_dfba_runtime_bar(io, panel.left + 0.5 * group_width - bar_width / 2, bar_width, zero_y, y_scale, reduced_value, SEQUENTIAL_DFBA_COMPARISON_REDUCED_COLOR, "reduced")
        _write_sequential_dfba_runtime_bar(io, panel.left + 1.5 * group_width - bar_width / 2, bar_width, zero_y, y_scale, full_value, SEQUENTIAL_DFBA_COMPARISON_FULL_COLOR, "full")
    end

    _write_sequential_dfba_svg_footer(io)
    return String(take!(io))
end

function _write_sequential_dfba_runtime_bar(io::IO, x, bar_width, zero_y, y_scale, value, color, label)
    y = y_scale(value)
    height_value = max(1.0, zero_y - y)
    println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - height_value; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(height_value; digits = 2))\" fill=\"$color\" />")
    _write_sequential_dfba_text(io, x + bar_width / 2, zero_y + 18, label; anchor = "middle", class = "tick")
    _write_sequential_dfba_text(io, x + bar_width / 2, y - 7, _sequential_dfba_format_value(value); anchor = "middle", class = "small-label")
    return nothing
end

function _write_sequential_dfba_polyline(io::IO, times, values, x_scale, y_scale, color)
    points = join(
        ["$(round(x_scale(times[i]); digits = 2)),$(round(y_scale(values[i]); digits = 2))" for i in eachindex(times)],
        " ",
    )
    println(io, "<polyline class=\"series\" fill=\"none\" stroke=\"$color\" points=\"$points\" />")
    return nothing
end

function _write_sequential_dfba_panel_axes(io::IO, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
    for i in 0:2
        x_value = x_min + i * (x_max - x_min) / 2
        x = x_scale(x_value)
        println(io, "<line class=\"grid\" x1=\"$(round(x; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(x; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
        _write_sequential_dfba_text(io, x, panel.top + panel.plot_height + 16, _sequential_dfba_format_value(x_value); anchor = "middle", class = "tick")
    end
    for i in 0:2
        y_value = y_min + i * (y_max - y_min) / 2
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_sequential_dfba_text(io, panel.left - 8, y + 4, _sequential_dfba_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _write_sequential_dfba_y_axis(io::IO, panel, y_min, y_max, y_scale)
    for i in 0:3
        y_value = y_min + i * (y_max - y_min) / 3
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_sequential_dfba_text(io, panel.left - 8, y + 4, _sequential_dfba_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _sequential_dfba_summary_metric(summary::DataFrame, model_scope::AbstractString, column::AbstractString)
    row_index = findfirst(==(String(model_scope)), String.(summary[!, "model_scope"]))
    row_index === nothing && error("Sequential DFBA comparison summary is missing model_scope $(String(model_scope)).")
    return summary[row_index, column]
end

function _write_sequential_dfba_legend(io::IO, x, y)
    entries = [
        ("reduced", SEQUENTIAL_DFBA_COMPARISON_REDUCED_COLOR),
        ("full", SEQUENTIAL_DFBA_COMPARISON_FULL_COLOR),
    ]
    for (i, (label, color)) in enumerate(entries)
        item_y = y + (i - 1) * 18.0
        println(io, "<line x1=\"$(round(Float64(x); digits = 2))\" y1=\"$(round(item_y; digits = 2))\" x2=\"$(round(Float64(x + 24); digits = 2))\" y2=\"$(round(item_y; digits = 2))\" stroke=\"$color\" stroke-width=\"2.8\" />")
        _write_sequential_dfba_text(io, x + 32, item_y + 4, label; class = "tick")
    end
    return nothing
end

function _sequential_dfba_expanded_limits(min_value::Real, max_value::Real)
    lo = Float64(min_value)
    hi = Float64(max_value)
    if lo == hi
        delta = max(1.0, abs(lo) * 0.05)
        return lo - delta, hi + delta
    end
    padding = 0.08 * (hi - lo)
    return lo - padding, hi + padding
end

function _write_sequential_dfba_svg_header(io::IO, width::Int, height::Int)
    println(io, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
    println(io, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$width\" height=\"$height\" viewBox=\"0 0 $width $height\">")
    println(io, "<style>")
    println(io, "text { font-family: Arial, sans-serif; fill: #1f2937; }")
    println(io, ".title { font-size: 18px; font-weight: 700; }")
    println(io, ".axis-label { font-size: 12px; }")
    println(io, ".tick { font-size: 11px; fill: #4b5563; }")
    println(io, ".small-label { font-size: 10px; fill: #4b5563; }")
    println(io, ".grid { stroke: #e5e7eb; stroke-width: 1; }")
    println(io, ".axis { stroke: #374151; stroke-width: 1.2; }")
    println(io, ".series { stroke-width: 2.2; stroke-linejoin: round; stroke-linecap: round; }")
    println(io, "</style>")
    println(io, "<rect x=\"0\" y=\"0\" width=\"$width\" height=\"$height\" fill=\"#ffffff\" />")
    return nothing
end

function _write_sequential_dfba_svg_footer(io::IO)
    println(io, "</svg>")
    return nothing
end

function _write_sequential_dfba_text(
    io::IO,
    x,
    y,
    text::AbstractString;
    anchor::AbstractString = "start",
    class::AbstractString = "tick",
)
    println(io, "<text class=\"$class\" x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(Float64(y); digits = 2))\" text-anchor=\"$anchor\">$(_sequential_dfba_xml_escape(text))</text>")
    return nothing
end

function _write_sequential_dfba_rotated_text(io::IO, x, y, text::AbstractString)
    x_value = round(Float64(x); digits = 2)
    y_value = round(Float64(y); digits = 2)
    println(io, "<text class=\"axis-label\" x=\"$x_value\" y=\"$y_value\" text-anchor=\"middle\" transform=\"rotate(-90 $x_value $y_value)\">$(_sequential_dfba_xml_escape(text))</text>")
    return nothing
end

function _sequential_dfba_format_value(value::Real)::String
    converted = Float64(value)
    if converted == 0.0
        return "0.0"
    elseif abs(converted) >= 1000 || abs(converted) < 0.001
        return string(round(converted; sigdigits = 3))
    end
    return string(round(converted; digits = 4))
end

function _sequential_dfba_xml_escape(text::AbstractString)::String
    escaped = replace(String(text), "&" => "&amp;")
    escaped = replace(escaped, "<" => "&lt;")
    escaped = replace(escaped, ">" => "&gt;")
    escaped = replace(escaped, "\"" => "&quot;")
    return replace(escaped, "'" => "&apos;")
end
