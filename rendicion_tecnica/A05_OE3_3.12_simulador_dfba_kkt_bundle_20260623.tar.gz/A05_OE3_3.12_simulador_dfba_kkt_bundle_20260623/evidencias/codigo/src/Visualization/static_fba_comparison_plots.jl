const STATIC_FBA_COMPARISON_PLOT_WIDTH = 960
const STATIC_FBA_COMPARISON_PLOT_HEIGHT = 420
const STATIC_FBA_COMPARISON_COLORS = Dict(
    "reduced" => "#2563eb",
    "full" => "#d97706",
    "diagnostic" => "#64748b",
)

"""
    write_static_fba_comparison_plots(comparison, output_dir; overwrite=false)

Write dependency-free SVG plots for a static FBA full-vs-reduced comparison.
"""
function write_static_fba_comparison_plots(
    comparison::StaticFBAComparisonResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Static FBA comparison plot output_dir exists and is not a directory: $output_path")
    end
    mkpath(output_path)

    paths = Dict{String, String}(
        "objective" => joinpath(output_path, "static_fba_objective_comparison.svg"),
        "selected_fluxes" => joinpath(output_path, "static_fba_selected_fluxes.svg"),
        "diagnostics" => joinpath(output_path, "static_fba_diagnostics.svg"),
    )
    for path in values(paths)
        _prepare_static_fba_plot_output_path(path, overwrite)
    end

    write(paths["objective"], _static_fba_objective_svg(comparison))
    write(paths["selected_fluxes"], _static_fba_selected_fluxes_svg(comparison))
    write(paths["diagnostics"], _static_fba_diagnostics_svg(comparison))
    return paths
end

function _prepare_static_fba_plot_output_path(path::AbstractString, overwrite::Bool)
    if isfile(path) && !overwrite
        error("Static FBA comparison plot output file already exists and overwrite=false: $(String(path))")
    end
    return nothing
end

function _static_fba_objective_svg(comparison::StaticFBAComparisonResult)::String
    summary = comparison.summary_table
    reduced_value = _static_fba_summary_value(summary, "reduced", "objective_value")
    full_value = _static_fba_summary_value(summary, "full", "objective_value")
    objective_id = String(comparison.metadata["objective_rxn_id"])
    values = [
        (scope = "reduced", value = Float64(reduced_value)),
        (scope = "full", value = Float64(full_value)),
    ]

    width = STATIC_FBA_COMPARISON_PLOT_WIDTH
    height = 360
    layout = _static_fba_plot_layout(width, height)
    y_min, y_max = _static_fba_expanded_limits(0.0, maximum(value.value for value in values))
    y_scale(value) = layout.top + (y_max - value) / (y_max - y_min) * layout.plot_height

    io = IOBuffer()
    _write_static_fba_svg_header(io, width, height)
    _write_static_fba_text(io, width / 2, 28, "Static FBA objective comparison ($objective_id)"; anchor = "middle", class = "title")
    _write_static_fba_y_axis(io, layout, y_min, y_max, y_scale)
    _write_static_fba_text(io, width / 2, height - 18, "model scope"; anchor = "middle", class = "axis-label")
    _write_static_fba_rotated_text(io, 18, layout.top + layout.plot_height / 2, "objective value")

    group_width = layout.plot_width / length(values)
    bar_width = min(130.0, group_width * 0.45)
    zero_y = y_scale(0.0)
    for (i, item) in enumerate(values)
        x = layout.left + (i - 0.5) * group_width - bar_width / 2
        y = y_scale(item.value)
        color = STATIC_FBA_COMPARISON_COLORS[item.scope]
        println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(y; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(zero_y - y; digits = 2))\" fill=\"$color\" />")
        _write_static_fba_text(io, x + bar_width / 2, zero_y + 18, item.scope; anchor = "middle", class = "tick")
        _write_static_fba_text(io, x + bar_width / 2, y - 8, _static_fba_format_value(item.value); anchor = "middle", class = "value-label")
    end

    _write_static_fba_svg_footer(io)
    return String(take!(io))
end

function _static_fba_selected_fluxes_svg(comparison::StaticFBAComparisonResult)::String
    table = comparison.selected_flux_table
    row_indices = [
        i for i in axes(table, 1) if
        !ismissing(table[i, "reduced_flux"]) || !ismissing(table[i, "full_flux"])
    ]
    isempty(row_indices) && error("Static FBA selected flux plot requires at least one present flux.")

    values = Float64[]
    for i in row_indices
        !ismissing(table[i, "reduced_flux"]) && push!(values, Float64(table[i, "reduced_flux"]))
        !ismissing(table[i, "full_flux"]) && push!(values, Float64(table[i, "full_flux"]))
    end
    y_min, y_max = _static_fba_expanded_limits(min(0.0, minimum(values)), max(0.0, maximum(values)))

    width = max(STATIC_FBA_COMPARISON_PLOT_WIDTH, 120 + 112 * length(row_indices))
    height = 480
    layout = _static_fba_plot_layout(width, height; bottom = 112.0)
    y_scale(value) = layout.top + (y_max - value) / (y_max - y_min) * layout.plot_height
    zero_y = y_scale(0.0)

    io = IOBuffer()
    _write_static_fba_svg_header(io, width, height)
    _write_static_fba_text(io, width / 2, 28, "Selected static FBA flux comparison"; anchor = "middle", class = "title")
    _write_static_fba_y_axis(io, layout, y_min, y_max, y_scale)
    _write_static_fba_text(io, width / 2, height - 18, "reaction ID"; anchor = "middle", class = "axis-label")
    _write_static_fba_rotated_text(io, 18, layout.top + layout.plot_height / 2, "flux")
    println(io, "<line class=\"zero-line\" x1=\"$(layout.left)\" y1=\"$(round(zero_y; digits = 2))\" x2=\"$(layout.left + layout.plot_width)\" y2=\"$(round(zero_y; digits = 2))\" />")

    group_width = layout.plot_width / length(row_indices)
    bar_width = min(28.0, group_width * 0.24)
    for (group_index, row_index) in enumerate(row_indices)
        center = layout.left + (group_index - 0.5) * group_width
        reaction_id = String(table[row_index, "reaction_id"])
        role = String(table[row_index, "role"])
        _write_static_fba_flux_bar(
            io,
            table[row_index, "reduced_flux"],
            center - bar_width - 2.0,
            bar_width,
            zero_y,
            y_scale,
            STATIC_FBA_COMPARISON_COLORS["reduced"],
            "absent",
        )
        _write_static_fba_flux_bar(
            io,
            table[row_index, "full_flux"],
            center + 2.0,
            bar_width,
            zero_y,
            y_scale,
            STATIC_FBA_COMPARISON_COLORS["full"],
            "absent",
        )
        _write_static_fba_rotated_text(io, center, height - 42, reaction_id)
        _write_static_fba_text(io, center, height - 78, role; anchor = "middle", class = "small-label")
    end

    _write_static_fba_legend(io, layout.left + 12, layout.top + 12)
    _write_static_fba_text(
        io,
        layout.left + layout.plot_width - 8,
        height - 78,
        "r_1992: reduced absent; full present/closed";
        anchor = "end",
        class = "small-label",
    )
    _write_static_fba_svg_footer(io)
    return String(take!(io))
end

function _static_fba_diagnostics_svg(comparison::StaticFBAComparisonResult)::String
    summary = comparison.summary_table
    diagnostics = [
        (scope = "reduced", metric = "mass-balance residual", value = Float64(_static_fba_summary_value(summary, "reduced", "mass_balance_residual"))),
        (scope = "full", metric = "mass-balance residual", value = Float64(_static_fba_summary_value(summary, "full", "mass_balance_residual"))),
        (scope = "reduced", metric = "lower-bound violation", value = Float64(_static_fba_summary_value(summary, "reduced", "max_lower_bound_violation"))),
        (scope = "full", metric = "lower-bound violation", value = Float64(_static_fba_summary_value(summary, "full", "max_lower_bound_violation"))),
        (scope = "reduced", metric = "upper-bound violation", value = Float64(_static_fba_summary_value(summary, "reduced", "max_upper_bound_violation"))),
        (scope = "full", metric = "upper-bound violation", value = Float64(_static_fba_summary_value(summary, "full", "max_upper_bound_violation"))),
    ]

    width = STATIC_FBA_COMPARISON_PLOT_WIDTH
    height = STATIC_FBA_COMPARISON_PLOT_HEIGHT
    layout = _static_fba_plot_layout(width, height; bottom = 96.0)
    max_value = max(maximum(item.value for item in diagnostics), eps(Float64))
    y_min, y_max = _static_fba_expanded_limits(0.0, max_value)
    y_scale(value) = layout.top + (y_max - value) / (y_max - y_min) * layout.plot_height
    zero_y = y_scale(0.0)

    io = IOBuffer()
    _write_static_fba_svg_header(io, width, height)
    _write_static_fba_text(io, width / 2, 28, "Static FBA solver diagnostics"; anchor = "middle", class = "title")
    _write_static_fba_y_axis(io, layout, y_min, y_max, y_scale)
    _write_static_fba_rotated_text(io, 18, layout.top + layout.plot_height / 2, "diagnostic value")

    group_width = layout.plot_width / 3
    bar_width = min(34.0, group_width * 0.16)
    metric_names = ["mass-balance residual", "lower-bound violation", "upper-bound violation"]
    for (metric_index, metric) in enumerate(metric_names)
        center = layout.left + (metric_index - 0.5) * group_width
        reduced = diagnostics[2 * metric_index - 1]
        full = diagnostics[2 * metric_index]
        _write_static_fba_diagnostic_bar(io, reduced.value, center - bar_width - 4.0, bar_width, zero_y, y_scale, STATIC_FBA_COMPARISON_COLORS["reduced"])
        _write_static_fba_diagnostic_bar(io, full.value, center + 4.0, bar_width, zero_y, y_scale, STATIC_FBA_COMPARISON_COLORS["full"])
        _write_static_fba_text(io, center, height - 64, metric; anchor = "middle", class = "small-label")
    end

    _write_static_fba_legend(io, layout.left + 12, layout.top + 12)
    _write_static_fba_svg_footer(io)
    return String(take!(io))
end

function _write_static_fba_flux_bar(io::IO, value, x, bar_width, zero_y, y_scale, color, missing_label)
    if ismissing(value)
        _write_static_fba_text(io, x + bar_width / 2, zero_y - 6, missing_label; anchor = "middle", class = "small-label")
        return nothing
    end

    flux = Float64(value)
    y = y_scale(flux)
    top_y = min(y, zero_y)
    height = max(1.0, abs(zero_y - y))
    println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(top_y; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(height; digits = 2))\" fill=\"$color\" />")
    label_y = flux >= 0.0 ? top_y - 5.0 : top_y + height + 14.0
    _write_static_fba_text(io, x + bar_width / 2, label_y, _static_fba_format_value(flux); anchor = "middle", class = "small-label")
    return nothing
end

function _write_static_fba_diagnostic_bar(io::IO, value, x, bar_width, zero_y, y_scale, color)
    y = y_scale(value)
    height = max(1.0, zero_y - y)
    println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - height; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(height; digits = 2))\" fill=\"$color\" />")
    _write_static_fba_text(io, x + bar_width / 2, zero_y - height - 6.0, _static_fba_format_value(value); anchor = "middle", class = "small-label")
    return nothing
end

function _static_fba_summary_value(summary::DataFrame, model_scope::AbstractString, column::AbstractString)
    row_index = findfirst(==(String(model_scope)), String.(summary[!, "model_scope"]))
    row_index === nothing && error("Static FBA comparison summary is missing model_scope $(String(model_scope)).")
    return summary[row_index, column]
end

function _static_fba_plot_layout(width::Int, height::Int; bottom::Real = 64.0)
    left = 92.0
    right = 34.0
    top = 52.0
    bottom_value = Float64(bottom)
    return (
        left = left,
        right = right,
        top = top,
        bottom = bottom_value,
        plot_width = width - left - right,
        plot_height = height - top - bottom_value,
    )
end

function _static_fba_expanded_limits(min_value::Real, max_value::Real)
    lo = Float64(min_value)
    hi = Float64(max_value)
    if lo == hi
        delta = max(1.0, abs(lo) * 0.05)
        return lo - delta, hi + delta
    end
    padding = 0.08 * (hi - lo)
    return lo - padding, hi + padding
end

function _write_static_fba_svg_header(io::IO, width::Int, height::Int)
    println(io, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
    println(io, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$width\" height=\"$height\" viewBox=\"0 0 $width $height\">")
    println(io, "<style>")
    println(io, "text { font-family: Arial, sans-serif; fill: #1f2937; }")
    println(io, ".title { font-size: 18px; font-weight: 700; }")
    println(io, ".axis-label { font-size: 12px; }")
    println(io, ".tick { font-size: 11px; fill: #4b5563; }")
    println(io, ".small-label { font-size: 10px; fill: #4b5563; }")
    println(io, ".value-label { font-size: 11px; font-weight: 600; }")
    println(io, ".grid { stroke: #e5e7eb; stroke-width: 1; }")
    println(io, ".axis { stroke: #374151; stroke-width: 1.2; }")
    println(io, ".zero-line { stroke: #111827; stroke-width: 1.1; stroke-dasharray: 3 3; }")
    println(io, "</style>")
    println(io, "<rect x=\"0\" y=\"0\" width=\"$width\" height=\"$height\" fill=\"#ffffff\" />")
    return nothing
end

function _write_static_fba_svg_footer(io::IO)
    println(io, "</svg>")
    return nothing
end

function _write_static_fba_y_axis(io::IO, layout, y_min, y_max, y_scale)
    for i in 0:4
        y_value = y_min + i * (y_max - y_min) / 4
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(layout.left)\" y1=\"$(round(y; digits = 2))\" x2=\"$(layout.left + layout.plot_width)\" y2=\"$(round(y; digits = 2))\" />")
        _write_static_fba_text(io, layout.left - 8, y + 4, _static_fba_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(layout.left)\" y1=\"$(layout.top)\" x2=\"$(layout.left)\" y2=\"$(layout.top + layout.plot_height)\" />")
    println(io, "<line class=\"axis\" x1=\"$(layout.left)\" y1=\"$(layout.top + layout.plot_height)\" x2=\"$(layout.left + layout.plot_width)\" y2=\"$(layout.top + layout.plot_height)\" />")
    return nothing
end

function _write_static_fba_legend(io::IO, x, y)
    entries = [("reduced", STATIC_FBA_COMPARISON_COLORS["reduced"]), ("full", STATIC_FBA_COMPARISON_COLORS["full"])]
    for (i, (label, color)) in enumerate(entries)
        item_y = y + (i - 1) * 18.0
        println(io, "<rect x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(item_y - 9; digits = 2))\" width=\"14\" height=\"10\" fill=\"$color\" />")
        _write_static_fba_text(io, x + 20, item_y, label; class = "tick")
    end
    return nothing
end

function _write_static_fba_text(
    io::IO,
    x,
    y,
    text::AbstractString;
    anchor::AbstractString = "start",
    class::AbstractString = "tick",
)
    println(io, "<text class=\"$class\" x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(Float64(y); digits = 2))\" text-anchor=\"$anchor\">$(_static_fba_xml_escape(text))</text>")
    return nothing
end

function _write_static_fba_rotated_text(io::IO, x, y, text::AbstractString)
    x_value = round(Float64(x); digits = 2)
    y_value = round(Float64(y); digits = 2)
    println(io, "<text class=\"axis-label\" x=\"$x_value\" y=\"$y_value\" text-anchor=\"middle\" transform=\"rotate(-90 $x_value $y_value)\">$(_static_fba_xml_escape(text))</text>")
    return nothing
end

function _static_fba_format_value(value::Real)::String
    converted = Float64(value)
    if converted == 0.0
        return "0.0"
    elseif abs(converted) >= 1000 || abs(converted) < 0.001
        return string(round(converted; sigdigits = 3))
    end
    return string(round(converted; digits = 5))
end

function _static_fba_xml_escape(text::AbstractString)::String
    escaped = replace(String(text), "&" => "&amp;")
    escaped = replace(escaped, "<" => "&lt;")
    escaped = replace(escaped, ">" => "&gt;")
    escaped = replace(escaped, "\"" => "&quot;")
    return replace(escaped, "'" => "&apos;")
end
