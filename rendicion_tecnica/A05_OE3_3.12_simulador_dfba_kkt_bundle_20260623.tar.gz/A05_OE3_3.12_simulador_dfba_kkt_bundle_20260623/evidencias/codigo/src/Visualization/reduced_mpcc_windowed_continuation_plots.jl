const REDUCED_MPCC_WINDOWED_PLOT_WIDTH = 1040
const REDUCED_MPCC_WINDOWED_SEQUENTIAL_COLOR = "#2563eb"
const REDUCED_MPCC_WINDOWED_MPCC_COLOR = "#dc2626"
const REDUCED_MPCC_GLOBAL_POLISH_COLOR = "#16a34a"
const REDUCED_MPCC_WINDOWED_DIFF_COLOR = "#64748b"

const REDUCED_MPCC_WINDOWED_STATE_PLOT_GROUPS = (
    core_states = (
        filename = "windowed_mpcc_core_states.svg",
        title = "Windowed MPCC vs sequential core states",
        states = ["biomass", "total_sugar", "glucose", "fructose", "ethanol", "oxygen"],
    ),
    nitrogen_reserves = (
        filename = "windowed_mpcc_nitrogen_reserves.svg",
        title = "Windowed MPCC vs sequential nitrogen and reserves",
        states = ["nitrogen", "protein", "carbohydrate"],
    ),
    aroma_products = (
        filename = "windowed_mpcc_aroma_products.svg",
        title = "Windowed MPCC vs sequential aroma products",
        states = [
            "phenylethanol",
            "isoamyl_alcohol",
            "isobutanol",
            "methionol",
            "tyrosol",
            "ethyl_acetate",
        ],
    ),
)

const REDUCED_MPCC_WINDOWED_RMSE_PLOT_STATES = [
    "biomass",
    "total_sugar",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "nitrogen",
    "carbohydrate",
]

"""
    write_reduced_dcdfba_mpcc_windowed_plots(result, output_dir; overwrite=false)

Write dependency-free SVG plots comparing the reduced sequential reference
against the reduced MPCC boundary candidate produced by the windowed
continuation diagnostic.
"""
function write_reduced_dcdfba_mpcc_windowed_plots(
    result::ReducedDCDFBAMPCCWindowedContinuationResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Reduced MPCC windowed plot output_dir exists and is not a directory: $output_path")
    end
    mkpath(output_path)

    nrow(result.aligned_timeseries_table) > 0 ||
        error("Reduced MPCC windowed plots require a non-empty aligned_timeseries_table.")

    paths = Dict{String, String}()
    for key in keys(REDUCED_MPCC_WINDOWED_STATE_PLOT_GROUPS)
        group = getproperty(REDUCED_MPCC_WINDOWED_STATE_PLOT_GROUPS, key)
        states = [
            state for state in group.states
            if _reduced_mpcc_windowed_has_state_series(result.aligned_timeseries_table, state)
        ]
        isempty(states) && continue
        path = joinpath(output_path, group.filename)
        _prepare_plot_output_path(path, overwrite)
        write(path, _reduced_mpcc_windowed_state_comparison_svg(result, states; title = group.title))
        paths[String(key)] = normpath(path)
    end

    if nrow(result.state_metrics_table) > 0
        rmse_path = joinpath(output_path, "windowed_mpcc_state_relative_rmse.svg")
        _prepare_plot_output_path(rmse_path, overwrite)
        write(rmse_path, _reduced_mpcc_windowed_state_rmse_svg(result))
        paths["state_relative_rmse"] = normpath(rmse_path)
    end

    return paths
end

"""
    write_reduced_dcdfba_mpcc_global_three_way_plots(result, output_dir; overwrite=false)

Write SVG plots comparing the sequential reference, the windowed seed used to
initialize the global polish, and the global MPCC candidate returned by Ipopt.
"""
function write_reduced_dcdfba_mpcc_global_three_way_plots(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Reduced MPCC global three-way plot output_dir exists and is not a directory: $output_path")
    end
    mkpath(output_path)

    table = _reduced_mpcc_global_polish_three_way_timeseries(result)
    nrow(table) == 0 && return Dict{String, String}()

    paths = Dict{String, String}()
    for key in keys(REDUCED_MPCC_WINDOWED_STATE_PLOT_GROUPS)
        group = getproperty(REDUCED_MPCC_WINDOWED_STATE_PLOT_GROUPS, key)
        states = [
            state for state in group.states
            if _reduced_mpcc_global_three_way_has_state_series(table, state)
        ]
        isempty(states) && continue
        filename =
            "global_polish_three_way_" *
            replace(String(group.filename), "windowed_mpcc_" => "")
        path = joinpath(output_path, filename)
        _prepare_plot_output_path(path, overwrite)
        title = replace(
            String(group.title),
            "Windowed MPCC vs sequential" =>
                "Global MPCC polish vs windowed seed and sequential",
        )
        write(path, _reduced_mpcc_global_three_way_state_svg(table, states; title = title))
        paths[String(key)] = normpath(path)
    end
    return paths
end

"""
    write_reduced_dcdfba_mpcc_windowed_report(result, output_dir; overwrite=false)

Write CSV/TOML diagnostics and SVG state-comparison plots for a reduced MPCC
windowed-continuation result.
"""
function write_reduced_dcdfba_mpcc_windowed_report(
    result::ReducedDCDFBAMPCCWindowedContinuationResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    diagnostics_dir = joinpath(output_path, "diagnostics")
    plots_dir = joinpath(output_path, "plots")

    result.metadata["outputs_written"] = true
    result.metadata["output_dir"] = output_path
    result.metadata["diagnostic_output_dir"] = diagnostics_dir
    result.metadata["plot_output_dir"] = plots_dir

    paths = Dict{String, String}()
    for (key, path) in export_reduced_dcdfba_mpcc_windowed_continuation(
        result,
        diagnostics_dir;
        overwrite = overwrite,
    )
        paths["diagnostics_$(key)"] = path
    end
    for (key, path) in write_reduced_dcdfba_mpcc_windowed_plots(
        result,
        plots_dir;
        overwrite = overwrite,
    )
        paths["plot_$(key)"] = path
    end
    if !isempty(result.window_comparisons)
        starts = build_reduced_dcdfba_mpcc_windowed_start_values(
            result;
            require_complete = false,
        )
        for (key, path) in export_reduced_dcdfba_mpcc_windowed_start_values(
            starts,
            joinpath(output_path, "global_start_values");
            overwrite = overwrite,
        )
            paths["global_start_values_$(key)"] = path
        end
    end
    return paths
end

function _reduced_mpcc_windowed_has_state_series(table::DataFrame, state_name::AbstractString)::Bool
    prefix = lowercase(String(state_name))
    return "$(prefix)_sequential" in names(table) &&
           "$(prefix)_mpcc_candidate" in names(table)
end

function _reduced_mpcc_global_three_way_has_state_series(
    table::DataFrame,
    state_name::AbstractString,
)::Bool
    prefix = lowercase(String(state_name))
    return "$(prefix)_sequential" in names(table) &&
           "$(prefix)_windowed_seed" in names(table) &&
           "$(prefix)_global_candidate" in names(table)
end

function _reduced_mpcc_windowed_state_comparison_svg(
    result::ReducedDCDFBAMPCCWindowedContinuationResult,
    states::AbstractVector{<:AbstractString};
    title::AbstractString,
)::String
    table = result.aligned_timeseries_table
    time = Float64.(table[!, "time"])
    all(isfinite, time) || error("Reduced MPCC windowed plot time values must be finite.")
    isempty(time) && error("Reduced MPCC windowed plot requires at least one time point.")

    width = REDUCED_MPCC_WINDOWED_PLOT_WIDTH
    panel_height = 124
    top = 58
    bottom = 44
    height = top + bottom + panel_height * length(states)
    panel_left = 104.0
    panel_right = 40.0
    plot_width = width - panel_left - panel_right
    x_min, x_max = _expanded_limits(minimum(time), maximum(time))

    io = IOBuffer()
    _write_svg_header(io, width, height)
    _write_text(io, width / 2, 28, title; anchor = "middle", class = "title")
    _write_reduced_mpcc_windowed_legend(io, width - 250.0, 30.0)

    for (panel_index, state_name) in enumerate(states)
        prefix = lowercase(String(state_name))
        sequential = Float64.(table[!, "$(prefix)_sequential"])
        mpcc = Float64.(table[!, "$(prefix)_mpcc_candidate"])
        all(isfinite, sequential) || error("Sequential values for $(state_name) must be finite.")
        all(isfinite, mpcc) || error("MPCC values for $(state_name) must be finite.")
        values = vcat(sequential, mpcc)
        y_min, y_max = _expanded_limits(minimum(values), maximum(values))
        panel = (
            left = panel_left,
            top = Float64(top + (panel_index - 1) * panel_height),
            plot_width = plot_width,
            plot_height = panel_height - 34.0,
        )
        x_scale(value) = panel.left + (value - x_min) / (x_max - x_min) * panel.plot_width
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height

        _write_axes(io, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
        _write_text(io, panel.left - 10, panel.top + 15, String(state_name); anchor = "end", class = "tick")
        _write_reduced_mpcc_windowed_polyline(
            io,
            time,
            sequential,
            x_scale,
            y_scale,
            REDUCED_MPCC_WINDOWED_SEQUENTIAL_COLOR,
        )
        _write_reduced_mpcc_windowed_polyline(
            io,
            time,
            mpcc,
            x_scale,
            y_scale,
            REDUCED_MPCC_WINDOWED_MPCC_COLOR,
        )
    end

    _write_text(io, width / 2, height - 16, "time (h)"; anchor = "middle", class = "axis-label")
    _write_svg_footer(io)
    return String(take!(io))
end

function _reduced_mpcc_global_three_way_state_svg(
    table::DataFrame,
    states::AbstractVector{<:AbstractString};
    title::AbstractString,
)::String
    time = Float64.(table[!, "time"])
    all(isfinite, time) || error("Reduced MPCC global three-way plot time values must be finite.")
    isempty(time) && error("Reduced MPCC global three-way plot requires at least one time point.")

    width = REDUCED_MPCC_WINDOWED_PLOT_WIDTH
    panel_height = 124
    top = 58
    bottom = 44
    height = top + bottom + panel_height * length(states)
    panel_left = 104.0
    panel_right = 40.0
    plot_width = width - panel_left - panel_right
    x_min, x_max = _expanded_limits(minimum(time), maximum(time))

    io = IOBuffer()
    _write_svg_header(io, width, height)
    _write_text(io, width / 2, 28, title; anchor = "middle", class = "title")
    _write_reduced_mpcc_global_three_way_legend(io, width - 300.0, 24.0)

    for (panel_index, state_name) in enumerate(states)
        prefix = lowercase(String(state_name))
        sequential = Float64.(table[!, "$(prefix)_sequential"])
        windowed = Float64.(table[!, "$(prefix)_windowed_seed"])
        global_candidate = Float64.(table[!, "$(prefix)_global_candidate"])
        all(isfinite, sequential) || error("Sequential values for $(state_name) must be finite.")
        all(isfinite, windowed) || error("Windowed seed values for $(state_name) must be finite.")
        all(isfinite, global_candidate) ||
            error("Global candidate values for $(state_name) must be finite.")
        values = vcat(sequential, windowed, global_candidate)
        y_min, y_max = _expanded_limits(minimum(values), maximum(values))
        panel = (
            left = panel_left,
            top = Float64(top + (panel_index - 1) * panel_height),
            plot_width = plot_width,
            plot_height = panel_height - 34.0,
        )
        x_scale(value) = panel.left + (value - x_min) / (x_max - x_min) * panel.plot_width
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height

        _write_axes(io, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
        _write_text(io, panel.left - 10, panel.top + 15, String(state_name); anchor = "end", class = "tick")
        _write_reduced_mpcc_windowed_polyline(
            io,
            time,
            sequential,
            x_scale,
            y_scale,
            REDUCED_MPCC_WINDOWED_SEQUENTIAL_COLOR,
        )
        _write_reduced_mpcc_windowed_polyline(
            io,
            time,
            windowed,
            x_scale,
            y_scale,
            REDUCED_MPCC_WINDOWED_MPCC_COLOR,
        )
        _write_reduced_mpcc_windowed_polyline(
            io,
            time,
            global_candidate,
            x_scale,
            y_scale,
            REDUCED_MPCC_GLOBAL_POLISH_COLOR,
        )
    end

    _write_text(io, width / 2, height - 16, "time (h)"; anchor = "middle", class = "axis-label")
    _write_svg_footer(io)
    return String(take!(io))
end

function _reduced_mpcc_windowed_state_rmse_svg(
    result::ReducedDCDFBAMPCCWindowedContinuationResult,
)::String
    table = result.state_metrics_table
    state_column = String.(table[!, "state_name"])
    row_indices = [
        findfirst(==(state_name), state_column) for
        state_name in REDUCED_MPCC_WINDOWED_RMSE_PLOT_STATES
    ]
    filter!(!isnothing, row_indices)
    isempty(row_indices) &&
        error("Reduced MPCC windowed RMSE plot requires at least one selected state.")

    labels = String.(table[row_indices, "state_name"])
    values = Float64.(table[row_indices, "relative_rmse"])
    width = REDUCED_MPCC_WINDOWED_PLOT_WIDTH
    height = 430
    panel = (
        left = 96.0,
        top = 58.0,
        plot_width = width - 140.0,
        plot_height = height - 142.0,
    )
    y_min, y_max = _expanded_limits(0.0, max(maximum(values), eps(Float64)))
    y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height
    zero_y = y_scale(0.0)

    io = IOBuffer()
    _write_svg_header(io, width, height)
    _write_text(io, width / 2, 28, "Windowed MPCC relative RMSE vs sequential"; anchor = "middle", class = "title")
    _write_reduced_mpcc_windowed_y_axis(io, panel, y_min, y_max, y_scale)
    group_width = panel.plot_width / length(labels)
    bar_width = min(58.0, group_width * 0.48)
    for (i, label) in enumerate(labels)
        x = panel.left + (i - 0.5) * group_width - bar_width / 2
        y = y_scale(values[i])
        height_value = max(1.0, zero_y - y)
        println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - height_value; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(height_value; digits = 2))\" fill=\"$REDUCED_MPCC_WINDOWED_DIFF_COLOR\" />")
        _write_text(io, x + bar_width / 2, zero_y + 18, label; anchor = "middle", class = "tick")
        _write_text(io, x + bar_width / 2, y - 7, _format_tick(values[i]); anchor = "middle", class = "tick")
    end
    _write_text(io, width / 2, height - 18, "state"; anchor = "middle", class = "axis-label")
    _write_rotated_text(io, 18, panel.top + panel.plot_height / 2, "relative RMSE")
    _write_svg_footer(io)
    return String(take!(io))
end

function _write_reduced_mpcc_windowed_polyline(io::IO, times, values, x_scale, y_scale, color)
    points = join(
        ["$(round(x_scale(times[i]); digits = 2)),$(round(y_scale(values[i]); digits = 2))" for i in eachindex(times)],
        " ",
    )
    println(io, "<polyline class=\"series\" fill=\"none\" stroke=\"$color\" points=\"$points\" />")
    return nothing
end

function _write_reduced_mpcc_windowed_legend(io::IO, x, y)
    entries = [
        ("sequential", REDUCED_MPCC_WINDOWED_SEQUENTIAL_COLOR),
        ("windowed MPCC", REDUCED_MPCC_WINDOWED_MPCC_COLOR),
    ]
    for (i, (label, color)) in enumerate(entries)
        item_y = y + (i - 1) * 18.0
        println(io, "<line x1=\"$(round(Float64(x); digits = 2))\" y1=\"$(round(item_y; digits = 2))\" x2=\"$(round(Float64(x + 28); digits = 2))\" y2=\"$(round(item_y; digits = 2))\" stroke=\"$color\" stroke-width=\"2.8\" />")
        _write_text(io, x + 36, item_y + 4, label; class = "tick")
    end
    return nothing
end

function _write_reduced_mpcc_global_three_way_legend(io::IO, x, y)
    entries = [
        ("sequential", REDUCED_MPCC_WINDOWED_SEQUENTIAL_COLOR),
        ("windowed seed", REDUCED_MPCC_WINDOWED_MPCC_COLOR),
        ("global MPCC", REDUCED_MPCC_GLOBAL_POLISH_COLOR),
    ]
    for (i, (label, color)) in enumerate(entries)
        item_y = y + (i - 1) * 18.0
        println(io, "<line x1=\"$(round(Float64(x); digits = 2))\" y1=\"$(round(item_y; digits = 2))\" x2=\"$(round(Float64(x + 28); digits = 2))\" y2=\"$(round(item_y; digits = 2))\" stroke=\"$color\" stroke-width=\"2.8\" />")
        _write_text(io, x + 36, item_y + 4, label; class = "tick")
    end
    return nothing
end

function _write_reduced_mpcc_windowed_y_axis(io::IO, panel, y_min, y_max, y_scale)
    for i in 0:4
        y_value = y_min + i * (y_max - y_min) / 4
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_text(io, panel.left - 8, y + 4, _format_tick(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end
