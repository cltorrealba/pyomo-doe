const DFVB_MATLAB_COMPARISON_PLOT_WIDTH = 980
const DFVB_MATLAB_COMPARISON_JULIA_COLOR = "#2563eb"
const DFVB_MATLAB_COMPARISON_BASELINE_COLOR = "#d97706"
const DFVB_MATLAB_COMPARISON_BAR_COLOR = "#475569"
const DFVB_MATLAB_COMPARISON_RUNTIME_COLOR = "#0f766e"
const DFVB_MATLAB_COMPARISON_CORE_STATES = ["biomass", "glucose", "fructose", "ethanol", "oxygen"]
const DFVB_MATLAB_COMPARISON_RMSE_STATES = [
    "biomass",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "carbohydrate",
]
const DFVB_MATLAB_COMPARISON_RUNTIME_METRICS = [
    "simulation_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
]

"""
    write_dfvb_matlab_comparison_plots(comparison, output_dir; overwrite=false)

Write dependency-free SVG plots for a Julia-vs-MATLAB DFVB state trajectory
comparison.
"""
function write_dfvb_matlab_comparison_plots(
    comparison::DFVBMatlabComparisonResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("DFVB MATLAB comparison plot output_dir exists and is not a directory: $output_path")
    end
    mkpath(output_path)

    paths = Dict{String, String}(
        "core_states" => joinpath(output_path, "dfvb_matlab_core_states.svg"),
        "state_rmse" => joinpath(output_path, "dfvb_matlab_state_rmse.svg"),
        "runtime_counters" => joinpath(output_path, "dfvb_matlab_runtime_counters.svg"),
    )
    for path in values(paths)
        _prepare_dfvb_matlab_plot_output_path(path, overwrite)
    end

    write(paths["core_states"], _dfvb_matlab_core_states_svg(comparison))
    write(paths["state_rmse"], _dfvb_matlab_state_rmse_svg(comparison))
    write(paths["runtime_counters"], _dfvb_matlab_runtime_counters_svg(comparison))
    return paths
end

function _prepare_dfvb_matlab_plot_output_path(path::AbstractString, overwrite::Bool)
    if isfile(path) && !overwrite
        error("DFVB MATLAB comparison plot output file already exists and overwrite=false: $(String(path))")
    end
    return nothing
end

function _dfvb_matlab_core_states_svg(comparison::DFVBMatlabComparisonResult)::String
    table = comparison.aligned_state_timeseries
    time = _dfvb_matlab_plot_numeric_column(table, "time")
    width = DFVB_MATLAB_COMPARISON_PLOT_WIDTH
    panel_height = 122
    top = 58
    bottom = 44
    height = top + bottom + panel_height * length(DFVB_MATLAB_COMPARISON_CORE_STATES)
    panel_left = 96.0
    panel_right = 36.0
    plot_width = width - panel_left - panel_right

    io = IOBuffer()
    _write_dfvb_matlab_svg_header(io, width, height)
    _write_dfvb_matlab_text(io, width / 2, 30, "Julia vs MATLAB DFVB core states"; anchor = "middle", class = "title")
    _write_dfvb_matlab_legend(io, width - 230, 28)

    for (panel_index, state_name) in enumerate(DFVB_MATLAB_COMPARISON_CORE_STATES)
        julia_col = "$(state_name)_julia"
        matlab_col = "$(state_name)_matlab"
        julia_col in names(table) && matlab_col in names(table) || continue
        julia_values = _dfvb_matlab_plot_numeric_column(table, julia_col)
        matlab_values = _dfvb_matlab_plot_numeric_column(table, matlab_col)
        panel = (
            left = panel_left,
            top = Float64(top + (panel_index - 1) * panel_height),
            plot_width = plot_width,
            plot_height = panel_height - 34.0,
        )
        x_min, x_max = _dfvb_matlab_expanded_limits(minimum(time), maximum(time))
        y_min, y_max = _dfvb_matlab_expanded_limits(
            minimum(vcat(julia_values, matlab_values)),
            maximum(vcat(julia_values, matlab_values)),
        )
        x_scale(value) = panel.left + (value - x_min) / (x_max - x_min) * panel.plot_width
        y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height

        _write_dfvb_matlab_panel_axes(io, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
        _write_dfvb_matlab_text(io, panel.left - 10, panel.top + 16, state_name; anchor = "end", class = "small-label")
        _write_dfvb_matlab_polyline(io, time, julia_values, x_scale, y_scale, DFVB_MATLAB_COMPARISON_JULIA_COLOR)
        _write_dfvb_matlab_polyline(io, time, matlab_values, x_scale, y_scale, DFVB_MATLAB_COMPARISON_BASELINE_COLOR)
    end

    _write_dfvb_matlab_text(io, width / 2, height - 16, "time (h)"; anchor = "middle", class = "axis-label")
    _write_dfvb_matlab_svg_footer(io)
    return String(take!(io))
end

function _dfvb_matlab_state_rmse_svg(comparison::DFVBMatlabComparisonResult)::String
    table = comparison.state_metrics
    row_indices = [
        findfirst(==(state_name), String.(table[!, "state_name"])) for
        state_name in DFVB_MATLAB_COMPARISON_RMSE_STATES
    ]
    filter!(!isnothing, row_indices)
    isempty(row_indices) && error("DFVB MATLAB comparison RMSE plot requires at least one selected state.")

    labels = String.(table[row_indices, "state_name"])
    values = Float64.(table[row_indices, "relative_rmse"])
    width = DFVB_MATLAB_COMPARISON_PLOT_WIDTH
    height = 420
    panel = (
        left = 92.0,
        top = 54.0,
        plot_width = width - 126.0,
        plot_height = height - 134.0,
    )
    return _dfvb_matlab_bar_svg(
        labels,
        values,
        "Julia vs MATLAB DFVB relative RMSE by state",
        "state",
        "relative RMSE",
        DFVB_MATLAB_COMPARISON_BAR_COLOR,
        width,
        height,
        panel;
        max_label_chars = 18,
        rotate_labels = false,
    )
end

function _dfvb_matlab_runtime_counters_svg(comparison::DFVBMatlabComparisonResult)::String
    summary = comparison.summary_table
    labels = copy(DFVB_MATLAB_COMPARISON_RUNTIME_METRICS)
    values = [
        Float64(_dfvb_matlab_summary_metric(summary, "julia_dfvb", metric)) for
        metric in labels
    ]
    width = DFVB_MATLAB_COMPARISON_PLOT_WIDTH
    height = 430
    panel = (
        left = 132.0,
        top = 76.0,
        plot_width = width - 176.0,
        plot_height = height - 184.0,
    )

    io = IOBuffer()
    _write_dfvb_matlab_svg_header(io, width, height)
    _write_dfvb_matlab_text(io, width / 2, 30, "Julia DFVB runtime counters"; anchor = "middle", class = "title")
    _write_dfvb_matlab_text(
        io,
        width / 2,
        52,
        "MATLAB baseline is an exported artifact; runtime counters are not applicable.";
        anchor = "middle",
        class = "small-label",
    )
    _write_dfvb_matlab_bar_body(
        io,
        labels,
        values,
        "runtime metric",
        "value",
        DFVB_MATLAB_COMPARISON_RUNTIME_COLOR,
        width,
        height,
        panel;
        max_label_chars = 30,
        rotate_labels = false,
    )
    _write_dfvb_matlab_svg_footer(io)
    return String(take!(io))
end

function _dfvb_matlab_bar_svg(
    labels::Vector{String},
    values::Vector{Float64},
    title::AbstractString,
    x_label::AbstractString,
    y_label::AbstractString,
    color::AbstractString,
    width::Int,
    height::Int,
    panel;
    max_label_chars::Int,
    rotate_labels::Bool,
)::String
    io = IOBuffer()
    _write_dfvb_matlab_svg_header(io, width, height)
    _write_dfvb_matlab_text(io, width / 2, 28, String(title); anchor = "middle", class = "title")
    _write_dfvb_matlab_bar_body(
        io,
        labels,
        values,
        x_label,
        y_label,
        color,
        width,
        height,
        panel;
        max_label_chars = max_label_chars,
        rotate_labels = rotate_labels,
    )
    _write_dfvb_matlab_svg_footer(io)
    return String(take!(io))
end

function _write_dfvb_matlab_bar_body(
    io::IO,
    labels::Vector{String},
    values::Vector{Float64},
    x_label::AbstractString,
    y_label::AbstractString,
    color::AbstractString,
    width::Int,
    height::Int,
    panel;
    max_label_chars::Int,
    rotate_labels::Bool,
)
    length(labels) == length(values) || error("DFVB MATLAB bar plot label/value length mismatch.")
    !isempty(labels) || error("DFVB MATLAB bar plot requires at least one value.")
    y_min, y_max = _dfvb_matlab_expanded_limits(0.0, max(maximum(abs.(values)), eps(Float64)))
    y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height
    zero_y = y_scale(0.0)
    group_width = panel.plot_width / length(labels)
    bar_width = min(68.0, group_width * 0.46)

    _write_dfvb_matlab_y_axis(io, panel, y_min, y_max, y_scale)
    for (i, label) in enumerate(labels)
        x = panel.left + (i - 0.5) * group_width - bar_width / 2
        value = abs(values[i])
        y = y_scale(value)
        height_value = max(1.0, zero_y - y)
        println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - height_value; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(height_value; digits = 2))\" fill=\"$color\" />")
        _write_dfvb_matlab_text(io, x + bar_width / 2, y - 7, _dfvb_matlab_format_value(value); anchor = "middle", class = "small-label")
        clipped_label = _dfvb_matlab_clip_label(label, max_label_chars)
        if rotate_labels
            _write_dfvb_matlab_rotated_text(io, x + bar_width / 2, zero_y + 22, clipped_label, -38.0; class = "tick")
        else
            _write_dfvb_matlab_text(io, x + bar_width / 2, zero_y + 18, clipped_label; anchor = "middle", class = "tick")
        end
    end
    _write_dfvb_matlab_text(io, width / 2, height - 18, String(x_label); anchor = "middle", class = "axis-label")
    _write_dfvb_matlab_rotated_text(io, 18, panel.top + panel.plot_height / 2, String(y_label), -90.0; class = "axis-label")
    return nothing
end

function _dfvb_matlab_plot_numeric_column(table::DataFrame, column::AbstractString)::Vector{Float64}
    column in names(table) || error("DFVB MATLAB comparison plot table is missing column $(String(column)).")
    return _dfvb_matlab_numeric_vector(table[!, column], String(column))
end

function _dfvb_matlab_summary_metric(summary::DataFrame, source::AbstractString, column::AbstractString)
    row_index = findfirst(==(String(source)), String.(summary[!, "source"]))
    row_index === nothing && error("DFVB MATLAB comparison summary is missing source $(String(source)).")
    return summary[row_index, column]
end

function _write_dfvb_matlab_polyline(io::IO, times, values, x_scale, y_scale, color)
    points = join(
        ["$(round(x_scale(times[i]); digits = 2)),$(round(y_scale(values[i]); digits = 2))" for i in eachindex(times)],
        " ",
    )
    println(io, "<polyline class=\"series\" fill=\"none\" stroke=\"$color\" points=\"$points\" />")
    return nothing
end

function _write_dfvb_matlab_panel_axes(io::IO, panel, x_min, x_max, y_min, y_max, x_scale, y_scale)
    for i in 0:2
        x_value = x_min + i * (x_max - x_min) / 2
        x = x_scale(x_value)
        println(io, "<line class=\"grid\" x1=\"$(round(x; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(x; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
        _write_dfvb_matlab_text(io, x, panel.top + panel.plot_height + 16, _dfvb_matlab_format_value(x_value); anchor = "middle", class = "tick")
    end
    for i in 0:2
        y_value = y_min + i * (y_max - y_min) / 2
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_dfvb_matlab_text(io, panel.left - 8, y + 4, _dfvb_matlab_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _write_dfvb_matlab_y_axis(io::IO, panel, y_min, y_max, y_scale)
    for i in 0:3
        y_value = y_min + i * (y_max - y_min) / 3
        y = y_scale(y_value)
        println(io, "<line class=\"grid\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(y; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(y; digits = 2))\" />")
        _write_dfvb_matlab_text(io, panel.left - 8, y + 4, _dfvb_matlab_format_value(y_value); anchor = "end", class = "tick")
    end
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top; digits = 2))\" x2=\"$(round(panel.left; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    println(io, "<line class=\"axis\" x1=\"$(round(panel.left; digits = 2))\" y1=\"$(round(panel.top + panel.plot_height; digits = 2))\" x2=\"$(round(panel.left + panel.plot_width; digits = 2))\" y2=\"$(round(panel.top + panel.plot_height; digits = 2))\" />")
    return nothing
end

function _write_dfvb_matlab_legend(io::IO, x, y)
    entries = [
        ("Julia DFVB", DFVB_MATLAB_COMPARISON_JULIA_COLOR),
        ("MATLAB aligned", DFVB_MATLAB_COMPARISON_BASELINE_COLOR),
    ]
    for (i, (label, color)) in enumerate(entries)
        item_y = y + (i - 1) * 18.0
        println(io, "<line x1=\"$(round(Float64(x); digits = 2))\" y1=\"$(round(item_y; digits = 2))\" x2=\"$(round(Float64(x + 24); digits = 2))\" y2=\"$(round(item_y; digits = 2))\" stroke=\"$color\" stroke-width=\"2.8\" />")
        _write_dfvb_matlab_text(io, x + 32, item_y + 4, label; class = "tick")
    end
    return nothing
end

function _dfvb_matlab_expanded_limits(min_value::Real, max_value::Real)
    lo = Float64(min_value)
    hi = Float64(max_value)
    if lo == hi
        delta = max(1.0, abs(lo) * 0.05)
        return lo - delta, hi + delta
    end
    padding = 0.08 * (hi - lo)
    return lo - padding, hi + padding
end

function _write_dfvb_matlab_svg_header(io::IO, width::Int, height::Int)
    println(io, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
    println(io, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$width\" height=\"$height\" viewBox=\"0 0 $width $height\">")
    println(io, "<style>")
    println(io, "text { font-family: Arial, sans-serif; fill: #1f2937; }")
    println(io, ".title { font-size: 18px; font-weight: 700; }")
    println(io, ".axis-label { font-size: 12px; }")
    println(io, ".tick { font-size: 11px; fill: #4b5563; }")
    println(io, ".small-label { font-size: 10px; fill: #4b5563; }")
    println(io, ".grid { stroke: #e5e7eb; stroke-width: 1; }")
    println(io, ".axis { stroke: #374151; stroke-width: 1.2; }")
    println(io, ".series { stroke-width: 2.2; stroke-linejoin: round; stroke-linecap: round; }")
    println(io, "</style>")
    println(io, "<rect x=\"0\" y=\"0\" width=\"$width\" height=\"$height\" fill=\"#ffffff\" />")
    return nothing
end

function _write_dfvb_matlab_svg_footer(io::IO)
    println(io, "</svg>")
    return nothing
end

function _write_dfvb_matlab_text(
    io::IO,
    x,
    y,
    text::AbstractString;
    anchor::AbstractString = "start",
    class::AbstractString = "tick",
)
    println(io, "<text class=\"$class\" x=\"$(round(Float64(x); digits = 2))\" y=\"$(round(Float64(y); digits = 2))\" text-anchor=\"$anchor\">$(_dfvb_matlab_xml_escape(text))</text>")
    return nothing
end

function _write_dfvb_matlab_rotated_text(
    io::IO,
    x,
    y,
    text::AbstractString,
    angle::Real;
    class::AbstractString = "tick",
)
    x_value = round(Float64(x); digits = 2)
    y_value = round(Float64(y); digits = 2)
    println(io, "<text class=\"$class\" x=\"$x_value\" y=\"$y_value\" text-anchor=\"end\" transform=\"rotate($(round(Float64(angle); digits = 2)) $x_value $y_value)\">$(_dfvb_matlab_xml_escape(text))</text>")
    return nothing
end

function _dfvb_matlab_format_value(value::Real)::String
    converted = Float64(value)
    if converted == 0.0
        return "0.0"
    elseif abs(converted) >= 1000 || abs(converted) < 0.001
        return string(round(converted; sigdigits = 3))
    end
    return string(round(converted; digits = 4))
end

function _dfvb_matlab_clip_label(label::AbstractString, max_chars::Integer)::String
    text = String(label)
    length(text) <= max_chars && return text
    return first(text, max_chars - 1) * "..."
end

function _dfvb_matlab_xml_escape(text::AbstractString)::String
    escaped = replace(String(text), "&" => "&amp;")
    escaped = replace(escaped, "<" => "&lt;")
    escaped = replace(escaped, ">" => "&gt;")
    escaped = replace(escaped, "\"" => "&quot;")
    return replace(escaped, "'" => "&apos;")
end
