import Libdl
import Ipopt
import JuMP
import MathOptInterface as MOI

const IPOPT_LINEAR_SOLVER_ENV = "MPCC_IPOPT_LINEAR_SOLVER"
const IPOPT_DEFAULT_LINEAR_SOLVER = "mumps"
const IPOPT_SUPPORTED_LINEAR_SOLVERS = ("mumps", "spral", "pardiso", "ma57", "ma86", "ma97")
const IPOPT_HSL_LINEAR_SOLVERS = ("ma57", "ma86", "ma97")
const IPOPT_HSL_REQUIRED_SYMBOLS = Dict(
    "ma57" => "ma57id_",
    "ma86" => "ma86_default_control_d",
    "ma97" => "ma97_default_control_d",
)
const IPOPT_HSLLIB_ENV = "MPCC_IPOPT_HSLLIB"
const IPOPT_WARM_START_INIT_POINT_ENV = "MPCC_IPOPT_WARM_START_INIT_POINT"
const IPOPT_WARM_START_BOUND_PUSH_ENV = "MPCC_IPOPT_WARM_START_BOUND_PUSH"
const IPOPT_WARM_START_BOUND_FRAC_ENV = "MPCC_IPOPT_WARM_START_BOUND_FRAC"
const IPOPT_WARM_START_SLACK_BOUND_PUSH_ENV =
    "MPCC_IPOPT_WARM_START_SLACK_BOUND_PUSH"
const IPOPT_WARM_START_SLACK_BOUND_FRAC_ENV =
    "MPCC_IPOPT_WARM_START_SLACK_BOUND_FRAC"
const IPOPT_WARM_START_MULT_BOUND_PUSH_ENV =
    "MPCC_IPOPT_WARM_START_MULT_BOUND_PUSH"
const IPOPT_MAX_WALL_TIME_ENV = "MPCC_IPOPT_MAX_WALL_TIME_SECONDS"
const IPOPT_HESSIAN_APPROXIMATION_ENV = "MPCC_IPOPT_HESSIAN_APPROXIMATION"
const IPOPT_HESSIAN_APPROXIMATION_VALUES = ("exact", "limited-memory")

"""
    ReducedToyNLPProblem

Small deterministic NLP used to verify the future reduced simultaneous path can
construct a JuMP model with Ipopt and a configured sparse linear solver. This is
not a DFBA, KKT, or MPCC model.
"""
struct ReducedToyNLPProblem
    jump_model::JuMP.Model
    x::JuMP.VariableRef
    y::JuMP.VariableRef
    linear_constraint::JuMP.ConstraintRef
    bilinear_constraint::JuMP.ConstraintRef
    metadata::Dict{String, Any}
end

"""
    ReducedToyNLPSmokeResult

Result from solving the reduced toy NLP smoke problem with Ipopt.
"""
struct ReducedToyNLPSmokeResult
    status::MOI.TerminationStatusCode
    primal_status::MOI.ResultStatusCode
    objective_value::Float64
    x::Float64
    y::Float64
    linear_constraint_residual::Float64
    bilinear_constraint_residual::Float64
    solver_name::String
    metadata::Dict{String, Any}
end

"""
    ipopt_optimizer(; linear_solver="mumps", print_level=nothing, max_iter=nothing, kwargs...)

Return an Ipopt optimizer factory configured with a validated sparse linear
solver. MUMPS remains the default baseline; SPRAL is available through the
bundled Ipopt_jll build; PARDISO and HSL-family solvers remain opt-in local
configuration choices. `MPCC_IPOPT_WARM_START_INIT_POINT=1` enables Ipopt's
native warm-start mode, but this only passes the option; explicit Ipopt dual
starts are tracked separately. The warm-start bound-push options can be
provided through `MPCC_IPOPT_WARM_START_BOUND_PUSH`,
`MPCC_IPOPT_WARM_START_BOUND_FRAC`,
`MPCC_IPOPT_WARM_START_SLACK_BOUND_PUSH`,
`MPCC_IPOPT_WARM_START_SLACK_BOUND_FRAC`, and
`MPCC_IPOPT_WARM_START_MULT_BOUND_PUSH`. `MPCC_IPOPT_HESSIAN_APPROXIMATION`
can be set to `limited-memory` for memory-reduced diagnostics; leaving it unset
keeps Ipopt's exact-Hessian default.
"""
function ipopt_optimizer(;
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    print_level::Union{Nothing, Int} = nothing,
    max_iter::Union{Nothing, Int} = nothing,
    tol::Union{Nothing, Real} = nothing,
    constr_viol_tol::Union{Nothing, Real} = nothing,
    dual_inf_tol::Union{Nothing, Real} = nothing,
    compl_inf_tol::Union{Nothing, Real} = nothing,
    acceptable_tol::Union{Nothing, Real} = nothing,
    acceptable_constr_viol_tol::Union{Nothing, Real} = nothing,
    acceptable_compl_inf_tol::Union{Nothing, Real} = nothing,
    acceptable_dual_inf_tol::Union{Nothing, Real} = nothing,
    acceptable_obj_change_tol::Union{Nothing, Real} = nothing,
    acceptable_iter::Union{Nothing, Int} = nothing,
    mu_strategy::Union{Nothing, AbstractString} = nothing,
    fixed_variable_treatment::Union{Nothing, AbstractString} = nothing,
    bound_push::Union{Nothing, Real} = nothing,
    bound_frac::Union{Nothing, Real} = nothing,
    honor_original_bounds::Union{Nothing, AbstractString} = nothing,
    hessian_approximation::Union{Nothing, AbstractString} = nothing,
    hsllib::Union{Nothing, AbstractString} = nothing,
    warm_start_init_point::Union{Nothing, Bool} = nothing,
    warm_start_bound_push::Union{Nothing, Real} = nothing,
    warm_start_bound_frac::Union{Nothing, Real} = nothing,
    warm_start_slack_bound_push::Union{Nothing, Real} = nothing,
    warm_start_slack_bound_frac::Union{Nothing, Real} = nothing,
    warm_start_mult_bound_push::Union{Nothing, Real} = nothing,
    print_frequency_iter::Union{Nothing, Int} = nothing,
    print_frequency_time::Union{Nothing, Real} = nothing,
    max_wall_time::Union{Nothing, Real} = nothing,
)
    resolved_print_level =
        print_level === nothing ? _ipopt_env_print_level() : print_level
    resolved_print_frequency_iter =
        print_frequency_iter === nothing ?
        _ipopt_env_print_frequency_iter() :
        print_frequency_iter
    resolved_print_frequency_time =
        print_frequency_time === nothing ?
        _ipopt_env_print_frequency_time() :
        print_frequency_time
    resolved_warm_start_init_point =
        warm_start_init_point === nothing ?
        ipopt_warm_start_init_point_from_env() :
        warm_start_init_point
    resolved_warm_start_bound_push =
        warm_start_bound_push === nothing ?
        ipopt_warm_start_bound_push_from_env() :
        warm_start_bound_push
    resolved_warm_start_bound_frac =
        warm_start_bound_frac === nothing ?
        ipopt_warm_start_bound_frac_from_env() :
        warm_start_bound_frac
    resolved_warm_start_slack_bound_push =
        warm_start_slack_bound_push === nothing ?
        ipopt_warm_start_slack_bound_push_from_env() :
        warm_start_slack_bound_push
    resolved_warm_start_slack_bound_frac =
        warm_start_slack_bound_frac === nothing ?
        ipopt_warm_start_slack_bound_frac_from_env() :
        warm_start_slack_bound_frac
    resolved_warm_start_mult_bound_push =
        warm_start_mult_bound_push === nothing ?
        ipopt_warm_start_mult_bound_push_from_env() :
        warm_start_mult_bound_push
    resolved_max_wall_time =
        max_wall_time === nothing ? ipopt_max_wall_time_from_env() : max_wall_time
    resolved_hessian_approximation =
        hessian_approximation === nothing ?
        ipopt_hessian_approximation_from_env() :
        _canonical_ipopt_hessian_approximation(hessian_approximation)
    resolved_linear_solver = _canonical_ipopt_linear_solver(linear_solver)
    resolved_hsllib, _ =
        _ipopt_resolve_hsllib(resolved_linear_solver, hsllib)

    resolved_print_level >= 0 ||
        throw(ArgumentError("Ipopt print_level must be nonnegative."))
    max_iter === nothing || max_iter >= 0 ||
        throw(ArgumentError("Ipopt max_iter must be nonnegative when provided."))
    acceptable_iter === nothing || acceptable_iter >= 0 ||
        throw(ArgumentError("Ipopt acceptable_iter must be nonnegative when provided."))
    resolved_print_frequency_iter === nothing || resolved_print_frequency_iter > 0 ||
        throw(ArgumentError("Ipopt print_frequency_iter must be positive when provided."))

    attributes = Pair{String, Any}[]
    resolved_hsllib === nothing ||
        push!(attributes, "hsllib" => resolved_hsllib)
    push!(attributes, "linear_solver" => resolved_linear_solver)
    push!(attributes, "print_level" => resolved_print_level)
    max_iter === nothing || push!(attributes, "max_iter" => max_iter)
    tol_value = _ipopt_positive_float_option("tol", tol)
    constr_viol_tol_value = _ipopt_positive_float_option("constr_viol_tol", constr_viol_tol)
    dual_inf_tol_value = _ipopt_positive_float_option("dual_inf_tol", dual_inf_tol)
    compl_inf_tol_value = _ipopt_positive_float_option("compl_inf_tol", compl_inf_tol)
    acceptable_tol_value = _ipopt_positive_float_option("acceptable_tol", acceptable_tol)
    acceptable_constr_viol_tol_value =
        _ipopt_positive_float_option("acceptable_constr_viol_tol", acceptable_constr_viol_tol)
    acceptable_compl_inf_tol_value =
        _ipopt_positive_float_option("acceptable_compl_inf_tol", acceptable_compl_inf_tol)
    acceptable_dual_inf_tol_value =
        _ipopt_positive_float_option("acceptable_dual_inf_tol", acceptable_dual_inf_tol)
    acceptable_obj_change_tol_value =
        _ipopt_positive_float_option("acceptable_obj_change_tol", acceptable_obj_change_tol)
    bound_push_value = _ipopt_positive_float_option("bound_push", bound_push)
    bound_frac_value = _ipopt_positive_float_option("bound_frac", bound_frac)
    warm_start_bound_push_value =
        _ipopt_positive_float_option(
            "warm_start_bound_push",
            resolved_warm_start_bound_push,
        )
    warm_start_bound_frac_value =
        _ipopt_positive_float_option(
            "warm_start_bound_frac",
            resolved_warm_start_bound_frac,
        )
    warm_start_slack_bound_push_value =
        _ipopt_positive_float_option(
            "warm_start_slack_bound_push",
            resolved_warm_start_slack_bound_push,
        )
    warm_start_slack_bound_frac_value =
        _ipopt_positive_float_option(
            "warm_start_slack_bound_frac",
            resolved_warm_start_slack_bound_frac,
        )
    warm_start_mult_bound_push_value =
        _ipopt_positive_float_option(
            "warm_start_mult_bound_push",
            resolved_warm_start_mult_bound_push,
        )
    mu_strategy_value = _ipopt_string_option(
        "mu_strategy",
        mu_strategy,
        ("adaptive", "monotone"),
    )
    fixed_variable_treatment_value = _ipopt_string_option(
        "fixed_variable_treatment",
        fixed_variable_treatment,
        ("make_parameter", "make_parameter_nodual", "make_constraint", "relax_bounds"),
    )
    honor_original_bounds_value = _ipopt_string_option(
        "honor_original_bounds",
        honor_original_bounds,
        ("yes", "no"),
    )
    hessian_approximation_value =
        resolved_hessian_approximation === nothing ?
        nothing :
        _ipopt_string_option(
            "hessian_approximation",
            resolved_hessian_approximation,
            IPOPT_HESSIAN_APPROXIMATION_VALUES,
        )
    print_frequency_time_value =
        _ipopt_nonnegative_float_option(
            "print_frequency_time",
            resolved_print_frequency_time,
        )
    max_wall_time_value =
        _ipopt_positive_float_option("max_wall_time", resolved_max_wall_time)
    tol_value === nothing || push!(attributes, "tol" => tol_value)
    constr_viol_tol_value === nothing ||
        push!(attributes, "constr_viol_tol" => constr_viol_tol_value)
    dual_inf_tol_value === nothing || push!(attributes, "dual_inf_tol" => dual_inf_tol_value)
    compl_inf_tol_value === nothing || push!(attributes, "compl_inf_tol" => compl_inf_tol_value)
    acceptable_tol_value === nothing ||
        push!(attributes, "acceptable_tol" => acceptable_tol_value)
    acceptable_constr_viol_tol_value === nothing ||
        push!(attributes, "acceptable_constr_viol_tol" => acceptable_constr_viol_tol_value)
    acceptable_compl_inf_tol_value === nothing ||
        push!(attributes, "acceptable_compl_inf_tol" => acceptable_compl_inf_tol_value)
    acceptable_dual_inf_tol_value === nothing ||
        push!(attributes, "acceptable_dual_inf_tol" => acceptable_dual_inf_tol_value)
    acceptable_obj_change_tol_value === nothing ||
        push!(attributes, "acceptable_obj_change_tol" => acceptable_obj_change_tol_value)
    acceptable_iter === nothing || push!(attributes, "acceptable_iter" => acceptable_iter)
    mu_strategy_value === nothing || push!(attributes, "mu_strategy" => mu_strategy_value)
    fixed_variable_treatment_value === nothing ||
        push!(attributes, "fixed_variable_treatment" => fixed_variable_treatment_value)
    bound_push_value === nothing || push!(attributes, "bound_push" => bound_push_value)
    bound_frac_value === nothing || push!(attributes, "bound_frac" => bound_frac_value)
    honor_original_bounds_value === nothing ||
        push!(attributes, "honor_original_bounds" => honor_original_bounds_value)
    hessian_approximation_value === nothing ||
        push!(attributes, "hessian_approximation" => hessian_approximation_value)
    push!(
        attributes,
        "warm_start_init_point" => (resolved_warm_start_init_point ? "yes" : "no"),
    )
    warm_start_bound_push_value === nothing ||
        push!(attributes, "warm_start_bound_push" => warm_start_bound_push_value)
    warm_start_bound_frac_value === nothing ||
        push!(attributes, "warm_start_bound_frac" => warm_start_bound_frac_value)
    warm_start_slack_bound_push_value === nothing ||
        push!(
            attributes,
            "warm_start_slack_bound_push" => warm_start_slack_bound_push_value,
        )
    warm_start_slack_bound_frac_value === nothing ||
        push!(
            attributes,
            "warm_start_slack_bound_frac" => warm_start_slack_bound_frac_value,
        )
    warm_start_mult_bound_push_value === nothing ||
        push!(
            attributes,
            "warm_start_mult_bound_push" => warm_start_mult_bound_push_value,
        )
    resolved_print_frequency_iter === nothing ||
        push!(attributes, "print_frequency_iter" => resolved_print_frequency_iter)
    print_frequency_time_value === nothing ||
        push!(attributes, "print_frequency_time" => print_frequency_time_value)
    max_wall_time_value === nothing ||
        push!(attributes, "max_wall_time" => max_wall_time_value)
    return JuMP.optimizer_with_attributes(Ipopt.Optimizer, attributes...)
end

"""
    ipopt_mumps_optimizer(; kwargs...)

Compatibility wrapper for the historical MUMPS-only constructor.
"""
function ipopt_mumps_optimizer(; kwargs...)
    return ipopt_optimizer(; linear_solver = "mumps", kwargs...)
end

function ipopt_linear_solver_from_env(
    default::AbstractString = IPOPT_DEFAULT_LINEAR_SOLVER,
)::String
    raw = strip(get(ENV, IPOPT_LINEAR_SOLVER_ENV, ""))
    return _canonical_ipopt_linear_solver(isempty(raw) ? default : raw)
end

function ipopt_warm_start_init_point_from_env(default::Bool = false)::Bool
    value = _ipopt_env_optional_bool(IPOPT_WARM_START_INIT_POINT_ENV)
    return value === nothing ? default : value
end

function ipopt_warm_start_bound_push_from_env(
    default::Union{Nothing, Real} = nothing,
)::Union{Nothing, Float64}
    return _ipopt_warm_start_positive_float_from_env(
        IPOPT_WARM_START_BOUND_PUSH_ENV,
        default,
    )
end

function ipopt_warm_start_bound_frac_from_env(
    default::Union{Nothing, Real} = nothing,
)::Union{Nothing, Float64}
    return _ipopt_warm_start_positive_float_from_env(
        IPOPT_WARM_START_BOUND_FRAC_ENV,
        default,
    )
end

function ipopt_warm_start_slack_bound_push_from_env(
    default::Union{Nothing, Real} = nothing,
)::Union{Nothing, Float64}
    return _ipopt_warm_start_positive_float_from_env(
        IPOPT_WARM_START_SLACK_BOUND_PUSH_ENV,
        default,
    )
end

function ipopt_warm_start_slack_bound_frac_from_env(
    default::Union{Nothing, Real} = nothing,
)::Union{Nothing, Float64}
    return _ipopt_warm_start_positive_float_from_env(
        IPOPT_WARM_START_SLACK_BOUND_FRAC_ENV,
        default,
    )
end

function ipopt_warm_start_mult_bound_push_from_env(
    default::Union{Nothing, Real} = nothing,
)::Union{Nothing, Float64}
    return _ipopt_warm_start_positive_float_from_env(
        IPOPT_WARM_START_MULT_BOUND_PUSH_ENV,
        default,
    )
end

function _ipopt_warm_start_positive_float_from_env(
    name::String,
    default::Union{Nothing, Real},
)::Union{Nothing, Float64}
    value = _ipopt_env_optional_positive_float(name)
    value === nothing && return default === nothing ? nothing : Float64(default)
    return value
end

function ipopt_max_wall_time_from_env(
    default::Union{Nothing, Real} = nothing,
)::Union{Nothing, Float64}
    value = _ipopt_env_optional_positive_float(
        IPOPT_MAX_WALL_TIME_ENV,
        "MPCC_IPOPT_MAX_WALL_TIME",
    )
    value === nothing && return default === nothing ? nothing : Float64(default)
    return value
end

function ipopt_hessian_approximation_from_env(
    default::Union{Nothing, AbstractString} = nothing,
)::Union{Nothing, String}
    raw = strip(get(ENV, IPOPT_HESSIAN_APPROXIMATION_ENV, ""))
    if isempty(raw)
        return default === nothing ? nothing : _canonical_ipopt_hessian_approximation(default)
    end
    return _canonical_ipopt_hessian_approximation(raw)
end

function _canonical_ipopt_linear_solver(linear_solver::AbstractString)::String
    normalized = lowercase(strip(String(linear_solver)))
    normalized in IPOPT_SUPPORTED_LINEAR_SOLVERS || throw(
        ArgumentError(
            "Ipopt linear_solver must be one of: " *
            "$(join(IPOPT_SUPPORTED_LINEAR_SOLVERS, ", ")). Got: $(linear_solver)",
        ),
    )
    return normalized
end

function _canonical_ipopt_hessian_approximation(
    hessian_approximation::AbstractString,
)::String
    normalized = replace(lowercase(strip(String(hessian_approximation))), "_" => "-")
    normalized in IPOPT_HESSIAN_APPROXIMATION_VALUES || throw(
        ArgumentError(
            "Ipopt hessian_approximation must be one of: " *
            "$(join(IPOPT_HESSIAN_APPROXIMATION_VALUES, ", ")). Got: " *
            "$(hessian_approximation)",
        ),
    )
    return normalized
end

function _ipopt_linear_solver_metadata(
    linear_solver::AbstractString;
    source::AbstractString = "argument",
)::Dict{String, Any}
    canonical = _canonical_ipopt_linear_solver(linear_solver)
    hsl_required = canonical in IPOPT_HSL_LINEAR_SOLVERS
    hsl_metadata = _ipopt_hsllib_metadata(canonical)
    return Dict{String, Any}(
        "linear_solver" => canonical,
        "linear_solver_source" => String(source),
        "linear_solver_env" => IPOPT_LINEAR_SOLVER_ENV,
        "linear_solver_supported_values" => collect(IPOPT_SUPPORTED_LINEAR_SOLVERS),
        "spral_available_from_ipopt_jll" => true,
        "pardiso_opt_in" => canonical == "pardiso",
        "pardiso_project_dependency_required" => false,
        "hsl_required" => hsl_required,
        "hsl_library_configured" => hsl_metadata.configured,
        "hsl_library_path" => hsl_metadata.path,
        "hsl_library_source" => hsl_metadata.source,
        "hsl_library_env" => IPOPT_HSLLIB_ENV,
        "ma57_required" => canonical == "ma57",
        "ma86_required" => canonical == "ma86",
        "ma97_required" => canonical == "ma97",
    )
end

function _ipopt_resolve_hsllib(
    linear_solver::AbstractString,
    explicit_hsllib::Union{Nothing, AbstractString},
)::Tuple{Union{Nothing, String}, String}
    canonical = _canonical_ipopt_linear_solver(linear_solver)
    canonical in IPOPT_HSL_LINEAR_SOLVERS || return nothing, "not_required"
    resolved = _ipopt_hsllib_candidate(explicit_hsllib)
    if resolved.path !== nothing
        _ipopt_validate_hsllib_symbol(canonical, resolved.path)
        return resolved.path, resolved.source
    end
    throw(
        ArgumentError(
            "Ipopt linear_solver=$(canonical) requires HSL. Set $(IPOPT_HSLLIB_ENV) " *
            "to the full libhsl path, or make HSL/HSL_jll available in the Julia environment.",
        ),
    )
end

function _ipopt_hsllib_metadata(linear_solver::AbstractString)
    canonical = _canonical_ipopt_linear_solver(linear_solver)
    canonical in IPOPT_HSL_LINEAR_SOLVERS ||
        return (configured = false, path = missing, source = "not_required")
    resolved = _ipopt_hsllib_candidate(nothing)
    return (
        configured = resolved.path !== nothing,
        path = resolved.path === nothing ? missing : resolved.path,
        source = resolved.source,
    )
end

function _ipopt_hsllib_candidate(explicit_hsllib::Union{Nothing, AbstractString})
    explicit = explicit_hsllib === nothing ? "" : strip(String(explicit_hsllib))
    if !isempty(explicit)
        return (path = explicit, source = "argument")
    end
    env_value = strip(get(ENV, IPOPT_HSLLIB_ENV, ""))
    if !isempty(env_value)
        return (path = env_value, source = "env")
    end
    package_value = _ipopt_hsllib_from_package("HSL", "34c5aeac-e683-54a6-a0e9-6e0fdc586c50")
    package_value !== nothing && return (path = package_value, source = "HSL_package")
    jll_value = _ipopt_hsllib_from_package("HSL_jll", "017b0a0e-03f4-516a-9b91-836bbd1904dd")
    jll_value !== nothing && return (path = jll_value, source = "HSL_jll_package")
    artifact_value = _ipopt_hsllib_from_artifact_search()
    artifact_value !== nothing && return (path = artifact_value, source = "artifact_search")
    return (path = nothing, source = "missing")
end

function _ipopt_validate_hsllib_symbol(linear_solver::AbstractString, hsllib_path::AbstractString)
    required_symbol = get(IPOPT_HSL_REQUIRED_SYMBOLS, String(linear_solver), nothing)
    required_symbol === nothing && return nothing

    handle = nothing
    try
        handle = Libdl.dlopen(String(hsllib_path))
        Libdl.dlsym(handle, Symbol(required_symbol))
    catch err
        throw(
            ArgumentError(
                "Configured HSL library for Ipopt linear_solver=$(linear_solver) does not " *
                "export $(required_symbol): $(hsllib_path). Install a full libHSL/HSL_jll " *
                "build with $(uppercase(String(linear_solver))) and set $(IPOPT_HSLLIB_ENV) " *
                "to that shared library. Original load error: $(err)",
            ),
        )
    finally
        handle === nothing || Libdl.dlclose(handle)
    end
    return nothing
end

function _ipopt_hsllib_from_package(package_name::AbstractString, uuid::AbstractString)
    pkg = Base.PkgId(Base.UUID(String(uuid)), String(package_name))
    module_ref =
        try
            Base.require(pkg)
        catch
            return nothing
        end
    for property in (:libhsl_path, :libhsl)
        hasproperty(module_ref, property) || continue
        value =
            try
                String(getproperty(module_ref, property))
            catch
                continue
            end
        !isempty(value) && return value
    end
    return nothing
end

function _ipopt_hsllib_from_artifact_search()
    libname =
        Sys.iswindows() ? "libhsl.dll" :
        Sys.isapple() ? "libhsl.dylib" :
        "libhsl.so"
    for depot in DEPOT_PATH
        artifact_dir = joinpath(depot, "artifacts")
        isdir(artifact_dir) || continue
        for (root, _, files) in walkdir(artifact_dir)
            libname in files || continue
            path = joinpath(root, libname)
            isfile(path) && return path
        end
    end
    return nothing
end

function _ipopt_warm_start_metadata(;
    source::AbstractString = "env_or_default",
)::Dict{String, Any}
    enabled = ipopt_warm_start_init_point_from_env()
    metadata = Dict{String, Any}(
        "ipopt_warm_start_init_point" => enabled,
        "ipopt_warm_start_init_point_option" => enabled ? "yes" : "no",
        "ipopt_warm_start_init_point_env" => IPOPT_WARM_START_INIT_POINT_ENV,
        "ipopt_warm_start_init_point_source" => String(source),
        "ipopt_warm_start_primal_starts_required" => true,
        "ipopt_warm_start_dual_starts_provided" => false,
    )
    merge!(metadata, _ipopt_warm_start_bound_options_metadata(source = source))
    return metadata
end

function _ipopt_warm_start_bound_options_metadata(;
    source::AbstractString = "env_or_default",
)::Dict{String, Any}
    option_specs = (
        (
            key = "ipopt_warm_start_bound_push",
            env = IPOPT_WARM_START_BOUND_PUSH_ENV,
            value = ipopt_warm_start_bound_push_from_env(),
        ),
        (
            key = "ipopt_warm_start_bound_frac",
            env = IPOPT_WARM_START_BOUND_FRAC_ENV,
            value = ipopt_warm_start_bound_frac_from_env(),
        ),
        (
            key = "ipopt_warm_start_slack_bound_push",
            env = IPOPT_WARM_START_SLACK_BOUND_PUSH_ENV,
            value = ipopt_warm_start_slack_bound_push_from_env(),
        ),
        (
            key = "ipopt_warm_start_slack_bound_frac",
            env = IPOPT_WARM_START_SLACK_BOUND_FRAC_ENV,
            value = ipopt_warm_start_slack_bound_frac_from_env(),
        ),
        (
            key = "ipopt_warm_start_mult_bound_push",
            env = IPOPT_WARM_START_MULT_BOUND_PUSH_ENV,
            value = ipopt_warm_start_mult_bound_push_from_env(),
        ),
    )
    metadata = Dict{String, Any}()
    for spec in option_specs
        metadata[spec.key] = spec.value === nothing ? missing : spec.value
        metadata["$(spec.key)_env"] = spec.env
        metadata["$(spec.key)_source"] = String(source)
    end
    return metadata
end

function _ipopt_max_wall_time_metadata(;
    source::AbstractString = "env_or_default",
)::Dict{String, Any}
    value = ipopt_max_wall_time_from_env()
    return Dict{String, Any}(
        "ipopt_max_wall_time_seconds" => value === nothing ? missing : value,
        "ipopt_max_wall_time_env" => IPOPT_MAX_WALL_TIME_ENV,
        "ipopt_max_wall_time_source" => String(source),
    )
end

function _ipopt_hessian_approximation_metadata(;
    source::AbstractString = "env_or_default",
)::Dict{String, Any}
    value = ipopt_hessian_approximation_from_env()
    configured = value !== nothing
    return Dict{String, Any}(
        "ipopt_hessian_approximation" => configured ? value : "exact",
        "ipopt_hessian_approximation_configured" => configured,
        "ipopt_hessian_approximation_env" => IPOPT_HESSIAN_APPROXIMATION_ENV,
        "ipopt_hessian_approximation_source" =>
            configured ? String(source) : "ipopt_default",
        "ipopt_hessian_approximation_supported_values" =>
            collect(IPOPT_HESSIAN_APPROXIMATION_VALUES),
    )
end

function _ipopt_env_print_level()::Int
    value = _ipopt_env_optional_nonnegative_int(
        "MPCC_IPOPT_PRINT_LEVEL",
        "MPCC_GLOBAL_POLISH_RETRY_IPOPT_PRINT_LEVEL",
    )
    return value === nothing ? 0 : value
end

function _ipopt_env_print_frequency_iter()
    return _ipopt_env_optional_positive_int(
        "MPCC_IPOPT_PRINT_FREQUENCY_ITER",
        "MPCC_GLOBAL_POLISH_RETRY_IPOPT_PRINT_FREQUENCY_ITER",
    )
end

function _ipopt_env_print_frequency_time()
    return _ipopt_env_optional_nonnegative_float(
        "MPCC_IPOPT_PRINT_FREQUENCY_TIME",
        "MPCC_GLOBAL_POLISH_RETRY_IPOPT_PRINT_FREQUENCY_TIME",
    )
end

function _ipopt_env_print_requested()::Bool
    return _ipopt_env_print_level() > 0
end

function _ipopt_env_optional_nonnegative_int(names::String...)
    raw = _ipopt_first_env_value(names...)
    raw === nothing && return nothing
    value = tryparse(Int, raw)
    value === nothing && throw(ArgumentError("Ipopt environment option must be an Int."))
    value >= 0 || throw(
        ArgumentError("Ipopt environment option must be nonnegative."),
    )
    return value
end

function _ipopt_env_optional_bool(name::String)
    raw = strip(get(ENV, name, ""))
    isempty(raw) && return nothing
    normalized = lowercase(raw)
    normalized in ("1", "true", "yes", "on") && return true
    normalized in ("0", "false", "no", "off") && return false
    throw(
        ArgumentError(
            "Ipopt environment option $name must be boolean: 1/0, true/false, yes/no, or on/off.",
        ),
    )
end

function _ipopt_env_optional_positive_int(names::String...)
    raw = _ipopt_first_env_value(names...)
    raw === nothing && return nothing
    value = tryparse(Int, raw)
    value === nothing && throw(ArgumentError("Ipopt environment option must be an Int."))
    value > 0 || throw(
        ArgumentError("Ipopt environment option must be positive."),
    )
    return value
end

function _ipopt_env_optional_nonnegative_float(names::String...)
    raw = _ipopt_first_env_value(names...)
    raw === nothing && return nothing
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError("Ipopt environment option must be a Float64."),
    )
    isfinite(value) && value >= 0.0 || throw(
        ArgumentError("Ipopt environment option must be finite and nonnegative."),
    )
    return value
end

function _ipopt_env_optional_positive_float(names::String...)
    raw = _ipopt_first_env_value(names...)
    raw === nothing && return nothing
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError("Ipopt environment option must be a Float64."),
    )
    isfinite(value) && value > 0.0 || throw(
        ArgumentError("Ipopt environment option must be finite and positive."),
    )
    return value
end

function _ipopt_first_env_value(names::String...)
    for name in names
        raw = strip(get(ENV, name, ""))
        isempty(raw) || return raw
    end
    return nothing
end

function _ipopt_positive_float_option(name::String, value::Union{Nothing, Real})
    value === nothing && return nothing
    float_value = Float64(value)
    isfinite(float_value) && float_value > 0.0 || throw(
        ArgumentError("Ipopt $(name) must be finite and positive when provided."),
    )
    return float_value
end

function _ipopt_nonnegative_float_option(name::String, value::Union{Nothing, Real})
    value === nothing && return nothing
    float_value = Float64(value)
    isfinite(float_value) && float_value >= 0.0 || throw(
        ArgumentError("Ipopt $(name) must be finite and nonnegative when provided."),
    )
    return float_value
end

function _ipopt_string_option(
    name::String,
    value::Union{Nothing, AbstractString},
    allowed::Tuple{Vararg{String}},
)
    value === nothing && return nothing
    normalized = lowercase(strip(String(value)))
    normalized in allowed || throw(
        ArgumentError(
            "Ipopt $(name) must be one of: $(join(allowed, ", ")). Got: $(value)",
        ),
    )
    return normalized
end

"""
    build_reduced_toy_nlp_smoke_problem(; optimizer=ipopt_optimizer(), silent=true)

Build a two-variable nonlinear smoke problem with a known local solution:
`x + y = 1.5`, `x*y = 0.5`, and objective
`(x - 1)^2 + (y - 0.5)^2`. The expected solution is `x = 1.0`,
`y = 0.5`.
"""
function build_reduced_toy_nlp_smoke_problem(;
    optimizer = ipopt_optimizer(),
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    silent::Bool = true,
)::ReducedToyNLPProblem
    jump_model = JuMP.Model(optimizer)
    silent && !_ipopt_env_print_requested() && JuMP.set_silent(jump_model)

    JuMP.@variable(jump_model, x >= 0.0, start = 0.8)
    JuMP.@variable(jump_model, y >= 0.0, start = 0.7)
    linear_constraint = JuMP.@constraint(jump_model, x + y == 1.5)
    bilinear_constraint = JuMP.@constraint(jump_model, x * y == 0.5)
    JuMP.@objective(jump_model, Min, (x - 1.0)^2 + (y - 0.5)^2)

    metadata = Dict{String, Any}(
        "problem_type" => "reduced_toy_nlp_smoke",
        "problem_scope" => "reduced_solver_setup_only",
        "optimizer" => "Ipopt",
        "dfba_model_loaded" => false,
        "dfvb_model_loaded" => false,
        "kkt_constraints_built" => false,
        "mpcc_complementarity_built" => false,
        "direct_collocation_dynamic_constraints_built" => false,
        "sequential_initialization_built" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "expected_x" => 1.0,
        "expected_y" => 0.5,
    )
    merge!(metadata, _ipopt_linear_solver_metadata(linear_solver))
    merge!(metadata, _ipopt_warm_start_metadata())
    merge!(metadata, _ipopt_max_wall_time_metadata())
    merge!(metadata, _ipopt_hessian_approximation_metadata())

    return ReducedToyNLPProblem(
        jump_model,
        x,
        y,
        linear_constraint,
        bilinear_constraint,
        metadata,
    )
end

"""
    solve_reduced_toy_nlp_smoke(; optimizer=ipopt_optimizer(), silent=true)

Solve the reduced toy NLP smoke problem with Ipopt and return compact solver
diagnostics. This function performs no DFBA, KKT, MPCC, or collocation-dynamic
solve.
"""
function solve_reduced_toy_nlp_smoke(;
    optimizer = ipopt_optimizer(),
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    silent::Bool = true,
)::ReducedToyNLPSmokeResult
    problem = build_reduced_toy_nlp_smoke_problem(;
        optimizer = optimizer,
        linear_solver = linear_solver,
        silent = silent,
    )
    JuMP.optimize!(problem.jump_model)

    status = JuMP.termination_status(problem.jump_model)
    primal_status = JuMP.primal_status(problem.jump_model)
    has_primal = primal_status == MOI.FEASIBLE_POINT
    x_value = has_primal ? Float64(JuMP.value(problem.x)) : NaN
    y_value = has_primal ? Float64(JuMP.value(problem.y)) : NaN
    objective_value = has_primal ? Float64(JuMP.objective_value(problem.jump_model)) : NaN

    metadata = copy(problem.metadata)
    metadata["solver_call_performed"] = true
    metadata["solver_status"] = string(status)
    metadata["primal_status"] = string(primal_status)
    metadata["solver_name"] = _ipopt_smoke_solver_name(problem.jump_model)
    metadata["solver_reported_solve_time_seconds"] =
        _ipopt_smoke_model_attribute_or_missing(problem.jump_model, MOI.SolveTimeSec())

    return ReducedToyNLPSmokeResult(
        status,
        primal_status,
        objective_value,
        x_value,
        y_value,
        x_value + y_value - 1.5,
        x_value * y_value - 0.5,
        metadata["solver_name"],
        metadata,
    )
end

function _ipopt_smoke_solver_name(jump_model::JuMP.Model)::String
    return try
        JuMP.solver_name(jump_model)
    catch
        "unknown"
    end
end

function _ipopt_smoke_model_attribute_or_missing(jump_model::JuMP.Model, attr)
    return try
        MOI.get(JuMP.backend(jump_model), attr)
    catch
        missing
    end
end
