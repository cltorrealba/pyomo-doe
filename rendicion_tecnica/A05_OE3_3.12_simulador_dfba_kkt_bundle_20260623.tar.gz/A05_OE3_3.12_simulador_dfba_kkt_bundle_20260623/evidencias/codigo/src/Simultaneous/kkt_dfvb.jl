"""
    build_kkt_dfvb_problem(args...; kwargs...)

Placeholder for the future simultaneous KKT/MPCC reduced DFVB formulation.

TODO: Implement only after the reduced DFVB null-space data contract is defined.
"""
function build_kkt_dfvb_problem(args...; kwargs...)
    error("Not implemented yet")
end
