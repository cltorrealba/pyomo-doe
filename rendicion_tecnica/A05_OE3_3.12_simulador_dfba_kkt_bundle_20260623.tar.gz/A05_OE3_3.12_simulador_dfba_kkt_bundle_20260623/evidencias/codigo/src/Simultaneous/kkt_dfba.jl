const KKT_DFBA_STATE_COUNT = 19

const KKT_DFBA_REQUIRED_CORE_ROLES = (
    "biomass_growth",
    "glucose_exchange",
    "fructose_exchange",
    "ethanol_exchange",
    "atp_maintenance",
    "protein_exchange",
    "carbohydrate_exchange",
)

"""
    KKTDFBADimensions

Dimension counts for the reduced KKT-DFBA scaffold over a finite-element
collocation grid. These are structural counts only; no JuMP variables are
created here.
"""
struct KKTDFBADimensions
    n_states::Int
    n_metabolites::Int
    n_reactions::Int
    nfe::Int
    collocation_degree::Int
    n_collocation_points::Int
    n_state_boundary_variables::Int
    n_state_collocation_variables::Int
    n_flux_variables::Int
    n_mass_balance_dual_variables::Int
    n_lower_bound_dual_variables::Int
    n_upper_bound_dual_variables::Int
    n_primal_variables::Int
    n_dual_variables::Int
    n_total_variables::Int
end

"""
    KKTDFBAConstraintLayout

Structural equation and complementarity-pair counts expected in a future
reduced KKT-DFBA MPCC. This scaffold records counts but does not build
constraints.
"""
struct KKTDFBAConstraintLayout
    mass_balance::Int
    lower_bound_feasibility::Int
    upper_bound_feasibility::Int
    stationarity::Int
    lower_bound_complementarity::Int
    upper_bound_complementarity::Int
    ode_residual::Int
    continuity::Int
    initial_condition::Int
    total_structural_relations::Int
end

"""
    KKTDFBAReactionRoles

Reaction IDs needed by the reduced DFBA KKT scaffold. Oxygen remains recorded
as `r_1992` for policy metadata, but it must be absent from the reduced model.
"""
struct KKTDFBAReactionRoles
    biomass_growth::String
    glucose_exchange::String
    fructose_exchange::String
    ethanol_exchange::String
    oxygen_exchange::String
    atp_maintenance::String
    protein_exchange::String
    carbohydrate_exchange::String
    nitrogen_sources::Vector{String}
    amino_acids::Vector{String}
    aromas::Vector{String}
    dynamic_bound_reactions::Vector{String}
    objective_reactions::Vector{String}
end

"""
    KKTDFBAProblem

Reduced KKT-DFBA scaffold binding a metabolic model, reaction map, collocation
grid, dimensions, and reaction-role contract. This is not a JuMP model and does
not solve an MPCC.
"""
struct KKTDFBAProblem
    model::MetabolicModel
    reaction_map::ReactionMap
    grid::FiniteElementGrid
    params::ZentenoKineticParameters
    dimensions::KKTDFBADimensions
    constraint_layout::KKTDFBAConstraintLayout
    reaction_roles::KKTDFBAReactionRoles
    metadata::Dict{String, Any}
end

"""
    build_kkt_dfba_problem(model, reaction_map, grid; params=default_zenteno_parameters(), model_scope="reduced")

Build a reduced KKT-DFBA structural scaffold over an existing finite-element
collocation grid. No solver, JuMP NLP, KKT equations, or complementarity
constraints are constructed.
"""
function build_kkt_dfba_problem(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    grid::FiniteElementGrid;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    model_scope::AbstractString = "reduced",
)::KKTDFBAProblem
    _validate_kkt_dfba_scope(model_scope)
    _validate_kkt_dfba_reduced_model_contract(model, reaction_map)
    reaction_roles = _kkt_dfba_reaction_roles(model, reaction_map, params)
    dimensions = _kkt_dfba_dimensions(model, grid)
    constraint_layout = _kkt_dfba_constraint_layout(dimensions)
    metadata = _kkt_dfba_metadata(model, grid, reaction_roles)

    return KKTDFBAProblem(
        model,
        reaction_map,
        grid,
        params,
        dimensions,
        constraint_layout,
        reaction_roles,
        metadata,
    )
end

"""
    build_kkt_dfba_problem(model, reaction_map; tspan, nfe, degree=3, kwargs...)

Build a finite-element collocation grid, then return the reduced KKT-DFBA
structural scaffold.
"""
function build_kkt_dfba_problem(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    tspan::Tuple{<:Real, <:Real},
    nfe::Int,
    degree::Int = 3,
    element_bounds::Union{Nothing, AbstractVector{<:Tuple{<:Real, <:Real}}} = nothing,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    model_scope::AbstractString = "reduced",
)::KKTDFBAProblem
    requested_tspan = (Float64(tspan[1]), Float64(tspan[2]))
    grid =
        element_bounds === nothing ?
        build_finite_element_grid(requested_tspan; nfe = nfe, degree = degree) :
        build_finite_element_grid(element_bounds; degree = degree)
    grid.nfe == nfe || throw(
        ArgumentError(
            "Explicit finite-element grid has nfe=$(grid.nfe), but nfe=$nfe was requested.",
        ),
    )
    isapprox(grid.tspan[1], requested_tspan[1]; atol = 100.0 * eps(Float64), rtol = 0.0) &&
        isapprox(grid.tspan[2], requested_tspan[2]; atol = 100.0 * eps(Float64), rtol = 0.0) ||
        throw(
            ArgumentError(
                "Explicit finite-element grid tspan $(grid.tspan) does not match requested tspan $requested_tspan.",
            ),
        )
    return build_kkt_dfba_problem(
        model,
        reaction_map,
        grid;
        params = params,
        model_scope = model_scope,
    )
end

function _validate_kkt_dfba_scope(model_scope::AbstractString)
    normalized = lowercase(strip(String(model_scope)))
    normalized == "reduced" || throw(
        ArgumentError(
            "KKT-DFBA scaffold currently supports model_scope=\"reduced\" only; got \"$model_scope\".",
        ),
    )
    return nothing
end

function _validate_kkt_dfba_reduced_model_contract(model::MetabolicModel, reaction_map::ReactionMap)
    size(model.S, 2) == length(model.rxn_ids) || throw(
        ArgumentError("KKT-DFBA scaffold requires one reaction ID per stoichiometric column."),
    )
    size(model.S, 1) == length(model.met_ids) || throw(
        ArgumentError("KKT-DFBA scaffold requires one metabolite ID per stoichiometric row."),
    )
    length(model.lb) == length(model.rxn_ids) || throw(
        ArgumentError("KKT-DFBA scaffold lower-bound vector length must match reaction count."),
    )
    length(model.ub) == length(model.rxn_ids) || throw(
        ArgumentError("KKT-DFBA scaffold upper-bound vector length must match reaction count."),
    )
    all(isfinite, model.lb) || throw(ArgumentError("KKT-DFBA scaffold lower bounds must be finite."))
    all(isfinite, model.ub) || throw(ArgumentError("KKT-DFBA scaffold upper bounds must be finite."))
    all(model.lb .<= model.ub) || throw(ArgumentError("KKT-DFBA scaffold requires lb <= ub."))

    _kkt_dfba_oxygen_not_r0001(reaction_map)
    has_reaction(model, "r_1992") && throw(
        ArgumentError(
            "KKT-DFBA scaffold must start from the reduced model; r_1992 is present, which indicates a full-scope oxygen reaction.",
        ),
    )
    get(reaction_map.disabled_reactions, "oxygen_exchange", "") == "r_1992" || throw(
        ArgumentError(
            "KKT-DFBA scaffold requires oxygen_exchange r_1992 to be explicitly disabled for the reduced model.",
        ),
    )

    report = validate_reaction_map(model, reaction_map)
    report.ok || throw(
        ArgumentError(
            "KKT-DFBA scaffold reaction-map validation failed. Missing reactions: " *
            "$(report.missing_required_reactions).",
        ),
    )
    return nothing
end

function _kkt_dfba_oxygen_not_r0001(reaction_map::ReactionMap)
    oxygen_id = strip(get(reaction_map.core, "oxygen_exchange", ""))
    disabled_oxygen_id = strip(get(reaction_map.disabled_reactions, "oxygen_exchange", ""))
    (oxygen_id == "r_0001" || disabled_oxygen_id == "r_0001") && throw(
        ArgumentError("KKT-DFBA scaffold oxygen_exchange must not map to r_0001."),
    )
    return nothing
end

function _kkt_dfba_reaction_roles(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    params::ZentenoKineticParameters,
)::KKTDFBAReactionRoles
    core_ids = Dict(
        role => _kkt_dfba_required_core_reaction_id(model, reaction_map, role) for
        role in KKT_DFBA_REQUIRED_CORE_ROLES
    )
    nitrogen_sources = [
        _kkt_dfba_required_group_reaction_id(model, reaction_map.nitrogen_sources, rxn_id, "nitrogen_sources") for
        rxn_id in params.nitrogen_source_ids
    ]
    amino_acids = [
        _kkt_dfba_required_group_role_id(model, reaction_map.amino_acids, role, "amino_acids") for
        role in ZENTENO_AMINO_ACID_ROLES
    ]
    aromas = [
        _kkt_dfba_required_group_role_id(model, reaction_map.aromas, role, "aromas") for
        role in ZENTENO_AROMA_ROLES
    ]

    dynamic_bound_reactions = sort(
        collect(
            Set(
                String[
                    core_ids["biomass_growth"],
                    core_ids["glucose_exchange"],
                    core_ids["fructose_exchange"],
                    core_ids["ethanol_exchange"],
                    core_ids["atp_maintenance"],
                    core_ids["protein_exchange"],
                    nitrogen_sources...,
                    amino_acids...,
                    aromas...,
                ],
            ),
        ),
    )
    objective_reactions = sort(
        collect(
            Set(
                String[
                    core_ids["biomass_growth"],
                    core_ids["atp_maintenance"],
                    core_ids["protein_exchange"],
                    amino_acids...,
                ],
            ),
        ),
    )

    return KKTDFBAReactionRoles(
        core_ids["biomass_growth"],
        core_ids["glucose_exchange"],
        core_ids["fructose_exchange"],
        core_ids["ethanol_exchange"],
        "r_1992",
        core_ids["atp_maintenance"],
        core_ids["protein_exchange"],
        core_ids["carbohydrate_exchange"],
        nitrogen_sources,
        amino_acids,
        aromas,
        dynamic_bound_reactions,
        objective_reactions,
    )
end

function _kkt_dfba_required_core_reaction_id(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    role::AbstractString,
)::String
    return _kkt_dfba_required_group_role_id(model, reaction_map.core, role, "core")
end

function _kkt_dfba_required_group_role_id(
    model::MetabolicModel,
    group::Dict{String, String},
    role::AbstractString,
    group_name::AbstractString,
)::String
    role_key = String(role)
    haskey(group, role_key) || throw(
        ArgumentError("KKT-DFBA scaffold missing required $group_name reaction-map role: $role_key."),
    )
    rxn_id = strip(group[role_key])
    isempty(rxn_id) && throw(
        ArgumentError("KKT-DFBA scaffold reaction-map role $role_key in $group_name has an empty reaction ID."),
    )
    has_reaction(model, rxn_id) || throw(
        ArgumentError("KKT-DFBA scaffold reaction-map role $role_key references missing reaction ID $rxn_id."),
    )
    return rxn_id
end

function _kkt_dfba_required_group_reaction_id(
    model::MetabolicModel,
    group::Dict{String, String},
    rxn_id::AbstractString,
    group_name::AbstractString,
)::String
    cleaned_id = strip(String(rxn_id))
    cleaned_id in values(group) || throw(
        ArgumentError(
            "KKT-DFBA scaffold reaction ID $cleaned_id is not configured in reaction-map group $group_name.",
        ),
    )
    has_reaction(model, cleaned_id) || throw(
        ArgumentError("KKT-DFBA scaffold reaction ID $cleaned_id is missing from the reduced model."),
    )
    return cleaned_id
end

function _kkt_dfba_dimensions(model::MetabolicModel, grid::FiniteElementGrid)::KKTDFBADimensions
    n_states = KKT_DFBA_STATE_COUNT
    n_metabolites = size(model.S, 1)
    n_reactions = size(model.S, 2)
    nfe = grid.nfe
    degree = grid.scheme.degree
    n_collocation_points = nfe * degree

    n_state_boundary_variables = n_states * (nfe + 1)
    n_state_collocation_variables = n_states * n_collocation_points
    n_flux_variables = n_reactions * n_collocation_points
    n_mass_balance_dual_variables = n_metabolites * n_collocation_points
    n_lower_bound_dual_variables = n_reactions * n_collocation_points
    n_upper_bound_dual_variables = n_reactions * n_collocation_points
    n_primal_variables =
        n_state_boundary_variables + n_state_collocation_variables + n_flux_variables
    n_dual_variables =
        n_mass_balance_dual_variables + n_lower_bound_dual_variables + n_upper_bound_dual_variables
    n_total_variables = n_primal_variables + n_dual_variables

    return KKTDFBADimensions(
        n_states,
        n_metabolites,
        n_reactions,
        nfe,
        degree,
        n_collocation_points,
        n_state_boundary_variables,
        n_state_collocation_variables,
        n_flux_variables,
        n_mass_balance_dual_variables,
        n_lower_bound_dual_variables,
        n_upper_bound_dual_variables,
        n_primal_variables,
        n_dual_variables,
        n_total_variables,
    )
end

function _kkt_dfba_constraint_layout(dimensions::KKTDFBADimensions)::KKTDFBAConstraintLayout
    mass_balance = dimensions.n_metabolites * dimensions.n_collocation_points
    lower_bound_feasibility = dimensions.n_reactions * dimensions.n_collocation_points
    upper_bound_feasibility = dimensions.n_reactions * dimensions.n_collocation_points
    stationarity = dimensions.n_reactions * dimensions.n_collocation_points
    lower_bound_complementarity = dimensions.n_reactions * dimensions.n_collocation_points
    upper_bound_complementarity = dimensions.n_reactions * dimensions.n_collocation_points
    ode_residual = dimensions.n_states * dimensions.n_collocation_points
    continuity = dimensions.n_states * dimensions.nfe
    initial_condition = dimensions.n_states
    total_structural_relations =
        mass_balance +
        lower_bound_feasibility +
        upper_bound_feasibility +
        stationarity +
        lower_bound_complementarity +
        upper_bound_complementarity +
        ode_residual +
        continuity +
        initial_condition

    return KKTDFBAConstraintLayout(
        mass_balance,
        lower_bound_feasibility,
        upper_bound_feasibility,
        stationarity,
        lower_bound_complementarity,
        upper_bound_complementarity,
        ode_residual,
        continuity,
        initial_condition,
        total_structural_relations,
    )
end

function _kkt_dfba_metadata(
    model::MetabolicModel,
    grid::FiniteElementGrid,
    reaction_roles::KKTDFBAReactionRoles,
)::Dict{String, Any}
    return Dict{String, Any}(
        "problem_type" => "reduced_kkt_dfba_scaffold",
        "model_scope" => "reduced",
        "model_id" => model.model_id,
        "grid_tspan" => grid.tspan,
        "grid_nfe" => grid.nfe,
        "grid_element_lengths_h" =>
            [element_bounds(grid, element_index)[2] - element_bounds(grid, element_index)[1] for element_index in 1:grid.nfe],
        "grid_min_element_length_h" =>
            minimum(element_bounds(grid, element_index)[2] - element_bounds(grid, element_index)[1] for element_index in 1:grid.nfe),
        "grid_max_element_length_h" =>
            maximum(element_bounds(grid, element_index)[2] - element_bounds(grid, element_index)[1] for element_index in 1:grid.nfe),
        "collocation_degree" => grid.scheme.degree,
        "state_count" => KKT_DFBA_STATE_COUNT,
        "flux_discretization" => "one flux vector per collocation point",
        "state_discretization" => "boundary and collocation state variables",
        "lp_primal_feasibility_component" => "S*v = 0 at each collocation point",
        "lp_bound_feasibility_component" => "lb(y) <= v <= ub(y) at each collocation point",
        "lp_stationarity_component" => "future reduced FBA KKT stationarity rows",
        "lp_complementarity_component" => "future lower/upper bound complementarity pairs",
        "dynamic_component" => "future ODE residual and finite-element continuity rows",
        "jump_model_built" => false,
        "solver_call_performed" => false,
        "ipopt_required" => false,
        "hsl_required" => false,
        "kkt_constraints_built" => false,
        "mpcc_complementarity_built" => false,
        "direct_collocation_dynamic_constraints_built" => false,
        "sequential_initialization_built" => false,
        "dfvb_kkt_deferred" => true,
        "full_model_kkt_deferred" => true,
        "first_mpcc_target" => "reduced_dfba",
        "sequential_scientific_baseline" => "full_dfba_cold",
        "persistent_lp_warm_start_policy" => "diagnostic_only_not_scientific_equivalence",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "oxygen_exchange_reaction_id" => reaction_roles.oxygen_exchange,
        "oxygen_exchange_present" => false,
        "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
        "carbohydrate_exchange_reaction_id" => reaction_roles.carbohydrate_exchange,
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "weighted_objective_value_is_biomass_flux" => false,
        "dynamic_bound_reaction_ids" => copy(reaction_roles.dynamic_bound_reactions),
        "objective_reaction_ids" => copy(reaction_roles.objective_reactions),
    )
end
