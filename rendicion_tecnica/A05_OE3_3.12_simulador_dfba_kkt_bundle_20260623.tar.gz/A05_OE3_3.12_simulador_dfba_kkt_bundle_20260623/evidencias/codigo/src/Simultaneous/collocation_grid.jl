"""
    RadauCollocationScheme

Numerical data for a Radau-right collocation rule on the normalized interval
`[0, 1]`.
"""
struct RadauCollocationScheme
    degree::Int
    nodes::Vector{Float64}
    weights::Vector{Float64}
    integration_matrix::Matrix{Float64}
    differentiation_matrix::Matrix{Float64}
    support_nodes::Vector{Float64}
    continuity_weights::Vector{Float64}
end

"""
    FiniteElementGrid

Finite-element grid with Radau collocation times for each element.
"""
struct FiniteElementGrid
    tspan::Tuple{Float64, Float64}
    nfe::Int
    scheme::RadauCollocationScheme
    element_bounds::Vector{Tuple{Float64, Float64}}
    collocation_times::Matrix{Float64}
end

"""
    radau_collocation_scheme(degree::Int = 3)

Build a Radau-right collocation scheme on `[0, 1]`. Only degree 3 is supported
for now, matching the De Oliveira-style `colmat` used by the local antecedent
implementation.
"""
function radau_collocation_scheme(degree::Int = 3)::RadauCollocationScheme
    degree == 3 || throw(
        ArgumentError(
            "Only Radau-right collocation degree 3 is supported, got degree=$degree.",
        ),
    )

    nodes = [
        (4.0 - sqrt(6.0)) / 10.0,
        (4.0 + sqrt(6.0)) / 10.0,
        1.0,
    ]
    weights = [
        (16.0 - sqrt(6.0)) / 36.0,
        (16.0 + sqrt(6.0)) / 36.0,
        1.0 / 9.0,
    ]
    integration_matrix = _collocation_integration_matrix(nodes)
    support_nodes = [0.0; nodes]
    differentiation_matrix = _collocation_differentiation_matrix(support_nodes, nodes)
    continuity_weights = copy(view(integration_matrix, degree, :))

    scheme = RadauCollocationScheme(
        degree,
        nodes,
        weights,
        integration_matrix,
        differentiation_matrix,
        support_nodes,
        continuity_weights,
    )
    _validate_radau_collocation_scheme(scheme)
    return scheme
end

"""
    build_finite_element_grid(tspan; nfe, degree=3)

Build a uniform finite-element grid and map Radau collocation nodes from the
local interval `[0, 1]` to global time.
"""
function build_finite_element_grid(
    tspan::Tuple{Float64, Float64};
    nfe::Int,
    degree::Int = 3,
)::FiniteElementGrid
    _validate_collocation_tspan(tspan)
    nfe > 0 || throw(ArgumentError("Finite-element grid nfe must be positive, got nfe=$nfe."))

    scheme = radau_collocation_scheme(degree)
    t0, tf = tspan
    element_size = (tf - t0) / nfe
    element_bounds = [
        (t0 + (element_index - 1) * element_size, t0 + element_index * element_size) for
        element_index in 1:nfe
    ]
    collocation_times = Matrix{Float64}(undef, nfe, scheme.degree)
    for element_index in 1:nfe
        left, right = element_bounds[element_index]
        length = right - left
        for collocation_index in 1:scheme.degree
            collocation_times[element_index, collocation_index] =
                left + scheme.nodes[collocation_index] * length
        end
    end

    return FiniteElementGrid(tspan, nfe, scheme, element_bounds, collocation_times)
end

"""
    build_finite_element_grid(element_bounds; degree=3)

Build a finite-element grid from explicit element bounds and map Radau
collocation nodes from the local interval `[0, 1]` to global time. Bounds must
be contiguous and strictly increasing.
"""
function build_finite_element_grid(
    raw_element_bounds::AbstractVector{<:Tuple{<:Real, <:Real}};
    degree::Int = 3,
)::FiniteElementGrid
    isempty(raw_element_bounds) &&
        throw(ArgumentError("Finite-element grid element_bounds must not be empty."))

    scheme = radau_collocation_scheme(degree)
    element_bounds = [
        (Float64(left), Float64(right)) for (left, right) in raw_element_bounds
    ]
    _validate_element_bounds(element_bounds)
    nfe = length(element_bounds)
    tspan = (element_bounds[1][1], element_bounds[end][2])

    collocation_times = Matrix{Float64}(undef, nfe, scheme.degree)
    for element_index in 1:nfe
        left, right = element_bounds[element_index]
        length = right - left
        for collocation_index in 1:scheme.degree
            collocation_times[element_index, collocation_index] =
                left + scheme.nodes[collocation_index] * length
        end
    end

    return FiniteElementGrid(tspan, nfe, scheme, element_bounds, collocation_times)
end

"""
    build_collocation_grid(tspan; nfe, degree=3)

Alias for `build_finite_element_grid`.
"""
function build_collocation_grid(
    tspan::Tuple{Float64, Float64};
    nfe::Int,
    degree::Int = 3,
)::FiniteElementGrid
    return build_finite_element_grid(tspan; nfe = nfe, degree = degree)
end

"""
    collocation_time(grid, element_index, collocation_index)

Return one global collocation time from a finite-element grid.
"""
function collocation_time(
    grid::FiniteElementGrid,
    element_index::Int,
    collocation_index::Int,
)::Float64
    _validate_element_index(grid, element_index)
    1 <= collocation_index <= grid.scheme.degree || throw(
        ArgumentError(
            "Collocation index must be in 1:$(grid.scheme.degree), got $collocation_index.",
        ),
    )
    return grid.collocation_times[element_index, collocation_index]
end

"""
    element_bounds(grid, element_index)

Return `(left, right)` time bounds for one finite element.
"""
function element_bounds(grid::FiniteElementGrid, element_index::Int)::Tuple{Float64, Float64}
    _validate_element_index(grid, element_index)
    return grid.element_bounds[element_index]
end

"""
    element_length(grid, element_index)

Return the time length of one finite element.
"""
function element_length(grid::FiniteElementGrid, element_index::Int)::Float64
    left, right = element_bounds(grid, element_index)
    return right - left
end

function _validate_collocation_tspan(tspan::Tuple{Float64, Float64})
    all(isfinite, tspan) || throw(ArgumentError("Finite-element grid tspan values must be finite."))
    tspan[2] > tspan[1] || throw(
        ArgumentError("Finite-element grid tspan must satisfy tspan[2] > tspan[1]."),
    )
    return nothing
end

function _validate_element_bounds(element_bounds::AbstractVector{<:Tuple{Float64, Float64}})
    isempty(element_bounds) &&
        throw(ArgumentError("Finite-element grid element_bounds must not be empty."))
    for (index, (left, right)) in pairs(element_bounds)
        isfinite(left) && isfinite(right) ||
            throw(ArgumentError("Finite-element grid element bounds must be finite."))
        right > left || throw(
            ArgumentError(
                "Finite-element grid element $index must satisfy right > left; got ($left, $right).",
            ),
        )
        if index > firstindex(element_bounds)
            previous_right = element_bounds[index - 1][2]
            isapprox(left, previous_right; atol = 100.0 * eps(Float64), rtol = 0.0) ||
                throw(
                    ArgumentError(
                        "Finite-element grid element bounds must be contiguous; element $index starts at $left after previous right bound $previous_right.",
                    ),
                )
        end
    end
    _validate_collocation_tspan((element_bounds[1][1], element_bounds[end][2]))
    return nothing
end

function _validate_element_index(grid::FiniteElementGrid, element_index::Int)
    1 <= element_index <= grid.nfe || throw(
        ArgumentError("Element index must be in 1:$(grid.nfe), got $element_index."),
    )
    return nothing
end

function _validate_radau_collocation_scheme(scheme::RadauCollocationScheme)
    scheme.degree == 3 || throw(ArgumentError("Radau collocation scheme degree must be 3."))
    length(scheme.nodes) == scheme.degree ||
        throw(ArgumentError("Radau collocation nodes length must match degree."))
    length(scheme.weights) == scheme.degree ||
        throw(ArgumentError("Radau collocation weights length must match degree."))
    size(scheme.integration_matrix) == (scheme.degree, scheme.degree) ||
        throw(ArgumentError("Radau integration matrix must be degree x degree."))
    size(scheme.differentiation_matrix) == (scheme.degree, scheme.degree + 1) ||
        throw(ArgumentError("Radau differentiation matrix must be degree x (degree + 1)."))
    scheme.support_nodes == [0.0; scheme.nodes] ||
        throw(ArgumentError("Radau support nodes must equal [0.0; nodes]."))
    length(scheme.continuity_weights) == scheme.degree ||
        throw(ArgumentError("Radau continuity weights length must match degree."))
    all(isfinite, scheme.nodes) || throw(ArgumentError("Radau nodes must be finite."))
    all(node -> 0.0 <= node <= 1.0, scheme.nodes) ||
        throw(ArgumentError("Radau nodes must be in [0, 1]."))
    isapprox(scheme.nodes[end], 1.0; atol = 10 * eps(Float64), rtol = 0.0) ||
        throw(ArgumentError("Radau-right scheme must include the right endpoint 1.0."))
    isapprox(sum(scheme.weights), 1.0; atol = 100 * eps(Float64), rtol = 0.0) ||
        throw(ArgumentError("Radau weights must sum to 1.0."))
    isapprox(scheme.continuity_weights, scheme.weights; atol = 100 * eps(Float64), rtol = 0.0) ||
        throw(ArgumentError("Radau continuity weights must match quadrature weights."))
    return nothing
end

function _collocation_integration_matrix(nodes::Vector{Float64})::Matrix{Float64}
    degree = length(nodes)
    matrix = Matrix{Float64}(undef, degree, degree)
    for basis_index in 1:degree
        coefficients = _lagrange_basis_coefficients(nodes, basis_index)
        for node_index in 1:degree
            matrix[node_index, basis_index] = _polynomial_integral_at(coefficients, nodes[node_index])
        end
    end
    return matrix
end

function _collocation_differentiation_matrix(
    support_nodes::Vector{Float64},
    evaluation_nodes::Vector{Float64},
)::Matrix{Float64}
    degree = length(evaluation_nodes)
    matrix = Matrix{Float64}(undef, degree, length(support_nodes))
    for basis_index in eachindex(support_nodes)
        coefficients = _lagrange_basis_coefficients(support_nodes, basis_index)
        for node_index in 1:degree
            matrix[node_index, basis_index] =
                _polynomial_derivative_at(coefficients, evaluation_nodes[node_index])
        end
    end
    return matrix
end

function _lagrange_basis_coefficients(nodes::Vector{Float64}, basis_index::Int)::Vector{Float64}
    1 <= basis_index <= length(nodes) ||
        throw(ArgumentError("Lagrange basis index is outside the node set."))
    coefficients = [1.0]
    denominator = 1.0
    center = nodes[basis_index]
    for node_index in eachindex(nodes)
        node_index == basis_index && continue
        node = nodes[node_index]
        coefficients = _multiply_by_linear_factor(coefficients, -node, 1.0)
        denominator *= center - node
    end
    denominator != 0.0 || throw(ArgumentError("Lagrange nodes must be distinct."))
    return coefficients ./ denominator
end

function _multiply_by_linear_factor(
    coefficients::Vector{Float64},
    constant::Float64,
    linear::Float64,
)::Vector{Float64}
    result = zeros(Float64, length(coefficients) + 1)
    for index in eachindex(coefficients)
        result[index] += constant * coefficients[index]
        result[index + 1] += linear * coefficients[index]
    end
    return result
end

function _polynomial_integral_at(coefficients::Vector{Float64}, x::Float64)::Float64
    value = 0.0
    power = x
    for index in eachindex(coefficients)
        value += coefficients[index] * power / index
        power *= x
    end
    return value
end

function _polynomial_derivative_at(coefficients::Vector{Float64}, x::Float64)::Float64
    value = 0.0
    power = 1.0
    for index in 2:length(coefficients)
        value += (index - 1) * coefficients[index] * power
        power *= x
    end
    return value
end
