import JuMP
import MathOptInterface as MOI

const REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER = 100
const REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_TOL = 1.0e-6
const REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_TOL = 1.0e-5
const REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_CONSTR_VIOL_TOL = 1.0e-6
const REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_COMPL_INF_TOL = 1.0e-5
const REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_DUAL_INF_TOL = 1.0e-5
const REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_ITER = 5
const REDUCED_DCDFBA_MPCC_DEFAULT_IPOPT_PROFILE = "acceptable"
const REDUCED_DCDFBA_MPCC_IPOPT_PROFILE_ENV = "MPCC_REDUCED_MPCC_IPOPT_PROFILE"
const REDUCED_DCDFBA_MPCC_IPOPT_PROFILE_NAMES =
    ("strict", "acceptable", "feasibility_first", "feasibility_handoff", "stability")
const REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_ENV = "MPCC_COMPLEMENTARITY_MODE"
const REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_TAU_ENV = "MPCC_COMPLEMENTARITY_TAU"
const REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_TAU_GATE_TOL_ENV =
    "MPCC_COMPLEMENTARITY_TAU_GATE_TOL"
const REDUCED_DCDFBA_MPCC_SKIP_NLP_BLOCK_VIOLATION_ROWS_ENV =
    "MPCC_GLOBAL_POLISH_SKIP_NLP_BLOCK_VIOLATION_ROWS"
const REDUCED_DCDFBA_MPCC_TAU_SCHEDULE_ENV = "MPCC_TAU_SCHEDULE"
const REDUCED_DCDFBA_MPCC_TAU_STAGE_MAX_ITERS_ENV = "MPCC_TAU_STAGE_MAX_ITERS"
const REDUCED_DCDFBA_MPCC_TAU_FINAL_RETRY_MAX_ITER_ENV =
    "MPCC_TAU_FINAL_RETRY_MAX_ITER"
const REDUCED_DCDFBA_MPCC_TAU_STAGE_ADVANCE_MAX_STRUCTURAL_RATIO_ENV =
    "MPCC_TAU_STAGE_ADVANCE_MAX_STRUCTURAL_RATIO"
const REDUCED_DCDFBA_MPCC_TAU_STAGE_ADVANCE_MAX_COMPLEMENTARITY_RATIO_ENV =
    "MPCC_TAU_STAGE_ADVANCE_MAX_COMPLEMENTARITY_RATIO"
const REDUCED_DCDFBA_MPCC_TAU_STAGE_RECOVERY_CONTINUE_ENV =
    "MPCC_TAU_STAGE_RECOVERY_CONTINUE"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_REFERENCE_REGULARIZATION_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_REFERENCE_REGULARIZATION_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TARGET_STATE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TARGET_STATE"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_REWARD_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_REWARD_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_STATE_SCALE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_STATE_SCALE_G_L"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_SCALE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_SCALE_G_L"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_SCALE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_SCALE_G_L"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_POLICY_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_POLICY"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_MAX_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_MAX_G_L"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_REWARD_POLICY_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_REWARD_POLICY"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_FDA_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_FDA_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_ORGANIC_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_ORGANIC_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_SCALE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_SCALE_G_L"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_THERMAL_ENERGY_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_THERMAL_ENERGY_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AMBIENT_TEMPERATURE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_AMBIENT_TEMPERATURE_C"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SCALE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SCALE_C"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_SCALE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_SCALE_C"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_DEFICIT_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_DEFICIT_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_DEFICIT_TARGET_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_DEFICIT_TARGET_G_L"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_DEFICIT_SCALE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_DEFICIT_SCALE_G_L"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_EXCESS_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_EXCESS_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_MAX_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_MAX_G_L"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_EXCESS_SCALE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_EXCESS_SCALE_G_L"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_TEMPERATURE_REWARD_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_TEMPERATURE_REWARD_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_FDA_REWARD_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_FDA_REWARD_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_ORGANIC_REWARD_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_ORGANIC_REWARD_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_WEIGHT_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_WEIGHT"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_STATE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_STATE"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_ELEMENTS_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_ELEMENTS"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_SCALE_ENV =
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_SCALE_G_L"
const REDUCED_DCDFBA_MPCC_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS_ENV =
    "MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS"
const REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_ENV =
    "MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START"
const REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_MAX_ITER_ENV =
    "MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START_MAX_ITER"
const REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_TOL_ENV =
    "MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START_TOL"
const REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_ELEMENTS_ENV =
    "MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START_ELEMENTS"
const REDUCED_DCDFBA_MPCC_FLUX_DUAL_START_MODE_ENV =
    "MPCC_FIXED_CONTROL_FLUX_DUAL_START_MODE"
const REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_ENV =
    "MPCC_REDUCED_DCDFBA_BASE_OBJECTIVE_MODE"
const REDUCED_DCDFBA_MPCC_STATE_NONNEGATIVE_BOUNDS_ENV =
    "MPCC_REDUCED_DCDFBA_STATE_NONNEGATIVE_BOUNDS"
const REDUCED_DCDFBA_MPCC_STATE_NONNEGATIVE_START_CLAMP_ENV =
    "MPCC_REDUCED_DCDFBA_STATE_NONNEGATIVE_START_CLAMP"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_OFF = "off"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_AROMA_NUTRIENT_ENERGY =
    "aroma_nutrient_energy"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_AROMA_REWARD_POLICY_TERMINAL = "terminal"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_AROMA_REWARD_POLICY_TERMINAL_PLUS_INTEGRATED_FLUX =
    "terminal_plus_integrated_flux"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_INTEGRATED_SUGAR_POLICY_SQUARED_TOTAL =
    "squared_total"
const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_INTEGRATED_SUGAR_POLICY_EXCESS_SLACK =
    "excess_slack"
const REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_STATE_DERIVATIVE_L2 =
    "state_derivative_l2"
const REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_ZERO = "zero"
const REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_EXACT = "exact"
const REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES = "scholtes"
const REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODES = (
    REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_EXACT,
    REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
)
const REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU = 1.0e-4
const REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU_GATE_ABS_TOL = 1.0e-8
const REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU_GATE_REL_TOL = 1.0e-3
const REDUCED_DCDFBA_MPCC_DEFAULT_TAU_SCHEDULE = [1.0e-2, 1.0e-4, 1.0e-6]
const REDUCED_DCDFBA_MPCC_NLP_STRUCTURE_NEARLY_FIXED_TOL = 1.0e-10

function reduced_dcdfba_base_objective_mode_from_env()::String
    mode = lowercase(
        strip(
            get(
                ENV,
                REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_ENV,
                REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_STATE_DERIVATIVE_L2,
            ),
        ),
    )
    if mode in ("state_derivative_l2", "state-derivative-l2", "derivative_l2")
        return REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_STATE_DERIVATIVE_L2
    elseif mode in ("zero", "off", "none")
        return REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_ZERO
    end
    throw(
        ArgumentError(
            "Reduced DC-dFBA base objective mode must be state_derivative_l2 or zero, got: $(mode).",
        ),
    )
end

"""
    ReducedDCDFBADynamicControlObjectiveConfig

Normalized simultaneous-control objective configuration. The objective is
disabled by default and, when enabled, augments the collocation regularization
with terminal aroma reward, optional terminal sugar cost, nutrient-use cost,
optional integrated sugar-progress cost, nutrient-use cost, thermal energy
proxy, and temperature smoothness terms.
"""
struct ReducedDCDFBADynamicControlObjectiveConfig
    mode::String
    target_state::String
    terminal_reward_weight::Float64
    terminal_state_scale_g_L::Float64
    terminal_sugar_weight::Float64
    terminal_sugar_scale_g_L::Float64
    integrated_sugar_weight::Float64
    integrated_sugar_scale_g_L::Float64
    integrated_sugar_policy::String
    integrated_sugar_max_g_L::Float64
    aroma_reward_policy::String
    nutrient_weight::Float64
    fda_weight::Float64
    organic_weight::Float64
    nutrient_scale_g_L::Float64
    thermal_energy_weight::Float64
    ambient_temperature_C::Float64
    temperature_scale_C::Float64
    temperature_smoothness_weight::Float64
    temperature_smoothness_scale_C::Float64
    aroma_deficit_weight::Float64
    aroma_deficit_target_g_L::Float64
    aroma_deficit_scale_g_L::Float64
    terminal_sugar_excess_weight::Float64
    terminal_sugar_max_g_L::Float64
    terminal_sugar_excess_scale_g_L::Float64
    direct_temperature_reward_weight::Float64
    direct_fda_reward_weight::Float64
    direct_organic_reward_weight::Float64
    tail_residual_weight::Float64
    tail_residual_state::String
    tail_residual_elements::String
    tail_residual_scale_g_L::Float64
end

const REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_WHITE_WINE_AROMA_BLEND_COMPONENTS = (
    (state_name = "phenylethanol", weight = 1.0, scale_g_L = 0.040),
    (state_name = "isoamyl_alcohol", weight = 0.7, scale_g_L = 0.120),
    (state_name = "isobutanol", weight = 0.5, scale_g_L = 0.040),
    (state_name = "methionol", weight = 0.4, scale_g_L = 0.002),
    (state_name = "tyrosol", weight = 0.4, scale_g_L = 0.020),
    (state_name = "ethyl_acetate", weight = 0.8, scale_g_L = 0.060),
)

"""
    ReducedMPCCIpoptProfile

Named Ipopt/MUMPS option set for reduced MPCC stability diagnostics. Profiles
only configure Ipopt options; they do not change the MPCC equations, reduced
model, HSL availability, or scientific validation gates.
"""
struct ReducedMPCCIpoptProfile
    name::String
    tol::Union{Nothing, Float64}
    constr_viol_tol::Union{Nothing, Float64}
    dual_inf_tol::Union{Nothing, Float64}
    compl_inf_tol::Union{Nothing, Float64}
    acceptable_tol::Union{Nothing, Float64}
    acceptable_constr_viol_tol::Union{Nothing, Float64}
    acceptable_compl_inf_tol::Union{Nothing, Float64}
    acceptable_dual_inf_tol::Union{Nothing, Float64}
    acceptable_obj_change_tol::Union{Nothing, Float64}
    acceptable_iter::Union{Nothing, Int}
    mu_strategy::Union{Nothing, String}
    fixed_variable_treatment::Union{Nothing, String}
    bound_push::Union{Nothing, Float64}
    bound_frac::Union{Nothing, Float64}
    honor_original_bounds::Union{Nothing, String}
end

"""
    ReducedMPCCNLPStructureAudit

Non-mutating structural count of a reduced MPCC JuMP NLP. The audit is used
to explain Ipopt degree-of-freedom pressure before changing the formulation:
it counts explicit constraints, variable bounds, fixed variables, and the
approximate balance after fixed-variable elimination.
"""
struct ReducedMPCCNLPStructureAudit
    n_total_variables::Int
    n_total_constraints::Int
    n_equality_constraints::Int
    n_inequality_constraints::Int
    n_other_constraints::Int
    n_variable_bound_constraints::Int
    n_fixed_variables::Int
    n_nearly_fixed_variables::Int
    n_variables_with_only_lower_bounds::Int
    n_variables_with_only_upper_bounds::Int
    n_variables_with_lower_and_upper_bounds::Int
    n_variables_with_no_bounds::Int
    n_effective_variables::Int
    dof_balance::Int
    too_few_degrees_of_freedom_risk::Bool
    nearly_fixed_tolerance::Float64
    fixed_variable_treatment_hint::String
    metadata::Dict{String, Any}
end

"""
    reduced_mpcc_ipopt_profile_names()

Return the supported named Ipopt profiles for reduced MPCC diagnostics.
"""
reduced_mpcc_ipopt_profile_names() = collect(REDUCED_DCDFBA_MPCC_IPOPT_PROFILE_NAMES)

"""
    reduced_mpcc_ipopt_profile(name = "acceptable")

Return a named reduced MPCC Ipopt stability profile. `acceptable` matches the
current default acceptable-tolerance policy; `feasibility_first` and
`stability` intentionally relax acceptable dual/complementarity gates for
diagnosing primal-feasible but dual-unstable MPCC cases.
"""
function reduced_mpcc_ipopt_profile(
    name::AbstractString = REDUCED_DCDFBA_MPCC_DEFAULT_IPOPT_PROFILE,
)::ReducedMPCCIpoptProfile
    normalized = lowercase(strip(String(name)))
    normalized == "strict" && return ReducedMPCCIpoptProfile(
        "strict",
        1.0e-8,
        1.0e-8,
        1.0e-6,
        1.0e-8,
        nothing,
        nothing,
        nothing,
        nothing,
        nothing,
        0,
        "adaptive",
        "relax_bounds",
        nothing,
        nothing,
        "yes",
    )
    normalized == "acceptable" && return ReducedMPCCIpoptProfile(
        "acceptable",
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_TOL,
        nothing,
        nothing,
        nothing,
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_TOL,
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_CONSTR_VIOL_TOL,
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_COMPL_INF_TOL,
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_DUAL_INF_TOL,
        nothing,
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_ACCEPTABLE_ITER,
        "adaptive",
        "relax_bounds",
        nothing,
        nothing,
        "yes",
    )
    normalized == "feasibility_first" && return ReducedMPCCIpoptProfile(
        "feasibility_first",
        1.0e-6,
        1.0e-6,
        nothing,
        1.0e-4,
        1.0e-4,
        5.0e-6,
        1.0e-4,
        1.0e4,
        1.0e-8,
        10,
        "adaptive",
        "relax_bounds",
        1.0e-8,
        1.0e-8,
        "yes",
    )
    normalized == "feasibility_handoff" && return ReducedMPCCIpoptProfile(
        "feasibility_handoff",
        1.0e-6,
        1.0e-6,
        nothing,
        1.0e-4,
        2.0e3,
        1.0e-4,
        2.0e-4,
        2.0e3,
        nothing,
        3,
        "adaptive",
        "relax_bounds",
        1.0e-8,
        1.0e-8,
        "yes",
    )
    normalized == "stability" && return ReducedMPCCIpoptProfile(
        "stability",
        1.0e-6,
        1.0e-6,
        1.0e2,
        1.0e-4,
        1.0e-4,
        5.0e-6,
        1.0e-4,
        1.0e3,
        1.0e-8,
        10,
        "adaptive",
        "relax_bounds",
        1.0e-8,
        1.0e-8,
        "yes",
    )
    throw(
        ArgumentError(
            "Reduced MPCC Ipopt profile must be one of: " *
            "$(join(REDUCED_DCDFBA_MPCC_IPOPT_PROFILE_NAMES, ", ")). Got: $name",
        ),
    )
end

function reduced_mpcc_ipopt_profile_name_from_env(
    default::AbstractString = REDUCED_DCDFBA_MPCC_DEFAULT_IPOPT_PROFILE,
)::String
    raw = strip(get(ENV, REDUCED_DCDFBA_MPCC_IPOPT_PROFILE_ENV, ""))
    return reduced_mpcc_ipopt_profile(isempty(raw) ? default : raw).name
end

function reduced_mpcc_ipopt_optimizer(;
    profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    max_iter::Union{Nothing, Int} = nothing,
    print_level::Union{Nothing, Int} = nothing,
    hessian_approximation::Union{Nothing, AbstractString} = nothing,
    warm_start_init_point::Union{Nothing, Bool} = nothing,
    warm_start_bound_push::Union{Nothing, Real} = nothing,
    warm_start_bound_frac::Union{Nothing, Real} = nothing,
    warm_start_slack_bound_push::Union{Nothing, Real} = nothing,
    warm_start_slack_bound_frac::Union{Nothing, Real} = nothing,
    warm_start_mult_bound_push::Union{Nothing, Real} = nothing,
    print_frequency_iter::Union{Nothing, Int} = nothing,
    print_frequency_time::Union{Nothing, Real} = nothing,
    max_wall_time::Union{Nothing, Real} = nothing,
)
    resolved = reduced_mpcc_ipopt_profile(profile)
    return ipopt_optimizer(;
        linear_solver = linear_solver,
        max_iter = max_iter,
        tol = resolved.tol,
        constr_viol_tol = resolved.constr_viol_tol,
        dual_inf_tol = resolved.dual_inf_tol,
        compl_inf_tol = resolved.compl_inf_tol,
        acceptable_tol = resolved.acceptable_tol,
        acceptable_constr_viol_tol = resolved.acceptable_constr_viol_tol,
        acceptable_compl_inf_tol = resolved.acceptable_compl_inf_tol,
        acceptable_dual_inf_tol = resolved.acceptable_dual_inf_tol,
        acceptable_obj_change_tol = resolved.acceptable_obj_change_tol,
        acceptable_iter = resolved.acceptable_iter,
        mu_strategy = resolved.mu_strategy,
        fixed_variable_treatment = resolved.fixed_variable_treatment,
        bound_push = resolved.bound_push,
        bound_frac = resolved.bound_frac,
        honor_original_bounds = resolved.honor_original_bounds,
        print_level = print_level,
        hessian_approximation = hessian_approximation,
        warm_start_init_point = warm_start_init_point,
        warm_start_bound_push = warm_start_bound_push,
        warm_start_bound_frac = warm_start_bound_frac,
        warm_start_slack_bound_push = warm_start_slack_bound_push,
        warm_start_slack_bound_frac = warm_start_slack_bound_frac,
        warm_start_mult_bound_push = warm_start_mult_bound_push,
        print_frequency_iter = print_frequency_iter,
        print_frequency_time = print_frequency_time,
        max_wall_time = max_wall_time,
    )
end

function reduced_mpcc_complementarity_mode_from_env(
    default::Union{Symbol, AbstractString} = REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
)::Symbol
    raw = strip(get(ENV, REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_ENV, ""))
    return _reduced_dcdfba_mpcc_complementarity_mode(
        isempty(raw) ? default : raw,
    )
end

function reduced_mpcc_complementarity_tau_from_env(
    default::Real = REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU,
)::Float64
    raw = strip(get(ENV, REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_TAU_ENV, ""))
    isempty(raw) && return _reduced_dcdfba_mpcc_validate_complementarity_tau(default)
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError(
            "Reduced MPCC complementarity tau environment value must be a Float64.",
        ),
    )
    return _reduced_dcdfba_mpcc_validate_complementarity_tau(value)
end

function reduced_mpcc_complementarity_tau_gate_tol_from_env(
    default::Union{Nothing, Real} = nothing,
)::Union{Nothing, Float64}
    raw = strip(get(ENV, REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_TAU_GATE_TOL_ENV, ""))
    isempty(raw) && return _reduced_dcdfba_mpcc_validate_complementarity_tau_gate_tol(default)
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError(
            "Reduced MPCC complementarity tau-gate tolerance environment value must be a Float64.",
        ),
    )
    return _reduced_dcdfba_mpcc_validate_complementarity_tau_gate_tol(value)
end

function reduced_mpcc_tau_schedule_from_env(
    default::AbstractVector{<:Real} = REDUCED_DCDFBA_MPCC_DEFAULT_TAU_SCHEDULE,
)::Vector{Float64}
    raw = strip(get(ENV, REDUCED_DCDFBA_MPCC_TAU_SCHEDULE_ENV, ""))
    isempty(raw) && return _reduced_dcdfba_mpcc_validate_tau_schedule(default)
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && throw(
            ArgumentError("Reduced MPCC tau schedule contains a non-Float64 value: $(stripped)."),
        )
        push!(values, value)
    end
    return _reduced_dcdfba_mpcc_validate_tau_schedule(values)
end

function reduced_mpcc_tau_stage_max_iters_from_env(default = nothing)
    raw = strip(get(ENV, REDUCED_DCDFBA_MPCC_TAU_STAGE_MAX_ITERS_ENV, ""))
    isempty(raw) && return _reduced_dcdfba_mpcc_validate_tau_stage_max_iters(default)
    values = Union{Nothing, Int}[]
    for token in split(raw, [',', ';'])
        stripped = lowercase(strip(token))
        isempty(stripped) && continue
        if stripped in ("default", "nothing", "none", "missing")
            push!(values, nothing)
            continue
        end
        value = tryparse(Int, stripped)
        value === nothing && throw(
            ArgumentError(
                "Reduced MPCC tau-stage max-iter schedule contains a non-Int value: $(token).",
            ),
        )
        value >= 0 || throw(
            ArgumentError("Reduced MPCC tau-stage max-iter values must be nonnegative."),
        )
        push!(values, value)
    end
    return _reduced_dcdfba_mpcc_validate_tau_stage_max_iters(values)
end

function reduced_mpcc_tau_final_retry_max_iter_from_env(default = nothing)
    raw = strip(get(ENV, REDUCED_DCDFBA_MPCC_TAU_FINAL_RETRY_MAX_ITER_ENV, ""))
    isempty(raw) && return default
    value = tryparse(Int, raw)
    value === nothing && throw(
        ArgumentError(
            "Reduced MPCC final tau retry max-iter value must be an Int, got: $(raw).",
        ),
    )
    value >= 0 || throw(
        ArgumentError("Reduced MPCC final tau retry max-iter value must be nonnegative."),
    )
    return value
end

function reduced_mpcc_dynamic_control_reference_regularization_weight_from_env()::Float64
    raw = strip(
        get(
            ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_REFERENCE_REGULARIZATION_WEIGHT_ENV,
            "0.0",
        ),
    )
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError(
            "Dynamic-control reference regularization weight must be a Float64, got: $(raw).",
        ),
    )
    isfinite(value) && value >= 0.0 || throw(
        ArgumentError(
            "Dynamic-control reference regularization weight must be finite and nonnegative.",
        ),
    )
    return value
end

function _reduced_dcdfba_dynamic_control_objective_mode(
    mode::Union{Symbol, AbstractString},
)::String
    normalized = lowercase(strip(String(mode)))
    normalized in ("", "0", "false", "none", "off", "disabled", "reference_regularization") &&
        return REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_OFF
    normalized in (
        "aroma_nutrient_energy",
        "white_wine",
        "serious_white_wine",
        "isoamyl_acetate",
        "isoamyl_acetate_proxy",
    ) && return REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_AROMA_NUTRIENT_ENERGY
    throw(
        ArgumentError(
            "Dynamic-control objective mode must be off or aroma_nutrient_energy, got: $(mode).",
        ),
    )
end

function _reduced_dcdfba_dynamic_control_objective_aroma_reward_policy(
    policy::Union{Symbol, AbstractString},
)::String
    normalized = lowercase(strip(String(policy)))
    normalized in ("", "terminal", "terminal_state", "state_terminal") &&
        return REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_AROMA_REWARD_POLICY_TERMINAL
    normalized in (
        "terminal_plus_integrated_flux",
        "terminal+integrated_flux",
        "terminal_plus_integrated_gross_production",
        "terminal_plus_gross_production",
        "integrated_flux",
        "integrated_gross_production",
        "gross_production",
    ) && return REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_AROMA_REWARD_POLICY_TERMINAL_PLUS_INTEGRATED_FLUX
    throw(
        ArgumentError(
            "Dynamic-control aroma reward policy must be terminal or " *
            "terminal_plus_integrated_flux, got: $(policy).",
        ),
    )
end

function _reduced_dcdfba_dynamic_control_objective_integrated_sugar_policy(
    policy::Union{Symbol, AbstractString},
)::String
    normalized = lowercase(strip(String(policy)))
    normalized in (
        "",
        "squared_total",
        "total_sugar_l2",
        "squared_total_sugar",
        "legacy",
    ) && return REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_INTEGRATED_SUGAR_POLICY_SQUARED_TOTAL
    normalized in (
        "excess_slack",
        "sugar_excess_slack",
        "dryness_excess",
        "sugar_excess_auc",
        "max_excess",
        "hinge",
    ) && return REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_INTEGRATED_SUGAR_POLICY_EXCESS_SLACK
    throw(
        ArgumentError(
            "Dynamic-control integrated sugar policy must be squared_total or " *
            "excess_slack, got: $(policy).",
        ),
    )
end

function _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
    name::AbstractString,
    default::Real,
)::Float64
    raw = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError("Environment variable $(name) must parse as Float64, got: $(raw)."),
    )
    isfinite(value) && value >= 0.0 || throw(
        ArgumentError(
            "Environment variable $(name) must be finite and nonnegative, got: $(raw).",
        ),
    )
    return value
end

function _reduced_dcdfba_dynamic_control_objective_env_positive_float(
    name::AbstractString,
    default::Real,
)::Float64
    raw = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError("Environment variable $(name) must parse as Float64, got: $(raw)."),
    )
    isfinite(value) && value > 0.0 || throw(
        ArgumentError(
            "Environment variable $(name) must be finite and positive, got: $(raw).",
        ),
    )
    return value
end

function _reduced_dcdfba_dynamic_control_objective_env_finite_float(
    name::AbstractString,
    default::Real,
)::Float64
    raw = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError("Environment variable $(name) must parse as Float64, got: $(raw)."),
    )
    isfinite(value) || throw(
        ArgumentError("Environment variable $(name) must be finite, got: $(raw)."),
    )
    return value
end

function ReducedDCDFBADynamicControlObjectiveConfig(;
    mode::Union{Symbol, AbstractString} =
        REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_OFF,
    target_state::AbstractString = "isoamyl_acetate",
    terminal_reward_weight::Real = 1.0,
    terminal_state_scale_g_L::Real = 0.1,
    terminal_sugar_weight::Real = 0.0,
    terminal_sugar_scale_g_L::Real = 100.0,
    integrated_sugar_weight::Real = 0.0,
    integrated_sugar_scale_g_L::Real = 100.0,
    integrated_sugar_policy::Union{Symbol, AbstractString} =
        REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_INTEGRATED_SUGAR_POLICY_SQUARED_TOTAL,
    integrated_sugar_max_g_L::Real = 5.0,
    aroma_reward_policy::Union{Symbol, AbstractString} =
        REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_AROMA_REWARD_POLICY_TERMINAL,
    nutrient_weight::Real = 0.2,
    fda_weight::Real = 1.0,
    organic_weight::Real = 1.0,
    nutrient_scale_g_L::Real = 1.0,
    thermal_energy_weight::Real = 0.05,
    ambient_temperature_C::Real = 20.0,
    temperature_scale_C::Real = 10.0,
    temperature_smoothness_weight::Real = 0.05,
    temperature_smoothness_scale_C::Real = 5.0,
    aroma_deficit_weight::Real = 0.0,
    aroma_deficit_target_g_L::Real = 0.0,
    aroma_deficit_scale_g_L::Real = 1.0e-4,
    terminal_sugar_excess_weight::Real = 0.0,
    terminal_sugar_max_g_L::Real = 5.0,
    terminal_sugar_excess_scale_g_L::Real = 5.0,
    direct_temperature_reward_weight::Real = 0.0,
    direct_fda_reward_weight::Real = 0.0,
    direct_organic_reward_weight::Real = 0.0,
    tail_residual_weight::Real = 0.0,
    tail_residual_state::AbstractString = "protein",
    tail_residual_elements::AbstractString = "last9",
    tail_residual_scale_g_L::Real = 1.0e-6,
)::ReducedDCDFBADynamicControlObjectiveConfig
    resolved_mode = _reduced_dcdfba_dynamic_control_objective_mode(mode)
    resolved_target_state = strip(String(target_state))
    isempty(resolved_target_state) && throw(
        ArgumentError("Dynamic-control objective target_state must not be empty."),
    )
    resolved_aroma_reward_policy =
        _reduced_dcdfba_dynamic_control_objective_aroma_reward_policy(
            aroma_reward_policy,
        )
    resolved_integrated_sugar_policy =
        _reduced_dcdfba_dynamic_control_objective_integrated_sugar_policy(
            integrated_sugar_policy,
        )
    values = Dict(
        "terminal_reward_weight" => Float64(terminal_reward_weight),
        "terminal_state_scale_g_L" => Float64(terminal_state_scale_g_L),
        "terminal_sugar_weight" => Float64(terminal_sugar_weight),
        "terminal_sugar_scale_g_L" => Float64(terminal_sugar_scale_g_L),
        "integrated_sugar_weight" => Float64(integrated_sugar_weight),
        "integrated_sugar_scale_g_L" => Float64(integrated_sugar_scale_g_L),
        "integrated_sugar_max_g_L" => Float64(integrated_sugar_max_g_L),
        "nutrient_weight" => Float64(nutrient_weight),
        "fda_weight" => Float64(fda_weight),
        "organic_weight" => Float64(organic_weight),
        "nutrient_scale_g_L" => Float64(nutrient_scale_g_L),
        "thermal_energy_weight" => Float64(thermal_energy_weight),
        "ambient_temperature_C" => Float64(ambient_temperature_C),
        "temperature_scale_C" => Float64(temperature_scale_C),
        "temperature_smoothness_weight" => Float64(temperature_smoothness_weight),
        "temperature_smoothness_scale_C" => Float64(temperature_smoothness_scale_C),
        "aroma_deficit_weight" => Float64(aroma_deficit_weight),
        "aroma_deficit_target_g_L" => Float64(aroma_deficit_target_g_L),
        "aroma_deficit_scale_g_L" => Float64(aroma_deficit_scale_g_L),
        "terminal_sugar_excess_weight" => Float64(terminal_sugar_excess_weight),
        "terminal_sugar_max_g_L" => Float64(terminal_sugar_max_g_L),
        "terminal_sugar_excess_scale_g_L" => Float64(terminal_sugar_excess_scale_g_L),
        "direct_temperature_reward_weight" => Float64(direct_temperature_reward_weight),
        "direct_fda_reward_weight" => Float64(direct_fda_reward_weight),
        "direct_organic_reward_weight" => Float64(direct_organic_reward_weight),
        "tail_residual_weight" => Float64(tail_residual_weight),
        "tail_residual_scale_g_L" => Float64(tail_residual_scale_g_L),
    )
    for key in (
        "terminal_reward_weight",
        "terminal_sugar_weight",
        "integrated_sugar_weight",
        "integrated_sugar_max_g_L",
        "nutrient_weight",
        "fda_weight",
        "organic_weight",
        "thermal_energy_weight",
        "temperature_smoothness_weight",
        "aroma_deficit_weight",
        "aroma_deficit_target_g_L",
        "terminal_sugar_excess_weight",
        "terminal_sugar_max_g_L",
        "direct_temperature_reward_weight",
        "direct_fda_reward_weight",
        "direct_organic_reward_weight",
        "tail_residual_weight",
    )
        isfinite(values[key]) && values[key] >= 0.0 || throw(
            ArgumentError("Dynamic-control objective $(key) must be finite and nonnegative."),
        )
    end
    for key in (
        "terminal_state_scale_g_L",
        "terminal_sugar_scale_g_L",
        "integrated_sugar_scale_g_L",
        "nutrient_scale_g_L",
        "temperature_scale_C",
        "temperature_smoothness_scale_C",
        "aroma_deficit_scale_g_L",
        "terminal_sugar_excess_scale_g_L",
        "tail_residual_scale_g_L",
    )
        isfinite(values[key]) && values[key] > 0.0 || throw(
            ArgumentError("Dynamic-control objective $(key) must be finite and positive."),
        )
    end
    isfinite(values["ambient_temperature_C"]) || throw(
        ArgumentError("Dynamic-control objective ambient_temperature_C must be finite."),
    )
    return ReducedDCDFBADynamicControlObjectiveConfig(
        resolved_mode,
        resolved_target_state,
        values["terminal_reward_weight"],
        values["terminal_state_scale_g_L"],
        values["terminal_sugar_weight"],
        values["terminal_sugar_scale_g_L"],
        values["integrated_sugar_weight"],
        values["integrated_sugar_scale_g_L"],
        resolved_integrated_sugar_policy,
        values["integrated_sugar_max_g_L"],
        resolved_aroma_reward_policy,
        values["nutrient_weight"],
        values["fda_weight"],
        values["organic_weight"],
        values["nutrient_scale_g_L"],
        values["thermal_energy_weight"],
        values["ambient_temperature_C"],
        values["temperature_scale_C"],
        values["temperature_smoothness_weight"],
        values["temperature_smoothness_scale_C"],
        values["aroma_deficit_weight"],
        values["aroma_deficit_target_g_L"],
        values["aroma_deficit_scale_g_L"],
        values["terminal_sugar_excess_weight"],
        values["terminal_sugar_max_g_L"],
        values["terminal_sugar_excess_scale_g_L"],
        values["direct_temperature_reward_weight"],
        values["direct_fda_reward_weight"],
        values["direct_organic_reward_weight"],
        values["tail_residual_weight"],
        strip(String(tail_residual_state)),
        strip(String(tail_residual_elements)),
        values["tail_residual_scale_g_L"],
    )
end

function reduced_mpcc_dynamic_control_objective_config_from_env(
)::ReducedDCDFBADynamicControlObjectiveConfig
    return ReducedDCDFBADynamicControlObjectiveConfig(
        mode = get(
            ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_OFF,
        ),
        target_state = get(
            ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TARGET_STATE_ENV,
            "isoamyl_acetate",
        ),
        terminal_reward_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_REWARD_WEIGHT_ENV,
            1.0,
        ),
        terminal_state_scale_g_L =
            _reduced_dcdfba_dynamic_control_objective_env_positive_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_STATE_SCALE_ENV,
            0.1,
        ),
        terminal_sugar_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_WEIGHT_ENV,
            0.0,
        ),
        terminal_sugar_scale_g_L =
            _reduced_dcdfba_dynamic_control_objective_env_positive_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_SCALE_ENV,
            100.0,
        ),
        integrated_sugar_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_WEIGHT_ENV,
            0.0,
        ),
        integrated_sugar_scale_g_L =
            _reduced_dcdfba_dynamic_control_objective_env_positive_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_SCALE_ENV,
            100.0,
        ),
        integrated_sugar_policy = get(
            ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_POLICY_ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_INTEGRATED_SUGAR_POLICY_SQUARED_TOTAL,
        ),
        integrated_sugar_max_g_L =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_MAX_ENV,
            5.0,
        ),
        aroma_reward_policy = get(
            ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_REWARD_POLICY_ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_AROMA_REWARD_POLICY_TERMINAL,
        ),
        nutrient_weight = _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_WEIGHT_ENV,
            0.2,
        ),
        fda_weight = _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_FDA_WEIGHT_ENV,
            1.0,
        ),
        organic_weight = _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_ORGANIC_WEIGHT_ENV,
            1.0,
        ),
        nutrient_scale_g_L = _reduced_dcdfba_dynamic_control_objective_env_positive_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_SCALE_ENV,
            1.0,
        ),
        thermal_energy_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_THERMAL_ENERGY_WEIGHT_ENV,
            0.05,
        ),
        ambient_temperature_C =
            _reduced_dcdfba_dynamic_control_objective_env_finite_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AMBIENT_TEMPERATURE_ENV,
            20.0,
        ),
        temperature_scale_C =
            _reduced_dcdfba_dynamic_control_objective_env_positive_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SCALE_ENV,
            10.0,
        ),
        temperature_smoothness_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_WEIGHT_ENV,
            0.05,
        ),
        temperature_smoothness_scale_C =
            _reduced_dcdfba_dynamic_control_objective_env_positive_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_SCALE_ENV,
            5.0,
        ),
        aroma_deficit_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_DEFICIT_WEIGHT_ENV,
            0.0,
        ),
        aroma_deficit_target_g_L =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_DEFICIT_TARGET_ENV,
            0.0,
        ),
        aroma_deficit_scale_g_L =
            _reduced_dcdfba_dynamic_control_objective_env_positive_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_DEFICIT_SCALE_ENV,
            1.0e-4,
        ),
        terminal_sugar_excess_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_EXCESS_WEIGHT_ENV,
            0.0,
        ),
        terminal_sugar_max_g_L =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_MAX_ENV,
            5.0,
        ),
        terminal_sugar_excess_scale_g_L =
            _reduced_dcdfba_dynamic_control_objective_env_positive_float(
                REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_EXCESS_SCALE_ENV,
                5.0,
            ),
        direct_temperature_reward_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
                REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_TEMPERATURE_REWARD_WEIGHT_ENV,
                0.0,
            ),
        direct_fda_reward_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
                REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_FDA_REWARD_WEIGHT_ENV,
                0.0,
            ),
        direct_organic_reward_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
                REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_ORGANIC_REWARD_WEIGHT_ENV,
                0.0,
            ),
        tail_residual_weight =
            _reduced_dcdfba_dynamic_control_objective_env_nonnegative_float(
                REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_WEIGHT_ENV,
                0.0,
            ),
        tail_residual_state = get(
            ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_STATE_ENV,
            "protein",
        ),
        tail_residual_elements = get(
            ENV,
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_ELEMENTS_ENV,
            "last9",
        ),
        tail_residual_scale_g_L =
            _reduced_dcdfba_dynamic_control_objective_env_positive_float(
                REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_SCALE_ENV,
                1.0e-6,
            ),
    )
end

function _reduced_dcdfba_mpcc_complementarity_mode(
    mode::Union{Symbol, AbstractString},
)::Symbol
    normalized = lowercase(strip(String(mode)))
    normalized in REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODES || throw(
        ArgumentError(
            "Reduced MPCC complementarity mode must be one of: " *
            "$(join(REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODES, ", ")). Got: $(mode)",
        ),
    )
    return Symbol(normalized)
end

function _reduced_dcdfba_mpcc_validate_complementarity_tau(tau::Real)::Float64
    value = Float64(tau)
    isfinite(value) && value >= 0.0 || throw(
        ArgumentError("Reduced MPCC complementarity tau must be finite and nonnegative."),
    )
    return value
end

function _reduced_dcdfba_mpcc_validate_complementarity_tau_gate_tol(
    tolerance::Union{Nothing, Real},
)::Union{Nothing, Float64}
    tolerance === nothing && return nothing
    value = Float64(tolerance)
    isfinite(value) && value >= 0.0 || throw(
        ArgumentError(
            "Reduced MPCC complementarity tau-gate tolerance must be finite and nonnegative.",
        ),
    )
    return value
end

function _reduced_dcdfba_mpcc_validate_tau_schedule(
    schedule::AbstractVector{<:Real},
)::Vector{Float64}
    values = Float64.(collect(schedule))
    isempty(values) && throw(
        ArgumentError("Reduced MPCC tau schedule must contain at least one value."),
    )
    all(value -> isfinite(value) && value >= 0.0, values) || throw(
        ArgumentError("Reduced MPCC tau schedule values must be finite and nonnegative."),
    )
    return values
end

function _reduced_dcdfba_mpcc_validate_tau_stage_max_iters(values)
    (values === nothing || values === missing) && return nothing
    parsed = Union{Nothing, Int}[]
    for value in values
        if value === nothing || value === missing
            push!(parsed, nothing)
            continue
        end
        int_value = try
            Int(value)
        catch
            throw(
                ArgumentError(
                    "Reduced MPCC tau-stage max-iter values must be Int-compatible.",
                ),
            )
        end
        int_value == value || throw(
            ArgumentError("Reduced MPCC tau-stage max-iter values must be Int-compatible."),
        )
        int_value >= 0 || throw(
            ArgumentError("Reduced MPCC tau-stage max-iter values must be nonnegative."),
        )
        push!(parsed, int_value)
    end
    isempty(parsed) && throw(
        ArgumentError("Reduced MPCC tau-stage max-iter schedule must not be empty when provided."),
    )
    return parsed
end

function _reduced_dcdfba_mpcc_resolve_tau_stage_max_iters(
    tau_stage_max_iters,
    stage_count::Int,
    fallback::Union{Nothing, Int},
)::Vector{Union{Nothing, Int}}
    stage_count > 0 || throw(
        ArgumentError("Reduced MPCC tau-stage max-iter resolution requires at least one stage."),
    )
    values = _reduced_dcdfba_mpcc_validate_tau_stage_max_iters(tau_stage_max_iters)
    values === nothing && return Union{Nothing, Int}[fallback for _ in 1:stage_count]
    if length(values) == 1
        return Union{Nothing, Int}[only(values) === nothing ? fallback : only(values) for _ in 1:stage_count]
    end
    length(values) == stage_count || throw(
        ArgumentError(
            "Reduced MPCC tau-stage max-iter schedule must have length 1 or match tau schedule length.",
        ),
    )
    return Union{Nothing, Int}[value === nothing ? fallback : value for value in values]
end

function _reduced_dcdfba_mpcc_tau_stage_max_iters_label(values)::String
    (values === nothing || values === missing) && return "default"
    parsed = _reduced_dcdfba_mpcc_validate_tau_stage_max_iters(values)
    return join((value === nothing ? "default" : string(value) for value in parsed), ",")
end

"""
    audit_reduced_mpcc_nlp_structure(model; nearly_fixed_tol=1e-10)

Count variables, explicit constraints, variable bounds, fixed variables, and
the approximate Ipopt degree-of-freedom balance for a reduced MPCC JuMP model.
This function does not modify the model and does not call the solver.
"""
function audit_reduced_mpcc_nlp_structure(
    model::JuMP.Model;
    nearly_fixed_tol::Real = REDUCED_DCDFBA_MPCC_NLP_STRUCTURE_NEARLY_FIXED_TOL,
)::ReducedMPCCNLPStructureAudit
    tolerance = Float64(nearly_fixed_tol)
    isfinite(tolerance) && tolerance >= 0.0 || throw(
        ArgumentError("Reduced MPCC NLP structure nearly_fixed_tol must be finite and nonnegative."),
    )

    variable_stats = _reduced_mpcc_nlp_variable_bound_counts(model, tolerance)
    constraint_stats = _reduced_mpcc_nlp_constraint_counts(model)

    n_total_variables = JuMP.num_variables(model)
    n_effective_variables = n_total_variables - variable_stats.fixed_variables
    dof_balance = n_effective_variables - constraint_stats.equality_constraints
    too_few_degrees_of_freedom_risk = dof_balance < 0
    hint = _reduced_mpcc_nlp_fixed_variable_treatment_hint(
        variable_stats.fixed_variables,
        constraint_stats.equality_constraints,
        n_effective_variables,
        dof_balance,
    )

    metadata = Dict{String, Any}(
        "nlp_structure_audit_built" => true,
        "nlp_structure_audit_scope" => "reduced_mpcc_jump_model",
        "nlp_structure_nearly_fixed_tolerance" => tolerance,
        "nlp_structure_total_variables" => n_total_variables,
        "nlp_structure_total_constraints" => constraint_stats.total_constraints,
        "nlp_structure_equality_constraints" => constraint_stats.equality_constraints,
        "nlp_structure_inequality_constraints" => constraint_stats.inequality_constraints,
        "nlp_structure_other_constraints" => constraint_stats.other_constraints,
        "nlp_structure_variable_bound_constraints" =>
            constraint_stats.variable_bound_constraints,
        "nlp_structure_fixed_variable_count" => variable_stats.fixed_variables,
        "nlp_structure_nearly_fixed_variable_count" =>
            variable_stats.nearly_fixed_variables,
        "nlp_structure_variables_with_only_lower_bounds" =>
            variable_stats.only_lower_bounds,
        "nlp_structure_variables_with_only_upper_bounds" =>
            variable_stats.only_upper_bounds,
        "nlp_structure_variables_with_lower_and_upper_bounds" =>
            variable_stats.lower_and_upper_bounds,
        "nlp_structure_variables_with_no_bounds" => variable_stats.no_bounds,
        "nlp_structure_effective_variable_count" => n_effective_variables,
        "nlp_structure_dof_balance" => dof_balance,
        "nlp_structure_too_few_degrees_of_freedom_risk" =>
            too_few_degrees_of_freedom_risk,
        "nlp_structure_fixed_variable_treatment_hint" => hint,
        "nlp_structure_ipopt_dof_warning_likely" => too_few_degrees_of_freedom_risk,
        "nlp_structure_mutates_model" => false,
        "nlp_structure_solver_call_performed" => false,
    )

    return ReducedMPCCNLPStructureAudit(
        n_total_variables,
        constraint_stats.total_constraints,
        constraint_stats.equality_constraints,
        constraint_stats.inequality_constraints,
        constraint_stats.other_constraints,
        constraint_stats.variable_bound_constraints,
        variable_stats.fixed_variables,
        variable_stats.nearly_fixed_variables,
        variable_stats.only_lower_bounds,
        variable_stats.only_upper_bounds,
        variable_stats.lower_and_upper_bounds,
        variable_stats.no_bounds,
        n_effective_variables,
        dof_balance,
        too_few_degrees_of_freedom_risk,
        tolerance,
        hint,
        metadata,
    )
end

function _reduced_mpcc_nlp_variable_bound_counts(
    model::JuMP.Model,
    nearly_fixed_tol::Float64,
)
    fixed_variables = 0
    nearly_fixed_variables = 0
    only_lower_bounds = 0
    only_upper_bounds = 0
    lower_and_upper_bounds = 0
    no_bounds = 0

    for variable in JuMP.all_variables(model)
        has_lower = JuMP.has_lower_bound(variable)
        has_upper = JuMP.has_upper_bound(variable)
        fixed = JuMP.is_fixed(variable)
        if has_lower && has_upper
            lower_and_upper_bounds += 1
        elseif has_lower
            only_lower_bounds += 1
        elseif has_upper
            only_upper_bounds += 1
        else
            no_bounds += 1
        end

        if fixed
            fixed_variables += 1
            continue
        end
        if has_lower && has_upper
            lower = JuMP.lower_bound(variable)
            upper = JuMP.upper_bound(variable)
            width = upper - lower
            if width == 0.0
                fixed_variables += 1
            elseif isfinite(width) && 0.0 < abs(width) <= nearly_fixed_tol
                nearly_fixed_variables += 1
            end
        end
    end

    return (
        fixed_variables = fixed_variables,
        nearly_fixed_variables = nearly_fixed_variables,
        only_lower_bounds = only_lower_bounds,
        only_upper_bounds = only_upper_bounds,
        lower_and_upper_bounds = lower_and_upper_bounds,
        no_bounds = no_bounds,
    )
end

function _reduced_mpcc_nlp_constraint_counts(model::JuMP.Model)
    total_constraints = 0
    equality_constraints = 0
    inequality_constraints = 0
    other_constraints = 0
    variable_bound_constraints = 0

    for (function_type, set_type) in JuMP.list_of_constraint_types(model)
        count = JuMP.num_constraints(model, function_type, set_type)
        if function_type == JuMP.VariableRef
            variable_bound_constraints += count
            continue
        end
        total_constraints += count
        if _reduced_mpcc_nlp_constraint_set_is_equality(set_type)
            equality_constraints += count
        elseif _reduced_mpcc_nlp_constraint_set_is_inequality(set_type)
            inequality_constraints += count
        else
            other_constraints += count
        end
    end

    return (
        total_constraints = total_constraints,
        equality_constraints = equality_constraints,
        inequality_constraints = inequality_constraints,
        other_constraints = other_constraints,
        variable_bound_constraints = variable_bound_constraints,
    )
end

function _reduced_mpcc_nlp_constraint_set_is_equality(::Type{S}) where {S}
    return S <: MOI.EqualTo || S <: MOI.Zeros
end

function _reduced_mpcc_nlp_constraint_set_is_inequality(::Type{S}) where {S}
    return S <: MOI.LessThan ||
           S <: MOI.GreaterThan ||
           S <: MOI.Interval ||
           S <: MOI.Nonnegatives ||
           S <: MOI.Nonpositives
end

function _reduced_mpcc_nlp_fixed_variable_treatment_hint(
    n_fixed_variables::Int,
    n_equality_constraints::Int,
    n_effective_variables::Int,
    dof_balance::Int,
)::String
    dof_balance < 0 && n_fixed_variables > 0 &&
        return "effective_variables_below_equalities_after_fixed_variable_elimination"
    dof_balance < 0 &&
        return "effective_variables_below_equalities_without_fixed_variable_pressure"
    dof_balance == 0 && return "square_nlp_after_fixed_variable_elimination"
    n_equality_constraints > n_effective_variables - n_fixed_variables &&
        return "low_positive_dof_margin"
    return "positive_dof_margin"
end

function _merge_reduced_dcdfba_metadata_prefix!(
    target::Dict{String, Any},
    source::Dict{String, Any},
    prefix::AbstractString,
)::Dict{String, Any}
    for (key, value) in source
        startswith(key, prefix) && (target[key] = value)
    end
    return target
end

"""
    ReducedDCDFBACollocationNLPDimensions

Concrete JuMP variable and constraint counts for the reduced DC-dFBA
collocation NLP scaffold. This is a primal collocation scaffold only; it does
not include FBA KKT dual variables or complementarity pairs.
"""
struct ReducedDCDFBACollocationNLPDimensions
    n_states::Int
    n_reactions::Int
    nfe::Int
    collocation_degree::Int
    n_collocation_points::Int
    n_state_boundary_variables::Int
    n_state_collocation_variables::Int
    n_state_derivative_variables::Int
    n_flux_variables::Int
    n_total_variables::Int
    n_collocation_integration_constraints::Int
    n_continuity_constraints::Int
    n_initial_condition_constraints::Int
    n_total_constraints::Int
end

"""
    ReducedDCDFBACollocationNLP

JuMP NLP scaffold for the first reduced direct-collocation DFBA path. The
model contains collocation state variables, state-derivative variables, and
reduced flux variables over a finite-element grid. It intentionally stops
before DFBA RHS residuals, `S*v = 0`, KKT stationarity, or MPCC
complementarity.
"""
struct ReducedDCDFBACollocationNLP
    kkt_problem::KKTDFBAProblem
    jump_model::JuMP.Model
    state_boundary::Matrix{JuMP.VariableRef}
    state_collocation::Array{JuMP.VariableRef, 3}
    state_derivative::Array{JuMP.VariableRef, 3}
    flux::Array{JuMP.VariableRef, 3}
    collocation_integration_constraints::Array{JuMP.ConstraintRef, 3}
    continuity_constraints::Matrix{JuMP.ConstraintRef}
    initial_condition_constraints::Vector{JuMP.ConstraintRef}
    dimensions::ReducedDCDFBACollocationNLPDimensions
    initial_state::Vector{Float64}
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBARHSReactionIndices

Reaction indices used by the reduced collocation RHS residual scaffold.
Indices are resolved from reaction IDs, never from `Indices_reacciones.csv`.
"""
struct ReducedDCDFBARHSReactionIndices
    biomass_growth::Int
    glucose_exchange::Int
    fructose_exchange::Int
    ethanol_exchange::Int
    atp_maintenance::Int
    protein_exchange::Int
    carbohydrate_exchange::Int
    nitrogen_sources::Vector{Int}
    amino_acids::Vector{Int}
    aromas::Vector{Int}
end

"""
    ReducedDCDFBARHSResidualLayout

State-wise residual counts for the reduced collocation RHS scaffold.
"""
struct ReducedDCDFBARHSResidualLayout
    biomass_growth::Int
    nitrogen::Int
    glucose::Int
    fructose::Int
    ethanol::Int
    oxygen::Int
    protein::Int
    carbohydrate::Int
    amino_acids::Int
    aromas::Int
    total_rhs_residual_constraints::Int
end

"""
    ReducedDCDFBARHSResidualScaffold

Constraints that link collocation state-derivative variables to a smooth,
growth-mode reduced DFBA RHS algebraic scaffold. This does not include LP
primal feasibility, stationarity, dual variables, or complementarity.
"""
struct ReducedDCDFBARHSResidualScaffold
    nlp::ReducedDCDFBACollocationNLP
    constraints::Array{JuMP.ConstraintRef, 3}
    layout::ReducedDCDFBARHSResidualLayout
    reaction_indices::ReducedDCDFBARHSReactionIndices
    mode::Symbol
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAPrimalFeasibilityLayout

Constraint counts for reduced FBA primal feasibility rows over the
collocation grid.
"""
struct ReducedDCDFBAPrimalFeasibilityLayout
    n_metabolites::Int
    n_reactions::Int
    nfe::Int
    collocation_degree::Int
    n_collocation_points::Int
    n_mass_balance_constraints::Int
    total_primal_feasibility_constraints::Int
end

"""
    ReducedDCDFBAPrimalFeasibilityScaffold

Mass-balance constraints `S*v = 0` at each collocation point for the reduced
FBA primal feasibility scaffold. This does not include bound feasibility
rows, stationarity, dual variables, or complementarity.
"""
struct ReducedDCDFBAPrimalFeasibilityScaffold
    nlp::ReducedDCDFBACollocationNLP
    mass_balance_constraints::Array{JuMP.ConstraintRef, 3}
    layout::ReducedDCDFBAPrimalFeasibilityLayout
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBABoundFeasibilityLayout

Constraint and dual-variable counts for reduced FBA bound feasibility rows
over the collocation grid.
"""
struct ReducedDCDFBABoundFeasibilityLayout
    n_reactions::Int
    nfe::Int
    collocation_degree::Int
    n_collocation_points::Int
    n_lower_bound_constraints::Int
    n_upper_bound_constraints::Int
    n_lower_bound_dual_variables::Int
    n_upper_bound_dual_variables::Int
    n_total_bound_feasibility_constraints::Int
    n_total_bound_dual_variables::Int
end

"""
    ReducedDCDFBADynamicBoundsLayout

Counts for smooth dynamic bound expressions and objective
coefficients over the reduced collocation grid.
"""
struct ReducedDCDFBADynamicBoundsLayout
    n_reactions::Int
    nfe::Int
    collocation_degree::Int
    n_collocation_points::Int
    n_lower_bound_reactions::Int
    n_upper_bound_reactions::Int
    n_objective_reactions::Int
    n_lower_bound_expressions::Int
    n_upper_bound_expressions::Int
    n_objective_coefficients::Int
end

"""
    ReducedDCDFBADynamicBoundsScaffold

State-dependent, smooth dynamic lower/upper bound expressions for
the reduced DC-dFBA KKT scaffold. The expressions are not standalone
constraints; they are consumed by `add_reduced_dcdfba_bound_feasibility!` and
`add_reduced_dcdfba_complementarity!` so the bound-dual variables remain
associated with the active bound rows.
"""
struct ReducedDCDFBADynamicBoundsScaffold
    nlp::ReducedDCDFBACollocationNLP
    lower_bound_expressions::Dict{Tuple{Int, Int, Int}, Any}
    upper_bound_expressions::Dict{Tuple{Int, Int, Int}, Any}
    objective_coefficients::Vector{Float64}
    objective_coefficient_expressions::Dict{Tuple{Int, Int, Int}, Any}
    lower_bound_reaction_indices::Vector{Int}
    upper_bound_reaction_indices::Vector{Int}
    objective_reaction_indices::Vector{Int}
    layout::ReducedDCDFBADynamicBoundsLayout
    mode::Symbol
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBABoundFeasibilityScaffold

Explicit bound feasibility rows and future KKT dual variables for reduced FBA
flux bounds. Lower-bound rows follow the De Oliveira-style convention
`lb - v <= 0` with nonpositive lower-bound dual variables. Upper-bound rows
use `v - ub <= 0` with nonnegative upper-bound dual variables. No
stationarity rows or complementarity products are created here.
"""
struct ReducedDCDFBABoundFeasibilityScaffold
    nlp::ReducedDCDFBACollocationNLP
    lower_bound_duals::Array{JuMP.VariableRef, 3}
    upper_bound_duals::Array{JuMP.VariableRef, 3}
    lower_bound_constraints::Array{JuMP.ConstraintRef, 3}
    upper_bound_constraints::Array{JuMP.ConstraintRef, 3}
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold}
    layout::ReducedDCDFBABoundFeasibilityLayout
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAStationarityLayout

Constraint and dual-variable counts for reduced FBA KKT stationarity rows over
the collocation grid.
"""
struct ReducedDCDFBAStationarityLayout
    n_metabolites::Int
    n_reactions::Int
    nfe::Int
    collocation_degree::Int
    n_collocation_points::Int
    n_mass_balance_dual_variables::Int
    n_stationarity_constraints::Int
    n_objective_coefficients::Int
end

"""
    ReducedDCDFBAStationarityScaffold

Reduced FBA KKT stationarity rows
`c + S'lambda + alpha_L + alpha_U = 0` at each collocation point. The
coefficient vector `c` and optional collocation-point expressions follow a
minimization convention; dynamic maximization objectives should pass negated
weights.
No complementarity products or solver calls are created here.
"""
struct ReducedDCDFBAStationarityScaffold
    nlp::ReducedDCDFBACollocationNLP
    bound_feasibility::ReducedDCDFBABoundFeasibilityScaffold
    mass_balance_duals::Array{JuMP.VariableRef, 3}
    stationarity_constraints::Array{JuMP.ConstraintRef, 3}
    layout::ReducedDCDFBAStationarityLayout
    objective_coefficients::Vector{Float64}
    objective_coefficient_expressions::Dict{Tuple{Int, Int, Int}, Any}
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAComplementarityLayout

Constraint counts for reduced FBA MPCC complementarity pairs over the
collocation grid.
"""
struct ReducedDCDFBAComplementarityLayout
    n_reactions::Int
    nfe::Int
    collocation_degree::Int
    n_collocation_points::Int
    n_lower_bound_complementarity_constraints::Int
    n_upper_bound_complementarity_constraints::Int
    n_total_complementarity_constraints::Int
end

"""
    ReducedDCDFBAComplementarityScaffold

Quadratic MPCC complementarity products for the reduced FBA bound pairs:
`(v - lb) * alpha_L = 0` and `(v - ub) * alpha_U = 0` at each collocation
point. This completes the fixed-bound reduced FBA KKT algebraic scaffold but
does not call Ipopt or claim a solved simultaneous DFBA trajectory.
"""
struct ReducedDCDFBAComplementarityScaffold
    nlp::ReducedDCDFBACollocationNLP
    stationarity::ReducedDCDFBAStationarityScaffold
    lower_bound_complementarity_constraints::Array{JuMP.ConstraintRef, 3}
    upper_bound_complementarity_constraints::Array{JuMP.ConstraintRef, 3}
    layout::ReducedDCDFBAComplementarityLayout
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBASequentialInitialization

Start values interpolated from a sequential reduced DFBA `SimulationResult`
onto the direct-collocation grid. The initializer stores the values applied to
state-boundary, state-collocation, state-derivative, and flux variables, but it
does not add constraints or call a solver.
"""
struct ReducedDCDFBASequentialInitialization
    nlp::ReducedDCDFBACollocationNLP
    state_boundary_starts::Matrix{Float64}
    state_collocation_starts::Array{Float64, 3}
    state_derivative_starts::Array{Float64, 3}
    flux_starts::Array{Float64, 3}
    flux_reaction_ids::Vector{String}
    initialized_flux_indices::Vector{Int}
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBADynamicControlDecisionScaffold

Auditable JuMP variables for liberated dynamic-control slots. These variables
carry starts and trust-region bounds from a `DynamicControlDecisionSpec`; the
MPCC builder can embed them into RHS equations and dynamic FBA bounds while
preserving fixed-schedule starts for equivalence checks.
"""
struct ReducedDCDFBADynamicControlDecisionScaffold
    spec::DynamicControlDecisionSpec
    temperature_variables::Vector{JuMP.VariableRef}
    fda_variables::Vector{JuMP.VariableRef}
    organic_variables::Vector{JuMP.VariableRef}
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAMPCCSmokeProblem

Guarded reduced MPCC smoke problem assembled from the reduced collocation NLP,
fixed-bound FBA KKT rows, and complementarity products. The builder does not
call Ipopt.
"""
struct ReducedDCDFBAMPCCSmokeProblem
    nlp::ReducedDCDFBACollocationNLP
    rhs_residuals::Union{Nothing, ReducedDCDFBARHSResidualScaffold}
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold}
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule}
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold}
    sequential_initialization::Union{Nothing, ReducedDCDFBASequentialInitialization}
    primal_feasibility::ReducedDCDFBAPrimalFeasibilityScaffold
    bound_feasibility::ReducedDCDFBABoundFeasibilityScaffold
    stationarity::ReducedDCDFBAStationarityScaffold
    complementarity::ReducedDCDFBAComplementarityScaffold
    flux_start::Vector{Float64}
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAMPCCSmokeResult

Compact diagnostics from a guarded reduced MPCC smoke solve. This result is
for solver integration only; it is not a validated simultaneous DFBA
simulation.
"""
struct ReducedDCDFBAMPCCSmokeResult
    status::MOI.TerminationStatusCode
    primal_status::MOI.ResultStatusCode
    objective_value::Float64
    max_mass_balance_residual::Float64
    max_lower_bound_violation::Float64
    max_upper_bound_violation::Float64
    max_stationarity_residual::Float64
    max_lower_complementarity_residual::Float64
    max_upper_complementarity_residual::Float64
    solver_name::String
    solve_elapsed_seconds::Float64
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAMPCCResidualThresholds

Residual thresholds used to classify the first guarded reduced MPCC solve
attempts. These thresholds are diagnostic gates only; satisfying them would
not by itself validate the trajectory scientifically.
"""
struct ReducedDCDFBAMPCCResidualThresholds
    max_rhs_residual::Float64
    max_mass_balance_residual::Float64
    max_lower_bound_violation::Float64
    max_upper_bound_violation::Float64
    max_stationarity_residual::Float64
    max_lower_complementarity_residual::Float64
    max_upper_complementarity_residual::Float64
end

"""
    ReducedDCDFBAMPCCSolveAttemptProblem

Guarded reduced MPCC solve-attempt problem. It wraps the existing reduced MPCC
smoke problem but requires the numerically relevant pieces for the first
dynamic attempt: RHS residuals, smooth growth-mode dynamic bounds, and
sequential initialization starts.
"""
struct ReducedDCDFBAMPCCSolveAttemptProblem
    smoke_problem::ReducedDCDFBAMPCCSmokeProblem
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds
    metadata::Dict{String, Any}
end

audit_reduced_mpcc_nlp_structure(
    nlp::ReducedDCDFBACollocationNLP;
    kwargs...,
) = audit_reduced_mpcc_nlp_structure(nlp.jump_model; kwargs...)

audit_reduced_mpcc_nlp_structure(
    problem::ReducedDCDFBAMPCCSmokeProblem;
    kwargs...,
) = audit_reduced_mpcc_nlp_structure(problem.nlp; kwargs...)

audit_reduced_mpcc_nlp_structure(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem;
    kwargs...,
) = audit_reduced_mpcc_nlp_structure(problem.smoke_problem; kwargs...)

"""
    ReducedDCDFBAMPCCCandidateDiagnostics

Post-solve value extraction for a guarded reduced MPCC solve attempt. It stores
candidate variable values and numerical diagnostics only; it is not a validated
simultaneous DFBA trajectory and it does not imply scientific acceptance.
"""
struct ReducedDCDFBAMPCCCandidateDiagnostics
    state_boundary::Matrix{Float64}
    state_collocation::Array{Float64, 3}
    state_derivative::Array{Float64, 3}
    flux::Array{Float64, 3}
    lower_bound_duals::Array{Float64, 3}
    upper_bound_duals::Array{Float64, 3}
    mass_balance_duals::Array{Float64, 3}
    residual_values::Dict{String, Float64}
    residual_thresholds::Dict{String, Float64}
    residual_ratios::Dict{String, Float64}
    ranked_residuals::Vector{String}
    warnings::Vector{String}
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAMPCCTrajectoryCandidate

Guarded trajectory-shaped view of a reduced MPCC candidate. It provides
boundary and collocation `SimulationResult` objects for state diagnostics while
keeping full flux values in `candidate_diagnostics.flux`. This is not a
validated scientific simulation.
"""
struct ReducedDCDFBAMPCCTrajectoryCandidate
    boundary_result::SimulationResult
    collocation_result::SimulationResult
    candidate_diagnostics::ReducedDCDFBAMPCCCandidateDiagnostics
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAMPCCSolveAttemptResult

Guarded first-solve diagnostics for the reduced MPCC path. This result wraps
the lower-level smoke solve result and records whether finite residuals satisfy
the configured diagnostic thresholds. It is not a validated simultaneous DFBA
simulation.
"""
struct ReducedDCDFBAMPCCSolveAttemptResult
    smoke_result::ReducedDCDFBAMPCCSmokeResult
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds
    residuals_available::Bool
    residual_thresholds_satisfied::Bool
    residual_report::Dict{String, Any}
    metadata::Dict{String, Any}
    candidate_diagnostics::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics}
end

"""
    ReducedDCDFBAMPCCTauContinuationResult

Sequential Scholtes-relaxation diagnostics for a reduced MPCC solve. Each stage
solves the same window with a smaller complementarity `tau`, warm-started from
the previous stage when a finite candidate is available.
"""
struct ReducedDCDFBAMPCCTauContinuationResult
    stage_table::DataFrame
    stage_results::Vector{ReducedDCDFBAMPCCSolveAttemptResult}
    final_result::Union{Nothing, ReducedDCDFBAMPCCSolveAttemptResult}
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAMPCCDiagnosticReport

Diagnostic report for reduced MPCC solve attempts. It ranks residuals against
configured thresholds and records simple start-value scaling signals. This is
an infeasibility/scaling aid only; it is not a solved simultaneous DFBA
trajectory and it does not add or modify MPCC equations.
"""
struct ReducedDCDFBAMPCCDiagnosticReport
    residual_values::Dict{String, Float64}
    residual_thresholds::Dict{String, Float64}
    residual_ratios::Dict{String, Float64}
    ranked_residuals::Vector{String}
    dominant_residual::String
    residuals_available::Bool
    residual_thresholds_satisfied::Bool
    scaling_summary::Dict{String, Float64}
    warnings::Vector{String}
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAMPCCScaleBlock

Magnitude summary and recommended scalar factor for one reduced MPCC variable
or constraint block. The factor is diagnostic only; it is not applied to the
JuMP model by this scaffold.
"""
struct ReducedDCDFBAMPCCScaleBlock
    name::String
    abs_max::Float64
    positive_abs_min::Float64
    positive_abs_max::Float64
    positive_scale_spread::Float64
    recommended_scale::Float64
    scaled_abs_max::Float64
    total_count::Int
    nonzero_count::Int
end

"""
    ReducedDCDFBAMPCCScalingPlan

Pre-solve scaling plan for the reduced MPCC scaffold. It records recommended
block-level scale factors for starts and constraint residual families, plus
warnings that should be reviewed before a guarded solve. It does not mutate
the model and does not call Ipopt.
"""
struct ReducedDCDFBAMPCCScalingPlan
    variable_blocks::Dict{String, ReducedDCDFBAMPCCScaleBlock}
    constraint_blocks::Dict{String, ReducedDCDFBAMPCCScaleBlock}
    variable_scale_factors::Dict{String, Float64}
    constraint_scale_factors::Dict{String, Float64}
    warnings::Vector{String}
    metadata::Dict{String, Any}
end

"""
    build_reduced_dcdfba_collocation_nlp(kkt_problem; initial_state=..., optimizer=ipopt_mumps_optimizer(), silent=true)

Build a reduced DC-dFBA collocation NLP scaffold from an existing
`KKTDFBAProblem`. The JuMP model includes collocation consistency,
finite-element continuity, and initial-condition constraints. It does not call
the solver and does not build DFBA KKT/MPCC constraints.
"""
function build_reduced_dcdfba_collocation_nlp(
    kkt_problem::KKTDFBAProblem;
    initial_state::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    optimizer = ipopt_mumps_optimizer(),
    silent::Bool = true,
    defer_fixed_flux_variable_bounds::Bool = false,
    state_nonnegative_bounds::Bool = false,
)::ReducedDCDFBACollocationNLP
    _validate_reduced_dcdfba_initial_state(initial_state)

    model = kkt_problem.model
    grid = kkt_problem.grid
    dimensions = _reduced_dcdfba_collocation_nlp_dimensions(kkt_problem)
    jump_model = JuMP.Model(optimizer)
    silent && !_ipopt_env_print_requested() && JuMP.set_silent(jump_model)

    n_states = dimensions.n_states
    n_reactions = dimensions.n_reactions
    nfe = dimensions.nfe
    degree = dimensions.collocation_degree

    JuMP.@variable(jump_model, state_boundary[1:n_states, 1:(nfe + 1)])
    JuMP.@variable(jump_model, state_collocation[1:n_states, 1:nfe, 1:degree])
    JuMP.@variable(jump_model, state_derivative[1:n_states, 1:nfe, 1:degree])
    JuMP.@variable(jump_model, flux[1:n_reactions, 1:nfe, 1:degree])
    state_bound_metadata = _set_reduced_dcdfba_state_nonnegative_bounds!(
        state_boundary,
        state_collocation;
        enabled = state_nonnegative_bounds,
    )

    _set_reduced_dcdfba_variable_starts!(
        state_boundary,
        state_collocation,
        state_derivative,
        flux,
        initial_state,
        model,
    )
    flux_bound_metadata = _set_reduced_dcdfba_flux_bounds!(
        flux,
        model;
        defer_fixed_bounds = defer_fixed_flux_variable_bounds,
    )

    collocation_integration_constraints = Array{JuMP.ConstraintRef, 3}(undef, n_states, nfe, degree)
    continuity_constraints = Matrix{JuMP.ConstraintRef}(undef, n_states, nfe)
    initial_condition_constraints = Vector{JuMP.ConstraintRef}(undef, n_states)
    _add_reduced_dcdfba_collocation_constraints!(
        collocation_integration_constraints,
        continuity_constraints,
        initial_condition_constraints,
        jump_model,
        grid,
        state_boundary,
        state_collocation,
        state_derivative,
        initial_state,
    )

    base_objective_mode = reduced_dcdfba_base_objective_mode_from_env()
    if base_objective_mode == REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_ZERO
        JuMP.@objective(jump_model, Min, 0.0)
    else
        JuMP.@objective(
            jump_model,
            Min,
            sum(
                state_derivative[i, e, j]^2 for
                i in 1:n_states, e in 1:nfe, j in 1:degree
            ),
        )
    end

    metadata = _reduced_dcdfba_collocation_nlp_metadata(kkt_problem, dimensions)
    metadata["base_objective_mode"] = base_objective_mode
    metadata["base_objective_mode_env"] = REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_ENV
    metadata["base_objective_description"] =
        base_objective_mode == REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_ZERO ?
        "zero objective before MPCC/dynamic-control terms" :
        "sum of squared state derivatives over collocation points"
    merge!(metadata, state_bound_metadata)
    merge!(metadata, flux_bound_metadata)

    return ReducedDCDFBACollocationNLP(
        kkt_problem,
        jump_model,
        state_boundary,
        state_collocation,
        state_derivative,
        flux,
        collocation_integration_constraints,
        continuity_constraints,
        initial_condition_constraints,
        dimensions,
        Float64.(initial_state),
        metadata,
    )
end

"""
    build_reduced_dcdfba_collocation_nlp(model, reaction_map; tspan, nfe, degree=3, kwargs...)

Build the reduced KKT-DFBA structural scaffold and then the collocation NLP
scaffold in one call.
"""
function build_reduced_dcdfba_collocation_nlp(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    tspan::Tuple{<:Real, <:Real},
    nfe::Int,
    degree::Int = 3,
    element_bounds::Union{Nothing, AbstractVector{<:Tuple{<:Real, <:Real}}} = nothing,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    model_scope::AbstractString = "reduced",
    initial_state::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    optimizer = ipopt_mumps_optimizer(),
    silent::Bool = true,
    defer_fixed_flux_variable_bounds::Bool = false,
    state_nonnegative_bounds::Bool = false,
)::ReducedDCDFBACollocationNLP
    kkt_problem = build_kkt_dfba_problem(
        model,
        reaction_map;
        tspan = tspan,
        nfe = nfe,
        degree = degree,
        element_bounds = element_bounds,
        params = params,
        model_scope = model_scope,
    )
    return build_reduced_dcdfba_collocation_nlp(
        kkt_problem;
        initial_state = initial_state,
        optimizer = optimizer,
        silent = silent,
        defer_fixed_flux_variable_bounds = defer_fixed_flux_variable_bounds,
        state_nonnegative_bounds = state_nonnegative_bounds,
    )
end

"""
    build_reduced_dcdfba_dynamic_bounds(nlp; mode=:growth)

Build smooth dynamic bound expressions and minimization-form
objective coefficients for the reduced DC-dFBA collocation scaffold. The
result is a structural input for bound feasibility, stationarity, and
complementarity rows; it does not call a solver and does not add constraints by
itself.
"""
function reduced_dcdfba_dynamic_bounds_mode_from_env()::Symbol
    raw = lowercase(strip(get(ENV, "MPCC_REDUCED_DCDFBA_DYNAMIC_BOUNDS_MODE", "growth")))
    raw in ("growth", "smooth_phase", "phase_smooth", "smooth-phase") || throw(
        ArgumentError(
            "MPCC_REDUCED_DCDFBA_DYNAMIC_BOUNDS_MODE must be growth or smooth_phase; got '$raw'.",
        ),
    )
    return raw == "growth" ? :growth : :smooth_phase
end

function reduced_dcdfba_phase_smoothing_width_from_env()::Float64
    raw = strip(get(ENV, "MPCC_REDUCED_DCDFBA_PHASE_SMOOTHING_WIDTH", "2e-4"))
    parsed = tryparse(Float64, raw)
    parsed === nothing && throw(
        ArgumentError("MPCC_REDUCED_DCDFBA_PHASE_SMOOTHING_WIDTH must be numeric; got '$raw'."),
    )
    return _reduced_dcdfba_validate_phase_smoothing_width(parsed)
end

function reduced_dcdfba_phase_proxy_mode_from_env()::Symbol
    raw = strip(get(ENV, "MPCC_REDUCED_DCDFBA_PHASE_PROXY_MODE", "total_molecular_weight"))
    return _reduced_dcdfba_phase_proxy_mode(raw)
end

function _reduced_dcdfba_dynamic_bounds_mode(mode::Union{Symbol, AbstractString})::Symbol
    normalized = Symbol(lowercase(replace(strip(String(mode)), '-' => '_')))
    normalized in (:growth, :smooth_phase, :phase_smooth) || throw(
        ArgumentError("Reduced DC-dFBA dynamic bounds mode must be :growth or :smooth_phase."),
    )
    return normalized == :growth ? :growth : :smooth_phase
end

function _reduced_dcdfba_phase_proxy_mode(mode::Union{Symbol, AbstractString})::Symbol
    normalized = Symbol(lowercase(replace(strip(String(mode)), '-' => '_')))
    aliases = Dict(
        :legacy => :total_molecular_weight,
        :current => :total_molecular_weight,
        :total => :total_molecular_weight,
        :total_nitrogen => :total_molecular_weight,
        :total_nitrogen_proxy => :total_molecular_weight,
        :molecular_weight => :total_molecular_weight,
        :total_molecular_weight => :total_molecular_weight,
        :free_n => :free_nitrogen,
        :free_nitrogen => :free_nitrogen,
        :nitrogen => :free_nitrogen,
        :nitrogen_equivalent => :nitrogen_equivalent,
        :n_equivalent => :nitrogen_equivalent,
        :aa_nitrogen_equivalent => :nitrogen_equivalent,
    )
    haskey(aliases, normalized) || throw(
        ArgumentError(
            "Reduced DC-dFBA phase proxy mode must be total_molecular_weight, " *
            "free_nitrogen, or nitrogen_equivalent. Got: $mode.",
        ),
    )
    return aliases[normalized]
end

function _reduced_dcdfba_validate_phase_smoothing_width(width::Real)::Float64
    value = Float64(width)
    isfinite(value) && value > 0.0 || throw(
        ArgumentError("Reduced DC-dFBA phase smoothing width must be positive and finite."),
    )
    return value
end

function _reduced_dcdfba_normalize_dynamic_control_schedule(
    dynamic_control_schedule,
)::Union{Nothing, DynamicControlSchedule}
    dynamic_control_schedule === nothing && return nothing
    dynamic_control_schedule isa DynamicControlSchedule || throw(
        ArgumentError("dynamic_control_schedule must be nothing or a DynamicControlSchedule."),
    )
    return dynamic_control_schedule
end

function _reduced_dcdfba_normalize_dynamic_control_decision_spec(
    dynamic_control_decision_spec,
)::Union{Nothing, DynamicControlDecisionSpec}
    dynamic_control_decision_spec === nothing && return nothing
    dynamic_control_decision_spec isa DynamicControlDecisionSpec || throw(
        ArgumentError(
            "dynamic_control_decision_spec must be nothing or a DynamicControlDecisionSpec.",
        ),
    )
    return dynamic_control_decision_spec
end

function _reduced_dcdfba_dynamic_control_values_within_bounds(
    values::AbstractVector{<:Real},
    lower::AbstractVector{<:Real},
    upper::AbstractVector{<:Real},
)::Bool
    length(values) == length(lower) == length(upper) || return false
    return all(eachindex(values)) do index
        value = Float64(values[index])
        lo = Float64(lower[index])
        hi = Float64(upper[index])
        isfinite(value) && isfinite(lo) && isfinite(hi) && lo <= value <= hi
    end
end

function _reduced_dcdfba_validate_dynamic_control_decision_spec(
    spec::DynamicControlDecisionSpec,
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule};
    tspan::Tuple{<:Real, <:Real},
    nfe::Int,
)::Nothing
    dynamic_control_schedule !== nothing || throw(
        ArgumentError(
            "dynamic_control_decision_spec requires a matching dynamic_control_schedule " *
            "while control variables are scaffolded but not yet coupled.",
        ),
    )
    nfe > 0 || throw(ArgumentError("dynamic_control_decision_spec requires nfe > 0."))
    t0 = Float64(tspan[1])
    t1 = Float64(tspan[2])
    isfinite(t0) && isfinite(t1) && t1 > t0 || throw(
        ArgumentError("dynamic_control_decision_spec requires a finite increasing tspan."),
    )
    t0 >= -1.0e-10 || throw(
        ArgumentError(
            "dynamic_control_decision_spec currently assumes a nonnegative absolute time grid.",
        ),
    )
    t1 <= spec.horizon_h + 1.0e-8 || throw(
        ArgumentError(
            "dynamic_control_decision_spec horizon $(spec.horizon_h) h does not cover tspan end $t1 h.",
        ),
    )
    spec.control_interval_h > 0.0 || throw(
        ArgumentError("dynamic_control_decision_spec control interval must be positive."),
    )
    length(spec.temperature_transition_times_h) + 1 == length(spec.temperature_start_C) ||
        throw(ArgumentError("dynamic_control_decision_spec temperature slot count is inconsistent."))
    length(spec.temperature_start_C) ==
    length(spec.temperature_lower_C) ==
    length(spec.temperature_upper_C) ==
    length(spec.temperature_free) || throw(
        ArgumentError("dynamic_control_decision_spec temperature bounds/free lengths mismatch."),
    )
    length(spec.addition_times_h) ==
    length(spec.fda_start_g_L) ==
    length(spec.fda_lower_g_L) ==
    length(spec.fda_upper_g_L) ==
    length(spec.fda_free) || throw(
        ArgumentError("dynamic_control_decision_spec FDA bounds/free lengths mismatch."),
    )
    length(spec.addition_times_h) ==
    length(spec.organic_start_g_L) ==
    length(spec.organic_lower_g_L) ==
    length(spec.organic_upper_g_L) ==
    length(spec.organic_free) || throw(
        ArgumentError("dynamic_control_decision_spec organic bounds/free lengths mismatch."),
    )
    _reduced_dcdfba_dynamic_control_values_within_bounds(
        spec.temperature_start_C,
        spec.temperature_lower_C,
        spec.temperature_upper_C,
    ) || throw(ArgumentError("dynamic_control_decision_spec temperature starts violate bounds."))
    _reduced_dcdfba_dynamic_control_values_within_bounds(
        spec.fda_start_g_L,
        spec.fda_lower_g_L,
        spec.fda_upper_g_L,
    ) || throw(ArgumentError("dynamic_control_decision_spec FDA starts violate bounds."))
    _reduced_dcdfba_dynamic_control_values_within_bounds(
        spec.organic_start_g_L,
        spec.organic_lower_g_L,
        spec.organic_upper_g_L,
    ) || throw(ArgumentError("dynamic_control_decision_spec organic starts violate bounds."))

    isapprox(
        dynamic_control_schedule.temperature_transition_times_h,
        spec.temperature_transition_times_h;
        atol = 1.0e-8,
        rtol = 1.0e-10,
    ) || throw(
        ArgumentError(
            "dynamic_control_decision_spec transition grid does not match dynamic_control_schedule.",
        ),
    )
    isapprox(
        dynamic_control_schedule.temperature_values_C,
        spec.temperature_start_C;
        atol = 1.0e-8,
        rtol = 1.0e-10,
    ) || throw(
        ArgumentError(
            "dynamic_control_decision_spec temperature starts do not match dynamic_control_schedule.",
        ),
    )
    isapprox(
        dynamic_control_schedule.temperature_transition_width_h,
        spec.temperature_transition_width_h;
        atol = 1.0e-10,
        rtol = 1.0e-10,
    ) || throw(
        ArgumentError(
            "dynamic_control_decision_spec temperature transition width does not match schedule.",
        ),
    )
    fda_start_from_schedule = _dynamic_control_dose_vector_from_events(
        dynamic_control_schedule.fda_events,
        spec.addition_times_h,
    )
    organic_start_from_schedule = _dynamic_control_dose_vector_from_events(
        dynamic_control_schedule.organic_events,
        spec.addition_times_h,
    )
    isapprox(fda_start_from_schedule, spec.fda_start_g_L; atol = 1.0e-8, rtol = 1.0e-10) ||
        throw(
            ArgumentError(
                "dynamic_control_decision_spec FDA starts do not match dynamic_control_schedule.",
            ),
        )
    isapprox(
        organic_start_from_schedule,
        spec.organic_start_g_L;
        atol = 1.0e-8,
        rtol = 1.0e-10,
    ) || throw(
        ArgumentError(
            "dynamic_control_decision_spec organic starts do not match dynamic_control_schedule.",
        ),
    )
    return nothing
end

function _reduced_dcdfba_mpcc_collocation_time(
    nlp::ReducedDCDFBACollocationNLP,
    element_index::Int,
    collocation_index::Int,
)::Float64
    return Float64(collocation_time(nlp.kkt_problem.grid, element_index, collocation_index))
end

function _reduced_dcdfba_mpcc_effective_params(
    nlp::ReducedDCDFBACollocationNLP,
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule},
    element_index::Int,
    collocation_index::Int,
)::ZentenoKineticParameters
    params = nlp.kkt_problem.params
    dynamic_control_schedule === nothing && return params
    time_h = _reduced_dcdfba_mpcc_collocation_time(nlp, element_index, collocation_index)
    return dynamic_zenteno_parameters(dynamic_control_schedule, time_h; base_params = params)
end

function _reduced_dcdfba_mpcc_effective_params(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    element_index::Int,
    collocation_index::Int,
    ;
    dynamic_control_values = nothing,
)::ZentenoKineticParameters
    if problem.dynamic_control_decisions !== nothing
        time_h = _reduced_dcdfba_mpcc_collocation_time(
            problem.nlp,
            element_index,
            collocation_index,
        )
        temperature_K =
            dynamic_control_values === nothing ?
            _reduced_dcdfba_dynamic_control_temperature_K_value(
                problem.dynamic_control_decisions,
                time_h,
            ) :
            _reduced_dcdfba_dynamic_control_temperature_K_value(
                problem.dynamic_control_decisions,
                dynamic_control_values,
                time_h,
            )
        return zenteno_parameters_with_temperature(
            problem.nlp.kkt_problem.params,
            temperature_K,
        )
    end
    return _reduced_dcdfba_mpcc_effective_params(
        problem.nlp,
        problem.dynamic_control_schedule,
        element_index,
        collocation_index,
    )
end

function _reduced_dcdfba_mpcc_dynamic_control_rhs_terms(
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule},
    params::ZentenoKineticParameters,
    state_values::AbstractVector,
    time_h::Real,
)
    dynamic_control_schedule === nothing && return (
        free_nitrogen_rate_gN_L_h = 0.0,
        amino_acid_state_rates_per_h = zeros(Float64, 5),
        aroma_loss_rates_g_L_h = zeros(Float64, 6),
    )

    values = dynamic_control_values(dynamic_control_schedule, time_h)
    amino_acid_nitrogen_rates =
        values.organic_nitrogen_rate_gN_L_h .*
        dynamic_control_schedule.organic_composition.amino_acid_nitrogen_fractions
    return (
        free_nitrogen_rate_gN_L_h = values.fda_nitrogen_rate_gN_L_h,
        amino_acid_state_rates_per_h = amino_acid_nitrogen_rates ./ params.MW_N,
        aroma_loss_rates_g_L_h =
            _reduced_dcdfba_mpcc_volatilization_aroma_loss_terms(
                dynamic_control_schedule.volatilization_model,
                state_values,
            ),
    )
end

function _reduced_dcdfba_dynamic_control_variable_value(variable::JuMP.VariableRef)::Float64
    if JuMP.result_count(JuMP.owner_model(variable)) > 0
        value = try
            JuMP.value(variable)
        catch
            nothing
        end
        if value !== nothing
            converted = Float64(value)
            isfinite(converted) && return converted
        end
    end
    start = JuMP.start_value(variable)
    start !== nothing || throw(
        ArgumentError("Dynamic-control variable has neither a solver value nor a start value."),
    )
    converted = Float64(start)
    isfinite(converted) || throw(
        ArgumentError("Dynamic-control variable start value is not finite."),
    )
    return converted
end

function _reduced_dcdfba_dynamic_control_variable_start_values_or_nothing(
    variables::AbstractVector{JuMP.VariableRef},
)
    values = try
        JuMP.start_value.(variables)
    catch
        return nothing
    end
    any(value -> value === nothing, values) && return nothing
    converted = Float64.(values)
    any(value -> !isfinite(value), converted) && return nothing
    return converted
end

function _reduced_dcdfba_dynamic_control_variable_solution_values_or_nothing(
    variables::AbstractVector{JuMP.VariableRef},
)
    values = _reduced_dcdfba_value_array_or_nothing(variables)
    values === nothing && return nothing
    converted = Float64.(values)
    any(value -> !isfinite(value), converted) && return nothing
    return converted
end

function _reduced_dcdfba_mpcc_empty_dynamic_control_candidate_values()
    return (
        temperature_C = Float64[],
        fda_g_L = Float64[],
        organic_g_L = Float64[],
    )
end

function _reduced_dcdfba_mpcc_dynamic_control_start_candidate_values_or_nothing(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)
    decisions = problem.dynamic_control_decisions
    decisions === nothing && return _reduced_dcdfba_mpcc_empty_dynamic_control_candidate_values()
    temperature_C =
        _reduced_dcdfba_dynamic_control_variable_start_values_or_nothing(decisions.temperature_variables)
    fda_g_L =
        _reduced_dcdfba_dynamic_control_variable_start_values_or_nothing(decisions.fda_variables)
    organic_g_L =
        _reduced_dcdfba_dynamic_control_variable_start_values_or_nothing(decisions.organic_variables)
    any(value -> value === nothing, (temperature_C, fda_g_L, organic_g_L)) && return nothing
    return (
        temperature_C = copy(temperature_C),
        fda_g_L = copy(fda_g_L),
        organic_g_L = copy(organic_g_L),
    )
end

function _reduced_dcdfba_mpcc_dynamic_control_solution_candidate_values_or_nothing(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)
    decisions = problem.dynamic_control_decisions
    decisions === nothing && return _reduced_dcdfba_mpcc_empty_dynamic_control_candidate_values()
    temperature_C =
        _reduced_dcdfba_dynamic_control_variable_solution_values_or_nothing(decisions.temperature_variables)
    fda_g_L =
        _reduced_dcdfba_dynamic_control_variable_solution_values_or_nothing(decisions.fda_variables)
    organic_g_L =
        _reduced_dcdfba_dynamic_control_variable_solution_values_or_nothing(decisions.organic_variables)
    any(value -> value === nothing, (temperature_C, fda_g_L, organic_g_L)) && return nothing
    return (
        temperature_C = copy(temperature_C),
        fda_g_L = copy(fda_g_L),
        organic_g_L = copy(organic_g_L),
    )
end

function _reduced_dcdfba_mpcc_candidate_dynamic_control_values(candidate_values)
    hasproperty(candidate_values, :dynamic_control_temperature_C) || return nothing
    hasproperty(candidate_values, :dynamic_control_fda_g_L) || return nothing
    hasproperty(candidate_values, :dynamic_control_organic_g_L) || return nothing
    temperature_C = Float64.(getproperty(candidate_values, :dynamic_control_temperature_C))
    fda_g_L = Float64.(getproperty(candidate_values, :dynamic_control_fda_g_L))
    organic_g_L = Float64.(getproperty(candidate_values, :dynamic_control_organic_g_L))
    isempty(temperature_C) && isempty(fda_g_L) && isempty(organic_g_L) && return nothing
    return (
        temperature_C = temperature_C,
        fda_g_L = fda_g_L,
        organic_g_L = organic_g_L,
    )
end

function _reduced_dcdfba_mpcc_candidate_dynamic_control_values_from_metadata(
    metadata::Dict{String, Any},
)
    get(metadata, "candidate_dynamic_control_values_captured", false) === true || return nothing
    temperature_C = get(metadata, "candidate_dynamic_control_temperature_C_values", nothing)
    fda_g_L = get(metadata, "candidate_dynamic_control_fda_g_L_values", nothing)
    organic_g_L = get(metadata, "candidate_dynamic_control_organic_g_L_values", nothing)
    any(value -> value === nothing, (temperature_C, fda_g_L, organic_g_L)) && return nothing
    return (
        temperature_C = Float64.(temperature_C),
        fda_g_L = Float64.(fda_g_L),
        organic_g_L = Float64.(organic_g_L),
    )
end

function _reduced_dcdfba_dynamic_control_step_coeff(
    time_h::Real,
    center_time_h::Real,
    width_h::Real,
)::Float64
    return _smooth_step(time_h, center_time_h, width_h)
end

function _reduced_dcdfba_dynamic_control_rate_coeff(
    time_h::Real,
    center_time_h::Real,
    width_h::Real,
)::Float64
    sigma = _reduced_dcdfba_dynamic_control_step_coeff(time_h, center_time_h, width_h)
    return sigma * (1.0 - sigma) / Float64(width_h)
end

function _reduced_dcdfba_dynamic_control_temperature_C_expression(
    decisions::ReducedDCDFBADynamicControlDecisionScaffold,
    time_h::Real,
)
    spec = decisions.spec
    variables = decisions.temperature_variables
    length(variables) == length(spec.temperature_start_C) || throw(
        ArgumentError("Dynamic-control temperature variable count does not match spec."),
    )
    value = variables[1]
    for (index, transition_time) in enumerate(spec.temperature_transition_times_h)
        coeff = _reduced_dcdfba_dynamic_control_step_coeff(
            time_h,
            transition_time,
            spec.temperature_transition_width_h,
        )
        value = value + coeff * (variables[index + 1] - variables[index])
    end
    return value
end

function _reduced_dcdfba_dynamic_control_temperature_K_expression(
    decisions::ReducedDCDFBADynamicControlDecisionScaffold,
    time_h::Real,
)
    return _reduced_dcdfba_dynamic_control_temperature_C_expression(decisions, time_h) + 273.15
end

function _reduced_dcdfba_dynamic_control_dose_rate_expression(
    variables::AbstractVector{JuMP.VariableRef},
    addition_times_h::AbstractVector{<:Real},
    transition_width_h::Real,
    time_h::Real,
)
    length(variables) == length(addition_times_h) || throw(
        ArgumentError("Dynamic-control dose variable count does not match addition grid."),
    )
    rate = 0.0
    for index in eachindex(variables)
        coeff = _reduced_dcdfba_dynamic_control_rate_coeff(
            time_h,
            addition_times_h[index],
            transition_width_h,
        )
        rate = rate + coeff * variables[index]
    end
    return rate
end

function _reduced_dcdfba_dynamic_control_temperature_C_value(
    decisions::ReducedDCDFBADynamicControlDecisionScaffold,
    time_h::Real,
)::Float64
    spec = decisions.spec
    values = _reduced_dcdfba_dynamic_control_variable_value.(decisions.temperature_variables)
    temperature = values[1]
    for (index, transition_time) in enumerate(spec.temperature_transition_times_h)
        coeff = _reduced_dcdfba_dynamic_control_step_coeff(
            time_h,
            transition_time,
            spec.temperature_transition_width_h,
        )
        temperature += coeff * (values[index + 1] - values[index])
    end
    return clamp(temperature, spec.temperature_min_C, spec.temperature_max_C)
end

function _reduced_dcdfba_dynamic_control_temperature_C_value(
    decisions::ReducedDCDFBADynamicControlDecisionScaffold,
    dynamic_control_values,
    time_h::Real,
)::Float64
    spec = decisions.spec
    values = Float64.(dynamic_control_values.temperature_C)
    length(values) == length(spec.temperature_start_C) || throw(
        ArgumentError("Captured dynamic-control temperature value count does not match spec."),
    )
    temperature = values[1]
    for (index, transition_time) in enumerate(spec.temperature_transition_times_h)
        coeff = _reduced_dcdfba_dynamic_control_step_coeff(
            time_h,
            transition_time,
            spec.temperature_transition_width_h,
        )
        temperature += coeff * (values[index + 1] - values[index])
    end
    return clamp(temperature, spec.temperature_min_C, spec.temperature_max_C)
end

function _reduced_dcdfba_dynamic_control_temperature_K_value(
    decisions::ReducedDCDFBADynamicControlDecisionScaffold,
    time_h::Real,
)::Float64
    return _reduced_dcdfba_dynamic_control_temperature_C_value(decisions, time_h) + 273.15
end

function _reduced_dcdfba_dynamic_control_temperature_K_value(
    decisions::ReducedDCDFBADynamicControlDecisionScaffold,
    dynamic_control_values,
    time_h::Real,
)::Float64
    return _reduced_dcdfba_dynamic_control_temperature_C_value(
        decisions,
        dynamic_control_values,
        time_h,
    ) + 273.15
end

function _reduced_dcdfba_dynamic_control_dose_rate_value(
    variables::AbstractVector{JuMP.VariableRef},
    addition_times_h::AbstractVector{<:Real},
    transition_width_h::Real,
    time_h::Real,
)::Float64
    length(variables) == length(addition_times_h) || throw(
        ArgumentError("Dynamic-control dose variable count does not match addition grid."),
    )
    values = _reduced_dcdfba_dynamic_control_variable_value.(variables)
    rate = 0.0
    for index in eachindex(values)
        coeff = _reduced_dcdfba_dynamic_control_rate_coeff(
            time_h,
            addition_times_h[index],
            transition_width_h,
        )
        rate += coeff * values[index]
    end
    return rate
end

function _reduced_dcdfba_dynamic_control_dose_rate_value(
    values::AbstractVector{<:Real},
    addition_times_h::AbstractVector{<:Real},
    transition_width_h::Real,
    time_h::Real,
)::Float64
    length(values) == length(addition_times_h) || throw(
        ArgumentError("Captured dynamic-control dose value count does not match addition grid."),
    )
    rate = 0.0
    for index in eachindex(values)
        coeff = _reduced_dcdfba_dynamic_control_rate_coeff(
            time_h,
            addition_times_h[index],
            transition_width_h,
        )
        rate += coeff * Float64(values[index])
    end
    return rate
end

function _reduced_dcdfba_mpcc_dynamic_control_rhs_terms(
    decisions::ReducedDCDFBADynamicControlDecisionScaffold,
    params::ZentenoKineticParameters,
    state_values::AbstractVector,
    time_h::Real,
)
    spec = decisions.spec
    fda_product_rate = _reduced_dcdfba_dynamic_control_dose_rate_expression(
        decisions.fda_variables,
        spec.addition_times_h,
        spec.addition_transition_width_h,
        time_h,
    )
    organic_product_rate = _reduced_dcdfba_dynamic_control_dose_rate_expression(
        decisions.organic_variables,
        spec.addition_times_h,
        spec.addition_transition_width_h,
        time_h,
    )
    organic_nitrogen_rate =
        organic_product_rate * spec.organic_composition.nitrogen_fraction_gN_per_g
    amino_acid_nitrogen_rates =
        organic_nitrogen_rate .* spec.organic_composition.amino_acid_nitrogen_fractions
    return (
        free_nitrogen_rate_gN_L_h = fda_product_rate * spec.fda_nitrogen_fraction_gN_per_g,
        amino_acid_state_rates_per_h = amino_acid_nitrogen_rates ./ params.MW_N,
        aroma_loss_rates_g_L_h =
            _reduced_dcdfba_mpcc_volatilization_aroma_loss_terms(
                spec.volatilization_model,
                state_values,
            ),
    )
end

function _reduced_dcdfba_mpcc_dynamic_control_rhs_terms_from_values(
    decisions::ReducedDCDFBADynamicControlDecisionScaffold,
    params::ZentenoKineticParameters,
    state_values::AbstractVector,
    time_h::Real,
)
    spec = decisions.spec
    fda_product_rate = _reduced_dcdfba_dynamic_control_dose_rate_value(
        decisions.fda_variables,
        spec.addition_times_h,
        spec.addition_transition_width_h,
        time_h,
    )
    organic_product_rate = _reduced_dcdfba_dynamic_control_dose_rate_value(
        decisions.organic_variables,
        spec.addition_times_h,
        spec.addition_transition_width_h,
        time_h,
    )
    organic_nitrogen_rate =
        organic_product_rate * spec.organic_composition.nitrogen_fraction_gN_per_g
    amino_acid_nitrogen_rates =
        organic_nitrogen_rate .* spec.organic_composition.amino_acid_nitrogen_fractions
    return (
        free_nitrogen_rate_gN_L_h = fda_product_rate * spec.fda_nitrogen_fraction_gN_per_g,
        amino_acid_state_rates_per_h = amino_acid_nitrogen_rates ./ params.MW_N,
        aroma_loss_rates_g_L_h =
            _reduced_dcdfba_mpcc_volatilization_aroma_loss_terms(
                spec.volatilization_model,
                state_values,
            ),
    )
end

function _reduced_dcdfba_mpcc_dynamic_control_rhs_terms_from_values(
    decisions::ReducedDCDFBADynamicControlDecisionScaffold,
    dynamic_control_values,
    params::ZentenoKineticParameters,
    state_values::AbstractVector,
    time_h::Real,
)
    spec = decisions.spec
    fda_product_rate = _reduced_dcdfba_dynamic_control_dose_rate_value(
        dynamic_control_values.fda_g_L,
        spec.addition_times_h,
        spec.addition_transition_width_h,
        time_h,
    )
    organic_product_rate = _reduced_dcdfba_dynamic_control_dose_rate_value(
        dynamic_control_values.organic_g_L,
        spec.addition_times_h,
        spec.addition_transition_width_h,
        time_h,
    )
    organic_nitrogen_rate =
        organic_product_rate * spec.organic_composition.nitrogen_fraction_gN_per_g
    amino_acid_nitrogen_rates =
        organic_nitrogen_rate .* spec.organic_composition.amino_acid_nitrogen_fractions
    return (
        free_nitrogen_rate_gN_L_h = fda_product_rate * spec.fda_nitrogen_fraction_gN_per_g,
        amino_acid_state_rates_per_h = amino_acid_nitrogen_rates ./ params.MW_N,
        aroma_loss_rates_g_L_h =
            _reduced_dcdfba_mpcc_volatilization_aroma_loss_terms(
                spec.volatilization_model,
                state_values,
            ),
    )
end

function _reduced_dcdfba_mpcc_volatilization_aroma_loss_terms(
    ::NoVolatilizationModel,
    state_values::AbstractVector,
)
    length(state_values) == KKT_DFBA_STATE_COUNT || throw(
        ArgumentError("Reduced MPCC dynamic-control RHS requires a 19-state vector."),
    )
    return zeros(Float64, 6)
end

function _reduced_dcdfba_mpcc_volatilization_aroma_loss_terms(
    model::VaporLiquidVolatilizationModel,
    state_values::AbstractVector,
)
    length(state_values) == KKT_DFBA_STATE_COUNT || throw(
        ArgumentError("Reduced MPCC dynamic-control RHS requires a 19-state vector."),
    )
    return [
        model.gas_exchange_rate_h_inv *
        model.aroma_partition_coefficients[k] *
        state_values[13 + k] for k in 1:6
    ]
end

function _reduced_dcdfba_mpcc_dynamic_control_metadata(
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule};
    applied_to_rhs::Bool = false,
    applied_to_dynamic_bounds::Bool = false,
)::Dict{String, Any}
    metadata = _dfba_dynamic_control_metadata(dynamic_control_schedule)
    metadata["mpcc_dynamic_control_schedule_argument_provided"] =
        dynamic_control_schedule !== nothing
    metadata["mpcc_dynamic_control_applied_to_rhs"] =
        dynamic_control_schedule !== nothing && applied_to_rhs
    metadata["mpcc_dynamic_control_applied_to_dynamic_bounds"] =
        dynamic_control_schedule !== nothing && applied_to_dynamic_bounds
    metadata["mpcc_fixed_control_replay_ready"] =
        dynamic_control_schedule !== nothing && applied_to_rhs && applied_to_dynamic_bounds
    metadata["mpcc_dynamic_control_variable_policy"] = "fixed_profile_not_decision_variable"
    metadata["mpcc_dynamic_control_decision_spec_provided"] = false
    metadata["mpcc_dynamic_control_decision_scaffold_built"] = false
    metadata["mpcc_dynamic_control_variables_coupled_to_rhs"] = false
    metadata["mpcc_dynamic_control_variables_coupled_to_dynamic_bounds"] = false
    metadata["fully_simultaneous_controls"] = false
    metadata["control_variable_count"] = 0
    metadata["control_free_variable_count"] = 0
    metadata["control_fixed_variable_count"] = 0
    metadata["free_temperature_count"] = 0
    metadata["free_fda_count"] = 0
    metadata["free_organic_count"] = 0
    metadata["control_bounds_ok"] = true
    metadata["control_starts_ok"] = true
    return metadata
end

function _reduced_dcdfba_add_dynamic_control_variable!(
    model::JuMP.Model,
    name::AbstractString,
    start::Real,
    lower::Real,
    upper::Real,
)::JuMP.VariableRef
    value = Float64(start)
    lo = Float64(lower)
    hi = Float64(upper)
    isfinite(value) && isfinite(lo) && isfinite(hi) && lo <= value <= hi || throw(
        ArgumentError("Dynamic-control variable $name has invalid start/bounds."),
    )
    variable = JuMP.@variable(model)
    JuMP.set_name(variable, String(name))
    JuMP.set_lower_bound(variable, lo)
    JuMP.set_upper_bound(variable, hi)
    JuMP.set_start_value(variable, value)
    return variable
end

function _reduced_dcdfba_add_dynamic_control_variables!(
    model::JuMP.Model,
    prefix::AbstractString,
    starts::AbstractVector{<:Real},
    lower::AbstractVector{<:Real},
    upper::AbstractVector{<:Real},
)::Vector{JuMP.VariableRef}
    length(starts) == length(lower) == length(upper) || throw(
        ArgumentError("Dynamic-control variable start/lower/upper lengths must match."),
    )
    variables = Vector{JuMP.VariableRef}(undef, length(starts))
    for index in eachindex(starts)
        variables[index] = _reduced_dcdfba_add_dynamic_control_variable!(
            model,
            "$(prefix)[$index]",
            starts[index],
            lower[index],
            upper[index],
        )
    end
    return variables
end

function _reduced_dcdfba_dynamic_control_variable_bounds_ok(
    variables::AbstractVector{JuMP.VariableRef},
    lower::AbstractVector{<:Real},
    upper::AbstractVector{<:Real},
)::Bool
    length(variables) == length(lower) == length(upper) || return false
    return all(eachindex(variables)) do index
        variable = variables[index]
        JuMP.has_lower_bound(variable) &&
            JuMP.has_upper_bound(variable) &&
            isapprox(JuMP.lower_bound(variable), Float64(lower[index]); atol = 1.0e-12, rtol = 1.0e-12) &&
            isapprox(JuMP.upper_bound(variable), Float64(upper[index]); atol = 1.0e-12, rtol = 1.0e-12)
    end
end

function _reduced_dcdfba_dynamic_control_variable_starts_ok(
    variables::AbstractVector{JuMP.VariableRef},
    starts::AbstractVector{<:Real},
)::Bool
    length(variables) == length(starts) || return false
    return all(eachindex(variables)) do index
        value = JuMP.start_value(variables[index])
        value !== nothing &&
            isapprox(Float64(value), Float64(starts[index]); atol = 1.0e-12, rtol = 1.0e-12)
    end
end

function build_reduced_dcdfba_dynamic_control_decision_scaffold!(
    nlp::ReducedDCDFBACollocationNLP,
    spec::Union{Nothing, DynamicControlDecisionSpec};
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule} = nothing,
)::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold}
    spec === nothing && return nothing
    _reduced_dcdfba_validate_dynamic_control_decision_spec(
        spec,
        dynamic_control_schedule;
        tspan = nlp.kkt_problem.grid.tspan,
        nfe = nlp.kkt_problem.grid.nfe,
    )

    temperature_variables = _reduced_dcdfba_add_dynamic_control_variables!(
        nlp.jump_model,
        "dynamic_control_temperature_C",
        spec.temperature_start_C,
        spec.temperature_lower_C,
        spec.temperature_upper_C,
    )
    fda_variables = _reduced_dcdfba_add_dynamic_control_variables!(
        nlp.jump_model,
        "dynamic_control_fda_g_L",
        spec.fda_start_g_L,
        spec.fda_lower_g_L,
        spec.fda_upper_g_L,
    )
    organic_variables = _reduced_dcdfba_add_dynamic_control_variables!(
        nlp.jump_model,
        "dynamic_control_organic_g_L",
        spec.organic_start_g_L,
        spec.organic_lower_g_L,
        spec.organic_upper_g_L,
    )

    temperature_bounds_ok = _reduced_dcdfba_dynamic_control_variable_bounds_ok(
        temperature_variables,
        spec.temperature_lower_C,
        spec.temperature_upper_C,
    )
    fda_bounds_ok = _reduced_dcdfba_dynamic_control_variable_bounds_ok(
        fda_variables,
        spec.fda_lower_g_L,
        spec.fda_upper_g_L,
    )
    organic_bounds_ok = _reduced_dcdfba_dynamic_control_variable_bounds_ok(
        organic_variables,
        spec.organic_lower_g_L,
        spec.organic_upper_g_L,
    )
    temperature_starts_ok = _reduced_dcdfba_dynamic_control_variable_starts_ok(
        temperature_variables,
        spec.temperature_start_C,
    )
    fda_starts_ok =
        _reduced_dcdfba_dynamic_control_variable_starts_ok(fda_variables, spec.fda_start_g_L)
    organic_starts_ok = _reduced_dcdfba_dynamic_control_variable_starts_ok(
        organic_variables,
        spec.organic_start_g_L,
    )

    free_temperature_count = count(identity, spec.temperature_free)
    free_fda_count = count(identity, spec.fda_free)
    free_organic_count = count(identity, spec.organic_free)
    control_variable_count =
        length(temperature_variables) + length(fda_variables) + length(organic_variables)
    control_free_variable_count =
        free_temperature_count + free_fda_count + free_organic_count
    metadata = Dict{String, Any}(
        "mpcc_dynamic_control_decision_spec_provided" => true,
        "mpcc_dynamic_control_decision_scaffold_built" => true,
        "mpcc_dynamic_control_variable_policy" => "scaffold_variables_not_yet_coupled",
        "mpcc_dynamic_control_variables_coupled_to_rhs" => false,
        "mpcc_dynamic_control_variables_coupled_to_dynamic_bounds" => false,
        "mpcc_dynamic_control_schedule_argument_provided" =>
            dynamic_control_schedule !== nothing,
        "mpcc_dynamic_control_fixed_schedule_available" =>
            dynamic_control_schedule !== nothing,
        "fully_simultaneous_controls" => false,
        "control_variable_count" => control_variable_count,
        "control_free_variable_count" => control_free_variable_count,
        "control_fixed_variable_count" =>
            control_variable_count - control_free_variable_count,
        "control_temperature_variable_count" => length(temperature_variables),
        "control_fda_variable_count" => length(fda_variables),
        "control_organic_variable_count" => length(organic_variables),
        "free_temperature_count" => free_temperature_count,
        "free_fda_count" => free_fda_count,
        "free_organic_count" => free_organic_count,
        "control_bounds_ok" =>
            temperature_bounds_ok && fda_bounds_ok && organic_bounds_ok,
        "control_starts_ok" =>
            temperature_starts_ok && fda_starts_ok && organic_starts_ok,
        "control_grid_horizon_h" => spec.horizon_h,
        "control_grid_interval_h" => spec.control_interval_h,
        "control_grid_tspan" => nlp.kkt_problem.grid.tspan,
        "control_grid_nfe" => nlp.kkt_problem.grid.nfe,
        "control_temperature_trust_region_C" => spec.temperature_trust_region_C,
        "control_fda_trust_region_g_L" => spec.fda_trust_region_g_L,
        "control_organic_trust_region_g_L" => spec.organic_trust_region_g_L,
        "control_scaffold_solver_call_performed" => false,
    )
    scaffold = ReducedDCDFBADynamicControlDecisionScaffold(
        spec,
        temperature_variables,
        fda_variables,
        organic_variables,
        metadata,
    )
    merge!(nlp.metadata, metadata)
    return scaffold
end

function _reduced_dcdfba_dynamic_control_reference_regularization_scale(trust::Real)::Float64
    value = Float64(trust)
    return isfinite(value) && value > 0.0 ? value : 1.0
end

function _reduced_dcdfba_add_dynamic_control_reference_regularization!(
    nlp::ReducedDCDFBACollocationNLP,
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold};
    weight::Real,
)::Dict{String, Any}
    regularization_weight = Float64(weight)
    isfinite(regularization_weight) && regularization_weight >= 0.0 || throw(
        ArgumentError(
            "Dynamic-control reference regularization weight must be finite and nonnegative.",
        ),
    )
    metadata = Dict{String, Any}(
        "dynamic_control_reference_regularization_weight" => regularization_weight,
        "dynamic_control_reference_regularization_weight_env" =>
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_REFERENCE_REGULARIZATION_WEIGHT_ENV,
        "dynamic_control_reference_regularization_enabled" => false,
        "dynamic_control_reference_regularization_policy" =>
            "disabled_or_no_free_control_variables",
        "dynamic_control_reference_regularization_term_count" => 0,
        "dynamic_control_reference_regularization_temperature_terms" => 0,
        "dynamic_control_reference_regularization_fda_terms" => 0,
        "dynamic_control_reference_regularization_organic_terms" => 0,
    )
    if dynamic_control_decisions === nothing || iszero(regularization_weight)
        merge!(nlp.metadata, metadata)
        return metadata
    end

    spec = dynamic_control_decisions.spec
    terms = Any[]
    temperature_scale =
        _reduced_dcdfba_dynamic_control_reference_regularization_scale(
            spec.temperature_trust_region_C,
        )
    fda_scale =
        _reduced_dcdfba_dynamic_control_reference_regularization_scale(
            spec.fda_trust_region_g_L,
        )
    organic_scale =
        _reduced_dcdfba_dynamic_control_reference_regularization_scale(
            spec.organic_trust_region_g_L,
        )
    for index in eachindex(dynamic_control_decisions.temperature_variables)
        spec.temperature_free[index] || continue
        variable = dynamic_control_decisions.temperature_variables[index]
        start = spec.temperature_start_C[index]
        push!(terms, ((variable - start) / temperature_scale)^2)
        metadata["dynamic_control_reference_regularization_temperature_terms"] =
            Int(metadata["dynamic_control_reference_regularization_temperature_terms"]) + 1
    end
    for index in eachindex(dynamic_control_decisions.fda_variables)
        spec.fda_free[index] || continue
        variable = dynamic_control_decisions.fda_variables[index]
        start = spec.fda_start_g_L[index]
        push!(terms, ((variable - start) / fda_scale)^2)
        metadata["dynamic_control_reference_regularization_fda_terms"] =
            Int(metadata["dynamic_control_reference_regularization_fda_terms"]) + 1
    end
    for index in eachindex(dynamic_control_decisions.organic_variables)
        spec.organic_free[index] || continue
        variable = dynamic_control_decisions.organic_variables[index]
        start = spec.organic_start_g_L[index]
        push!(terms, ((variable - start) / organic_scale)^2)
        metadata["dynamic_control_reference_regularization_organic_terms"] =
            Int(metadata["dynamic_control_reference_regularization_organic_terms"]) + 1
    end
    isempty(terms) && begin
        merge!(nlp.metadata, metadata)
        return metadata
    end

    base_objective = JuMP.objective_function(nlp.jump_model)
    regularization_expression = first(terms)
    for term in Iterators.drop(terms, 1)
        regularization_expression += term
    end
    JuMP.@objective(
        nlp.jump_model,
        Min,
        base_objective + regularization_weight * regularization_expression,
    )

    metadata["dynamic_control_reference_regularization_enabled"] = true
    metadata["dynamic_control_reference_regularization_policy"] =
        "quadratic_trust_scaled_deviation_from_reference_schedule"
    metadata["dynamic_control_reference_regularization_term_count"] = length(terms)
    merge!(nlp.metadata, metadata)
    return metadata
end

function _reduced_dcdfba_dynamic_control_objective_target_state(
    requested_state::AbstractString,
)::Tuple{String, String, String}
    normalized = lowercase(strip(String(requested_state)))
    if normalized in (
        "isoamyl_acetate",
        "isoamyl-acetate",
        "isoamyl acetate",
        "isopentyl_acetate",
        "3-methylbutyl_acetate",
    )
        return (
            "isoamyl_alcohol",
            "isoamyl_acetate_proxy",
            "isoamyl_acetate_not_explicit_in_reduced_state_vector",
        )
    end
    return (strip(String(requested_state)), strip(String(requested_state)), "exact_state_name")
end

function _reduced_dcdfba_dynamic_control_objective_is_white_wine_blend(
    requested_state::AbstractString,
)::Bool
    normalized = lowercase(strip(String(requested_state)))
    return normalized in (
        "white_wine_aroma_blend",
        "white-wine-aroma-blend",
        "white wine aroma blend",
        "aroma_blend",
        "available_aroma_blend",
        "reduced_aroma_blend",
    )
end

function _reduced_dcdfba_dynamic_control_objective_target_components(
    requested_state::AbstractString,
    state_names;
    terminal_state_scale_g_L::Real,
)
    if _reduced_dcdfba_dynamic_control_objective_is_white_wine_blend(
        requested_state,
    )
        components = NamedTuple[]
        for component in
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_WHITE_WINE_AROMA_BLEND_COMPONENTS
            state_index = findfirst(==(component.state_name), state_names)
            state_index === nothing && throw(
                ArgumentError(
                    "Dynamic-control white-wine aroma blend component " *
                    "'$(component.state_name)' is absent from DEFAULT_SIMULATION_STATE_NAMES.",
                ),
            )
            push!(
                components,
                (
                    state_name = component.state_name,
                    state_index = Int(state_index),
                    weight = Float64(component.weight),
                    scale_g_L = Float64(component.scale_g_L),
                ),
            )
        end
        return (
            "white_wine_aroma_blend",
            "available_aroma_state_blend",
            "available_reduced_aroma_linear_blend",
            0,
            components,
        )
    end

    target_state, target_alias, alias_policy =
        _reduced_dcdfba_dynamic_control_objective_target_state(requested_state)
    target_index = findfirst(==(target_state), state_names)
    target_index === nothing && throw(
        ArgumentError(
            "Dynamic-control objective target state '$(requested_state)' resolved to " *
            "'$(target_state)', which is absent from DEFAULT_SIMULATION_STATE_NAMES.",
        ),
    )
    return (
        target_state,
        target_alias,
        alias_policy,
        Int(target_index),
        [
            (
                state_name = target_state,
                state_index = Int(target_index),
                weight = 1.0,
                scale_g_L = Float64(terminal_state_scale_g_L),
            ),
        ],
    )
end

function _reduced_dcdfba_push_dynamic_control_objective_term!(
    terms::Vector{Any},
    expression,
    weight::Float64,
)
    iszero(weight) && return false
    push!(terms, expression)
    return true
end

function _reduced_dcdfba_dynamic_control_sum_expression(variables::AbstractVector)
    expression = 0.0
    for variable in variables
        expression += variable
    end
    return expression
end

function _reduced_dcdfba_variable_start_value_or_zero(variable)::Float64
    start = JuMP.start_value(variable)
    start === nothing && return 0.0
    value = Float64(start)
    return isfinite(value) ? value : 0.0
end

function _reduced_dcdfba_dynamic_control_integrated_aroma_reward_expression(
    nlp::ReducedDCDFBACollocationNLP,
    target_components,
)
    grid = nlp.kkt_problem.grid
    reaction_indices = _reduced_dcdfba_rhs_reaction_indices(nlp.kkt_problem)
    params = nlp.kkt_problem.params
    degree = nlp.dimensions.collocation_degree
    nfe = nlp.dimensions.nfe
    weights = grid.scheme.weights
    expression = 0.0
    for component in target_components
        aroma_index = Int(component.state_index) - 13
        1 <= aroma_index <= length(reaction_indices.aromas) || throw(
            ArgumentError(
                "Integrated aroma reward requires aroma states 14:19; " *
                "component '$(component.state_name)' has state index $(component.state_index).",
            ),
        )
        reaction_index_value = reaction_indices.aromas[aroma_index]
        molecular_weight = params.aroma_molecular_weights[aroma_index]
        component_scale = Float64(component.scale_g_L)
        component_weight = Float64(component.weight)
        for e in 1:nfe
            h = element_length(grid, e)
            for j in 1:degree
                expression +=
                    component_weight *
                    h *
                    weights[j] *
                    molecular_weight *
                    nlp.flux[reaction_index_value, e, j] *
                    nlp.state_collocation[1, e, j] / component_scale
            end
        end
    end
    return expression
end

function _reduced_dcdfba_dynamic_control_integrated_sugar_penalty_expression(
    nlp::ReducedDCDFBACollocationNLP,
    sugar_scale_g_L::Real,
)
    grid = nlp.kkt_problem.grid
    degree = nlp.dimensions.collocation_degree
    nfe = nlp.dimensions.nfe
    weights = grid.scheme.weights
    scale = Float64(sugar_scale_g_L)
    expression = 0.0
    horizon_h = 0.0
    for e in 1:nfe
        h = element_length(grid, e)
        horizon_h += h
        for j in 1:degree
            sugar = nlp.state_collocation[3, e, j] + nlp.state_collocation[4, e, j]
            expression += h * weights[j] * (sugar / scale)^2
        end
    end
    return horizon_h > 0.0 ? expression / horizon_h : expression
end

function _reduced_dcdfba_dynamic_control_integrated_sugar_excess_slack_expression(
    nlp::ReducedDCDFBACollocationNLP,
    sugar_max_g_L::Real,
    sugar_scale_g_L::Real,
)
    grid = nlp.kkt_problem.grid
    degree = nlp.dimensions.collocation_degree
    nfe = nlp.dimensions.nfe
    weights = grid.scheme.weights
    sugar_max = Float64(sugar_max_g_L)
    scale = Float64(sugar_scale_g_L)
    isfinite(sugar_max) && sugar_max >= 0.0 || throw(
        ArgumentError("Integrated sugar excess max must be finite and nonnegative."),
    )
    isfinite(scale) && scale > 0.0 || throw(
        ArgumentError("Integrated sugar excess scale must be finite and positive."),
    )

    expression = 0.0
    horizon_h = 0.0
    slack_count = 0
    max_slack_start = 0.0
    for e in 1:nfe
        h = element_length(grid, e)
        horizon_h += h
        for j in 1:degree
            sugar = nlp.state_collocation[3, e, j] + nlp.state_collocation[4, e, j]
            sugar_start =
                _reduced_dcdfba_variable_start_value_or_zero(nlp.state_collocation[3, e, j]) +
                _reduced_dcdfba_variable_start_value_or_zero(nlp.state_collocation[4, e, j])
            slack_start = max(0.0, sugar_start - sugar_max)
            slack = JuMP.@variable(nlp.jump_model, lower_bound = 0.0)
            JuMP.set_name(slack, "dynamic_control_integrated_sugar_excess_slack[$e,$j]")
            JuMP.set_start_value(slack, slack_start)
            JuMP.@constraint(nlp.jump_model, sugar - sugar_max <= slack)
            expression += h * weights[j] * (slack / scale)^2
            slack_count += 1
            max_slack_start = max(max_slack_start, slack_start)
        end
    end
    return (
        expression = horizon_h > 0.0 ? expression / horizon_h : expression,
        slack_count = slack_count,
        constraint_count = slack_count,
        max_slack_start_g_L = max_slack_start,
    )
end

function _reduced_dcdfba_refresh_dynamic_control_objective_slack_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "dynamic_control_objective_slack_start_refresh_applied" => false,
        "dynamic_control_objective_slack_start_refresh_integrated_sugar_count" => 0,
        "dynamic_control_objective_slack_start_refresh_integrated_sugar_max_delta_g_L" => 0.0,
        "dynamic_control_objective_slack_start_refresh_integrated_sugar_max_violation_before_g_L" =>
            0.0,
        "dynamic_control_objective_slack_start_refresh_terminal_sugar_excess_applied" =>
            false,
        "dynamic_control_objective_slack_start_refresh_terminal_sugar_excess_delta_g_L" =>
            0.0,
    )
    nlp = problem.nlp
    objective_metadata = problem.metadata
    raw_policy = get(
        objective_metadata,
        "dynamic_control_objective_integrated_sugar_policy",
        "disabled",
    )
    policy = raw_policy isa Missing ? "disabled" : String(raw_policy)
    sugar_max = _reduced_dcdfba_metadata_float(
        objective_metadata,
        "dynamic_control_objective_integrated_sugar_max_g_L",
        NaN,
    )
    if policy == "radau_time_average_of_squared_total_sugar_excess_slack" && isfinite(sugar_max)
        refreshed_count = 0
        max_delta = 0.0
        max_violation_before = 0.0
        for e in 1:nlp.dimensions.nfe
            for j in 1:nlp.dimensions.collocation_degree
                slack = JuMP.variable_by_name(
                    nlp.jump_model,
                    "dynamic_control_integrated_sugar_excess_slack[$e,$j]",
                )
                slack === nothing && continue
                sugar_start =
                    _reduced_dcdfba_variable_start_value_or_zero(
                        nlp.state_collocation[3, e, j],
                    ) +
                    _reduced_dcdfba_variable_start_value_or_zero(
                        nlp.state_collocation[4, e, j],
                    )
                old_start = _reduced_dcdfba_variable_start_value_or_zero(slack)
                new_start = max(0.0, sugar_start - sugar_max)
                JuMP.set_start_value(slack, new_start)
                refreshed_count += 1
                max_delta = max(max_delta, abs(new_start - old_start))
                max_violation_before =
                    max(max_violation_before, max(0.0, sugar_start - sugar_max - old_start))
            end
        end
        metadata["dynamic_control_objective_slack_start_refresh_applied"] =
            Bool(metadata["dynamic_control_objective_slack_start_refresh_applied"]) ||
            refreshed_count > 0
        metadata["dynamic_control_objective_slack_start_refresh_integrated_sugar_count"] =
            refreshed_count
        metadata["dynamic_control_objective_slack_start_refresh_integrated_sugar_max_delta_g_L"] =
            max_delta
        metadata[
            "dynamic_control_objective_slack_start_refresh_integrated_sugar_max_violation_before_g_L"
        ] = max_violation_before
    end

    terminal_slack = JuMP.variable_by_name(
        nlp.jump_model,
        "dynamic_control_terminal_sugar_excess_slack",
    )
    if terminal_slack !== nothing
        terminal_sugar_max = _reduced_dcdfba_metadata_float(
            objective_metadata,
            "dynamic_control_objective_terminal_sugar_max_g_L",
            NaN,
        )
        if isfinite(terminal_sugar_max)
            terminal_index = nlp.dimensions.nfe + 1
            sugar_start =
                _reduced_dcdfba_variable_start_value_or_zero(
                    nlp.state_boundary[3, terminal_index],
                ) +
                _reduced_dcdfba_variable_start_value_or_zero(
                    nlp.state_boundary[4, terminal_index],
                )
            old_start = _reduced_dcdfba_variable_start_value_or_zero(terminal_slack)
            new_start = max(0.0, sugar_start - terminal_sugar_max)
            JuMP.set_start_value(terminal_slack, new_start)
            metadata["dynamic_control_objective_slack_start_refresh_applied"] = true
            metadata[
                "dynamic_control_objective_slack_start_refresh_terminal_sugar_excess_applied"
            ] = true
            metadata[
                "dynamic_control_objective_slack_start_refresh_terminal_sugar_excess_delta_g_L"
            ] = abs(new_start - old_start)
        end
    end

    merge!(problem.metadata, metadata)
    merge!(problem.nlp.metadata, metadata)
    return metadata
end

function _reduced_dcdfba_dynamic_control_tail_residual_elements(
    element_spec::AbstractString,
    nfe::Integer,
)::Vector{Int}
    total_elements = Int(nfe)
    total_elements > 0 || throw(ArgumentError("Tail residual penalty requires nfe > 0."))
    normalized = lowercase(strip(String(element_spec)))
    if isempty(normalized) || normalized in ("last", "tail", "last9", "tail9")
        return collect(max(1, total_elements - 8):total_elements)
    elseif normalized in ("all", "*")
        return collect(1:total_elements)
    end

    last_match = match(r"^(last|tail)([0-9]+)$", normalized)
    if last_match !== nothing
        count = parse(Int, last_match.captures[2])
        count > 0 || throw(
            ArgumentError("Tail residual element count must be positive: $(element_spec)."),
        )
        return collect(max(1, total_elements - count + 1):total_elements)
    end

    elements = Int[]
    for token in split(normalized, ',')
        stripped = strip(token)
        isempty(stripped) && continue
        if occursin(':', stripped)
            parts = split(stripped, ':')
            length(parts) == 2 || throw(
                ArgumentError("Invalid tail residual element range: $(stripped)."),
            )
            first_element = parse(Int, strip(parts[1]))
            last_element = parse(Int, strip(parts[2]))
            first_element <= last_element || throw(
                ArgumentError("Tail residual element ranges must be increasing: $(stripped)."),
            )
            append!(elements, first_element:last_element)
        else
            push!(elements, parse(Int, stripped))
        end
    end
    isempty(elements) && throw(
        ArgumentError("Tail residual element specification selected no elements."),
    )
    unique!(sort!(elements))
    for element in elements
        1 <= element <= total_elements || throw(
            ArgumentError(
                "Tail residual element $(element) is outside valid range 1:$(total_elements).",
            ),
        )
    end
    return elements
end

function _reduced_dcdfba_dynamic_control_tail_residual_penalty_expression(
    nlp::ReducedDCDFBACollocationNLP;
    state_name::AbstractString,
    element_spec::AbstractString,
    scale_g_L::Real,
)
    state_names = copy(DEFAULT_SIMULATION_STATE_NAMES)
    resolved_state = strip(String(state_name))
    isempty(resolved_state) && throw(
        ArgumentError("Tail residual penalty state name must not be empty."),
    )
    state_index = findfirst(==(resolved_state), state_names)
    state_index === nothing && throw(
        ArgumentError(
            "Tail residual penalty state '$(resolved_state)' is absent from " *
            "DEFAULT_SIMULATION_STATE_NAMES.",
        ),
    )

    scale = Float64(scale_g_L)
    isfinite(scale) && scale > 0.0 || throw(
        ArgumentError("Tail residual penalty scale must be finite and positive."),
    )

    grid = nlp.kkt_problem.grid
    degree = nlp.dimensions.collocation_degree
    elements = _reduced_dcdfba_dynamic_control_tail_residual_elements(
        element_spec,
        nlp.dimensions.nfe,
    )
    integration_matrix = grid.scheme.integration_matrix
    continuity_weights = grid.scheme.continuity_weights

    expression = 0.0
    collocation_term_count = 0
    continuity_term_count = 0
    for e in elements
        h = element_length(grid, e)
        for j in 1:degree
            residual =
                nlp.state_collocation[state_index, e, j] -
                (
                    nlp.state_boundary[state_index, e] +
                    h * sum(
                        integration_matrix[j, k] *
                        nlp.state_derivative[state_index, e, k] for k in 1:degree
                    )
                )
            expression += (residual / scale)^2
            collocation_term_count += 1
        end
        continuity_residual =
            nlp.state_boundary[state_index, e + 1] -
            (
                nlp.state_boundary[state_index, e] +
                h * sum(
                    continuity_weights[k] *
                    nlp.state_derivative[state_index, e, k] for k in 1:degree
                )
            )
        expression += (continuity_residual / scale)^2
        continuity_term_count += 1
    end

    term_count = collocation_term_count + continuity_term_count
    return (
        expression = term_count > 0 ? expression / term_count : expression,
        state_name = resolved_state,
        state_index = Int(state_index),
        element_spec = strip(String(element_spec)),
        first_element = first(elements),
        last_element = last(elements),
        element_count = length(elements),
        term_count = term_count,
        collocation_term_count = collocation_term_count,
        continuity_term_count = continuity_term_count,
    )
end

function _reduced_dcdfba_add_dynamic_control_objective!(
    nlp::ReducedDCDFBACollocationNLP,
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold};
    config::ReducedDCDFBADynamicControlObjectiveConfig,
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "dynamic_control_objective_mode" => config.mode,
        "dynamic_control_objective_mode_env" =>
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_ENV,
        "dynamic_control_objective_enabled" => false,
        "dynamic_control_objective_policy" => "disabled",
        "dynamic_control_objective_requested_target_state" => config.target_state,
        "dynamic_control_objective_resolved_target_state" => missing,
        "dynamic_control_objective_target_state_alias" => missing,
        "dynamic_control_objective_target_state_alias_policy" => missing,
        "dynamic_control_objective_target_state_index" => 0,
        "dynamic_control_objective_target_component_count" => 0,
        "dynamic_control_objective_target_component_names" => String[],
        "dynamic_control_objective_target_component_weights" => Float64[],
        "dynamic_control_objective_target_component_scales_g_L" => Float64[],
        "dynamic_control_objective_terminal_reward_weight" =>
            config.terminal_reward_weight,
        "dynamic_control_objective_terminal_state_scale_g_L" =>
            config.terminal_state_scale_g_L,
        "dynamic_control_objective_terminal_sugar_weight" =>
            config.terminal_sugar_weight,
        "dynamic_control_objective_terminal_sugar_scale_g_L" =>
            config.terminal_sugar_scale_g_L,
        "dynamic_control_objective_integrated_sugar_weight" =>
            config.integrated_sugar_weight,
        "dynamic_control_objective_integrated_sugar_scale_g_L" =>
            config.integrated_sugar_scale_g_L,
        "dynamic_control_objective_integrated_sugar_config_policy" =>
            config.integrated_sugar_policy,
        "dynamic_control_objective_integrated_sugar_policy_env" =>
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_POLICY_ENV,
        "dynamic_control_objective_integrated_sugar_max_g_L" =>
            config.integrated_sugar_max_g_L,
        "dynamic_control_objective_aroma_reward_policy" =>
            config.aroma_reward_policy,
        "dynamic_control_objective_aroma_reward_policy_env" =>
            REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_REWARD_POLICY_ENV,
        "dynamic_control_objective_terminal_reward_effective_weight" =>
            config.terminal_reward_weight,
        "dynamic_control_objective_integrated_aroma_reward_effective_weight" => 0.0,
        "dynamic_control_objective_nutrient_weight" => config.nutrient_weight,
        "dynamic_control_objective_fda_weight" => config.fda_weight,
        "dynamic_control_objective_organic_weight" => config.organic_weight,
        "dynamic_control_objective_nutrient_scale_g_L" => config.nutrient_scale_g_L,
        "dynamic_control_objective_thermal_energy_weight" =>
            config.thermal_energy_weight,
        "dynamic_control_objective_ambient_temperature_C" =>
            config.ambient_temperature_C,
        "dynamic_control_objective_temperature_scale_C" => config.temperature_scale_C,
        "dynamic_control_objective_temperature_smoothness_weight" =>
            config.temperature_smoothness_weight,
        "dynamic_control_objective_temperature_smoothness_scale_C" =>
            config.temperature_smoothness_scale_C,
        "dynamic_control_objective_aroma_deficit_weight" =>
            config.aroma_deficit_weight,
        "dynamic_control_objective_aroma_deficit_target_g_L" =>
            config.aroma_deficit_target_g_L,
        "dynamic_control_objective_aroma_deficit_scale_g_L" =>
            config.aroma_deficit_scale_g_L,
        "dynamic_control_objective_terminal_sugar_excess_weight" =>
            config.terminal_sugar_excess_weight,
        "dynamic_control_objective_terminal_sugar_max_g_L" =>
            config.terminal_sugar_max_g_L,
        "dynamic_control_objective_terminal_sugar_excess_scale_g_L" =>
            config.terminal_sugar_excess_scale_g_L,
        "dynamic_control_objective_direct_temperature_reward_weight" =>
            config.direct_temperature_reward_weight,
        "dynamic_control_objective_direct_fda_reward_weight" =>
            config.direct_fda_reward_weight,
        "dynamic_control_objective_direct_organic_reward_weight" =>
            config.direct_organic_reward_weight,
        "dynamic_control_objective_tail_residual_weight" =>
            config.tail_residual_weight,
        "dynamic_control_objective_tail_residual_state" =>
            config.tail_residual_state,
        "dynamic_control_objective_tail_residual_elements" =>
            config.tail_residual_elements,
        "dynamic_control_objective_tail_residual_scale_g_L" =>
            config.tail_residual_scale_g_L,
        "dynamic_control_objective_term_count" => 0,
        "dynamic_control_objective_terminal_reward_terms" => 0,
        "dynamic_control_objective_aroma_deficit_terms" => 0,
        "dynamic_control_objective_aroma_deficit_constraint_built" => false,
        "dynamic_control_objective_aroma_deficit_slack_start_g_L" => 0.0,
        "dynamic_control_objective_terminal_sugar_terms" => 0,
        "dynamic_control_objective_terminal_sugar_excess_terms" => 0,
        "dynamic_control_objective_terminal_sugar_excess_constraint_built" => false,
        "dynamic_control_objective_terminal_sugar_excess_slack_start_g_L" => 0.0,
        "dynamic_control_objective_integrated_sugar_terms" => 0,
        "dynamic_control_objective_integrated_sugar_policy" => "disabled",
        "dynamic_control_objective_integrated_sugar_slack_count" => 0,
        "dynamic_control_objective_integrated_sugar_constraint_count" => 0,
        "dynamic_control_objective_integrated_sugar_max_slack_start_g_L" => 0.0,
        "dynamic_control_objective_integrated_sugar_expression_policy" => "disabled",
        "dynamic_control_objective_integrated_aroma_reward_terms" => 0,
        "dynamic_control_objective_integrated_aroma_reward_policy" => "disabled",
        "dynamic_control_objective_nutrient_terms" => 0,
        "dynamic_control_objective_thermal_energy_terms" => 0,
        "dynamic_control_objective_temperature_smoothness_terms" => 0,
        "dynamic_control_objective_direct_temperature_reward_terms" => 0,
        "dynamic_control_objective_direct_fda_reward_terms" => 0,
        "dynamic_control_objective_direct_organic_reward_terms" => 0,
        "dynamic_control_objective_tail_residual_terms" => 0,
        "dynamic_control_objective_tail_residual_state_index" => 0,
        "dynamic_control_objective_tail_residual_first_element" => 0,
        "dynamic_control_objective_tail_residual_last_element" => 0,
        "dynamic_control_objective_tail_residual_element_count" => 0,
        "dynamic_control_objective_tail_residual_collocation_term_count" => 0,
        "dynamic_control_objective_tail_residual_continuity_term_count" => 0,
        "dynamic_control_objective_temperature_slot_count" => 0,
        "dynamic_control_objective_fda_slot_count" => 0,
        "dynamic_control_objective_organic_slot_count" => 0,
    )
    if config.mode == REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE_OFF
        merge!(nlp.metadata, metadata)
        return metadata
    end

    state_names = copy(DEFAULT_SIMULATION_STATE_NAMES)
    target_state, target_alias, alias_policy, target_state_index, target_components =
        _reduced_dcdfba_dynamic_control_objective_target_components(
            config.target_state,
            state_names;
            terminal_state_scale_g_L = config.terminal_state_scale_g_L,
        )
    metadata["dynamic_control_objective_resolved_target_state"] = target_state
    metadata["dynamic_control_objective_target_state_alias"] = target_alias
    metadata["dynamic_control_objective_target_state_alias_policy"] = alias_policy
    metadata["dynamic_control_objective_target_state_index"] = target_state_index
    metadata["dynamic_control_objective_target_component_count"] =
        length(target_components)
    metadata["dynamic_control_objective_target_component_names"] =
        [String(component.state_name) for component in target_components]
    metadata["dynamic_control_objective_target_component_weights"] =
        [Float64(component.weight) for component in target_components]
    metadata["dynamic_control_objective_target_component_scales_g_L"] =
        [Float64(component.scale_g_L) for component in target_components]

    component_weight_sum = sum(
        Float64(component.weight) for component in target_components
    )
    component_weight_sum > 0.0 || throw(
        ArgumentError("Dynamic-control objective target component weights sum to zero."),
    )

    temperature_variables = JuMP.VariableRef[]
    fda_variables = JuMP.VariableRef[]
    organic_variables = JuMP.VariableRef[]
    if dynamic_control_decisions !== nothing
        append!(temperature_variables, dynamic_control_decisions.temperature_variables)
        append!(fda_variables, dynamic_control_decisions.fda_variables)
        append!(organic_variables, dynamic_control_decisions.organic_variables)
    end
    metadata["dynamic_control_objective_temperature_slot_count"] =
        length(temperature_variables)
    metadata["dynamic_control_objective_fda_slot_count"] = length(fda_variables)
    metadata["dynamic_control_objective_organic_slot_count"] = length(organic_variables)

    terms = Any[]
    terminal_reward_effective_weight = config.terminal_reward_weight
    integrated_reward_effective_weight = 0.0
    if config.aroma_reward_policy ==
       REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_AROMA_REWARD_POLICY_TERMINAL_PLUS_INTEGRATED_FLUX
        terminal_reward_effective_weight = 0.5 * config.terminal_reward_weight
        integrated_reward_effective_weight = 0.5 * config.terminal_reward_weight
    end
    metadata["dynamic_control_objective_terminal_reward_effective_weight"] =
        terminal_reward_effective_weight
    metadata["dynamic_control_objective_integrated_aroma_reward_effective_weight"] =
        integrated_reward_effective_weight

    terminal_reward_expression = 0.0
    for component in target_components
        final_state = nlp.state_boundary[component.state_index, nlp.dimensions.nfe + 1]
        terminal_reward_expression +=
            Float64(component.weight) * final_state / Float64(component.scale_g_L)
    end
    if _reduced_dcdfba_push_dynamic_control_objective_term!(
        terms,
        -terminal_reward_effective_weight * terminal_reward_expression / component_weight_sum,
        terminal_reward_effective_weight,
    )
        metadata["dynamic_control_objective_terminal_reward_terms"] = 1
    end
    if !iszero(config.aroma_deficit_weight)
        length(target_components) == 1 || throw(
            ArgumentError(
                "Dynamic-control aroma deficit target currently requires a single target state.",
            ),
        )
        component = only(target_components)
        final_target_state = nlp.state_boundary[component.state_index, nlp.dimensions.nfe + 1]
        target_start =
            _reduced_dcdfba_variable_start_value_or_zero(final_target_state)
        aroma_deficit_slack_start =
            max(0.0, config.aroma_deficit_target_g_L - target_start)
        aroma_deficit_slack = JuMP.@variable(
            nlp.jump_model,
            lower_bound = 0.0,
            base_name = "dynamic_control_aroma_deficit_slack",
        )
        JuMP.set_start_value(aroma_deficit_slack, aroma_deficit_slack_start)
        JuMP.@constraint(
            nlp.jump_model,
            config.aroma_deficit_target_g_L - final_target_state <= aroma_deficit_slack,
        )
        push!(
            terms,
            config.aroma_deficit_weight *
            (aroma_deficit_slack / config.aroma_deficit_scale_g_L)^2,
        )
        metadata["dynamic_control_objective_aroma_deficit_terms"] = 1
        metadata["dynamic_control_objective_aroma_deficit_constraint_built"] = true
        metadata["dynamic_control_objective_aroma_deficit_slack_start_g_L"] =
            aroma_deficit_slack_start
    end
    if !iszero(config.terminal_sugar_weight)
        final_sugar_expression =
            (
                nlp.state_boundary[3, nlp.dimensions.nfe + 1] +
                nlp.state_boundary[4, nlp.dimensions.nfe + 1]
            ) / config.terminal_sugar_scale_g_L
        push!(terms, config.terminal_sugar_weight * final_sugar_expression^2)
        metadata["dynamic_control_objective_terminal_sugar_terms"] = 1
    end
    if !iszero(config.terminal_sugar_excess_weight)
        final_sugar =
            nlp.state_boundary[3, nlp.dimensions.nfe + 1] +
            nlp.state_boundary[4, nlp.dimensions.nfe + 1]
        final_sugar_start =
            _reduced_dcdfba_variable_start_value_or_zero(
                nlp.state_boundary[3, nlp.dimensions.nfe + 1],
            ) +
            _reduced_dcdfba_variable_start_value_or_zero(
                nlp.state_boundary[4, nlp.dimensions.nfe + 1],
            )
        terminal_sugar_excess_slack_start =
            max(0.0, final_sugar_start - config.terminal_sugar_max_g_L)
        terminal_sugar_excess_slack = JuMP.@variable(
            nlp.jump_model,
            lower_bound = 0.0,
            base_name = "dynamic_control_terminal_sugar_excess_slack",
        )
        JuMP.set_start_value(
            terminal_sugar_excess_slack,
            terminal_sugar_excess_slack_start,
        )
        JuMP.@constraint(
            nlp.jump_model,
            final_sugar - config.terminal_sugar_max_g_L <= terminal_sugar_excess_slack,
        )
        push!(
            terms,
            config.terminal_sugar_excess_weight *
            (
                terminal_sugar_excess_slack /
                config.terminal_sugar_excess_scale_g_L
            )^2,
        )
        metadata["dynamic_control_objective_terminal_sugar_excess_terms"] = 1
        metadata["dynamic_control_objective_terminal_sugar_excess_constraint_built"] =
            true
        metadata["dynamic_control_objective_terminal_sugar_excess_slack_start_g_L"] =
            terminal_sugar_excess_slack_start
    end
    if !iszero(config.integrated_sugar_weight)
        integrated_sugar_expression = 0.0
        if config.integrated_sugar_policy ==
           REDUCED_DCDFBA_MPCC_DYNAMIC_CONTROL_INTEGRATED_SUGAR_POLICY_EXCESS_SLACK
            integrated_sugar_slacks =
                _reduced_dcdfba_dynamic_control_integrated_sugar_excess_slack_expression(
                    nlp,
                    config.integrated_sugar_max_g_L,
                    config.integrated_sugar_scale_g_L,
                )
            integrated_sugar_expression = integrated_sugar_slacks.expression
            metadata["dynamic_control_objective_integrated_sugar_slack_count"] =
                integrated_sugar_slacks.slack_count
            metadata["dynamic_control_objective_integrated_sugar_constraint_count"] =
                integrated_sugar_slacks.constraint_count
            metadata["dynamic_control_objective_integrated_sugar_max_slack_start_g_L"] =
                integrated_sugar_slacks.max_slack_start_g_L
            metadata["dynamic_control_objective_integrated_sugar_policy"] =
                "radau_time_average_of_squared_total_sugar_excess_slack"
            metadata["dynamic_control_objective_integrated_sugar_expression_policy"] =
                "radau_time_average_of_squared_total_sugar_excess_slack"
        else
            integrated_sugar_expression =
                _reduced_dcdfba_dynamic_control_integrated_sugar_penalty_expression(
                    nlp,
                    config.integrated_sugar_scale_g_L,
                )
            metadata["dynamic_control_objective_integrated_sugar_policy"] =
                "radau_time_average_of_squared_total_sugar"
            metadata["dynamic_control_objective_integrated_sugar_expression_policy"] =
                "radau_time_average_of_squared_total_sugar"
        end
        push!(terms, config.integrated_sugar_weight * integrated_sugar_expression)
        metadata["dynamic_control_objective_integrated_sugar_terms"] = 1
    end
    if integrated_reward_effective_weight > 0.0
        integrated_reward_expression =
            _reduced_dcdfba_dynamic_control_integrated_aroma_reward_expression(
                nlp,
                target_components,
            )
        push!(
            terms,
            -integrated_reward_effective_weight *
            integrated_reward_expression / component_weight_sum,
        )
        metadata["dynamic_control_objective_integrated_aroma_reward_terms"] = 1
        metadata["dynamic_control_objective_integrated_aroma_reward_policy"] =
            "radau_integral_of_gross_aroma_production_flux_times_biomass"
    end

    nutrient_slot_count = length(fda_variables) + length(organic_variables)
    if !iszero(config.nutrient_weight) && nutrient_slot_count > 0
        fda_sum = _reduced_dcdfba_dynamic_control_sum_expression(fda_variables)
        organic_sum = _reduced_dcdfba_dynamic_control_sum_expression(organic_variables)
        nutrient_expression =
            (config.fda_weight * fda_sum + config.organic_weight * organic_sum) /
            config.nutrient_scale_g_L
        push!(terms, config.nutrient_weight * nutrient_expression)
        metadata["dynamic_control_objective_nutrient_terms"] = 1
    end

    if !iszero(config.thermal_energy_weight) && !isempty(temperature_variables)
        thermal_expression = 0.0
        for variable in temperature_variables
            thermal_expression +=
                ((variable - config.ambient_temperature_C) / config.temperature_scale_C)^2
        end
        push!(
            terms,
            config.thermal_energy_weight * thermal_expression / length(temperature_variables),
        )
        metadata["dynamic_control_objective_thermal_energy_terms"] = 1
    end

    if !iszero(config.temperature_smoothness_weight) && length(temperature_variables) > 1
        smoothness_expression = 0.0
        for index in 2:length(temperature_variables)
            smoothness_expression +=
                (
                    (temperature_variables[index] - temperature_variables[index - 1]) /
                    config.temperature_smoothness_scale_C
                )^2
        end
        push!(
            terms,
            config.temperature_smoothness_weight * smoothness_expression /
            (length(temperature_variables) - 1),
        )
        metadata["dynamic_control_objective_temperature_smoothness_terms"] = 1
    end

    if !iszero(config.direct_temperature_reward_weight) && !isempty(temperature_variables)
        direct_temperature_expression = 0.0
        for variable in temperature_variables
            direct_temperature_expression +=
                (variable - config.ambient_temperature_C) / config.temperature_scale_C
        end
        push!(
            terms,
            -config.direct_temperature_reward_weight *
            direct_temperature_expression / length(temperature_variables),
        )
        metadata["dynamic_control_objective_direct_temperature_reward_terms"] = 1
    end

    if !iszero(config.direct_fda_reward_weight) && !isempty(fda_variables)
        fda_expression =
            _reduced_dcdfba_dynamic_control_sum_expression(fda_variables) /
            config.nutrient_scale_g_L
        push!(terms, -config.direct_fda_reward_weight * fda_expression)
        metadata["dynamic_control_objective_direct_fda_reward_terms"] = 1
    end

    if !iszero(config.direct_organic_reward_weight) && !isempty(organic_variables)
        organic_expression =
            _reduced_dcdfba_dynamic_control_sum_expression(organic_variables) /
            config.nutrient_scale_g_L
        push!(terms, -config.direct_organic_reward_weight * organic_expression)
        metadata["dynamic_control_objective_direct_organic_reward_terms"] = 1
    end

    if !iszero(config.tail_residual_weight)
        tail_residual =
            _reduced_dcdfba_dynamic_control_tail_residual_penalty_expression(
                nlp;
                state_name = config.tail_residual_state,
                element_spec = config.tail_residual_elements,
                scale_g_L = config.tail_residual_scale_g_L,
            )
        push!(terms, config.tail_residual_weight * tail_residual.expression)
        metadata["dynamic_control_objective_tail_residual_terms"] =
            tail_residual.term_count
        metadata["dynamic_control_objective_tail_residual_state"] =
            tail_residual.state_name
        metadata["dynamic_control_objective_tail_residual_state_index"] =
            tail_residual.state_index
        metadata["dynamic_control_objective_tail_residual_elements"] =
            tail_residual.element_spec
        metadata["dynamic_control_objective_tail_residual_first_element"] =
            tail_residual.first_element
        metadata["dynamic_control_objective_tail_residual_last_element"] =
            tail_residual.last_element
        metadata["dynamic_control_objective_tail_residual_element_count"] =
            tail_residual.element_count
        metadata["dynamic_control_objective_tail_residual_collocation_term_count"] =
            tail_residual.collocation_term_count
        metadata["dynamic_control_objective_tail_residual_continuity_term_count"] =
            tail_residual.continuity_term_count
    end

    if isempty(terms)
        metadata["dynamic_control_objective_policy"] = "enabled_but_all_weights_zero"
        merge!(nlp.metadata, metadata)
        return metadata
    end

    base_objective = JuMP.objective_function(nlp.jump_model)
    objective_expression = first(terms)
    for term in Iterators.drop(terms, 1)
        objective_expression += term
    end
    JuMP.@objective(nlp.jump_model, Min, base_objective + objective_expression)

    metadata["dynamic_control_objective_enabled"] = true
    metadata["dynamic_control_objective_policy"] =
        "aroma_reward_or_deficit_plus_optional_sugar_constraint_nutrient_and_thermal_costs"
    metadata["dynamic_control_objective_term_count"] = length(terms)
    metadata["objective_description"] =
        "base objective plus dynamic-control aroma/sugar/nutrient/thermal objective"
    merge!(nlp.metadata, metadata)
    return metadata
end

function build_reduced_dcdfba_dynamic_bounds(
    nlp::ReducedDCDFBACollocationNLP;
    mode::Symbol = :growth,
    phase_smoothing_width::Real = reduced_dcdfba_phase_smoothing_width_from_env(),
    phase_proxy_mode::Union{Symbol, AbstractString} = reduced_dcdfba_phase_proxy_mode_from_env(),
    dynamic_control_schedule = nothing,
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold} =
        nothing,
)::ReducedDCDFBADynamicBoundsScaffold
    resolved_mode = _reduced_dcdfba_dynamic_bounds_mode(mode)
    resolved_phase_smoothing_width =
        _reduced_dcdfba_validate_phase_smoothing_width(phase_smoothing_width)
    resolved_phase_proxy_mode = _reduced_dcdfba_phase_proxy_mode(phase_proxy_mode)
    resolved_dynamic_control_schedule =
        _reduced_dcdfba_normalize_dynamic_control_schedule(dynamic_control_schedule)
    get(nlp.metadata, "dynamic_flux_bounds_built", false) && throw(
        ArgumentError("Reduced DC-dFBA dynamic bounds were already built for this NLP."),
    )

    lower_bound_expressions = Dict{Tuple{Int, Int, Int}, Any}()
    upper_bound_expressions = Dict{Tuple{Int, Int, Int}, Any}()
    objective_coefficients = zeros(Float64, nlp.dimensions.n_reactions)
    objective_coefficient_expressions = Dict{Tuple{Int, Int, Int}, Any}()

    reaction_indices = _reduced_dcdfba_rhs_reaction_indices(nlp.kkt_problem)
    if resolved_mode == :growth
        _build_reduced_dcdfba_growth_dynamic_bound_expressions!(
            lower_bound_expressions,
            upper_bound_expressions,
            nlp,
            reaction_indices,
            resolved_dynamic_control_schedule,
            dynamic_control_decisions,
        )
        _build_reduced_dcdfba_growth_objective_coefficients!(
            objective_coefficients,
            reaction_indices,
        )
    elseif resolved_mode == :smooth_phase
        _build_reduced_dcdfba_smooth_phase_dynamic_bound_expressions!(
            lower_bound_expressions,
            upper_bound_expressions,
            objective_coefficient_expressions,
            nlp,
            reaction_indices,
            resolved_phase_smoothing_width,
            resolved_phase_proxy_mode,
            resolved_dynamic_control_schedule,
            dynamic_control_decisions,
        )
    else
        throw(ArgumentError("Unsupported reduced DC-dFBA dynamic bounds mode: $resolved_mode."))
    end

    lower_reactions = _unique_sorted_first_indices(lower_bound_expressions)
    upper_reactions = _unique_sorted_first_indices(upper_bound_expressions)
    objective_reactions = _reduced_dcdfba_dynamic_objective_reactions(
        objective_coefficients,
        objective_coefficient_expressions,
    )
    layout = _reduced_dcdfba_dynamic_bounds_layout(
        nlp.dimensions,
        lower_reactions,
        upper_reactions,
        objective_reactions,
    )
    metadata = _reduced_dcdfba_dynamic_bounds_metadata(
        nlp,
        reaction_indices,
        lower_reactions,
        upper_reactions,
        objective_reactions,
        layout,
        resolved_mode,
        resolved_phase_smoothing_width,
        resolved_phase_proxy_mode,
        objective_coefficient_expressions,
        resolved_dynamic_control_schedule,
        dynamic_control_decisions,
    )

    merge!(nlp.metadata, metadata)

    return ReducedDCDFBADynamicBoundsScaffold(
        nlp,
        lower_bound_expressions,
        upper_bound_expressions,
        objective_coefficients,
        objective_coefficient_expressions,
        lower_reactions,
        upper_reactions,
        objective_reactions,
        layout,
        resolved_mode,
        metadata,
    )
end

"""
    initialize_reduced_dcdfba_from_simulation!(nlp, simulation)

Interpolate a sequential reduced DFBA `SimulationResult` onto the
direct-collocation grid and apply the resulting values as JuMP starts. State
starts are interpolated at finite-element boundaries and Radau collocation
times; derivative starts use piecewise-linear slopes from the saved sequential
states. Flux starts are applied only for reaction IDs present in
`simulation.metadata["flux_rxn_ids"]`; all other flux starts are preserved.
"""
function initialize_reduced_dcdfba_from_simulation!(
    nlp::ReducedDCDFBACollocationNLP,
    simulation::SimulationResult;
    flux_start_policy::Symbol = :provided_fluxes_or_existing,
)::ReducedDCDFBASequentialInitialization
    flux_start_policy == :provided_fluxes_or_existing || throw(
        ArgumentError(
            "Reduced DC-dFBA sequential initialization supports flux_start_policy=:provided_fluxes_or_existing only.",
        ),
    )
    get(nlp.metadata, "sequential_initialization_built", false) && throw(
        ArgumentError("Reduced DC-dFBA sequential initialization was already applied to this NLP."),
    )
    _validate_reduced_dcdfba_sequential_initialization_inputs(nlp, simulation)

    state_boundary_starts = _reduced_dcdfba_sequential_state_boundary_starts(nlp, simulation)
    state_collocation_starts = _reduced_dcdfba_sequential_state_collocation_starts(nlp, simulation)
    state_derivative_starts = _reduced_dcdfba_sequential_state_derivative_starts(nlp, simulation)
    flux_starts, flux_reaction_ids, initialized_flux_indices =
        _reduced_dcdfba_sequential_flux_starts(nlp, simulation)

    _apply_reduced_dcdfba_sequential_start_values!(
        nlp,
        state_boundary_starts,
        state_collocation_starts,
        state_derivative_starts,
        flux_starts,
        initialized_flux_indices,
    )

    metadata = _reduced_dcdfba_sequential_initialization_metadata(
        nlp,
        simulation,
        flux_start_policy,
        flux_reaction_ids,
        initialized_flux_indices,
    )
    merge!(nlp.metadata, metadata)

    return ReducedDCDFBASequentialInitialization(
        nlp,
        state_boundary_starts,
        state_collocation_starts,
        state_derivative_starts,
        flux_starts,
        flux_reaction_ids,
        initialized_flux_indices,
        metadata,
    )
end

"""
    build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map; kwargs...)

Build a guarded reduced MPCC smoke problem for the real reduced model with a
single default finite element. The builder initializes flux starts from a
static reduced FBA solve, assembles fixed-bound KKT/MPCC rows, and does not
call Ipopt.
"""
function build_reduced_dcdfba_mpcc_smoke_problem(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    tspan::Tuple{<:Real, <:Real} = (0.0, 0.25),
    nfe::Int = 1,
    degree::Int = 3,
    element_bounds::Union{Nothing, AbstractVector{<:Tuple{<:Real, <:Real}}} = nothing,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    include_rhs::Bool = false,
    use_dynamic_bounds::Bool = false,
    dynamic_bounds_mode::Symbol = reduced_dcdfba_dynamic_bounds_mode_from_env(),
    dynamic_phase_smoothing_width::Real = reduced_dcdfba_phase_smoothing_width_from_env(),
    dynamic_phase_proxy_mode::Union{Symbol, AbstractString} =
        reduced_dcdfba_phase_proxy_mode_from_env(),
    dynamic_control_schedule = nothing,
    dynamic_control_decision_spec = nothing,
    dynamic_control_reference_regularization_weight::Real =
        reduced_mpcc_dynamic_control_reference_regularization_weight_from_env(),
    dynamic_control_objective_config::ReducedDCDFBADynamicControlObjectiveConfig =
        reduced_mpcc_dynamic_control_objective_config_from_env(),
    sequential_initialization::Union{Nothing, SimulationResult} = nothing,
    initial_state = nothing,
    objective_coefficients::Union{Nothing, AbstractVector{<:Real}} = nothing,
    collocation_consistent_state_starts::Bool = false,
    collocation_consistent_state_start_max_iterations::Int = 4,
    collocation_consistent_state_start_tolerance::Real = 1.0e-10,
    collocation_consistent_state_start_element_indices = nothing,
    apply_default_start_initializers::Bool = true,
    state_nonnegative_bounds::Bool = reduced_dcdfba_state_nonnegative_bounds_from_env(),
    state_nonnegative_start_clamp::Bool =
        reduced_dcdfba_state_nonnegative_start_clamp_from_env(),
    optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} = 0,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_EXACT,
    complementarity_tau::Real = REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU,
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    silent::Bool = true,
)::ReducedDCDFBAMPCCSmokeProblem
    trace_start_time = time()
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_build_start",
    )
    _validate_reduced_dcdfba_mpcc_smoke_max_iter(ipopt_max_iter)
    resolved_linear_solver = _canonical_ipopt_linear_solver(linear_solver)
    resolved_complementarity_mode =
        _reduced_dcdfba_mpcc_complementarity_mode(complementarity_mode)
    resolved_complementarity_tau =
        _reduced_dcdfba_mpcc_validate_complementarity_tau(complementarity_tau)
    resolved_complementarity_tau_gate_tol =
        _reduced_dcdfba_mpcc_validate_complementarity_tau_gate_tol(
            complementarity_tau_gate_tol,
        )
    resolved_dynamic_control_schedule =
        _reduced_dcdfba_normalize_dynamic_control_schedule(dynamic_control_schedule)
    resolved_dynamic_control_decision_spec =
        _reduced_dcdfba_normalize_dynamic_control_decision_spec(dynamic_control_decision_spec)
    if resolved_dynamic_control_decision_spec !== nothing
        _reduced_dcdfba_validate_dynamic_control_decision_spec(
            resolved_dynamic_control_decision_spec,
            resolved_dynamic_control_schedule;
            tspan = tspan,
            nfe = nfe,
        )
    end
    resolved_optimizer = optimizer === nothing ?
                         ipopt_optimizer(;
                             linear_solver = resolved_linear_solver,
                             max_iter = ipopt_max_iter,
                         ) :
                         optimizer
    resolved_initial_state, initial_state_metadata =
        _reduced_dcdfba_mpcc_smoke_initial_state(initial_state, sequential_initialization)

    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_before_collocation_nlp_build",
    )
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = tspan,
        nfe = nfe,
        degree = degree,
        element_bounds = element_bounds,
        params = params,
        initial_state = resolved_initial_state,
        optimizer = resolved_optimizer,
        silent = silent,
        defer_fixed_flux_variable_bounds = true,
        state_nonnegative_bounds = state_nonnegative_bounds,
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_after_collocation_nlp_build",
    )
    flux_start, flux_start_metadata =
        _reduced_dcdfba_mpcc_smoke_static_fba_flux_start(model, reaction_map)
    _set_reduced_dcdfba_flux_start!(nlp, flux_start)
    sequential_start = sequential_initialization === nothing ?
                       nothing :
                       initialize_reduced_dcdfba_from_simulation!(nlp, sequential_initialization)
    dynamic_control_decisions = build_reduced_dcdfba_dynamic_control_decision_scaffold!(
        nlp,
        resolved_dynamic_control_decision_spec;
        dynamic_control_schedule = resolved_dynamic_control_schedule,
    )
    dynamic_control_reference_regularization_metadata =
        _reduced_dcdfba_add_dynamic_control_reference_regularization!(
            nlp,
            dynamic_control_decisions;
            weight = dynamic_control_reference_regularization_weight,
        )
    dynamic_control_objective_metadata = _reduced_dcdfba_add_dynamic_control_objective!(
        nlp,
        dynamic_control_decisions;
        config = dynamic_control_objective_config,
    )

    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_before_rhs_residuals",
    )
    rhs_residuals = include_rhs ?
                    add_reduced_dcdfba_rhs_residuals!(
                        nlp;
                        dynamic_control_schedule = resolved_dynamic_control_schedule,
                        dynamic_control_decisions = dynamic_control_decisions,
                    ) :
                    nothing
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_after_rhs_residuals",
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_before_dynamic_bounds",
    )
    dynamic_bounds = use_dynamic_bounds ?
                     build_reduced_dcdfba_dynamic_bounds(
                         nlp;
                         mode = dynamic_bounds_mode,
                         phase_smoothing_width = dynamic_phase_smoothing_width,
                         phase_proxy_mode = dynamic_phase_proxy_mode,
                         dynamic_control_schedule = resolved_dynamic_control_schedule,
                         dynamic_control_decisions = dynamic_control_decisions,
                     ) :
                     nothing
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_after_dynamic_bounds",
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_before_kkt_rows",
    )
    primal_feasibility = add_reduced_dcdfba_primal_feasibility!(nlp)
    bound_feasibility = add_reduced_dcdfba_bound_feasibility!(nlp; dynamic_bounds = dynamic_bounds)
    stationarity_objective_coefficients =
        objective_coefficients === nothing && dynamic_bounds !== nothing ?
        dynamic_bounds.objective_coefficients :
        objective_coefficients
    stationarity_objective_expressions =
        objective_coefficients === nothing && dynamic_bounds !== nothing ?
        dynamic_bounds.objective_coefficient_expressions :
        nothing
    stationarity = add_reduced_dcdfba_stationarity!(
        nlp,
        bound_feasibility;
        objective_coefficients = stationarity_objective_coefficients,
        objective_coefficient_expressions = stationarity_objective_expressions,
    )
    complementarity = add_reduced_dcdfba_complementarity!(
        nlp,
        stationarity;
        complementarity_mode = resolved_complementarity_mode,
        complementarity_tau = resolved_complementarity_tau,
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_after_kkt_rows",
    )

    metadata = _reduced_dcdfba_mpcc_smoke_problem_metadata(
        nlp,
        include_rhs,
        use_dynamic_bounds,
        sequential_start,
        ipopt_max_iter,
        resolved_linear_solver,
        resolved_complementarity_mode,
        resolved_complementarity_tau,
        resolved_complementarity_tau_gate_tol,
        flux_start_metadata,
        resolved_dynamic_control_schedule,
        dynamic_control_decisions,
    )
    merge!(metadata, initial_state_metadata)
    merge!(metadata, dynamic_control_reference_regularization_metadata)
    merge!(metadata, dynamic_control_objective_metadata)
    merge!(nlp.metadata, metadata)

    problem = ReducedDCDFBAMPCCSmokeProblem(
        nlp,
        rhs_residuals,
        dynamic_bounds,
        resolved_dynamic_control_schedule,
        dynamic_control_decisions,
        sequential_start,
        primal_feasibility,
        bound_feasibility,
        stationarity,
        complementarity,
        flux_start,
        metadata,
    )
    if apply_default_start_initializers
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_before_default_start_initializers",
        )
        applied_start_metadata = Dict{String, Any}(
            "default_start_initializers_applied" => true,
        )
        merge!(problem.metadata, applied_start_metadata)
        merge!(problem.nlp.metadata, applied_start_metadata)
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_before_dynamic_flux_lp_starts",
        )
        local_lp_metadata = _reduced_dcdfba_apply_dynamic_flux_lp_starts!(problem)
        merge!(problem.metadata, local_lp_metadata)
        merge!(problem.nlp.metadata, local_lp_metadata)
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_after_dynamic_flux_lp_starts",
        )
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_before_dynamic_flux_projection_starts",
        )
        projection_metadata = _reduced_dcdfba_project_dynamic_flux_starts!(problem)
        merge!(problem.metadata, projection_metadata)
        merge!(problem.nlp.metadata, projection_metadata)
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_after_dynamic_flux_projection_starts",
        )
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_before_stationarity_dual_starts",
        )
        stationarity_dual_metadata = _reduced_dcdfba_apply_stationarity_dual_starts!(problem)
        merge!(problem.metadata, stationarity_dual_metadata)
        merge!(problem.nlp.metadata, stationarity_dual_metadata)
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_after_stationarity_dual_starts",
        )
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_before_rhs_derivative_starts",
        )
        derivative_metadata = _reduced_dcdfba_apply_rhs_consistent_derivative_starts!(problem)
        merge!(problem.metadata, derivative_metadata)
        merge!(problem.nlp.metadata, derivative_metadata)
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_after_rhs_derivative_starts",
        )
        if collocation_consistent_state_starts
            _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
                trace_start_time,
                "smoke_problem_before_collocation_consistent_state_starts",
            )
            state_start_metadata = _reduced_dcdfba_apply_collocation_consistent_state_starts!(
                problem;
                max_iterations = collocation_consistent_state_start_max_iterations,
                tolerance = Float64(collocation_consistent_state_start_tolerance),
                element_indices = collocation_consistent_state_start_element_indices,
            )
            merge!(problem.metadata, state_start_metadata)
            merge!(problem.nlp.metadata, state_start_metadata)
            _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
                trace_start_time,
                "smoke_problem_after_collocation_consistent_state_starts",
            )
        end
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "smoke_problem_after_default_start_initializers",
        )
    else
        skipped_start_metadata = Dict{String, Any}(
            "default_start_initializers_applied" => false,
            "dynamic_flux_lp_starts_applied" => false,
            "dynamic_flux_projection_starts_applied" => false,
            "stationarity_dual_starts_applied" => false,
            "rhs_consistent_derivative_starts_applied" => false,
            "collocation_consistent_state_starts_applied" => false,
            "default_start_initializers_skip_reason" =>
                "external_dense_start_values_will_be_applied",
        )
        merge!(problem.metadata, skipped_start_metadata)
        merge!(problem.nlp.metadata, skipped_start_metadata)
    end
    state_clamp_metadata = _reduced_dcdfba_clamp_state_starts_to_nonnegative_bounds!(
        problem.nlp;
        requested = state_nonnegative_start_clamp,
    )
    merge!(problem.metadata, state_clamp_metadata)
    merge!(problem.nlp.metadata, state_clamp_metadata)
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_before_structure_audit",
    )
    structure_audit = audit_reduced_mpcc_nlp_structure(problem)
    merge!(problem.metadata, structure_audit.metadata)
    merge!(problem.nlp.metadata, structure_audit.metadata)
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "smoke_problem_build_done",
    )
    return problem
end

"""
    solve_reduced_dcdfba_mpcc_smoke(model, reaction_map; kwargs...)

Build and run a guarded reduced MPCC smoke solve with Ipopt/MUMPS. By default
`ipopt_max_iter = 0`, so the function verifies solver entry and model
evaluation without attempting a production MPCC solve.
"""
function solve_reduced_dcdfba_mpcc_smoke(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    tspan::Tuple{<:Real, <:Real} = (0.0, 0.25),
    nfe::Int = 1,
    degree::Int = 3,
    element_bounds::Union{Nothing, AbstractVector{<:Tuple{<:Real, <:Real}}} = nothing,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    include_rhs::Bool = false,
    use_dynamic_bounds::Bool = false,
    dynamic_bounds_mode::Symbol = reduced_dcdfba_dynamic_bounds_mode_from_env(),
    dynamic_phase_smoothing_width::Real = reduced_dcdfba_phase_smoothing_width_from_env(),
    dynamic_phase_proxy_mode::Union{Symbol, AbstractString} =
        reduced_dcdfba_phase_proxy_mode_from_env(),
    dynamic_control_schedule = nothing,
    dynamic_control_decision_spec = nothing,
    dynamic_control_reference_regularization_weight::Real =
        reduced_mpcc_dynamic_control_reference_regularization_weight_from_env(),
    dynamic_control_objective_config::ReducedDCDFBADynamicControlObjectiveConfig =
        reduced_mpcc_dynamic_control_objective_config_from_env(),
    sequential_initialization::Union{Nothing, SimulationResult} = nothing,
    objective_coefficients::Union{Nothing, AbstractVector{<:Real}} = nothing,
    collocation_consistent_state_starts::Bool = false,
    state_nonnegative_bounds::Bool = reduced_dcdfba_state_nonnegative_bounds_from_env(),
    state_nonnegative_start_clamp::Bool =
        reduced_dcdfba_state_nonnegative_start_clamp_from_env(),
    optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} = 0,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_EXACT,
    complementarity_tau::Real = REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU,
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    silent::Bool = true,
)::ReducedDCDFBAMPCCSmokeResult
    problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        tspan = tspan,
        nfe = nfe,
        degree = degree,
        element_bounds = element_bounds,
        params = params,
        include_rhs = include_rhs,
        use_dynamic_bounds = use_dynamic_bounds,
        dynamic_bounds_mode = dynamic_bounds_mode,
        dynamic_phase_smoothing_width = dynamic_phase_smoothing_width,
        dynamic_phase_proxy_mode = dynamic_phase_proxy_mode,
        dynamic_control_schedule = dynamic_control_schedule,
        dynamic_control_decision_spec = dynamic_control_decision_spec,
        dynamic_control_reference_regularization_weight =
            dynamic_control_reference_regularization_weight,
        dynamic_control_objective_config = dynamic_control_objective_config,
        sequential_initialization = sequential_initialization,
        objective_coefficients = objective_coefficients,
        collocation_consistent_state_starts = collocation_consistent_state_starts,
        state_nonnegative_bounds = state_nonnegative_bounds,
        state_nonnegative_start_clamp = state_nonnegative_start_clamp,
        optimizer = optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        complementarity_tau_gate_tol = complementarity_tau_gate_tol,
        silent = silent,
    )

    solve_elapsed_seconds = @elapsed JuMP.optimize!(problem.nlp.jump_model)
    result = _reduced_dcdfba_mpcc_smoke_result(problem, solve_elapsed_seconds)
    merge!(problem.nlp.metadata, result.metadata)
    return result
end

function _reduced_dcdfba_mpcc_smoke_initial_state(
    initial_state,
    sequential_initialization::Union{Nothing, SimulationResult},
)::Tuple{Vector{Float64}, Dict{String, Any}}
    resolved, source = if initial_state === nothing
        if sequential_initialization === nothing
            (
                zenteno_state_to_vector(default_zenteno_initial_state()),
                "default_zenteno_initial_state",
            )
        else
            (
                Float64.(sequential_initialization.states[:, 1]),
                "sequential_initialization_first_saved_state",
            )
        end
    else
        (Float64.(collect(initial_state)), "provided_initial_state")
    end
    _validate_reduced_dcdfba_initial_state(resolved)

    matches_sequential = missing
    if sequential_initialization !== nothing
        sequential_initial = Float64.(sequential_initialization.states[:, 1])
        length(sequential_initial) == length(resolved) || throw(
            ArgumentError(
                "Reduced MPCC sequential initialization first state dimension does not " *
                "match initial_state dimension.",
            ),
        )
        matches_sequential = all(
            isapprox(resolved[i], sequential_initial[i]; atol = 1.0e-8, rtol = 1.0e-8)
            for i in eachindex(resolved)
        )
        matches_sequential || throw(
            ArgumentError(
                "Reduced MPCC initial_state must match the first saved state of " *
                "sequential_initialization when both are provided.",
            ),
        )
    end

    return (
        resolved,
        Dict{String, Any}(
            "mpcc_initial_state_source" => source,
            "mpcc_initial_state_matches_sequential_initialization" => matches_sequential,
            "mpcc_initial_state_first_biomass" => resolved[1],
            "mpcc_initial_state_first_total_sugar" => resolved[3] + resolved[4],
        ),
    )
end

"""
    default_reduced_dcdfba_mpcc_residual_thresholds(; kwargs...)

Return diagnostic residual thresholds for guarded reduced MPCC solve attempts.
The defaults are intentionally strict numerical gates and are not a scientific
trajectory-validation criterion.
"""
function default_reduced_dcdfba_mpcc_residual_thresholds(;
    max_rhs_residual::Real = 1.0e-6,
    max_mass_balance_residual::Real = 1.0e-6,
    max_lower_bound_violation::Real = 1.0e-6,
    max_upper_bound_violation::Real = 1.0e-6,
    max_stationarity_residual::Real = 1.0e-5,
    max_lower_complementarity_residual::Real = 1.0e-5,
    max_upper_complementarity_residual::Real = 1.0e-5,
)::ReducedDCDFBAMPCCResidualThresholds
    thresholds = ReducedDCDFBAMPCCResidualThresholds(
        Float64(max_rhs_residual),
        Float64(max_mass_balance_residual),
        Float64(max_lower_bound_violation),
        Float64(max_upper_bound_violation),
        Float64(max_stationarity_residual),
        Float64(max_lower_complementarity_residual),
        Float64(max_upper_complementarity_residual),
    )
    _validate_reduced_dcdfba_mpcc_residual_thresholds(thresholds)
    return thresholds
end

"""
    build_reduced_dcdfba_mpcc_solve_attempt_problem(model, reaction_map; sequential_initialization, kwargs...)

Build the first guarded dynamic reduced MPCC solve-attempt problem. This always
includes the smooth RHS residual scaffold, dynamic bound/objective
rows, and optionally sequential initialization starts. It does not call Ipopt.
"""
function build_reduced_dcdfba_mpcc_solve_attempt_problem(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    sequential_initialization::Union{Nothing, SimulationResult},
    tspan::Tuple{<:Real, <:Real} = (0.0, 0.25),
    nfe::Int = 1,
    degree::Int = 3,
    element_bounds::Union{Nothing, AbstractVector{<:Tuple{<:Real, <:Real}}} = nothing,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    dynamic_control_schedule = nothing,
    dynamic_control_decision_spec = nothing,
    dynamic_control_reference_regularization_weight::Real =
        reduced_mpcc_dynamic_control_reference_regularization_weight_from_env(),
    dynamic_control_objective_config::ReducedDCDFBADynamicControlObjectiveConfig =
        reduced_mpcc_dynamic_control_objective_config_from_env(),
    collocation_consistent_state_start_max_iterations::Int = 4,
    collocation_consistent_state_start_tolerance::Real = 1.0e-10,
    collocation_consistent_state_start_element_indices = nothing,
    bound_dual_complementarity_clip::Bool = false,
    bound_dual_complementarity_clip_element_indices = collocation_consistent_state_start_element_indices,
    bound_dual_complementarity_clip_budget_fraction::Real =
        _reduced_dcdfba_fixed_flux_dual_fit_complementarity_budget_fraction(),
    apply_default_start_initializers::Bool = true,
    state_nonnegative_bounds::Bool = reduced_dcdfba_state_nonnegative_bounds_from_env(),
    state_nonnegative_start_clamp::Bool =
        reduced_dcdfba_state_nonnegative_start_clamp_from_env(),
    silent::Bool = true,
)::ReducedDCDFBAMPCCSolveAttemptProblem
    trace_start_time = time()
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "solve_attempt_problem_build_start",
    )
    _validate_reduced_dcdfba_mpcc_residual_thresholds(residual_thresholds)
    resolved_ipopt_profile = reduced_mpcc_ipopt_profile(ipopt_profile)
    resolved_linear_solver = _canonical_ipopt_linear_solver(linear_solver)
    resolved_complementarity_mode =
        _reduced_dcdfba_mpcc_complementarity_mode(complementarity_mode)
    resolved_complementarity_tau =
        _reduced_dcdfba_mpcc_validate_complementarity_tau(complementarity_tau)
    resolved_complementarity_tau_gate_tol =
        _reduced_dcdfba_mpcc_validate_complementarity_tau_gate_tol(
            complementarity_tau_gate_tol,
        )
    optimizer_metadata = _reduced_dcdfba_mpcc_solve_attempt_optimizer_metadata(
        optimizer,
        ipopt_max_iter,
        resolved_ipopt_profile,
        resolved_linear_solver,
    )
    resolved_optimizer = _reduced_dcdfba_mpcc_solve_attempt_optimizer(
        optimizer,
        ipopt_max_iter,
        resolved_ipopt_profile,
        resolved_linear_solver,
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "solve_attempt_problem_before_smoke_problem",
    )
    smoke_problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        tspan = tspan,
        nfe = nfe,
        degree = degree,
        element_bounds = element_bounds,
        params = params,
        include_rhs = true,
        use_dynamic_bounds = true,
        dynamic_control_schedule = dynamic_control_schedule,
        dynamic_control_decision_spec = dynamic_control_decision_spec,
        dynamic_control_reference_regularization_weight =
            dynamic_control_reference_regularization_weight,
        dynamic_control_objective_config = dynamic_control_objective_config,
        sequential_initialization = sequential_initialization,
        collocation_consistent_state_starts = true,
        collocation_consistent_state_start_max_iterations =
            collocation_consistent_state_start_max_iterations,
        collocation_consistent_state_start_tolerance =
            collocation_consistent_state_start_tolerance,
        collocation_consistent_state_start_element_indices =
            collocation_consistent_state_start_element_indices,
        optimizer = resolved_optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = resolved_linear_solver,
        complementarity_mode = resolved_complementarity_mode,
        complementarity_tau = resolved_complementarity_tau,
        complementarity_tau_gate_tol = resolved_complementarity_tau_gate_tol,
        apply_default_start_initializers = apply_default_start_initializers,
        state_nonnegative_bounds = state_nonnegative_bounds,
        state_nonnegative_start_clamp = state_nonnegative_start_clamp,
        silent = silent,
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "solve_attempt_problem_after_smoke_problem",
    )
    bound_dual_clip_metadata = Dict{String, Any}(
        "bound_dual_complementarity_clip_enabled" => bound_dual_complementarity_clip,
        "bound_dual_complementarity_clip_elements" =>
            bound_dual_complementarity_clip_element_indices === nothing ?
            "all" :
            copy(collect(bound_dual_complementarity_clip_element_indices)),
    )
    if bound_dual_complementarity_clip
        merge!(
            bound_dual_clip_metadata,
            _reduced_dcdfba_clip_bound_dual_starts_for_complementarity!(
                smoke_problem;
                element_indices = bound_dual_complementarity_clip_element_indices,
                complementarity_tau = resolved_complementarity_tau,
                complementarity_budget_fraction = bound_dual_complementarity_clip_budget_fraction,
            ),
        )
    else
        bound_dual_clip_metadata["bound_dual_complementarity_clip_applied"] = false
        bound_dual_clip_metadata["bound_dual_complementarity_clip_policy"] = "disabled"
        bound_dual_clip_metadata["bound_dual_complementarity_clip_complementarity_budget_fraction"] =
            Float64(bound_dual_complementarity_clip_budget_fraction)
    end
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "solve_attempt_problem_after_bound_dual_clip",
    )
    merge!(smoke_problem.metadata, bound_dual_clip_metadata)
    merge!(smoke_problem.nlp.metadata, bound_dual_clip_metadata)
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "solve_attempt_problem_before_metadata",
    )
    metadata = _reduced_dcdfba_mpcc_solve_attempt_problem_metadata(
        smoke_problem,
        residual_thresholds,
        ipopt_max_iter,
        resolved_linear_solver,
        resolved_complementarity_mode,
        resolved_complementarity_tau,
    )
    _reduced_dcdfba_mpcc_copy_initial_state_metadata!(metadata, smoke_problem.metadata)
    _merge_reduced_dcdfba_metadata_prefix!(metadata, smoke_problem.metadata, "base_flux_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, smoke_problem.metadata, "fixed_flux_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, smoke_problem.metadata, "flux_variable_")
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        smoke_problem.metadata,
        "nlp_structure_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        smoke_problem.nlp.metadata,
        "base_objective_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        smoke_problem.metadata,
        "dynamic_control_reference_regularization_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        smoke_problem.metadata,
        "dynamic_control_objective_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        smoke_problem.metadata,
        "bound_dual_complementarity_clip_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        smoke_problem.metadata,
        "state_nonnegative_",
    )
    merge!(metadata, optimizer_metadata)
    merge!(smoke_problem.metadata, metadata)
    merge!(smoke_problem.nlp.metadata, metadata)
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "solve_attempt_problem_build_done",
    )
    return ReducedDCDFBAMPCCSolveAttemptProblem(smoke_problem, residual_thresholds, metadata)
end

function _reduced_dcdfba_mpcc_copy_initial_state_metadata!(
    target::Dict{String, Any},
    source::Dict{String, Any},
)
    for key in (
        "mpcc_initial_state_source",
        "mpcc_initial_state_matches_sequential_initialization",
        "mpcc_initial_state_first_biomass",
        "mpcc_initial_state_first_total_sugar",
    )
        haskey(source, key) && (target[key] = source[key])
    end
    return target
end

"""
    solve_reduced_dcdfba_mpcc_solve_attempt(model, reaction_map; sequential_initialization, kwargs...)

Build and run a guarded reduced MPCC solve attempt with Ipopt/MUMPS. The
function first checks pre-solve residual and scaling readiness, then records
post-solve residual diagnostics. It is a diagnostic entry point for the reduced
model only; it does not claim a valid simultaneous DFBA trajectory.
"""
function solve_reduced_dcdfba_mpcc_solve_attempt(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    sequential_initialization::Union{Nothing, SimulationResult},
    tspan::Tuple{<:Real, <:Real} = (0.0, 0.25),
    nfe::Int = 1,
    degree::Int = 3,
    element_bounds::Union{Nothing, AbstractVector{<:Tuple{<:Real, <:Real}}} = nothing,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    dynamic_control_schedule = nothing,
    dynamic_control_decision_spec = nothing,
    dynamic_control_reference_regularization_weight::Real =
        reduced_mpcc_dynamic_control_reference_regularization_weight_from_env(),
    dynamic_control_objective_config::ReducedDCDFBADynamicControlObjectiveConfig =
        reduced_mpcc_dynamic_control_objective_config_from_env(),
    collocation_consistent_state_start_max_iterations::Int = 4,
    collocation_consistent_state_start_tolerance::Real = 1.0e-10,
    collocation_consistent_state_start_element_indices = nothing,
    bound_dual_complementarity_clip::Bool = false,
    bound_dual_complementarity_clip_element_indices = collocation_consistent_state_start_element_indices,
    bound_dual_complementarity_clip_budget_fraction::Real =
        _reduced_dcdfba_fixed_flux_dual_fit_complementarity_budget_fraction(),
    apply_default_start_initializers::Bool = true,
    candidate_start_seed::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics} =
        nothing,
    flux_dual_start_seed::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics} =
        nothing,
    state_nonnegative_bounds::Bool = reduced_dcdfba_state_nonnegative_bounds_from_env(),
    state_nonnegative_start_clamp::Bool =
        reduced_dcdfba_state_nonnegative_start_clamp_from_env(),
    require_pre_solve_ready::Bool = true,
    pre_solve_only::Bool = false,
    silent::Bool = true,
)::ReducedDCDFBAMPCCSolveAttemptResult
    trace_start_time = time()
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "before_build_solve_attempt_problem",
    )
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = sequential_initialization,
        tspan = tspan,
        nfe = nfe,
        degree = degree,
        element_bounds = element_bounds,
        params = params,
        residual_thresholds = residual_thresholds,
        optimizer = optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        complementarity_tau_gate_tol = complementarity_tau_gate_tol,
        dynamic_control_schedule = dynamic_control_schedule,
        dynamic_control_decision_spec = dynamic_control_decision_spec,
        dynamic_control_reference_regularization_weight =
            dynamic_control_reference_regularization_weight,
        dynamic_control_objective_config = dynamic_control_objective_config,
        collocation_consistent_state_start_max_iterations =
            collocation_consistent_state_start_max_iterations,
        collocation_consistent_state_start_tolerance =
            collocation_consistent_state_start_tolerance,
        collocation_consistent_state_start_element_indices =
            collocation_consistent_state_start_element_indices,
        bound_dual_complementarity_clip = bound_dual_complementarity_clip,
        bound_dual_complementarity_clip_element_indices =
            bound_dual_complementarity_clip_element_indices,
        bound_dual_complementarity_clip_budget_fraction =
            bound_dual_complementarity_clip_budget_fraction,
        apply_default_start_initializers = apply_default_start_initializers,
        state_nonnegative_bounds = state_nonnegative_bounds,
        state_nonnegative_start_clamp = state_nonnegative_start_clamp,
        silent = silent,
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "after_build_solve_attempt_problem",
    )
    return _solve_reduced_dcdfba_mpcc_solve_attempt_problem(
        problem;
        require_pre_solve_ready = require_pre_solve_ready,
        pre_solve_only = pre_solve_only,
        candidate_start_seed = candidate_start_seed,
        flux_dual_start_seed = flux_dual_start_seed,
    )
end

function _solve_reduced_dcdfba_mpcc_solve_attempt_problem(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem;
    require_pre_solve_ready::Bool = true,
    return_pre_solve_blocked_result::Bool = false,
    pre_solve_only::Bool = false,
    candidate_start_seed::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics} =
        nothing,
    flux_dual_start_seed::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics} =
        nothing,
    candidate_selection_policy::Symbol = :safe,
)::ReducedDCDFBAMPCCSolveAttemptResult
    trace_start_time = time()
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "start",
    )
    candidate_start_seed !== nothing && flux_dual_start_seed !== nothing && throw(
        ArgumentError(
            "Reduced DC-dFBA MPCC solve attempt accepts either candidate_start_seed " *
            "or flux_dual_start_seed, not both.",
        ),
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "before_candidate_start_seed",
    )
    candidate_start_metadata =
        _reduced_dcdfba_mpcc_apply_candidate_start_seed_if_available!(
            problem,
            candidate_start_seed,
        )
    merge!(problem.metadata, candidate_start_metadata)
    merge!(problem.smoke_problem.metadata, candidate_start_metadata)
    merge!(problem.smoke_problem.nlp.metadata, candidate_start_metadata)
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "after_candidate_start_seed",
    )

    repair_after_candidate_start = _reduced_dcdfba_env_bool(
        REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_ENV,
        false,
    )
    repair_after_candidate_start_metadata = Dict{String, Any}(
        "collocation_consistent_state_start_repair_after_candidate_seed_enabled" =>
            repair_after_candidate_start,
        "collocation_consistent_state_start_repair_after_candidate_seed_applied" =>
            false,
        "collocation_consistent_state_start_repair_after_candidate_seed_policy" =>
            repair_after_candidate_start ?
            "enabled_waiting_for_candidate_seed" :
            "disabled_by_env",
        "collocation_consistent_state_start_repair_after_candidate_seed_env" =>
            REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_ENV,
    )
    if repair_after_candidate_start && candidate_start_seed !== nothing
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "before_repair_after_candidate_start",
        )
        raw_default_max_iterations =
            get(problem.metadata, "collocation_consistent_state_start_max_iterations", 2)
        default_max_iterations =
            raw_default_max_iterations isa Integer ?
            Int(raw_default_max_iterations) :
            Int(round(Float64(raw_default_max_iterations)))
        max_iterations = _reduced_dcdfba_env_nonnegative_int(
            REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_MAX_ITER_ENV,
            max(0, default_max_iterations),
        )
        raw_default_tolerance =
            get(problem.metadata, "collocation_consistent_state_start_tolerance", 1.0e-10)
        default_tolerance = Float64(raw_default_tolerance)
        tolerance_override = _reduced_dcdfba_env_optional_positive_float(
            REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_TOL_ENV,
        )
        tolerance =
            tolerance_override === nothing ? default_tolerance : Float64(tolerance_override)
        raw_elements = strip(
            get(
                ENV,
                REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_ELEMENTS_ENV,
                "",
            ),
        )
        element_indices = isempty(raw_elements) ? nothing :
                          _reduced_dcdfba_parse_env_contiguous_element_indices(
            problem.smoke_problem.nlp.dimensions.nfe,
            raw_elements,
            REDUCED_DCDFBA_MPCC_REPAIR_AFTER_CANDIDATE_START_ELEMENTS_ENV,
        )
        repair_metadata = _reduced_dcdfba_apply_collocation_consistent_state_starts!(
            problem.smoke_problem;
            max_iterations = max_iterations,
            tolerance = tolerance,
            element_indices = element_indices,
        )
        repair_metadata[
            "collocation_consistent_state_start_repair_after_candidate_seed_enabled"
        ] = true
        repair_metadata[
            "collocation_consistent_state_start_repair_after_candidate_seed_applied"
        ] = true
        repair_metadata[
            "collocation_consistent_state_start_repair_after_candidate_seed_policy"
        ] = "repair_starts_after_full_candidate_seed_before_pre_solve_diagnostics"
        repair_metadata[
            "collocation_consistent_state_start_repair_after_candidate_seed_max_iterations"
        ] = max_iterations
        repair_metadata[
            "collocation_consistent_state_start_repair_after_candidate_seed_tolerance"
        ] = tolerance
        repair_metadata[
            "collocation_consistent_state_start_repair_after_candidate_seed_elements"
        ] = isempty(raw_elements) ? "all" : raw_elements
        merge!(problem.metadata, repair_metadata)
        merge!(problem.smoke_problem.metadata, repair_metadata)
        merge!(problem.smoke_problem.nlp.metadata, repair_metadata)
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "after_repair_after_candidate_start",
        )
    else
        if repair_after_candidate_start
            repair_after_candidate_start_metadata[
                "collocation_consistent_state_start_repair_after_candidate_seed_policy"
            ] = "enabled_but_no_candidate_seed"
        end
        merge!(problem.metadata, repair_after_candidate_start_metadata)
        merge!(problem.smoke_problem.metadata, repair_after_candidate_start_metadata)
        merge!(problem.smoke_problem.nlp.metadata, repair_after_candidate_start_metadata)
    end

    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "before_dynamic_control_objective_slack_start_refresh",
    )
    objective_slack_start_refresh_metadata =
        _reduced_dcdfba_refresh_dynamic_control_objective_slack_starts!(
            problem.smoke_problem,
        )
    merge!(problem.metadata, objective_slack_start_refresh_metadata)
    merge!(problem.smoke_problem.metadata, objective_slack_start_refresh_metadata)
    merge!(problem.smoke_problem.nlp.metadata, objective_slack_start_refresh_metadata)
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "after_dynamic_control_objective_slack_start_refresh",
    )

    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "before_pre_solve_diagnostics",
    )
    pre_solve_report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "after_pre_solve_diagnostics",
    )
    pre_solve_metadata = _reduced_dcdfba_mpcc_solve_attempt_pre_solve_metadata(
        pre_solve_report,
        require_pre_solve_ready,
    )
    merge!(problem.metadata, pre_solve_metadata)
    merge!(problem.smoke_problem.metadata, pre_solve_metadata)
    merge!(problem.smoke_problem.nlp.metadata, pre_solve_metadata)
    if Bool(pre_solve_metadata["guarded_solve_attempt_blocked"])
        if return_pre_solve_blocked_result
            return _reduced_dcdfba_mpcc_pre_solve_blocked_solve_attempt_result(
                problem,
                pre_solve_report,
                pre_solve_metadata,
            )
        end
        throw(
            ArgumentError(
                "Reduced DC-dFBA MPCC solve attempt blocked by pre-solve diagnostics. " *
                "Set require_pre_solve_ready = false to run a diagnostic solver call anyway.",
            ),
        )
    end

    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "before_flux_dual_start_seed",
    )
    seed_metadata = _reduced_dcdfba_mpcc_apply_flux_dual_start_seed_if_available!(
        problem,
        flux_dual_start_seed,
    )
    merge!(problem.metadata, seed_metadata)
    merge!(problem.smoke_problem.metadata, seed_metadata)
    merge!(problem.smoke_problem.nlp.metadata, seed_metadata)
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "after_flux_dual_start_seed",
    )

    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "before_pre_solve_candidate_values",
    )
    pre_solve_candidate_values =
        _reduced_dcdfba_mpcc_pre_solve_candidate_value_arrays_or_nothing(
            problem.smoke_problem,
        )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "after_pre_solve_candidate_values",
    )
    if pre_solve_only
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "before_pre_solve_only_result",
        )
        result = _reduced_dcdfba_mpcc_pre_solve_only_solve_attempt_result(
            problem,
            pre_solve_report,
            pre_solve_metadata,
            pre_solve_candidate_values,
        )
        _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
            trace_start_time,
            "after_pre_solve_only_result",
        )
        return result
    end
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "before_optimize",
    )
    solve_elapsed_seconds = @elapsed JuMP.optimize!(problem.smoke_problem.nlp.jump_model)
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "after_optimize",
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "before_post_solve_diagnostics",
    )
    smoke_result = _reduced_dcdfba_mpcc_smoke_result(problem.smoke_problem, solve_elapsed_seconds)
    residual_report = _reduced_dcdfba_mpcc_solve_attempt_residual_report(
        problem.smoke_problem,
        smoke_result,
        problem.residual_thresholds,
    )
    post_solve_metadata = _reduced_dcdfba_mpcc_solve_attempt_post_solve_metadata(
        smoke_result,
        residual_report,
    )
    post_solve_candidate_diagnostics = _reduced_dcdfba_mpcc_candidate_diagnostics_or_nothing(
        problem,
        smoke_result,
    )
    pre_solve_candidate_diagnostics =
        _reduced_dcdfba_mpcc_pre_solve_candidate_diagnostics_or_nothing(
            problem,
            smoke_result,
            pre_solve_candidate_values,
        )
    candidate_selection = _reduced_dcdfba_mpcc_select_solve_attempt_candidate(
        pre_solve_candidate_diagnostics,
        post_solve_candidate_diagnostics,
        selection_policy = candidate_selection_policy,
    )
    _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
        trace_start_time,
        "after_post_solve_diagnostics",
    )
    candidate_diagnostics = candidate_selection.candidate
    if candidate_diagnostics !== nothing
        merge!(candidate_diagnostics.metadata, candidate_selection.metadata)
    end
    complementarity_location_metadata =
        _reduced_dcdfba_mpcc_complementarity_location_metadata(
            reduced_dcdfba_mpcc_complementarity_location_rows(
                problem.smoke_problem,
                candidate_diagnostics,
            ),
        )
    bound_violation_location_metadata =
        _reduced_dcdfba_mpcc_bound_violation_location_metadata(
            reduced_dcdfba_mpcc_bound_violation_location_rows(
                problem.smoke_problem,
                candidate_diagnostics,
            ),
        )
    rhs_residual_location_metadata =
        _reduced_dcdfba_mpcc_rhs_residual_location_metadata(
            reduced_dcdfba_mpcc_rhs_residual_location_rows(
                problem.smoke_problem,
                candidate_diagnostics,
            ),
        )
    metadata = copy(problem.metadata)
    merge!(metadata, smoke_result.metadata)
    merge!(metadata, residual_report)
    merge!(metadata, post_solve_metadata)
    merge!(metadata, _reduced_dcdfba_mpcc_candidate_metadata(candidate_diagnostics))
    merge!(metadata, candidate_selection.metadata)
    merge!(metadata, complementarity_location_metadata)
    merge!(metadata, bound_violation_location_metadata)
    merge!(metadata, rhs_residual_location_metadata)
    metadata["problem_type"] = "reduced_dcdfba_mpcc_solve_attempt"
    metadata["problem_scope"] = "guarded_reduced_dynamic_mpcc_solve_attempt"
    metadata["solver_call_performed"] = true
    metadata["solve_attempt_is_scientific_simulation"] = false
    metadata["smoke_result_is_scientific_simulation"] = false

    merge!(problem.smoke_problem.metadata, metadata)
    merge!(problem.smoke_problem.nlp.metadata, metadata)

    residuals_available = Bool(residual_report["residuals_available"])
    residual_thresholds_satisfied = Bool(residual_report["residual_thresholds_satisfied"])
    return ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        problem.residual_thresholds,
        residuals_available,
        residual_thresholds_satisfied,
        residual_report,
        metadata,
        candidate_diagnostics,
    )
end

function _reduced_dcdfba_mpcc_solve_attempt_trace_phase!(
    start_time::Real,
    phase::AbstractString,
)
    _reduced_dcdfba_env_bool("MPCC_REDUCED_MPCC_SOLVE_ATTEMPT_TRACE_PHASES", false) ||
        return nothing
    elapsed = round(time() - Float64(start_time); digits = 3)
    println("reduced_mpcc_solve_attempt_phase: $(String(phase)) elapsed_seconds=$elapsed")
    flush(stdout)
    return nothing
end

function _reduced_dcdfba_mpcc_pre_solve_blocked_solve_attempt_result(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    pre_solve_report::ReducedDCDFBAMPCCDiagnosticReport,
    pre_solve_metadata::Dict{String, Any},
)::ReducedDCDFBAMPCCSolveAttemptResult
    residuals = copy(pre_solve_report.residual_values)
    thresholds = copy(pre_solve_report.residual_thresholds)
    ratios = copy(pre_solve_report.residual_ratios)
    within = Dict{String, Bool}(
        key => isfinite(get(residuals, key, NaN)) &&
               get(residuals, key, NaN) <= get(thresholds, key, NaN)
        for key in keys(thresholds)
    )
    tau_status = _reduced_dcdfba_mpcc_complementarity_tau_status(
        problem.smoke_problem,
        get(residuals, "max_lower_complementarity_residual", NaN),
        get(residuals, "max_upper_complementarity_residual", NaN),
    )
    residual_report = Dict{String, Any}(
        "residuals_available" => pre_solve_report.residuals_available,
        "residual_thresholds_satisfied" =>
            pre_solve_report.residual_thresholds_satisfied,
        "residual_threshold_report" => within,
        "residual_ratios" => ratios,
        "ranked_residuals" => copy(pre_solve_report.ranked_residuals),
        "dominant_residual" => pre_solve_report.dominant_residual,
        "max_lower_complementarity_product" =>
            get(residuals, "max_lower_complementarity_residual", NaN),
        "max_upper_complementarity_product" =>
            get(residuals, "max_upper_complementarity_residual", NaN),
        "max_complementarity_tau_violation" =>
            tau_status.max_complementarity_tau_violation,
        "max_complementarity_tau_violation_raw" =>
            tau_status.max_complementarity_tau_violation_raw,
        "complementarity_tau_gate_tolerance" =>
            tau_status.complementarity_tau_gate_tolerance,
        "complementarity_tau_gate_tolerance_source" =>
            tau_status.complementarity_tau_gate_tolerance_source,
        "complementarity_tau_gate_pass" => tau_status.complementarity_tau_gate_pass,
        "complementarity_mode" =>
            get(problem.metadata, "complementarity_mode", "exact"),
        "complementarity_tau" =>
            get(problem.metadata, "complementarity_tau", missing),
        "complementarity_residual_gate_policy" =>
            _reduced_dcdfba_mpcc_complementarity_residual_gate_policy(problem.metadata),
        "residual_thresholds_are_scientific_acceptance_criteria" => false,
    )
    for key in keys(residuals)
        residual_report[key] = residuals[key]
        residual_report["$(key)_threshold"] = get(thresholds, key, NaN)
        residual_report["$(key)_ratio"] = get(ratios, key, NaN)
        residual_report["$(key)_within_threshold"] = get(within, key, false)
    end

    jump_model = problem.smoke_problem.nlp.jump_model
    solver_name = _reduced_dcdfba_solver_name(jump_model)
    metadata = copy(problem.metadata)
    merge!(metadata, pre_solve_metadata)
    metadata["solver_call_performed"] = false
    metadata["solver_status"] = string(MOI.OPTIMIZE_NOT_CALLED)
    metadata["primal_status"] = string(MOI.NO_SOLUTION)
    metadata["solver_result_count"] = 0
    metadata["solver_name"] = solver_name
    metadata["solver_reported_solve_time_seconds"] = missing
    metadata["solve_elapsed_seconds"] = 0.0
    metadata["solve_attempt_blocked_by_pre_solve_guard"] = true
    metadata["solve_attempt_is_scientific_simulation"] = false
    metadata["smoke_result_is_scientific_simulation"] = false
    metadata["max_mass_balance_residual"] =
        get(residuals, "max_mass_balance_residual", NaN)
    metadata["max_lower_bound_violation"] =
        get(residuals, "max_lower_bound_violation", NaN)
    metadata["max_upper_bound_violation"] =
        get(residuals, "max_upper_bound_violation", NaN)
    metadata["max_stationarity_residual"] =
        get(residuals, "max_stationarity_residual", NaN)
    metadata["max_lower_complementarity_residual"] =
        get(residuals, "max_lower_complementarity_residual", NaN)
    metadata["max_upper_complementarity_residual"] =
        get(residuals, "max_upper_complementarity_residual", NaN)
    metadata["max_lower_complementarity_product"] =
        get(residuals, "max_lower_complementarity_residual", NaN)
    metadata["max_upper_complementarity_product"] =
        get(residuals, "max_upper_complementarity_residual", NaN)
    metadata["max_complementarity_tau_violation"] =
        tau_status.max_complementarity_tau_violation
    metadata["max_complementarity_tau_violation_raw"] =
        tau_status.max_complementarity_tau_violation_raw
    metadata["complementarity_tau_gate_tolerance"] =
        tau_status.complementarity_tau_gate_tolerance
    metadata["complementarity_tau_gate_tolerance_source"] =
        tau_status.complementarity_tau_gate_tolerance_source
    metadata["complementarity_tau_gate_pass"] = tau_status.complementarity_tau_gate_pass

    smoke_result = ReducedDCDFBAMPCCSmokeResult(
        MOI.OPTIMIZE_NOT_CALLED,
        MOI.NO_SOLUTION,
        NaN,
        get(residuals, "max_mass_balance_residual", NaN),
        get(residuals, "max_lower_bound_violation", NaN),
        get(residuals, "max_upper_bound_violation", NaN),
        get(residuals, "max_stationarity_residual", NaN),
        get(residuals, "max_lower_complementarity_residual", NaN),
        get(residuals, "max_upper_complementarity_residual", NaN),
        solver_name,
        0.0,
        metadata,
    )
    merge!(
        metadata,
        residual_report,
        _reduced_dcdfba_mpcc_solve_attempt_post_solve_metadata(
            smoke_result,
            residual_report,
        ),
        _reduced_dcdfba_mpcc_candidate_metadata(nothing),
    )
    metadata["problem_type"] = "reduced_dcdfba_mpcc_solve_attempt"
    metadata["problem_scope"] = "guarded_reduced_dynamic_mpcc_solve_attempt"
    metadata["solver_call_performed"] = false
    metadata["solve_attempt_blocked_by_pre_solve_guard"] = true

    merge!(problem.metadata, metadata)
    merge!(problem.smoke_problem.metadata, metadata)
    merge!(problem.smoke_problem.nlp.metadata, metadata)

    return ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        problem.residual_thresholds,
        Bool(residual_report["residuals_available"]),
        Bool(residual_report["residual_thresholds_satisfied"]),
        residual_report,
        metadata,
        nothing,
    )
end

function _reduced_dcdfba_mpcc_pre_solve_only_solve_attempt_result(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    pre_solve_report::ReducedDCDFBAMPCCDiagnosticReport,
    pre_solve_metadata::Dict{String, Any},
    pre_solve_candidate_values,
)::ReducedDCDFBAMPCCSolveAttemptResult
    result = _reduced_dcdfba_mpcc_pre_solve_blocked_solve_attempt_result(
        problem,
        pre_solve_report,
        pre_solve_metadata,
    )
    pre_solve_candidate_diagnostics =
        _reduced_dcdfba_mpcc_pre_solve_candidate_diagnostics_or_nothing(
            problem,
            result.smoke_result,
            pre_solve_candidate_values,
        )
    candidate_selection = _reduced_dcdfba_mpcc_select_solve_attempt_candidate(
        pre_solve_candidate_diagnostics,
        nothing,
    )
    candidate_diagnostics = candidate_selection.candidate
    if candidate_diagnostics !== nothing
        merge!(candidate_diagnostics.metadata, candidate_selection.metadata)
    end

    complementarity_location_metadata =
        _reduced_dcdfba_mpcc_complementarity_location_metadata(
            reduced_dcdfba_mpcc_complementarity_location_rows(
                problem.smoke_problem,
                candidate_diagnostics,
            ),
        )
    bound_violation_location_metadata =
        _reduced_dcdfba_mpcc_bound_violation_location_metadata(
            reduced_dcdfba_mpcc_bound_violation_location_rows(
                problem.smoke_problem,
                candidate_diagnostics,
            ),
        )
    rhs_residual_location_metadata =
        _reduced_dcdfba_mpcc_rhs_residual_location_metadata(
            reduced_dcdfba_mpcc_rhs_residual_location_rows(
                problem.smoke_problem,
                candidate_diagnostics,
            ),
        )

    metadata = result.metadata
    merge!(
        metadata,
        _reduced_dcdfba_mpcc_candidate_metadata(candidate_diagnostics),
        candidate_selection.metadata,
        complementarity_location_metadata,
        bound_violation_location_metadata,
        rhs_residual_location_metadata,
    )
    metadata["solver_call_performed"] = false
    metadata["solve_attempt_pre_solve_only"] = true
    metadata["solve_attempt_pre_solve_only_reason"] =
        "MPCC_FIXED_CONTROL_PRE_SOLVE_ONLY"
    metadata["solve_attempt_blocked_by_pre_solve_guard"] = false
    metadata["solver_status"] = string(MOI.OPTIMIZE_NOT_CALLED)
    metadata["primal_status"] = string(MOI.NO_SOLUTION)
    metadata["problem_type"] = "reduced_dcdfba_mpcc_solve_attempt"
    metadata["problem_scope"] = "guarded_reduced_dynamic_mpcc_solve_attempt"

    merge!(problem.metadata, metadata)
    merge!(problem.smoke_problem.metadata, metadata)
    merge!(problem.smoke_problem.nlp.metadata, metadata)
    merge!(result.smoke_result.metadata, metadata)

    return ReducedDCDFBAMPCCSolveAttemptResult(
        result.smoke_result,
        result.residual_thresholds,
        result.residuals_available,
        result.residual_thresholds_satisfied,
        result.residual_report,
        metadata,
        candidate_diagnostics,
    )
end

"""
    solve_reduced_dcdfba_mpcc_tau_continuation(model, reaction_map; sequential_initialization, tau_schedule, kwargs...)

Run a sequential Scholtes relaxation over the same reduced MPCC window. Each
stage rebuilds the problem with the current `complementarity_tau`; once a stage
produces finite candidate arrays, those arrays seed the next stage. The final
result is diagnostic and keeps the same acceptance gates as a normal solve
attempt.
"""
function solve_reduced_dcdfba_mpcc_tau_continuation(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    sequential_initialization::Union{Nothing, SimulationResult},
    tspan::Tuple{<:Real, <:Real} = (0.0, 0.25),
    nfe::Int = 1,
    degree::Int = 3,
    element_bounds::Union{Nothing, AbstractVector{<:Tuple{<:Real, <:Real}}} = nothing,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    tau_schedule = reduced_mpcc_tau_schedule_from_env(),
    tau_stage_max_iters = reduced_mpcc_tau_stage_max_iters_from_env(),
    tau_final_retry_max_iter = reduced_mpcc_tau_final_retry_max_iter_from_env(),
    allow_coarse_tau_fallback::Bool = false,
    dynamic_control_schedule = nothing,
    dynamic_control_decision_spec = nothing,
    dynamic_control_reference_regularization_weight::Real =
        reduced_mpcc_dynamic_control_reference_regularization_weight_from_env(),
    dynamic_control_objective_config::ReducedDCDFBADynamicControlObjectiveConfig =
        reduced_mpcc_dynamic_control_objective_config_from_env(),
    collocation_consistent_state_start_max_iterations::Int = 4,
    collocation_consistent_state_start_tolerance::Real = 1.0e-10,
    collocation_consistent_state_start_element_indices = nothing,
    bound_dual_complementarity_clip::Bool = false,
    bound_dual_complementarity_clip_element_indices =
        collocation_consistent_state_start_element_indices,
    bound_dual_complementarity_clip_budget_fraction::Real =
        _reduced_dcdfba_fixed_flux_dual_fit_complementarity_budget_fraction(),
    apply_default_start_initializers::Bool = true,
    candidate_start_seed::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics} =
        nothing,
    flux_dual_start_seed::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics} =
        nothing,
    state_nonnegative_bounds::Bool = reduced_dcdfba_state_nonnegative_bounds_from_env(),
    state_nonnegative_start_clamp::Bool =
        reduced_dcdfba_state_nonnegative_start_clamp_from_env(),
    require_pre_solve_ready::Bool = true,
    pre_solve_only::Bool = false,
    silent::Bool = true,
    tau_stage_callback = nothing,
)::ReducedDCDFBAMPCCTauContinuationResult
    candidate_start_seed !== nothing && flux_dual_start_seed !== nothing && throw(
        ArgumentError(
            "Reduced DC-dFBA MPCC tau continuation accepts either candidate_start_seed " *
            "or flux_dual_start_seed, not both.",
        ),
    )
    schedule = _reduced_dcdfba_mpcc_validate_tau_schedule(tau_schedule)
    resolved_mode = _reduced_dcdfba_mpcc_complementarity_mode(complementarity_mode)
    resolved_linear_solver = _canonical_ipopt_linear_solver(linear_solver)
    resolved_complementarity_tau_gate_tol =
        _reduced_dcdfba_mpcc_validate_complementarity_tau_gate_tol(
            complementarity_tau_gate_tol,
        )
    stage_max_iters = _reduced_dcdfba_mpcc_resolve_tau_stage_max_iters(
        tau_stage_max_iters,
        length(schedule),
        ipopt_max_iter,
    )
    final_retry_max_iter =
        tau_final_retry_max_iter === nothing || tau_final_retry_max_iter === missing ?
        nothing : Int(tau_final_retry_max_iter)
    if final_retry_max_iter !== nothing
        final_retry_max_iter >= 0 || throw(
            ArgumentError("Reduced MPCC final tau retry max-iter value must be nonnegative."),
        )
    end
    stage_results = ReducedDCDFBAMPCCSolveAttemptResult[]
    rows = Vector{Dict{String, Any}}()
    previous_candidate = nothing

    for (stage_index, tau) in enumerate(schedule)
        candidate_before_stage = previous_candidate
        stage_ipopt_max_iter = stage_max_iters[stage_index]
        _reduced_dcdfba_mpcc_maybe_tau_stage_callback(
            tau_stage_callback,
            Dict{String, Any}(
                "event" => "stage_start",
                "stage_index" => stage_index,
                "stage_count" => length(schedule),
                "tau" => tau,
                "stage_ipopt_max_iter" => stage_ipopt_max_iter,
                "final_retry_performed" => false,
            ),
        )
        problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
            model,
            reaction_map;
            sequential_initialization = sequential_initialization,
            tspan = tspan,
            nfe = nfe,
            degree = degree,
            element_bounds = element_bounds,
            params = params,
            residual_thresholds = residual_thresholds,
            optimizer = optimizer,
            ipopt_max_iter = stage_ipopt_max_iter,
            linear_solver = resolved_linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = resolved_mode,
            complementarity_tau = tau,
            complementarity_tau_gate_tol = resolved_complementarity_tau_gate_tol,
            dynamic_control_schedule = dynamic_control_schedule,
            dynamic_control_decision_spec = dynamic_control_decision_spec,
            dynamic_control_reference_regularization_weight =
                dynamic_control_reference_regularization_weight,
            dynamic_control_objective_config = dynamic_control_objective_config,
            collocation_consistent_state_start_max_iterations =
                collocation_consistent_state_start_max_iterations,
            collocation_consistent_state_start_tolerance =
                collocation_consistent_state_start_tolerance,
            collocation_consistent_state_start_element_indices =
                collocation_consistent_state_start_element_indices,
            bound_dual_complementarity_clip = bound_dual_complementarity_clip,
            bound_dual_complementarity_clip_element_indices =
                bound_dual_complementarity_clip_element_indices,
            bound_dual_complementarity_clip_budget_fraction =
                bound_dual_complementarity_clip_budget_fraction,
            apply_default_start_initializers = apply_default_start_initializers,
            state_nonnegative_bounds = state_nonnegative_bounds,
            state_nonnegative_start_clamp = state_nonnegative_start_clamp,
            silent = silent,
        )
        if previous_candidate !== nothing
            _apply_reduced_dcdfba_mpcc_candidate_starts!(problem, previous_candidate)
        else
            _merge_reduced_dcdfba_mpcc_tau_stage_metadata!(
                problem,
                Dict{String, Any}(
                    "tau_continuation_warm_start_from_previous_stage" => false,
                    "tau_continuation_warm_start_stage_index" => missing,
                ),
            )
        end
        stage_metadata = Dict{String, Any}(
            "tau_continuation_performed" => true,
            "tau_continuation_stage_index" => stage_index,
            "tau_continuation_stage_count_requested" => length(schedule),
            "tau_continuation_tau" => tau,
            "tau_schedule" => copy(schedule),
            "tau_stage_max_iters" => copy(stage_max_iters),
            "tau_stage_max_iters_env" => REDUCED_DCDFBA_MPCC_TAU_STAGE_MAX_ITERS_ENV,
            "tau_continuation_stage_ipopt_max_iter" => stage_ipopt_max_iter,
        )
        _merge_reduced_dcdfba_mpcc_tau_stage_metadata!(problem, stage_metadata)

        result = _solve_reduced_dcdfba_mpcc_solve_attempt_problem(
            problem;
            require_pre_solve_ready = require_pre_solve_ready &&
                                      previous_candidate === nothing,
            return_pre_solve_blocked_result = true,
            pre_solve_only = pre_solve_only,
            candidate_start_seed =
                previous_candidate === nothing ? candidate_start_seed : nothing,
            flux_dual_start_seed =
                previous_candidate === nothing && candidate_start_seed === nothing ?
                flux_dual_start_seed : nothing,
            candidate_selection_policy = :prefer_post_solve_if_available,
        )
        merge!(result.metadata, stage_metadata)
        advancement_metadata = _reduced_dcdfba_mpcc_tau_stage_advancement_metadata(
            result,
            stage_index,
            length(schedule),
        )
        recovery_continue_enabled = _reduced_dcdfba_env_bool(
            REDUCED_DCDFBA_MPCC_TAU_STAGE_RECOVERY_CONTINUE_ENV,
            false,
        )
        recovery_continue =
            recovery_continue_enabled &&
            get(advancement_metadata, "tau_continuation_stage_advance_allowed", false) !== true &&
            get(advancement_metadata, "tau_continuation_stage_is_final", false) !== true &&
            (
                result.candidate_diagnostics !== nothing ||
                candidate_before_stage !== nothing
            )
        recovery_candidate =
            result.candidate_diagnostics !== nothing ?
            result.candidate_diagnostics :
            candidate_before_stage
        if recovery_continue
            merge!(
                advancement_metadata,
                Dict{String, Any}(
                    "tau_continuation_stage_recovery_continue_enabled" =>
                        recovery_continue_enabled,
                    "tau_continuation_stage_recovery_continue_allowed" => true,
                    "tau_continuation_stage_recovery_continue_reason" =>
                        result.candidate_diagnostics !== nothing ?
                        "reuse_current_failed_stage_candidate" :
                        "reuse_previous_candidate_after_stage_failure",
                    "tau_continuation_stage_recovery_start_stage_index" =>
                        get(
                            recovery_candidate.metadata,
                            "tau_continuation_stage_index",
                            missing,
                        ),
                    "tau_continuation_stage_recovery_start_tau" =>
                        get(
                            recovery_candidate.metadata,
                            "complementarity_tau",
                            missing,
                        ),
                ),
            )
        else
            merge!(
                advancement_metadata,
                Dict{String, Any}(
                    "tau_continuation_stage_recovery_continue_enabled" =>
                        recovery_continue_enabled,
                    "tau_continuation_stage_recovery_continue_allowed" => false,
                    "tau_continuation_stage_recovery_continue_reason" => "not_needed",
                    "tau_continuation_stage_recovery_start_stage_index" => missing,
                    "tau_continuation_stage_recovery_start_tau" => missing,
                ),
            )
        end
        merge!(result.metadata, advancement_metadata)
        if result.candidate_diagnostics !== nothing
            merge!(result.candidate_diagnostics.metadata, stage_metadata)
            merge!(result.candidate_diagnostics.metadata, advancement_metadata)
        end
        push!(stage_results, result)
        row = _reduced_dcdfba_mpcc_tau_continuation_stage_row(result, stage_index, tau)
        row["stage_result_index"] = length(stage_results)
        push!(rows, row)
        _reduced_dcdfba_mpcc_maybe_tau_stage_callback(
            tau_stage_callback,
            _reduced_dcdfba_mpcc_tau_stage_progress_event(
                "stage_complete",
                row,
                stage_index,
                length(schedule),
                tau,
                stage_ipopt_max_iter,
            ),
        )

        final_retry_candidate =
            result.candidate_diagnostics !== nothing ?
            result.candidate_diagnostics :
            candidate_before_stage
        final_retry_candidate_source =
            result.candidate_diagnostics !== nothing ?
            "final_stage_candidate" :
            "pre_final_tau_candidate"
        final_retry_residual_feasible =
            get(result.metadata, "candidate_residual_feasible", false) === true
        final_retry_trajectory_ready =
            get(result.metadata, "candidate_trajectory_extraction_ready", false) === true
        final_retry_needs_residual_polish = !final_retry_residual_feasible
        final_retry_needs_status_polish =
            final_retry_residual_feasible && !final_retry_trajectory_ready
        final_retry_reason =
            final_retry_needs_residual_polish ? "final_stage_not_residual_feasible" :
            final_retry_needs_status_polish ? "final_stage_residual_feasible_status_polish" :
            "not_needed"
        final_retry_allowed =
            get(advancement_metadata, "tau_continuation_stage_is_final", false) === true &&
            final_retry_max_iter !== nothing &&
            stage_ipopt_max_iter !== nothing &&
            final_retry_max_iter > stage_ipopt_max_iter &&
            (final_retry_needs_residual_polish || final_retry_needs_status_polish) &&
            final_retry_candidate !== nothing
        if final_retry_allowed
            result.metadata["tau_continuation_final_retry_triggered"] = true
            result.metadata["tau_continuation_final_retry_trigger_reason"] =
                final_retry_reason
            _reduced_dcdfba_mpcc_maybe_tau_stage_callback(
                tau_stage_callback,
                Dict{String, Any}(
                    "event" => "final_retry_start",
                    "stage_index" => stage_index,
                    "stage_count" => length(schedule),
                    "tau" => tau,
                    "stage_ipopt_max_iter" => final_retry_max_iter,
                    "final_retry_performed" => true,
                    "final_retry_of_stage_index" => stage_index,
                    "final_retry_start_source" => final_retry_candidate_source,
                    "final_retry_trigger_reason" => final_retry_reason,
                ),
            )
            retry_problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
                model,
                reaction_map;
                sequential_initialization = sequential_initialization,
                tspan = tspan,
                nfe = nfe,
                degree = degree,
                element_bounds = element_bounds,
                params = params,
                residual_thresholds = residual_thresholds,
                optimizer = optimizer,
                ipopt_max_iter = final_retry_max_iter,
                linear_solver = resolved_linear_solver,
                ipopt_profile = ipopt_profile,
                complementarity_mode = resolved_mode,
                complementarity_tau = tau,
                complementarity_tau_gate_tol = resolved_complementarity_tau_gate_tol,
                dynamic_control_schedule = dynamic_control_schedule,
                dynamic_control_decision_spec = dynamic_control_decision_spec,
                dynamic_control_reference_regularization_weight =
                    dynamic_control_reference_regularization_weight,
                dynamic_control_objective_config = dynamic_control_objective_config,
                collocation_consistent_state_start_max_iterations =
                    collocation_consistent_state_start_max_iterations,
                collocation_consistent_state_start_tolerance =
                    collocation_consistent_state_start_tolerance,
                collocation_consistent_state_start_element_indices =
                    collocation_consistent_state_start_element_indices,
                bound_dual_complementarity_clip = bound_dual_complementarity_clip,
                bound_dual_complementarity_clip_element_indices =
                    bound_dual_complementarity_clip_element_indices,
                bound_dual_complementarity_clip_budget_fraction =
                    bound_dual_complementarity_clip_budget_fraction,
                apply_default_start_initializers = apply_default_start_initializers,
                state_nonnegative_bounds = state_nonnegative_bounds,
                state_nonnegative_start_clamp = state_nonnegative_start_clamp,
                silent = silent,
            )
            _apply_reduced_dcdfba_mpcc_candidate_starts!(
                retry_problem,
                final_retry_candidate,
            )
            retry_stage_metadata = copy(stage_metadata)
            merge!(
                retry_stage_metadata,
                Dict{String, Any}(
                    "tau_continuation_final_retry_performed" => true,
                    "tau_continuation_final_retry_of_stage_index" => stage_index,
                    "tau_continuation_final_retry_previous_max_iter" =>
                        stage_ipopt_max_iter,
                    "tau_continuation_stage_ipopt_max_iter" =>
                        final_retry_max_iter,
                    "tau_continuation_final_retry_max_iter" =>
                        final_retry_max_iter,
                    "tau_continuation_final_retry_max_iter_env" =>
                        REDUCED_DCDFBA_MPCC_TAU_FINAL_RETRY_MAX_ITER_ENV,
                    "tau_continuation_final_retry_start_source" =>
                        final_retry_candidate_source,
                    "tau_continuation_final_retry_trigger_reason" =>
                        final_retry_reason,
                ),
            )
            _merge_reduced_dcdfba_mpcc_tau_stage_metadata!(
                retry_problem,
                retry_stage_metadata,
            )
            retry_result = _solve_reduced_dcdfba_mpcc_solve_attempt_problem(
                retry_problem;
                require_pre_solve_ready = false,
                return_pre_solve_blocked_result = true,
                pre_solve_only = pre_solve_only,
                flux_dual_start_seed = nothing,
                candidate_selection_policy = :prefer_post_solve_if_available,
            )
            merge!(retry_result.metadata, retry_stage_metadata)
            retry_advancement_metadata =
                _reduced_dcdfba_mpcc_tau_stage_advancement_metadata(
                    retry_result,
                    stage_index,
                    length(schedule),
                )
            merge!(
                retry_advancement_metadata,
                Dict{String, Any}(
                    "tau_continuation_stage_recovery_continue_allowed" => false,
                    "tau_continuation_stage_recovery_continue_reason" => "not_needed",
                    "tau_continuation_stage_recovery_start_stage_index" => missing,
                    "tau_continuation_stage_recovery_start_tau" => missing,
                ),
            )
            merge!(retry_result.metadata, retry_advancement_metadata)
            if retry_result.candidate_diagnostics !== nothing
                merge!(retry_result.candidate_diagnostics.metadata, retry_stage_metadata)
                merge!(
                    retry_result.candidate_diagnostics.metadata,
                    retry_advancement_metadata,
                )
            end
            push!(stage_results, retry_result)
            retry_row =
                _reduced_dcdfba_mpcc_tau_continuation_stage_row(
                    retry_result,
                    stage_index,
                    tau,
                )
            retry_row["stage_result_index"] = length(stage_results)
            retry_row["final_retry_of_stage_index"] = stage_index
            push!(rows, retry_row)
            _reduced_dcdfba_mpcc_maybe_tau_stage_callback(
                tau_stage_callback,
                _reduced_dcdfba_mpcc_tau_stage_progress_event(
                    "final_retry_complete",
                    retry_row,
                    stage_index,
                    length(schedule),
                    tau,
                    final_retry_max_iter,
                ),
            )
        else
            result.metadata["tau_continuation_final_retry_triggered"] = false
        end

        if get(
            advancement_metadata,
            "tau_continuation_stage_advance_allowed",
            false,
        ) === true
            previous_candidate = result.candidate_diagnostics
        elseif recovery_continue
            previous_candidate = recovery_candidate
        elseif get(
            advancement_metadata,
            "tau_continuation_stage_is_final",
            false,
        ) !== true
            break
        else
            previous_candidate = result.candidate_diagnostics
        end
    end

    selection = _reduced_dcdfba_mpcc_select_tau_continuation_result(
        stage_results;
        allow_coarse_tau_fallback = allow_coarse_tau_fallback,
    )
    final_result = selection.result
    selected_stage_index = selection.stage_index
    for row in rows
        row["stage_selected_for_return"] =
            selected_stage_index !== missing &&
            get(row, "stage_result_index", row["stage_index"]) == selected_stage_index
    end
    stage_table = DataFrame(rows)
    metadata = _reduced_dcdfba_mpcc_tau_continuation_metadata(
        schedule,
        stage_results,
        stage_table,
        final_result,
        resolved_mode,
        resolved_linear_solver,
        ipopt_profile,
        selection,
        stage_max_iters,
        allow_coarse_tau_fallback,
    )
    if final_result !== nothing
        merge!(final_result.metadata, metadata)
        _reduced_dcdfba_mpcc_apply_coarse_tau_fallback_metadata!(
            final_result,
            metadata,
        )
        final_result.smoke_result.metadata["tau_continuation_stage_count"] =
            metadata["tau_continuation_stage_count"]
        final_result.smoke_result.metadata["tau_schedule"] = metadata["tau_schedule"]
    end
    return ReducedDCDFBAMPCCTauContinuationResult(
        stage_table,
        stage_results,
        final_result,
        metadata,
    )
end

function _apply_reduced_dcdfba_mpcc_candidate_starts!(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)
    nlp = problem.smoke_problem.nlp
    _reduced_dcdfba_mpcc_set_start_values!(
        nlp.state_boundary,
        candidate.state_boundary,
        "state_boundary",
    )
    _reduced_dcdfba_mpcc_set_start_values!(
        nlp.state_collocation,
        candidate.state_collocation,
        "state_collocation",
    )
    _reduced_dcdfba_mpcc_set_start_values!(
        nlp.state_derivative,
        candidate.state_derivative,
        "state_derivative",
    )
    _reduced_dcdfba_mpcc_set_start_values!(nlp.flux, candidate.flux, "flux")
    _reduced_dcdfba_mpcc_set_start_values!(
        problem.smoke_problem.bound_feasibility.lower_bound_duals,
        candidate.lower_bound_duals,
        "lower_bound_duals",
    )
    _reduced_dcdfba_mpcc_set_start_values!(
        problem.smoke_problem.bound_feasibility.upper_bound_duals,
        candidate.upper_bound_duals,
        "upper_bound_duals",
    )
    _reduced_dcdfba_mpcc_set_start_values!(
        problem.smoke_problem.stationarity.mass_balance_duals,
        candidate.mass_balance_duals,
        "mass_balance_duals",
    )
    metadata = Dict{String, Any}(
        "tau_continuation_warm_start_from_previous_stage" => true,
        "tau_continuation_warm_start_stage_index" =>
            get(candidate.metadata, "tau_continuation_stage_index", missing),
        "tau_continuation_warm_start_source" => "previous_tau_candidate_arrays",
        "tau_continuation_warm_start_candidate_residual_feasible" =>
            get(candidate.metadata, "candidate_residual_feasible", false),
    )
    _merge_reduced_dcdfba_mpcc_tau_stage_metadata!(problem, metadata)
    return nothing
end

function _reduced_dcdfba_mpcc_apply_candidate_start_seed_if_available!(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    seed::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
)::Dict{String, Any}
    seed === nothing && return Dict{String, Any}(
        "full_candidate_start_seed_applied" => false,
        "full_candidate_start_seed_policy" => "not_requested",
        "full_candidate_start_seed_source" => "none",
        "full_candidate_start_seed_applied_before_pre_solve" => false,
        "full_candidate_start_seed_dynamic_controls_applied" => false,
    )

    _apply_reduced_dcdfba_mpcc_candidate_starts!(problem, seed)
    apply_dynamic_controls = _reduced_dcdfba_env_bool(
        REDUCED_DCDFBA_MPCC_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS_ENV,
        true,
    )
    dynamic_control_metadata = apply_dynamic_controls ?
        _reduced_dcdfba_mpcc_apply_candidate_dynamic_control_starts!(problem.smoke_problem, seed) :
        Dict{String, Any}(
            "full_candidate_start_seed_dynamic_controls_applied" => false,
            "full_candidate_start_seed_dynamic_controls_skip_reason" =>
                "disabled_by_env",
        )
    metadata = Dict{String, Any}(
        "full_candidate_start_seed_applied" => true,
        "full_candidate_start_seed_policy" =>
            "complete_candidate_arrays_before_pre_solve_diagnostics",
        "full_candidate_start_seed_source" => "serialized_candidate_diagnostics",
        "full_candidate_start_seed_applied_before_pre_solve" => true,
        "full_candidate_start_seed_apply_dynamic_controls" => apply_dynamic_controls,
        "full_candidate_start_seed_dynamic_controls_policy" =>
            apply_dynamic_controls ?
            "apply_from_candidate_metadata" :
            "use_problem_dynamic_control_starts",
        "full_candidate_start_seed_candidate_value_source" =>
            get(seed.metadata, "candidate_values_source", missing),
        "full_candidate_start_seed_selected_candidate_source" =>
            get(seed.metadata, "selected_candidate_source", missing),
        "full_candidate_start_seed_residual_feasible" =>
            get(seed.metadata, "candidate_residual_feasible", missing),
        "full_candidate_start_seed_trajectory_ready" =>
            get(seed.metadata, "candidate_trajectory_extraction_ready", missing),
        "full_candidate_start_seed_grid_nfe" =>
            get(seed.metadata, "candidate_grid_nfe", size(seed.state_collocation, 2)),
        "full_candidate_start_seed_collocation_degree" =>
            get(seed.metadata, "candidate_collocation_degree", size(seed.state_collocation, 3)),
    )
    merge!(metadata, dynamic_control_metadata)
    return metadata
end

function _reduced_dcdfba_mpcc_apply_candidate_dynamic_control_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Dict{String, Any}
    decisions = problem.dynamic_control_decisions
    decisions === nothing && return Dict{String, Any}(
        "full_candidate_start_seed_dynamic_controls_applied" => false,
        "full_candidate_start_seed_dynamic_controls_skip_reason" =>
            "target_problem_has_no_dynamic_control_decisions",
    )
    values = _reduced_dcdfba_mpcc_candidate_dynamic_control_values_from_metadata(candidate.metadata)
    values === nothing && return Dict{String, Any}(
        "full_candidate_start_seed_dynamic_controls_applied" => false,
        "full_candidate_start_seed_dynamic_controls_skip_reason" =>
            "candidate_has_no_captured_dynamic_control_values",
    )

    temperature_adjustment =
        _reduced_dcdfba_mpcc_set_candidate_dynamic_control_starts!(
            decisions.temperature_variables,
            values.temperature_C,
            "temperature_C",
        )
    fda_adjustment =
        _reduced_dcdfba_mpcc_set_candidate_dynamic_control_starts!(
            decisions.fda_variables,
            values.fda_g_L,
            "fda_g_L",
        )
    organic_adjustment =
        _reduced_dcdfba_mpcc_set_candidate_dynamic_control_starts!(
            decisions.organic_variables,
            values.organic_g_L,
            "organic_g_L",
        )
    return Dict{String, Any}(
        "full_candidate_start_seed_dynamic_controls_applied" => true,
        "full_candidate_start_seed_dynamic_controls_skip_reason" => "not_applicable",
        "full_candidate_start_seed_temperature_count" => length(values.temperature_C),
        "full_candidate_start_seed_fda_count" => length(values.fda_g_L),
        "full_candidate_start_seed_organic_count" => length(values.organic_g_L),
        "full_candidate_start_seed_temperature_max_bound_adjustment" =>
            temperature_adjustment,
        "full_candidate_start_seed_fda_max_bound_adjustment" => fda_adjustment,
        "full_candidate_start_seed_organic_max_bound_adjustment" => organic_adjustment,
    )
end

function _reduced_dcdfba_mpcc_set_candidate_dynamic_control_starts!(
    variables::AbstractVector{JuMP.VariableRef},
    values::AbstractVector{<:Real},
    label::AbstractString,
)::Float64
    length(variables) == length(values) || throw(
        ArgumentError(
            "Reduced MPCC candidate start dynamic-control $label length mismatch: " *
            "$(length(values)) values for $(length(variables)) variables.",
        ),
    )
    max_adjustment = 0.0
    for index in eachindex(values)
        raw = Float64(values[index])
        isfinite(raw) || throw(
            ArgumentError(
                "Reduced MPCC candidate start dynamic-control $label[$index] is not finite.",
            ),
        )
        variable = variables[index]
        lower = JuMP.has_lower_bound(variable) ? JuMP.lower_bound(variable) : -Inf
        upper = JuMP.has_upper_bound(variable) ? JuMP.upper_bound(variable) : Inf
        projected = clamp(raw, lower, upper)
        adjustment = abs(projected - raw)
        adjustment <= 1.0e-8 || throw(
            ArgumentError(
                "Reduced MPCC candidate start dynamic-control $label[$index]=$raw " *
                "is outside target bounds [$lower, $upper].",
            ),
        )
        max_adjustment = max(max_adjustment, adjustment)
        JuMP.set_start_value(variable, projected)
    end
    return Float64(max_adjustment)
end

function _reduced_dcdfba_mpcc_apply_flux_dual_start_seed_if_available!(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    seed::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
)::Dict{String, Any}
    seed === nothing && return Dict{String, Any}(
        "cross_window_flux_dual_start_applied" => false,
        "cross_window_flux_dual_start_policy" => "not_requested",
        "cross_window_flux_dual_start_source" => "none",
        "cross_window_flux_dual_start_applied_after_pre_solve" => false,
        "cross_window_flux_dual_start_rhs_derivatives_refreshed" => false,
    )
    return _apply_reduced_dcdfba_mpcc_flux_dual_start_seed!(problem, seed)
end

function _reduced_dcdfba_mpcc_flux_dual_start_mode_from_env()::Symbol
    raw = lowercase(strip(get(ENV, REDUCED_DCDFBA_MPCC_FLUX_DUAL_START_MODE_ENV, "none")))
    raw in ("flux_duals", "flux_dual", "all", "full", "default") && return :flux_duals
    raw in ("duals", "duals_only", "dual_only") && return :duals_only
    raw in ("flux", "flux_only") && return :flux_only
    raw in ("none", "off", "disabled", "skip") && return :none
    throw(
        ArgumentError(
            "$REDUCED_DCDFBA_MPCC_FLUX_DUAL_START_MODE_ENV must be one of " *
            "flux_duals, duals_only, flux_only, none; got: $raw",
        ),
    )
end

function _apply_reduced_dcdfba_mpcc_flux_dual_start_seed!(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    seed::ReducedDCDFBAMPCCCandidateDiagnostics;
    refresh_rhs_derivative_starts::Bool = true,
)::Dict{String, Any}
    smoke_problem = problem.smoke_problem
    n_reactions = smoke_problem.nlp.dimensions.n_reactions
    n_metabolites = smoke_problem.nlp.kkt_problem.dimensions.n_metabolites
    nfe = smoke_problem.nlp.dimensions.nfe
    degree = smoke_problem.nlp.dimensions.collocation_degree
    _validate_reduced_dcdfba_mpcc_flux_dual_start_seed(seed, n_reactions, n_metabolites)

    source_element = size(seed.flux, 2)
    source_collocation = size(seed.flux, 3)
    source_flux = view(seed.flux, :, source_element, source_collocation)
    source_lower_duals = view(seed.lower_bound_duals, :, source_element, source_collocation)
    source_upper_duals = view(seed.upper_bound_duals, :, source_element, source_collocation)
    source_mass_duals =
        view(seed.mass_balance_duals, :, source_element, source_collocation)
    state_values = _reduced_dcdfba_start_array_or_nothing(smoke_problem.nlp.state_collocation)
    mode = _reduced_dcdfba_mpcc_flux_dual_start_mode_from_env()
    apply_flux = mode in (:flux_duals, :flux_only)
    apply_duals = mode in (:flux_duals, :duals_only)
    if mode == :none
        return Dict{String, Any}(
            "cross_window_flux_dual_start_applied" => false,
            "cross_window_flux_dual_start_policy" => "disabled_by_mode",
            "cross_window_flux_dual_start_mode" => String(mode),
            "cross_window_flux_dual_start_source" => "previous_window_candidate",
            "cross_window_flux_dual_start_source_element" => source_element,
            "cross_window_flux_dual_start_source_collocation" => source_collocation,
            "cross_window_flux_dual_start_applied_after_pre_solve" => true,
            "cross_window_flux_dual_start_flux_applied" => false,
            "cross_window_flux_dual_start_duals_applied" => false,
            "cross_window_flux_dual_start_rhs_derivatives_refreshed" => false,
        )
    end

    target_points = 0
    max_flux_projection_adjustment = 0.0
    max_lower_dual_sign_clipping = 0.0
    max_upper_dual_sign_clipping = 0.0
    max_abs_flux_start = 0.0
    max_abs_mass_dual_start = 0.0
    for e in 1:nfe, j in 1:degree
        target_points += 1
        bounds = state_values === nothing ?
                 (lb = smoke_problem.nlp.kkt_problem.model.lb, ub = smoke_problem.nlp.kkt_problem.model.ub) :
                 _reduced_dcdfba_numeric_flux_bounds(smoke_problem, e, j, state_values)
        for r in 1:n_reactions
            if apply_flux
                raw_flux = Float64(source_flux[r])
                projected_flux = clamp(raw_flux, bounds.lb[r], bounds.ub[r])
                max_flux_projection_adjustment =
                    max(max_flux_projection_adjustment, abs(projected_flux - raw_flux))
                max_abs_flux_start = max(max_abs_flux_start, abs(projected_flux))
                JuMP.set_start_value(smoke_problem.nlp.flux[r, e, j], projected_flux)
            end

            if apply_duals
                raw_lower_dual = Float64(source_lower_duals[r])
                raw_upper_dual = Float64(source_upper_duals[r])
                lower_dual = min(raw_lower_dual, 0.0)
                upper_dual = max(raw_upper_dual, 0.0)
                max_lower_dual_sign_clipping =
                    max(max_lower_dual_sign_clipping, abs(lower_dual - raw_lower_dual))
                max_upper_dual_sign_clipping =
                    max(max_upper_dual_sign_clipping, abs(upper_dual - raw_upper_dual))
                JuMP.set_start_value(
                    smoke_problem.bound_feasibility.lower_bound_duals[r, e, j],
                    lower_dual,
                )
                JuMP.set_start_value(
                    smoke_problem.bound_feasibility.upper_bound_duals[r, e, j],
                    upper_dual,
                )
            end
        end
        if apply_duals
            for m in 1:n_metabolites
                mass_dual = Float64(source_mass_duals[m])
                max_abs_mass_dual_start = max(max_abs_mass_dual_start, abs(mass_dual))
                JuMP.set_start_value(
                    smoke_problem.stationarity.mass_balance_duals[m, e, j],
                    mass_dual,
                )
            end
        end
    end

    derivative_metadata =
        apply_flux && refresh_rhs_derivative_starts && smoke_problem.rhs_residuals !== nothing ?
        _reduced_dcdfba_apply_rhs_consistent_derivative_starts!(smoke_problem) :
        Dict{String, Any}()
    metadata = Dict{String, Any}(
        "cross_window_flux_dual_start_applied" => true,
        "cross_window_flux_dual_start_mode" => String(mode),
        "cross_window_flux_dual_start_flux_applied" => apply_flux,
        "cross_window_flux_dual_start_duals_applied" => apply_duals,
        "cross_window_flux_dual_start_policy" =>
            apply_flux && apply_duals ?
            "previous_window_final_collocation_flux_duals_constant_over_target_window" :
            apply_flux ?
            "previous_window_final_collocation_flux_constant_over_target_window" :
            "previous_window_final_collocation_duals_constant_over_target_window",
        "cross_window_flux_dual_start_source" => "previous_window_candidate",
        "cross_window_flux_dual_start_source_stage_index" =>
            get(seed.metadata, "tau_continuation_stage_index", missing),
        "cross_window_flux_dual_start_source_tau" =>
            get(seed.metadata, "complementarity_tau", missing),
        "cross_window_flux_dual_start_source_solver_status" =>
            get(seed.metadata, "candidate_solver_status", missing),
        "cross_window_flux_dual_start_source_residual_feasible" =>
            get(seed.metadata, "candidate_residual_feasible", missing),
        "cross_window_flux_dual_start_source_element" => source_element,
        "cross_window_flux_dual_start_source_collocation" => source_collocation,
        "cross_window_flux_dual_start_target_collocation_points" => target_points,
        "cross_window_flux_dual_start_applied_after_pre_solve" => true,
        "cross_window_flux_dual_start_bounds_policy" =>
            state_values === nothing ? "base_bounds" : "target_dynamic_bounds",
        "cross_window_flux_dual_start_max_flux_projection_adjustment" =>
            max_flux_projection_adjustment,
        "cross_window_flux_dual_start_max_abs_flux" => max_abs_flux_start,
        "cross_window_flux_dual_start_max_lower_dual_sign_clipping" =>
            max_lower_dual_sign_clipping,
        "cross_window_flux_dual_start_max_upper_dual_sign_clipping" =>
            max_upper_dual_sign_clipping,
        "cross_window_flux_dual_start_max_abs_mass_balance_dual" =>
            max_abs_mass_dual_start,
        "cross_window_flux_dual_start_rhs_derivatives_refreshed" =>
            apply_flux && refresh_rhs_derivative_starts && smoke_problem.rhs_residuals !== nothing,
    )
    merge!(metadata, derivative_metadata)
    return metadata
end

function _validate_reduced_dcdfba_mpcc_flux_dual_start_seed(
    seed::ReducedDCDFBAMPCCCandidateDiagnostics,
    n_reactions::Int,
    n_metabolites::Int,
)
    size(seed.flux, 1) == n_reactions || throw(
        ArgumentError(
            "Reduced MPCC cross-window flux seed reaction count does not match target problem.",
        ),
    )
    size(seed.lower_bound_duals, 1) == n_reactions || throw(
        ArgumentError(
            "Reduced MPCC cross-window lower-dual seed reaction count does not match target problem.",
        ),
    )
    size(seed.upper_bound_duals, 1) == n_reactions || throw(
        ArgumentError(
            "Reduced MPCC cross-window upper-dual seed reaction count does not match target problem.",
        ),
    )
    size(seed.mass_balance_duals, 1) == n_metabolites || throw(
        ArgumentError(
            "Reduced MPCC cross-window mass-dual seed metabolite count does not match target problem.",
        ),
    )
    size(seed.flux, 2) > 0 && size(seed.flux, 3) > 0 || throw(
        ArgumentError("Reduced MPCC cross-window flux seed must contain collocation values."),
    )
    for (label, values) in (
        ("flux", seed.flux),
        ("lower_bound_duals", seed.lower_bound_duals),
        ("upper_bound_duals", seed.upper_bound_duals),
        ("mass_balance_duals", seed.mass_balance_duals),
    )
        all(isfinite, values) || throw(
            ArgumentError("Reduced MPCC cross-window $label seed values must be finite."),
        )
    end
    return nothing
end

function _reduced_dcdfba_mpcc_set_start_values!(
    variables,
    values,
    label::AbstractString,
)
    size(variables) == size(values) || throw(
        ArgumentError(
            "Reduced MPCC tau continuation cannot apply $label starts with mismatched shapes.",
        ),
    )
    for index in eachindex(values)
        value = Float64(values[index])
        isfinite(value) || throw(
            ArgumentError(
                "Reduced MPCC tau continuation cannot apply non-finite $label start values.",
            ),
        )
        JuMP.set_start_value(variables[index], value)
    end
    return nothing
end

function _merge_reduced_dcdfba_mpcc_tau_stage_metadata!(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    metadata::Dict{String, Any},
)
    merge!(problem.metadata, metadata)
    merge!(problem.smoke_problem.metadata, metadata)
    merge!(problem.smoke_problem.nlp.metadata, metadata)
    return problem
end

function _reduced_dcdfba_mpcc_tau_stage_advancement_metadata(
    result::ReducedDCDFBAMPCCSolveAttemptResult,
    stage_index::Int,
    n_schedule::Int,
)::Dict{String, Any}
    metadata = result.metadata
    is_final_stage = stage_index >= n_schedule
    candidate_available =
        result.candidate_diagnostics !== nothing ||
        get(metadata, "candidate_values_available", false) === true
    pre_solve_required = get(metadata, "pre_solve_guard_required", true) === true
    pre_solve_passed =
        !pre_solve_required || get(metadata, "pre_solve_guard_passed", true) === true
    residuals_available =
        result.residuals_available ||
        get(metadata, "residuals_available", false) === true ||
        get(metadata, "post_solve_residuals_available", false) === true
    primal_allows =
        get(metadata, "post_solve_primal_status_allows_residual_candidate", false) === true
    tau_gate_pass = get(metadata, "complementarity_tau_gate_pass", false) === true
    structural_ratio_limit = _reduced_dcdfba_env_nonnegative_float(
        REDUCED_DCDFBA_MPCC_TAU_STAGE_ADVANCE_MAX_STRUCTURAL_RATIO_ENV,
        100.0,
    )
    structural_ratio =
        _reduced_dcdfba_mpcc_tau_stage_structural_advance_ratio(metadata)
    structural_allows =
        isfinite(structural_ratio) && structural_ratio <= structural_ratio_limit
    complementarity_ratio_limit = _reduced_dcdfba_env_nonnegative_float(
        REDUCED_DCDFBA_MPCC_TAU_STAGE_ADVANCE_MAX_COMPLEMENTARITY_RATIO_ENV,
        1.25,
    )
    complementarity_ratio =
        _reduced_dcdfba_mpcc_tau_stage_complementarity_advance_ratio(
            metadata,
            get(metadata, "complementarity_tau", NaN),
        )
    complementarity_allows =
        isfinite(complementarity_ratio) &&
        complementarity_ratio <= complementarity_ratio_limit
    advance_allowed =
        !is_final_stage &&
        candidate_available &&
        pre_solve_passed &&
        residuals_available &&
        primal_allows &&
        tau_gate_pass &&
        structural_allows &&
        complementarity_allows

    reason =
        !pre_solve_passed ? "pre_solve_guard_failed" :
        !candidate_available ? "candidate_values_unavailable" :
        !residuals_available ? "post_solve_residuals_unavailable" :
        !primal_allows ? "primal_status_blocks_warm_start" :
        !tau_gate_pass ? "tau_gate_failed" :
        !structural_allows ? "structural_residual_ratio_exceeds_advance_limit" :
        !complementarity_allows ? "complementarity_ratio_exceeds_advance_limit" :
        is_final_stage ? "final_stage_no_advance_needed" :
        "finite_candidate_tau_gate_pass"

    return Dict{String, Any}(
        "tau_continuation_stage_is_final" => is_final_stage,
        "tau_continuation_stage_advance_allowed" => advance_allowed,
        "tau_continuation_stage_advance_reason" => reason,
        "tau_continuation_stage_candidate_available" => candidate_available,
        "tau_continuation_stage_pre_solve_required" => pre_solve_required,
        "tau_continuation_stage_pre_solve_passed" => pre_solve_passed,
        "tau_continuation_stage_residuals_available" => residuals_available,
        "tau_continuation_stage_primal_allows_warm_start" => primal_allows,
        "tau_continuation_stage_tau_gate_pass" => tau_gate_pass,
        "tau_continuation_stage_structural_advance_ratio" => structural_ratio,
        "tau_continuation_stage_structural_advance_ratio_limit" =>
            structural_ratio_limit,
        "tau_continuation_stage_structural_advance_ratio_env" =>
            REDUCED_DCDFBA_MPCC_TAU_STAGE_ADVANCE_MAX_STRUCTURAL_RATIO_ENV,
        "tau_continuation_stage_structural_advance_allowed" =>
            structural_allows,
        "tau_continuation_stage_complementarity_advance_ratio" =>
            complementarity_ratio,
        "tau_continuation_stage_complementarity_advance_ratio_limit" =>
            complementarity_ratio_limit,
        "tau_continuation_stage_complementarity_advance_ratio_env" =>
            REDUCED_DCDFBA_MPCC_TAU_STAGE_ADVANCE_MAX_COMPLEMENTARITY_RATIO_ENV,
        "tau_continuation_stage_complementarity_advance_allowed" =>
            complementarity_allows,
    )
end

function _reduced_dcdfba_mpcc_tau_stage_structural_advance_ratio(
    metadata::AbstractDict,
)::Float64
    structural_keys = (
        ("max_rhs_residual", 1.0e-6),
        ("max_collocation_integration_residual", 1.0e-6),
        ("max_continuity_residual", 1.0e-6),
        ("max_initial_condition_residual", 1.0e-6),
        ("max_mass_balance_residual", 1.0e-6),
        ("max_lower_bound_violation", 1.0e-6),
        ("max_upper_bound_violation", 1.0e-6),
        ("max_stationarity_residual", 1.0e-5),
    )
    max_ratio = 0.0
    found = false
    for (key, default_threshold) in structural_keys
        raw_value = get(metadata, key, missing)
        raw_value === missing && continue
        value = try
            Float64(raw_value)
        catch
            NaN
        end
        isfinite(value) || continue
        raw_threshold = get(metadata, "$(key)_threshold", default_threshold)
        threshold = try
            Float64(raw_threshold)
        catch
            NaN
        end
        isfinite(threshold) && threshold > 0.0 || continue
        max_ratio = max(max_ratio, abs(value) / threshold)
        found = true
    end
    return found ? max_ratio : Inf
end

function _reduced_dcdfba_mpcc_tau_stage_complementarity_advance_ratio(
    metadata::AbstractDict,
    tau_raw,
)::Float64
    tau = try
        Float64(tau_raw)
    catch
        NaN
    end
    isfinite(tau) && tau >= 0.0 || return Inf
    values = Float64[]
    for key in (
        "max_lower_complementarity_residual",
        "max_lower_complementarity_product",
        "max_upper_complementarity_residual",
        "max_upper_complementarity_product",
    )
        raw_value = get(metadata, key, missing)
        raw_value === missing && continue
        value = try
            Float64(raw_value)
        catch
            NaN
        end
        isfinite(value) || continue
        push!(values, abs(value))
    end
    isempty(values) && return Inf
    max_complementarity = maximum(values)
    if tau == 0.0
        return max_complementarity == 0.0 ? 0.0 : Inf
    end
    return max_complementarity / tau
end

function _reduced_dcdfba_mpcc_tau_continuation_stage_row(
    result::ReducedDCDFBAMPCCSolveAttemptResult,
    stage_index::Int,
    tau::Float64,
)::Dict{String, Any}
    metadata = result.metadata
    return Dict{String, Any}(
        "stage_index" => stage_index,
        "stage_result_index" => missing,
        "tau" => tau,
        "solver_status" => string(result.smoke_result.status),
        "primal_status" => string(result.smoke_result.primal_status),
        "residual_feasible" => get(metadata, "candidate_residual_feasible", false),
        "residual_thresholds_satisfied" => result.residual_thresholds_satisfied,
        "candidate_values_available" =>
            result.candidate_diagnostics !== nothing ||
            get(metadata, "candidate_values_available", false) === true,
        "candidate_selection_policy" =>
            get(metadata, "candidate_selection_policy", missing),
        "candidate_selection_policy_symbol" =>
            get(metadata, "candidate_selection_policy_symbol", missing),
        "candidate_selection_reason" =>
            get(metadata, "candidate_selection_reason", missing),
        "selected_candidate_source" =>
            get(metadata, "selected_candidate_source", missing),
        "selected_candidate_is_post_solve" =>
            get(metadata, "selected_candidate_is_post_solve", missing),
        "selected_candidate_is_pre_solve_start" =>
            get(metadata, "selected_candidate_is_pre_solve_start", missing),
        "solve_elapsed_seconds" => result.smoke_result.solve_elapsed_seconds,
        "linear_solver" => get(metadata, "linear_solver", missing),
        "ipopt_profile" => get(metadata, "ipopt_profile", missing),
        "complementarity_mode" => get(metadata, "complementarity_mode", missing),
        "complementarity_tau" => get(metadata, "complementarity_tau", tau),
        "stage_ipopt_max_iter" =>
            get(metadata, "tau_continuation_stage_ipopt_max_iter", missing),
        "max_rhs_residual" =>
            get(metadata, "max_rhs_residual", missing),
        "max_mass_balance_residual" =>
            get(metadata, "max_mass_balance_residual", missing),
        "max_stationarity_residual" =>
            get(metadata, "max_stationarity_residual", missing),
        "max_lower_bound_violation" =>
            get(metadata, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" =>
            get(metadata, "max_upper_bound_violation", missing),
        "max_lower_complementarity_residual" =>
            get(
                metadata,
                "max_lower_complementarity_residual",
                get(metadata, "max_lower_complementarity_product", missing),
            ),
        "max_upper_complementarity_residual" =>
            get(
                metadata,
                "max_upper_complementarity_residual",
                get(metadata, "max_upper_complementarity_product", missing),
            ),
        "max_lower_complementarity_product" =>
            get(metadata, "max_lower_complementarity_product", missing),
        "max_upper_complementarity_product" =>
            get(metadata, "max_upper_complementarity_product", missing),
        "max_complementarity_tau_violation" =>
            get(metadata, "max_complementarity_tau_violation", missing),
        "max_complementarity_tau_violation_raw" =>
            get(metadata, "max_complementarity_tau_violation_raw", missing),
        "complementarity_tau_gate_tolerance" =>
            get(metadata, "complementarity_tau_gate_tolerance", missing),
        "complementarity_tau_gate_tolerance_source" =>
            get(metadata, "complementarity_tau_gate_tolerance_source", missing),
        "complementarity_tau_gate_pass" =>
            get(metadata, "complementarity_tau_gate_pass", missing),
        "dominant_residual" =>
            get(metadata, "candidate_dominant_residual", missing),
        "warm_start_from_previous_stage" =>
            get(metadata, "tau_continuation_warm_start_from_previous_stage", false),
        "cross_window_flux_dual_start_applied" =>
            get(metadata, "cross_window_flux_dual_start_applied", false),
        "cross_window_flux_dual_start_policy" =>
            get(metadata, "cross_window_flux_dual_start_policy", missing),
        "cross_window_flux_dual_start_mode" =>
            get(metadata, "cross_window_flux_dual_start_mode", missing),
        "cross_window_flux_dual_start_flux_applied" =>
            get(metadata, "cross_window_flux_dual_start_flux_applied", false),
        "cross_window_flux_dual_start_duals_applied" =>
            get(metadata, "cross_window_flux_dual_start_duals_applied", false),
        "stage_is_final" =>
            get(metadata, "tau_continuation_stage_is_final", missing),
        "stage_advance_allowed" =>
            get(metadata, "tau_continuation_stage_advance_allowed", missing),
        "stage_advance_reason" =>
            get(metadata, "tau_continuation_stage_advance_reason", missing),
        "stage_recovery_continue_enabled" =>
            get(metadata, "tau_continuation_stage_recovery_continue_enabled", missing),
        "stage_recovery_continue_allowed" =>
            get(metadata, "tau_continuation_stage_recovery_continue_allowed", missing),
        "stage_recovery_continue_reason" =>
            get(metadata, "tau_continuation_stage_recovery_continue_reason", missing),
        "stage_structural_advance_ratio" =>
            get(metadata, "tau_continuation_stage_structural_advance_ratio", missing),
        "stage_structural_advance_ratio_limit" =>
            get(metadata, "tau_continuation_stage_structural_advance_ratio_limit", missing),
        "stage_structural_advance_allowed" =>
            get(metadata, "tau_continuation_stage_structural_advance_allowed", missing),
        "stage_complementarity_advance_ratio" =>
            get(metadata, "tau_continuation_stage_complementarity_advance_ratio", missing),
        "stage_complementarity_advance_ratio_limit" =>
            get(metadata, "tau_continuation_stage_complementarity_advance_ratio_limit", missing),
        "stage_complementarity_advance_allowed" =>
            get(metadata, "tau_continuation_stage_complementarity_advance_allowed", missing),
        "final_retry_performed" =>
            get(metadata, "tau_continuation_final_retry_performed", false),
        "final_retry_trigger_reason" =>
            get(metadata, "tau_continuation_final_retry_trigger_reason", missing),
        "final_retry_max_iter" =>
            get(metadata, "tau_continuation_final_retry_max_iter", missing),
        "final_retry_of_stage_index" =>
            get(metadata, "tau_continuation_final_retry_of_stage_index", missing),
        "stage_selected_for_return" => false,
    )
end

function _reduced_dcdfba_mpcc_tau_stage_progress_event(
    event::AbstractString,
    row::Dict{String, Any},
    stage_index::Int,
    stage_count::Int,
    tau::Real,
    stage_ipopt_max_iter,
)::Dict{String, Any}
    progress = copy(row)
    merge!(
        progress,
        Dict{String, Any}(
            "event" => String(event),
            "stage_index" => stage_index,
            "stage_count" => stage_count,
            "tau" => Float64(tau),
            "stage_ipopt_max_iter" => stage_ipopt_max_iter,
        ),
    )
    return progress
end

function _reduced_dcdfba_mpcc_maybe_tau_stage_callback(
    callback,
    event::Dict{String, Any},
)
    callback === nothing && return nothing
    callback(event)
    return nothing
end

function _reduced_dcdfba_mpcc_select_tau_continuation_result(
    stage_results::Vector{ReducedDCDFBAMPCCSolveAttemptResult},
    ;
    allow_coarse_tau_fallback::Bool = false,
)
    isempty(stage_results) && return (
        result = nothing,
        stage_index = missing,
        reason = "no_stage_results",
        selected_by_fallback = false,
        selected_by_coarse_tau_fallback = false,
    )

    selected_index = 0
    for (index, result) in enumerate(stage_results)
        metadata = result.metadata
        candidate_available =
            result.candidate_diagnostics !== nothing ||
            get(metadata, "candidate_values_available", false) === true
        residual_feasible =
            get(metadata, "candidate_residual_feasible", false) === true
        primal_allows =
            get(metadata, "post_solve_primal_status_allows_residual_candidate", false) === true ||
            get(metadata, "candidate_primal_status_allows_residual_candidate", false) === true
        if candidate_available && residual_feasible && primal_allows
            selected_index = index
        end
    end

    if selected_index == 0
        if allow_coarse_tau_fallback
            coarse_index = 0
            for (index, result) in enumerate(stage_results)
                if _reduced_dcdfba_mpcc_coarse_tau_fallback_candidate(result)
                    coarse_index = index
                end
            end
            if coarse_index != 0
                return (
                    result = stage_results[coarse_index],
                    stage_index = coarse_index,
                    reason = "selected_coarse_tau_stage_residual_feasible_fallback",
                    selected_by_fallback = coarse_index != length(stage_results),
                    selected_by_coarse_tau_fallback = true,
                )
            end
        end

        best_index = 0
        best_score = Inf
        for (index, result) in enumerate(stage_results)
            score = _reduced_dcdfba_mpcc_candidate_residual_score(result)
            if isfinite(score) && score < best_score
                best_index = index
                best_score = score
            end
        end
        if best_index != 0
            return (
                result = stage_results[best_index],
                stage_index = best_index,
                reason = "no_residual_feasible_stage_using_best_residual_candidate",
                selected_by_fallback = best_index != length(stage_results),
                selected_by_coarse_tau_fallback = false,
            )
        end
        return (
            result = last(stage_results),
            stage_index = length(stage_results),
            reason = "no_residual_feasible_stage_using_last_attempt",
            selected_by_fallback = false,
            selected_by_coarse_tau_fallback = false,
        )
    end

    return (
        result = stage_results[selected_index],
        stage_index = selected_index,
        reason =
            selected_index == length(stage_results) ?
            "selected_lowest_tau_residual_feasible_stage" :
            "selected_best_residual_feasible_stage_before_polish_failure",
        selected_by_fallback = selected_index != length(stage_results),
        selected_by_coarse_tau_fallback = false,
    )
end

function _reduced_dcdfba_mpcc_coarse_tau_fallback_candidate(
    result::ReducedDCDFBAMPCCSolveAttemptResult,
)::Bool
    metadata = result.metadata
    candidate_available =
        result.candidate_diagnostics !== nothing ||
        get(metadata, "candidate_values_available", false) === true
    candidate_available || return false
    primal_allows =
        get(metadata, "post_solve_primal_status_allows_residual_candidate", false) === true ||
        get(metadata, "candidate_primal_status_allows_residual_candidate", false) === true
    primal_allows || return false
    get(metadata, "complementarity_tau_gate_pass", false) === true || return false
    return _reduced_dcdfba_mpcc_noncomplementarity_residual_feasible(result)
end

function _reduced_dcdfba_mpcc_noncomplementarity_residual_feasible(
    result::ReducedDCDFBAMPCCSolveAttemptResult,
)::Bool
    metadata = result.metadata
    thresholds = result.residual_thresholds
    pairs = (
        ("max_rhs_residual", thresholds.max_rhs_residual),
        ("max_mass_balance_residual", thresholds.max_mass_balance_residual),
        ("max_lower_bound_violation", thresholds.max_lower_bound_violation),
        ("max_upper_bound_violation", thresholds.max_upper_bound_violation),
        ("max_stationarity_residual", thresholds.max_stationarity_residual),
    )
    for (key, threshold) in pairs
        ratio = _reduced_dcdfba_mpcc_residual_ratio(metadata, key, threshold)
        isfinite(ratio) && ratio <= 1.0 || return false
    end
    return true
end

function _reduced_dcdfba_mpcc_candidate_residual_score(
    result::ReducedDCDFBAMPCCSolveAttemptResult,
)::Float64
    metadata = result.metadata
    candidate_available =
        result.candidate_diagnostics !== nothing ||
        get(metadata, "candidate_values_available", false) === true
    candidate_available || return Inf
    thresholds = _reduced_dcdfba_mpcc_effective_threshold_values(
        result.metadata,
        result.residual_thresholds,
    )
    ratios = Float64[
        _reduced_dcdfba_mpcc_residual_ratio(
            metadata,
            "max_rhs_residual",
            thresholds["max_rhs_residual"],
        ),
        _reduced_dcdfba_mpcc_residual_ratio(
            metadata,
            "max_mass_balance_residual",
            thresholds["max_mass_balance_residual"],
        ),
        _reduced_dcdfba_mpcc_residual_ratio(
            metadata,
            "max_lower_bound_violation",
            thresholds["max_lower_bound_violation"],
        ),
        _reduced_dcdfba_mpcc_residual_ratio(
            metadata,
            "max_upper_bound_violation",
            thresholds["max_upper_bound_violation"],
        ),
        _reduced_dcdfba_mpcc_residual_ratio(
            metadata,
            "max_stationarity_residual",
            thresholds["max_stationarity_residual"],
        ),
        _reduced_dcdfba_mpcc_residual_ratio(
            metadata,
            "max_lower_complementarity_residual",
            thresholds["max_lower_complementarity_residual"],
        ),
        _reduced_dcdfba_mpcc_residual_ratio(
            metadata,
            "max_upper_complementarity_residual",
            thresholds["max_upper_complementarity_residual"],
        ),
    ]
    any(!isfinite, ratios) && return Inf
    return maximum(ratios)
end

function _reduced_dcdfba_mpcc_candidate_residual_score(
    candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
)::Float64
    candidate === nothing && return Inf
    ratios = collect(values(candidate.residual_ratios))
    isempty(ratios) && return Inf
    any(!isfinite, ratios) && return Inf
    return maximum(abs, ratios)
end

function _reduced_dcdfba_mpcc_residual_ratio(
    metadata::Dict{String, Any},
    key::AbstractString,
    threshold::Real,
)::Float64
    threshold_value = Float64(threshold)
    isfinite(threshold_value) && threshold_value > 0.0 || return Inf
    value = get(metadata, key, missing)
    value === missing && return Inf
    value === nothing && return Inf
    parsed = try
        Float64(value)
    catch
        return Inf
    end
    isfinite(parsed) || return Inf
    return abs(parsed) / threshold_value
end

function _reduced_dcdfba_mpcc_tau_continuation_metadata(
    schedule::Vector{Float64},
    stage_results::Vector{ReducedDCDFBAMPCCSolveAttemptResult},
    stage_table::DataFrame,
    final_result::Union{Nothing, ReducedDCDFBAMPCCSolveAttemptResult},
    complementarity_mode::Symbol,
    linear_solver::AbstractString,
    ipopt_profile::AbstractString,
    selection = _reduced_dcdfba_mpcc_select_tau_continuation_result(stage_results),
    stage_max_iters = nothing,
    allow_coarse_tau_fallback::Bool = false,
)::Dict{String, Any}
    completed_requested_stages = length(stage_results) >= length(schedule)
    attempted_final_result = isempty(stage_results) ? nothing : last(stage_results)
    attempted_final_stage_index =
        attempted_final_result === nothing ? missing :
        get(attempted_final_result.metadata, "tau_continuation_stage_index", length(stage_results))
    attempted_schedule_index = min(max(length(stage_results), 1), length(schedule))
    attempted_final_tau =
        attempted_final_result === nothing ? missing :
        get(attempted_final_result.metadata, "complementarity_tau", schedule[attempted_schedule_index])
    attempted_final_residual_feasible =
        attempted_final_result !== nothing &&
        get(attempted_final_result.metadata, "candidate_residual_feasible", false) === true
    attempted_final_tau_gate_pass =
        attempted_final_result !== nothing &&
        get(attempted_final_result.metadata, "complementarity_tau_gate_pass", false) === true
    selected_tau_gate_pass =
        final_result !== nothing &&
        get(final_result.metadata, "complementarity_tau_gate_pass", false) === true
    completed =
        completed_requested_stages &&
        attempted_final_residual_feasible &&
        attempted_final_tau_gate_pass
    blocking_stage =
        final_result === nothing ? missing :
        (completed ? missing : attempted_final_stage_index)
    stage_advance_count =
        count(
            result -> get(
                result.metadata,
                "tau_continuation_stage_advance_allowed",
                false,
            ) === true,
            stage_results,
        )
    selected_stage_index = selection.stage_index
    selected_by_fallback = selection.selected_by_fallback === true
    selected_by_coarse_tau_fallback =
        selection.selected_by_coarse_tau_fallback === true
    selected_residual_feasible =
        final_result !== nothing &&
        (
            get(final_result.metadata, "candidate_residual_feasible", false) === true ||
            selected_by_coarse_tau_fallback
        )
    polish_failed =
        selected_by_fallback &&
        !selected_by_coarse_tau_fallback &&
        attempted_final_result !== nothing &&
        selected_stage_index !== attempted_final_stage_index
    blocking_reason =
        final_result === nothing || completed ? missing :
        selected_by_coarse_tau_fallback ?
        "coarse_tau_stage_fallback_selected_after_final_stage_failure" :
        polish_failed ? "polish_stage_failed_selected_best_residual_feasible_stage" :
        get(attempted_final_result.metadata, "guarded_solve_attempt_blocked", false) === true ?
        get(
            attempted_final_result.metadata,
            "tau_continuation_stage_advance_reason",
            "pre_solve_guard_failed",
        ) :
        completed_requested_stages && !attempted_final_residual_feasible ?
        "final_residual_gate_failed" :
        completed_requested_stages && !attempted_final_tau_gate_pass ?
        "final_tau_gate_failed" :
        get(
            attempted_final_result.metadata,
            "tau_continuation_stage_advance_reason",
            missing,
        )
    final_tau = if final_result === nothing
        missing
    else
        metadata_tau = get(final_result.metadata, "complementarity_tau", missing)
        if metadata_tau !== missing
            metadata_tau
        else
            fallback_index =
                selected_stage_index === missing ? attempted_schedule_index :
                min(Int(selected_stage_index), length(schedule))
            schedule[fallback_index]
        end
    end
    total_elapsed = isempty(stage_results) ? 0.0 :
        sum(result.smoke_result.solve_elapsed_seconds for result in stage_results)
    max_tau_violation = isempty(stage_results) ? missing :
        maximum(
            Float64(
                get(result.metadata, "max_complementarity_tau_violation", NaN),
            ) for result in stage_results
        )
    cross_window_seed_applied = any(
        result -> get(result.metadata, "cross_window_flux_dual_start_applied", false) === true,
        stage_results,
    )
    return Dict{String, Any}(
        "tau_continuation_performed" => true,
        "tau_schedule" => copy(schedule),
        "tau_schedule_env" => REDUCED_DCDFBA_MPCC_TAU_SCHEDULE_ENV,
        "tau_stage_max_iters" => stage_max_iters === nothing ? missing : copy(stage_max_iters),
        "tau_stage_max_iters_env" => REDUCED_DCDFBA_MPCC_TAU_STAGE_MAX_ITERS_ENV,
        "tau_stage_max_iters_label" => _reduced_dcdfba_mpcc_tau_stage_max_iters_label(stage_max_iters),
        "tau_final_retry_max_iter_env" =>
            REDUCED_DCDFBA_MPCC_TAU_FINAL_RETRY_MAX_ITER_ENV,
        "tau_continuation_final_retry_performed" => any(
            result -> get(result.metadata, "tau_continuation_final_retry_performed", false) === true,
            stage_results,
        ),
        "tau_continuation_final_retry_count" => count(
            result -> get(result.metadata, "tau_continuation_final_retry_performed", false) === true,
            stage_results,
        ),
        "tau_continuation_stage_count" => length(stage_results),
        "tau_continuation_stage_count_requested" => length(schedule),
        "tau_continuation_allow_coarse_tau_fallback" => allow_coarse_tau_fallback,
        "tau_continuation_coarse_tau_fallback_applied" =>
            selected_by_coarse_tau_fallback,
        "tau_continuation_completed" => completed,
        "tau_continuation_final_residual_feasible" => selected_residual_feasible,
        "tau_continuation_final_tau_gate_pass" => selected_tau_gate_pass,
        "tau_continuation_attempted_final_stage_index" => attempted_final_stage_index,
        "tau_continuation_attempted_final_tau" => attempted_final_tau,
        "tau_continuation_attempted_final_residual_feasible" =>
            attempted_final_residual_feasible,
        "tau_continuation_attempted_final_tau_gate_pass" =>
            attempted_final_tau_gate_pass,
        "tau_continuation_selected_stage_index" => selected_stage_index,
        "tau_continuation_selected_tau" => final_tau,
        "tau_continuation_selected_residual_feasible" => selected_residual_feasible,
        "tau_continuation_selected_tau_gate_pass" => selected_tau_gate_pass,
        "tau_continuation_selected_reason" => selection.reason,
        "tau_continuation_selected_by_best_stage_fallback" => selected_by_fallback,
        "tau_continuation_selected_by_coarse_tau_fallback" =>
            selected_by_coarse_tau_fallback,
        "tau_continuation_polish_attempted" =>
            attempted_final_result !== nothing && selected_stage_index !== missing &&
            attempted_final_stage_index !== selected_stage_index,
        "tau_continuation_polish_failed" => polish_failed,
        "tau_continuation_blocking_stage" => blocking_stage,
        "tau_continuation_blocking_reason" => blocking_reason,
        "tau_continuation_stage_advance_count" => stage_advance_count,
        "tau_continuation_final_tau" => final_tau,
        "tau_continuation_final_tau_gate_tolerance" =>
            final_result === nothing ? missing :
            get(final_result.metadata, "complementarity_tau_gate_tolerance", missing),
        "tau_continuation_total_elapsed_seconds" => total_elapsed,
        "tau_continuation_max_tau_violation" => max_tau_violation,
        "tau_continuation_stage_table_rows" => nrow(stage_table),
        "cross_window_flux_dual_start_applied" => cross_window_seed_applied,
        "cross_window_flux_dual_start_policy" =>
            _reduced_dcdfba_mpcc_first_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_policy",
                cross_window_seed_applied ? missing : "not_requested",
            ),
        "cross_window_flux_dual_start_mode" =>
            _reduced_dcdfba_mpcc_first_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_mode",
                missing,
            ),
        "cross_window_flux_dual_start_flux_applied" => any(
            result -> get(
                result.metadata,
                "cross_window_flux_dual_start_flux_applied",
                false,
            ) === true,
            stage_results,
        ),
        "cross_window_flux_dual_start_duals_applied" => any(
            result -> get(
                result.metadata,
                "cross_window_flux_dual_start_duals_applied",
                false,
            ) === true,
            stage_results,
        ),
        "cross_window_flux_dual_start_source" =>
            _reduced_dcdfba_mpcc_first_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_source",
                cross_window_seed_applied ? missing : "none",
            ),
        "cross_window_flux_dual_start_source_stage_index" =>
            _reduced_dcdfba_mpcc_first_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_source_stage_index",
                missing,
            ),
        "cross_window_flux_dual_start_source_tau" =>
            _reduced_dcdfba_mpcc_first_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_source_tau",
                missing,
            ),
        "cross_window_flux_dual_start_source_solver_status" =>
            _reduced_dcdfba_mpcc_first_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_source_solver_status",
                missing,
            ),
        "cross_window_flux_dual_start_source_residual_feasible" =>
            _reduced_dcdfba_mpcc_first_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_source_residual_feasible",
                missing,
            ),
        "cross_window_flux_dual_start_max_flux_projection_adjustment" =>
            _reduced_dcdfba_mpcc_max_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_max_flux_projection_adjustment",
            ),
        "cross_window_flux_dual_start_max_lower_dual_sign_clipping" =>
            _reduced_dcdfba_mpcc_max_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_max_lower_dual_sign_clipping",
            ),
        "cross_window_flux_dual_start_max_upper_dual_sign_clipping" =>
            _reduced_dcdfba_mpcc_max_stage_metadata_value(
                stage_results,
                "cross_window_flux_dual_start_max_upper_dual_sign_clipping",
            ),
        "cross_window_flux_dual_start_rhs_derivatives_refreshed" => any(
            result -> get(
                result.metadata,
                "cross_window_flux_dual_start_rhs_derivatives_refreshed",
                false,
            ) === true,
            stage_results,
        ),
        "linear_solver" => linear_solver,
        "ipopt_profile" => String(ipopt_profile),
        "complementarity_mode" => String(complementarity_mode),
        "complementarity_tau" => final_tau,
    )
end

function _reduced_dcdfba_mpcc_apply_coarse_tau_fallback_metadata!(
    result::ReducedDCDFBAMPCCSolveAttemptResult,
    metadata::Dict{String, Any},
)
    get(metadata, "tau_continuation_coarse_tau_fallback_applied", false) === true ||
        return result
    strict_residual_feasible = get(result.metadata, "candidate_residual_feasible", false)
    strict_iteration_limit =
        get(result.metadata, "candidate_iteration_limit_residual_feasible", false)
    solver_status = String(get(result.metadata, "candidate_solver_status", ""))
    iteration_limit =
        strict_iteration_limit === true || solver_status == string(MOI.ITERATION_LIMIT)
    fallback_metadata = Dict{String, Any}(
        "candidate_coarse_tau_stage_fallback_applied" => true,
        "candidate_residual_feasible_source" => "coarse_tau_stage_fallback",
        "candidate_residual_feasible_strict_before_coarse_tau_fallback" =>
            strict_residual_feasible,
        "candidate_iteration_limit_residual_feasible_strict_before_coarse_tau_fallback" =>
            strict_iteration_limit,
        "candidate_coarse_tau_stage_noncomplementarity_residual_feasible" => true,
        "candidate_coarse_tau_stage_tau_gate_pass" =>
            get(result.metadata, "complementarity_tau_gate_pass", false),
        "candidate_coarse_tau_stage_selected_tau" =>
            get(metadata, "tau_continuation_selected_tau", missing),
        "candidate_coarse_tau_stage_attempted_final_tau" =>
            get(metadata, "tau_continuation_attempted_final_tau", missing),
        "candidate_residual_feasible" => true,
        "candidate_iteration_limit_residual_feasible" => iteration_limit,
        "candidate_residual_thresholds_satisfied" => false,
    )
    merge!(result.metadata, fallback_metadata)
    merge!(result.smoke_result.metadata, fallback_metadata)
    if result.candidate_diagnostics !== nothing
        merge!(result.candidate_diagnostics.metadata, fallback_metadata)
    end
    return result
end

function _reduced_dcdfba_mpcc_first_stage_metadata_value(
    stage_results::Vector{ReducedDCDFBAMPCCSolveAttemptResult},
    key::AbstractString,
    default,
)
    for result in stage_results
        get(result.metadata, "cross_window_flux_dual_start_applied", false) === true ||
            continue
        value = get(result.metadata, key, missing)
        value === missing || return value
    end
    return default
end

function _reduced_dcdfba_mpcc_max_stage_metadata_value(
    stage_results::Vector{ReducedDCDFBAMPCCSolveAttemptResult},
    key::AbstractString,
)
    values = Float64[]
    for result in stage_results
        raw = get(result.metadata, key, missing)
        raw === missing && continue
        value = try
            Float64(raw)
        catch
            NaN
        end
        isfinite(value) && push!(values, value)
    end
    return isempty(values) ? missing : maximum(values)
end

"""
    diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)

Build start-value residual and scaling diagnostics for a guarded reduced MPCC
solve-attempt problem without calling the solver.
"""
function diagnose_reduced_dcdfba_mpcc_solve_attempt(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
)::ReducedDCDFBAMPCCDiagnosticReport
    _validate_reduced_dcdfba_mpcc_residual_thresholds(problem.residual_thresholds)
    residuals = _reduced_dcdfba_mpcc_start_residual_values(problem.smoke_problem)
    thresholds = _reduced_dcdfba_mpcc_effective_threshold_values(
        problem.smoke_problem,
        problem.residual_thresholds,
    )
    ratios = _reduced_dcdfba_mpcc_residual_ratios(residuals, thresholds)
    ranked_residuals = _reduced_dcdfba_mpcc_ranked_residuals(ratios)
    dominant_residual = isempty(ranked_residuals) ? "unavailable" : first(ranked_residuals)
    residuals_available = all(isfinite, values(residuals))
    residual_thresholds_satisfied =
        residuals_available && all(key -> abs(residuals[key]) <= thresholds[key], keys(residuals))
    scaling_summary = _reduced_dcdfba_mpcc_start_scaling_summary(problem.smoke_problem)
    scaling_plan = build_reduced_dcdfba_mpcc_scaling_plan(problem)
    merge!(scaling_summary, _reduced_dcdfba_mpcc_scaling_plan_summary(scaling_plan))
    warnings = _reduced_dcdfba_mpcc_diagnostic_warnings(
        residuals_available,
        residual_thresholds_satisfied,
        ratios,
        scaling_summary,
    )
    warnings = unique(vcat(warnings, scaling_plan.warnings))

    metadata = _reduced_dcdfba_mpcc_diagnostic_metadata(
        "initial_start_values",
        problem.metadata,
        residuals_available,
        residual_thresholds_satisfied,
        dominant_residual,
        length(warnings),
    )
    _merge_reduced_dcdfba_mpcc_scaling_plan_diagnostic_metadata!(metadata, scaling_plan)
    return ReducedDCDFBAMPCCDiagnosticReport(
        residuals,
        thresholds,
        ratios,
        ranked_residuals,
        dominant_residual,
        residuals_available,
        residual_thresholds_satisfied,
        scaling_summary,
        warnings,
        metadata,
    )
end

"""
    extract_reduced_dcdfba_mpcc_candidate(problem, smoke_result)
    extract_reduced_dcdfba_mpcc_candidate(result)

Extract post-solve candidate values and diagnostics for a guarded reduced MPCC
solve attempt. This function requires JuMP result values and returns diagnostic
arrays only; the result is not a scientific simultaneous DFBA simulation.
"""
function extract_reduced_dcdfba_mpcc_candidate(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    smoke_result::ReducedDCDFBAMPCCSmokeResult,
)::ReducedDCDFBAMPCCCandidateDiagnostics
    _validate_reduced_dcdfba_mpcc_residual_thresholds(problem.residual_thresholds)
    JuMP.result_count(problem.smoke_problem.nlp.jump_model) > 0 || throw(
        ArgumentError(
            "Reduced DC-dFBA MPCC candidate extraction requires available JuMP result values.",
        ),
    )
    values = _reduced_dcdfba_mpcc_candidate_value_arrays(problem.smoke_problem)
    values === nothing && throw(
        ArgumentError(
            "Reduced DC-dFBA MPCC candidate extraction requires available JuMP result values.",
        ),
    )
    return _reduced_dcdfba_mpcc_candidate_diagnostics_from_values(
        problem.smoke_problem,
        smoke_result,
        problem.residual_thresholds,
        values,
        "post_solve_values",
    )
end

function extract_reduced_dcdfba_mpcc_candidate(
    result::ReducedDCDFBAMPCCSolveAttemptResult,
)::ReducedDCDFBAMPCCCandidateDiagnostics
    result.candidate_diagnostics === nothing && throw(
        ArgumentError("Reduced DC-dFBA MPCC solve-attempt result has no extracted candidate."),
    )
    return result.candidate_diagnostics
end

"""
    extract_reduced_dcdfba_mpcc_trajectory_candidate(result; require_trajectory_ready=false)
    extract_reduced_dcdfba_mpcc_trajectory_candidate(candidate; require_trajectory_ready=false)

Build boundary and collocation `SimulationResult` views from a reduced MPCC
candidate. By default this permits diagnostic extraction from residual-feasible
`ITERATION_LIMIT` candidates, but it keeps scientific-simulation flags false.
Set `require_trajectory_ready=true` to require a solver status accepted by the
trajectory gate.
"""
function extract_reduced_dcdfba_mpcc_trajectory_candidate(
    result::ReducedDCDFBAMPCCSolveAttemptResult;
    require_trajectory_ready::Bool = false,
)::ReducedDCDFBAMPCCTrajectoryCandidate
    candidate = extract_reduced_dcdfba_mpcc_candidate(result)
    return extract_reduced_dcdfba_mpcc_trajectory_candidate(
        candidate;
        require_trajectory_ready = require_trajectory_ready,
    )
end

function extract_reduced_dcdfba_mpcc_trajectory_candidate(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics;
    require_trajectory_ready::Bool = false,
)::ReducedDCDFBAMPCCTrajectoryCandidate
    trajectory_ready = get(
        candidate.metadata,
        "candidate_trajectory_extraction_ready",
        false,
    ) === true
    if require_trajectory_ready && !trajectory_ready
        throw(
            ArgumentError(
                "Reduced DC-dFBA MPCC trajectory candidate is not trajectory-ready. " *
                "Set require_trajectory_ready=false to extract diagnostic-only views.",
            ),
        )
    end

    boundary_times = _reduced_dcdfba_mpcc_candidate_time_vector(
        candidate,
        "candidate_boundary_times",
    )
    collocation_times = _reduced_dcdfba_mpcc_candidate_time_vector(
        candidate,
        "candidate_collocation_times",
    )
    boundary_states = copy(candidate.state_boundary)
    collocation_states = _reduced_dcdfba_flatten_candidate_collocation_values(
        candidate.state_collocation,
    )
    size(boundary_states, 2) == length(boundary_times) || throw(
        ArgumentError("Reduced MPCC boundary state columns do not match boundary times."),
    )
    size(collocation_states, 2) == length(collocation_times) || throw(
        ArgumentError("Reduced MPCC collocation state columns do not match collocation times."),
    )

    metadata = _reduced_dcdfba_mpcc_trajectory_candidate_metadata(
        candidate,
        require_trajectory_ready,
        trajectory_ready,
    )
    boundary_metadata = copy(metadata)
    boundary_metadata["trajectory_candidate_result_kind"] = "finite_element_boundary_states"
    boundary_metadata["trajectory_candidate_time_policy"] = "finite_element_boundaries"
    boundary_metadata["trajectory_candidate_state_policy"] = "state_boundary_values"
    boundary_metadata["trajectory_candidate_fluxes_stored_in_simulation_result"] = false

    collocation_metadata = copy(metadata)
    collocation_metadata["trajectory_candidate_result_kind"] = "radau_collocation_states"
    collocation_metadata["trajectory_candidate_time_policy"] = "radau_collocation_points"
    collocation_metadata["trajectory_candidate_state_policy"] = "state_collocation_values"
    collocation_metadata["trajectory_candidate_fluxes_stored_in_simulation_result"] = false

    boundary_result = SimulationResult(
        boundary_times,
        boundary_states;
        metadata = boundary_metadata,
    )
    collocation_result = SimulationResult(
        collocation_times,
        collocation_states;
        metadata = collocation_metadata,
    )

    return ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary_result,
        collocation_result,
        candidate,
        metadata,
    )
end

"""
    diagnose_reduced_dcdfba_mpcc_solve_attempt(result)

Rank the residual diagnostics from a guarded reduced MPCC solve-attempt result.
This does not reinterpret the result as a scientific trajectory.
"""
function diagnose_reduced_dcdfba_mpcc_solve_attempt(
    result::ReducedDCDFBAMPCCSolveAttemptResult,
)::ReducedDCDFBAMPCCDiagnosticReport
    _validate_reduced_dcdfba_mpcc_residual_thresholds(result.residual_thresholds)
    residuals = _reduced_dcdfba_mpcc_result_residual_values(result)
    thresholds = _reduced_dcdfba_mpcc_effective_threshold_values(
        result.metadata,
        result.residual_thresholds,
    )
    ratios = _reduced_dcdfba_mpcc_residual_ratios(residuals, thresholds)
    ranked_residuals = _reduced_dcdfba_mpcc_ranked_residuals(ratios)
    dominant_residual = isempty(ranked_residuals) ? "unavailable" : first(ranked_residuals)
    residuals_available = all(isfinite, values(residuals))
    residual_thresholds_satisfied =
        residuals_available && all(key -> abs(residuals[key]) <= thresholds[key], keys(residuals))
    scaling_summary = Dict{String, Float64}()
    warnings = _reduced_dcdfba_mpcc_diagnostic_warnings(
        residuals_available,
        residual_thresholds_satisfied,
        ratios,
        scaling_summary,
    )

    metadata = _reduced_dcdfba_mpcc_diagnostic_metadata(
        "solve_result",
        result.metadata,
        residuals_available,
        residual_thresholds_satisfied,
        dominant_residual,
        length(warnings),
    )
    return ReducedDCDFBAMPCCDiagnosticReport(
        residuals,
        thresholds,
        ratios,
        ranked_residuals,
        dominant_residual,
        residuals_available,
        residual_thresholds_satisfied,
        scaling_summary,
        warnings,
        metadata,
    )
end

"""
    build_reduced_dcdfba_mpcc_scaling_plan(problem; target_abs_max=1.0, min_scale=1e-6, max_scale=1e6)

Build a pre-solve block-scaling plan for a reduced MPCC problem. The plan uses
current start values to summarize variable magnitudes and constraint residual
families, including collocation integration, finite-element continuity, RHS,
KKT, and complementarity blocks. It does not mutate the JuMP model and does
not call a solver.
"""
function build_reduced_dcdfba_mpcc_scaling_plan(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem;
    target_abs_max::Real = 1.0,
    min_scale::Real = 1.0e-6,
    max_scale::Real = 1.0e6,
)::ReducedDCDFBAMPCCScalingPlan
    return build_reduced_dcdfba_mpcc_scaling_plan(
        problem.smoke_problem;
        target_abs_max = target_abs_max,
        min_scale = min_scale,
        max_scale = max_scale,
    )
end

function build_reduced_dcdfba_mpcc_scaling_plan(
    problem::ReducedDCDFBAMPCCSmokeProblem;
    target_abs_max::Real = 1.0,
    min_scale::Real = 1.0e-6,
    max_scale::Real = 1.0e6,
)::ReducedDCDFBAMPCCScalingPlan
    target, min_factor, max_factor =
        _validate_reduced_dcdfba_mpcc_scaling_parameters(target_abs_max, min_scale, max_scale)
    starts = _reduced_dcdfba_mpcc_scaling_start_values(problem)
    variable_blocks = _reduced_dcdfba_mpcc_variable_scale_blocks(
        starts,
        target,
        min_factor,
        max_factor,
    )
    constraint_blocks = _reduced_dcdfba_mpcc_constraint_scale_blocks(
        problem,
        starts,
        target,
        min_factor,
        max_factor,
    )
    variable_scale_factors = Dict{String, Float64}(
        name => block.recommended_scale for (name, block) in variable_blocks
    )
    constraint_scale_factors = Dict{String, Float64}(
        name => block.recommended_scale for (name, block) in constraint_blocks
    )
    warnings =
        _reduced_dcdfba_mpcc_scaling_plan_warnings(variable_blocks, constraint_blocks)
    metadata = _reduced_dcdfba_mpcc_scaling_plan_metadata(
        problem,
        target,
        min_factor,
        max_factor,
        variable_blocks,
        constraint_blocks,
        warnings,
    )
    return ReducedDCDFBAMPCCScalingPlan(
        variable_blocks,
        constraint_blocks,
        variable_scale_factors,
        constraint_scale_factors,
        warnings,
        metadata,
    )
end

"""
    add_reduced_dcdfba_primal_feasibility!(nlp)

Add reduced FBA primal feasibility rows `S*v = 0` at every collocation point.
This is the stoichiometric mass-balance part of the future KKT reformulation
only; no stationarity, dual variables, or complementarity are created.
"""
function add_reduced_dcdfba_primal_feasibility!(
    nlp::ReducedDCDFBACollocationNLP,
)::ReducedDCDFBAPrimalFeasibilityScaffold
    get(nlp.metadata, "mass_balance_constraints_built", false) && throw(
        ArgumentError("Reduced DC-dFBA primal feasibility constraints were already added."),
    )

    model = nlp.kkt_problem.model
    dimensions = nlp.dimensions
    size(model.S, 1) == nlp.kkt_problem.dimensions.n_metabolites || throw(
        ArgumentError("Reduced DC-dFBA primal feasibility S row count does not match scaffold dimensions."),
    )
    size(model.S, 2) == dimensions.n_reactions || throw(
        ArgumentError("Reduced DC-dFBA primal feasibility S column count does not match flux dimensions."),
    )

    constraints = Array{JuMP.ConstraintRef, 3}(
        undef,
        size(model.S, 1),
        dimensions.nfe,
        dimensions.collocation_degree,
    )
    row_entries = _reduced_dcdfba_stoichiometric_row_entries(model)
    _add_reduced_dcdfba_mass_balance_constraints!(constraints, nlp, row_entries)
    layout = _reduced_dcdfba_primal_feasibility_layout(nlp)
    metadata = _reduced_dcdfba_primal_feasibility_metadata(layout)

    merge!(nlp.metadata, metadata)

    return ReducedDCDFBAPrimalFeasibilityScaffold(nlp, constraints, layout, metadata)
end

"""
    add_reduced_dcdfba_bound_feasibility!(nlp; dynamic_bounds=nothing)

Add explicit reduced FBA bound-feasibility rows for `lb <= v <= ub` at every
collocation point, plus lower- and upper-bound dual variables for a future KKT
stationarity block. This does not add stationarity or MPCC complementarity.
"""
function add_reduced_dcdfba_bound_feasibility!(
    nlp::ReducedDCDFBACollocationNLP;
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold} = nothing,
)::ReducedDCDFBABoundFeasibilityScaffold
    get(nlp.metadata, "bound_feasibility_constraints_built", false) && throw(
        ArgumentError("Reduced DC-dFBA bound-feasibility constraints were already added."),
    )
    _validate_reduced_dcdfba_bound_feasibility_model(nlp)
    _validate_reduced_dcdfba_dynamic_bounds_attachment(nlp, dynamic_bounds)

    dimensions = nlp.dimensions
    n_reactions = dimensions.n_reactions
    nfe = dimensions.nfe
    degree = dimensions.collocation_degree
    jump_model = nlp.jump_model

    JuMP.@variable(jump_model, lower_bound_duals[1:n_reactions, 1:nfe, 1:degree] <= 0.0)
    JuMP.@variable(jump_model, upper_bound_duals[1:n_reactions, 1:nfe, 1:degree] >= 0.0)
    _set_reduced_dcdfba_bound_dual_starts!(lower_bound_duals, upper_bound_duals)

    lower_bound_constraints = Array{JuMP.ConstraintRef, 3}(undef, n_reactions, nfe, degree)
    upper_bound_constraints = Array{JuMP.ConstraintRef, 3}(undef, n_reactions, nfe, degree)
    _add_reduced_dcdfba_bound_feasibility_constraints!(
        lower_bound_constraints,
        upper_bound_constraints,
        nlp,
        dynamic_bounds,
    )

    layout = _reduced_dcdfba_bound_feasibility_layout(dimensions)
    metadata = _reduced_dcdfba_bound_feasibility_metadata(layout, dynamic_bounds)
    if get(nlp.metadata, "fixed_flux_variable_bounds_deferred", false) === true
        metadata["fixed_flux_bounds_enforced_by_bound_feasibility_rows"] = true
        metadata["fixed_flux_bound_feasibility_reduces_ipopt_fixed_variable_pressure"] = true
        metadata["fixed_flux_collocation_variable_count"] =
            get(nlp.metadata, "fixed_flux_collocation_variable_count", 0)
        metadata["fixed_flux_reaction_count"] =
            get(nlp.metadata, "fixed_flux_reaction_count", 0)
        metadata["fixed_flux_reaction_ids"] =
            get(nlp.metadata, "fixed_flux_reaction_ids", String[])
    end
    merge!(nlp.metadata, metadata)

    return ReducedDCDFBABoundFeasibilityScaffold(
        nlp,
        lower_bound_duals,
        upper_bound_duals,
        lower_bound_constraints,
        upper_bound_constraints,
        dynamic_bounds,
        layout,
        metadata,
    )
end

"""
    add_reduced_dcdfba_stationarity!(nlp, bound_feasibility; objective_coefficients=nothing)

Add reduced FBA KKT stationarity rows using explicit mass-balance duals and
the bound duals created by `add_reduced_dcdfba_bound_feasibility!`. The
stationarity rows are linear equations of the form
`c + S'lambda + alpha_L + alpha_U = 0`. By default `c = 0`; dynamic objective
coefficients are deferred to a later block.
"""
function add_reduced_dcdfba_stationarity!(
    nlp::ReducedDCDFBACollocationNLP,
    bound_feasibility::ReducedDCDFBABoundFeasibilityScaffold;
    objective_coefficients::Union{Nothing, AbstractVector{<:Real}} = nothing,
    objective_coefficient_expressions::Union{Nothing, Dict{Tuple{Int, Int, Int}, Any}} =
        nothing,
)::ReducedDCDFBAStationarityScaffold
    get(nlp.metadata, "stationarity_constraints_built", false) && throw(
        ArgumentError("Reduced DC-dFBA stationarity constraints were already added."),
    )
    _validate_reduced_dcdfba_stationarity_inputs(nlp, bound_feasibility)

    dimensions = nlp.dimensions
    n_metabolites = nlp.kkt_problem.dimensions.n_metabolites
    n_reactions = dimensions.n_reactions
    nfe = dimensions.nfe
    degree = dimensions.collocation_degree
    jump_model = nlp.jump_model
    coefficients, coefficient_expressions, objective_policy =
        _reduced_dcdfba_stationarity_objective_coefficients(
            nlp,
            objective_coefficients,
            objective_coefficient_expressions,
        )

    JuMP.@variable(jump_model, mass_balance_duals[1:n_metabolites, 1:nfe, 1:degree])
    _set_reduced_dcdfba_mass_balance_dual_starts!(mass_balance_duals)

    stationarity_constraints = Array{JuMP.ConstraintRef, 3}(undef, n_reactions, nfe, degree)
    column_entries = _reduced_dcdfba_stoichiometric_column_entries(nlp.kkt_problem.model)
    _add_reduced_dcdfba_stationarity_constraints!(
        stationarity_constraints,
        nlp,
        bound_feasibility,
        mass_balance_duals,
        column_entries,
        coefficients,
        coefficient_expressions,
    )

    layout = _reduced_dcdfba_stationarity_layout(nlp)
    metadata = _reduced_dcdfba_stationarity_metadata(
        layout,
        objective_policy,
        coefficients,
        coefficient_expressions,
        bound_feasibility.dynamic_bounds,
    )
    merge!(nlp.metadata, metadata)

    return ReducedDCDFBAStationarityScaffold(
        nlp,
        bound_feasibility,
        mass_balance_duals,
        stationarity_constraints,
        layout,
        coefficients,
        coefficient_expressions,
        metadata,
    )
end

"""
    add_reduced_dcdfba_complementarity!(nlp, stationarity; complementarity_mode=:exact, complementarity_tau=1e-4)

Add reduced FBA MPCC complementarity products for lower and upper bound pairs
using an existing stationarity scaffold. Exact mode creates quadratic equality
constraints; Scholtes mode relaxes the signed products with a nonnegative tau.
"""
function add_reduced_dcdfba_complementarity!(
    nlp::ReducedDCDFBACollocationNLP,
    stationarity::ReducedDCDFBAStationarityScaffold,
    ;
    complementarity_mode::Union{Symbol, AbstractString} =
        REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_EXACT,
    complementarity_tau::Real = REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU,
)::ReducedDCDFBAComplementarityScaffold
    get(nlp.metadata, "mpcc_complementarity_built", false) && throw(
        ArgumentError("Reduced DC-dFBA MPCC complementarity constraints were already added."),
    )
    _validate_reduced_dcdfba_complementarity_inputs(nlp, stationarity)
    mode = _reduced_dcdfba_mpcc_complementarity_mode(complementarity_mode)
    tau = _reduced_dcdfba_mpcc_validate_complementarity_tau(complementarity_tau)

    dimensions = nlp.dimensions
    n_reactions = dimensions.n_reactions
    nfe = dimensions.nfe
    degree = dimensions.collocation_degree
    lower_bound_complementarity_constraints =
        Array{JuMP.ConstraintRef, 3}(undef, n_reactions, nfe, degree)
    upper_bound_complementarity_constraints =
        Array{JuMP.ConstraintRef, 3}(undef, n_reactions, nfe, degree)

    _add_reduced_dcdfba_complementarity_constraints!(
        lower_bound_complementarity_constraints,
        upper_bound_complementarity_constraints,
        nlp,
        stationarity,
        mode,
        tau,
    )

    layout = _reduced_dcdfba_complementarity_layout(dimensions)
    metadata = _reduced_dcdfba_complementarity_metadata(
        layout,
        stationarity.bound_feasibility.dynamic_bounds,
        mode,
        tau,
    )
    merge!(nlp.metadata, metadata)

    return ReducedDCDFBAComplementarityScaffold(
        nlp,
        stationarity,
        lower_bound_complementarity_constraints,
        upper_bound_complementarity_constraints,
        layout,
        metadata,
    )
end

"""
    add_reduced_dcdfba_rhs_residuals!(nlp; mode=:growth)

Add a first reduced collocation RHS residual scaffold to an existing
`ReducedDCDFBACollocationNLP`. The initial implementation supports a fixed
smooth `:growth` mode only. It intentionally avoids non-smooth `max` operators,
dynamic flux bounds, `S*v = 0`, KKT stationarity, and MPCC complementarity.
"""
function add_reduced_dcdfba_rhs_residuals!(
    nlp::ReducedDCDFBACollocationNLP;
    mode::Symbol = :growth,
    dynamic_control_schedule = nothing,
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold} =
        nothing,
)::ReducedDCDFBARHSResidualScaffold
    mode == :growth || throw(
        ArgumentError(
            "Reduced DC-dFBA collocation RHS residual scaffold currently supports mode=:growth only.",
        ),
    )
    resolved_dynamic_control_schedule =
        _reduced_dcdfba_normalize_dynamic_control_schedule(dynamic_control_schedule)
    get(nlp.metadata, "ode_rhs_constraints_built", false) && throw(
        ArgumentError("Reduced DC-dFBA collocation RHS residual constraints were already added."),
    )

    dimensions = nlp.dimensions
    constraints = Array{JuMP.ConstraintRef, 3}(
        undef,
        dimensions.n_states,
        dimensions.nfe,
        dimensions.collocation_degree,
    )
    reaction_indices = _reduced_dcdfba_rhs_reaction_indices(nlp.kkt_problem)
    _add_reduced_dcdfba_growth_rhs_constraints!(
        constraints,
        nlp,
        reaction_indices,
        resolved_dynamic_control_schedule,
        dynamic_control_decisions,
    )
    layout = _reduced_dcdfba_rhs_residual_layout(dimensions)
    metadata = _reduced_dcdfba_rhs_residual_metadata(
        nlp,
        layout,
        resolved_dynamic_control_schedule,
        dynamic_control_decisions,
    )

    merge!(nlp.metadata, metadata)

    return ReducedDCDFBARHSResidualScaffold(
        nlp,
        constraints,
        layout,
        reaction_indices,
        mode,
        metadata,
    )
end

function _reduced_dcdfba_collocation_nlp_dimensions(
    kkt_problem::KKTDFBAProblem,
)::ReducedDCDFBACollocationNLPDimensions
    scaffold_dimensions = kkt_problem.dimensions
    n_states = scaffold_dimensions.n_states
    n_reactions = scaffold_dimensions.n_reactions
    nfe = scaffold_dimensions.nfe
    degree = scaffold_dimensions.collocation_degree
    n_collocation_points = scaffold_dimensions.n_collocation_points

    n_state_boundary_variables = scaffold_dimensions.n_state_boundary_variables
    n_state_collocation_variables = scaffold_dimensions.n_state_collocation_variables
    n_state_derivative_variables = n_states * n_collocation_points
    n_flux_variables = scaffold_dimensions.n_flux_variables
    n_total_variables =
        n_state_boundary_variables +
        n_state_collocation_variables +
        n_state_derivative_variables +
        n_flux_variables

    n_collocation_integration_constraints = n_states * n_collocation_points
    n_continuity_constraints = n_states * nfe
    n_initial_condition_constraints = n_states
    n_total_constraints =
        n_collocation_integration_constraints +
        n_continuity_constraints +
        n_initial_condition_constraints

    return ReducedDCDFBACollocationNLPDimensions(
        n_states,
        n_reactions,
        nfe,
        degree,
        n_collocation_points,
        n_state_boundary_variables,
        n_state_collocation_variables,
        n_state_derivative_variables,
        n_flux_variables,
        n_total_variables,
        n_collocation_integration_constraints,
        n_continuity_constraints,
        n_initial_condition_constraints,
        n_total_constraints,
    )
end

function _reduced_dcdfba_primal_feasibility_layout(
    nlp::ReducedDCDFBACollocationNLP,
)::ReducedDCDFBAPrimalFeasibilityLayout
    dimensions = nlp.dimensions
    n_metabolites = nlp.kkt_problem.dimensions.n_metabolites
    n_mass_balance_constraints = n_metabolites * dimensions.n_collocation_points
    return ReducedDCDFBAPrimalFeasibilityLayout(
        n_metabolites,
        dimensions.n_reactions,
        dimensions.nfe,
        dimensions.collocation_degree,
        dimensions.n_collocation_points,
        n_mass_balance_constraints,
        n_mass_balance_constraints,
    )
end

function _reduced_dcdfba_bound_feasibility_layout(
    dimensions::ReducedDCDFBACollocationNLPDimensions,
)::ReducedDCDFBABoundFeasibilityLayout
    n_bound_constraints = dimensions.n_reactions * dimensions.n_collocation_points
    return ReducedDCDFBABoundFeasibilityLayout(
        dimensions.n_reactions,
        dimensions.nfe,
        dimensions.collocation_degree,
        dimensions.n_collocation_points,
        n_bound_constraints,
        n_bound_constraints,
        n_bound_constraints,
        n_bound_constraints,
        2 * n_bound_constraints,
        2 * n_bound_constraints,
    )
end

function _reduced_dcdfba_dynamic_bounds_layout(
    dimensions::ReducedDCDFBACollocationNLPDimensions,
    lower_reactions::AbstractVector{<:Integer},
    upper_reactions::AbstractVector{<:Integer},
    objective_reactions::AbstractVector{<:Integer},
)::ReducedDCDFBADynamicBoundsLayout
    ncp = dimensions.n_collocation_points
    return ReducedDCDFBADynamicBoundsLayout(
        dimensions.n_reactions,
        dimensions.nfe,
        dimensions.collocation_degree,
        ncp,
        length(lower_reactions),
        length(upper_reactions),
        length(objective_reactions),
        length(lower_reactions) * ncp,
        length(upper_reactions) * ncp,
        dimensions.n_reactions,
    )
end

function _reduced_dcdfba_stationarity_layout(
    nlp::ReducedDCDFBACollocationNLP,
)::ReducedDCDFBAStationarityLayout
    dimensions = nlp.dimensions
    n_metabolites = nlp.kkt_problem.dimensions.n_metabolites
    n_mass_balance_dual_variables = n_metabolites * dimensions.n_collocation_points
    n_stationarity_constraints = dimensions.n_reactions * dimensions.n_collocation_points
    return ReducedDCDFBAStationarityLayout(
        n_metabolites,
        dimensions.n_reactions,
        dimensions.nfe,
        dimensions.collocation_degree,
        dimensions.n_collocation_points,
        n_mass_balance_dual_variables,
        n_stationarity_constraints,
        dimensions.n_reactions,
    )
end

function _reduced_dcdfba_complementarity_layout(
    dimensions::ReducedDCDFBACollocationNLPDimensions,
)::ReducedDCDFBAComplementarityLayout
    n_bound_pairs = dimensions.n_reactions * dimensions.n_collocation_points
    return ReducedDCDFBAComplementarityLayout(
        dimensions.n_reactions,
        dimensions.nfe,
        dimensions.collocation_degree,
        dimensions.n_collocation_points,
        n_bound_pairs,
        n_bound_pairs,
        2 * n_bound_pairs,
    )
end

function _reduced_dcdfba_stoichiometric_row_entries(model::MetabolicModel)
    row_indices, column_indices, values = findnz(model.S)
    row_entries = [Vector{Tuple{Int, Float64}}() for _ in 1:size(model.S, 1)]
    for entry_index in eachindex(values)
        push!(
            row_entries[row_indices[entry_index]],
            (column_indices[entry_index], values[entry_index]),
        )
    end
    return row_entries
end

function _reduced_dcdfba_stoichiometric_column_entries(model::MetabolicModel)
    row_indices, column_indices, values = findnz(model.S)
    column_entries = [Vector{Tuple{Int, Float64}}() for _ in 1:size(model.S, 2)]
    for entry_index in eachindex(values)
        push!(
            column_entries[column_indices[entry_index]],
            (row_indices[entry_index], values[entry_index]),
        )
    end
    return column_entries
end

function _add_reduced_dcdfba_mass_balance_constraints!(
    constraints::Array{JuMP.ConstraintRef, 3},
    nlp::ReducedDCDFBACollocationNLP,
    row_entries::Vector{Vector{Tuple{Int, Float64}}},
)
    jump_model = nlp.jump_model
    flux = nlp.flux
    n_metabolites = size(constraints, 1)
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree

    for metabolite_index in 1:n_metabolites, e in 1:nfe, j in 1:degree
        expression = JuMP.AffExpr(0.0)
        for (reaction_index_value, coefficient) in row_entries[metabolite_index]
            JuMP.add_to_expression!(
                expression,
                coefficient,
                flux[reaction_index_value, e, j],
            )
        end
        constraints[metabolite_index, e, j] =
            JuMP.@constraint(jump_model, expression == 0.0)
    end
    return nothing
end

function _reduced_dcdfba_primal_feasibility_metadata(
    layout::ReducedDCDFBAPrimalFeasibilityLayout,
)::Dict{String, Any}
    return Dict{String, Any}(
        "mass_balance_constraints_built" => true,
        "reduced_fba_primal_feasibility_built" => true,
        "primal_feasibility_component" => "S*v = 0 at each collocation point",
        "primal_feasibility_total_constraints" => layout.total_primal_feasibility_constraints,
        "primal_feasibility_metabolite_count" => layout.n_metabolites,
        "primal_feasibility_reaction_count" => layout.n_reactions,
        "bound_feasibility_constraints_built" => false,
        "stationarity_constraints_built" => false,
        "kkt_constraints_built" => false,
        "mpcc_complementarity_built" => false,
        "dynamic_flux_bounds_applied" => false,
        "solver_call_performed" => false,
        "sequential_initialization_built" => false,
        "dfvb_kkt_deferred" => true,
        "full_model_kkt_deferred" => true,
        "first_mpcc_target" => "reduced_dfba",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
end

function _validate_reduced_dcdfba_complementarity_inputs(
    nlp::ReducedDCDFBACollocationNLP,
    stationarity::ReducedDCDFBAStationarityScaffold,
)
    stationarity.nlp === nlp || throw(
        ArgumentError("Reduced DC-dFBA complementarity requires stationarity variables from the same NLP."),
    )
    stationarity.bound_feasibility.nlp === nlp || throw(
        ArgumentError("Reduced DC-dFBA complementarity requires bound-feasibility variables from the same NLP."),
    )
    get(nlp.metadata, "mass_balance_constraints_built", false) || throw(
        ArgumentError("Reduced DC-dFBA complementarity requires primal feasibility rows before complementarity."),
    )
    get(nlp.metadata, "bound_feasibility_constraints_built", false) || throw(
        ArgumentError("Reduced DC-dFBA complementarity requires bound feasibility rows before complementarity."),
    )
    get(nlp.metadata, "stationarity_constraints_built", false) || throw(
        ArgumentError("Reduced DC-dFBA complementarity requires stationarity rows before complementarity."),
    )
    size(stationarity.bound_feasibility.lower_bound_duals) == size(nlp.flux) || throw(
        ArgumentError("Reduced DC-dFBA complementarity lower-bound dual dimensions must match flux dimensions."),
    )
    size(stationarity.bound_feasibility.upper_bound_duals) == size(nlp.flux) || throw(
        ArgumentError("Reduced DC-dFBA complementarity upper-bound dual dimensions must match flux dimensions."),
    )
    return nothing
end

function _add_reduced_dcdfba_complementarity_constraints!(
    lower_bound_complementarity_constraints::Array{JuMP.ConstraintRef, 3},
    upper_bound_complementarity_constraints::Array{JuMP.ConstraintRef, 3},
    nlp::ReducedDCDFBACollocationNLP,
    stationarity::ReducedDCDFBAStationarityScaffold,
    complementarity_mode::Symbol,
    complementarity_tau::Float64,
)
    jump_model = nlp.jump_model
    flux = nlp.flux
    dynamic_bounds = stationarity.bound_feasibility.dynamic_bounds
    lower_bound_duals = stationarity.bound_feasibility.lower_bound_duals
    upper_bound_duals = stationarity.bound_feasibility.upper_bound_duals
    n_reactions = nlp.dimensions.n_reactions
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree

    for r in 1:n_reactions, e in 1:nfe, j in 1:degree
        lower_product =
            (
                flux[r, e, j] -
                _reduced_dcdfba_lower_bound_expression(nlp, dynamic_bounds, r, e, j)
            ) * lower_bound_duals[r, e, j]
        upper_product =
            (
                flux[r, e, j] -
                _reduced_dcdfba_upper_bound_expression(nlp, dynamic_bounds, r, e, j)
            ) * upper_bound_duals[r, e, j]
        if complementarity_mode == :exact
            lower_bound_complementarity_constraints[r, e, j] =
                JuMP.@constraint(jump_model, lower_product == 0.0)
            upper_bound_complementarity_constraints[r, e, j] =
                JuMP.@constraint(jump_model, upper_product == 0.0)
        else
            lower_bound_complementarity_constraints[r, e, j] =
                JuMP.@constraint(jump_model, -lower_product <= complementarity_tau)
            upper_bound_complementarity_constraints[r, e, j] =
                JuMP.@constraint(jump_model, -upper_product <= complementarity_tau)
        end
    end
    return nothing
end

function _reduced_dcdfba_complementarity_metadata(
    layout::ReducedDCDFBAComplementarityLayout,
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold},
    complementarity_mode::Symbol,
    complementarity_tau::Float64,
)::Dict{String, Any}
    dynamic_applied = dynamic_bounds !== nothing
    scholtes = complementarity_mode == :scholtes
    return Dict{String, Any}(
        "mpcc_complementarity_built" => true,
        "reduced_fba_complementarity_built" => true,
        "reduced_fba_kkt_constraints_built" => true,
        "kkt_constraints_built" => true,
        "lower_bound_complementarity_built" => true,
        "upper_bound_complementarity_built" => true,
        "lower_bound_complementarity_form" =>
            scholtes ?
            (
                dynamic_applied ?
                "-((v - lb_dynamic_or_base) * alpha_L) <= tau" :
                "-((v - lb) * alpha_L) <= tau"
            ) :
            (dynamic_applied ? "(v - lb_dynamic_or_base) * alpha_L = 0" : "(v - lb) * alpha_L = 0"),
        "upper_bound_complementarity_form" =>
            scholtes ?
            (
                dynamic_applied ?
                "-((v - ub_dynamic_or_base) * alpha_U) <= tau" :
                "-((v - ub) * alpha_U) <= tau"
            ) :
            (dynamic_applied ? "(v - ub_dynamic_or_base) * alpha_U = 0" : "(v - ub) * alpha_U = 0"),
        "lower_bound_dual_sign" => "nonpositive",
        "upper_bound_dual_sign" => "nonnegative",
        "complementarity_mode" => String(complementarity_mode),
        "complementarity_tau" => scholtes ? complementarity_tau : missing,
        "complementarity_tau_env" => REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_TAU_ENV,
        "complementarity_mode_env" => REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_ENV,
        "complementarity_constraint_type" =>
            scholtes ? "scholtes_inequalities" : "quadratic_equalities",
        "complementarity_relaxation_sign_policy" =>
            scholtes ? "sign_consistent_nonnegative_kkt_products" : "exact_zero_products",
        "complementarity_lower_constraints" => layout.n_lower_bound_complementarity_constraints,
        "complementarity_upper_constraints" => layout.n_upper_bound_complementarity_constraints,
        "complementarity_total_constraints" => layout.n_total_complementarity_constraints,
        "mpcc_formulation_scope" =>
            dynamic_applied ?
            "reduced_fba_dynamic_growth_bounds_at_collocation_points" :
            "reduced_fba_fixed_bounds_at_collocation_points",
        "full_simultaneous_dfba_solver_built" => false,
        "dynamic_flux_bounds_applied" => dynamic_applied,
        "solver_call_performed" => false,
        "sequential_initialization_built" => false,
        "dfvb_kkt_deferred" => true,
        "full_model_kkt_deferred" => true,
        "first_mpcc_target" => "reduced_dfba",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
end

function _validate_reduced_dcdfba_mpcc_smoke_max_iter(ipopt_max_iter::Union{Nothing, Int})
    ipopt_max_iter === nothing || ipopt_max_iter >= 0 || throw(
        ArgumentError("Reduced DC-dFBA MPCC smoke ipopt_max_iter must be nonnegative when provided."),
    )
    return nothing
end

function _reduced_dcdfba_mpcc_smoke_static_fba_flux_start(
    model::MetabolicModel,
    reaction_map::ReactionMap,
)::Tuple{Vector{Float64}, Dict{String, Any}}
    biomass_id = strip(get(reaction_map.core, "biomass_growth", ""))
    isempty(biomass_id) && throw(
        ArgumentError("Reduced DC-dFBA MPCC smoke requires a biomass_growth reaction in the reaction map."),
    )
    has_reaction(model, biomass_id) || throw(
        ArgumentError("Reduced DC-dFBA MPCC smoke biomass reaction is missing from the reduced model: $biomass_id."),
    )

    fba = solve_fba(model; objective_rxn_id = biomass_id)
    has_fluxes = length(fba.fluxes) == length(model.rxn_ids)
    has_fluxes || throw(
        ArgumentError("Reduced DC-dFBA MPCC smoke static FBA start did not return a complete flux vector."),
    )

    metadata = Dict{String, Any}(
        "static_fba_flux_start_built" => true,
        "static_fba_flux_start_objective_rxn_id" => biomass_id,
        "static_fba_flux_start_status" => string(fba.status),
        "static_fba_flux_start_objective_value" => fba.objective_value,
        "static_fba_flux_start_mass_balance_residual" => fba.mass_balance_residual,
        "static_fba_flux_start_max_lower_bound_violation" => fba.max_lower_bound_violation,
        "static_fba_flux_start_max_upper_bound_violation" => fba.max_upper_bound_violation,
    )
    return copy(fba.fluxes), metadata
end

function _set_reduced_dcdfba_flux_start!(
    nlp::ReducedDCDFBACollocationNLP,
    flux_start::AbstractVector{<:Real},
)
    n_reactions = nlp.dimensions.n_reactions
    length(flux_start) == n_reactions || throw(
        ArgumentError("Reduced DC-dFBA flux start must have $n_reactions entries."),
    )
    all(isfinite, flux_start) || throw(
        ArgumentError("Reduced DC-dFBA flux start values must be finite."),
    )

    for r in 1:n_reactions, e in 1:nlp.dimensions.nfe, j in 1:nlp.dimensions.collocation_degree
        JuMP.set_start_value(nlp.flux[r, e, j], Float64(flux_start[r]))
    end
    return nothing
end

function _reduced_dcdfba_env_bool(name::AbstractString, default::Bool)
    raw = lowercase(strip(get(ENV, String(name), default ? "true" : "false")))
    raw in ("1", "true", "yes", "y", "on") && return true
    raw in ("0", "false", "no", "n", "off") && return false
    throw(ArgumentError("Environment variable $name must be boolean, got: $raw"))
end

function reduced_dcdfba_state_nonnegative_bounds_from_env()::Bool
    return _reduced_dcdfba_env_bool(
        REDUCED_DCDFBA_MPCC_STATE_NONNEGATIVE_BOUNDS_ENV,
        false,
    )
end

function reduced_dcdfba_state_nonnegative_start_clamp_from_env()::Bool
    return _reduced_dcdfba_env_bool(
        REDUCED_DCDFBA_MPCC_STATE_NONNEGATIVE_START_CLAMP_ENV,
        false,
    )
end

function _reduced_dcdfba_env_optional_positive_float(
    name::AbstractString,
)
    raw = strip(get(ENV, String(name), ""))
    isempty(raw) && return nothing
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError("Environment variable $name must be a Float64, got: $raw"),
    )
    isfinite(value) && value > 0.0 || throw(
        ArgumentError("Environment variable $name must be finite and positive, got: $value"),
    )
    return value
end

function _reduced_dcdfba_env_nonnegative_float(
    name::AbstractString,
    default::Real,
)::Float64
    raw = strip(get(ENV, String(name), string(default)))
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError("Environment variable $name must be a Float64, got: $raw"),
    )
    isfinite(value) && value >= 0.0 || throw(
        ArgumentError("Environment variable $name must be finite and nonnegative, got: $value"),
    )
    return value
end

function _reduced_dcdfba_env_nonnegative_int(
    name::AbstractString,
    default::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default)))
    value = tryparse(Int, raw)
    value === nothing && throw(
        ArgumentError("Environment variable $name must be an Int, got: $raw"),
    )
    value >= 0 || throw(
        ArgumentError("Environment variable $name must be nonnegative, got: $value"),
    )
    return value
end

function _reduced_dcdfba_env_positive_unit_float_vector(
    name::AbstractString,
    default::Vector{Float64},
)::Vector{Float64}
    raw = strip(get(ENV, String(name), join(default, ",")))
    isempty(raw) && return copy(default)
    factors = Float64[]
    for token in split(raw, r"[,;\s]+")
        isempty(token) && continue
        value = tryparse(Float64, token)
        value === nothing && throw(
            ArgumentError("Environment variable $name must contain Float64 values, got: $token"),
        )
        isfinite(value) && 0.0 < value <= 1.0 || throw(
            ArgumentError("Environment variable $name values must be in (0, 1], got: $value"),
        )
        push!(factors, value)
    end
    isempty(factors) && throw(
        ArgumentError("Environment variable $name must contain at least one damping factor."),
    )
    return factors
end

function _reduced_dcdfba_dynamic_flux_lp_start_options()
    time_limit =
        _reduced_dcdfba_env_optional_positive_float(
            "MPCC_DYNAMIC_FLUX_LP_TIME_LIMIT",
        )
    trace = _reduced_dcdfba_env_bool("MPCC_DYNAMIC_FLUX_LP_TRACE", false)
    trace_every =
        max(
            1,
            _reduced_dcdfba_env_nonnegative_int(
                "MPCC_DYNAMIC_FLUX_LP_TRACE_EVERY",
                1,
            ),
        )
    max_points =
        _reduced_dcdfba_env_nonnegative_int(
            "MPCC_DYNAMIC_FLUX_LP_MAX_POINTS",
            0,
        )
    fail_fast = _reduced_dcdfba_env_bool("MPCC_DYNAMIC_FLUX_LP_FAIL_FAST", true)
    relaxed_fallback =
        _reduced_dcdfba_env_bool("MPCC_DYNAMIC_FLUX_LP_RELAXED_FALLBACK", false)
    relaxed_mass_weight =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_DYNAMIC_FLUX_LP_RELAXED_MASS_WEIGHT",
            1.0e3,
        )
    if relaxed_fallback && !(relaxed_mass_weight > 0.0)
        throw(
            ArgumentError(
                "MPCC_DYNAMIC_FLUX_LP_RELAXED_MASS_WEIGHT must be positive when relaxed fallback is enabled.",
            ),
        )
    end

    optimizer_attributes = Dict{String, Any}()
    time_limit !== nothing && (optimizer_attributes["time_limit"] = time_limit)
    presolve = strip(get(ENV, "MPCC_DYNAMIC_FLUX_LP_HIGHS_PRESOLVE", ""))
    isempty(presolve) || (optimizer_attributes["presolve"] = String(presolve))
    solver = strip(get(ENV, "MPCC_DYNAMIC_FLUX_LP_HIGHS_SOLVER", ""))
    isempty(solver) || (optimizer_attributes["solver"] = String(solver))

    return (
        time_limit = time_limit,
        trace = trace,
        trace_every = trace_every,
        max_points = max_points,
        fail_fast = fail_fast,
        relaxed_fallback = relaxed_fallback,
        relaxed_mass_weight = relaxed_mass_weight,
        optimizer_attributes = optimizer_attributes,
    )
end

function _reduced_dcdfba_stationarity_dual_start_options()
    time_limit =
        _reduced_dcdfba_env_optional_positive_float(
            "MPCC_STATIONARITY_DUAL_START_LP_TIME_LIMIT",
        )
    trace = _reduced_dcdfba_env_bool("MPCC_STATIONARITY_DUAL_START_LP_TRACE", false)
    trace_every =
        max(
            1,
            _reduced_dcdfba_env_nonnegative_int(
                "MPCC_STATIONARITY_DUAL_START_LP_TRACE_EVERY",
                1,
            ),
        )
    max_points =
        _reduced_dcdfba_env_nonnegative_int(
            "MPCC_STATIONARITY_DUAL_START_LP_MAX_POINTS",
            0,
        )
    fail_fast = _reduced_dcdfba_env_bool("MPCC_STATIONARITY_DUAL_START_LP_FAIL_FAST", true)

    optimizer_attributes = Dict{String, Any}()
    time_limit !== nothing && (optimizer_attributes["time_limit"] = time_limit)
    presolve = strip(get(ENV, "MPCC_STATIONARITY_DUAL_START_LP_HIGHS_PRESOLVE", ""))
    isempty(presolve) || (optimizer_attributes["presolve"] = String(presolve))
    solver = strip(get(ENV, "MPCC_STATIONARITY_DUAL_START_LP_HIGHS_SOLVER", ""))
    isempty(solver) || (optimizer_attributes["solver"] = String(solver))

    return (
        time_limit = time_limit,
        trace = trace,
        trace_every = trace_every,
        max_points = max_points,
        fail_fast = fail_fast,
        optimizer_attributes = optimizer_attributes,
    )
end

function _reduced_dcdfba_fixed_flux_dual_fit_complementarity_budget_fraction()::Float64
    name = "MPCC_FIXED_FLUX_DUAL_FIT_COMPLEMENTARITY_BUDGET_FRACTION"
    raw = strip(get(ENV, name, "0.5"))
    value = tryparse(Float64, raw)
    value === nothing && throw(
        ArgumentError("Environment variable $name must be a Float64, got: $raw"),
    )
    isfinite(value) && 0.0 < value <= 1.0 || throw(
        ArgumentError("Environment variable $name must be finite and in (0, 1], got: $value"),
    )
    return value
end

function _reduced_dcdfba_collocation_repair_start_options()
    trace =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE", false)
    restore_best =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_RESTORE_BEST", true)
    monotone =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MONOTONE", true)
    trace_substeps =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE_SUBSTEPS", false)
    final_state_refresh =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_REFRESH", false)
    final_flux_projection =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_FLUX_PROJECTION",
            false,
        )
    final_complementarity_flux_projection =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION",
            false,
        )
    final_complementarity_flux_projection_trigger_threshold =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION_TRIGGER_THRESHOLD",
            default_reduced_dcdfba_mpcc_residual_thresholds().max_lower_complementarity_residual,
        )
    final_dual_fit =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_DUAL_FIT",
            false,
        )
    final_selective_dual_fit =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT",
            false,
        )
    final_selective_dual_fit_trigger_threshold =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT_TRIGGER_THRESHOLD",
            default_reduced_dcdfba_mpcc_residual_thresholds().max_lower_complementarity_residual,
        )
    final_state_after_rhs =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS",
            false,
        )
    final_state_after_rhs_guard =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD",
            true,
        )
    final_state_after_rhs_acceptance_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_ACCEPT_TOL",
            0.0,
        )
    final_state_after_rhs_damping_factors =
        _reduced_dcdfba_env_positive_unit_float_vector(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_DAMPING_FACTORS",
            [1.0, 0.5, 0.25, 0.1, 0.05, 0.01],
        )
    final_state_after_rhs_refresh_rhs =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_REFRESH_RHS",
            false,
        )
    final_state_after_rhs_guard_score =
        lowercase(
            strip(
                get(
                    ENV,
                    "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD_SCORE",
                    "primal_structural",
                ),
            ),
        )
    final_state_after_rhs_guard_score in
    ("primal_structural", "full_raw", "full_threshold_ratio", "candidate_threshold_ratio") || throw(
        ArgumentError(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD_SCORE must be " *
            "primal_structural, full_raw, full_threshold_ratio, or candidate_threshold_ratio; got: " *
            final_state_after_rhs_guard_score,
        ),
    )
    repair_score_policy =
        lowercase(
            strip(
                get(
                    ENV,
                    "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SCORE",
                    "collocation_state",
                ),
            ),
        )
    repair_score_policy in
    (
        "collocation_state",
        "primal_structural",
        "full_raw",
        "full_threshold_ratio",
        "candidate_threshold_ratio",
    ) || throw(
        ArgumentError(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SCORE must be collocation_state, " *
            "primal_structural, full_raw, full_threshold_ratio, or candidate_threshold_ratio; got: " *
            repair_score_policy,
        ),
    )
    flux_refresh_guard =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD",
            false,
        )
    flux_refresh_guard_score =
        lowercase(
            strip(
                get(
                    ENV,
                    "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_SCORE",
                    "candidate_threshold_ratio",
                ),
            ),
        )
    flux_refresh_guard_score in
    ("primal_structural", "full_raw", "full_threshold_ratio", "candidate_threshold_ratio") || throw(
        ArgumentError(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_SCORE must be " *
            "primal_structural, full_raw, full_threshold_ratio, or candidate_threshold_ratio; got: " *
            flux_refresh_guard_score,
        ),
    )
    flux_refresh_guard_acceptance_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_ACCEPT_TOL",
            0.0,
        )
    flux_refresh_max_iterations =
        _reduced_dcdfba_env_nonnegative_int(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_MAX_ITER",
            0,
        )
    trace_every =
        max(
            1,
            _reduced_dcdfba_env_nonnegative_int(
                "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE_EVERY",
                1,
            ),
        )
    stagnation_iterations =
        _reduced_dcdfba_env_nonnegative_int(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_STAGNATION_ITERATIONS",
            0,
        )
    stagnation_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_STAGNATION_TOL",
            0.0,
        )
    monotone_acceptance_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MONOTONE_ACCEPT_TOL",
            0.0,
        )
    damping_factors =
        _reduced_dcdfba_env_positive_unit_float_vector(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_DAMPING_FACTORS",
            [1.0, 0.5, 0.25, 0.1, 0.05, 0.01],
        )
    post_tail_repair_enabled =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ENABLED",
            false,
        )
    post_tail_repair_elements_raw =
        strip(get(ENV, "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS", ""))
    post_tail_repair_acceptance_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ACCEPT_TOL",
            0.0,
        )
    post_tail_repair_guard_acceptance_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_GUARD_ACCEPT_TOL",
            0.0,
        )
    post_tail_repair_damping_factors =
        _reduced_dcdfba_env_positive_unit_float_vector(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_DAMPING_FACTORS",
            [1.0, 0.5, 0.25, 0.1, 0.05, 0.01],
        )
    post_tail_repair_refresh_dynamic_flux =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_REFRESH_DYNAMIC_FLUX",
            true,
        )
    post_tail_repair_guard_score =
        lowercase(
            strip(
                get(
                    ENV,
                    "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_GUARD_SCORE",
                    "candidate_threshold_ratio",
                ),
            ),
        )
    post_tail_repair_guard_score in
    ("primal_structural", "full_raw", "full_threshold_ratio", "candidate_threshold_ratio") || throw(
        ArgumentError(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_GUARD_SCORE must be " *
            "primal_structural, full_raw, full_threshold_ratio, or candidate_threshold_ratio; got: " *
            post_tail_repair_guard_score,
        ),
    )
    feasibility_projection_segments_raw =
        strip(get(ENV, "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_SEGMENTS", ""))
    feasibility_projection_enabled =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_ENABLED",
            false,
        ) || !isempty(feasibility_projection_segments_raw)
    feasibility_projection_acceptance_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_ACCEPT_TOL",
            0.0,
        )
    feasibility_projection_guard_acceptance_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_GUARD_ACCEPT_TOL",
            0.0,
        )
    feasibility_projection_damping_factors =
        _reduced_dcdfba_env_positive_unit_float_vector(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_DAMPING_FACTORS",
            [1.0, 0.5, 0.25, 0.1, 0.05, 0.01],
        )
    feasibility_projection_refresh_dynamic_flux =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_REFRESH_DYNAMIC_FLUX",
            false,
        )
    feasibility_projection_final_state_refresh =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_FINAL_STATE_REFRESH",
            true,
        )
    feasibility_projection_final_flux_projection =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_FINAL_FLUX_PROJECTION",
            true,
        )
    feasibility_projection_final_state_after_rhs =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_FINAL_STATE_AFTER_RHS",
            true,
        )
    feasibility_projection_final_state_after_rhs_refresh_rhs =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_FINAL_STATE_AFTER_RHS_REFRESH_RHS",
            true,
        )
    feasibility_projection_guard_score =
        lowercase(
            strip(
                get(
                    ENV,
                    "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_GUARD_SCORE",
                    "primal_structural",
                ),
            ),
        )
    feasibility_projection_guard_score in
    ("primal_structural", "full_raw", "full_threshold_ratio", "candidate_threshold_ratio") || throw(
        ArgumentError(
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_GUARD_SCORE must be " *
            "primal_structural, full_raw, full_threshold_ratio, or candidate_threshold_ratio; got: " *
            feasibility_projection_guard_score,
        ),
    )
    segmented_repair_segments_raw =
        strip(get(ENV, "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS", ""))
    segmented_repair_enabled =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_ENABLED",
            false,
        ) || !isempty(segmented_repair_segments_raw)
    segmented_repair_acceptance_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_ACCEPT_TOL",
            0.0,
        )
    segmented_repair_guard_acceptance_tolerance =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_GUARD_ACCEPT_TOL",
            0.0,
        )
    segmented_repair_damping_factors =
        _reduced_dcdfba_env_positive_unit_float_vector(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_DAMPING_FACTORS",
            [1.0, 0.5, 0.25, 0.1, 0.05, 0.01],
        )
    segmented_repair_refresh_dynamic_flux =
        _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_REFRESH_DYNAMIC_FLUX",
            true,
        )
    segmented_repair_guard_score =
        lowercase(
            strip(
                get(
                    ENV,
                    "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_GUARD_SCORE",
                    "candidate_threshold_ratio",
                ),
            ),
        )
    segmented_repair_guard_score in
    ("primal_structural", "full_raw", "full_threshold_ratio", "candidate_threshold_ratio") || throw(
        ArgumentError(
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_GUARD_SCORE must be " *
            "primal_structural, full_raw, full_threshold_ratio, or candidate_threshold_ratio; got: " *
            segmented_repair_guard_score,
        ),
    )
    return (
        trace = trace,
        restore_best = restore_best,
        monotone = monotone,
        trace_substeps = trace_substeps,
        final_state_refresh = final_state_refresh,
        final_flux_projection = final_flux_projection,
        final_complementarity_flux_projection = final_complementarity_flux_projection,
        final_complementarity_flux_projection_trigger_threshold =
            final_complementarity_flux_projection_trigger_threshold,
        final_dual_fit = final_dual_fit,
        final_selective_dual_fit = final_selective_dual_fit,
        final_selective_dual_fit_trigger_threshold =
            final_selective_dual_fit_trigger_threshold,
        final_state_after_rhs = final_state_after_rhs,
        final_state_after_rhs_guard = final_state_after_rhs_guard,
        final_state_after_rhs_acceptance_tolerance =
            final_state_after_rhs_acceptance_tolerance,
        final_state_after_rhs_damping_factors = final_state_after_rhs_damping_factors,
        final_state_after_rhs_refresh_rhs = final_state_after_rhs_refresh_rhs,
        final_state_after_rhs_guard_score = final_state_after_rhs_guard_score,
        repair_score_policy = repair_score_policy,
        flux_refresh_guard = flux_refresh_guard,
        flux_refresh_guard_score = flux_refresh_guard_score,
        flux_refresh_guard_acceptance_tolerance =
            flux_refresh_guard_acceptance_tolerance,
        flux_refresh_max_iterations = flux_refresh_max_iterations,
        trace_every = trace_every,
        damping_factors = damping_factors,
        monotone_acceptance_tolerance = monotone_acceptance_tolerance,
        stagnation_iterations = stagnation_iterations,
        stagnation_tolerance = stagnation_tolerance,
        stagnation_enabled = stagnation_iterations > 0 && stagnation_tolerance > 0.0,
        post_tail_repair_enabled = post_tail_repair_enabled,
        post_tail_repair_elements_raw = post_tail_repair_elements_raw,
        post_tail_repair_acceptance_tolerance = post_tail_repair_acceptance_tolerance,
        post_tail_repair_guard_acceptance_tolerance =
            post_tail_repair_guard_acceptance_tolerance,
        post_tail_repair_damping_factors = post_tail_repair_damping_factors,
        post_tail_repair_refresh_dynamic_flux = post_tail_repair_refresh_dynamic_flux,
        post_tail_repair_guard_score = post_tail_repair_guard_score,
        feasibility_projection_enabled = feasibility_projection_enabled,
        feasibility_projection_segments_raw = feasibility_projection_segments_raw,
        feasibility_projection_acceptance_tolerance =
            feasibility_projection_acceptance_tolerance,
        feasibility_projection_guard_acceptance_tolerance =
            feasibility_projection_guard_acceptance_tolerance,
        feasibility_projection_damping_factors = feasibility_projection_damping_factors,
        feasibility_projection_refresh_dynamic_flux =
            feasibility_projection_refresh_dynamic_flux,
        feasibility_projection_final_state_refresh =
            feasibility_projection_final_state_refresh,
        feasibility_projection_final_flux_projection =
            feasibility_projection_final_flux_projection,
        feasibility_projection_final_state_after_rhs =
            feasibility_projection_final_state_after_rhs,
        feasibility_projection_final_state_after_rhs_refresh_rhs =
            feasibility_projection_final_state_after_rhs_refresh_rhs,
        feasibility_projection_guard_score = feasibility_projection_guard_score,
        segmented_repair_enabled = segmented_repair_enabled,
        segmented_repair_segments_raw = segmented_repair_segments_raw,
        segmented_repair_acceptance_tolerance = segmented_repair_acceptance_tolerance,
        segmented_repair_guard_acceptance_tolerance =
            segmented_repair_guard_acceptance_tolerance,
        segmented_repair_damping_factors = segmented_repair_damping_factors,
        segmented_repair_refresh_dynamic_flux = segmented_repair_refresh_dynamic_flux,
        segmented_repair_guard_score = segmented_repair_guard_score,
    )
end

function _reduced_dcdfba_restore_mpcc_start_values!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    starts,
)::Nothing
    _reduced_dcdfba_mpcc_set_start_values!(
        problem.nlp.state_boundary,
        starts.state_boundary,
        "state_boundary",
    )
    _reduced_dcdfba_mpcc_set_start_values!(
        problem.nlp.state_collocation,
        starts.state_collocation,
        "state_collocation",
    )
    _reduced_dcdfba_mpcc_set_start_values!(
        problem.nlp.state_derivative,
        starts.state_derivative,
        "state_derivative",
    )
    _reduced_dcdfba_mpcc_set_start_values!(problem.nlp.flux, starts.flux, "flux")
    _reduced_dcdfba_mpcc_set_start_values!(
        problem.bound_feasibility.lower_bound_duals,
        starts.lower_dual,
        "lower_bound_duals",
    )
    _reduced_dcdfba_mpcc_set_start_values!(
        problem.bound_feasibility.upper_bound_duals,
        starts.upper_dual,
        "upper_bound_duals",
    )
    _reduced_dcdfba_mpcc_set_start_values!(
        problem.stationarity.mass_balance_duals,
        starts.mass_dual,
        "mass_balance_duals",
    )
    return nothing
end

function _reduced_dcdfba_apply_damped_state_start_update!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    baseline_starts,
    damping_factor::Float64,
)::Tuple{Float64, Float64}
    0.0 < damping_factor <= 1.0 || throw(
        ArgumentError("Reduced DC-dFBA collocation repair damping factor must be in (0, 1]."),
    )
    target_state_boundary =
        _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_boundary)
    target_state_collocation =
        _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    any(value -> value === nothing, (target_state_boundary, target_state_collocation)) &&
        throw(
            ArgumentError("Reduced DC-dFBA damped collocation repair requires finite target state starts."),
        )
    max_boundary_adjustment = 0.0
    max_collocation_adjustment = 0.0
    for index in eachindex(target_state_boundary)
        baseline = baseline_starts.state_boundary[index]
        value = baseline + damping_factor * (target_state_boundary[index] - baseline)
        max_boundary_adjustment = max(max_boundary_adjustment, abs(value - baseline))
        JuMP.set_start_value(problem.nlp.state_boundary[index], value)
    end
    for index in eachindex(target_state_collocation)
        baseline = baseline_starts.state_collocation[index]
        value = baseline + damping_factor * (target_state_collocation[index] - baseline)
        max_collocation_adjustment = max(max_collocation_adjustment, abs(value - baseline))
        JuMP.set_start_value(problem.nlp.state_collocation[index], value)
    end
    return max_collocation_adjustment, max_boundary_adjustment
end

function _reduced_dcdfba_collocation_repair_substep_summary(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    label::AbstractString,
    ;
    include_structural::Bool = false,
)::Dict{String, Any}
    residuals = _reduced_dcdfba_collocation_state_start_residual_summary(problem)
    summary = Dict{String, Any}(
        "label" => String(label),
        "collocation_residual" => residuals.collocation,
        "continuity_residual" => residuals.continuity,
        "rhs_residual" => residuals.rhs,
        "max_residual" => _reduced_dcdfba_collocation_state_start_residual_max(residuals),
    )
    if include_structural
        structural = _reduced_dcdfba_collocation_repair_structural_start_summary(problem)
        merge!(
            summary,
            Dict{String, Any}(
                "mass_balance_residual" => structural.max_mass_balance_residual,
                "lower_bound_violation" => structural.max_lower_bound_violation,
                "upper_bound_violation" => structural.max_upper_bound_violation,
                "stationarity_residual" => structural.max_stationarity_residual,
                "lower_complementarity_residual" =>
                    structural.max_lower_complementarity_residual,
                "upper_complementarity_residual" =>
                    structural.max_upper_complementarity_residual,
                "primal_structural_residual" => maximum(
                    filter(
                        isfinite,
                        [
                            residuals.collocation,
                            residuals.continuity,
                            residuals.rhs,
                            structural.max_mass_balance_residual,
                            structural.max_lower_bound_violation,
                            structural.max_upper_bound_violation,
                        ],
                    ),
                ),
            ),
        )
    end
    return summary
end

function _reduced_dcdfba_record_collocation_repair_substep!(
    summaries::Vector{Dict{String, Any}},
    problem::ReducedDCDFBAMPCCSmokeProblem,
    label::AbstractString,
    ;
    include_structural::Bool = false,
)::Dict{String, Any}
    summary = _reduced_dcdfba_collocation_repair_substep_summary(
        problem,
        label;
        include_structural = include_structural,
    )
    push!(summaries, summary)
    return summary
end

function _reduced_dcdfba_push_collocation_repair_substep_trace!(
    records::Vector{Dict{String, Any}},
    phase::AbstractString,
    iteration::Integer,
    trial_index::Integer,
    selected_elements,
    damping_factor::Real,
    accepted,
    trial,
)
    first_element = isempty(selected_elements) ? missing : first(selected_elements)
    last_element = isempty(selected_elements) ? missing : last(selected_elements)
    finite_element_count = length(selected_elements)
    for (substep_index, summary) in enumerate(trial.substep_summaries)
        summary isa AbstractDict || continue
        push!(
            records,
            Dict{String, Any}(
                "phase" => String(phase),
                "iteration" => Int(iteration),
                "trial_index" => Int(trial_index),
                "substep_index" => substep_index,
                "substep_label" => get(summary, "label", missing),
                "first_element" => first_element,
                "last_element" => last_element,
                "finite_element_count" => finite_element_count,
                "damping_factor" => Float64(damping_factor),
                "accepted" => accepted,
                "max_residual" => get(summary, "max_residual", missing),
                "collocation_residual" =>
                    get(summary, "collocation_residual", missing),
                "continuity_residual" => get(summary, "continuity_residual", missing),
                "rhs_residual" => get(summary, "rhs_residual", missing),
                "mass_balance_residual" =>
                    get(summary, "mass_balance_residual", missing),
                "lower_bound_violation" =>
                    get(summary, "lower_bound_violation", missing),
                "upper_bound_violation" =>
                    get(summary, "upper_bound_violation", missing),
                "stationarity_residual" =>
                    get(summary, "stationarity_residual", missing),
                "lower_complementarity_residual" =>
                    get(summary, "lower_complementarity_residual", missing),
                "upper_complementarity_residual" =>
                    get(summary, "upper_complementarity_residual", missing),
                "primal_structural_residual" =>
                    get(summary, "primal_structural_residual", missing),
                "dynamic_flux_refresh_applied" =>
                    trial.dynamic_flux_refresh_applied,
                "final_state_refresh_applied" => trial.final_state_refresh_applied,
                "final_flux_projection_applied" =>
                    trial.final_flux_projection_applied,
                "final_state_after_rhs_applied" =>
                    trial.final_state_after_rhs_applied,
            ),
        )
    end
    return records
end

function _reduced_dcdfba_collocation_repair_summary_float(
    summary::AbstractDict,
    key::AbstractString,
)::Float64
    value = get(summary, String(key), NaN)
    value isa Real || return NaN
    return Float64(value)
end

function _reduced_dcdfba_collocation_repair_primal_structural_residual(
    summary::AbstractDict,
)::Float64
    return _reduced_dcdfba_collocation_repair_summary_float(
        summary,
        "primal_structural_residual",
    )
end

function _reduced_dcdfba_collocation_repair_full_raw_residual(
    summary::AbstractDict,
)::Float64
    values = Float64[
        _reduced_dcdfba_collocation_repair_summary_float(summary, "collocation_residual"),
        _reduced_dcdfba_collocation_repair_summary_float(summary, "continuity_residual"),
        _reduced_dcdfba_collocation_repair_summary_float(summary, "rhs_residual"),
        _reduced_dcdfba_collocation_repair_summary_float(summary, "mass_balance_residual"),
        _reduced_dcdfba_collocation_repair_summary_float(summary, "lower_bound_violation"),
        _reduced_dcdfba_collocation_repair_summary_float(summary, "upper_bound_violation"),
        _reduced_dcdfba_collocation_repair_summary_float(summary, "stationarity_residual"),
        _reduced_dcdfba_collocation_repair_summary_float(
            summary,
            "lower_complementarity_residual",
        ),
        _reduced_dcdfba_collocation_repair_summary_float(
            summary,
            "upper_complementarity_residual",
        ),
    ]
    finite_values = filter(isfinite, values)
    return isempty(finite_values) ? NaN : maximum(finite_values)
end

function _reduced_dcdfba_collocation_repair_full_threshold_ratio(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    summary::AbstractDict,
)::Float64
    residuals = Dict{String, Float64}(
        "max_collocation_integration_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "collocation_residual"),
        "max_continuity_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "continuity_residual"),
        "max_rhs_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "rhs_residual"),
        "max_mass_balance_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "mass_balance_residual"),
        "max_lower_bound_violation" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "lower_bound_violation"),
        "max_upper_bound_violation" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "upper_bound_violation"),
        "max_stationarity_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "stationarity_residual"),
        "max_lower_complementarity_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                summary,
                "lower_complementarity_residual",
            ),
        "max_upper_complementarity_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                summary,
                "upper_complementarity_residual",
            ),
    )
    thresholds = _reduced_dcdfba_mpcc_threshold_values(
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    )
    ratios = _reduced_dcdfba_mpcc_residual_ratios(residuals, thresholds)
    finite_values = filter(isfinite, collect(values(ratios)))
    return isempty(finite_values) ? NaN : maximum(abs.(finite_values))
end

function _reduced_dcdfba_collocation_repair_candidate_threshold_ratio(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    summary::AbstractDict,
)::Float64
    residuals = Dict{String, Float64}(
        "max_rhs_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "rhs_residual"),
        "max_mass_balance_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "mass_balance_residual"),
        "max_lower_bound_violation" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "lower_bound_violation"),
        "max_upper_bound_violation" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "upper_bound_violation"),
        "max_stationarity_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(summary, "stationarity_residual"),
        "max_lower_complementarity_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                summary,
                "lower_complementarity_residual",
            ),
        "max_upper_complementarity_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                summary,
                "upper_complementarity_residual",
            ),
    )
    thresholds = _reduced_dcdfba_mpcc_effective_threshold_values(
        problem,
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    )
    ratios = _reduced_dcdfba_mpcc_residual_ratios(residuals, thresholds)
    finite_values = filter(isfinite, collect(values(ratios)))
    return isempty(finite_values) ? NaN : maximum(abs.(finite_values))
end

function _reduced_dcdfba_collocation_repair_guard_score(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    summary::AbstractDict,
    score_policy::AbstractString,
)::Float64
    policy = lowercase(strip(String(score_policy)))
    if policy == "collocation_state"
        return _reduced_dcdfba_collocation_repair_summary_float(summary, "max_residual")
    elseif policy == "primal_structural"
        return _reduced_dcdfba_collocation_repair_primal_structural_residual(summary)
    elseif policy == "full_raw"
        return _reduced_dcdfba_collocation_repair_full_raw_residual(summary)
    elseif policy == "full_threshold_ratio"
        return _reduced_dcdfba_collocation_repair_full_threshold_ratio(problem, summary)
    elseif policy == "candidate_threshold_ratio"
        return _reduced_dcdfba_collocation_repair_candidate_threshold_ratio(
            problem,
            summary,
        )
    end
    throw(ArgumentError("Unsupported collocation repair guard score policy: $score_policy."))
end

function _reduced_dcdfba_evaluate_final_state_after_rhs_guarded!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    substep_summaries::Vector{Dict{String, Any}},
    selected_elements,
    damping_factors::AbstractVector{<:Real},
    acceptance_tolerance::Real,
    ;
    iteration::Int = 0,
    outer_damping_factor::Real = 1.0,
    trace_substeps::Bool = false,
    refresh_rhs_after_state::Bool = false,
    score_policy::AbstractString = "primal_structural",
)
    baseline_starts = _reduced_dcdfba_mpcc_scaling_start_values(problem)
    before_summary = _reduced_dcdfba_record_collocation_repair_substep!(
        substep_summaries,
        problem,
        "before_final_state_after_rhs_guard",
        include_structural = true,
    )
    trace_substeps &&
        _reduced_dcdfba_print_collocation_repair_substep_trace(
            iteration,
            outer_damping_factor,
            before_summary,
        )

    before_structural =
        _reduced_dcdfba_collocation_repair_primal_structural_residual(before_summary)
    before_score =
        _reduced_dcdfba_collocation_repair_guard_score(problem, before_summary, score_policy)
    accepted = false
    accepted_damping_factor = missing
    accepted_summary = before_summary
    accepted_collocation_adjustment = 0.0
    accepted_boundary_adjustment = 0.0
    accepted_start_values = nothing
    best_score = before_score
    trial_count = 0
    last_rejected_damping_factor = missing
    last_rejected_score = NaN
    last_rejected_collocation = NaN
    last_rejected_lower_violation = NaN
    last_rejected_upper_violation = NaN
    last_rhs_refresh_metadata = Dict{String, Any}()

    for raw_factor in damping_factors
        factor = Float64(raw_factor)
        0.0 < factor <= 1.0 || throw(
            ArgumentError("Reduced DC-dFBA final-state-after-RHS damping factor must be in (0, 1]."),
        )
        trial_count += 1
        _reduced_dcdfba_restore_mpcc_start_values!(problem, baseline_starts)
        full_collocation_adjustment, full_boundary_adjustment =
            _reduced_dcdfba_set_collocation_consistent_state_starts!(
                problem;
                element_indices = selected_elements,
            )
        collocation_adjustment, boundary_adjustment =
            factor == 1.0 ?
            (full_collocation_adjustment, full_boundary_adjustment) :
            _reduced_dcdfba_apply_damped_state_start_update!(
                problem,
                baseline_starts,
                factor,
            )
        if refresh_rhs_after_state
            last_rhs_refresh_metadata = _reduced_dcdfba_apply_rhs_consistent_derivative_starts!(
                problem;
                element_indices = selected_elements,
            )
        end
        trial_summary = _reduced_dcdfba_record_collocation_repair_substep!(
            substep_summaries,
            problem,
            "after_final_state_after_rhs_guard_trial_damping_$factor",
            include_structural = true,
        )
        trace_substeps &&
            _reduced_dcdfba_print_collocation_repair_substep_trace(
                iteration,
                outer_damping_factor,
                trial_summary,
            )
        trial_structural =
            _reduced_dcdfba_collocation_repair_primal_structural_residual(trial_summary)
        trial_score =
            _reduced_dcdfba_collocation_repair_guard_score(problem, trial_summary, score_policy)
        if _reduced_dcdfba_collocation_repair_trial_accepted(
            trial_score,
            best_score,
            acceptance_tolerance,
        )
            accepted = true
            accepted_damping_factor = factor
            accepted_summary = trial_summary
            accepted_collocation_adjustment = collocation_adjustment
            accepted_boundary_adjustment = boundary_adjustment
            accepted_start_values = _reduced_dcdfba_mpcc_scaling_start_values(problem)
            best_score = trial_score
            continue
        end
        last_rejected_damping_factor = factor
        last_rejected_score = trial_score
        last_rejected_collocation =
            _reduced_dcdfba_collocation_repair_summary_float(
                trial_summary,
                "collocation_residual",
            )
        last_rejected_lower_violation =
            _reduced_dcdfba_collocation_repair_summary_float(
                trial_summary,
                "lower_bound_violation",
            )
        last_rejected_upper_violation =
            _reduced_dcdfba_collocation_repair_summary_float(
                trial_summary,
                "upper_bound_violation",
            )
    end

    if accepted
        _reduced_dcdfba_restore_mpcc_start_values!(problem, accepted_start_values)
    else
        _reduced_dcdfba_restore_mpcc_start_values!(problem, baseline_starts)
        restored_summary = _reduced_dcdfba_record_collocation_repair_substep!(
            substep_summaries,
            problem,
            "after_final_state_after_rhs_guard_rejected_restore",
            include_structural = true,
        )
        trace_substeps &&
            _reduced_dcdfba_print_collocation_repair_substep_trace(
                iteration,
                outer_damping_factor,
                restored_summary,
        )
        accepted_summary = restored_summary
    end

    after_structural =
        _reduced_dcdfba_collocation_repair_primal_structural_residual(accepted_summary)
    after_score =
        _reduced_dcdfba_collocation_repair_guard_score(problem, accepted_summary, score_policy)
    metadata = Dict{String, Any}(
        "collocation_consistent_state_start_final_state_after_rhs_guard_enabled" => true,
        "collocation_consistent_state_start_final_state_after_rhs_guard_policy" =>
            "select_best_damped_state_after_rhs_by_$score_policy",
        "collocation_consistent_state_start_final_state_after_rhs_guard_score_policy" =>
            String(score_policy),
        "collocation_consistent_state_start_final_state_after_rhs_guard_trial_count" =>
            trial_count,
        "collocation_consistent_state_start_final_state_after_rhs_guard_accepted" =>
            accepted,
        "collocation_consistent_state_start_final_state_after_rhs_guard_accepted_damping_factor" =>
            accepted_damping_factor,
        "collocation_consistent_state_start_final_state_after_rhs_guard_damping_factors" =>
            Float64.(damping_factors),
        "collocation_consistent_state_start_final_state_after_rhs_guard_acceptance_tolerance" =>
            Float64(acceptance_tolerance),
        "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_enabled" =>
            refresh_rhs_after_state,
        "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_policy" =>
            refresh_rhs_after_state ?
            "refresh_rhs_consistent_derivatives_after_each_damped_state_trial" :
            "disabled",
        "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_last_applied" =>
            get(last_rhs_refresh_metadata, "rhs_consistent_derivative_start_applied", false),
        "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_last_max_rhs_residual_after" =>
            get(
                last_rhs_refresh_metadata,
                "rhs_consistent_derivative_start_max_rhs_residual_after",
                NaN,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_primal_structural_residual" =>
            before_structural,
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_primal_structural_residual" =>
            after_structural,
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_score" =>
            before_score,
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_score" =>
            after_score,
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_collocation_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                before_summary,
                "collocation_residual",
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_collocation_residual" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                accepted_summary,
                "collocation_residual",
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_lower_bound_violation" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                before_summary,
                "lower_bound_violation",
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_lower_bound_violation" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                accepted_summary,
                "lower_bound_violation",
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_upper_bound_violation" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                before_summary,
                "upper_bound_violation",
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_upper_bound_violation" =>
            _reduced_dcdfba_collocation_repair_summary_float(
                accepted_summary,
                "upper_bound_violation",
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_last_rejected_damping_factor" =>
            last_rejected_damping_factor,
        "collocation_consistent_state_start_final_state_after_rhs_guard_last_rejected_score" =>
            last_rejected_score,
        "collocation_consistent_state_start_final_state_after_rhs_guard_last_rejected_collocation_residual" =>
            last_rejected_collocation,
        "collocation_consistent_state_start_final_state_after_rhs_guard_last_rejected_lower_bound_violation" =>
            last_rejected_lower_violation,
        "collocation_consistent_state_start_final_state_after_rhs_guard_last_rejected_upper_bound_violation" =>
            last_rejected_upper_violation,
    )
    return (
        accepted = accepted,
        damping_factor = accepted_damping_factor,
        collocation_adjustment = accepted_collocation_adjustment,
        boundary_adjustment = accepted_boundary_adjustment,
        before_summary = before_summary,
        after_summary = accepted_summary,
        metadata = metadata,
    )
end

function _reduced_dcdfba_collocation_repair_structural_start_summary(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)
    state_values = problem.dynamic_bounds === nothing ?
                   nothing :
                   _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    any(
        value -> value === nothing,
        (flux_values, lower_dual_values, upper_dual_values, mass_dual_values),
    ) && return (
        max_mass_balance_residual = NaN,
        max_lower_bound_violation = NaN,
        max_upper_bound_violation = NaN,
        max_stationarity_residual = NaN,
        max_lower_complementarity_residual = NaN,
        max_upper_complementarity_residual = NaN,
    )
    problem.dynamic_bounds !== nothing && state_values === nothing && return (
        max_mass_balance_residual = NaN,
        max_lower_bound_violation = NaN,
        max_upper_bound_violation = NaN,
        max_stationarity_residual = NaN,
        max_lower_complementarity_residual = NaN,
        max_upper_complementarity_residual = NaN,
    )
    return _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )
end

function _reduced_dcdfba_print_collocation_repair_substep_trace(
    iteration::Int,
    damping_factor::Real,
    summary::AbstractDict,
)::Nothing
    println(
        "collocation_repair_substep: iteration=$iteration damping_factor=$damping_factor label=$(summary["label"]) max_residual=$(summary["max_residual"]) collocation_residual=$(summary["collocation_residual"]) continuity_residual=$(summary["continuity_residual"]) rhs_residual=$(summary["rhs_residual"]) mass_residual=$(get(summary, "mass_balance_residual", missing)) lower_bound_violation=$(get(summary, "lower_bound_violation", missing)) upper_bound_violation=$(get(summary, "upper_bound_violation", missing)) stationarity_residual=$(get(summary, "stationarity_residual", missing)) primal_structural_residual=$(get(summary, "primal_structural_residual", missing))",
    )
    flush(stdout)
    return nothing
end

function _reduced_dcdfba_evaluate_collocation_repair_trial!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    baseline_starts,
    selected_elements,
    damping_factor::Float64,
    ;
    iteration::Int = 0,
    trace_substeps::Bool = false,
    final_state_refresh::Bool = false,
    final_flux_projection::Bool = false,
    final_complementarity_flux_projection::Bool = false,
    final_complementarity_flux_projection_trigger_threshold::Real =
        default_reduced_dcdfba_mpcc_residual_thresholds().max_lower_complementarity_residual,
    final_dual_fit::Bool = false,
    final_selective_dual_fit::Bool = false,
    final_selective_dual_fit_trigger_threshold::Real =
        default_reduced_dcdfba_mpcc_residual_thresholds().max_lower_complementarity_residual,
    final_state_after_rhs::Bool = false,
    final_state_after_rhs_guard::Bool = true,
    final_state_after_rhs_acceptance_tolerance::Real = 0.0,
    final_state_after_rhs_damping_factors::AbstractVector{<:Real} =
        [1.0, 0.5, 0.25, 0.1, 0.05, 0.01],
    final_state_after_rhs_refresh_rhs::Bool = false,
    final_state_after_rhs_guard_score::AbstractString = "primal_structural",
    repair_score_policy::AbstractString = "collocation_state",
    refresh_dynamic_flux::Bool = true,
    flux_refresh_guard::Bool = false,
    flux_refresh_guard_score::AbstractString = "candidate_threshold_ratio",
    flux_refresh_guard_acceptance_tolerance::Real = 0.0,
)
    _reduced_dcdfba_restore_mpcc_start_values!(problem, baseline_starts)
    substep_summaries = Dict{String, Any}[]
    full_collocation_adjustment, full_boundary_adjustment =
        _reduced_dcdfba_set_collocation_consistent_state_starts!(
            problem;
            element_indices = selected_elements,
        )
    collocation_adjustment, boundary_adjustment =
        damping_factor == 1.0 ?
        (full_collocation_adjustment, full_boundary_adjustment) :
        _reduced_dcdfba_apply_damped_state_start_update!(
            problem,
            baseline_starts,
            damping_factor,
        )
    state_summary = _reduced_dcdfba_record_collocation_repair_substep!(
        substep_summaries,
        problem,
        "after_state_update",
        include_structural = trace_substeps,
    )
    trace_substeps &&
        _reduced_dcdfba_print_collocation_repair_substep_trace(
            iteration,
            damping_factor,
            state_summary,
        )

    refresh_metadata = Dict{String, Any}()
    dynamic_flux_metadata = Dict{String, Any}()
    dynamic_flux_refresh_applied = false
    if refresh_dynamic_flux
        flux_refresh_baseline =
            flux_refresh_guard ? _reduced_dcdfba_mpcc_scaling_start_values(problem) : nothing
        flux_refresh_before_summary = nothing
        flux_refresh_before_score = NaN
        if flux_refresh_guard
            flux_refresh_before_summary =
                _reduced_dcdfba_record_collocation_repair_substep!(
                    substep_summaries,
                    problem,
                    "before_flux_refresh_guard",
                    include_structural = true,
                )
            trace_substeps &&
                _reduced_dcdfba_print_collocation_repair_substep_trace(
                    iteration,
                    damping_factor,
                    flux_refresh_before_summary,
                )
            flux_refresh_before_score =
                _reduced_dcdfba_collocation_repair_guard_score(
                    problem,
                    flux_refresh_before_summary,
                    flux_refresh_guard_score,
                )
        end
        dynamic_flux_metadata = _reduced_dcdfba_apply_dynamic_flux_lp_starts!(
            problem;
            element_indices = selected_elements,
        )
        merge!(refresh_metadata, dynamic_flux_metadata)
        dynamic_flux_summary = _reduced_dcdfba_record_collocation_repair_substep!(
            substep_summaries,
            problem,
            "after_dynamic_flux_lp",
            include_structural = trace_substeps,
        )
        trace_substeps &&
            _reduced_dcdfba_print_collocation_repair_substep_trace(
                iteration,
                damping_factor,
                dynamic_flux_summary,
            )

        projection_metadata = _reduced_dcdfba_project_dynamic_flux_starts!(
            problem;
            element_indices = selected_elements,
        )
        merge!(refresh_metadata, projection_metadata)
        projection_summary = _reduced_dcdfba_record_collocation_repair_substep!(
            substep_summaries,
            problem,
            "after_flux_projection",
            include_structural = trace_substeps,
        )
        trace_substeps &&
            _reduced_dcdfba_print_collocation_repair_substep_trace(
                iteration,
                damping_factor,
                projection_summary,
            )

        stationarity_metadata = _reduced_dcdfba_apply_stationarity_dual_starts!(
            problem;
            element_indices = selected_elements,
        )
        merge!(refresh_metadata, stationarity_metadata)
        stationarity_summary = _reduced_dcdfba_record_collocation_repair_substep!(
            substep_summaries,
            problem,
            "after_stationarity_duals",
            include_structural = trace_substeps,
        )
        trace_substeps &&
            _reduced_dcdfba_print_collocation_repair_substep_trace(
                iteration,
                damping_factor,
                stationarity_summary,
            )
        dynamic_flux_refresh_applied = true
        if flux_refresh_guard
            flux_refresh_after_summary =
                _reduced_dcdfba_record_collocation_repair_substep!(
                    substep_summaries,
                    problem,
                    "after_flux_refresh_guard",
                    include_structural = true,
                )
            trace_substeps &&
                _reduced_dcdfba_print_collocation_repair_substep_trace(
                    iteration,
                    damping_factor,
                    flux_refresh_after_summary,
                )
            flux_refresh_after_score =
                _reduced_dcdfba_collocation_repair_guard_score(
                    problem,
                    flux_refresh_after_summary,
                    flux_refresh_guard_score,
                )
            flux_refresh_guard_accepted =
                _reduced_dcdfba_collocation_repair_trial_not_worse(
                    flux_refresh_after_score,
                    flux_refresh_before_score,
                    flux_refresh_guard_acceptance_tolerance,
                )
            flux_guard_metadata = Dict{String, Any}(
                "collocation_consistent_state_start_flux_refresh_guard_enabled" => true,
                "collocation_consistent_state_start_flux_refresh_guard_score_policy" =>
                    String(flux_refresh_guard_score),
                "collocation_consistent_state_start_flux_refresh_guard_acceptance_tolerance" =>
                    Float64(flux_refresh_guard_acceptance_tolerance),
                "collocation_consistent_state_start_flux_refresh_guard_accepted" =>
                    flux_refresh_guard_accepted,
                "collocation_consistent_state_start_flux_refresh_guard_before_score" =>
                    flux_refresh_before_score,
                "collocation_consistent_state_start_flux_refresh_guard_after_score" =>
                    flux_refresh_after_score,
                "collocation_consistent_state_start_flux_refresh_guard_before_primal_structural_residual" =>
                    _reduced_dcdfba_collocation_repair_primal_structural_residual(
                        flux_refresh_before_summary,
                    ),
                "collocation_consistent_state_start_flux_refresh_guard_after_primal_structural_residual" =>
                    _reduced_dcdfba_collocation_repair_primal_structural_residual(
                        flux_refresh_after_summary,
                    ),
                "collocation_consistent_state_start_flux_refresh_guard_before_rhs_residual" =>
                    _reduced_dcdfba_collocation_repair_summary_float(
                        flux_refresh_before_summary,
                        "rhs_residual",
                    ),
                "collocation_consistent_state_start_flux_refresh_guard_after_rhs_residual" =>
                    _reduced_dcdfba_collocation_repair_summary_float(
                        flux_refresh_after_summary,
                        "rhs_residual",
                    ),
                "collocation_consistent_state_start_flux_refresh_guard_before_mass_balance_residual" =>
                    _reduced_dcdfba_collocation_repair_summary_float(
                        flux_refresh_before_summary,
                        "mass_balance_residual",
                    ),
                "collocation_consistent_state_start_flux_refresh_guard_after_mass_balance_residual" =>
                    _reduced_dcdfba_collocation_repair_summary_float(
                        flux_refresh_after_summary,
                        "mass_balance_residual",
                    ),
            )
            if !flux_refresh_guard_accepted
                _reduced_dcdfba_restore_mpcc_start_values!(problem, flux_refresh_baseline)
                dynamic_flux_refresh_applied = false
                flux_guard_metadata[
                    "collocation_consistent_state_start_flux_refresh_guard_policy"
                ] = "restore_baseline_when_flux_refresh_worsens_score"
                restored_flux_summary =
                    _reduced_dcdfba_record_collocation_repair_substep!(
                        substep_summaries,
                        problem,
                        "after_flux_refresh_guard_rejected_restore",
                        include_structural = true,
                    )
                trace_substeps &&
                    _reduced_dcdfba_print_collocation_repair_substep_trace(
                        iteration,
                        damping_factor,
                        restored_flux_summary,
                    )
                flux_guard_metadata[
                    "collocation_consistent_state_start_flux_refresh_guard_restored_score"
                ] = _reduced_dcdfba_collocation_repair_guard_score(
                    problem,
                    restored_flux_summary,
                    flux_refresh_guard_score,
                )
            else
                flux_guard_metadata[
                    "collocation_consistent_state_start_flux_refresh_guard_policy"
                ] = "accept_flux_refresh_when_score_not_worse"
                flux_guard_metadata[
                    "collocation_consistent_state_start_flux_refresh_guard_restored_score"
                ] = NaN
            end
            merge!(refresh_metadata, flux_guard_metadata)
            merge!(dynamic_flux_metadata, flux_guard_metadata)
        else
            flux_guard_metadata = Dict{String, Any}(
                "collocation_consistent_state_start_flux_refresh_guard_enabled" => false,
                "collocation_consistent_state_start_flux_refresh_guard_policy" =>
                    "disabled",
                "collocation_consistent_state_start_flux_refresh_guard_accepted" =>
                    missing,
            )
            merge!(refresh_metadata, flux_guard_metadata)
            merge!(dynamic_flux_metadata, flux_guard_metadata)
        end
    else
        dynamic_flux_metadata = Dict{String, Any}(
            "dynamic_flux_lp_start_applied" => false,
            "dynamic_flux_lp_start_policy" =>
                "skipped_by_collocation_repair_flux_refresh_iteration_cap",
            "dynamic_flux_lp_start_solve_attempt_count" => 0,
            "dynamic_flux_lp_start_total_solve_elapsed_seconds" => 0.0,
            "dynamic_flux_lp_start_max_solve_elapsed_seconds" => 0.0,
        )
        merge!(refresh_metadata, dynamic_flux_metadata)
        skipped_flux_summary = _reduced_dcdfba_record_collocation_repair_substep!(
            substep_summaries,
            problem,
            "after_dynamic_flux_lp_skipped",
            include_structural = trace_substeps,
        )
        trace_substeps &&
            _reduced_dcdfba_print_collocation_repair_substep_trace(
                iteration,
                damping_factor,
                skipped_flux_summary,
            )
        frozen_projection_metadata =
            _reduced_dcdfba_project_dynamic_flux_starts_mass_balanced!(
                problem;
                element_indices = selected_elements,
            )
        merge!(refresh_metadata, frozen_projection_metadata)
        frozen_projection_summary = _reduced_dcdfba_record_collocation_repair_substep!(
            substep_summaries,
            problem,
            "after_frozen_flux_mass_balanced_projection",
            include_structural = trace_substeps,
        )
        trace_substeps &&
            _reduced_dcdfba_print_collocation_repair_substep_trace(
                iteration,
                damping_factor,
                frozen_projection_summary,
            )
    end

    rhs_metadata = _reduced_dcdfba_apply_rhs_consistent_derivative_starts!(
        problem;
        element_indices = selected_elements,
    )
    merge!(refresh_metadata, rhs_metadata)
    rhs_summary = _reduced_dcdfba_record_collocation_repair_substep!(
        substep_summaries,
        problem,
        "after_rhs_derivatives",
        include_structural = trace_substeps,
    )
    trace_substeps &&
        _reduced_dcdfba_print_collocation_repair_substep_trace(
            iteration,
            damping_factor,
            rhs_summary,
        )

    final_state_collocation_adjustment = 0.0
    final_state_boundary_adjustment = 0.0
    final_state_after_rhs_applied = false
    final_complementarity_flux_projection_applied = false
    if final_state_refresh
        final_state_collocation_adjustment, final_state_boundary_adjustment =
            _reduced_dcdfba_set_collocation_consistent_state_starts!(
                problem;
                element_indices = selected_elements,
            )
        collocation_adjustment =
            max(collocation_adjustment, final_state_collocation_adjustment)
        boundary_adjustment = max(boundary_adjustment, final_state_boundary_adjustment)
        final_state_summary = _reduced_dcdfba_record_collocation_repair_substep!(
            substep_summaries,
            problem,
            "after_final_state_update",
            include_structural = trace_substeps,
        )
        trace_substeps &&
            _reduced_dcdfba_print_collocation_repair_substep_trace(
                iteration,
                damping_factor,
                final_state_summary,
            )
        if final_flux_projection
            final_projection_metadata =
                _reduced_dcdfba_project_dynamic_flux_starts_mass_balanced!(
                problem;
                element_indices = selected_elements,
            )
            merge!(refresh_metadata, final_projection_metadata)
            final_projection_summary = _reduced_dcdfba_record_collocation_repair_substep!(
                substep_summaries,
                problem,
                "after_final_mass_balanced_flux_projection",
                include_structural = trace_substeps,
            )
            trace_substeps &&
                _reduced_dcdfba_print_collocation_repair_substep_trace(
                    iteration,
                    damping_factor,
                    final_projection_summary,
                )

            if final_complementarity_flux_projection
                complementarity_projection_baseline =
                    _reduced_dcdfba_mpcc_scaling_start_values(problem)
                complementarity_projection_before_summary =
                    _reduced_dcdfba_record_collocation_repair_substep!(
                        substep_summaries,
                        problem,
                        "before_final_active_complementarity_flux_projection_guard",
                        include_structural = true,
                    )
                complementarity_projection_before_score =
                    _reduced_dcdfba_collocation_repair_guard_score(
                        problem,
                        complementarity_projection_before_summary,
                        "candidate_threshold_ratio",
                    )
                final_complementarity_projection_metadata =
                    _reduced_dcdfba_project_active_complementarity_flux_starts!(
                        problem;
                        element_indices = selected_elements,
                        complementarity_trigger_threshold =
                            final_complementarity_flux_projection_trigger_threshold,
                    )
                final_complementarity_flux_projection_applied =
                    get(
                        final_complementarity_projection_metadata,
                        "active_complementarity_flux_projection_applied",
                        false,
                    ) === true
                final_complementarity_projection_summary =
                    _reduced_dcdfba_record_collocation_repair_substep!(
                        substep_summaries,
                        problem,
                        "after_final_active_complementarity_flux_projection",
                        include_structural = true,
                    )
                complementarity_projection_after_score =
                    _reduced_dcdfba_collocation_repair_guard_score(
                        problem,
                        final_complementarity_projection_summary,
                        "candidate_threshold_ratio",
                    )
                complementarity_projection_guard_accepted =
                    _reduced_dcdfba_collocation_repair_trial_accepted(
                        complementarity_projection_after_score,
                        complementarity_projection_before_score,
                        0.0,
                    )
                if !complementarity_projection_guard_accepted
                    _reduced_dcdfba_restore_mpcc_start_values!(
                        problem,
                        complementarity_projection_baseline,
                    )
                    final_complementarity_flux_projection_applied = false
                    final_complementarity_projection_metadata[
                        "active_complementarity_flux_projection_applied"
                    ] = false
                    final_complementarity_projection_metadata[
                        "active_complementarity_flux_projection_policy"
                    ] = "guard_rejected_restore_candidate_threshold_ratio"
                    restored_complementarity_projection_summary =
                        _reduced_dcdfba_record_collocation_repair_substep!(
                            substep_summaries,
                            problem,
                            "after_final_active_complementarity_flux_projection_guard_rejected_restore",
                            include_structural = true,
                        )
                    final_complementarity_projection_summary =
                        restored_complementarity_projection_summary
                    complementarity_projection_after_score =
                        _reduced_dcdfba_collocation_repair_guard_score(
                            problem,
                            final_complementarity_projection_summary,
                            "candidate_threshold_ratio",
                        )
                end
                merge!(refresh_metadata, final_complementarity_projection_metadata)
                merge!(
                    refresh_metadata,
                    Dict{String, Any}(
                        "active_complementarity_flux_projection_guard_enabled" =>
                            true,
                        "active_complementarity_flux_projection_guard_score_policy" =>
                            "candidate_threshold_ratio",
                        "active_complementarity_flux_projection_guard_accepted" =>
                            complementarity_projection_guard_accepted,
                        "active_complementarity_flux_projection_guard_before_score" =>
                            complementarity_projection_before_score,
                        "active_complementarity_flux_projection_guard_after_score" =>
                            complementarity_projection_after_score,
                        "active_complementarity_flux_projection_guard_before_collocation_residual" =>
                            _reduced_dcdfba_collocation_repair_summary_float(
                                complementarity_projection_before_summary,
                                "collocation_residual",
                            ),
                        "active_complementarity_flux_projection_guard_after_collocation_residual" =>
                            _reduced_dcdfba_collocation_repair_summary_float(
                                final_complementarity_projection_summary,
                                "collocation_residual",
                            ),
                        "active_complementarity_flux_projection_guard_before_lower_complementarity_residual" =>
                            _reduced_dcdfba_collocation_repair_summary_float(
                                complementarity_projection_before_summary,
                                "lower_complementarity_residual",
                            ),
                        "active_complementarity_flux_projection_guard_after_lower_complementarity_residual" =>
                            _reduced_dcdfba_collocation_repair_summary_float(
                                final_complementarity_projection_summary,
                                "lower_complementarity_residual",
                            ),
                    ),
                )
                trace_substeps &&
                    _reduced_dcdfba_print_collocation_repair_substep_trace(
                        iteration,
                        damping_factor,
                        final_complementarity_projection_summary,
                    )
            else
                refresh_metadata[
                    "active_complementarity_flux_projection_applied"
                ] = false
                refresh_metadata[
                    "active_complementarity_flux_projection_policy"
                ] = "disabled"
                refresh_metadata[
                    "active_complementarity_flux_projection_guard_enabled"
                ] = false
            end

            if final_dual_fit
                final_dual_fit_metadata =
                    _reduced_dcdfba_apply_fixed_flux_stationarity_dual_fit_starts!(
                        problem;
                        element_indices = selected_elements,
                    )
                merge!(refresh_metadata, final_dual_fit_metadata)
                final_dual_fit_summary = _reduced_dcdfba_record_collocation_repair_substep!(
                    substep_summaries,
                    problem,
                    "after_final_fixed_flux_dual_fit",
                    include_structural = trace_substeps,
                )
                trace_substeps &&
                    _reduced_dcdfba_print_collocation_repair_substep_trace(
                        iteration,
                        damping_factor,
                        final_dual_fit_summary,
                    )
            else
                refresh_metadata[
                    "collocation_consistent_state_start_final_dual_fit_applied"
                ] = false
            end

            final_rhs_metadata = _reduced_dcdfba_apply_rhs_consistent_derivative_starts!(
                problem;
                element_indices = selected_elements,
            )
            merge!(refresh_metadata, final_rhs_metadata)
            final_rhs_summary = _reduced_dcdfba_record_collocation_repair_substep!(
                substep_summaries,
                problem,
                "after_final_rhs_derivatives",
                include_structural = trace_substeps,
            )
            trace_substeps &&
                _reduced_dcdfba_print_collocation_repair_substep_trace(
                    iteration,
                    damping_factor,
                    final_rhs_summary,
                )

            if final_state_after_rhs
                if final_state_after_rhs_guard
                    final_after_rhs_trial =
                        _reduced_dcdfba_evaluate_final_state_after_rhs_guarded!(
                            problem,
                            substep_summaries,
                            selected_elements,
                            final_state_after_rhs_damping_factors,
                            final_state_after_rhs_acceptance_tolerance;
                            iteration = iteration,
                            outer_damping_factor = damping_factor,
                            trace_substeps = trace_substeps,
                            refresh_rhs_after_state = final_state_after_rhs_refresh_rhs,
                            score_policy = final_state_after_rhs_guard_score,
                        )
                    merge!(refresh_metadata, final_after_rhs_trial.metadata)
                    final_state_after_rhs_applied = final_after_rhs_trial.accepted
                    final_after_rhs_collocation_adjustment =
                        final_after_rhs_trial.collocation_adjustment
                    final_after_rhs_boundary_adjustment =
                        final_after_rhs_trial.boundary_adjustment
                else
                    final_after_rhs_collocation_adjustment, final_after_rhs_boundary_adjustment =
                        _reduced_dcdfba_set_collocation_consistent_state_starts!(
                        problem;
                        element_indices = selected_elements,
                    )
                    final_state_after_rhs_applied = true
                    refresh_metadata[
                        "collocation_consistent_state_start_final_state_after_rhs_guard_enabled"
                    ] = false
                    refresh_metadata[
                        "collocation_consistent_state_start_final_state_after_rhs_guard_policy"
                    ] = "disabled_legacy_unconditional_state_after_rhs_update"
                    final_state_after_rhs_summary =
                        _reduced_dcdfba_record_collocation_repair_substep!(
                            substep_summaries,
                            problem,
                            "after_final_state_after_rhs_update",
                            include_structural = trace_substeps,
                        )
                    trace_substeps &&
                        _reduced_dcdfba_print_collocation_repair_substep_trace(
                            iteration,
                            damping_factor,
                            final_state_after_rhs_summary,
                        )
                end
                collocation_adjustment =
                    max(collocation_adjustment, final_after_rhs_collocation_adjustment)
                boundary_adjustment = max(boundary_adjustment, final_after_rhs_boundary_adjustment)
                final_state_collocation_adjustment = max(
                    final_state_collocation_adjustment,
                    final_after_rhs_collocation_adjustment,
                )
                final_state_boundary_adjustment = max(
                    final_state_boundary_adjustment,
                    final_after_rhs_boundary_adjustment,
                )
            end
        end
    end

    final_selective_dual_fit_applied = false
    if final_selective_dual_fit
        final_selective_dual_fit_metadata =
            _reduced_dcdfba_apply_selective_fixed_flux_stationarity_dual_fit_starts!(
                problem;
                element_indices = selected_elements,
                complementarity_trigger_threshold =
                    final_selective_dual_fit_trigger_threshold,
            )
        merge!(refresh_metadata, final_selective_dual_fit_metadata)
        final_selective_dual_fit_applied =
            get(
                final_selective_dual_fit_metadata,
                "selective_fixed_flux_stationarity_dual_fit_applied",
                false,
            ) === true
        final_selective_dual_fit_summary =
            _reduced_dcdfba_record_collocation_repair_substep!(
                substep_summaries,
                problem,
                "after_final_selective_fixed_flux_dual_fit",
                include_structural = trace_substeps,
            )
        trace_substeps &&
            _reduced_dcdfba_print_collocation_repair_substep_trace(
                iteration,
                damping_factor,
                final_selective_dual_fit_summary,
            )
    end

    residuals = _reduced_dcdfba_collocation_state_start_residual_summary(problem)
    residual_max = _reduced_dcdfba_collocation_state_start_residual_max(residuals)
    score_policy = lowercase(strip(String(repair_score_policy)))
    final_summary = _reduced_dcdfba_collocation_repair_substep_summary(
        problem,
        "after_trial_final_score";
        include_structural = score_policy != "collocation_state",
    )
    repair_score =
        _reduced_dcdfba_collocation_repair_guard_score(
            problem,
            final_summary,
            score_policy,
        )
    return (
        damping_factor = damping_factor,
        collocation_adjustment = collocation_adjustment,
        boundary_adjustment = boundary_adjustment,
        residuals = residuals,
        residual_max = residual_max,
        repair_score = repair_score,
        refresh_metadata = refresh_metadata,
        dynamic_flux_metadata = dynamic_flux_metadata,
        substep_summaries = substep_summaries,
        final_state_refresh_applied = final_state_refresh,
        final_flux_projection_applied = final_state_refresh && final_flux_projection,
        final_dual_fit_applied = final_state_refresh && final_flux_projection && final_dual_fit,
        final_complementarity_flux_projection_applied =
            final_complementarity_flux_projection_applied,
        final_selective_dual_fit_applied = final_selective_dual_fit_applied,
        final_state_after_rhs_applied = final_state_after_rhs_applied,
        dynamic_flux_refresh_applied = dynamic_flux_refresh_applied,
        final_state_collocation_adjustment = final_state_collocation_adjustment,
        final_state_boundary_adjustment = final_state_boundary_adjustment,
    )
end

function _reduced_dcdfba_collocation_repair_trial_accepted(
    residual_max::Real,
    previous_residual_max::Real,
    acceptance_tolerance::Real,
)::Bool
    isfinite(residual_max) || return false
    isfinite(previous_residual_max) || return true
    return residual_max < previous_residual_max - acceptance_tolerance
end

function _reduced_dcdfba_collocation_repair_trial_not_worse(
    residual_max::Real,
    previous_residual_max::Real,
    acceptance_tolerance::Real,
)::Bool
    isfinite(residual_max) || return false
    isfinite(previous_residual_max) || return true
    return residual_max <= previous_residual_max + acceptance_tolerance
end

function _reduced_dcdfba_apply_dynamic_flux_lp_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    ;
    element_indices = nothing,
)::Dict{String, Any}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    problem.dynamic_bounds === nothing && return Dict{String, Any}(
        "dynamic_flux_lp_start_applied" => false,
        "dynamic_flux_lp_start_policy" => "not_applied_no_dynamic_bounds",
        "dynamic_flux_lp_start_finite_element_count" => length(selected_elements),
        "dynamic_flux_lp_start_collocation_points" => 0,
        "dynamic_flux_lp_start_optimal_count" => 0,
        "dynamic_flux_lp_start_max_mass_balance_residual" => 0.0,
        "dynamic_flux_lp_start_max_lower_bound_violation" => 0.0,
        "dynamic_flux_lp_start_max_upper_bound_violation" => 0.0,
        "dynamic_flux_lp_start_max_adjustment_from_previous" => 0.0,
    )

    state_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    previous_flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    state_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA dynamic local FBA flux starts require finite state start values."),
    )
    previous_flux_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA dynamic local FBA flux starts require finite flux start values."),
    )

    model = problem.nlp.kkt_problem.model
    reaction_map = problem.nlp.kkt_problem.reaction_map
    params = problem.nlp.kkt_problem.params
    n_reactions = problem.nlp.dimensions.n_reactions
    nfe = problem.nlp.dimensions.nfe
    degree = problem.nlp.dimensions.collocation_degree
    options = _reduced_dcdfba_dynamic_flux_lp_start_options()

    status_counts = Dict{String, Int}()
    collocation_points = 0
    solve_attempt_count = 0
    optimal_count = 0
    max_mass_balance_residual = 0.0
    max_lower_bound_violation = 0.0
    max_upper_bound_violation = 0.0
    max_adjustment = 0.0
    max_solve_elapsed = 0.0
    total_solve_elapsed = 0.0
    slowest_element_index = missing
    slowest_collocation_index = missing
    slowest_ordinal = missing
    slowest_status = missing
    first_nonoptimal_element_index = missing
    first_nonoptimal_collocation_index = missing
    first_nonoptimal_ordinal = missing
    first_nonoptimal_status = missing
    last_attempt_element_index = missing
    last_attempt_collocation_index = missing
    last_attempt_ordinal = missing
    invalid_bound_pair_count = 0
    max_invalid_bound_gap = 0.0
    min_objective_value = Inf
    max_objective_value = -Inf
    truncated_by_max_points = false

    for e in selected_elements, j in 1:degree
        if options.max_points > 0 && solve_attempt_count >= options.max_points
            truncated_by_max_points = true
            break
        end
        collocation_points += 1
        local_bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, state_values)
        crossing = _reduced_dcdfba_bound_crossing_summary(local_bounds.lb, local_bounds.ub)
        if crossing.count > 0
            status_counts["INVALID_BOUNDS"] = get(status_counts, "INVALID_BOUNDS", 0) + 1
            invalid_bound_pair_count += crossing.count
            max_invalid_bound_gap = max(max_invalid_bound_gap, crossing.max_gap)
            continue
        end
        local_model = MetabolicModel(
            model.S,
            local_bounds.lb,
            local_bounds.ub,
            model.rxn_ids,
            model.met_ids;
            model_id = model.model_id,
        )
        objective_weights =
            _reduced_dcdfba_dynamic_flux_lp_start_objective_weights(problem, e, j, state_values)
        solve_attempt_count += 1
        last_attempt_element_index = e
        last_attempt_collocation_index = j
        last_attempt_ordinal = solve_attempt_count
        if options.trace &&
           (solve_attempt_count == 1 || solve_attempt_count % options.trace_every == 0)
            println(
                "dynamic_flux_lp_start_begin: ordinal=$solve_attempt_count element=$e collocation=$j time_limit=$(options.time_limit === nothing ? "missing" : options.time_limit)",
            )
            flush(stdout)
        end

        started_at = time()
        result = solve_fba(
            local_model;
            objective_weights = objective_weights,
            optimizer_attributes = options.optimizer_attributes,
        )
        solve_elapsed = time() - started_at

        status_key = string(result.status)
        status_counts[status_key] = get(status_counts, status_key, 0) + 1
        max_solve_elapsed < solve_elapsed && begin
            max_solve_elapsed = solve_elapsed
            slowest_element_index = e
            slowest_collocation_index = j
            slowest_ordinal = solve_attempt_count
            slowest_status = status_key
        end
        total_solve_elapsed += solve_elapsed
        if options.trace
            println(
                "dynamic_flux_lp_start_end: ordinal=$solve_attempt_count element=$e collocation=$j status=$status_key elapsed_seconds=$(round(solve_elapsed; digits = 6)) objective=$(result.objective_value)",
            )
            flush(stdout)
        end
        if result.status != MOI.OPTIMAL
            if first_nonoptimal_element_index === missing
                first_nonoptimal_element_index = e
                first_nonoptimal_collocation_index = j
                first_nonoptimal_ordinal = solve_attempt_count
                first_nonoptimal_status = status_key
            end
            options.fail_fast && throw(
                ArgumentError(
                    "Reduced DC-dFBA dynamic local FBA flux start failed at element=$e collocation=$j ordinal=$solve_attempt_count with status $status_key after $(round(solve_elapsed; digits = 6)) seconds.",
                ),
            )
            continue
        end
        length(result.fluxes) == n_reactions || throw(
            ArgumentError("Reduced DC-dFBA dynamic local FBA flux start returned an incomplete flux vector."),
        )

        optimal_count += 1
        max_mass_balance_residual = max(max_mass_balance_residual, result.mass_balance_residual)
        max_lower_bound_violation = max(max_lower_bound_violation, result.max_lower_bound_violation)
        max_upper_bound_violation = max(max_upper_bound_violation, result.max_upper_bound_violation)
        min_objective_value = min(min_objective_value, result.objective_value)
        max_objective_value = max(max_objective_value, result.objective_value)

        for r in 1:n_reactions
            value = Float64(result.fluxes[r])
            max_adjustment = max(max_adjustment, abs(value - previous_flux_values[r, e, j]))
            JuMP.set_start_value(problem.nlp.flux[r, e, j], value)
            previous_flux_values[r, e, j] = value
        end
    end

    return Dict{String, Any}(
        "dynamic_flux_lp_start_applied" => true,
        "dynamic_flux_lp_start_policy" =>
            "solve_weighted_local_fba_at_each_collocation_point",
        "dynamic_flux_lp_start_finite_element_count" => length(selected_elements),
        "dynamic_flux_lp_start_collocation_points" => collocation_points,
        "dynamic_flux_lp_start_solve_attempt_count" => solve_attempt_count,
        "dynamic_flux_lp_start_optimal_count" => optimal_count,
        "dynamic_flux_lp_start_status_counts" => status_counts,
        "dynamic_flux_lp_start_solver" => "HiGHS",
        "dynamic_flux_lp_start_optimizer_attributes" => options.optimizer_attributes,
        "dynamic_flux_lp_start_time_limit_seconds" =>
            options.time_limit === nothing ? missing : options.time_limit,
        "dynamic_flux_lp_start_trace_enabled" => options.trace,
        "dynamic_flux_lp_start_trace_every" => options.trace_every,
        "dynamic_flux_lp_start_max_points" => options.max_points,
        "dynamic_flux_lp_start_truncated_by_max_points" => truncated_by_max_points,
        "dynamic_flux_lp_start_fail_fast" => options.fail_fast,
        "dynamic_flux_lp_start_total_solve_elapsed_seconds" => total_solve_elapsed,
        "dynamic_flux_lp_start_max_solve_elapsed_seconds" => max_solve_elapsed,
        "dynamic_flux_lp_start_slowest_element_index" => slowest_element_index,
        "dynamic_flux_lp_start_slowest_collocation_index" => slowest_collocation_index,
        "dynamic_flux_lp_start_slowest_ordinal" => slowest_ordinal,
        "dynamic_flux_lp_start_slowest_status" => slowest_status,
        "dynamic_flux_lp_start_first_nonoptimal_element_index" =>
            first_nonoptimal_element_index,
        "dynamic_flux_lp_start_first_nonoptimal_collocation_index" =>
            first_nonoptimal_collocation_index,
        "dynamic_flux_lp_start_first_nonoptimal_ordinal" => first_nonoptimal_ordinal,
        "dynamic_flux_lp_start_first_nonoptimal_status" => first_nonoptimal_status,
        "dynamic_flux_lp_start_last_attempt_element_index" => last_attempt_element_index,
        "dynamic_flux_lp_start_last_attempt_collocation_index" =>
            last_attempt_collocation_index,
        "dynamic_flux_lp_start_last_attempt_ordinal" => last_attempt_ordinal,
        "dynamic_flux_lp_start_objective_policy" =>
            problem.dynamic_bounds.mode == :smooth_phase ?
            "smooth_phase_objective_weights_at_collocation_state" :
            "zenteno_dynamic_objective_weights_at_collocation_state",
        "dynamic_flux_lp_start_objective_value_min" =>
            isfinite(min_objective_value) ? min_objective_value : missing,
        "dynamic_flux_lp_start_objective_value_max" =>
            isfinite(max_objective_value) ? max_objective_value : missing,
        "dynamic_flux_lp_start_invalid_bound_point_count" =>
            get(status_counts, "INVALID_BOUNDS", 0),
        "dynamic_flux_lp_start_invalid_bound_pair_count" => invalid_bound_pair_count,
        "dynamic_flux_lp_start_max_invalid_bound_gap" => max_invalid_bound_gap,
        "dynamic_flux_lp_start_objective_value_is_biomass_flux" => false,
        "dynamic_flux_lp_start_max_mass_balance_residual" => max_mass_balance_residual,
        "dynamic_flux_lp_start_max_lower_bound_violation" => max_lower_bound_violation,
        "dynamic_flux_lp_start_max_upper_bound_violation" => max_upper_bound_violation,
        "dynamic_flux_lp_start_max_adjustment_from_previous" => max_adjustment,
        "dynamic_flux_lp_start_indices_reacciones_used" => false,
        "dynamic_flux_lp_start_r0001_used_as_oxygen" => false,
    )
end

function _reduced_dcdfba_project_dynamic_flux_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    ;
    element_indices = nothing,
)::Dict{String, Any}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    problem.dynamic_bounds === nothing && return Dict{String, Any}(
        "dynamic_flux_start_projection_applied" => false,
        "dynamic_flux_start_projection_policy" => "not_applied_no_dynamic_bounds",
        "dynamic_flux_start_projection_finite_element_count" => length(selected_elements),
        "dynamic_flux_start_projection_checked_points" => 0,
        "dynamic_flux_start_projection_changed_count" => 0,
        "dynamic_flux_start_projection_changed_fraction" => 0.0,
        "dynamic_flux_start_projection_max_adjustment" => 0.0,
        "dynamic_flux_start_projection_max_lower_bound_violation_before" => 0.0,
        "dynamic_flux_start_projection_max_lower_bound_violation_after" => 0.0,
        "dynamic_flux_start_projection_max_upper_bound_violation_before" => 0.0,
        "dynamic_flux_start_projection_max_upper_bound_violation_after" => 0.0,
    )

    state_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    state_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA dynamic flux-start projection requires finite state start values."),
    )
    flux_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA dynamic flux-start projection requires finite flux start values."),
    )

    changed_count = 0
    checked_points = 0
    max_adjustment = 0.0
    max_lower_before = 0.0
    max_lower_after = 0.0
    max_upper_before = 0.0
    max_upper_after = 0.0
    tolerance = 100.0 * eps(Float64)

    for e in selected_elements, j in 1:problem.nlp.dimensions.collocation_degree
        bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, state_values)
        all(bounds.lb .<= bounds.ub .+ tolerance) || throw(
            ArgumentError("Reduced DC-dFBA dynamic flux-start projection found lower bounds above upper bounds."),
        )
        for r in 1:problem.nlp.dimensions.n_reactions
            checked_points += 1
            raw_value = flux_values[r, e, j]
            lower_bound = bounds.lb[r]
            upper_bound = bounds.ub[r]
            max_lower_before = max(max_lower_before, max(lower_bound - raw_value, 0.0))
            max_upper_before = max(max_upper_before, max(raw_value - upper_bound, 0.0))

            projected_value = clamp(raw_value, lower_bound, upper_bound)
            adjustment = abs(projected_value - raw_value)
            if adjustment > tolerance
                changed_count += 1
                max_adjustment = max(max_adjustment, adjustment)
                JuMP.set_start_value(problem.nlp.flux[r, e, j], projected_value)
                flux_values[r, e, j] = projected_value
            end

            max_lower_after = max(max_lower_after, max(lower_bound - projected_value, 0.0))
            max_upper_after = max(max_upper_after, max(projected_value - upper_bound, 0.0))
        end
    end

    return Dict{String, Any}(
        "dynamic_flux_start_projection_applied" => true,
        "dynamic_flux_start_projection_policy" =>
            "clamp_flux_start_values_to_numeric_dynamic_or_base_bounds",
        "dynamic_flux_start_projection_finite_element_count" => length(selected_elements),
        "dynamic_flux_start_projection_checked_points" => checked_points,
        "dynamic_flux_start_projection_changed_count" => changed_count,
        "dynamic_flux_start_projection_changed_fraction" =>
            checked_points == 0 ? 0.0 : changed_count / checked_points,
        "dynamic_flux_start_projection_max_adjustment" => max_adjustment,
        "dynamic_flux_start_projection_max_lower_bound_violation_before" => max_lower_before,
        "dynamic_flux_start_projection_max_lower_bound_violation_after" => max_lower_after,
        "dynamic_flux_start_projection_max_upper_bound_violation_before" => max_upper_before,
        "dynamic_flux_start_projection_max_upper_bound_violation_after" => max_upper_after,
    )
end

function _reduced_dcdfba_project_dynamic_flux_starts_mass_balanced!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    ;
    element_indices = nothing,
)::Dict{String, Any}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    problem.dynamic_bounds === nothing && return Dict{String, Any}(
        "dynamic_flux_start_mass_balanced_projection_applied" => false,
        "dynamic_flux_start_mass_balanced_projection_policy" =>
            "not_applied_no_dynamic_bounds",
        "dynamic_flux_start_mass_balanced_projection_finite_element_count" =>
            length(selected_elements),
        "dynamic_flux_start_mass_balanced_projection_checked_points" => 0,
        "dynamic_flux_start_mass_balanced_projection_solve_attempt_count" => 0,
        "dynamic_flux_start_mass_balanced_projection_optimal_count" => 0,
        "dynamic_flux_start_mass_balanced_projection_max_adjustment" => 0.0,
        "dynamic_flux_start_mass_balanced_projection_max_l1_adjustment" => 0.0,
        "dynamic_flux_start_mass_balanced_projection_max_mass_balance_residual_before" => 0.0,
        "dynamic_flux_start_mass_balanced_projection_max_mass_balance_residual_after" => 0.0,
        "dynamic_flux_start_mass_balanced_projection_max_lower_bound_violation_before" => 0.0,
        "dynamic_flux_start_mass_balanced_projection_max_lower_bound_violation_after" => 0.0,
        "dynamic_flux_start_mass_balanced_projection_max_upper_bound_violation_before" => 0.0,
        "dynamic_flux_start_mass_balanced_projection_max_upper_bound_violation_after" => 0.0,
    )

    state_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    state_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA mass-balanced dynamic flux-start projection requires finite state start values."),
    )
    flux_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA mass-balanced dynamic flux-start projection requires finite flux start values."),
    )

    model = problem.nlp.kkt_problem.model
    n_metabolites = problem.nlp.kkt_problem.dimensions.n_metabolites
    n_reactions = problem.nlp.dimensions.n_reactions
    options = _reduced_dcdfba_dynamic_flux_lp_start_options()
    row_indices, column_indices, sparse_values = findnz(model.S)
    tolerance = 100.0 * eps(Float64)

    checked_points = 0
    solve_attempt_count = 0
    optimal_count = 0
    relaxed_attempt_count = 0
    relaxed_optimal_count = 0
    skipped_feasible_count = 0
    status_counts = Dict{String, Int}()
    relaxed_status_counts = Dict{String, Int}()
    invalid_bound_pair_count = 0
    max_invalid_bound_gap = 0.0
    max_adjustment = 0.0
    max_l1_adjustment = 0.0
    max_relaxed_mass_balance_residual_after = 0.0
    max_mass_before = 0.0
    max_mass_after = 0.0
    max_lower_before = 0.0
    max_lower_after = 0.0
    max_upper_before = 0.0
    max_upper_after = 0.0
    min_objective_value = Inf
    max_objective_value = -Inf
    first_nonoptimal_element_index = missing
    first_nonoptimal_collocation_index = missing
    first_nonoptimal_ordinal = missing
    first_nonoptimal_status = missing

    for e in selected_elements, j in 1:problem.nlp.dimensions.collocation_degree
        checked_points += 1
        bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, state_values)
        crossing = _reduced_dcdfba_bound_crossing_summary(bounds.lb, bounds.ub)
        if crossing.count > 0
            status_counts["INVALID_BOUNDS"] = get(status_counts, "INVALID_BOUNDS", 0) + 1
            invalid_bound_pair_count += crossing.count
            max_invalid_bound_gap = max(max_invalid_bound_gap, crossing.max_gap)
            continue
        end

        reference_flux = copy(flux_values[:, e, j])
        mass_before = maximum(abs.(model.S * reference_flux))
        lower_before = maximum(max.(bounds.lb .- reference_flux, 0.0))
        upper_before = maximum(max.(reference_flux .- bounds.ub, 0.0))
        max_mass_before = max(max_mass_before, mass_before)
        max_lower_before = max(max_lower_before, lower_before)
        max_upper_before = max(max_upper_before, upper_before)
        if mass_before <= tolerance && lower_before <= tolerance && upper_before <= tolerance
            skipped_feasible_count += 1
            max_mass_after = max(max_mass_after, mass_before)
            max_lower_after = max(max_lower_after, lower_before)
            max_upper_after = max(max_upper_after, upper_before)
            continue
        end

        projection_model = JuMP.Model(HiGHS.Optimizer)
        for (name, value) in options.optimizer_attributes
            JuMP.set_optimizer_attribute(projection_model, String(name), value)
        end
        JuMP.set_silent(projection_model)
        JuMP.@variable(projection_model, projected_flux[1:n_reactions])
        JuMP.@variable(projection_model, deviation_pos[1:n_reactions] >= 0.0)
        JuMP.@variable(projection_model, deviation_neg[1:n_reactions] >= 0.0)
        for r in 1:n_reactions
            JuMP.set_lower_bound(projected_flux[r], bounds.lb[r])
            JuMP.set_upper_bound(projected_flux[r], bounds.ub[r])
            JuMP.@constraint(
                projection_model,
                projected_flux[r] - reference_flux[r] ==
                deviation_pos[r] - deviation_neg[r],
            )
        end
        mass_balance_expressions = [JuMP.AffExpr(0.0) for _ in 1:n_metabolites]
        for k in eachindex(sparse_values)
            JuMP.add_to_expression!(
                mass_balance_expressions[row_indices[k]],
                sparse_values[k],
                projected_flux[column_indices[k]],
            )
        end
        JuMP.@constraint(
            projection_model,
            steady_state[m = 1:n_metabolites],
            mass_balance_expressions[m] == 0.0,
        )
        objective_expression = JuMP.AffExpr(0.0)
        for r in 1:n_reactions
            JuMP.add_to_expression!(objective_expression, 1.0, deviation_pos[r])
            JuMP.add_to_expression!(objective_expression, 1.0, deviation_neg[r])
        end
        JuMP.@objective(projection_model, Min, objective_expression)

        solve_attempt_count += 1
        JuMP.optimize!(projection_model)
        status = JuMP.termination_status(projection_model)
        status_key = string(status)
        status_counts[status_key] = get(status_counts, status_key, 0) + 1
        if status != MOI.OPTIMAL
            if first_nonoptimal_element_index === missing
                first_nonoptimal_element_index = e
                first_nonoptimal_collocation_index = j
                first_nonoptimal_ordinal = solve_attempt_count
                first_nonoptimal_status = status_key
            end
            if options.relaxed_fallback
                relaxed_attempt_count += 1
                relaxed_model = JuMP.Model(HiGHS.Optimizer)
                for (name, value) in options.optimizer_attributes
                    JuMP.set_optimizer_attribute(relaxed_model, String(name), value)
                end
                JuMP.set_silent(relaxed_model)
                JuMP.@variable(relaxed_model, relaxed_flux[1:n_reactions])
                JuMP.@variable(relaxed_model, relaxed_deviation_pos[1:n_reactions] >= 0.0)
                JuMP.@variable(relaxed_model, relaxed_deviation_neg[1:n_reactions] >= 0.0)
                JuMP.@variable(relaxed_model, mass_balance_pos[1:n_metabolites] >= 0.0)
                JuMP.@variable(relaxed_model, mass_balance_neg[1:n_metabolites] >= 0.0)
                for r in 1:n_reactions
                    JuMP.set_lower_bound(relaxed_flux[r], bounds.lb[r])
                    JuMP.set_upper_bound(relaxed_flux[r], bounds.ub[r])
                    JuMP.@constraint(
                        relaxed_model,
                        relaxed_flux[r] - reference_flux[r] ==
                        relaxed_deviation_pos[r] - relaxed_deviation_neg[r],
                    )
                end
                relaxed_mass_balance_expressions =
                    [JuMP.AffExpr(0.0) for _ in 1:n_metabolites]
                for k in eachindex(sparse_values)
                    JuMP.add_to_expression!(
                        relaxed_mass_balance_expressions[row_indices[k]],
                        sparse_values[k],
                        relaxed_flux[column_indices[k]],
                    )
                end
                JuMP.@constraint(
                    relaxed_model,
                    relaxed_steady_state[m = 1:n_metabolites],
                    relaxed_mass_balance_expressions[m] ==
                    mass_balance_pos[m] - mass_balance_neg[m],
                )
                relaxed_objective = JuMP.AffExpr(0.0)
                for r in 1:n_reactions
                    JuMP.add_to_expression!(relaxed_objective, 1.0, relaxed_deviation_pos[r])
                    JuMP.add_to_expression!(relaxed_objective, 1.0, relaxed_deviation_neg[r])
                end
                for m in 1:n_metabolites
                    JuMP.add_to_expression!(
                        relaxed_objective,
                        options.relaxed_mass_weight,
                        mass_balance_pos[m],
                    )
                    JuMP.add_to_expression!(
                        relaxed_objective,
                        options.relaxed_mass_weight,
                        mass_balance_neg[m],
                    )
                end
                JuMP.@objective(relaxed_model, Min, relaxed_objective)
                JuMP.optimize!(relaxed_model)
                relaxed_status = JuMP.termination_status(relaxed_model)
                relaxed_status_key = string(relaxed_status)
                relaxed_status_counts[relaxed_status_key] =
                    get(relaxed_status_counts, relaxed_status_key, 0) + 1
                if relaxed_status == MOI.OPTIMAL
                    relaxed_optimal_count += 1
                    relaxed_projected = Float64.(JuMP.value.(relaxed_flux))
                    mass_after = maximum(abs.(model.S * relaxed_projected))
                    lower_after = maximum(max.(bounds.lb .- relaxed_projected, 0.0))
                    upper_after = maximum(max.(relaxed_projected .- bounds.ub, 0.0))
                    l1_adjustment = sum(abs.(relaxed_projected .- reference_flux))
                    max_mass_after = max(max_mass_after, mass_after)
                    max_relaxed_mass_balance_residual_after =
                        max(max_relaxed_mass_balance_residual_after, mass_after)
                    max_lower_after = max(max_lower_after, lower_after)
                    max_upper_after = max(max_upper_after, upper_after)
                    max_l1_adjustment = max(max_l1_adjustment, l1_adjustment)
                    for r in 1:n_reactions
                        adjustment = abs(relaxed_projected[r] - reference_flux[r])
                        max_adjustment = max(max_adjustment, adjustment)
                        if adjustment > tolerance
                            JuMP.set_start_value(problem.nlp.flux[r, e, j], relaxed_projected[r])
                            flux_values[r, e, j] = relaxed_projected[r]
                        end
                    end
                    continue
                end
            end
            options.fail_fast && throw(
                ArgumentError(
                    "Reduced DC-dFBA mass-balanced dynamic flux-start projection failed at element=$e collocation=$j ordinal=$solve_attempt_count with status $status_key.",
                ),
            )
            continue
        end

        optimal_count += 1
        objective_value = Float64(JuMP.objective_value(projection_model))
        min_objective_value = min(min_objective_value, objective_value)
        max_objective_value = max(max_objective_value, objective_value)
        projected = Float64.(JuMP.value.(projected_flux))
        mass_after = maximum(abs.(model.S * projected))
        lower_after = maximum(max.(bounds.lb .- projected, 0.0))
        upper_after = maximum(max.(projected .- bounds.ub, 0.0))
        l1_adjustment = sum(abs.(projected .- reference_flux))
        max_mass_after = max(max_mass_after, mass_after)
        max_lower_after = max(max_lower_after, lower_after)
        max_upper_after = max(max_upper_after, upper_after)
        max_l1_adjustment = max(max_l1_adjustment, l1_adjustment)
        for r in 1:n_reactions
            adjustment = abs(projected[r] - reference_flux[r])
            max_adjustment = max(max_adjustment, adjustment)
            if adjustment > tolerance
                JuMP.set_start_value(problem.nlp.flux[r, e, j], projected[r])
                flux_values[r, e, j] = projected[r]
            end
        end
    end

    return Dict{String, Any}(
        "dynamic_flux_start_mass_balanced_projection_applied" => true,
        "dynamic_flux_start_mass_balanced_projection_policy" =>
            "minimize_l1_flux_adjustment_subject_to_mass_balance_and_dynamic_or_base_bounds",
        "dynamic_flux_start_mass_balanced_projection_finite_element_count" =>
            length(selected_elements),
        "dynamic_flux_start_mass_balanced_projection_checked_points" => checked_points,
        "dynamic_flux_start_mass_balanced_projection_solve_attempt_count" =>
            solve_attempt_count,
        "dynamic_flux_start_mass_balanced_projection_optimal_count" => optimal_count,
        "dynamic_flux_start_mass_balanced_projection_relaxed_fallback_enabled" =>
            options.relaxed_fallback,
        "dynamic_flux_start_mass_balanced_projection_relaxed_mass_weight" =>
            options.relaxed_mass_weight,
        "dynamic_flux_start_mass_balanced_projection_relaxed_attempt_count" =>
            relaxed_attempt_count,
        "dynamic_flux_start_mass_balanced_projection_relaxed_optimal_count" =>
            relaxed_optimal_count,
        "dynamic_flux_start_mass_balanced_projection_relaxed_status_counts" =>
            relaxed_status_counts,
        "dynamic_flux_start_mass_balanced_projection_max_relaxed_mass_balance_residual_after" =>
            max_relaxed_mass_balance_residual_after,
        "dynamic_flux_start_mass_balanced_projection_skipped_feasible_count" =>
            skipped_feasible_count,
        "dynamic_flux_start_mass_balanced_projection_status_counts" => status_counts,
        "dynamic_flux_start_mass_balanced_projection_solver" => "HiGHS",
        "dynamic_flux_start_mass_balanced_projection_optimizer_attributes" =>
            options.optimizer_attributes,
        "dynamic_flux_start_mass_balanced_projection_time_limit_seconds" =>
            options.time_limit === nothing ? missing : options.time_limit,
        "dynamic_flux_start_mass_balanced_projection_fail_fast" => options.fail_fast,
        "dynamic_flux_start_mass_balanced_projection_first_nonoptimal_element_index" =>
            first_nonoptimal_element_index,
        "dynamic_flux_start_mass_balanced_projection_first_nonoptimal_collocation_index" =>
            first_nonoptimal_collocation_index,
        "dynamic_flux_start_mass_balanced_projection_first_nonoptimal_ordinal" =>
            first_nonoptimal_ordinal,
        "dynamic_flux_start_mass_balanced_projection_first_nonoptimal_status" =>
            first_nonoptimal_status,
        "dynamic_flux_start_mass_balanced_projection_invalid_bound_point_count" =>
            get(status_counts, "INVALID_BOUNDS", 0),
        "dynamic_flux_start_mass_balanced_projection_invalid_bound_pair_count" =>
            invalid_bound_pair_count,
        "dynamic_flux_start_mass_balanced_projection_max_invalid_bound_gap" =>
            max_invalid_bound_gap,
        "dynamic_flux_start_mass_balanced_projection_objective_value_min" =>
            isfinite(min_objective_value) ? min_objective_value : missing,
        "dynamic_flux_start_mass_balanced_projection_objective_value_max" =>
            isfinite(max_objective_value) ? max_objective_value : missing,
        "dynamic_flux_start_mass_balanced_projection_max_adjustment" => max_adjustment,
        "dynamic_flux_start_mass_balanced_projection_max_l1_adjustment" =>
            max_l1_adjustment,
        "dynamic_flux_start_mass_balanced_projection_max_mass_balance_residual_before" =>
            max_mass_before,
        "dynamic_flux_start_mass_balanced_projection_max_mass_balance_residual_after" =>
            max_mass_after,
        "dynamic_flux_start_mass_balanced_projection_max_lower_bound_violation_before" =>
            max_lower_before,
        "dynamic_flux_start_mass_balanced_projection_max_lower_bound_violation_after" =>
            max_lower_after,
        "dynamic_flux_start_mass_balanced_projection_max_upper_bound_violation_before" =>
            max_upper_before,
        "dynamic_flux_start_mass_balanced_projection_max_upper_bound_violation_after" =>
            max_upper_after,
        "dynamic_flux_start_mass_balanced_projection_indices_reacciones_used" => false,
        "dynamic_flux_start_mass_balanced_projection_r0001_used_as_oxygen" => false,
    )
end

function _reduced_dcdfba_project_active_complementarity_flux_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem;
    element_indices = nothing,
    complementarity_trigger_threshold::Real =
        default_reduced_dcdfba_mpcc_residual_thresholds().max_lower_complementarity_residual,
)::Dict{String, Any}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    state_values = problem.dynamic_bounds === nothing ? nothing :
                   _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)
    any(
        value -> value === nothing,
        (flux_values, lower_dual_values, upper_dual_values, mass_dual_values),
    ) && throw(
        ArgumentError("Reduced DC-dFBA active complementarity flux projection requires finite flux and dual starts."),
    )
    problem.dynamic_bounds !== nothing && state_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA active complementarity flux projection requires finite state starts for dynamic bounds."),
    )
    trigger_threshold = Float64(complementarity_trigger_threshold)
    isfinite(trigger_threshold) && trigger_threshold >= 0.0 || throw(
        ArgumentError("Reduced DC-dFBA active complementarity flux projection requires a finite nonnegative trigger threshold."),
    )

    before = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )

    model = problem.nlp.kkt_problem.model
    n_metabolites = problem.nlp.kkt_problem.dimensions.n_metabolites
    n_reactions = problem.nlp.dimensions.n_reactions
    degree = problem.nlp.dimensions.collocation_degree
    options = _reduced_dcdfba_dynamic_flux_lp_start_options()
    row_indices, column_indices, sparse_values = findnz(model.S)
    tolerance = 100.0 * eps(Float64)

    checked_points = 0
    triggered_points = 0
    solve_attempt_count = 0
    optimal_count = 0
    skipped_no_trigger_count = 0
    status_counts = Dict{String, Int}()
    lower_active_count = 0
    upper_active_count = 0
    changed_count = 0
    max_adjustment = 0.0
    max_l1_adjustment = 0.0
    max_mass_before = 0.0
    max_mass_after = 0.0
    max_lower_product_before = before.max_lower_complementarity_residual
    max_upper_product_before = before.max_upper_complementarity_residual
    min_objective_value = Inf
    max_objective_value = -Inf
    first_nonoptimal_element_index = missing
    first_nonoptimal_collocation_index = missing
    first_nonoptimal_status = missing

    for e in selected_elements, j in 1:degree
        checked_points += 1
        bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, state_values)
        crossing = _reduced_dcdfba_bound_crossing_summary(bounds.lb, bounds.ub)
        if crossing.count > 0
            status_counts["INVALID_BOUNDS"] = get(status_counts, "INVALID_BOUNDS", 0) + 1
            continue
        end

        reference_flux = copy(flux_values[:, e, j])
        active_lower = falses(n_reactions)
        active_upper = falses(n_reactions)
        for r in 1:n_reactions
            lower_product = abs((reference_flux[r] - bounds.lb[r]) * lower_dual_values[r, e, j])
            upper_product = abs((reference_flux[r] - bounds.ub[r]) * upper_dual_values[r, e, j])
            if lower_product > trigger_threshold || upper_product > trigger_threshold
                if lower_product >= upper_product
                    active_lower[r] = true
                else
                    active_upper[r] = true
                end
            end
        end
        point_lower_count = count(active_lower)
        point_upper_count = count(active_upper)
        if point_lower_count + point_upper_count == 0
            skipped_no_trigger_count += 1
            continue
        end
        triggered_points += 1
        lower_active_count += point_lower_count
        upper_active_count += point_upper_count
        max_mass_before = max(max_mass_before, maximum(abs.(model.S * reference_flux)))

        projection_model = JuMP.Model(HiGHS.Optimizer)
        for (name, value) in options.optimizer_attributes
            JuMP.set_optimizer_attribute(projection_model, String(name), value)
        end
        JuMP.set_silent(projection_model)
        JuMP.@variable(projection_model, projected_flux[1:n_reactions])
        JuMP.@variable(projection_model, projection_deviation_pos[1:n_reactions] >= 0.0)
        JuMP.@variable(projection_model, projection_deviation_neg[1:n_reactions] >= 0.0)
        for r in 1:n_reactions
            JuMP.set_lower_bound(projected_flux[r], bounds.lb[r])
            JuMP.set_upper_bound(projected_flux[r], bounds.ub[r])
            if active_lower[r]
                JuMP.fix(projected_flux[r], bounds.lb[r]; force = true)
            elseif active_upper[r]
                JuMP.fix(projected_flux[r], bounds.ub[r]; force = true)
            end
            JuMP.@constraint(
                projection_model,
                projected_flux[r] - reference_flux[r] ==
                projection_deviation_pos[r] - projection_deviation_neg[r],
            )
        end
        mass_balance_expressions = [JuMP.AffExpr(0.0) for _ in 1:n_metabolites]
        for k in eachindex(sparse_values)
            JuMP.add_to_expression!(
                mass_balance_expressions[row_indices[k]],
                sparse_values[k],
                projected_flux[column_indices[k]],
            )
        end
        JuMP.@constraint(
            projection_model,
            active_complementarity_steady_state[m = 1:n_metabolites],
            mass_balance_expressions[m] == 0.0,
        )
        JuMP.@objective(
            projection_model,
            Min,
            sum(projection_deviation_pos) + sum(projection_deviation_neg),
        )

        solve_attempt_count += 1
        JuMP.optimize!(projection_model)
        status = JuMP.termination_status(projection_model)
        status_key = string(status)
        status_counts[status_key] = get(status_counts, status_key, 0) + 1
        if status != MOI.OPTIMAL
            if first_nonoptimal_element_index === missing
                first_nonoptimal_element_index = e
                first_nonoptimal_collocation_index = j
                first_nonoptimal_status = status_key
            end
            continue
        end

        optimal_count += 1
        objective_value = Float64(JuMP.objective_value(projection_model))
        min_objective_value = min(min_objective_value, objective_value)
        max_objective_value = max(max_objective_value, objective_value)
        projected = Float64.(JuMP.value.(projected_flux))
        max_mass_after = max(max_mass_after, maximum(abs.(model.S * projected)))
        l1_adjustment = sum(abs.(projected .- reference_flux))
        max_l1_adjustment = max(max_l1_adjustment, l1_adjustment)
        for r in 1:n_reactions
            adjustment = abs(projected[r] - reference_flux[r])
            max_adjustment = max(max_adjustment, adjustment)
            if adjustment > tolerance
                changed_count += 1
                JuMP.set_start_value(problem.nlp.flux[r, e, j], projected[r])
                flux_values[r, e, j] = projected[r]
            end
        end
    end

    after = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )
    return Dict{String, Any}(
        "active_complementarity_flux_projection_applied" =>
            triggered_points > 0 && optimal_count > 0,
        "active_complementarity_flux_projection_policy" =>
            "fix_high_product_fluxes_to_active_bounds_minimize_l1_deviation_preserve_mass_balance",
        "active_complementarity_flux_projection_trigger_threshold" =>
            trigger_threshold,
        "active_complementarity_flux_projection_finite_element_count" =>
            length(selected_elements),
        "active_complementarity_flux_projection_checked_points" => checked_points,
        "active_complementarity_flux_projection_triggered_points" => triggered_points,
        "active_complementarity_flux_projection_skipped_no_trigger_count" =>
            skipped_no_trigger_count,
        "active_complementarity_flux_projection_solve_attempt_count" =>
            solve_attempt_count,
        "active_complementarity_flux_projection_optimal_count" => optimal_count,
        "active_complementarity_flux_projection_status_counts" => status_counts,
        "active_complementarity_flux_projection_solver" => "HiGHS",
        "active_complementarity_flux_projection_lower_active_count" =>
            lower_active_count,
        "active_complementarity_flux_projection_upper_active_count" =>
            upper_active_count,
        "active_complementarity_flux_projection_changed_count" => changed_count,
        "active_complementarity_flux_projection_max_adjustment" => max_adjustment,
        "active_complementarity_flux_projection_max_l1_adjustment" =>
            max_l1_adjustment,
        "active_complementarity_flux_projection_max_mass_balance_residual_before" =>
            max_mass_before,
        "active_complementarity_flux_projection_max_mass_balance_residual_after" =>
            max_mass_after,
        "active_complementarity_flux_projection_max_lower_complementarity_before" =>
            max_lower_product_before,
        "active_complementarity_flux_projection_max_upper_complementarity_before" =>
            max_upper_product_before,
        "active_complementarity_flux_projection_max_lower_complementarity_after" =>
            after.max_lower_complementarity_residual,
        "active_complementarity_flux_projection_max_upper_complementarity_after" =>
            after.max_upper_complementarity_residual,
        "active_complementarity_flux_projection_objective_value_min" =>
            isfinite(min_objective_value) ? min_objective_value : missing,
        "active_complementarity_flux_projection_objective_value_max" =>
            isfinite(max_objective_value) ? max_objective_value : missing,
        "active_complementarity_flux_projection_first_nonoptimal_element_index" =>
            first_nonoptimal_element_index,
        "active_complementarity_flux_projection_first_nonoptimal_collocation_index" =>
            first_nonoptimal_collocation_index,
        "active_complementarity_flux_projection_first_nonoptimal_status" =>
            first_nonoptimal_status,
        "active_complementarity_flux_projection_indices_reacciones_used" => false,
        "active_complementarity_flux_projection_r0001_used_as_oxygen" => false,
    )
end

function _reduced_dcdfba_apply_stationarity_dual_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    ;
    element_indices = nothing,
)::Dict{String, Any}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    state_values = problem.dynamic_bounds === nothing ? nothing :
                   _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)
    any(
        value -> value === nothing,
        (flux_values, lower_dual_values, upper_dual_values, mass_dual_values),
    ) && throw(
        ArgumentError("Reduced DC-dFBA stationarity dual starts require finite flux and dual start values."),
    )
    problem.dynamic_bounds !== nothing && state_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA stationarity dual starts require finite state start values for dynamic bounds."),
    )

    before = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )
    _reduced_dcdfba_stationarity_has_objective(problem) || return Dict{String, Any}(
        "stationarity_dual_start_applied" => false,
        "stationarity_dual_start_policy" => "not_applied_zero_stationarity_objective",
        "stationarity_dual_start_finite_element_count" => length(selected_elements),
        "stationarity_dual_start_collocation_points" => 0,
        "stationarity_dual_start_optimal_count" => 0,
        "stationarity_dual_start_status_counts" => Dict{String, Int}(),
        "stationarity_dual_start_solver" => "not_called",
        "stationarity_dual_start_objective_policy" => "zero_stationarity_objective",
        "stationarity_dual_start_objective_nonzero_count" => 0,
        "stationarity_dual_start_flux_start_updated" => false,
        "stationarity_dual_start_mass_balance_duals_changed" => false,
        "stationarity_dual_start_bound_duals_changed" => false,
        "stationarity_dual_start_max_stationarity_residual_before" =>
            before.max_stationarity_residual,
        "stationarity_dual_start_max_stationarity_residual_after" =>
            before.max_stationarity_residual,
        "stationarity_dual_start_max_lower_complementarity_residual_after" =>
            before.max_lower_complementarity_residual,
        "stationarity_dual_start_max_upper_complementarity_residual_after" =>
            before.max_upper_complementarity_residual,
        "stationarity_dual_start_max_mass_balance_residual" =>
            before.max_mass_balance_residual,
        "stationarity_dual_start_max_lower_bound_violation" =>
            before.max_lower_bound_violation,
        "stationarity_dual_start_max_upper_bound_violation" =>
            before.max_upper_bound_violation,
        "stationarity_dual_start_max_flux_adjustment_from_previous" => 0.0,
        "stationarity_dual_start_mass_balance_dual_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(mass_dual_values),
        "stationarity_dual_start_lower_bound_dual_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(lower_dual_values),
        "stationarity_dual_start_upper_bound_dual_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(upper_dual_values),
        "stationarity_dual_start_max_dual_sign_clipping" => 0.0,
        "stationarity_dual_start_indices_reacciones_used" => false,
        "stationarity_dual_start_r0001_used_as_oxygen" => false,
        "stationarity_dual_start_is_scientific_simulation" => false,
    )

    model = problem.nlp.kkt_problem.model
    n_metabolites = problem.nlp.kkt_problem.dimensions.n_metabolites
    n_reactions = problem.nlp.dimensions.n_reactions
    nfe = problem.nlp.dimensions.nfe
    degree = problem.nlp.dimensions.collocation_degree
    options = _reduced_dcdfba_stationarity_dual_start_options()

    status_counts = Dict{String, Int}()
    collocation_points = 0
    solve_attempt_count = 0
    optimal_count = 0
    max_mass_balance_residual = 0.0
    max_lower_bound_violation = 0.0
    max_upper_bound_violation = 0.0
    max_flux_adjustment = 0.0
    max_dual_sign_clipping = 0.0
    max_objective_nonzero_count = 0
    invalid_bound_pair_count = 0
    max_invalid_bound_gap = 0.0
    min_objective_value = Inf
    max_objective_value = -Inf
    max_solve_elapsed = 0.0
    total_solve_elapsed = 0.0
    slowest_element_index = missing
    slowest_collocation_index = missing
    slowest_ordinal = missing
    slowest_status = missing
    first_nonoptimal_element_index = missing
    first_nonoptimal_collocation_index = missing
    first_nonoptimal_ordinal = missing
    first_nonoptimal_status = missing
    first_nonoptimal_primal_status = missing
    first_nonoptimal_dual_status = missing
    last_attempt_element_index = missing
    last_attempt_collocation_index = missing
    last_attempt_ordinal = missing
    truncated_by_max_points = false

    for e in selected_elements, j in 1:degree
        if options.max_points > 0 && solve_attempt_count >= options.max_points
            truncated_by_max_points = true
            break
        end
        collocation_points += 1
        local_bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, state_values)
        crossing = _reduced_dcdfba_bound_crossing_summary(local_bounds.lb, local_bounds.ub)
        if crossing.count > 0
            status_counts["INVALID_BOUNDS"] = get(status_counts, "INVALID_BOUNDS", 0) + 1
            invalid_bound_pair_count += crossing.count
            max_invalid_bound_gap = max(max_invalid_bound_gap, crossing.max_gap)
            continue
        end
        local_model = MetabolicModel(
            model.S,
            local_bounds.lb,
            local_bounds.ub,
            model.rxn_ids,
            model.met_ids;
            model_id = model.model_id,
        )
        objective_weights = _reduced_dcdfba_stationarity_start_objective_weights(
            model,
            _reduced_dcdfba_numeric_stationarity_coefficients(problem, e, j, state_values),
        )
        max_objective_nonzero_count = max(max_objective_nonzero_count, length(objective_weights))
        lp_problem = build_fba_problem(
            local_model;
            objective_weights = objective_weights,
            sense = :min,
            silent = true,
            optimizer_attributes = options.optimizer_attributes,
        )
        solve_attempt_count += 1
        last_attempt_element_index = e
        last_attempt_collocation_index = j
        last_attempt_ordinal = solve_attempt_count
        if options.trace &&
           (solve_attempt_count == 1 || solve_attempt_count % options.trace_every == 0)
            println(
                "stationarity_dual_start_begin: ordinal=$solve_attempt_count element=$e collocation=$j time_limit=$(options.time_limit === nothing ? "missing" : options.time_limit)",
            )
            flush(stdout)
        end
        started_at = time()
        JuMP.optimize!(lp_problem.jump_model)
        solve_elapsed = time() - started_at

        status = JuMP.termination_status(lp_problem.jump_model)
        status_key = string(status)
        status_counts[status_key] = get(status_counts, status_key, 0) + 1
        primal_status = JuMP.primal_status(lp_problem.jump_model)
        dual_status = JuMP.dual_status(lp_problem.jump_model)
        max_solve_elapsed < solve_elapsed && begin
            max_solve_elapsed = solve_elapsed
            slowest_element_index = e
            slowest_collocation_index = j
            slowest_ordinal = solve_attempt_count
            slowest_status = status_key
        end
        total_solve_elapsed += solve_elapsed
        if options.trace
            println(
                "stationarity_dual_start_end: ordinal=$solve_attempt_count element=$e collocation=$j status=$status_key primal_status=$(string(primal_status)) dual_status=$(string(dual_status)) elapsed_seconds=$(round(solve_elapsed; digits = 6))",
            )
            flush(stdout)
        end
        feasible_primal =
            primal_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT)
        feasible_dual =
            dual_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT)
        if status != MOI.OPTIMAL || !feasible_primal || !feasible_dual
            if first_nonoptimal_element_index === missing
                first_nonoptimal_element_index = e
                first_nonoptimal_collocation_index = j
                first_nonoptimal_ordinal = solve_attempt_count
                first_nonoptimal_status = status_key
                first_nonoptimal_primal_status = string(primal_status)
                first_nonoptimal_dual_status = string(dual_status)
            end
            options.fail_fast && throw(
                ArgumentError(
                    "Reduced DC-dFBA stationarity dual-start LP failed at element=$e collocation=$j ordinal=$solve_attempt_count with status=$status_key primal_status=$(string(primal_status)) dual_status=$(string(dual_status)) after $(round(solve_elapsed; digits = 6)) seconds.",
                ),
            )
            continue
        end

        optimal_count += 1
        objective_value = Float64(JuMP.objective_value(lp_problem.jump_model))
        min_objective_value = min(min_objective_value, objective_value)
        max_objective_value = max(max_objective_value, objective_value)
        flux = Float64.(JuMP.value.(lp_problem.fluxes))
        length(flux) == n_reactions || throw(
            ArgumentError("Reduced DC-dFBA stationarity dual-start LP returned an incomplete flux vector."),
        )

        mass_dual = _reduced_dcdfba_stationarity_lp_mass_duals(lp_problem, n_metabolites)
        lower_dual, upper_dual, dual_sign_clipping =
            _reduced_dcdfba_stationarity_lp_bound_duals(lp_problem, n_reactions)
        max_dual_sign_clipping = max(max_dual_sign_clipping, dual_sign_clipping)

        max_mass_balance_residual =
            max(max_mass_balance_residual, maximum(abs.(model.S * flux)))
        max_lower_bound_violation =
            max(max_lower_bound_violation, maximum(max.(local_model.lb .- flux, 0.0)))
        max_upper_bound_violation =
            max(max_upper_bound_violation, maximum(max.(flux .- local_model.ub, 0.0)))

        for r in 1:n_reactions
            max_flux_adjustment = max(max_flux_adjustment, abs(flux[r] - flux_values[r, e, j]))
            JuMP.set_start_value(problem.nlp.flux[r, e, j], flux[r])
            JuMP.set_start_value(problem.bound_feasibility.lower_bound_duals[r, e, j], lower_dual[r])
            JuMP.set_start_value(problem.bound_feasibility.upper_bound_duals[r, e, j], upper_dual[r])
            flux_values[r, e, j] = flux[r]
            lower_dual_values[r, e, j] = lower_dual[r]
            upper_dual_values[r, e, j] = upper_dual[r]
        end
        for m in 1:n_metabolites
            JuMP.set_start_value(problem.stationarity.mass_balance_duals[m, e, j], mass_dual[m])
            mass_dual_values[m, e, j] = mass_dual[m]
        end
    end

    after = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )
    return Dict{String, Any}(
        "stationarity_dual_start_applied" => true,
        "stationarity_dual_start_policy" =>
            "solve_local_minimization_lp_for_primal_and_kkt_dual_starts",
        "stationarity_dual_start_finite_element_count" => length(selected_elements),
        "stationarity_dual_start_collocation_points" => collocation_points,
        "stationarity_dual_start_solve_attempt_count" => solve_attempt_count,
        "stationarity_dual_start_optimal_count" => optimal_count,
        "stationarity_dual_start_status_counts" => status_counts,
        "stationarity_dual_start_solver" => "HiGHS",
        "stationarity_dual_start_optimizer_attributes" => options.optimizer_attributes,
        "stationarity_dual_start_time_limit_seconds" =>
            options.time_limit === nothing ? missing : options.time_limit,
        "stationarity_dual_start_trace_enabled" => options.trace,
        "stationarity_dual_start_trace_every" => options.trace_every,
        "stationarity_dual_start_max_points" => options.max_points,
        "stationarity_dual_start_truncated_by_max_points" => truncated_by_max_points,
        "stationarity_dual_start_fail_fast" => options.fail_fast,
        "stationarity_dual_start_total_solve_elapsed_seconds" => total_solve_elapsed,
        "stationarity_dual_start_max_solve_elapsed_seconds" => max_solve_elapsed,
        "stationarity_dual_start_slowest_element_index" => slowest_element_index,
        "stationarity_dual_start_slowest_collocation_index" =>
            slowest_collocation_index,
        "stationarity_dual_start_slowest_ordinal" => slowest_ordinal,
        "stationarity_dual_start_slowest_status" => slowest_status,
        "stationarity_dual_start_first_nonoptimal_element_index" =>
            first_nonoptimal_element_index,
        "stationarity_dual_start_first_nonoptimal_collocation_index" =>
            first_nonoptimal_collocation_index,
        "stationarity_dual_start_first_nonoptimal_ordinal" =>
            first_nonoptimal_ordinal,
        "stationarity_dual_start_first_nonoptimal_status" =>
            first_nonoptimal_status,
        "stationarity_dual_start_first_nonoptimal_primal_status" =>
            first_nonoptimal_primal_status,
        "stationarity_dual_start_first_nonoptimal_dual_status" =>
            first_nonoptimal_dual_status,
        "stationarity_dual_start_last_attempt_element_index" =>
            last_attempt_element_index,
        "stationarity_dual_start_last_attempt_collocation_index" =>
            last_attempt_collocation_index,
        "stationarity_dual_start_last_attempt_ordinal" => last_attempt_ordinal,
        "stationarity_dual_start_objective_policy" =>
            "stationarity_minimization_coefficients",
        "stationarity_dual_start_objective_nonzero_count" => max_objective_nonzero_count,
        "stationarity_dual_start_objective_value_min" =>
            isfinite(min_objective_value) ? min_objective_value : missing,
        "stationarity_dual_start_objective_value_max" =>
            isfinite(max_objective_value) ? max_objective_value : missing,
        "stationarity_dual_start_invalid_bound_point_count" =>
            get(status_counts, "INVALID_BOUNDS", 0),
        "stationarity_dual_start_invalid_bound_pair_count" => invalid_bound_pair_count,
        "stationarity_dual_start_max_invalid_bound_gap" => max_invalid_bound_gap,
        "stationarity_dual_start_flux_start_updated" => true,
        "stationarity_dual_start_mass_balance_duals_changed" => true,
        "stationarity_dual_start_bound_duals_changed" => true,
        "stationarity_dual_start_max_stationarity_residual_before" =>
            before.max_stationarity_residual,
        "stationarity_dual_start_max_stationarity_residual_after" =>
            after.max_stationarity_residual,
        "stationarity_dual_start_max_lower_complementarity_residual_after" =>
            after.max_lower_complementarity_residual,
        "stationarity_dual_start_max_upper_complementarity_residual_after" =>
            after.max_upper_complementarity_residual,
        "stationarity_dual_start_max_mass_balance_residual" =>
            max_mass_balance_residual,
        "stationarity_dual_start_max_lower_bound_violation" =>
            max_lower_bound_violation,
        "stationarity_dual_start_max_upper_bound_violation" =>
            max_upper_bound_violation,
        "stationarity_dual_start_max_flux_adjustment_from_previous" =>
            max_flux_adjustment,
        "stationarity_dual_start_mass_balance_dual_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(mass_dual_values),
        "stationarity_dual_start_lower_bound_dual_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(lower_dual_values),
        "stationarity_dual_start_upper_bound_dual_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(upper_dual_values),
        "stationarity_dual_start_max_dual_sign_clipping" => max_dual_sign_clipping,
        "stationarity_dual_start_indices_reacciones_used" => false,
        "stationarity_dual_start_r0001_used_as_oxygen" => false,
        "stationarity_dual_start_is_scientific_simulation" => false,
    )
end

function _reduced_dcdfba_apply_fixed_flux_stationarity_dual_fit_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    ;
    element_indices = nothing,
    complementarity_tau::Real =
        get(problem.metadata, "complementarity_tau", REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU),
    complementarity_budget_fraction::Real =
        _reduced_dcdfba_fixed_flux_dual_fit_complementarity_budget_fraction(),
    dual_bound::Real = 1.0e6,
    dual_l1_weight::Real = 1.0e-9,
    dual_budget_zero_threshold::Real = 1.0e-7,
)::Dict{String, Any}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    state_values = problem.dynamic_bounds === nothing ? nothing :
                   _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)
    any(
        value -> value === nothing,
        (flux_values, lower_dual_values, upper_dual_values, mass_dual_values),
    ) && throw(
        ArgumentError("Reduced DC-dFBA fixed-flux dual fit requires finite flux and dual start values."),
    )
    problem.dynamic_bounds !== nothing && state_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA fixed-flux dual fit requires finite state start values for dynamic bounds."),
    )
    isfinite(Float64(complementarity_tau)) && Float64(complementarity_tau) >= 0.0 || throw(
        ArgumentError("Reduced DC-dFBA fixed-flux dual fit requires a finite nonnegative complementarity tau."),
    )
    isfinite(Float64(complementarity_budget_fraction)) &&
        0.0 < Float64(complementarity_budget_fraction) <= 1.0 || throw(
        ArgumentError(
            "Reduced DC-dFBA fixed-flux dual fit requires a finite complementarity budget fraction in (0, 1].",
        ),
    )
    isfinite(Float64(dual_bound)) && Float64(dual_bound) > 0.0 || throw(
        ArgumentError("Reduced DC-dFBA fixed-flux dual fit requires a finite positive dual bound."),
    )
    isfinite(Float64(dual_l1_weight)) && Float64(dual_l1_weight) >= 0.0 || throw(
        ArgumentError("Reduced DC-dFBA fixed-flux dual fit requires a finite nonnegative L1 weight."),
    )
    isfinite(Float64(dual_budget_zero_threshold)) &&
        Float64(dual_budget_zero_threshold) >= 0.0 || throw(
        ArgumentError("Reduced DC-dFBA fixed-flux dual fit requires a finite nonnegative dual zero threshold."),
    )

    before = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )

    model = problem.nlp.kkt_problem.model
    n_metabolites = problem.nlp.kkt_problem.dimensions.n_metabolites
    n_reactions = problem.nlp.dimensions.n_reactions
    degree = problem.nlp.dimensions.collocation_degree
    tau = Float64(complementarity_tau)
    budget_tau = tau * Float64(complementarity_budget_fraction)
    max_dual_abs = Float64(dual_bound)
    l1_weight = Float64(dual_l1_weight)
    zero_budget_threshold = Float64(dual_budget_zero_threshold)
    row_indices = SparseArrays.rowvals(model.S)
    sparse_values = SparseArrays.nonzeros(model.S)

    status_counts = Dict{String, Int}()
    collocation_points = 0
    optimal_count = 0
    max_stationarity_fit_residual = 0.0
    max_lower_dual_abs = 0.0
    max_upper_dual_abs = 0.0
    max_mass_dual_abs = 0.0
    max_lower_budget = 0.0
    max_upper_budget = 0.0
    min_objective_value = Inf
    max_objective_value = -Inf

    for e in selected_elements, j in 1:degree
        collocation_points += 1
        flux = flux_values[:, e, j]
        bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, state_values)
        coefficients =
            _reduced_dcdfba_numeric_stationarity_coefficients(problem, e, j, state_values)

        lower_budget = Vector{Float64}(undef, n_reactions)
        upper_budget = Vector{Float64}(undef, n_reactions)
        for r in 1:n_reactions
            lower_gap = abs(Float64(flux[r] - bounds.lb[r]))
            upper_gap = abs(Float64(flux[r] - bounds.ub[r]))
            raw_lower_budget =
                lower_gap == 0.0 ? max_dual_abs : min(max_dual_abs, budget_tau / lower_gap)
            raw_upper_budget =
                upper_gap == 0.0 ? max_dual_abs : min(max_dual_abs, budget_tau / upper_gap)
            lower_budget[r] =
                raw_lower_budget <= zero_budget_threshold ? 0.0 : raw_lower_budget
            upper_budget[r] =
                raw_upper_budget <= zero_budget_threshold ? 0.0 : raw_upper_budget
        end
        max_lower_budget = max(max_lower_budget, maximum(lower_budget))
        max_upper_budget = max(max_upper_budget, maximum(upper_budget))

        fit_model = JuMP.Model(HiGHS.Optimizer)
        JuMP.set_silent(fit_model)
        JuMP.@variable(fit_model, -max_dual_abs <= mass_dual[1:n_metabolites] <= max_dual_abs)
        JuMP.@variable(fit_model, lower_dual[1:n_reactions] <= 0.0)
        JuMP.@variable(fit_model, upper_dual[1:n_reactions] >= 0.0)
        JuMP.@variable(fit_model, residual_pos[1:n_reactions] >= 0.0)
        JuMP.@variable(fit_model, residual_neg[1:n_reactions] >= 0.0)
        JuMP.@variable(fit_model, mass_dual_abs[1:n_metabolites] >= 0.0)

        for r in 1:n_reactions
            JuMP.set_lower_bound(lower_dual[r], -lower_budget[r])
            JuMP.set_upper_bound(upper_dual[r], upper_budget[r])
        end
        for m in 1:n_metabolites
            JuMP.@constraint(fit_model, mass_dual_abs[m] >= mass_dual[m])
            JuMP.@constraint(fit_model, mass_dual_abs[m] >= -mass_dual[m])
        end
        for r in 1:n_reactions
            stationarity_expression =
                coefficients[r] + lower_dual[r] + upper_dual[r]
            for position in SparseArrays.nzrange(model.S, r)
                stationarity_expression +=
                    sparse_values[position] * mass_dual[row_indices[position]]
            end
            JuMP.@constraint(
                fit_model,
                stationarity_expression == residual_pos[r] - residual_neg[r],
            )
        end
        JuMP.@objective(
            fit_model,
            Min,
            sum(residual_pos) +
            sum(residual_neg) +
            l1_weight * (sum(mass_dual_abs) - sum(lower_dual) + sum(upper_dual)),
        )
        JuMP.optimize!(fit_model)

        status = JuMP.termination_status(fit_model)
        status_key = string(status)
        status_counts[status_key] = get(status_counts, status_key, 0) + 1
        primal_status = JuMP.primal_status(fit_model)
        status == MOI.OPTIMAL || throw(
            ArgumentError("Reduced DC-dFBA fixed-flux dual fit failed with status $status_key."),
        )
        primal_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT) || throw(
            ArgumentError(
                "Reduced DC-dFBA fixed-flux dual fit did not return a feasible point: $primal_status.",
            ),
        )

        optimal_count += 1
        objective_value = Float64(JuMP.objective_value(fit_model))
        min_objective_value = min(min_objective_value, objective_value)
        max_objective_value = max(max_objective_value, objective_value)

        fitted_mass_dual = Float64.(JuMP.value.(mass_dual))
        fitted_lower_dual = Float64.(JuMP.value.(lower_dual))
        fitted_upper_dual = Float64.(JuMP.value.(upper_dual))
        stationarity_residual =
            Float64.(JuMP.value.(residual_pos) .- JuMP.value.(residual_neg))
        max_stationarity_fit_residual =
            max(max_stationarity_fit_residual, maximum(abs.(stationarity_residual)))
        max_mass_dual_abs = max(max_mass_dual_abs, maximum(abs.(fitted_mass_dual)))
        max_lower_dual_abs = max(max_lower_dual_abs, maximum(abs.(fitted_lower_dual)))
        max_upper_dual_abs = max(max_upper_dual_abs, maximum(abs.(fitted_upper_dual)))

        for r in 1:n_reactions
            JuMP.set_start_value(
                problem.bound_feasibility.lower_bound_duals[r, e, j],
                fitted_lower_dual[r],
            )
            JuMP.set_start_value(
                problem.bound_feasibility.upper_bound_duals[r, e, j],
                fitted_upper_dual[r],
            )
            lower_dual_values[r, e, j] = fitted_lower_dual[r]
            upper_dual_values[r, e, j] = fitted_upper_dual[r]
        end
        for m in 1:n_metabolites
            JuMP.set_start_value(problem.stationarity.mass_balance_duals[m, e, j], fitted_mass_dual[m])
            mass_dual_values[m, e, j] = fitted_mass_dual[m]
        end
    end

    after = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )
    return Dict{String, Any}(
        "fixed_flux_stationarity_dual_fit_applied" => true,
        "fixed_flux_stationarity_dual_fit_policy" =>
            "l1_stationarity_dual_fit_preserve_flux_with_scholtes_dual_budgets",
        "fixed_flux_stationarity_dual_fit_finite_element_count" => length(selected_elements),
        "fixed_flux_stationarity_dual_fit_collocation_points" => collocation_points,
        "fixed_flux_stationarity_dual_fit_optimal_count" => optimal_count,
        "fixed_flux_stationarity_dual_fit_status_counts" => status_counts,
        "fixed_flux_stationarity_dual_fit_solver" => "HiGHS",
        "fixed_flux_stationarity_dual_fit_flux_start_updated" => false,
        "fixed_flux_stationarity_dual_fit_mass_balance_duals_changed" => true,
        "fixed_flux_stationarity_dual_fit_bound_duals_changed" => true,
        "fixed_flux_stationarity_dual_fit_complementarity_tau" => tau,
        "fixed_flux_stationarity_dual_fit_complementarity_budget_fraction" =>
            Float64(complementarity_budget_fraction),
        "fixed_flux_stationarity_dual_fit_effective_complementarity_budget_tau" =>
            budget_tau,
        "fixed_flux_stationarity_dual_fit_dual_bound" => max_dual_abs,
        "fixed_flux_stationarity_dual_fit_dual_l1_weight" => l1_weight,
        "fixed_flux_stationarity_dual_fit_dual_budget_zero_threshold" =>
            zero_budget_threshold,
        "fixed_flux_stationarity_dual_fit_objective_value_min" =>
            isfinite(min_objective_value) ? min_objective_value : missing,
        "fixed_flux_stationarity_dual_fit_objective_value_max" =>
            isfinite(max_objective_value) ? max_objective_value : missing,
        "fixed_flux_stationarity_dual_fit_max_stationarity_fit_residual" =>
            max_stationarity_fit_residual,
        "fixed_flux_stationarity_dual_fit_max_stationarity_residual_before" =>
            before.max_stationarity_residual,
        "fixed_flux_stationarity_dual_fit_max_stationarity_residual_after" =>
            after.max_stationarity_residual,
        "fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after" =>
            after.max_lower_complementarity_residual,
        "fixed_flux_stationarity_dual_fit_max_upper_complementarity_residual_after" =>
            after.max_upper_complementarity_residual,
        "fixed_flux_stationarity_dual_fit_max_mass_balance_residual" =>
            after.max_mass_balance_residual,
        "fixed_flux_stationarity_dual_fit_max_lower_bound_violation" =>
            after.max_lower_bound_violation,
        "fixed_flux_stationarity_dual_fit_max_upper_bound_violation" =>
            after.max_upper_bound_violation,
        "fixed_flux_stationarity_dual_fit_mass_balance_dual_abs_max" =>
            max_mass_dual_abs,
        "fixed_flux_stationarity_dual_fit_lower_bound_dual_abs_max" =>
            max_lower_dual_abs,
        "fixed_flux_stationarity_dual_fit_upper_bound_dual_abs_max" =>
            max_upper_dual_abs,
        "fixed_flux_stationarity_dual_fit_max_lower_dual_budget" =>
            max_lower_budget,
        "fixed_flux_stationarity_dual_fit_max_upper_dual_budget" =>
            max_upper_budget,
        "fixed_flux_stationarity_dual_fit_indices_reacciones_used" => false,
        "fixed_flux_stationarity_dual_fit_r0001_used_as_oxygen" => false,
        "fixed_flux_stationarity_dual_fit_is_scientific_simulation" => false,
    )
end

function _reduced_dcdfba_contiguous_element_ranges(
    element_indices::AbstractVector{<:Integer},
)::Vector{UnitRange{Int}}
    isempty(element_indices) && return UnitRange{Int}[]
    sorted_indices = sort!(unique!(Int.(collect(element_indices))))
    ranges = UnitRange{Int}[]
    first_index = sorted_indices[1]
    previous_index = first_index
    for index in sorted_indices[2:end]
        if index == previous_index + 1
            previous_index = index
        else
            push!(ranges, first_index:previous_index)
            first_index = index
            previous_index = index
        end
    end
    push!(ranges, first_index:previous_index)
    return ranges
end

function _reduced_dcdfba_select_complementarity_triggered_elements(
    problem::ReducedDCDFBAMPCCSmokeProblem;
    element_indices = nothing,
    complementarity_tau::Real =
        get(problem.metadata, "complementarity_tau", REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU),
    complementarity_trigger_threshold::Union{Nothing, Real} = nothing,
)
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    state_values = problem.dynamic_bounds === nothing ? nothing :
                   _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    any(value -> value === nothing, (flux_values, lower_dual_values, upper_dual_values)) && throw(
        ArgumentError("Reduced DC-dFBA complementarity-triggered dual fit requires finite flux and bound-dual start values."),
    )
    problem.dynamic_bounds !== nothing && state_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA complementarity-triggered dual fit requires finite state start values for dynamic bounds."),
    )
    tau = Float64(complementarity_tau)
    isfinite(tau) && tau >= 0.0 || throw(
        ArgumentError("Reduced DC-dFBA complementarity-triggered dual fit requires a finite nonnegative complementarity tau."),
    )
    gate_tolerance = _reduced_dcdfba_mpcc_complementarity_tau_gate_tolerance(
        problem.metadata,
        tau,
    )
    trigger_threshold = if complementarity_trigger_threshold === nothing
        tau + gate_tolerance.tolerance
    else
        Float64(complementarity_trigger_threshold)
    end
    isfinite(trigger_threshold) && trigger_threshold >= 0.0 || throw(
        ArgumentError("Reduced DC-dFBA complementarity-triggered dual fit requires a finite nonnegative trigger threshold."),
    )

    nfe = problem.nlp.dimensions.nfe
    n_reactions = problem.nlp.dimensions.n_reactions
    degree = problem.nlp.dimensions.collocation_degree
    triggered_element = falses(nfe)
    triggered_point = falses(nfe, degree)
    lower_trigger_count = 0
    upper_trigger_count = 0
    point_count = 0
    max_lower_product = 0.0
    max_upper_product = 0.0

    for e in selected_elements, j in 1:degree
        flux = flux_values[:, e, j]
        bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, state_values)
        point_triggered = false
        for r in 1:n_reactions
            lower_product =
                abs(Float64((flux[r] - bounds.lb[r]) * lower_dual_values[r, e, j]))
            upper_product =
                abs(Float64((flux[r] - bounds.ub[r]) * upper_dual_values[r, e, j]))
            max_lower_product = max(max_lower_product, lower_product)
            max_upper_product = max(max_upper_product, upper_product)
            if lower_product > trigger_threshold
                lower_trigger_count += 1
                point_triggered = true
            end
            if upper_product > trigger_threshold
                upper_trigger_count += 1
                point_triggered = true
            end
        end
        if point_triggered
            triggered_element[e] = true
            if !triggered_point[e, j]
                point_count += 1
                triggered_point[e, j] = true
            end
        end
    end

    triggered_elements = findall(triggered_element)
    return (
        elements = Int.(triggered_elements),
        ranges = _reduced_dcdfba_contiguous_element_ranges(triggered_elements),
        trigger_threshold = Float64(trigger_threshold),
        trigger_tolerance = gate_tolerance.tolerance,
        trigger_tolerance_source = gate_tolerance.source,
        lower_trigger_count = lower_trigger_count,
        upper_trigger_count = upper_trigger_count,
        point_count = point_count,
        max_lower_product = Float64(max_lower_product),
        max_upper_product = Float64(max_upper_product),
    )
end

function _reduced_dcdfba_apply_selective_fixed_flux_stationarity_dual_fit_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem;
    element_indices = nothing,
    complementarity_tau::Real =
        get(problem.metadata, "complementarity_tau", REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU),
    complementarity_budget_fraction::Real =
        _reduced_dcdfba_fixed_flux_dual_fit_complementarity_budget_fraction(),
    complementarity_trigger_threshold::Union{Nothing, Real} = nothing,
)::Dict{String, Any}
    state_values = problem.dynamic_bounds === nothing ? nothing :
                   _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)
    any(
        value -> value === nothing,
        (flux_values, lower_dual_values, upper_dual_values, mass_dual_values),
    ) && throw(
        ArgumentError("Reduced DC-dFBA selective fixed-flux dual fit requires finite flux and dual start values."),
    )
    problem.dynamic_bounds !== nothing && state_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA selective fixed-flux dual fit requires finite state start values for dynamic bounds."),
    )
    tau = Float64(complementarity_tau)
    budget_fraction = Float64(complementarity_budget_fraction)
    isfinite(tau) && tau >= 0.0 || throw(
        ArgumentError("Reduced DC-dFBA selective fixed-flux dual fit requires a finite nonnegative complementarity tau."),
    )
    isfinite(budget_fraction) && 0.0 < budget_fraction <= 1.0 || throw(
        ArgumentError("Reduced DC-dFBA selective fixed-flux dual fit requires a finite complementarity budget fraction in (0, 1]."),
    )

    guard_stationarity =
        _reduced_dcdfba_env_bool("MPCC_SELECTIVE_FIXED_FLUX_DUAL_FIT_GUARD_STATIONARITY", true)
    stationarity_acceptance_max =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_SELECTIVE_FIXED_FLUX_DUAL_FIT_STATIONARITY_MAX",
            default_reduced_dcdfba_mpcc_residual_thresholds().max_stationarity_residual,
        )
    stationarity_acceptance_abs_tol =
        _reduced_dcdfba_env_nonnegative_float(
            "MPCC_SELECTIVE_FIXED_FLUX_DUAL_FIT_STATIONARITY_ABS_TOL",
            1.0e-8,
        )

    before = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )
    baseline_lower_dual_values = copy(lower_dual_values)
    baseline_upper_dual_values = copy(upper_dual_values)
    baseline_mass_dual_values = copy(mass_dual_values)
    selection = _reduced_dcdfba_select_complementarity_triggered_elements(
        problem;
        element_indices = element_indices,
        complementarity_tau = tau,
        complementarity_trigger_threshold = complementarity_trigger_threshold,
    )

    status_counts = Dict{String, Int}()
    collocation_points = 0
    optimal_count = 0
    min_objective_value = Inf
    max_objective_value = -Inf
    max_stationarity_fit_residual = 0.0
    max_lower_dual_budget = 0.0
    max_upper_dual_budget = 0.0

    for element_range in selection.ranges
        fit_metadata = _reduced_dcdfba_apply_fixed_flux_stationarity_dual_fit_starts!(
            problem;
            element_indices = element_range,
            complementarity_tau = tau,
            complementarity_budget_fraction = budget_fraction,
        )
        collocation_points += Int(
            get(fit_metadata, "fixed_flux_stationarity_dual_fit_collocation_points", 0),
        )
        optimal_count += Int(
            get(fit_metadata, "fixed_flux_stationarity_dual_fit_optimal_count", 0),
        )
        range_status_counts =
            get(fit_metadata, "fixed_flux_stationarity_dual_fit_status_counts", Dict{String, Int}())
        if range_status_counts isa AbstractDict
            for (status, count) in range_status_counts
                status_key = string(status)
                status_counts[status_key] =
                    get(status_counts, status_key, 0) + Int(count)
            end
        end
        objective_min = get(fit_metadata, "fixed_flux_stationarity_dual_fit_objective_value_min", missing)
        objective_max = get(fit_metadata, "fixed_flux_stationarity_dual_fit_objective_value_max", missing)
        if objective_min !== missing
            min_objective_value = min(min_objective_value, Float64(objective_min))
        end
        if objective_max !== missing
            max_objective_value = max(max_objective_value, Float64(objective_max))
        end
        max_stationarity_fit_residual = max(
            max_stationarity_fit_residual,
            Float64(
                get(
                    fit_metadata,
                    "fixed_flux_stationarity_dual_fit_max_stationarity_fit_residual",
                    0.0,
                ),
            ),
        )
        max_lower_dual_budget = max(
            max_lower_dual_budget,
            Float64(get(fit_metadata, "fixed_flux_stationarity_dual_fit_max_lower_dual_budget", 0.0)),
        )
        max_upper_dual_budget = max(
            max_upper_dual_budget,
            Float64(get(fit_metadata, "fixed_flux_stationarity_dual_fit_max_upper_dual_budget", 0.0)),
        )
    end

    after_flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    after_lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    after_upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    after_mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)
    after_state_values = problem.dynamic_bounds === nothing ? nothing :
                         _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    after = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        after_flux_values,
        after_lower_dual_values,
        after_upper_dual_values,
        after_mass_dual_values,
        after_state_values,
    )
    stationarity_acceptance_threshold = max(
        stationarity_acceptance_max,
        before.max_stationarity_residual + stationarity_acceptance_abs_tol,
    )
    accepted =
        isempty(selection.elements) ||
        !guard_stationarity ||
        after.max_stationarity_residual <= stationarity_acceptance_threshold
    rejected_by_stationarity_guard = !isempty(selection.elements) && !accepted
    if rejected_by_stationarity_guard
        _reduced_dcdfba_mpcc_set_start_values!(
            problem.bound_feasibility.lower_bound_duals,
            baseline_lower_dual_values,
            "lower_bound_duals",
        )
        _reduced_dcdfba_mpcc_set_start_values!(
            problem.bound_feasibility.upper_bound_duals,
            baseline_upper_dual_values,
            "upper_bound_duals",
        )
        _reduced_dcdfba_mpcc_set_start_values!(
            problem.stationarity.mass_balance_duals,
            baseline_mass_dual_values,
            "mass_balance_duals",
        )
        after = before
    end

    return Dict{String, Any}(
        "selective_fixed_flux_stationarity_dual_fit_applied" =>
            !isempty(selection.elements) && accepted,
        "selective_fixed_flux_stationarity_dual_fit_policy" =>
            guard_stationarity ?
            "scholtes_complementarity_triggered_fixed_flux_stationarity_dual_fit_with_stationarity_guard" :
            "scholtes_complementarity_triggered_fixed_flux_stationarity_dual_fit",
        "selective_fixed_flux_stationarity_dual_fit_skip_reason" =>
            isempty(selection.elements) ? "no_complementarity_products_above_trigger" : missing,
        "selective_fixed_flux_stationarity_dual_fit_guard_stationarity_enabled" =>
            guard_stationarity,
        "selective_fixed_flux_stationarity_dual_fit_stationarity_acceptance_max" =>
            stationarity_acceptance_max,
        "selective_fixed_flux_stationarity_dual_fit_stationarity_acceptance_abs_tol" =>
            stationarity_acceptance_abs_tol,
        "selective_fixed_flux_stationarity_dual_fit_stationarity_acceptance_threshold" =>
            stationarity_acceptance_threshold,
        "selective_fixed_flux_stationarity_dual_fit_accepted" => accepted,
        "selective_fixed_flux_stationarity_dual_fit_rejected" =>
            rejected_by_stationarity_guard,
        "selective_fixed_flux_stationarity_dual_fit_rejection_reason" =>
            rejected_by_stationarity_guard ?
            "stationarity_residual_would_exceed_guard_threshold" :
            missing,
        "selective_fixed_flux_stationarity_dual_fit_restored_baseline_duals" =>
            rejected_by_stationarity_guard,
        "selective_fixed_flux_stationarity_dual_fit_trigger_threshold" =>
            selection.trigger_threshold,
        "selective_fixed_flux_stationarity_dual_fit_trigger_tolerance" =>
            selection.trigger_tolerance,
        "selective_fixed_flux_stationarity_dual_fit_trigger_tolerance_source" =>
            selection.trigger_tolerance_source,
        "selective_fixed_flux_stationarity_dual_fit_complementarity_tau" => tau,
        "selective_fixed_flux_stationarity_dual_fit_complementarity_budget_fraction" =>
            budget_fraction,
        "selective_fixed_flux_stationarity_dual_fit_effective_complementarity_budget_tau" =>
            tau * budget_fraction,
        "selective_fixed_flux_stationarity_dual_fit_element_count" =>
            length(selection.elements),
        "selective_fixed_flux_stationarity_dual_fit_range_count" =>
            length(selection.ranges),
        "selective_fixed_flux_stationarity_dual_fit_collocation_points_triggered" =>
            selection.point_count,
        "selective_fixed_flux_stationarity_dual_fit_lower_product_trigger_count" =>
            selection.lower_trigger_count,
        "selective_fixed_flux_stationarity_dual_fit_upper_product_trigger_count" =>
            selection.upper_trigger_count,
        "selective_fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_before" =>
            before.max_lower_complementarity_residual,
        "selective_fixed_flux_stationarity_dual_fit_max_upper_complementarity_residual_before" =>
            before.max_upper_complementarity_residual,
        "selective_fixed_flux_stationarity_dual_fit_max_lower_product_selected_before" =>
            selection.max_lower_product,
        "selective_fixed_flux_stationarity_dual_fit_max_upper_product_selected_before" =>
            selection.max_upper_product,
        "selective_fixed_flux_stationarity_dual_fit_max_stationarity_residual_before" =>
            before.max_stationarity_residual,
        "selective_fixed_flux_stationarity_dual_fit_max_stationarity_residual_after" =>
            after.max_stationarity_residual,
        "selective_fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after" =>
            after.max_lower_complementarity_residual,
        "selective_fixed_flux_stationarity_dual_fit_max_upper_complementarity_residual_after" =>
            after.max_upper_complementarity_residual,
        "selective_fixed_flux_stationarity_dual_fit_max_mass_balance_residual_after" =>
            after.max_mass_balance_residual,
        "selective_fixed_flux_stationarity_dual_fit_max_lower_bound_violation_after" =>
            after.max_lower_bound_violation,
        "selective_fixed_flux_stationarity_dual_fit_max_upper_bound_violation_after" =>
            after.max_upper_bound_violation,
        "selective_fixed_flux_stationarity_dual_fit_collocation_points" =>
            collocation_points,
        "selective_fixed_flux_stationarity_dual_fit_optimal_count" => optimal_count,
        "selective_fixed_flux_stationarity_dual_fit_status_counts" => status_counts,
        "selective_fixed_flux_stationarity_dual_fit_solver" =>
            isempty(selection.elements) ? "not_called" : "HiGHS",
        "selective_fixed_flux_stationarity_dual_fit_objective_value_min" =>
            isfinite(min_objective_value) ? min_objective_value : missing,
        "selective_fixed_flux_stationarity_dual_fit_objective_value_max" =>
            isfinite(max_objective_value) ? max_objective_value : missing,
        "selective_fixed_flux_stationarity_dual_fit_max_stationarity_fit_residual" =>
            max_stationarity_fit_residual,
        "selective_fixed_flux_stationarity_dual_fit_max_lower_dual_budget" =>
            max_lower_dual_budget,
        "selective_fixed_flux_stationarity_dual_fit_max_upper_dual_budget" =>
            max_upper_dual_budget,
        "selective_fixed_flux_stationarity_dual_fit_flux_start_updated" => false,
        "selective_fixed_flux_stationarity_dual_fit_mass_balance_duals_changed" =>
            !isempty(selection.elements) && accepted,
        "selective_fixed_flux_stationarity_dual_fit_bound_duals_changed" =>
            !isempty(selection.elements) && accepted,
        "selective_fixed_flux_stationarity_dual_fit_indices_reacciones_used" => false,
        "selective_fixed_flux_stationarity_dual_fit_r0001_used_as_oxygen" => false,
        "selective_fixed_flux_stationarity_dual_fit_is_scientific_simulation" => false,
    )
end

function _reduced_dcdfba_clip_bound_dual_starts_for_complementarity!(
    problem::ReducedDCDFBAMPCCSmokeProblem;
    element_indices = nothing,
    complementarity_tau::Real =
        get(problem.metadata, "complementarity_tau", REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU),
    complementarity_budget_fraction::Real =
        _reduced_dcdfba_fixed_flux_dual_fit_complementarity_budget_fraction(),
)::Dict{String, Any}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    state_values = problem.dynamic_bounds === nothing ? nothing :
                   _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)
    any(
        value -> value === nothing,
        (flux_values, lower_dual_values, upper_dual_values, mass_dual_values),
    ) && throw(
        ArgumentError("Reduced DC-dFBA bound-dual complementarity clipping requires finite flux and dual start values."),
    )
    problem.dynamic_bounds !== nothing && state_values === nothing && throw(
        ArgumentError("Reduced DC-dFBA bound-dual complementarity clipping requires finite state start values for dynamic bounds."),
    )
    isfinite(Float64(complementarity_tau)) && Float64(complementarity_tau) >= 0.0 || throw(
        ArgumentError("Reduced DC-dFBA bound-dual complementarity clipping requires a finite nonnegative complementarity tau."),
    )
    isfinite(Float64(complementarity_budget_fraction)) &&
        0.0 < Float64(complementarity_budget_fraction) <= 1.0 || throw(
        ArgumentError(
            "Reduced DC-dFBA bound-dual complementarity clipping requires a finite complementarity budget fraction in (0, 1].",
        ),
    )

    before = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )

    tau = Float64(complementarity_tau)
    budget_fraction = Float64(complementarity_budget_fraction)
    budget_tau = tau * budget_fraction
    n_reactions = problem.nlp.dimensions.n_reactions
    degree = problem.nlp.dimensions.collocation_degree
    clipped_lower_count = 0
    clipped_upper_count = 0
    lower_sign_clipped_count = 0
    upper_sign_clipped_count = 0
    collocation_points = 0
    max_dual_adjustment = 0.0

    for e in selected_elements, j in 1:degree
        collocation_points += 1
        flux = flux_values[:, e, j]
        bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, state_values)
        for r in 1:n_reactions
            lower_old = Float64(lower_dual_values[r, e, j])
            upper_old = Float64(upper_dual_values[r, e, j])
            lower_new = lower_old
            upper_new = upper_old

            if lower_new > 0.0
                lower_new = 0.0
                lower_sign_clipped_count += 1
            end
            if upper_new < 0.0
                upper_new = 0.0
                upper_sign_clipped_count += 1
            end

            lower_gap = abs(Float64(flux[r] - bounds.lb[r]))
            upper_gap = abs(Float64(flux[r] - bounds.ub[r]))
            if lower_gap > 0.0 && abs(lower_gap * lower_new) > budget_tau
                lower_limit = budget_tau / lower_gap
                lower_new = -min(abs(lower_new), lower_limit)
                clipped_lower_count += 1
            end
            if upper_gap > 0.0 && abs(upper_gap * upper_new) > budget_tau
                upper_limit = budget_tau / upper_gap
                upper_new = min(abs(upper_new), upper_limit)
                clipped_upper_count += 1
            end

            if lower_new != lower_old
                JuMP.set_start_value(
                    problem.bound_feasibility.lower_bound_duals[r, e, j],
                    lower_new,
                )
                lower_dual_values[r, e, j] = lower_new
                max_dual_adjustment = max(max_dual_adjustment, abs(lower_new - lower_old))
            end
            if upper_new != upper_old
                JuMP.set_start_value(
                    problem.bound_feasibility.upper_bound_duals[r, e, j],
                    upper_new,
                )
                upper_dual_values[r, e, j] = upper_new
                max_dual_adjustment = max(max_dual_adjustment, abs(upper_new - upper_old))
            end
        end
    end

    after = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )
    return Dict{String, Any}(
        "bound_dual_complementarity_clip_applied" => true,
        "bound_dual_complementarity_clip_policy" =>
            "sign_preserving_bound_dual_clipping_to_scholtes_budget",
        "bound_dual_complementarity_clip_finite_element_count" => length(selected_elements),
        "bound_dual_complementarity_clip_collocation_points" => collocation_points,
        "bound_dual_complementarity_clip_complementarity_tau" => tau,
        "bound_dual_complementarity_clip_complementarity_budget_fraction" =>
            budget_fraction,
        "bound_dual_complementarity_clip_effective_complementarity_budget_tau" =>
            budget_tau,
        "bound_dual_complementarity_clip_lower_count" => clipped_lower_count,
        "bound_dual_complementarity_clip_upper_count" => clipped_upper_count,
        "bound_dual_complementarity_clip_lower_sign_count" => lower_sign_clipped_count,
        "bound_dual_complementarity_clip_upper_sign_count" => upper_sign_clipped_count,
        "bound_dual_complementarity_clip_max_dual_adjustment" => max_dual_adjustment,
        "bound_dual_complementarity_clip_max_stationarity_residual_before" =>
            before.max_stationarity_residual,
        "bound_dual_complementarity_clip_max_stationarity_residual_after" =>
            after.max_stationarity_residual,
        "bound_dual_complementarity_clip_max_lower_complementarity_residual_before" =>
            before.max_lower_complementarity_residual,
        "bound_dual_complementarity_clip_max_lower_complementarity_residual_after" =>
            after.max_lower_complementarity_residual,
        "bound_dual_complementarity_clip_max_upper_complementarity_residual_before" =>
            before.max_upper_complementarity_residual,
        "bound_dual_complementarity_clip_max_upper_complementarity_residual_after" =>
            after.max_upper_complementarity_residual,
        "bound_dual_complementarity_clip_max_mass_balance_residual_after" =>
            after.max_mass_balance_residual,
        "bound_dual_complementarity_clip_max_lower_bound_violation_after" =>
            after.max_lower_bound_violation,
        "bound_dual_complementarity_clip_max_upper_bound_violation_after" =>
            after.max_upper_bound_violation,
    )
end

function _reduced_dcdfba_stationarity_start_objective_weights(
    model::MetabolicModel,
    objective_coefficients::Vector{Float64},
)::Dict{String, Float64}
    return Dict{String, Float64}(
        model.rxn_ids[r] => objective_coefficients[r] for
        r in eachindex(objective_coefficients) if !iszero(objective_coefficients[r])
    )
end

function _reduced_dcdfba_bound_crossing_summary(
    lb::AbstractVector{<:Real},
    ub::AbstractVector{<:Real},
)
    count = 0
    max_gap = 0.0
    for i in eachindex(lb, ub)
        gap = Float64(lb[i] - ub[i])
        if gap > 0.0
            count += 1
            max_gap = max(max_gap, gap)
        end
    end
    return (count = count, max_gap = max_gap)
end

function _reduced_dcdfba_dynamic_flux_lp_start_objective_weights(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    element_index::Int,
    collocation_index::Int,
    state_values,
)::Dict{String, Float64}
    coefficients =
        _reduced_dcdfba_numeric_stationarity_coefficients(problem, element_index, collocation_index, state_values)
    model = problem.nlp.kkt_problem.model
    return Dict{String, Float64}(
        model.rxn_ids[r] => -coefficients[r] for
        r in eachindex(coefficients) if !iszero(coefficients[r])
    )
end

function _reduced_dcdfba_stationarity_has_objective(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)::Bool
    any(!iszero, problem.stationarity.objective_coefficients) && return true
    return !isempty(problem.stationarity.objective_coefficient_expressions)
end

function _reduced_dcdfba_stationarity_start_local_model(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    state_values,
    element_index::Int,
    collocation_index::Int,
)::MetabolicModel
    model = problem.nlp.kkt_problem.model
    problem.dynamic_bounds === nothing && return model

    bounds = _reduced_dcdfba_numeric_flux_bounds(problem, element_index, collocation_index, state_values)
    any(bounds.lb .> bounds.ub) && throw(
        ArgumentError("Reduced DC-dFBA stationarity dual-start local model has lb > ub."),
    )
    return MetabolicModel(
        model.S,
        bounds.lb,
        bounds.ub,
        model.rxn_ids,
        model.met_ids;
        model_id = model.model_id,
    )
end

function _reduced_dcdfba_stationarity_lp_mass_duals(
    lp_problem,
    n_metabolites::Int,
)::Vector{Float64}
    mass_duals = Vector{Float64}(undef, n_metabolites)
    for m in 1:n_metabolites
        constraint = JuMP.constraint_by_name(lp_problem.jump_model, "steady_state[$m]")
        constraint === nothing && throw(
            ArgumentError("Reduced DC-dFBA stationarity dual-start LP is missing steady_state[$m]."),
        )
        mass_duals[m] = -Float64(JuMP.dual(constraint))
    end
    return mass_duals
end

function _reduced_dcdfba_stationarity_lp_bound_duals(
    lp_problem,
    n_reactions::Int,
)::Tuple{Vector{Float64}, Vector{Float64}, Float64}
    lower_duals = Vector{Float64}(undef, n_reactions)
    upper_duals = Vector{Float64}(undef, n_reactions)
    max_sign_clipping = 0.0
    for r in 1:n_reactions
        raw_lower = -Float64(JuMP.dual(JuMP.LowerBoundRef(lp_problem.fluxes[r])))
        raw_upper = -Float64(JuMP.dual(JuMP.UpperBoundRef(lp_problem.fluxes[r])))
        lower_duals[r] = min(raw_lower, 0.0)
        upper_duals[r] = max(raw_upper, 0.0)
        max_sign_clipping = max(
            max_sign_clipping,
            abs(lower_duals[r] - raw_lower),
            abs(upper_duals[r] - raw_upper),
        )
    end
    return lower_duals, upper_duals, max_sign_clipping
end

function _reduced_dcdfba_apply_rhs_consistent_derivative_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    ;
    element_indices = nothing,
)::Dict{String, Any}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    problem.rhs_residuals === nothing && return Dict{String, Any}(
        "rhs_consistent_derivative_start_applied" => false,
        "rhs_consistent_derivative_start_policy" => "not_applied_no_rhs_residuals",
        "rhs_consistent_derivative_start_finite_element_count" => length(selected_elements),
        "rhs_consistent_derivative_start_collocation_points" => 0,
        "rhs_consistent_derivative_start_max_adjustment" => 0.0,
        "rhs_consistent_derivative_start_max_abs_value" => 0.0,
        "rhs_consistent_derivative_start_max_rhs_residual_after" => NaN,
    )

    state_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    derivative_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_derivative)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    any(value -> value === nothing, (state_values, derivative_values, flux_values)) && throw(
        ArgumentError("Reduced DC-dFBA RHS-consistent derivative starts require finite state, derivative, and flux start values."),
    )

    collocation_points = 0
    max_adjustment = 0.0
    max_abs_value = 0.0
    for e in selected_elements, j in 1:problem.nlp.dimensions.collocation_degree
        collocation_points += 1
        expected = _reduced_dcdfba_mpcc_rhs_expected_vector(problem, state_values, flux_values, e, j)
        for i in 1:KKT_DFBA_STATE_COUNT
            max_adjustment = max(max_adjustment, abs(expected[i] - derivative_values[i, e, j]))
            max_abs_value = max(max_abs_value, abs(expected[i]))
            JuMP.set_start_value(problem.nlp.state_derivative[i, e, j], expected[i])
            derivative_values[i, e, j] = expected[i]
        end
    end

    rhs_residual_after = _reduced_dcdfba_mpcc_rhs_residual_from_values(
        problem,
        state_values,
        derivative_values,
        flux_values,
    )
    return Dict{String, Any}(
        "rhs_consistent_derivative_start_applied" => true,
        "rhs_consistent_derivative_start_policy" =>
            "set_state_derivative_starts_to_reduced_dfba_rhs_at_collocation_points",
        "rhs_consistent_derivative_start_finite_element_count" => length(selected_elements),
        "rhs_consistent_derivative_start_collocation_points" => collocation_points,
        "rhs_consistent_derivative_start_max_adjustment" => max_adjustment,
        "rhs_consistent_derivative_start_max_abs_value" => max_abs_value,
        "rhs_consistent_derivative_start_max_rhs_residual_after" => rhs_residual_after,
        "rhs_consistent_derivative_start_oxygen_derivative_policy" =>
            "dy6_fixed_zero_for_reduced_model",
        "rhs_consistent_derivative_start_carbohydrate_policy" =>
            "empirical_rhs_not_driven_by_r_4048",
        "rhs_consistent_derivative_start_is_scientific_simulation" => false,
    )
end

function _reduced_dcdfba_start_element_indices(nfe::Int, element_indices)::Vector{Int}
    nfe > 0 || throw(ArgumentError("Reduced DC-dFBA start refresh requires nfe > 0."))
    element_indices === nothing && return collect(1:nfe)
    indices = sort!(unique!(Int.(collect(element_indices))))
    all(index -> 1 <= index <= nfe, indices) || throw(
        ArgumentError(
            "Reduced DC-dFBA start refresh element indices must be between 1 and $nfe.",
        ),
    )
    if length(indices) > 1 && any(diff(indices) .!= 1)
        throw(ArgumentError("Reduced DC-dFBA start refresh element indices must be contiguous."))
    end
    return indices
end

function _reduced_dcdfba_parse_positive_int_token(
    raw_token,
    raw_value::AbstractString,
    env_name::AbstractString,
)::Int
    token = strip(string(raw_token))
    value = tryparse(Int, token)
    value !== nothing && value > 0 || throw(
        ArgumentError("$env_name must contain positive integer element indices; got: $raw_value"),
    )
    return value
end

function _reduced_dcdfba_parse_env_contiguous_element_indices(
    nfe::Int,
    raw_value,
    env_name::AbstractString;
    default_indices = nothing,
)::Vector{Int}
    cleaned = strip(replace(string(raw_value), ';' => ','))
    normalized = lowercase(cleaned)
    isempty(cleaned) &&
        return _reduced_dcdfba_start_element_indices(nfe, default_indices)
    normalized in ("all", "*") && return collect(1:nfe)

    range_separator = occursin(":", cleaned) ? ":" :
                      (occursin("-", cleaned) && !occursin(",", cleaned) ? "-" : "")
    if !isempty(range_separator)
        tokens = split(cleaned, range_separator)
        length(tokens) == 2 || throw(
            ArgumentError("$env_name must be a contiguous range like 129:168 or a comma list; got: $raw_value"),
        )
        first_element =
            _reduced_dcdfba_parse_positive_int_token(tokens[1], cleaned, env_name)
        last_element =
            _reduced_dcdfba_parse_positive_int_token(tokens[2], cleaned, env_name)
        first_element <= last_element || throw(
            ArgumentError("$env_name range must be increasing; got: $raw_value"),
        )
        return _reduced_dcdfba_start_element_indices(nfe, first_element:last_element)
    end

    indices = sort!(
        unique!(
            [
                _reduced_dcdfba_parse_positive_int_token(token, cleaned, env_name) for
                token in split(cleaned, ',') if !isempty(strip(token))
            ],
        ),
    )
    return _reduced_dcdfba_start_element_indices(nfe, indices)
end

function _reduced_dcdfba_parse_env_contiguous_element_segments(
    nfe::Int,
    raw_value,
    env_name::AbstractString,
)::Vector{Vector{Int}}
    cleaned = strip(string(raw_value))
    isempty(cleaned) && return Vector{Int}[]
    normalized = lowercase(cleaned)
    normalized in ("off", "none", "disabled") && return Vector{Int}[]

    segments = Vector{Vector{Int}}()
    for token in split(replace(cleaned, '|' => ';'), ';')
        segment_raw = strip(String(token))
        isempty(segment_raw) && continue
        push!(
            segments,
            _reduced_dcdfba_parse_env_contiguous_element_indices(
                nfe,
                segment_raw,
                env_name,
            ),
        )
    end
    return segments
end

function _reduced_dcdfba_apply_collocation_consistent_state_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem;
    max_iterations::Int = 4,
    tolerance::Float64 = 1.0e-10,
    element_indices = nothing,
)::Dict{String, Any}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    max_iterations >= 0 || throw(
        ArgumentError("Reduced DC-dFBA collocation-consistent state starts require max_iterations >= 0."),
    )
    isfinite(tolerance) && tolerance > 0.0 || throw(
        ArgumentError("Reduced DC-dFBA collocation-consistent state starts require a finite positive tolerance."),
    )
    problem.rhs_residuals === nothing && return Dict{String, Any}(
        "collocation_consistent_state_start_applied" => false,
        "collocation_consistent_state_start_policy" => "not_applied_no_rhs_residuals",
        "collocation_consistent_state_start_finite_element_count" =>
            length(selected_elements),
        "collocation_consistent_state_start_iterations" => 0,
        "collocation_consistent_state_start_max_iterations" => max_iterations,
        "collocation_consistent_state_start_tolerance" => tolerance,
        "collocation_consistent_state_start_converged" => false,
        "collocation_consistent_state_start_initial_collocation_residual" => NaN,
        "collocation_consistent_state_start_initial_continuity_residual" => NaN,
        "collocation_consistent_state_start_initial_rhs_residual" => NaN,
        "collocation_consistent_state_start_final_collocation_residual" => NaN,
        "collocation_consistent_state_start_final_continuity_residual" => NaN,
        "collocation_consistent_state_start_final_rhs_residual" => NaN,
        "collocation_consistent_state_start_max_state_collocation_adjustment" => 0.0,
        "collocation_consistent_state_start_max_state_boundary_adjustment" => 0.0,
        "collocation_consistent_state_start_initial_max_residual" => NaN,
        "collocation_consistent_state_start_final_max_residual" => NaN,
        "collocation_consistent_state_start_score_policy" => "collocation_state",
        "collocation_consistent_state_start_initial_score" => NaN,
        "collocation_consistent_state_start_final_score" => NaN,
        "collocation_consistent_state_start_best_score" => NaN,
        "collocation_consistent_state_start_last_residual_improvement" => NaN,
        "collocation_consistent_state_start_last_score_improvement" => NaN,
        "collocation_consistent_state_start_trace_enabled" => false,
        "collocation_consistent_state_start_restore_best_enabled" => true,
        "collocation_consistent_state_start_monotone_enabled" => true,
        "collocation_consistent_state_start_trace_substeps_enabled" => false,
        "collocation_consistent_state_start_final_state_refresh_enabled" => false,
        "collocation_consistent_state_start_final_flux_projection_enabled" => false,
        "collocation_consistent_state_start_final_dual_fit_enabled" => false,
        "collocation_consistent_state_start_final_selective_dual_fit_enabled" => false,
        "collocation_consistent_state_start_last_final_selective_dual_fit_applied" => false,
        "collocation_consistent_state_start_final_state_after_rhs_enabled" => false,
        "collocation_consistent_state_start_final_state_after_rhs_guard_enabled" => true,
        "collocation_consistent_state_start_final_state_after_rhs_guard_policy" =>
            "not_applied_no_rhs_residuals",
        "collocation_consistent_state_start_final_state_after_rhs_guard_accepted" => false,
        "collocation_consistent_state_start_final_state_after_rhs_guard_trial_count" => 0,
        "collocation_consistent_state_start_final_state_after_rhs_guard_accepted_damping_factor" =>
            missing,
        "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_enabled" =>
            false,
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_primal_structural_residual" =>
            NaN,
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_primal_structural_residual" =>
            NaN,
        "collocation_consistent_state_start_flux_refresh_guard_enabled" => false,
        "collocation_consistent_state_start_flux_refresh_guard_policy" =>
            "not_applied_no_rhs_residuals",
        "collocation_consistent_state_start_flux_refresh_guard_score_policy" =>
            "candidate_threshold_ratio",
        "collocation_consistent_state_start_flux_refresh_guard_acceptance_tolerance" =>
            0.0,
        "collocation_consistent_state_start_flux_refresh_guard_accepted" => false,
        "collocation_consistent_state_start_flux_refresh_guard_before_score" => NaN,
        "collocation_consistent_state_start_flux_refresh_guard_after_score" => NaN,
        "collocation_consistent_state_start_flux_refresh_max_iterations" => 0,
        "collocation_consistent_state_start_trace_every" => 1,
        "collocation_consistent_state_start_damping_factors" =>
            [1.0, 0.5, 0.25, 0.1, 0.05, 0.01],
        "collocation_consistent_state_start_monotone_acceptance_tolerance" => 0.0,
        "collocation_consistent_state_start_trial_count" => 0,
        "collocation_consistent_state_start_rejected_trial_count" => 0,
        "collocation_consistent_state_start_last_accepted_damping_factor" => missing,
        "collocation_consistent_state_start_min_accepted_damping_factor" => missing,
        "collocation_consistent_state_start_last_rejected_damping_factor" => missing,
        "collocation_consistent_state_start_last_rejected_max_residual" => NaN,
        "collocation_consistent_state_start_last_rejected_score" => NaN,
        "collocation_consistent_state_start_stopped_by_monotone_guard" => false,
        "collocation_consistent_state_start_last_final_state_refresh_applied" => false,
        "collocation_consistent_state_start_last_final_flux_projection_applied" => false,
        "collocation_consistent_state_start_last_final_dual_fit_applied" => false,
        "collocation_consistent_state_start_last_final_state_after_rhs_applied" => false,
        "collocation_consistent_state_start_last_dynamic_flux_refresh_applied" => false,
        "collocation_consistent_state_start_last_final_state_collocation_adjustment" => 0.0,
        "collocation_consistent_state_start_last_final_state_boundary_adjustment" => 0.0,
        "collocation_consistent_state_start_best_iteration" => 0,
        "collocation_consistent_state_start_best_max_residual" => NaN,
        "collocation_consistent_state_start_restored_best_iteration" => false,
        "collocation_consistent_state_start_restore_best_improvement" => 0.0,
        "collocation_consistent_state_start_restore_best_score_improvement" => 0.0,
        "collocation_consistent_state_start_stagnation_tolerance" => 0.0,
        "collocation_consistent_state_start_stagnation_iterations" => 0,
        "collocation_consistent_state_start_stagnation_counter" => 0,
        "collocation_consistent_state_start_stopped_by_stagnation" => false,
        "collocation_consistent_state_start_last_dynamic_flux_lp_attempt_count" => 0,
        "collocation_consistent_state_start_last_dynamic_flux_lp_total_solve_elapsed_seconds" =>
            0.0,
        "collocation_consistent_state_start_last_dynamic_flux_lp_max_solve_elapsed_seconds" =>
            0.0,
        "collocation_consistent_state_start_repair_trace" => Dict{String, Any}[],
        "collocation_consistent_state_start_repair_trace_count" => 0,
        "collocation_consistent_state_start_repair_substep_trace" =>
            Dict{String, Any}[],
        "collocation_consistent_state_start_repair_substep_trace_count" => 0,
        "collocation_consistent_state_start_feasibility_projection_enabled" => false,
        "collocation_consistent_state_start_feasibility_projection_applied" => false,
        "collocation_consistent_state_start_feasibility_projection_segment_count" => 0,
        "collocation_consistent_state_start_feasibility_projection_accepted_count" => 0,
        "collocation_consistent_state_start_feasibility_projection_trial_count" => 0,
        "collocation_consistent_state_start_feasibility_projection_rejected_trial_count" => 0,
        "collocation_consistent_state_start_feasibility_projection_records" =>
            Dict{String, Any}[],
        "collocation_consistent_state_start_segment_repair_enabled" => false,
        "collocation_consistent_state_start_segment_repair_applied" => false,
        "collocation_consistent_state_start_segment_repair_segment_count" => 0,
        "collocation_consistent_state_start_segment_repair_accepted_count" => 0,
        "collocation_consistent_state_start_segment_repair_trial_count" => 0,
        "collocation_consistent_state_start_segment_repair_rejected_trial_count" => 0,
        "collocation_consistent_state_start_segment_repair_records" =>
            Dict{String, Any}[],
        "collocation_consistent_state_start_is_scientific_simulation" => false,
    )

    options = _reduced_dcdfba_collocation_repair_start_options()
    repair_trace_records = Dict{String, Any}[]
    repair_substep_trace_records = Dict{String, Any}[]
    initial_residuals = _reduced_dcdfba_collocation_state_start_residual_summary(problem)
    final_residuals = initial_residuals
    initial_residual_max =
        _reduced_dcdfba_collocation_state_start_residual_max(initial_residuals)
    final_residual_max = initial_residual_max
    repair_score_policy = String(options.repair_score_policy)
    initial_score_summary = _reduced_dcdfba_collocation_repair_substep_summary(
        problem,
        "initial_repair_score";
        include_structural = repair_score_policy != "collocation_state",
    )
    initial_repair_score = _reduced_dcdfba_collocation_repair_guard_score(
        problem,
        initial_score_summary,
        repair_score_policy,
    )
    final_repair_score = initial_repair_score
    best_residuals = initial_residuals
    best_residual_max = initial_residual_max
    best_repair_score = initial_repair_score
    best_iteration = 0
    best_start_values =
        options.restore_best ? _reduced_dcdfba_mpcc_scaling_start_values(problem) : nothing
    last_residual_improvement = NaN
    last_score_improvement = NaN
    max_collocation_adjustment = 0.0
    max_boundary_adjustment = 0.0
    iterations = 0
    stagnation_counter = 0
    stopped_by_stagnation = false
    stopped_by_monotone_guard = false
    trial_count = 0
    rejected_trial_count = 0
    last_accepted_damping_factor = missing
    min_accepted_damping_factor = missing
    last_rejected_damping_factor = missing
    last_rejected_max_residual = NaN
    last_rejected_score = NaN
    last_final_state_refresh_applied = false
    last_final_flux_projection_applied = false
    last_final_complementarity_flux_projection_applied = false
    last_final_dual_fit_applied = false
    last_final_selective_dual_fit_applied = false
    last_final_state_after_rhs_applied = false
    last_dynamic_flux_refresh_applied = false
    last_final_state_collocation_adjustment = 0.0
    last_final_state_boundary_adjustment = 0.0
    last_dynamic_flux_metadata = Dict{String, Any}()
    converged = _reduced_dcdfba_collocation_state_start_converged(
        final_residuals,
        tolerance,
    )
    if options.trace
        _reduced_dcdfba_print_collocation_repair_trace(
            iterations,
            final_residuals,
            final_residual_max,
            NaN,
            0.0,
            0.0,
            last_dynamic_flux_metadata,
            converged,
        )
    end

    while !converged &&
              iterations < max_iterations &&
              !stopped_by_stagnation &&
              !stopped_by_monotone_guard
        iterations += 1
        previous_residual_max = final_residual_max
        previous_repair_score = final_repair_score
        baseline_start_values = _reduced_dcdfba_mpcc_scaling_start_values(problem)
        accepted_trial = nothing
        trial_factors = options.monotone ? options.damping_factors : [1.0]
        refresh_dynamic_flux =
            options.flux_refresh_max_iterations == 0 ||
            iterations <= options.flux_refresh_max_iterations
        for damping_factor in trial_factors
            trial = _reduced_dcdfba_evaluate_collocation_repair_trial!(
                problem,
                baseline_start_values,
                selected_elements,
                Float64(damping_factor),
                iteration = iterations,
                trace_substeps = options.trace_substeps,
                final_state_refresh = options.final_state_refresh,
                final_flux_projection = options.final_flux_projection,
                final_complementarity_flux_projection =
                    options.final_complementarity_flux_projection,
                final_complementarity_flux_projection_trigger_threshold =
                    options.final_complementarity_flux_projection_trigger_threshold,
                final_dual_fit = options.final_dual_fit,
                final_selective_dual_fit = options.final_selective_dual_fit,
                final_selective_dual_fit_trigger_threshold =
                    options.final_selective_dual_fit_trigger_threshold,
                final_state_after_rhs = options.final_state_after_rhs,
                final_state_after_rhs_guard = options.final_state_after_rhs_guard,
                final_state_after_rhs_acceptance_tolerance =
                    options.final_state_after_rhs_acceptance_tolerance,
                final_state_after_rhs_damping_factors =
                    options.final_state_after_rhs_damping_factors,
                final_state_after_rhs_refresh_rhs =
                    options.final_state_after_rhs_refresh_rhs,
                final_state_after_rhs_guard_score =
                    options.final_state_after_rhs_guard_score,
                repair_score_policy = repair_score_policy,
                refresh_dynamic_flux = refresh_dynamic_flux,
                flux_refresh_guard = options.flux_refresh_guard,
                flux_refresh_guard_score = options.flux_refresh_guard_score,
                flux_refresh_guard_acceptance_tolerance =
                    options.flux_refresh_guard_acceptance_tolerance,
            )
            trial_count += 1
            trial_improvement =
                isfinite(previous_residual_max) && isfinite(trial.residual_max) ?
                previous_residual_max - trial.residual_max :
                NaN
            trial_score_improvement =
                isfinite(previous_repair_score) && isfinite(trial.repair_score) ?
                previous_repair_score - trial.repair_score :
                NaN
            accepted =
                !options.monotone ||
                _reduced_dcdfba_collocation_repair_trial_accepted(
                    trial.repair_score,
                    previous_repair_score,
                    options.monotone_acceptance_tolerance,
                )
            push!(
                repair_trace_records,
                Dict{String, Any}(
                    "phase" => "main",
                    "iteration" => iterations,
                    "trial_index" => trial_count,
                    "first_element" =>
                        isempty(selected_elements) ? missing : first(selected_elements),
                    "last_element" =>
                        isempty(selected_elements) ? missing : last(selected_elements),
                    "finite_element_count" => length(selected_elements),
                    "damping_factor" => trial.damping_factor,
                    "score_policy" => repair_score_policy,
                    "previous_score" => previous_repair_score,
                    "score" => trial.repair_score,
                    "score_improvement" => trial_score_improvement,
                    "previous_max_residual" => previous_residual_max,
                    "max_residual" => trial.residual_max,
                    "residual_improvement" => trial_improvement,
                    "collocation_residual" => trial.residuals.collocation,
                    "continuity_residual" => trial.residuals.continuity,
                    "rhs_residual" => trial.residuals.rhs,
                    "accepted" => accepted,
                    "residual_accepted" => accepted,
                    "guard_accepted" => missing,
                    "guard_score_policy" => missing,
                    "before_guard_score" => missing,
                    "guard_score" => missing,
                    "dynamic_flux_refresh_applied" => trial.dynamic_flux_refresh_applied,
                    "final_state_refresh_applied" => trial.final_state_refresh_applied,
                    "final_flux_projection_applied" => trial.final_flux_projection_applied,
                    "final_state_after_rhs_applied" => trial.final_state_after_rhs_applied,
                    "final_state_after_rhs_guard_accepted" => get(
                        trial.refresh_metadata,
                        "collocation_consistent_state_start_final_state_after_rhs_guard_accepted",
                        missing,
                    ),
                ),
            )
            _reduced_dcdfba_push_collocation_repair_substep_trace!(
                repair_substep_trace_records,
                "main",
                iterations,
                trial_count,
                selected_elements,
                trial.damping_factor,
                accepted,
                trial,
            )
            if options.trace
                println(
                    "collocation_repair_trial: iteration=$iterations damping_factor=$(trial.damping_factor) score_policy=$repair_score_policy score=$(trial.repair_score) score_improvement=$trial_score_improvement max_residual=$(trial.residual_max) residual_improvement=$trial_improvement accepted=$accepted",
                )
                flush(stdout)
            end
            if accepted
                accepted_trial = trial
                last_accepted_damping_factor = trial.damping_factor
                min_accepted_damping_factor =
                    min_accepted_damping_factor === missing ?
                    trial.damping_factor :
                    min(Float64(min_accepted_damping_factor), trial.damping_factor)
                break
            end
            rejected_trial_count += 1
            last_rejected_damping_factor = trial.damping_factor
            last_rejected_max_residual = trial.residual_max
            last_rejected_score = trial.repair_score
        end

        if accepted_trial === nothing
            _reduced_dcdfba_restore_mpcc_start_values!(problem, baseline_start_values)
            final_residuals = _reduced_dcdfba_collocation_state_start_residual_summary(problem)
            final_residual_max =
                _reduced_dcdfba_collocation_state_start_residual_max(final_residuals)
            final_score_summary = _reduced_dcdfba_collocation_repair_substep_summary(
                problem,
                "monotone_rejected_restore_score";
                include_structural = repair_score_policy != "collocation_state",
            )
            final_repair_score = _reduced_dcdfba_collocation_repair_guard_score(
                problem,
                final_score_summary,
                repair_score_policy,
            )
            last_residual_improvement = 0.0
            last_score_improvement = 0.0
            stopped_by_monotone_guard = options.monotone
            if options.trace && stopped_by_monotone_guard
                println(
                    "collocation_repair_monotone_stop: iteration=$iterations score_policy=$repair_score_policy previous_score=$previous_repair_score previous_max_residual=$previous_residual_max rejected_trials=$rejected_trial_count last_rejected_damping_factor=$last_rejected_damping_factor last_rejected_score=$last_rejected_score last_rejected_max_residual=$last_rejected_max_residual",
                )
                flush(stdout)
            end
            break
        end

        collocation_adjustment = accepted_trial.collocation_adjustment
        boundary_adjustment = accepted_trial.boundary_adjustment
        max_collocation_adjustment =
            max(max_collocation_adjustment, collocation_adjustment)
        max_boundary_adjustment = max(max_boundary_adjustment, boundary_adjustment)
        merge!(problem.metadata, accepted_trial.refresh_metadata)
        merge!(problem.nlp.metadata, accepted_trial.refresh_metadata)
        last_dynamic_flux_metadata = accepted_trial.dynamic_flux_metadata
        last_final_state_refresh_applied = accepted_trial.final_state_refresh_applied
        last_final_flux_projection_applied = accepted_trial.final_flux_projection_applied
        last_final_complementarity_flux_projection_applied =
            accepted_trial.final_complementarity_flux_projection_applied
        last_final_dual_fit_applied = accepted_trial.final_dual_fit_applied
        last_final_selective_dual_fit_applied =
            accepted_trial.final_selective_dual_fit_applied
        last_final_state_after_rhs_applied = accepted_trial.final_state_after_rhs_applied
        last_dynamic_flux_refresh_applied = accepted_trial.dynamic_flux_refresh_applied
        last_final_state_collocation_adjustment =
            accepted_trial.final_state_collocation_adjustment
        last_final_state_boundary_adjustment =
            accepted_trial.final_state_boundary_adjustment
        final_residuals = accepted_trial.residuals
        final_residual_max = accepted_trial.residual_max
        final_repair_score = accepted_trial.repair_score
        last_residual_improvement =
            isfinite(previous_residual_max) && isfinite(final_residual_max) ?
            previous_residual_max - final_residual_max :
            NaN
        last_score_improvement =
            isfinite(previous_repair_score) && isfinite(final_repair_score) ?
            previous_repair_score - final_repair_score :
            NaN
        if options.restore_best &&
           isfinite(final_repair_score) &&
           (!isfinite(best_repair_score) || final_repair_score < best_repair_score)
            best_residuals = final_residuals
            best_residual_max = final_residual_max
            best_repair_score = final_repair_score
            best_iteration = iterations
            best_start_values = _reduced_dcdfba_mpcc_scaling_start_values(problem)
        end
        converged = _reduced_dcdfba_collocation_state_start_converged(
            final_residuals,
            tolerance,
        )
        if !converged && options.stagnation_enabled
            if isfinite(last_score_improvement) &&
               last_score_improvement <= options.stagnation_tolerance
                stagnation_counter += 1
            else
                stagnation_counter = 0
            end
            stopped_by_stagnation = stagnation_counter >= options.stagnation_iterations
        end
        if options.trace &&
           (
               iterations == 1 ||
               iterations % options.trace_every == 0 ||
               converged ||
               stopped_by_stagnation
           )
            _reduced_dcdfba_print_collocation_repair_trace(
                iterations,
                final_residuals,
                final_residual_max,
                last_residual_improvement,
                collocation_adjustment,
                boundary_adjustment,
                last_dynamic_flux_metadata,
                converged,
            )
        end
        if options.trace && stopped_by_stagnation
            println(
                "collocation_repair_stagnation_stop: iteration=$iterations tolerance=$(options.stagnation_tolerance) consecutive_iterations=$stagnation_counter max_residual=$final_residual_max last_improvement=$last_residual_improvement",
            )
            flush(stdout)
        end
    end

    restored_best_iteration =
        options.restore_best &&
        best_start_values !== nothing &&
        isfinite(best_repair_score) &&
        isfinite(final_repair_score) &&
        best_repair_score < final_repair_score
    restore_best_improvement =
        restored_best_iteration ? final_residual_max - best_residual_max : 0.0
    restore_best_score_improvement =
        restored_best_iteration ? final_repair_score - best_repair_score : 0.0
    if restored_best_iteration
        _reduced_dcdfba_restore_mpcc_start_values!(problem, best_start_values)
        final_residuals = best_residuals
        final_residual_max = best_residual_max
        final_repair_score = best_repair_score
        converged = _reduced_dcdfba_collocation_state_start_converged(
            final_residuals,
            tolerance,
        )
        if options.trace
            println(
                "collocation_repair_restore_best: best_iteration=$best_iteration score_policy=$repair_score_policy restored_score=$final_repair_score score_improvement=$restore_best_score_improvement restored_max_residual=$final_residual_max residual_improvement=$restore_best_improvement",
            )
            flush(stdout)
        end
    end

    feasibility_projection_applied = false
    feasibility_projection_accepted_count = 0
    feasibility_projection_trial_count = 0
    feasibility_projection_rejected_trial_count = 0
    feasibility_projection_before_residual = final_residual_max
    feasibility_projection_after_residual = final_residual_max
    feasibility_projection_before_collocation_residual = final_residuals.collocation
    feasibility_projection_after_collocation_residual = final_residuals.collocation
    feasibility_projection_before_continuity_residual = final_residuals.continuity
    feasibility_projection_after_continuity_residual = final_residuals.continuity
    feasibility_projection_records = Dict{String, Any}[]
    feasibility_projection_ranges = String[]
    if options.feasibility_projection_enabled
        nfe = problem.nlp.dimensions.nfe
        feasibility_projection_elements_list =
            _reduced_dcdfba_parse_env_contiguous_element_segments(
                nfe,
                options.feasibility_projection_segments_raw,
                "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_SEGMENTS",
            )
        if isempty(feasibility_projection_elements_list)
            push!(feasibility_projection_elements_list, selected_elements)
        end
        feasibility_projection_applied = !isempty(feasibility_projection_elements_list)
        for (projection_index, projection_elements) in
            enumerate(feasibility_projection_elements_list)
            projection_first_element =
                isempty(projection_elements) ? missing : first(projection_elements)
            projection_last_element =
                isempty(projection_elements) ? missing : last(projection_elements)
            projection_label =
                isempty(projection_elements) ? "empty" :
                "$(first(projection_elements)):$(last(projection_elements))"
            push!(feasibility_projection_ranges, projection_label)
            projection_baseline = _reduced_dcdfba_mpcc_scaling_start_values(problem)
            projection_before_residual = final_residual_max
            projection_before_collocation_residual = final_residuals.collocation
            projection_before_continuity_residual = final_residuals.continuity
            projection_before_summary =
                _reduced_dcdfba_collocation_repair_substep_summary(
                    problem,
                    "before_feasibility_projection_guard_$projection_index";
                    include_structural = true,
                )
            projection_before_guard_score =
                _reduced_dcdfba_collocation_repair_guard_score(
                    problem,
                    projection_before_summary,
                    options.feasibility_projection_guard_score,
                )
            accepted_projection_trial = nothing
            accepted_projection_guard_score = NaN
            projection_local_trial_count = 0
            projection_local_rejected_trial_count = 0
            projection_last_rejected_damping_factor = missing
            projection_last_rejected_residual = NaN
            projection_last_rejected_guard_score = NaN
            for damping_factor in options.feasibility_projection_damping_factors
                projection_trial =
                    _reduced_dcdfba_evaluate_collocation_repair_trial!(
                        problem,
                        projection_baseline,
                        projection_elements,
                        Float64(damping_factor),
                        iteration = iterations + projection_index,
                        trace_substeps = options.trace_substeps,
                        final_state_refresh =
                            options.feasibility_projection_final_state_refresh,
                        final_flux_projection =
                            options.feasibility_projection_final_flux_projection,
                        final_complementarity_flux_projection = false,
                        final_complementarity_flux_projection_trigger_threshold =
                            options.final_complementarity_flux_projection_trigger_threshold,
                        final_dual_fit = false,
                        final_selective_dual_fit = false,
                        final_selective_dual_fit_trigger_threshold =
                            options.final_selective_dual_fit_trigger_threshold,
                        final_state_after_rhs =
                            options.feasibility_projection_final_state_after_rhs,
                        final_state_after_rhs_guard = true,
                        final_state_after_rhs_acceptance_tolerance =
                            options.feasibility_projection_guard_acceptance_tolerance,
                        final_state_after_rhs_damping_factors =
                            options.feasibility_projection_damping_factors,
                        final_state_after_rhs_refresh_rhs =
                            options.feasibility_projection_final_state_after_rhs_refresh_rhs,
                        final_state_after_rhs_guard_score =
                            options.feasibility_projection_guard_score,
                        repair_score_policy = "collocation_state",
                        refresh_dynamic_flux =
                            options.feasibility_projection_refresh_dynamic_flux,
                        flux_refresh_guard =
                            options.feasibility_projection_refresh_dynamic_flux,
                        flux_refresh_guard_score =
                            options.feasibility_projection_guard_score,
                        flux_refresh_guard_acceptance_tolerance =
                            options.feasibility_projection_guard_acceptance_tolerance,
                    )
                projection_local_trial_count += 1
                feasibility_projection_trial_count += 1
                projection_after_summary =
                    _reduced_dcdfba_collocation_repair_substep_summary(
                        problem,
                        "after_feasibility_projection_guard_$projection_index";
                        include_structural = true,
                    )
                projection_after_guard_score =
                    _reduced_dcdfba_collocation_repair_guard_score(
                        problem,
                        projection_after_summary,
                        options.feasibility_projection_guard_score,
                    )
                residual_accepted = _reduced_dcdfba_collocation_repair_trial_accepted(
                    projection_trial.residual_max,
                    projection_before_residual,
                    options.feasibility_projection_acceptance_tolerance,
                )
                guard_accepted = _reduced_dcdfba_collocation_repair_trial_not_worse(
                    projection_after_guard_score,
                    projection_before_guard_score,
                    options.feasibility_projection_guard_acceptance_tolerance,
                )
                accepted = residual_accepted && guard_accepted
                push!(
                    repair_trace_records,
                    Dict{String, Any}(
                        "phase" => "feasibility_projection",
                        "projection_index" => projection_index,
                        "iteration" => iterations + projection_index,
                        "trial_index" =>
                            trial_count + feasibility_projection_trial_count,
                        "first_element" => projection_first_element,
                        "last_element" => projection_last_element,
                        "finite_element_count" => length(projection_elements),
                        "damping_factor" => projection_trial.damping_factor,
                        "score_policy" => "collocation_state",
                        "previous_score" => missing,
                        "score" => projection_trial.repair_score,
                        "score_improvement" => missing,
                        "previous_max_residual" => projection_before_residual,
                        "max_residual" => projection_trial.residual_max,
                        "residual_improvement" =>
                            isfinite(projection_before_residual) &&
                            isfinite(projection_trial.residual_max) ?
                            projection_before_residual - projection_trial.residual_max :
                            NaN,
                        "collocation_residual" =>
                            projection_trial.residuals.collocation,
                        "continuity_residual" =>
                            projection_trial.residuals.continuity,
                        "rhs_residual" => projection_trial.residuals.rhs,
                        "accepted" => accepted,
                        "residual_accepted" => residual_accepted,
                        "guard_accepted" => guard_accepted,
                        "guard_score_policy" =>
                            options.feasibility_projection_guard_score,
                        "before_guard_score" => projection_before_guard_score,
                        "guard_score" => projection_after_guard_score,
                        "dynamic_flux_refresh_applied" =>
                            projection_trial.dynamic_flux_refresh_applied,
                        "final_state_refresh_applied" =>
                            projection_trial.final_state_refresh_applied,
                        "final_flux_projection_applied" =>
                            projection_trial.final_flux_projection_applied,
                        "final_state_after_rhs_applied" =>
                            projection_trial.final_state_after_rhs_applied,
                        "final_state_after_rhs_guard_accepted" => get(
                            projection_trial.refresh_metadata,
                            "collocation_consistent_state_start_final_state_after_rhs_guard_accepted",
                            missing,
                        ),
                    ),
                )
                _reduced_dcdfba_push_collocation_repair_substep_trace!(
                    repair_substep_trace_records,
                    "feasibility_projection",
                    iterations + projection_index,
                    trial_count + feasibility_projection_trial_count,
                    projection_elements,
                    projection_trial.damping_factor,
                    accepted,
                    projection_trial,
                )
                if options.trace
                    println(
                        "collocation_feasibility_projection_trial: projection=$projection_index elements=$projection_label damping_factor=$(projection_trial.damping_factor) residual=$(projection_trial.residual_max) before_residual=$projection_before_residual residual_accepted=$residual_accepted guard_score=$(projection_after_guard_score) before_guard_score=$projection_before_guard_score guard_policy=$(options.feasibility_projection_guard_score) guard_accepted=$guard_accepted dynamic_flux_refresh=$(options.feasibility_projection_refresh_dynamic_flux)",
                    )
                    flush(stdout)
                end
                if accepted
                    accepted_projection_trial = projection_trial
                    accepted_projection_guard_score = projection_after_guard_score
                    break
                end
                projection_local_rejected_trial_count += 1
                feasibility_projection_rejected_trial_count += 1
                projection_last_rejected_damping_factor =
                    projection_trial.damping_factor
                projection_last_rejected_residual = projection_trial.residual_max
                projection_last_rejected_guard_score = projection_after_guard_score
            end

            projection_accepted = accepted_projection_trial !== nothing
            projection_after_residual = projection_before_residual
            projection_after_collocation_residual = projection_before_collocation_residual
            projection_after_continuity_residual = projection_before_continuity_residual
            projection_after_guard_score = projection_before_guard_score
            projection_accepted_damping_factor = missing
            if !projection_accepted
                _reduced_dcdfba_restore_mpcc_start_values!(problem, projection_baseline)
            else
                feasibility_projection_accepted_count += 1
                projection_accepted_damping_factor =
                    accepted_projection_trial.damping_factor
                projection_after_residual = accepted_projection_trial.residual_max
                projection_after_guard_score = accepted_projection_guard_score
                merge!(problem.metadata, accepted_projection_trial.refresh_metadata)
                merge!(problem.nlp.metadata, accepted_projection_trial.refresh_metadata)
                last_dynamic_flux_metadata =
                    accepted_projection_trial.dynamic_flux_metadata
                last_final_state_refresh_applied =
                    accepted_projection_trial.final_state_refresh_applied
                last_final_flux_projection_applied =
                    accepted_projection_trial.final_flux_projection_applied
                last_final_complementarity_flux_projection_applied =
                    accepted_projection_trial.final_complementarity_flux_projection_applied
                last_final_dual_fit_applied =
                    accepted_projection_trial.final_dual_fit_applied
                last_final_selective_dual_fit_applied =
                    accepted_projection_trial.final_selective_dual_fit_applied
                last_final_state_after_rhs_applied =
                    accepted_projection_trial.final_state_after_rhs_applied
                last_dynamic_flux_refresh_applied =
                    accepted_projection_trial.dynamic_flux_refresh_applied
                last_final_state_collocation_adjustment =
                    accepted_projection_trial.final_state_collocation_adjustment
                last_final_state_boundary_adjustment =
                    accepted_projection_trial.final_state_boundary_adjustment
                max_collocation_adjustment = max(
                    max_collocation_adjustment,
                    accepted_projection_trial.collocation_adjustment,
                )
                max_boundary_adjustment = max(
                    max_boundary_adjustment,
                    accepted_projection_trial.boundary_adjustment,
                )
                final_residuals = accepted_projection_trial.residuals
                final_residual_max = accepted_projection_trial.residual_max
                final_score_summary =
                    _reduced_dcdfba_collocation_repair_substep_summary(
                        problem,
                        "after_feasibility_projection_final_score_$projection_index";
                        include_structural = repair_score_policy != "collocation_state",
                    )
                final_repair_score =
                    _reduced_dcdfba_collocation_repair_guard_score(
                        problem,
                        final_score_summary,
                        repair_score_policy,
                    )
                projection_after_collocation_residual = final_residuals.collocation
                projection_after_continuity_residual = final_residuals.continuity
                converged = _reduced_dcdfba_collocation_state_start_converged(
                    final_residuals,
                    tolerance,
                )
            end
            push!(
                feasibility_projection_records,
                Dict{String, Any}(
                    "projection_index" => projection_index,
                    "range" => projection_label,
                    "first_element" => projection_first_element,
                    "last_element" => projection_last_element,
                    "finite_element_count" => length(projection_elements),
                    "accepted" => projection_accepted,
                    "accepted_damping_factor" => projection_accepted_damping_factor,
                    "trial_count" => projection_local_trial_count,
                    "rejected_trial_count" => projection_local_rejected_trial_count,
                    "before_max_residual" => projection_before_residual,
                    "after_max_residual" => projection_after_residual,
                    "before_collocation_residual" =>
                        projection_before_collocation_residual,
                    "after_collocation_residual" =>
                        projection_after_collocation_residual,
                    "before_continuity_residual" =>
                        projection_before_continuity_residual,
                    "after_continuity_residual" =>
                        projection_after_continuity_residual,
                    "before_guard_score" => projection_before_guard_score,
                    "after_guard_score" => projection_after_guard_score,
                    "last_rejected_damping_factor" =>
                        projection_last_rejected_damping_factor,
                    "last_rejected_residual" => projection_last_rejected_residual,
                    "last_rejected_guard_score" =>
                        projection_last_rejected_guard_score,
                ),
            )
        end
        trial_count += feasibility_projection_trial_count
        rejected_trial_count += feasibility_projection_rejected_trial_count
        feasibility_projection_after_residual = final_residual_max
        feasibility_projection_after_collocation_residual = final_residuals.collocation
        feasibility_projection_after_continuity_residual = final_residuals.continuity
    end

    segment_repair_applied = false
    segment_repair_accepted_count = 0
    segment_repair_trial_count = 0
    segment_repair_rejected_trial_count = 0
    segment_repair_before_residual = final_residual_max
    segment_repair_after_residual = final_residual_max
    segment_repair_before_collocation_residual = final_residuals.collocation
    segment_repair_after_collocation_residual = final_residuals.collocation
    segment_repair_before_continuity_residual = final_residuals.continuity
    segment_repair_after_continuity_residual = final_residuals.continuity
    segment_repair_records = Dict{String, Any}[]
    segment_repair_ranges = String[]
    if options.segmented_repair_enabled
        nfe = problem.nlp.dimensions.nfe
        segment_elements_list =
            _reduced_dcdfba_parse_env_contiguous_element_segments(
                nfe,
                options.segmented_repair_segments_raw,
                "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS",
            )
        segment_repair_applied = !isempty(segment_elements_list)
        for (segment_index, segment_elements) in enumerate(segment_elements_list)
            segment_first_element =
                isempty(segment_elements) ? missing : first(segment_elements)
            segment_last_element =
                isempty(segment_elements) ? missing : last(segment_elements)
            segment_label =
                isempty(segment_elements) ? "empty" :
                "$(first(segment_elements)):$(last(segment_elements))"
            push!(segment_repair_ranges, segment_label)
            segment_baseline = _reduced_dcdfba_mpcc_scaling_start_values(problem)
            segment_before_residual = final_residual_max
            segment_before_collocation_residual = final_residuals.collocation
            segment_before_continuity_residual = final_residuals.continuity
            segment_before_summary = _reduced_dcdfba_collocation_repair_substep_summary(
                problem,
                "before_segment_repair_guard_$segment_index";
                include_structural = true,
            )
            segment_before_guard_score =
                _reduced_dcdfba_collocation_repair_guard_score(
                    problem,
                    segment_before_summary,
                    options.segmented_repair_guard_score,
                )
            accepted_segment_trial = nothing
            accepted_segment_guard_score = NaN
            segment_local_trial_count = 0
            segment_local_rejected_trial_count = 0
            segment_last_rejected_damping_factor = missing
            segment_last_rejected_residual = NaN
            segment_last_rejected_guard_score = NaN
            for damping_factor in options.segmented_repair_damping_factors
                segment_trial = _reduced_dcdfba_evaluate_collocation_repair_trial!(
                    problem,
                    segment_baseline,
                    segment_elements,
                    Float64(damping_factor),
                    iteration = iterations + segment_index,
                    trace_substeps = options.trace_substeps,
                    final_state_refresh = options.final_state_refresh,
                    final_flux_projection = options.final_flux_projection,
                    final_complementarity_flux_projection =
                        options.final_complementarity_flux_projection,
                    final_complementarity_flux_projection_trigger_threshold =
                        options.final_complementarity_flux_projection_trigger_threshold,
                    final_dual_fit = options.final_dual_fit,
                    final_selective_dual_fit = options.final_selective_dual_fit,
                    final_selective_dual_fit_trigger_threshold =
                        options.final_selective_dual_fit_trigger_threshold,
                    final_state_after_rhs = options.final_state_after_rhs,
                    final_state_after_rhs_guard = options.final_state_after_rhs_guard,
                    final_state_after_rhs_acceptance_tolerance =
                        options.final_state_after_rhs_acceptance_tolerance,
                    final_state_after_rhs_damping_factors =
                        options.final_state_after_rhs_damping_factors,
                    final_state_after_rhs_refresh_rhs =
                        options.final_state_after_rhs_refresh_rhs,
                    final_state_after_rhs_guard_score =
                        options.final_state_after_rhs_guard_score,
                    repair_score_policy = "collocation_state",
                    refresh_dynamic_flux = options.segmented_repair_refresh_dynamic_flux,
                    flux_refresh_guard = options.flux_refresh_guard,
                    flux_refresh_guard_score = options.flux_refresh_guard_score,
                    flux_refresh_guard_acceptance_tolerance =
                        options.flux_refresh_guard_acceptance_tolerance,
                )
                segment_local_trial_count += 1
                segment_repair_trial_count += 1
                segment_after_summary =
                    _reduced_dcdfba_collocation_repair_substep_summary(
                        problem,
                        "after_segment_repair_guard_$segment_index";
                        include_structural = true,
                    )
                segment_after_guard_score =
                    _reduced_dcdfba_collocation_repair_guard_score(
                        problem,
                        segment_after_summary,
                        options.segmented_repair_guard_score,
                    )
                residual_accepted = _reduced_dcdfba_collocation_repair_trial_accepted(
                    segment_trial.residual_max,
                    segment_before_residual,
                    options.segmented_repair_acceptance_tolerance,
                )
                guard_accepted = _reduced_dcdfba_collocation_repair_trial_not_worse(
                    segment_after_guard_score,
                    segment_before_guard_score,
                    options.segmented_repair_guard_acceptance_tolerance,
                )
                accepted = residual_accepted && guard_accepted
                push!(
                    repair_trace_records,
                    Dict{String, Any}(
                        "phase" => "segment",
                        "segment_index" => segment_index,
                        "iteration" => iterations + segment_index,
                        "trial_index" => trial_count + segment_repair_trial_count,
                        "first_element" => segment_first_element,
                        "last_element" => segment_last_element,
                        "finite_element_count" => length(segment_elements),
                        "damping_factor" => segment_trial.damping_factor,
                        "score_policy" => "collocation_state",
                        "previous_score" => missing,
                        "score" => segment_trial.repair_score,
                        "score_improvement" => missing,
                        "previous_max_residual" => segment_before_residual,
                        "max_residual" => segment_trial.residual_max,
                        "residual_improvement" =>
                            isfinite(segment_before_residual) &&
                            isfinite(segment_trial.residual_max) ?
                            segment_before_residual - segment_trial.residual_max :
                            NaN,
                        "collocation_residual" => segment_trial.residuals.collocation,
                        "continuity_residual" => segment_trial.residuals.continuity,
                        "rhs_residual" => segment_trial.residuals.rhs,
                        "accepted" => accepted,
                        "residual_accepted" => residual_accepted,
                        "guard_accepted" => guard_accepted,
                        "guard_score_policy" => options.segmented_repair_guard_score,
                        "before_guard_score" => segment_before_guard_score,
                        "guard_score" => segment_after_guard_score,
                        "dynamic_flux_refresh_applied" =>
                            segment_trial.dynamic_flux_refresh_applied,
                        "final_state_refresh_applied" =>
                            segment_trial.final_state_refresh_applied,
                        "final_flux_projection_applied" =>
                            segment_trial.final_flux_projection_applied,
                        "final_state_after_rhs_applied" =>
                            segment_trial.final_state_after_rhs_applied,
                        "final_state_after_rhs_guard_accepted" => get(
                            segment_trial.refresh_metadata,
                            "collocation_consistent_state_start_final_state_after_rhs_guard_accepted",
                            missing,
                        ),
                    ),
                )
                _reduced_dcdfba_push_collocation_repair_substep_trace!(
                    repair_substep_trace_records,
                    "segment",
                    iterations + segment_index,
                    trial_count + segment_repair_trial_count,
                    segment_elements,
                    segment_trial.damping_factor,
                    accepted,
                    segment_trial,
                )
                if options.trace
                    println(
                        "collocation_segment_repair_trial: segment=$segment_index elements=$segment_label damping_factor=$(segment_trial.damping_factor) residual=$(segment_trial.residual_max) before_residual=$segment_before_residual residual_accepted=$residual_accepted guard_score=$(segment_after_guard_score) before_guard_score=$segment_before_guard_score guard_policy=$(options.segmented_repair_guard_score) guard_accepted=$guard_accepted",
                    )
                    flush(stdout)
                end
                if accepted
                    accepted_segment_trial = segment_trial
                    accepted_segment_guard_score = segment_after_guard_score
                    break
                end
                segment_local_rejected_trial_count += 1
                segment_repair_rejected_trial_count += 1
                segment_last_rejected_damping_factor = segment_trial.damping_factor
                segment_last_rejected_residual = segment_trial.residual_max
                segment_last_rejected_guard_score = segment_after_guard_score
            end

            segment_accepted = accepted_segment_trial !== nothing
            segment_after_residual = segment_before_residual
            segment_after_collocation_residual = segment_before_collocation_residual
            segment_after_continuity_residual = segment_before_continuity_residual
            segment_after_guard_score = segment_before_guard_score
            segment_accepted_damping_factor = missing
            if !segment_accepted
                _reduced_dcdfba_restore_mpcc_start_values!(problem, segment_baseline)
            else
                segment_repair_accepted_count += 1
                segment_accepted_damping_factor =
                    accepted_segment_trial.damping_factor
                segment_after_residual = accepted_segment_trial.residual_max
                segment_after_guard_score = accepted_segment_guard_score
                merge!(problem.metadata, accepted_segment_trial.refresh_metadata)
                merge!(problem.nlp.metadata, accepted_segment_trial.refresh_metadata)
                last_dynamic_flux_metadata = accepted_segment_trial.dynamic_flux_metadata
                last_final_state_refresh_applied =
                    accepted_segment_trial.final_state_refresh_applied
                last_final_flux_projection_applied =
                    accepted_segment_trial.final_flux_projection_applied
                last_final_complementarity_flux_projection_applied =
                    accepted_segment_trial.final_complementarity_flux_projection_applied
                last_final_dual_fit_applied = accepted_segment_trial.final_dual_fit_applied
                last_final_selective_dual_fit_applied =
                    accepted_segment_trial.final_selective_dual_fit_applied
                last_final_state_after_rhs_applied =
                    accepted_segment_trial.final_state_after_rhs_applied
                last_dynamic_flux_refresh_applied =
                    accepted_segment_trial.dynamic_flux_refresh_applied
                last_final_state_collocation_adjustment =
                    accepted_segment_trial.final_state_collocation_adjustment
                last_final_state_boundary_adjustment =
                    accepted_segment_trial.final_state_boundary_adjustment
                max_collocation_adjustment = max(
                    max_collocation_adjustment,
                    accepted_segment_trial.collocation_adjustment,
                )
                max_boundary_adjustment =
                    max(max_boundary_adjustment, accepted_segment_trial.boundary_adjustment)
                final_residuals = accepted_segment_trial.residuals
                final_residual_max = accepted_segment_trial.residual_max
                final_score_summary =
                    _reduced_dcdfba_collocation_repair_substep_summary(
                        problem,
                        "after_segment_repair_final_score_$segment_index";
                        include_structural = repair_score_policy != "collocation_state",
                    )
                final_repair_score =
                    _reduced_dcdfba_collocation_repair_guard_score(
                        problem,
                        final_score_summary,
                        repair_score_policy,
                    )
                segment_after_collocation_residual = final_residuals.collocation
                segment_after_continuity_residual = final_residuals.continuity
                converged = _reduced_dcdfba_collocation_state_start_converged(
                    final_residuals,
                    tolerance,
                )
            end
            push!(
                segment_repair_records,
                Dict{String, Any}(
                    "segment_index" => segment_index,
                    "range" => segment_label,
                    "first_element" => segment_first_element,
                    "last_element" => segment_last_element,
                    "finite_element_count" => length(segment_elements),
                    "accepted" => segment_accepted,
                    "accepted_damping_factor" => segment_accepted_damping_factor,
                    "trial_count" => segment_local_trial_count,
                    "rejected_trial_count" => segment_local_rejected_trial_count,
                    "before_max_residual" => segment_before_residual,
                    "after_max_residual" => segment_after_residual,
                    "before_collocation_residual" =>
                        segment_before_collocation_residual,
                    "after_collocation_residual" =>
                        segment_after_collocation_residual,
                    "before_continuity_residual" =>
                        segment_before_continuity_residual,
                    "after_continuity_residual" =>
                        segment_after_continuity_residual,
                    "before_guard_score" => segment_before_guard_score,
                    "after_guard_score" => segment_after_guard_score,
                    "last_rejected_damping_factor" =>
                        segment_last_rejected_damping_factor,
                    "last_rejected_residual" => segment_last_rejected_residual,
                    "last_rejected_guard_score" =>
                        segment_last_rejected_guard_score,
                ),
            )
        end
        trial_count += segment_repair_trial_count
        rejected_trial_count += segment_repair_rejected_trial_count
        segment_repair_after_residual = final_residual_max
        segment_repair_after_collocation_residual = final_residuals.collocation
        segment_repair_after_continuity_residual = final_residuals.continuity
    end

    post_tail_repair_applied = false
    post_tail_repair_accepted = false
    post_tail_repair_defaulted_elements = false
    post_tail_repair_first_element = missing
    post_tail_repair_last_element = missing
    post_tail_repair_finite_element_count = 0
    post_tail_repair_trial_count = 0
    post_tail_repair_rejected_trial_count = 0
    post_tail_repair_accepted_damping_factor = missing
    post_tail_repair_last_rejected_damping_factor = missing
    post_tail_repair_last_rejected_residual = NaN
    post_tail_repair_last_rejected_guard_score = NaN
    post_tail_repair_before_residual = final_residual_max
    post_tail_repair_after_residual = final_residual_max
    post_tail_repair_before_collocation_residual = final_residuals.collocation
    post_tail_repair_after_collocation_residual = final_residuals.collocation
    post_tail_repair_before_continuity_residual = final_residuals.continuity
    post_tail_repair_after_continuity_residual = final_residuals.continuity
    post_tail_repair_before_guard_score = NaN
    post_tail_repair_after_guard_score = NaN
    if options.post_tail_repair_enabled
        post_tail_repair_applied = true
        nfe = problem.nlp.dimensions.nfe
        tail_count = max(1, cld(nfe, 4))
        default_tail_elements = max(1, nfe - tail_count + 1):nfe
        post_tail_repair_defaulted_elements =
            isempty(strip(String(options.post_tail_repair_elements_raw)))
        post_tail_elements = _reduced_dcdfba_parse_env_contiguous_element_indices(
            nfe,
            options.post_tail_repair_elements_raw,
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS";
            default_indices = default_tail_elements,
        )
        post_tail_repair_first_element =
            isempty(post_tail_elements) ? missing : first(post_tail_elements)
        post_tail_repair_last_element =
            isempty(post_tail_elements) ? missing : last(post_tail_elements)
        post_tail_repair_finite_element_count = length(post_tail_elements)
        post_tail_baseline = _reduced_dcdfba_mpcc_scaling_start_values(problem)
        post_tail_before_summary = _reduced_dcdfba_collocation_repair_substep_summary(
            problem,
            "before_post_tail_repair_guard";
            include_structural = true,
        )
        post_tail_repair_before_guard_score =
            _reduced_dcdfba_collocation_repair_guard_score(
                problem,
                post_tail_before_summary,
                options.post_tail_repair_guard_score,
            )
        accepted_post_tail_trial = nothing
        accepted_post_tail_guard_score = NaN
        for damping_factor in options.post_tail_repair_damping_factors
            post_tail_trial = _reduced_dcdfba_evaluate_collocation_repair_trial!(
                problem,
                post_tail_baseline,
                post_tail_elements,
                Float64(damping_factor),
                iteration = iterations + 1,
                trace_substeps = options.trace_substeps,
                final_state_refresh = options.final_state_refresh,
                final_flux_projection = options.final_flux_projection,
                final_complementarity_flux_projection =
                    options.final_complementarity_flux_projection,
                final_complementarity_flux_projection_trigger_threshold =
                    options.final_complementarity_flux_projection_trigger_threshold,
                final_dual_fit = options.final_dual_fit,
                final_selective_dual_fit = options.final_selective_dual_fit,
                final_selective_dual_fit_trigger_threshold =
                    options.final_selective_dual_fit_trigger_threshold,
                final_state_after_rhs = options.final_state_after_rhs,
                final_state_after_rhs_guard = options.final_state_after_rhs_guard,
                final_state_after_rhs_acceptance_tolerance =
                    options.final_state_after_rhs_acceptance_tolerance,
                final_state_after_rhs_damping_factors =
                    options.final_state_after_rhs_damping_factors,
                final_state_after_rhs_refresh_rhs =
                    options.final_state_after_rhs_refresh_rhs,
                final_state_after_rhs_guard_score =
                    options.final_state_after_rhs_guard_score,
                repair_score_policy = "collocation_state",
                refresh_dynamic_flux = options.post_tail_repair_refresh_dynamic_flux,
                flux_refresh_guard = options.flux_refresh_guard,
                flux_refresh_guard_score = options.flux_refresh_guard_score,
                flux_refresh_guard_acceptance_tolerance =
                    options.flux_refresh_guard_acceptance_tolerance,
            )
            post_tail_repair_trial_count += 1
            post_tail_after_summary = _reduced_dcdfba_collocation_repair_substep_summary(
                problem,
                "after_post_tail_repair_guard";
                include_structural = true,
            )
            post_tail_after_guard_score =
                _reduced_dcdfba_collocation_repair_guard_score(
                    problem,
                    post_tail_after_summary,
                    options.post_tail_repair_guard_score,
                )
            residual_accepted = _reduced_dcdfba_collocation_repair_trial_accepted(
                post_tail_trial.residual_max,
                post_tail_repair_before_residual,
                options.post_tail_repair_acceptance_tolerance,
            )
            guard_accepted = _reduced_dcdfba_collocation_repair_trial_not_worse(
                post_tail_after_guard_score,
                post_tail_repair_before_guard_score,
                options.post_tail_repair_guard_acceptance_tolerance,
            )
            push!(
                repair_trace_records,
                Dict{String, Any}(
                    "phase" => "post_tail",
                    "iteration" => iterations + 1,
                    "trial_index" => trial_count + post_tail_repair_trial_count,
                    "first_element" => post_tail_repair_first_element,
                    "last_element" => post_tail_repair_last_element,
                    "finite_element_count" => post_tail_repair_finite_element_count,
                    "damping_factor" => post_tail_trial.damping_factor,
                    "score_policy" => "collocation_state",
                    "previous_score" => missing,
                    "score" => post_tail_trial.repair_score,
                    "score_improvement" => missing,
                    "previous_max_residual" => post_tail_repair_before_residual,
                    "max_residual" => post_tail_trial.residual_max,
                    "residual_improvement" =>
                        isfinite(post_tail_repair_before_residual) &&
                        isfinite(post_tail_trial.residual_max) ?
                        post_tail_repair_before_residual - post_tail_trial.residual_max :
                        NaN,
                    "collocation_residual" => post_tail_trial.residuals.collocation,
                    "continuity_residual" => post_tail_trial.residuals.continuity,
                    "rhs_residual" => post_tail_trial.residuals.rhs,
                    "accepted" => residual_accepted && guard_accepted,
                    "residual_accepted" => residual_accepted,
                    "guard_accepted" => guard_accepted,
                    "guard_score_policy" => options.post_tail_repair_guard_score,
                    "before_guard_score" => post_tail_repair_before_guard_score,
                    "guard_score" => post_tail_after_guard_score,
                    "dynamic_flux_refresh_applied" =>
                        post_tail_trial.dynamic_flux_refresh_applied,
                    "final_state_refresh_applied" =>
                        post_tail_trial.final_state_refresh_applied,
                    "final_flux_projection_applied" =>
                        post_tail_trial.final_flux_projection_applied,
                    "final_state_after_rhs_applied" =>
                        post_tail_trial.final_state_after_rhs_applied,
                    "final_state_after_rhs_guard_accepted" => get(
                        post_tail_trial.refresh_metadata,
                        "collocation_consistent_state_start_final_state_after_rhs_guard_accepted",
                        missing,
                    ),
                ),
            )
            _reduced_dcdfba_push_collocation_repair_substep_trace!(
                repair_substep_trace_records,
                "post_tail",
                iterations + 1,
                trial_count + post_tail_repair_trial_count,
                post_tail_elements,
                post_tail_trial.damping_factor,
                residual_accepted && guard_accepted,
                post_tail_trial,
            )
            if options.trace
                println(
                    "collocation_post_tail_repair_trial: damping_factor=$(post_tail_trial.damping_factor) residual=$(post_tail_trial.residual_max) before_residual=$post_tail_repair_before_residual residual_accepted=$residual_accepted guard_score=$(post_tail_after_guard_score) before_guard_score=$post_tail_repair_before_guard_score guard_policy=$(options.post_tail_repair_guard_score) guard_accepted=$guard_accepted",
                )
                flush(stdout)
            end
            if residual_accepted && guard_accepted
                accepted_post_tail_trial = post_tail_trial
                accepted_post_tail_guard_score = post_tail_after_guard_score
                break
            end
            post_tail_repair_rejected_trial_count += 1
            post_tail_repair_last_rejected_damping_factor =
                post_tail_trial.damping_factor
            post_tail_repair_last_rejected_residual = post_tail_trial.residual_max
            post_tail_repair_last_rejected_guard_score = post_tail_after_guard_score
        end

        if accepted_post_tail_trial === nothing
            _reduced_dcdfba_restore_mpcc_start_values!(problem, post_tail_baseline)
            post_tail_repair_after_residual = post_tail_repair_before_residual
            post_tail_repair_after_guard_score = post_tail_repair_before_guard_score
        else
            post_tail_repair_accepted = true
            post_tail_repair_accepted_damping_factor =
                accepted_post_tail_trial.damping_factor
            post_tail_repair_after_residual = accepted_post_tail_trial.residual_max
            post_tail_repair_after_guard_score = accepted_post_tail_guard_score
            merge!(problem.metadata, accepted_post_tail_trial.refresh_metadata)
            merge!(problem.nlp.metadata, accepted_post_tail_trial.refresh_metadata)
            last_dynamic_flux_metadata = accepted_post_tail_trial.dynamic_flux_metadata
            last_final_state_refresh_applied =
                accepted_post_tail_trial.final_state_refresh_applied
            last_final_flux_projection_applied =
                accepted_post_tail_trial.final_flux_projection_applied
            last_final_complementarity_flux_projection_applied =
                accepted_post_tail_trial.final_complementarity_flux_projection_applied
            last_final_dual_fit_applied = accepted_post_tail_trial.final_dual_fit_applied
            last_final_selective_dual_fit_applied =
                accepted_post_tail_trial.final_selective_dual_fit_applied
            last_final_state_after_rhs_applied =
                accepted_post_tail_trial.final_state_after_rhs_applied
            last_dynamic_flux_refresh_applied =
                accepted_post_tail_trial.dynamic_flux_refresh_applied
            last_final_state_collocation_adjustment =
                accepted_post_tail_trial.final_state_collocation_adjustment
            last_final_state_boundary_adjustment =
                accepted_post_tail_trial.final_state_boundary_adjustment
            max_collocation_adjustment = max(
                max_collocation_adjustment,
                accepted_post_tail_trial.collocation_adjustment,
            )
            max_boundary_adjustment =
                max(max_boundary_adjustment, accepted_post_tail_trial.boundary_adjustment)
            final_residuals = accepted_post_tail_trial.residuals
            final_residual_max = accepted_post_tail_trial.residual_max
            final_score_summary = _reduced_dcdfba_collocation_repair_substep_summary(
                problem,
                "after_post_tail_repair_final_score";
                include_structural = repair_score_policy != "collocation_state",
            )
            final_repair_score = _reduced_dcdfba_collocation_repair_guard_score(
                problem,
                final_score_summary,
                repair_score_policy,
            )
            post_tail_repair_after_collocation_residual = final_residuals.collocation
            post_tail_repair_after_continuity_residual = final_residuals.continuity
            converged = _reduced_dcdfba_collocation_state_start_converged(
                final_residuals,
                tolerance,
            )
        end
        trial_count += post_tail_repair_trial_count
        rejected_trial_count += post_tail_repair_rejected_trial_count
    end

    repair_suffix =
        (feasibility_projection_applied ? "_feasibility_projection" : "") *
        (segment_repair_applied ? "_segmented_repair" : "")
    refresh_suffix =
        repair_suffix *
        (
            options.final_state_refresh && options.final_flux_projection && options.final_state_after_rhs ?
            "_final_state_mass_balanced_flux_projection_state_after_rhs" :
            options.final_state_refresh && options.final_flux_projection ?
            "_final_state_mass_balanced_flux_projection" :
            options.final_state_refresh ? "_final_state_refresh" : ""
        )
    policy = if element_indices === nothing
        options.monotone ?
        "monotone_damped_fixed_point_state_flux_dual_rhs_start_refresh$refresh_suffix" :
        "fixed_point_state_flux_dual_rhs_start_refresh$refresh_suffix"
    else
        options.monotone ?
        "tail_only_monotone_damped_fixed_point_state_flux_dual_rhs_start_refresh$refresh_suffix" :
        "tail_only_fixed_point_state_flux_dual_rhs_start_refresh$refresh_suffix"
    end

    return Dict{String, Any}(
        "collocation_consistent_state_start_applied" => true,
        "collocation_consistent_state_start_policy" => policy,
        "collocation_consistent_state_start_finite_element_count" =>
            length(selected_elements),
        "collocation_consistent_state_start_first_element" =>
            isempty(selected_elements) ? missing : first(selected_elements),
        "collocation_consistent_state_start_last_element" =>
            isempty(selected_elements) ? missing : last(selected_elements),
        "collocation_consistent_state_start_iterations" => iterations,
        "collocation_consistent_state_start_max_iterations" => max_iterations,
        "collocation_consistent_state_start_tolerance" => tolerance,
        "collocation_consistent_state_start_converged" => converged,
        "collocation_consistent_state_start_initial_collocation_residual" =>
            initial_residuals.collocation,
        "collocation_consistent_state_start_initial_continuity_residual" =>
            initial_residuals.continuity,
        "collocation_consistent_state_start_initial_rhs_residual" =>
            initial_residuals.rhs,
        "collocation_consistent_state_start_final_collocation_residual" =>
            final_residuals.collocation,
        "collocation_consistent_state_start_final_continuity_residual" =>
            final_residuals.continuity,
        "collocation_consistent_state_start_final_rhs_residual" =>
            final_residuals.rhs,
        "collocation_consistent_state_start_max_state_collocation_adjustment" =>
            max_collocation_adjustment,
        "collocation_consistent_state_start_max_state_boundary_adjustment" =>
            max_boundary_adjustment,
        "collocation_consistent_state_start_initial_max_residual" =>
            initial_residual_max,
        "collocation_consistent_state_start_final_max_residual" =>
            final_residual_max,
        "collocation_consistent_state_start_score_policy" =>
            repair_score_policy,
        "collocation_consistent_state_start_initial_score" =>
            initial_repair_score,
        "collocation_consistent_state_start_final_score" =>
            final_repair_score,
        "collocation_consistent_state_start_best_score" =>
            best_repair_score,
        "collocation_consistent_state_start_last_residual_improvement" =>
            last_residual_improvement,
        "collocation_consistent_state_start_last_score_improvement" =>
            last_score_improvement,
        "collocation_consistent_state_start_trace_enabled" => options.trace,
        "collocation_consistent_state_start_restore_best_enabled" =>
            options.restore_best,
        "collocation_consistent_state_start_monotone_enabled" =>
            options.monotone,
        "collocation_consistent_state_start_trace_substeps_enabled" =>
            options.trace_substeps,
        "collocation_consistent_state_start_final_state_refresh_enabled" =>
            options.final_state_refresh,
        "collocation_consistent_state_start_final_flux_projection_enabled" =>
            options.final_flux_projection,
        "collocation_consistent_state_start_final_complementarity_flux_projection_enabled" =>
            options.final_complementarity_flux_projection,
        "collocation_consistent_state_start_final_complementarity_flux_projection_trigger_threshold" =>
            options.final_complementarity_flux_projection_trigger_threshold,
        "collocation_consistent_state_start_final_dual_fit_enabled" =>
            options.final_dual_fit,
        "collocation_consistent_state_start_final_selective_dual_fit_enabled" =>
            options.final_selective_dual_fit,
        "collocation_consistent_state_start_final_selective_dual_fit_trigger_threshold" =>
            options.final_selective_dual_fit_trigger_threshold,
        "collocation_consistent_state_start_final_state_after_rhs_enabled" =>
            options.final_state_after_rhs,
        "collocation_consistent_state_start_final_state_after_rhs_guard_enabled" =>
            options.final_state_after_rhs_guard,
        "collocation_consistent_state_start_final_state_after_rhs_guard_policy" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_policy",
                options.final_state_after_rhs_guard ?
                "select_best_damped_state_after_rhs_by_primal_structural_residual" :
                "disabled_legacy_unconditional_state_after_rhs_update",
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_accepted" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_accepted",
                false,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_trial_count" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_trial_count",
                0,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_accepted_damping_factor" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_accepted_damping_factor",
                missing,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_damping_factors" =>
            copy(options.final_state_after_rhs_damping_factors),
        "collocation_consistent_state_start_final_state_after_rhs_guard_acceptance_tolerance" =>
            options.final_state_after_rhs_acceptance_tolerance,
        "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_enabled" =>
            options.final_state_after_rhs_refresh_rhs,
        "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_policy" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_policy",
                options.final_state_after_rhs_refresh_rhs ?
                "refresh_rhs_consistent_derivatives_after_each_damped_state_trial" :
                "disabled",
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_primal_structural_residual" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_before_primal_structural_residual",
                NaN,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_primal_structural_residual" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_after_primal_structural_residual",
                NaN,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_collocation_residual" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_before_collocation_residual",
                NaN,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_collocation_residual" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_after_collocation_residual",
                NaN,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_lower_bound_violation" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_before_lower_bound_violation",
                NaN,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_lower_bound_violation" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_after_lower_bound_violation",
                NaN,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_before_upper_bound_violation" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_before_upper_bound_violation",
                NaN,
            ),
        "collocation_consistent_state_start_final_state_after_rhs_guard_after_upper_bound_violation" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_state_after_rhs_guard_after_upper_bound_violation",
                NaN,
            ),
        "collocation_consistent_state_start_flux_refresh_guard_enabled" =>
            options.flux_refresh_guard,
        "collocation_consistent_state_start_flux_refresh_guard_policy" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_flux_refresh_guard_policy",
                options.flux_refresh_guard ? "not_applied_no_accepted_flux_refresh" : "disabled",
            ),
        "collocation_consistent_state_start_flux_refresh_guard_score_policy" =>
            options.flux_refresh_guard_score,
        "collocation_consistent_state_start_flux_refresh_guard_acceptance_tolerance" =>
            options.flux_refresh_guard_acceptance_tolerance,
        "collocation_consistent_state_start_flux_refresh_guard_accepted" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_flux_refresh_guard_accepted",
                missing,
            ),
        "collocation_consistent_state_start_flux_refresh_guard_before_score" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_flux_refresh_guard_before_score",
                NaN,
            ),
        "collocation_consistent_state_start_flux_refresh_guard_after_score" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_flux_refresh_guard_after_score",
                NaN,
            ),
        "collocation_consistent_state_start_flux_refresh_guard_restored_score" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_flux_refresh_guard_restored_score",
                NaN,
            ),
        "collocation_consistent_state_start_flux_refresh_guard_before_rhs_residual" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_flux_refresh_guard_before_rhs_residual",
                NaN,
            ),
        "collocation_consistent_state_start_flux_refresh_guard_after_rhs_residual" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_flux_refresh_guard_after_rhs_residual",
                NaN,
            ),
        "collocation_consistent_state_start_flux_refresh_max_iterations" =>
            options.flux_refresh_max_iterations,
        "collocation_consistent_state_start_trace_every" => options.trace_every,
        "collocation_consistent_state_start_damping_factors" =>
            copy(options.damping_factors),
        "collocation_consistent_state_start_monotone_acceptance_tolerance" =>
            options.monotone_acceptance_tolerance,
        "collocation_consistent_state_start_trial_count" => trial_count,
        "collocation_consistent_state_start_rejected_trial_count" =>
            rejected_trial_count,
        "collocation_consistent_state_start_last_accepted_damping_factor" =>
            last_accepted_damping_factor,
        "collocation_consistent_state_start_min_accepted_damping_factor" =>
            min_accepted_damping_factor,
        "collocation_consistent_state_start_last_rejected_damping_factor" =>
            last_rejected_damping_factor,
        "collocation_consistent_state_start_last_rejected_max_residual" =>
            last_rejected_max_residual,
        "collocation_consistent_state_start_last_rejected_score" =>
            last_rejected_score,
        "collocation_consistent_state_start_stopped_by_monotone_guard" =>
            stopped_by_monotone_guard,
        "collocation_consistent_state_start_last_final_state_refresh_applied" =>
            last_final_state_refresh_applied,
        "collocation_consistent_state_start_last_final_flux_projection_applied" =>
            last_final_flux_projection_applied,
        "collocation_consistent_state_start_last_final_complementarity_flux_projection_applied" =>
            last_final_complementarity_flux_projection_applied,
        "collocation_consistent_state_start_last_final_dual_fit_applied" =>
            last_final_dual_fit_applied,
        "collocation_consistent_state_start_last_final_selective_dual_fit_applied" =>
            last_final_selective_dual_fit_applied,
        "collocation_consistent_state_start_last_final_state_after_rhs_applied" =>
            last_final_state_after_rhs_applied,
        "collocation_consistent_state_start_last_dynamic_flux_refresh_applied" =>
            last_dynamic_flux_refresh_applied,
        "collocation_consistent_state_start_last_final_state_collocation_adjustment" =>
            last_final_state_collocation_adjustment,
        "collocation_consistent_state_start_last_final_state_boundary_adjustment" =>
            last_final_state_boundary_adjustment,
        "collocation_consistent_state_start_best_iteration" => best_iteration,
        "collocation_consistent_state_start_best_max_residual" =>
            best_residual_max,
        "collocation_consistent_state_start_restored_best_iteration" =>
            restored_best_iteration,
        "collocation_consistent_state_start_restore_best_improvement" =>
            restore_best_improvement,
        "collocation_consistent_state_start_restore_best_score_improvement" =>
            restore_best_score_improvement,
        "collocation_consistent_state_start_stagnation_tolerance" =>
            options.stagnation_tolerance,
        "collocation_consistent_state_start_stagnation_iterations" =>
            options.stagnation_iterations,
        "collocation_consistent_state_start_stagnation_counter" =>
            stagnation_counter,
        "collocation_consistent_state_start_stopped_by_stagnation" =>
            stopped_by_stagnation,
        "collocation_consistent_state_start_last_dynamic_flux_lp_attempt_count" =>
            get(last_dynamic_flux_metadata, "dynamic_flux_lp_start_solve_attempt_count", 0),
        "collocation_consistent_state_start_last_dynamic_flux_lp_total_solve_elapsed_seconds" =>
            get(
                last_dynamic_flux_metadata,
                "dynamic_flux_lp_start_total_solve_elapsed_seconds",
                0.0,
            ),
        "collocation_consistent_state_start_last_dynamic_flux_lp_max_solve_elapsed_seconds" =>
            get(
                last_dynamic_flux_metadata,
                "dynamic_flux_lp_start_max_solve_elapsed_seconds",
                0.0,
            ),
        "collocation_consistent_state_start_repair_trace" => repair_trace_records,
        "collocation_consistent_state_start_repair_trace_count" =>
            length(repair_trace_records),
        "collocation_consistent_state_start_repair_substep_trace" =>
            repair_substep_trace_records,
        "collocation_consistent_state_start_repair_substep_trace_count" =>
            length(repair_substep_trace_records),
        "collocation_consistent_state_start_feasibility_projection_enabled" =>
            options.feasibility_projection_enabled,
        "collocation_consistent_state_start_feasibility_projection_applied" =>
            feasibility_projection_applied,
        "collocation_consistent_state_start_feasibility_projection_segments_raw" =>
            options.feasibility_projection_segments_raw,
        "collocation_consistent_state_start_feasibility_projection_ranges" =>
            copy(feasibility_projection_ranges),
        "collocation_consistent_state_start_feasibility_projection_segment_count" =>
            length(feasibility_projection_records),
        "collocation_consistent_state_start_feasibility_projection_accepted_count" =>
            feasibility_projection_accepted_count,
        "collocation_consistent_state_start_feasibility_projection_trial_count" =>
            feasibility_projection_trial_count,
        "collocation_consistent_state_start_feasibility_projection_rejected_trial_count" =>
            feasibility_projection_rejected_trial_count,
        "collocation_consistent_state_start_feasibility_projection_acceptance_tolerance" =>
            options.feasibility_projection_acceptance_tolerance,
        "collocation_consistent_state_start_feasibility_projection_guard_score_policy" =>
            options.feasibility_projection_guard_score,
        "collocation_consistent_state_start_feasibility_projection_guard_acceptance_tolerance" =>
            options.feasibility_projection_guard_acceptance_tolerance,
        "collocation_consistent_state_start_feasibility_projection_damping_factors" =>
            copy(options.feasibility_projection_damping_factors),
        "collocation_consistent_state_start_feasibility_projection_refresh_dynamic_flux" =>
            options.feasibility_projection_refresh_dynamic_flux,
        "collocation_consistent_state_start_feasibility_projection_final_state_refresh" =>
            options.feasibility_projection_final_state_refresh,
        "collocation_consistent_state_start_feasibility_projection_final_flux_projection" =>
            options.feasibility_projection_final_flux_projection,
        "collocation_consistent_state_start_feasibility_projection_final_state_after_rhs" =>
            options.feasibility_projection_final_state_after_rhs,
        "collocation_consistent_state_start_feasibility_projection_final_state_after_rhs_refresh_rhs" =>
            options.feasibility_projection_final_state_after_rhs_refresh_rhs,
        "collocation_consistent_state_start_feasibility_projection_before_max_residual" =>
            feasibility_projection_before_residual,
        "collocation_consistent_state_start_feasibility_projection_after_max_residual" =>
            feasibility_projection_after_residual,
        "collocation_consistent_state_start_feasibility_projection_before_collocation_residual" =>
            feasibility_projection_before_collocation_residual,
        "collocation_consistent_state_start_feasibility_projection_after_collocation_residual" =>
            feasibility_projection_after_collocation_residual,
        "collocation_consistent_state_start_feasibility_projection_before_continuity_residual" =>
            feasibility_projection_before_continuity_residual,
        "collocation_consistent_state_start_feasibility_projection_after_continuity_residual" =>
            feasibility_projection_after_continuity_residual,
        "collocation_consistent_state_start_feasibility_projection_records" =>
            feasibility_projection_records,
        "collocation_consistent_state_start_segment_repair_enabled" =>
            options.segmented_repair_enabled,
        "collocation_consistent_state_start_segment_repair_applied" =>
            segment_repair_applied,
        "collocation_consistent_state_start_segment_repair_segments_raw" =>
            options.segmented_repair_segments_raw,
        "collocation_consistent_state_start_segment_repair_ranges" =>
            copy(segment_repair_ranges),
        "collocation_consistent_state_start_segment_repair_segment_count" =>
            length(segment_repair_records),
        "collocation_consistent_state_start_segment_repair_accepted_count" =>
            segment_repair_accepted_count,
        "collocation_consistent_state_start_segment_repair_trial_count" =>
            segment_repair_trial_count,
        "collocation_consistent_state_start_segment_repair_rejected_trial_count" =>
            segment_repair_rejected_trial_count,
        "collocation_consistent_state_start_segment_repair_acceptance_tolerance" =>
            options.segmented_repair_acceptance_tolerance,
        "collocation_consistent_state_start_segment_repair_guard_score_policy" =>
            options.segmented_repair_guard_score,
        "collocation_consistent_state_start_segment_repair_guard_acceptance_tolerance" =>
            options.segmented_repair_guard_acceptance_tolerance,
        "collocation_consistent_state_start_segment_repair_damping_factors" =>
            copy(options.segmented_repair_damping_factors),
        "collocation_consistent_state_start_segment_repair_refresh_dynamic_flux" =>
            options.segmented_repair_refresh_dynamic_flux,
        "collocation_consistent_state_start_segment_repair_before_max_residual" =>
            segment_repair_before_residual,
        "collocation_consistent_state_start_segment_repair_after_max_residual" =>
            segment_repair_after_residual,
        "collocation_consistent_state_start_segment_repair_before_collocation_residual" =>
            segment_repair_before_collocation_residual,
        "collocation_consistent_state_start_segment_repair_after_collocation_residual" =>
            segment_repair_after_collocation_residual,
        "collocation_consistent_state_start_segment_repair_before_continuity_residual" =>
            segment_repair_before_continuity_residual,
        "collocation_consistent_state_start_segment_repair_after_continuity_residual" =>
            segment_repair_after_continuity_residual,
        "collocation_consistent_state_start_segment_repair_records" =>
            segment_repair_records,
        "collocation_consistent_state_start_post_tail_repair_enabled" =>
            options.post_tail_repair_enabled,
        "collocation_consistent_state_start_post_tail_repair_applied" =>
            post_tail_repair_applied,
        "collocation_consistent_state_start_post_tail_repair_accepted" =>
            post_tail_repair_accepted,
        "collocation_consistent_state_start_post_tail_repair_defaulted_elements" =>
            post_tail_repair_defaulted_elements,
        "collocation_consistent_state_start_post_tail_repair_finite_element_count" =>
            post_tail_repair_finite_element_count,
        "collocation_consistent_state_start_post_tail_repair_first_element" =>
            post_tail_repair_first_element,
        "collocation_consistent_state_start_post_tail_repair_last_element" =>
            post_tail_repair_last_element,
        "collocation_consistent_state_start_post_tail_repair_damping_factors" =>
            copy(options.post_tail_repair_damping_factors),
        "collocation_consistent_state_start_post_tail_repair_accepted_damping_factor" =>
            post_tail_repair_accepted_damping_factor,
        "collocation_consistent_state_start_post_tail_repair_trial_count" =>
            post_tail_repair_trial_count,
        "collocation_consistent_state_start_post_tail_repair_rejected_trial_count" =>
            post_tail_repair_rejected_trial_count,
        "collocation_consistent_state_start_post_tail_repair_acceptance_tolerance" =>
            options.post_tail_repair_acceptance_tolerance,
        "collocation_consistent_state_start_post_tail_repair_guard_score_policy" =>
            options.post_tail_repair_guard_score,
        "collocation_consistent_state_start_post_tail_repair_guard_acceptance_tolerance" =>
            options.post_tail_repair_guard_acceptance_tolerance,
        "collocation_consistent_state_start_post_tail_repair_refresh_dynamic_flux" =>
            options.post_tail_repair_refresh_dynamic_flux,
        "collocation_consistent_state_start_post_tail_repair_before_max_residual" =>
            post_tail_repair_before_residual,
        "collocation_consistent_state_start_post_tail_repair_after_max_residual" =>
            post_tail_repair_after_residual,
        "collocation_consistent_state_start_post_tail_repair_before_collocation_residual" =>
            post_tail_repair_before_collocation_residual,
        "collocation_consistent_state_start_post_tail_repair_after_collocation_residual" =>
            post_tail_repair_after_collocation_residual,
        "collocation_consistent_state_start_post_tail_repair_before_continuity_residual" =>
            post_tail_repair_before_continuity_residual,
        "collocation_consistent_state_start_post_tail_repair_after_continuity_residual" =>
            post_tail_repair_after_continuity_residual,
        "collocation_consistent_state_start_post_tail_repair_before_guard_score" =>
            post_tail_repair_before_guard_score,
        "collocation_consistent_state_start_post_tail_repair_after_guard_score" =>
            post_tail_repair_after_guard_score,
        "collocation_consistent_state_start_post_tail_repair_last_rejected_damping_factor" =>
            post_tail_repair_last_rejected_damping_factor,
        "collocation_consistent_state_start_post_tail_repair_last_rejected_residual" =>
            post_tail_repair_last_rejected_residual,
        "collocation_consistent_state_start_post_tail_repair_last_rejected_guard_score" =>
            post_tail_repair_last_rejected_guard_score,
        "collocation_consistent_state_start_dynamic_flux_refreshed" =>
            problem.dynamic_bounds !== nothing,
        "collocation_consistent_state_start_stationarity_duals_refreshed" => true,
        "collocation_consistent_state_start_rhs_derivatives_refreshed" => true,
        "collocation_consistent_state_start_is_scientific_simulation" => false,
    )
end

function _reduced_dcdfba_set_collocation_consistent_state_starts!(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    ;
    element_indices = nothing,
)::Tuple{Float64, Float64}
    selected_elements =
        _reduced_dcdfba_start_element_indices(problem.nlp.dimensions.nfe, element_indices)
    isempty(selected_elements) && return 0.0, 0.0
    state_boundary_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_boundary)
    state_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    derivative_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_derivative)
    any(value -> value === nothing, (state_boundary_values, state_values, derivative_values)) &&
        throw(
            ArgumentError("Reduced DC-dFBA collocation-consistent state starts require finite state and derivative start values."),
        )

    grid = problem.nlp.kkt_problem.grid
    integration_matrix = grid.scheme.integration_matrix
    continuity_weights = grid.scheme.continuity_weights
    n_states = problem.nlp.dimensions.n_states
    max_collocation_adjustment = 0.0
    max_boundary_adjustment = 0.0

    if first(selected_elements) == 1
        for i in 1:n_states
            initial_value = Float64(problem.nlp.initial_state[i])
            max_boundary_adjustment =
                max(max_boundary_adjustment, abs(initial_value - state_boundary_values[i, 1]))
            JuMP.set_start_value(problem.nlp.state_boundary[i, 1], initial_value)
            state_boundary_values[i, 1] = initial_value
        end
    end

    for e in selected_elements
        h = element_length(grid, e)
        for i in 1:n_states
            left_value = state_boundary_values[i, e]
            for j in 1:grid.scheme.degree
                expected =
                    left_value +
                    h * sum(
                        integration_matrix[j, k] * derivative_values[i, e, k] for
                        k in 1:grid.scheme.degree
                    )
                max_collocation_adjustment =
                    max(max_collocation_adjustment, abs(expected - state_values[i, e, j]))
                JuMP.set_start_value(problem.nlp.state_collocation[i, e, j], expected)
                state_values[i, e, j] = expected
            end

            right_value =
                left_value +
                h * sum(
                    continuity_weights[k] * derivative_values[i, e, k] for
                    k in 1:grid.scheme.degree
                )
            max_boundary_adjustment =
                max(max_boundary_adjustment, abs(right_value - state_boundary_values[i, e + 1]))
            JuMP.set_start_value(problem.nlp.state_boundary[i, e + 1], right_value)
            state_boundary_values[i, e + 1] = right_value
        end
    end
    return max_collocation_adjustment, max_boundary_adjustment
end

function _reduced_dcdfba_collocation_state_start_residual_summary(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)
    starts = _reduced_dcdfba_mpcc_scaling_start_values(problem)
    constraint_values = _reduced_dcdfba_mpcc_constraint_start_values(problem, starts)
    return (
        collocation = _reduced_dcdfba_abs_max_or_nan(
            constraint_values["collocation_integration"],
        ),
        continuity = _reduced_dcdfba_abs_max_or_nan(constraint_values["continuity"]),
        rhs = haskey(constraint_values, "rhs") ?
              _reduced_dcdfba_abs_max_or_nan(constraint_values["rhs"]) :
              NaN,
    )
end

function _reduced_dcdfba_collocation_state_start_residual_max(residuals)::Float64
    max_residual = 0.0
    has_finite = false
    for value in (residuals.collocation, residuals.continuity, residuals.rhs)
        if isfinite(value)
            max_residual = max(max_residual, Float64(value))
            has_finite = true
        end
    end
    return has_finite ? max_residual : NaN
end

function _reduced_dcdfba_print_collocation_repair_trace(
    iteration::Int,
    residuals,
    residual_max::Real,
    residual_improvement::Real,
    collocation_adjustment::Real,
    boundary_adjustment::Real,
    dynamic_flux_metadata::AbstractDict,
    converged::Bool,
)::Nothing
    dynamic_lp_attempts =
        get(dynamic_flux_metadata, "dynamic_flux_lp_start_solve_attempt_count", 0)
    dynamic_lp_total_solve_elapsed =
        get(dynamic_flux_metadata, "dynamic_flux_lp_start_total_solve_elapsed_seconds", 0.0)
    dynamic_lp_max_solve_elapsed =
        get(dynamic_flux_metadata, "dynamic_flux_lp_start_max_solve_elapsed_seconds", 0.0)
    println(
        "collocation_repair_iteration: iteration=$iteration max_residual=$residual_max residual_improvement=$residual_improvement collocation_residual=$(residuals.collocation) continuity_residual=$(residuals.continuity) rhs_residual=$(residuals.rhs) collocation_adjustment=$collocation_adjustment boundary_adjustment=$boundary_adjustment dynamic_lp_attempts=$dynamic_lp_attempts dynamic_lp_total_solve_seconds=$dynamic_lp_total_solve_elapsed dynamic_lp_max_solve_seconds=$dynamic_lp_max_solve_elapsed converged=$converged",
    )
    flush(stdout)
    return nothing
end

function _reduced_dcdfba_collocation_state_start_converged(
    residuals,
    tolerance::Float64,
)::Bool
    isfinite(residuals.collocation) || return false
    isfinite(residuals.continuity) || return false
    isfinite(residuals.rhs) || return false
    return max(residuals.collocation, residuals.continuity, residuals.rhs) <= tolerance
end

function _validate_reduced_dcdfba_sequential_initialization_inputs(
    nlp::ReducedDCDFBACollocationNLP,
    simulation::SimulationResult,
)
    n_states = nlp.dimensions.n_states
    size(simulation.states, 1) == n_states || throw(
        ArgumentError(
            "Reduced DC-dFBA sequential initialization requires $n_states state rows, " *
            "got $(size(simulation.states, 1)).",
        ),
    )
    length(simulation.time) == size(simulation.states, 2) || throw(
        ArgumentError("Reduced DC-dFBA sequential initialization time/state dimensions are inconsistent."),
    )
    length(simulation.time) >= 2 || throw(
        ArgumentError("Reduced DC-dFBA sequential initialization requires at least two saved time points."),
    )
    all(isfinite, simulation.time) || throw(
        ArgumentError("Reduced DC-dFBA sequential initialization times must be finite."),
    )
    all(isfinite, simulation.states) || throw(
        ArgumentError("Reduced DC-dFBA sequential initialization states must be finite."),
    )
    all(diff(simulation.time) .> 0.0) || throw(
        ArgumentError("Reduced DC-dFBA sequential initialization times must be strictly increasing."),
    )
    _validate_reduced_dcdfba_sequential_initialization_time_coverage(nlp, simulation)

    if simulation.fluxes !== nothing
        all(isfinite, simulation.fluxes) || throw(
            ArgumentError("Reduced DC-dFBA sequential initialization fluxes must be finite when provided."),
        )
        flux_rxn_ids = _reduced_dcdfba_simulation_flux_rxn_ids(simulation)
        size(simulation.fluxes, 1) == length(flux_rxn_ids) || throw(
            ArgumentError(
                "Reduced DC-dFBA sequential initialization flux row count must match metadata flux_rxn_ids.",
            ),
        )
        model = nlp.kkt_problem.model
        for rxn_id in flux_rxn_ids
            rxn_id == "r_0001" && throw(
                ArgumentError("Reduced DC-dFBA sequential initialization must not use r_0001 as oxygen."),
            )
            rxn_id == "r_1992" && throw(
                ArgumentError("Reduced DC-dFBA sequential initialization must not include absent reduced oxygen r_1992."),
            )
            has_reaction(model, rxn_id) || throw(
                ArgumentError("Reduced DC-dFBA sequential initialization flux reaction is missing: $rxn_id."),
            )
        end
    end
    return nothing
end

function _validate_reduced_dcdfba_sequential_initialization_time_coverage(
    nlp::ReducedDCDFBACollocationNLP,
    simulation::SimulationResult,
)
    grid = nlp.kkt_problem.grid
    first_time = first(simulation.time)
    last_time = last(simulation.time)
    tolerance = 100.0 * eps(Float64) * max(1.0, abs(first_time), abs(last_time), abs(grid.tspan[1]), abs(grid.tspan[2]))
    grid.tspan[1] >= first_time - tolerance || throw(
        ArgumentError("Sequential initialization starts after the collocation grid tspan."),
    )
    grid.tspan[2] <= last_time + tolerance || throw(
        ArgumentError("Sequential initialization ends before the collocation grid tspan."),
    )
    return nothing
end

function _reduced_dcdfba_sequential_state_boundary_starts(
    nlp::ReducedDCDFBACollocationNLP,
    simulation::SimulationResult,
)::Matrix{Float64}
    n_states = nlp.dimensions.n_states
    nfe = nlp.dimensions.nfe
    starts = Matrix{Float64}(undef, n_states, nfe + 1)
    for e in 1:nfe
        left, right = element_bounds(nlp.kkt_problem.grid, e)
        if e == 1
            starts[:, 1] .= _reduced_dcdfba_interpolated_state(simulation, left)
        end
        starts[:, e + 1] .= _reduced_dcdfba_interpolated_state(simulation, right)
    end
    return starts
end

function _reduced_dcdfba_sequential_state_collocation_starts(
    nlp::ReducedDCDFBACollocationNLP,
    simulation::SimulationResult,
)::Array{Float64, 3}
    n_states = nlp.dimensions.n_states
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree
    starts = Array{Float64, 3}(undef, n_states, nfe, degree)
    for e in 1:nfe, j in 1:degree
        starts[:, e, j] .= _reduced_dcdfba_interpolated_state(
            simulation,
            collocation_time(nlp.kkt_problem.grid, e, j),
        )
    end
    return starts
end

function _reduced_dcdfba_sequential_state_derivative_starts(
    nlp::ReducedDCDFBACollocationNLP,
    simulation::SimulationResult,
)::Array{Float64, 3}
    n_states = nlp.dimensions.n_states
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree
    starts = Array{Float64, 3}(undef, n_states, nfe, degree)
    for e in 1:nfe, j in 1:degree
        starts[:, e, j] .= _reduced_dcdfba_piecewise_state_slope(
            simulation,
            collocation_time(nlp.kkt_problem.grid, e, j),
        )
    end
    return starts
end

function _reduced_dcdfba_sequential_flux_starts(
    nlp::ReducedDCDFBACollocationNLP,
    simulation::SimulationResult,
)
    n_reactions = nlp.dimensions.n_reactions
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree
    starts = Array{Float64, 3}(undef, n_reactions, nfe, degree)
    for r in 1:n_reactions, e in 1:nfe, j in 1:degree
        starts[r, e, j] = _reduced_dcdfba_existing_flux_start(nlp, r, e, j)
    end

    flux_rxn_ids = _reduced_dcdfba_simulation_flux_rxn_ids(simulation)
    initialized_flux_indices = Int[]
    if simulation.fluxes !== nothing
        model = nlp.kkt_problem.model
        for (row_index, rxn_id) in enumerate(flux_rxn_ids)
            reaction_index_value = reaction_index(model, rxn_id)
            push!(initialized_flux_indices, reaction_index_value)
            for e in 1:nfe, j in 1:degree
                raw_value = _reduced_dcdfba_linear_interpolate(
                    simulation.time,
                    view(simulation.fluxes, row_index, :),
                    collocation_time(nlp.kkt_problem.grid, e, j),
                )
                starts[reaction_index_value, e, j] =
                    clamp(raw_value, model.lb[reaction_index_value], model.ub[reaction_index_value])
            end
        end
    end
    return starts, flux_rxn_ids, sort!(unique!(initialized_flux_indices))
end

function _reduced_dcdfba_existing_flux_start(
    nlp::ReducedDCDFBACollocationNLP,
    reaction_index_value::Int,
    element_index::Int,
    collocation_index::Int,
)::Float64
    value = JuMP.start_value(nlp.flux[reaction_index_value, element_index, collocation_index])
    value === nothing && return clamp(
        0.0,
        nlp.kkt_problem.model.lb[reaction_index_value],
        nlp.kkt_problem.model.ub[reaction_index_value],
    )
    return Float64(value)
end

function _apply_reduced_dcdfba_sequential_start_values!(
    nlp::ReducedDCDFBACollocationNLP,
    state_boundary_starts::Matrix{Float64},
    state_collocation_starts::Array{Float64, 3},
    state_derivative_starts::Array{Float64, 3},
    flux_starts::Array{Float64, 3},
    initialized_flux_indices::Vector{Int},
)
    for index in eachindex(nlp.state_boundary)
        JuMP.set_start_value(nlp.state_boundary[index], state_boundary_starts[index])
    end
    for index in eachindex(nlp.state_collocation)
        JuMP.set_start_value(nlp.state_collocation[index], state_collocation_starts[index])
        JuMP.set_start_value(nlp.state_derivative[index], state_derivative_starts[index])
    end
    for reaction_index_value in initialized_flux_indices,
        e in 1:nlp.dimensions.nfe,
        j in 1:nlp.dimensions.collocation_degree

        JuMP.set_start_value(nlp.flux[reaction_index_value, e, j], flux_starts[reaction_index_value, e, j])
    end
    return nothing
end

function _reduced_dcdfba_interpolated_state(
    simulation::SimulationResult,
    time_value::Real,
)::Vector{Float64}
    return [
        _reduced_dcdfba_linear_interpolate(simulation.time, view(simulation.states, i, :), Float64(time_value)) for
        i in axes(simulation.states, 1)
    ]
end

function _reduced_dcdfba_piecewise_state_slope(
    simulation::SimulationResult,
    time_value::Real,
)::Vector{Float64}
    segment_index = _reduced_dcdfba_time_segment(simulation.time, Float64(time_value))
    dt = simulation.time[segment_index + 1] - simulation.time[segment_index]
    return Float64.((simulation.states[:, segment_index + 1] .- simulation.states[:, segment_index]) ./ dt)
end

function _reduced_dcdfba_linear_interpolate(times::AbstractVector, values, time_value::Real)::Float64
    segment_index = _reduced_dcdfba_time_segment(times, Float64(time_value))
    left_time = Float64(times[segment_index])
    right_time = Float64(times[segment_index + 1])
    left_value = Float64(values[segment_index])
    right_value = Float64(values[segment_index + 1])
    right_time == left_time && return left_value
    theta = (Float64(time_value) - left_time) / (right_time - left_time)
    return (1.0 - theta) * left_value + theta * right_value
end

function _reduced_dcdfba_time_segment(times::AbstractVector, time_value::Float64)::Int
    n_time = length(times)
    tolerance = 100.0 * eps(Float64) * max(1.0, maximum(abs.(Float64.(times))), abs(time_value))
    time_value <= Float64(times[1]) + tolerance && return 1
    time_value >= Float64(times[end]) - tolerance && return n_time - 1
    for index in 1:(n_time - 1)
        if Float64(times[index]) - tolerance <= time_value <= Float64(times[index + 1]) + tolerance
            return index
        end
    end
    throw(ArgumentError("Interpolation time $time_value is outside the sequential initialization support."))
end

function _reduced_dcdfba_simulation_flux_rxn_ids(simulation::SimulationResult)::Vector{String}
    simulation.fluxes === nothing && return String[]
    raw_value = get(simulation.metadata, "flux_rxn_ids", nothing)
    raw_value isa AbstractVector || throw(
        ArgumentError(
            "Reduced DC-dFBA sequential initialization requires metadata[\"flux_rxn_ids\"] when fluxes are provided.",
        ),
    )
    return strip.(String.(raw_value))
end

function _reduced_dcdfba_sequential_initialization_metadata(
    nlp::ReducedDCDFBACollocationNLP,
    simulation::SimulationResult,
    flux_start_policy::Symbol,
    flux_rxn_ids::Vector{String},
    initialized_flux_indices::Vector{Int},
)::Dict{String, Any}
    return Dict{String, Any}(
        "sequential_initialization_built" => true,
        "sequential_initialization_source" => "SimulationResult",
        "sequential_initialization_state_policy" => "piecewise_linear_interpolation_at_grid_times",
        "sequential_initialization_derivative_policy" => "piecewise_linear_saved_state_slopes",
        "sequential_initialization_flux_policy" => String(flux_start_policy),
        "sequential_initialization_flux_fallback_policy" => "preserve_existing_start_for_missing_reactions",
        "sequential_initialization_flux_clamp_policy" => "clamp_provided_flux_starts_to_base_bounds",
        "sequential_initialization_time_points" => length(simulation.time),
        "sequential_initialization_time_start" => first(simulation.time),
        "sequential_initialization_time_end" => last(simulation.time),
        "sequential_initialization_grid_tspan" => nlp.kkt_problem.grid.tspan,
        "sequential_initialization_grid_nfe" => nlp.kkt_problem.grid.nfe,
        "sequential_initialization_collocation_degree" => nlp.kkt_problem.grid.scheme.degree,
        "sequential_initialization_flux_reaction_count" => length(flux_rxn_ids),
        "sequential_initialization_flux_reaction_ids" => copy(flux_rxn_ids),
        "sequential_initialization_flux_index_count" => length(initialized_flux_indices),
        "sequential_initialization_missing_flux_start_count" =>
            nlp.dimensions.n_reactions - length(initialized_flux_indices),
        "sequential_initialization_simulation_model_scope" =>
            get(simulation.metadata, "model_scope", "unknown"),
        "sequential_initialization_simulation_termination_reason" =>
            get(simulation.metadata, "termination_reason", "unknown"),
        "sequential_initialization_is_scientific_solution" => false,
        "solver_call_performed" => false,
        "dfvb_kkt_deferred" => true,
        "full_model_kkt_deferred" => true,
        "first_mpcc_target" => "reduced_dfba",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
end

function _reduced_dcdfba_mpcc_smoke_problem_metadata(
    nlp::ReducedDCDFBACollocationNLP,
    include_rhs::Bool,
    use_dynamic_bounds::Bool,
    sequential_initialization::Union{Nothing, ReducedDCDFBASequentialInitialization},
    ipopt_max_iter::Union{Nothing, Int},
    linear_solver::AbstractString,
    complementarity_mode::Symbol,
    complementarity_tau::Float64,
    complementarity_tau_gate_tol::Union{Nothing, Float64},
    flux_start_metadata::Dict{String, Any},
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule},
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold},
)::Dict{String, Any}
    has_sequential_initialization = sequential_initialization !== nothing
    metadata = Dict{String, Any}(
        "problem_type" => "reduced_dcdfba_mpcc_smoke",
        "problem_scope" => "guarded_reduced_mpcc_solver_entry_smoke",
        "optimizer" => "Ipopt",
        "ipopt_max_iter" => ipopt_max_iter,
        "model_scope" => "reduced",
        "model_id" => nlp.kkt_problem.model.model_id,
        "grid_tspan" => nlp.kkt_problem.grid.tspan,
        "grid_nfe" => nlp.kkt_problem.grid.nfe,
        "collocation_degree" => nlp.kkt_problem.grid.scheme.degree,
        "rhs_residuals_included" => include_rhs,
        "mass_balance_constraints_built" => true,
        "bound_feasibility_constraints_built" => true,
        "stationarity_constraints_built" => true,
        "mpcc_complementarity_built" => true,
        "complementarity_mode" => String(complementarity_mode),
        "complementarity_tau" =>
            complementarity_mode == :scholtes ? complementarity_tau : missing,
        "kkt_constraints_built" => true,
        "full_simultaneous_dfba_solver_built" => false,
        "dynamic_flux_bounds_applied" => use_dynamic_bounds,
        "dynamic_flux_bound_mode" =>
            use_dynamic_bounds ? get(nlp.metadata, "dynamic_flux_bound_mode", "growth") : "none",
        "dynamic_flux_bound_policy" =>
            use_dynamic_bounds ? get(nlp.metadata, "dynamic_flux_bound_policy", missing) : missing,
        "dynamic_phase_smoothing_width" =>
            use_dynamic_bounds ? get(nlp.metadata, "dynamic_phase_smoothing_width", missing) : missing,
        "dynamic_phase_proxy_mode" =>
            use_dynamic_bounds ? get(nlp.metadata, "dynamic_phase_proxy_mode", missing) : missing,
        "dynamic_phase_proxy_definition" =>
            use_dynamic_bounds ? get(nlp.metadata, "dynamic_phase_proxy_definition", missing) : missing,
        "dynamic_turnover_threshold" =>
            use_dynamic_bounds ? get(nlp.metadata, "dynamic_turnover_threshold", missing) : missing,
        "smooth_turnover_mode_embedded" =>
            use_dynamic_bounds ? get(nlp.metadata, "smooth_turnover_mode_embedded", missing) : missing,
        "turnover_mode_deferred" =>
            use_dynamic_bounds ? get(nlp.metadata, "turnover_mode_deferred", missing) : missing,
        "dynamic_objective_coefficients_applied" => use_dynamic_bounds,
        "mpcc_fixed_control_replay_ready" =>
            dynamic_control_schedule !== nothing && include_rhs && use_dynamic_bounds,
        "solver_call_performed" => false,
        "sequential_initialization_built" => has_sequential_initialization,
        "sequential_initialization_source" =>
            has_sequential_initialization ? "SimulationResult" : "none",
        "dfvb_kkt_deferred" => true,
        "full_model_kkt_deferred" => true,
        "first_mpcc_target" => "reduced_dfba",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "smoke_result_is_scientific_simulation" => false,
    )
    merge!(
        metadata,
        _reduced_dcdfba_mpcc_dynamic_control_metadata(
            dynamic_control_schedule;
            applied_to_rhs = include_rhs,
            applied_to_dynamic_bounds = use_dynamic_bounds,
        ),
    )
    if dynamic_control_decisions !== nothing
        merge!(metadata, dynamic_control_decisions.metadata)
        metadata["mpcc_dynamic_control_variable_policy"] =
            "coupled_control_decision_variables"
        metadata["mpcc_dynamic_control_variables_coupled_to_rhs"] = include_rhs
        metadata["mpcc_dynamic_control_variables_coupled_to_dynamic_bounds"] =
            use_dynamic_bounds
        metadata["fully_simultaneous_controls"] = include_rhs || use_dynamic_bounds
        metadata["mpcc_dynamic_control_decision_embedding_ready"] =
            include_rhs && use_dynamic_bounds
    end
    merge!(
        metadata,
        _reduced_dcdfba_mpcc_complementarity_tau_gate_problem_metadata(
            complementarity_mode,
            complementarity_tau,
            complementarity_tau_gate_tol,
        ),
    )
    merge!(metadata, _ipopt_linear_solver_metadata(linear_solver))
    merge!(metadata, _ipopt_hessian_approximation_metadata())
    _merge_reduced_dcdfba_metadata_prefix!(metadata, nlp.metadata, "base_flux_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, nlp.metadata, "fixed_flux_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, nlp.metadata, "flux_variable_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, nlp.metadata, "rhs_residual_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, nlp.metadata, "dynamic_flux_bounds_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, nlp.metadata, "complementarity_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, nlp.metadata, "state_nonnegative_")
    if has_sequential_initialization
        metadata["sequential_initialization_state_policy"] =
            sequential_initialization.metadata["sequential_initialization_state_policy"]
        metadata["sequential_initialization_flux_policy"] =
            sequential_initialization.metadata["sequential_initialization_flux_policy"]
        metadata["sequential_initialization_flux_reaction_count"] =
            sequential_initialization.metadata["sequential_initialization_flux_reaction_count"]
    end
    merge!(metadata, flux_start_metadata)
    return metadata
end

function _reduced_dcdfba_mpcc_smoke_result(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    solve_elapsed_seconds::Float64,
)::ReducedDCDFBAMPCCSmokeResult
    jump_model = problem.nlp.jump_model
    status = JuMP.termination_status(jump_model)
    primal_status = JuMP.primal_status(jump_model)
    has_values = JuMP.result_count(jump_model) > 0

    objective_value = has_values ? _reduced_dcdfba_objective_value_or_nan(jump_model) : NaN
    diagnostics = _reduced_dcdfba_mpcc_smoke_diagnostics(problem, has_values)
    solver_name = _reduced_dcdfba_solver_name(jump_model)
    tau_status = _reduced_dcdfba_mpcc_complementarity_tau_status(
        problem,
        diagnostics.max_lower_complementarity_residual,
        diagnostics.max_upper_complementarity_residual,
    )

    metadata = copy(problem.metadata)
    metadata["solver_call_performed"] = true
    metadata["solver_status"] = string(status)
    metadata["primal_status"] = string(primal_status)
    metadata["solver_result_count"] = JuMP.result_count(jump_model)
    metadata["solver_name"] = solver_name
    metadata["solver_reported_solve_time_seconds"] =
        _reduced_dcdfba_model_attribute_or_missing(jump_model, MOI.SolveTimeSec())
    metadata["solve_elapsed_seconds"] = solve_elapsed_seconds
    metadata["smoke_result_is_scientific_simulation"] = false
    metadata["max_mass_balance_residual"] = diagnostics.max_mass_balance_residual
    metadata["max_lower_bound_violation"] = diagnostics.max_lower_bound_violation
    metadata["max_upper_bound_violation"] = diagnostics.max_upper_bound_violation
    metadata["max_stationarity_residual"] = diagnostics.max_stationarity_residual
    metadata["max_lower_complementarity_residual"] = diagnostics.max_lower_complementarity_residual
    metadata["max_upper_complementarity_residual"] = diagnostics.max_upper_complementarity_residual
    metadata["max_lower_complementarity_product"] = diagnostics.max_lower_complementarity_residual
    metadata["max_upper_complementarity_product"] = diagnostics.max_upper_complementarity_residual
    metadata["max_complementarity_tau_violation"] =
        tau_status.max_complementarity_tau_violation
    metadata["max_complementarity_tau_violation_raw"] =
        tau_status.max_complementarity_tau_violation_raw
    metadata["complementarity_tau_gate_tolerance"] =
        tau_status.complementarity_tau_gate_tolerance
    metadata["complementarity_tau_gate_tolerance_source"] =
        tau_status.complementarity_tau_gate_tolerance_source
    metadata["complementarity_tau_gate_pass"] = tau_status.complementarity_tau_gate_pass
    merge!(
        metadata,
        _reduced_dcdfba_dynamic_control_objective_component_metadata(problem, has_values),
    )

    return ReducedDCDFBAMPCCSmokeResult(
        status,
        primal_status,
        objective_value,
        diagnostics.max_mass_balance_residual,
        diagnostics.max_lower_bound_violation,
        diagnostics.max_upper_bound_violation,
        diagnostics.max_stationarity_residual,
        diagnostics.max_lower_complementarity_residual,
        diagnostics.max_upper_complementarity_residual,
        solver_name,
        solve_elapsed_seconds,
        metadata,
    )
end

function _validate_reduced_dcdfba_mpcc_residual_thresholds(
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
)
    values = (
        thresholds.max_rhs_residual,
        thresholds.max_mass_balance_residual,
        thresholds.max_lower_bound_violation,
        thresholds.max_upper_bound_violation,
        thresholds.max_stationarity_residual,
        thresholds.max_lower_complementarity_residual,
        thresholds.max_upper_complementarity_residual,
    )
    all(value -> isfinite(value) && value >= 0.0, values) || throw(
        ArgumentError("Reduced DC-dFBA MPCC residual thresholds must be finite and nonnegative."),
    )
    return nothing
end

function _reduced_dcdfba_mpcc_solve_attempt_optimizer(
    optimizer,
    ipopt_max_iter::Union{Nothing, Int},
    profile::ReducedMPCCIpoptProfile,
    linear_solver::AbstractString,
)
    optimizer !== nothing && return optimizer
    return reduced_mpcc_ipopt_optimizer(;
        profile = profile.name,
        linear_solver = linear_solver,
        max_iter = ipopt_max_iter,
    )
end

function _reduced_dcdfba_mpcc_solve_attempt_optimizer_metadata(
    optimizer,
    ipopt_max_iter::Union{Nothing, Int},
    profile::ReducedMPCCIpoptProfile,
    linear_solver::AbstractString,
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "solve_attempt_optimizer_profile" =>
            optimizer === nothing ? profile.name :
            "custom_optimizer",
        "solve_attempt_optimizer_profile_is_default" => optimizer === nothing,
        "solve_attempt_ipopt_profile" => optimizer === nothing ? profile.name : "custom_optimizer",
        "solve_attempt_ipopt_profile_env" => REDUCED_DCDFBA_MPCC_IPOPT_PROFILE_ENV,
        "solve_attempt_ipopt_max_iter" => ipopt_max_iter,
        "solve_attempt_linear_solver" => linear_solver,
    )
    warm_start_metadata =
        optimizer === nothing ?
        _ipopt_warm_start_metadata(source = "env_or_default") :
        Dict{String, Any}(
            "ipopt_warm_start_init_point" => missing,
            "ipopt_warm_start_init_point_option" => missing,
            "ipopt_warm_start_init_point_env" => IPOPT_WARM_START_INIT_POINT_ENV,
            "ipopt_warm_start_init_point_source" => "custom_optimizer",
            "ipopt_warm_start_primal_starts_required" => missing,
            "ipopt_warm_start_dual_starts_provided" => missing,
            "ipopt_warm_start_bound_push" => missing,
            "ipopt_warm_start_bound_push_env" => IPOPT_WARM_START_BOUND_PUSH_ENV,
            "ipopt_warm_start_bound_push_source" => "custom_optimizer",
            "ipopt_warm_start_bound_frac" => missing,
            "ipopt_warm_start_bound_frac_env" => IPOPT_WARM_START_BOUND_FRAC_ENV,
            "ipopt_warm_start_bound_frac_source" => "custom_optimizer",
            "ipopt_warm_start_slack_bound_push" => missing,
            "ipopt_warm_start_slack_bound_push_env" =>
                IPOPT_WARM_START_SLACK_BOUND_PUSH_ENV,
            "ipopt_warm_start_slack_bound_push_source" => "custom_optimizer",
            "ipopt_warm_start_slack_bound_frac" => missing,
            "ipopt_warm_start_slack_bound_frac_env" =>
                IPOPT_WARM_START_SLACK_BOUND_FRAC_ENV,
            "ipopt_warm_start_slack_bound_frac_source" => "custom_optimizer",
            "ipopt_warm_start_mult_bound_push" => missing,
            "ipopt_warm_start_mult_bound_push_env" =>
                IPOPT_WARM_START_MULT_BOUND_PUSH_ENV,
            "ipopt_warm_start_mult_bound_push_source" => "custom_optimizer",
        )
    for (key, value) in warm_start_metadata
        metadata["solve_attempt_$(key)"] = value
    end
    max_wall_time_metadata =
        optimizer === nothing ?
        _ipopt_max_wall_time_metadata(source = "env_or_default") :
        Dict{String, Any}(
            "ipopt_max_wall_time_seconds" => missing,
            "ipopt_max_wall_time_env" => IPOPT_MAX_WALL_TIME_ENV,
            "ipopt_max_wall_time_source" => "custom_optimizer",
        )
    for (key, value) in max_wall_time_metadata
        metadata["solve_attempt_$(key)"] = value
    end
    hessian_approximation_metadata =
        optimizer === nothing ?
        _ipopt_hessian_approximation_metadata(source = "env_or_default") :
        Dict{String, Any}(
            "ipopt_hessian_approximation" => missing,
            "ipopt_hessian_approximation_configured" => missing,
            "ipopt_hessian_approximation_env" => IPOPT_HESSIAN_APPROXIMATION_ENV,
            "ipopt_hessian_approximation_source" => "custom_optimizer",
            "ipopt_hessian_approximation_supported_values" =>
                collect(IPOPT_HESSIAN_APPROXIMATION_VALUES),
        )
    for (key, value) in hessian_approximation_metadata
        metadata["solve_attempt_$(key)"] = value
    end
    linear_solver_metadata =
        _ipopt_linear_solver_metadata(linear_solver; source = optimizer === nothing ? "argument_or_env" : "custom_optimizer")
    for (key, value) in linear_solver_metadata
        metadata["solve_attempt_$(key)"] = value
    end
    if optimizer === nothing
        _reduced_dcdfba_mpcc_ipopt_profile_metadata!(metadata, profile)
    end
    return metadata
end

function _reduced_dcdfba_mpcc_ipopt_profile_metadata!(
    metadata::Dict{String, Any},
    profile::ReducedMPCCIpoptProfile,
)::Dict{String, Any}
    metadata["solve_attempt_ipopt_tol"] = _reduced_dcdfba_mpcc_profile_value(profile.tol)
    metadata["solve_attempt_ipopt_constr_viol_tol"] =
        _reduced_dcdfba_mpcc_profile_value(profile.constr_viol_tol)
    metadata["solve_attempt_ipopt_dual_inf_tol"] =
        _reduced_dcdfba_mpcc_profile_value(profile.dual_inf_tol)
    metadata["solve_attempt_ipopt_compl_inf_tol"] =
        _reduced_dcdfba_mpcc_profile_value(profile.compl_inf_tol)
    metadata["solve_attempt_ipopt_acceptable_tol"] =
        _reduced_dcdfba_mpcc_profile_value(profile.acceptable_tol)
    metadata["solve_attempt_ipopt_acceptable_constr_viol_tol"] =
        _reduced_dcdfba_mpcc_profile_value(profile.acceptable_constr_viol_tol)
    metadata["solve_attempt_ipopt_acceptable_compl_inf_tol"] =
        _reduced_dcdfba_mpcc_profile_value(profile.acceptable_compl_inf_tol)
    metadata["solve_attempt_ipopt_acceptable_dual_inf_tol"] =
        _reduced_dcdfba_mpcc_profile_value(profile.acceptable_dual_inf_tol)
    metadata["solve_attempt_ipopt_acceptable_obj_change_tol"] =
        _reduced_dcdfba_mpcc_profile_value(profile.acceptable_obj_change_tol)
    metadata["solve_attempt_ipopt_acceptable_iter"] =
        _reduced_dcdfba_mpcc_profile_value(profile.acceptable_iter)
    metadata["solve_attempt_ipopt_mu_strategy"] =
        _reduced_dcdfba_mpcc_profile_value(profile.mu_strategy)
    metadata["solve_attempt_ipopt_fixed_variable_treatment"] =
        _reduced_dcdfba_mpcc_profile_value(profile.fixed_variable_treatment)
    metadata["solve_attempt_ipopt_bound_push"] =
        _reduced_dcdfba_mpcc_profile_value(profile.bound_push)
    metadata["solve_attempt_ipopt_bound_frac"] =
        _reduced_dcdfba_mpcc_profile_value(profile.bound_frac)
    metadata["solve_attempt_ipopt_honor_original_bounds"] =
        _reduced_dcdfba_mpcc_profile_value(profile.honor_original_bounds)
    return metadata
end

_reduced_dcdfba_mpcc_profile_value(value) = value === nothing ? missing : value

function _reduced_dcdfba_mpcc_solve_attempt_problem_metadata(
    smoke_problem::ReducedDCDFBAMPCCSmokeProblem,
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
    ipopt_max_iter::Union{Nothing, Int},
    linear_solver::AbstractString,
    complementarity_mode::Symbol,
    complementarity_tau::Float64,
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "problem_type" => "reduced_dcdfba_mpcc_solve_attempt",
        "problem_scope" => "guarded_reduced_dynamic_mpcc_solve_attempt",
        "solve_attempt_guarded" => true,
        "solve_attempt_requires_rhs_residuals" => true,
        "solve_attempt_requires_dynamic_bounds" => true,
        "solve_attempt_requires_sequential_initialization" => true,
        "rhs_residuals_included" => smoke_problem.rhs_residuals !== nothing,
        "dynamic_flux_bounds_applied" => smoke_problem.dynamic_bounds !== nothing,
        "dynamic_flux_bound_mode" =>
            smoke_problem.dynamic_bounds === nothing ? "none" : String(smoke_problem.dynamic_bounds.mode),
        "dynamic_flux_bound_policy" =>
            smoke_problem.dynamic_bounds === nothing ? missing :
            get(smoke_problem.dynamic_bounds.metadata, "dynamic_flux_bound_policy", missing),
        "dynamic_phase_smoothing_width" =>
            smoke_problem.dynamic_bounds === nothing ? missing :
            get(smoke_problem.dynamic_bounds.metadata, "dynamic_phase_smoothing_width", missing),
        "dynamic_phase_proxy_mode" =>
            smoke_problem.dynamic_bounds === nothing ? missing :
            get(smoke_problem.dynamic_bounds.metadata, "dynamic_phase_proxy_mode", missing),
        "dynamic_phase_proxy_definition" =>
            smoke_problem.dynamic_bounds === nothing ? missing :
            get(smoke_problem.dynamic_bounds.metadata, "dynamic_phase_proxy_definition", missing),
        "dynamic_turnover_threshold" =>
            smoke_problem.dynamic_bounds === nothing ? missing :
            get(smoke_problem.dynamic_bounds.metadata, "dynamic_turnover_threshold", missing),
        "smooth_turnover_mode_embedded" =>
            smoke_problem.dynamic_bounds === nothing ? missing :
            get(smoke_problem.dynamic_bounds.metadata, "smooth_turnover_mode_embedded", missing),
        "turnover_mode_deferred" =>
            smoke_problem.dynamic_bounds === nothing ? missing :
            get(smoke_problem.dynamic_bounds.metadata, "turnover_mode_deferred", missing),
        "sequential_initialization_built" => smoke_problem.sequential_initialization !== nothing,
        "ipopt_max_iter" => ipopt_max_iter,
        "complementarity_mode" => String(complementarity_mode),
        "complementarity_tau" =>
            complementarity_mode == :scholtes ? complementarity_tau : missing,
        "model_scope" => "reduced",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "solver_call_performed" => false,
        "solve_attempt_is_scientific_simulation" => false,
        "residual_threshold_max_rhs_residual" => thresholds.max_rhs_residual,
        "residual_threshold_max_mass_balance_residual" => thresholds.max_mass_balance_residual,
        "residual_threshold_max_lower_bound_violation" => thresholds.max_lower_bound_violation,
        "residual_threshold_max_upper_bound_violation" => thresholds.max_upper_bound_violation,
        "residual_threshold_max_stationarity_residual" => thresholds.max_stationarity_residual,
        "residual_threshold_max_lower_complementarity_residual" =>
            thresholds.max_lower_complementarity_residual,
        "residual_threshold_max_upper_complementarity_residual" =>
            thresholds.max_upper_complementarity_residual,
        "residual_thresholds_are_scientific_acceptance_criteria" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
    merge!(metadata, _ipopt_linear_solver_metadata(linear_solver))
    merge!(metadata, _ipopt_warm_start_metadata())
    merge!(metadata, _ipopt_max_wall_time_metadata())
    merge!(metadata, _ipopt_hessian_approximation_metadata())
    _merge_reduced_dcdfba_metadata_prefix!(metadata, smoke_problem.metadata, "mpcc_dynamic_control_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, smoke_problem.metadata, "control_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, smoke_problem.metadata, "free_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, smoke_problem.metadata, "rhs_residual_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, smoke_problem.metadata, "dynamic_flux_bounds_")
    haskey(smoke_problem.metadata, "fully_simultaneous_controls") &&
        (metadata["fully_simultaneous_controls"] =
            smoke_problem.metadata["fully_simultaneous_controls"])
    _merge_reduced_dcdfba_metadata_prefix!(metadata, smoke_problem.metadata, "complementarity_")
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        smoke_problem.metadata,
        "collocation_consistent_state_start_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        smoke_problem.metadata,
        "selective_fixed_flux_stationarity_dual_fit_",
    )
    _merge_reduced_dcdfba_dynamic_flux_start_projection_metadata!(metadata, smoke_problem)
    return metadata
end

function _merge_reduced_dcdfba_dynamic_flux_start_projection_metadata!(
    metadata::Dict{String, Any},
    problem::ReducedDCDFBAMPCCSmokeProblem,
)
    for key in (
        "dynamic_flux_lp_start_applied",
        "dynamic_flux_lp_start_policy",
        "dynamic_flux_lp_start_collocation_points",
        "dynamic_flux_lp_start_solve_attempt_count",
        "dynamic_flux_lp_start_optimal_count",
        "dynamic_flux_lp_start_status_counts",
        "dynamic_flux_lp_start_solver",
        "dynamic_flux_lp_start_optimizer_attributes",
        "dynamic_flux_lp_start_time_limit_seconds",
        "dynamic_flux_lp_start_trace_enabled",
        "dynamic_flux_lp_start_trace_every",
        "dynamic_flux_lp_start_max_points",
        "dynamic_flux_lp_start_truncated_by_max_points",
        "dynamic_flux_lp_start_fail_fast",
        "dynamic_flux_lp_start_total_solve_elapsed_seconds",
        "dynamic_flux_lp_start_max_solve_elapsed_seconds",
        "dynamic_flux_lp_start_slowest_element_index",
        "dynamic_flux_lp_start_slowest_collocation_index",
        "dynamic_flux_lp_start_slowest_ordinal",
        "dynamic_flux_lp_start_slowest_status",
        "dynamic_flux_lp_start_first_nonoptimal_element_index",
        "dynamic_flux_lp_start_first_nonoptimal_collocation_index",
        "dynamic_flux_lp_start_first_nonoptimal_ordinal",
        "dynamic_flux_lp_start_first_nonoptimal_status",
        "dynamic_flux_lp_start_last_attempt_element_index",
        "dynamic_flux_lp_start_last_attempt_collocation_index",
        "dynamic_flux_lp_start_last_attempt_ordinal",
        "dynamic_flux_lp_start_objective_policy",
        "dynamic_flux_lp_start_objective_value_min",
        "dynamic_flux_lp_start_objective_value_max",
        "dynamic_flux_lp_start_objective_value_is_biomass_flux",
        "dynamic_flux_lp_start_max_mass_balance_residual",
        "dynamic_flux_lp_start_max_lower_bound_violation",
        "dynamic_flux_lp_start_max_upper_bound_violation",
        "dynamic_flux_lp_start_max_adjustment_from_previous",
        "dynamic_flux_lp_start_indices_reacciones_used",
        "dynamic_flux_lp_start_r0001_used_as_oxygen",
        "dynamic_flux_start_projection_applied",
        "dynamic_flux_start_projection_policy",
        "dynamic_flux_start_projection_checked_points",
        "dynamic_flux_start_projection_changed_count",
        "dynamic_flux_start_projection_changed_fraction",
        "dynamic_flux_start_projection_max_adjustment",
        "dynamic_flux_start_projection_max_lower_bound_violation_before",
        "dynamic_flux_start_projection_max_lower_bound_violation_after",
        "dynamic_flux_start_projection_max_upper_bound_violation_before",
        "dynamic_flux_start_projection_max_upper_bound_violation_after",
        "stationarity_dual_start_applied",
        "stationarity_dual_start_policy",
        "stationarity_dual_start_collocation_points",
        "stationarity_dual_start_optimal_count",
        "stationarity_dual_start_status_counts",
        "stationarity_dual_start_solver",
        "stationarity_dual_start_objective_policy",
        "stationarity_dual_start_objective_nonzero_count",
        "stationarity_dual_start_objective_value_min",
        "stationarity_dual_start_objective_value_max",
        "stationarity_dual_start_flux_start_updated",
        "stationarity_dual_start_mass_balance_duals_changed",
        "stationarity_dual_start_bound_duals_changed",
        "stationarity_dual_start_max_stationarity_residual_before",
        "stationarity_dual_start_max_stationarity_residual_after",
        "stationarity_dual_start_max_lower_complementarity_residual_after",
        "stationarity_dual_start_max_upper_complementarity_residual_after",
        "stationarity_dual_start_max_mass_balance_residual",
        "stationarity_dual_start_max_lower_bound_violation",
        "stationarity_dual_start_max_upper_bound_violation",
        "stationarity_dual_start_max_flux_adjustment_from_previous",
        "stationarity_dual_start_mass_balance_dual_abs_max",
        "stationarity_dual_start_lower_bound_dual_abs_max",
        "stationarity_dual_start_upper_bound_dual_abs_max",
        "stationarity_dual_start_max_dual_sign_clipping",
        "stationarity_dual_start_indices_reacciones_used",
        "stationarity_dual_start_r0001_used_as_oxygen",
        "stationarity_dual_start_is_scientific_simulation",
        "rhs_consistent_derivative_start_applied",
        "rhs_consistent_derivative_start_policy",
        "rhs_consistent_derivative_start_collocation_points",
        "rhs_consistent_derivative_start_max_adjustment",
        "rhs_consistent_derivative_start_max_abs_value",
        "rhs_consistent_derivative_start_max_rhs_residual_after",
        "rhs_consistent_derivative_start_oxygen_derivative_policy",
        "rhs_consistent_derivative_start_carbohydrate_policy",
        "rhs_consistent_derivative_start_is_scientific_simulation",
        "collocation_consistent_state_start_applied",
        "collocation_consistent_state_start_policy",
        "collocation_consistent_state_start_iterations",
        "collocation_consistent_state_start_max_iterations",
        "collocation_consistent_state_start_tolerance",
        "collocation_consistent_state_start_converged",
        "collocation_consistent_state_start_initial_collocation_residual",
        "collocation_consistent_state_start_initial_continuity_residual",
        "collocation_consistent_state_start_initial_rhs_residual",
        "collocation_consistent_state_start_final_collocation_residual",
        "collocation_consistent_state_start_final_continuity_residual",
        "collocation_consistent_state_start_final_rhs_residual",
        "collocation_consistent_state_start_max_state_collocation_adjustment",
        "collocation_consistent_state_start_max_state_boundary_adjustment",
        "collocation_consistent_state_start_initial_max_residual",
        "collocation_consistent_state_start_final_max_residual",
        "collocation_consistent_state_start_last_residual_improvement",
        "collocation_consistent_state_start_trace_enabled",
        "collocation_consistent_state_start_restore_best_enabled",
        "collocation_consistent_state_start_monotone_enabled",
        "collocation_consistent_state_start_trace_substeps_enabled",
        "collocation_consistent_state_start_final_state_refresh_enabled",
        "collocation_consistent_state_start_final_flux_projection_enabled",
        "collocation_consistent_state_start_final_dual_fit_enabled",
        "collocation_consistent_state_start_flux_refresh_guard_enabled",
        "collocation_consistent_state_start_flux_refresh_guard_policy",
        "collocation_consistent_state_start_flux_refresh_guard_score_policy",
        "collocation_consistent_state_start_flux_refresh_guard_accepted",
        "collocation_consistent_state_start_flux_refresh_guard_before_score",
        "collocation_consistent_state_start_flux_refresh_guard_after_score",
        "collocation_consistent_state_start_flux_refresh_guard_restored_score",
        "collocation_consistent_state_start_flux_refresh_max_iterations",
        "collocation_consistent_state_start_trace_every",
        "collocation_consistent_state_start_damping_factors",
        "collocation_consistent_state_start_monotone_acceptance_tolerance",
        "collocation_consistent_state_start_trial_count",
        "collocation_consistent_state_start_rejected_trial_count",
        "collocation_consistent_state_start_last_accepted_damping_factor",
        "collocation_consistent_state_start_min_accepted_damping_factor",
        "collocation_consistent_state_start_last_rejected_damping_factor",
        "collocation_consistent_state_start_last_rejected_max_residual",
        "collocation_consistent_state_start_stopped_by_monotone_guard",
        "collocation_consistent_state_start_last_final_state_refresh_applied",
        "collocation_consistent_state_start_last_final_flux_projection_applied",
        "collocation_consistent_state_start_last_final_dual_fit_applied",
        "collocation_consistent_state_start_last_dynamic_flux_refresh_applied",
        "collocation_consistent_state_start_last_final_state_collocation_adjustment",
        "collocation_consistent_state_start_last_final_state_boundary_adjustment",
        "collocation_consistent_state_start_best_iteration",
        "collocation_consistent_state_start_best_max_residual",
        "collocation_consistent_state_start_restored_best_iteration",
        "collocation_consistent_state_start_restore_best_improvement",
        "collocation_consistent_state_start_stagnation_tolerance",
        "collocation_consistent_state_start_stagnation_iterations",
        "collocation_consistent_state_start_stagnation_counter",
        "collocation_consistent_state_start_stopped_by_stagnation",
        "collocation_consistent_state_start_last_dynamic_flux_lp_attempt_count",
        "collocation_consistent_state_start_last_dynamic_flux_lp_total_solve_elapsed_seconds",
        "collocation_consistent_state_start_last_dynamic_flux_lp_max_solve_elapsed_seconds",
        "collocation_consistent_state_start_dynamic_flux_refreshed",
        "collocation_consistent_state_start_stationarity_duals_refreshed",
        "collocation_consistent_state_start_rhs_derivatives_refreshed",
        "collocation_consistent_state_start_is_scientific_simulation",
    )
        if haskey(problem.metadata, key)
            metadata[key] = problem.metadata[key]
        end
    end
    return metadata
end

function _reduced_dcdfba_mpcc_solve_attempt_residual_report(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    smoke_result::ReducedDCDFBAMPCCSmokeResult,
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
    ;
    include_structural_rows::Bool = true,
)::Dict{String, Any}
    rhs_residual = _reduced_dcdfba_mpcc_rhs_residual(problem)
    residuals = Dict{String, Float64}(
        "max_rhs_residual" => rhs_residual,
        "max_mass_balance_residual" => smoke_result.max_mass_balance_residual,
        "max_lower_bound_violation" => smoke_result.max_lower_bound_violation,
        "max_upper_bound_violation" => smoke_result.max_upper_bound_violation,
        "max_stationarity_residual" => smoke_result.max_stationarity_residual,
        "max_lower_complementarity_residual" => smoke_result.max_lower_complementarity_residual,
        "max_upper_complementarity_residual" => smoke_result.max_upper_complementarity_residual,
    )
    env_skips_structural_rows = _reduced_dcdfba_mpcc_skip_nlp_block_violation_rows()
    skip_structural_rows = env_skips_structural_rows || !include_structural_rows
    structural_skip_reason =
        env_skips_structural_rows ? REDUCED_DCDFBA_MPCC_SKIP_NLP_BLOCK_VIOLATION_ROWS_ENV :
        !include_structural_rows ? "deferred_by_caller" :
        missing
    structural_rows =
        skip_structural_rows ? Dict{String, Any}[] :
        _reduced_dcdfba_mpcc_nlp_block_violation_rows(problem)
    structural_residuals, structural_thresholds =
        _reduced_dcdfba_mpcc_structural_nlp_residual_gate_values(
            residuals,
            structural_rows,
            thresholds,
        )
    empty!(residuals)
    merge!(residuals, structural_residuals)
    threshold_values = _reduced_dcdfba_mpcc_effective_threshold_values(
        problem,
        thresholds,
    )
    merge!(
        threshold_values,
        structural_thresholds,
    )
    within = Dict{String, Bool}(
        key => isfinite(residuals[key]) && residuals[key] <= threshold_values[key] for
        key in keys(residuals)
    )
    residuals_available = all(value -> isfinite(value), values(residuals))
    residual_thresholds_satisfied = residuals_available && all(values(within))
    ratios = _reduced_dcdfba_mpcc_residual_ratios(residuals, threshold_values)
    ranked_residuals = _reduced_dcdfba_mpcc_ranked_residuals(ratios)
    dominant_residual = isempty(ranked_residuals) ? "unavailable" : first(ranked_residuals)
    tau_status = _reduced_dcdfba_mpcc_complementarity_tau_status(
        problem,
        smoke_result.max_lower_complementarity_residual,
        smoke_result.max_upper_complementarity_residual,
    )

    report = Dict{String, Any}(
        "residuals_available" => residuals_available,
        "residual_thresholds_satisfied" => residual_thresholds_satisfied,
        "residual_threshold_report" => within,
        "residual_ratios" => ratios,
        "ranked_residuals" => ranked_residuals,
        "dominant_residual" => dominant_residual,
        "max_rhs_residual_within_threshold" => within["max_rhs_residual"],
        "max_collocation_integration_residual_within_threshold" =>
            within["max_collocation_integration_residual"],
        "max_continuity_residual_within_threshold" => within["max_continuity_residual"],
        "max_initial_condition_residual_within_threshold" =>
            within["max_initial_condition_residual"],
        "max_mass_balance_residual_within_threshold" => within["max_mass_balance_residual"],
        "max_lower_bound_violation_within_threshold" => within["max_lower_bound_violation"],
        "max_upper_bound_violation_within_threshold" => within["max_upper_bound_violation"],
        "max_stationarity_residual_within_threshold" => within["max_stationarity_residual"],
        "max_lower_complementarity_residual_within_threshold" =>
            within["max_lower_complementarity_residual"],
        "max_upper_complementarity_residual_within_threshold" =>
            within["max_upper_complementarity_residual"],
        "max_lower_complementarity_product" =>
            smoke_result.max_lower_complementarity_residual,
        "max_upper_complementarity_product" =>
            smoke_result.max_upper_complementarity_residual,
        "max_complementarity_tau_violation" =>
            tau_status.max_complementarity_tau_violation,
        "max_complementarity_tau_violation_raw" =>
            tau_status.max_complementarity_tau_violation_raw,
        "complementarity_tau_gate_tolerance" =>
            tau_status.complementarity_tau_gate_tolerance,
        "complementarity_tau_gate_tolerance_source" =>
            tau_status.complementarity_tau_gate_tolerance_source,
        "complementarity_tau_gate_pass" => tau_status.complementarity_tau_gate_pass,
        "complementarity_mode" =>
            get(problem.metadata, "complementarity_mode", "exact"),
        "complementarity_tau" =>
            get(problem.metadata, "complementarity_tau", missing),
        "complementarity_residual_gate_policy" =>
            _reduced_dcdfba_mpcc_complementarity_residual_gate_policy(problem.metadata),
        "nlp_block_violation_report_skipped" => skip_structural_rows,
        "nlp_block_violation_report_skip_reason" =>
            structural_skip_reason,
        "structural_nlp_residual_gate_applied" => !skip_structural_rows,
        "structural_nlp_residual_gate_skipped" => skip_structural_rows,
        "structural_nlp_residual_gate_skip_reason" =>
            structural_skip_reason,
        "residual_thresholds_are_scientific_acceptance_criteria" => false,
    )
    for key in keys(residuals)
        report[key] = residuals[key]
        report["$(key)_threshold"] = threshold_values[key]
        report["$(key)_ratio"] = ratios[key]
    end
    return report
end

function _reduced_dcdfba_mpcc_solve_attempt_pre_solve_metadata(
    report::ReducedDCDFBAMPCCDiagnosticReport,
    require_pre_solve_ready::Bool,
)::Dict{String, Any}
    scaling_ready = get(
        report.metadata,
        "scaling_plan_ready_for_guarded_solve_attempt",
        false,
    ) === true
    blocking_warning_count = Int(get(report.metadata, "scaling_blocking_warning_count", 0))
    review_warning_count = Int(get(report.metadata, "scaling_review_warning_count", 0))
    scaling_warnings_block_solver = false
    guard_passed = report.residuals_available &&
                   report.residual_thresholds_satisfied
    solve_allowed = !require_pre_solve_ready || guard_passed
    guard_failure_component =
        !report.residuals_available ? "residuals_unavailable" :
        !report.residual_thresholds_satisfied ? "residual_thresholds_failed" :
        scaling_warnings_block_solver && !scaling_ready ? "scaling_plan_not_ready" :
        scaling_warnings_block_solver && blocking_warning_count > 0 ? "scaling_blocking_warnings" :
        "none"
    first_warning = isempty(report.warnings) ? missing : first(report.warnings)
    return Dict{String, Any}(
        "pre_solve_diagnostic_report_built" => true,
        "pre_solve_guard_required" => require_pre_solve_ready,
        "pre_solve_guard_passed" => guard_passed,
        "pre_solve_guard_failure_component" => guard_failure_component,
        "pre_solve_guard_policy" => "residual_thresholds_only",
        "pre_solve_residuals_available" => report.residuals_available,
        "pre_solve_residual_thresholds_satisfied" =>
            report.residual_thresholds_satisfied,
        "pre_solve_scaling_plan_ready_for_guarded_solve_attempt" => scaling_ready,
        "pre_solve_scaling_warnings_block_solver" => scaling_warnings_block_solver,
        "pre_solve_scaling_warning_policy" =>
            "diagnostic_only_after_residual_thresholds_pass",
        "pre_solve_scaling_blocking_warning_count" => blocking_warning_count,
        "pre_solve_scaling_review_warning_count" => review_warning_count,
        "pre_solve_warning_count" => length(report.warnings),
        "pre_solve_first_warning" => first_warning,
        "pre_solve_warnings" => copy(report.warnings),
        "pre_solve_dominant_residual" => report.dominant_residual,
        "guarded_solve_attempt_allowed" => solve_allowed,
        "guarded_solve_attempt_blocked" => require_pre_solve_ready && !guard_passed,
        "pre_solve_is_scientific_simulation" => false,
    )
end

function _reduced_dcdfba_mpcc_solve_attempt_post_solve_metadata(
    smoke_result::ReducedDCDFBAMPCCSmokeResult,
    residual_report::Dict{String, Any},
)::Dict{String, Any}
    status_allows_candidate =
        _reduced_dcdfba_mpcc_status_allows_trajectory_candidate(smoke_result.status)
    almost_locally_solved_accepted = smoke_result.status == MOI.ALMOST_LOCALLY_SOLVED
    residuals_satisfied = get(residual_report, "residual_thresholds_satisfied", false) === true
    residuals_available = get(residual_report, "residuals_available", false) === true
    primal_status_allows_residual_candidate =
        _reduced_dcdfba_mpcc_primal_status_allows_residual_candidate(smoke_result.primal_status)
    residual_feasible_candidate = residuals_available &&
                                  residuals_satisfied &&
                                  primal_status_allows_residual_candidate
    iteration_limit_residual_feasible_candidate =
        smoke_result.status == MOI.ITERATION_LIMIT && residual_feasible_candidate
    trajectory_extraction_ready = status_allows_candidate &&
                                  residual_feasible_candidate
    requires_status_before_trajectory_extraction =
        !status_allows_candidate && residual_feasible_candidate
    next_recommended_action = if trajectory_extraction_ready
        "extract_candidate_trajectory"
    elseif iteration_limit_residual_feasible_candidate
        "review_iteration_limit_residual_feasible_candidate"
    elseif residuals_available && !residuals_satisfied
        "improve_residuals_before_trajectory_extraction"
    else
        "improve_solver_status_or_residual_availability"
    end
    return Dict{String, Any}(
        "post_solve_diagnostic_report_built" => true,
        "post_solve_status_allows_trajectory_candidate" => status_allows_candidate,
        "post_solve_almost_locally_solved_accepted" =>
            almost_locally_solved_accepted && residual_feasible_candidate,
        "post_solve_acceptable_solver_status" =>
            smoke_result.status in (MOI.LOCALLY_SOLVED, MOI.ALMOST_LOCALLY_SOLVED, MOI.OPTIMAL),
        "post_solve_primal_status_allows_residual_candidate" =>
            primal_status_allows_residual_candidate,
        "post_solve_residuals_available" => residuals_available,
        "post_solve_residual_thresholds_satisfied" => residuals_satisfied,
        "post_solve_residual_feasible_candidate" => residual_feasible_candidate,
        "post_solve_iteration_limit_residual_feasible_candidate" =>
            iteration_limit_residual_feasible_candidate,
        "post_solve_requires_status_before_trajectory_extraction" =>
            requires_status_before_trajectory_extraction,
        "post_solve_dominant_residual" =>
            get(residual_report, "dominant_residual", "unavailable"),
        "post_solve_next_recommended_action" => next_recommended_action,
        "trajectory_extraction_ready" => trajectory_extraction_ready,
        "solved_trajectory_claimed" => false,
        "post_solve_is_scientific_simulation" => false,
    )
end

function _reduced_dcdfba_mpcc_status_allows_trajectory_candidate(
    status::MOI.TerminationStatusCode,
)::Bool
    return status in (MOI.LOCALLY_SOLVED, MOI.ALMOST_LOCALLY_SOLVED, MOI.OPTIMAL)
end

function _reduced_dcdfba_mpcc_primal_status_allows_residual_candidate(
    status::MOI.ResultStatusCode,
)::Bool
    return status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT)
end

function _reduced_dcdfba_mpcc_pre_solve_candidate_value_arrays_or_nothing(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)
    starts = try
        _reduced_dcdfba_mpcc_scaling_start_values(problem)
    catch
        return nothing
    end
    dynamic_control_values =
        _reduced_dcdfba_mpcc_dynamic_control_start_candidate_values_or_nothing(problem)
    dynamic_control_values === nothing && return nothing
    return (
        state_boundary = copy(starts.state_boundary),
        state_collocation = copy(starts.state_collocation),
        state_derivative = copy(starts.state_derivative),
        flux = copy(starts.flux),
        lower_bound_duals = copy(starts.lower_dual),
        upper_bound_duals = copy(starts.upper_dual),
        mass_balance_duals = copy(starts.mass_dual),
        dynamic_control_temperature_C = copy(dynamic_control_values.temperature_C),
        dynamic_control_fda_g_L = copy(dynamic_control_values.fda_g_L),
        dynamic_control_organic_g_L = copy(dynamic_control_values.organic_g_L),
    )
end

function _reduced_dcdfba_mpcc_pre_solve_candidate_diagnostics_or_nothing(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    smoke_result::ReducedDCDFBAMPCCSmokeResult,
    candidate_values,
)::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics}
    candidate_values === nothing && return nothing
    candidate = _reduced_dcdfba_mpcc_candidate_diagnostics_from_values(
        problem.smoke_problem,
        smoke_result,
        problem.residual_thresholds,
        candidate_values,
        "pre_solve_start_values",
    )
    residuals_available = all(isfinite, values(candidate.residual_values))
    residual_thresholds_satisfied =
        residuals_available &&
        all(
            key -> abs(candidate.residual_values[key]) <= candidate.residual_thresholds[key],
            keys(candidate.residual_values),
        )
    residual_feasible_candidate = residuals_available && residual_thresholds_satisfied
    candidate.metadata["candidate_solver_status"] = "PRE_SOLVE_START_VALUES"
    candidate.metadata["candidate_primal_status"] = "FEASIBLE_START_VALUES"
    candidate.metadata["candidate_status_source"] =
        "pre_solve_start_values_not_solver_result"
    candidate.metadata["candidate_status_allows_trajectory_candidate"] = false
    candidate.metadata["candidate_primal_status_allows_residual_candidate"] = true
    candidate.metadata["candidate_residuals_available"] = residuals_available
    candidate.metadata["candidate_residual_thresholds_satisfied"] =
        residual_thresholds_satisfied
    candidate.metadata["candidate_residual_feasible"] = residual_feasible_candidate
    candidate.metadata["candidate_trajectory_extraction_ready"] = false
    candidate.metadata["candidate_iteration_limit_residual_feasible"] =
        residual_feasible_candidate
    candidate.metadata["pre_solve_start_candidate_diagnostics_built"] = true
    candidate.metadata["post_solve_solver_status_observed_after_start_capture"] =
        string(smoke_result.status)
    candidate.metadata["post_solve_primal_status_observed_after_start_capture"] =
        string(smoke_result.primal_status)
    return candidate
end

function _reduced_dcdfba_mpcc_candidate_metadata_bool(
    candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
    key::AbstractString,
)::Bool
    candidate === nothing && return false
    return get(candidate.metadata, String(key), false) === true
end

function _reduced_dcdfba_mpcc_candidate_metadata_source(
    candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
    fallback::AbstractString,
)::String
    candidate === nothing && return String(fallback)
    return String(
        get(
            candidate.metadata,
            "candidate_values_source",
            get(candidate.metadata, "candidate_value_source", fallback),
        ),
    )
end

function _reduced_dcdfba_mpcc_prefixed_dynamic_control_candidate_metadata(
    candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
    prefix::AbstractString,
)::Dict{String, Any}
    output = Dict{String, Any}(
        "$(prefix)_dynamic_control_values_captured" => false,
    )
    candidate === nothing && return output
    for (key, value) in candidate.metadata
        startswith(key, "candidate_dynamic_control_") || continue
        suffix = key[(length("candidate_") + 1):end]
        output["$(prefix)_$(suffix)"] = deepcopy(value)
    end
    if !haskey(output, "$(prefix)_dynamic_control_values_captured")
        output["$(prefix)_dynamic_control_values_captured"] = false
    end
    return output
end

function _reduced_dcdfba_mpcc_vector_max_abs_delta_or_missing(
    values,
    reference_values,
)
    length(values) == length(reference_values) || return missing
    isempty(values) && return 0.0
    return maximum(abs.(Float64.(values) .- Float64.(reference_values)))
end

function _reduced_dcdfba_mpcc_vector_sum_delta_or_missing(
    values,
    reference_values,
)
    length(values) == length(reference_values) || return missing
    return sum(Float64.(values)) - sum(Float64.(reference_values))
end

function _reduced_dcdfba_mpcc_post_solve_dynamic_control_delta_metadata(
    pre_solve_candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
    post_solve_candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
)::Dict{String, Any}
    output = Dict{String, Any}(
        "post_solve_candidate_dynamic_control_delta_vs_pre_solve_available" => false,
    )
    pre_values =
        pre_solve_candidate === nothing ? nothing :
        _reduced_dcdfba_mpcc_candidate_dynamic_control_values_from_metadata(
            pre_solve_candidate.metadata,
        )
    post_values =
        post_solve_candidate === nothing ? nothing :
        _reduced_dcdfba_mpcc_candidate_dynamic_control_values_from_metadata(
            post_solve_candidate.metadata,
        )
    (pre_values === nothing || post_values === nothing) && return output
    output["post_solve_candidate_dynamic_control_delta_vs_pre_solve_available"] = true
    for (family, values, reference_values) in (
        ("temperature_C", post_values.temperature_C, pre_values.temperature_C),
        ("fda_g_L", post_values.fda_g_L, pre_values.fda_g_L),
        ("organic_g_L", post_values.organic_g_L, pre_values.organic_g_L),
    )
        output["post_solve_candidate_dynamic_control_$(family)_max_abs_delta_vs_pre_solve"] =
            _reduced_dcdfba_mpcc_vector_max_abs_delta_or_missing(values, reference_values)
        output["post_solve_candidate_dynamic_control_$(family)_sum_delta_vs_pre_solve"] =
            _reduced_dcdfba_mpcc_vector_sum_delta_or_missing(values, reference_values)
    end
    return output
end

function _reduced_dcdfba_mpcc_select_solve_attempt_candidate(
    pre_solve_candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
    post_solve_candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics};
    accept_post_solve_requires_trajectory_ready::Bool = false,
    selection_policy::Symbol = :safe,
)
    selection_policy in (:safe, :prefer_post_solve_if_available) || throw(
        ArgumentError(
            "Reduced MPCC solve-attempt candidate selection policy must be " *
            ":safe or :prefer_post_solve_if_available, got: $(selection_policy).",
        ),
    )
    pre_available = pre_solve_candidate !== nothing
    post_available = post_solve_candidate !== nothing
    pre_residual_feasible = _reduced_dcdfba_mpcc_candidate_metadata_bool(
        pre_solve_candidate,
        "candidate_residual_feasible",
    )
    post_residual_feasible = _reduced_dcdfba_mpcc_candidate_metadata_bool(
        post_solve_candidate,
        "candidate_residual_feasible",
    )
    pre_trajectory_ready = _reduced_dcdfba_mpcc_candidate_metadata_bool(
        pre_solve_candidate,
        "candidate_trajectory_extraction_ready",
    )
    post_trajectory_ready = _reduced_dcdfba_mpcc_candidate_metadata_bool(
        post_solve_candidate,
        "candidate_trajectory_extraction_ready",
    )
    post_accepted =
        post_available &&
        post_residual_feasible &&
        (!accept_post_solve_requires_trajectory_ready || post_trajectory_ready)
    pre_residual_score = _reduced_dcdfba_mpcc_candidate_residual_score(pre_solve_candidate)
    post_residual_score = _reduced_dcdfba_mpcc_candidate_residual_score(post_solve_candidate)
    pre_is_best_failed_candidate =
        pre_available &&
        !pre_residual_feasible &&
        !post_residual_feasible &&
        (
            !post_available ||
            (isfinite(pre_residual_score) && pre_residual_score <= post_residual_score)
        )
    selected_candidate =
        if selection_policy == :prefer_post_solve_if_available && post_available
            post_solve_candidate
        elseif post_accepted
            post_solve_candidate
        elseif pre_available && pre_residual_feasible
            pre_solve_candidate
        elseif pre_is_best_failed_candidate
            pre_solve_candidate
        elseif post_available
            post_solve_candidate
        else
            pre_solve_candidate
        end
    selected_is_post = selected_candidate !== nothing && selected_candidate === post_solve_candidate
    selected_is_pre =
        selected_candidate !== nothing && selected_candidate === pre_solve_candidate
    post_rejection_reason =
        if !post_available
            "missing"
        elseif post_accepted
            "accepted"
        elseif !post_residual_feasible
            "not_residual_feasible"
        elseif accept_post_solve_requires_trajectory_ready && !post_trajectory_ready
            "not_trajectory_ready"
        else
            "fallback_pre_solve_start_preferred"
        end
    reason =
        if selection_policy == :prefer_post_solve_if_available && post_available
            post_residual_feasible ?
            "post_solve_candidate_selected_for_continuation_warm_start_residual_feasible" :
            "post_solve_candidate_selected_for_continuation_warm_start_not_residual_feasible"
        elseif post_accepted
            "post_solve_candidate_residual_feasible"
        elseif !post_available && pre_available
            "post_solve_candidate_missing_fallback_to_pre_solve_start"
        elseif post_available && !post_residual_feasible && pre_residual_feasible
            "post_solve_candidate_not_residual_feasible_fallback_to_pre_solve_start"
        elseif post_available &&
               accept_post_solve_requires_trajectory_ready &&
               !post_trajectory_ready &&
               pre_residual_feasible
            "post_solve_candidate_not_trajectory_ready_fallback_to_pre_solve_start"
        elseif pre_is_best_failed_candidate
            "pre_solve_start_retained_for_diagnostics_lower_residual_score"
        elseif selected_is_post
            "post_solve_candidate_retained_for_diagnostics_no_residual_feasible_fallback"
        elseif selected_is_pre
            "pre_solve_start_retained_for_diagnostics_no_residual_feasible_post_solve_candidate"
        else
            "no_candidate_values_available"
        end
    selected_source =
        selected_is_post ?
        _reduced_dcdfba_mpcc_candidate_metadata_source(
            post_solve_candidate,
            "post_solve_values",
        ) :
        selected_is_pre ?
        _reduced_dcdfba_mpcc_candidate_metadata_source(
            pre_solve_candidate,
            "pre_solve_start_values",
        ) : "none"
    metadata = Dict{String, Any}(
        "candidate_selection_policy" =>
            selection_policy == :prefer_post_solve_if_available ?
            "prefer_post_solve_if_available_for_internal_continuation_warm_start" :
            "prefer_post_solve_residual_feasible_else_pre_solve_residual_feasible_else_lower_residual_score",
        "candidate_selection_policy_symbol" => String(selection_policy),
        "candidate_selection_reason" => reason,
        "candidate_selection_accept_post_solve_requires_trajectory_ready" =>
            accept_post_solve_requires_trajectory_ready,
        "candidate_selection_pre_solve_residual_score" => pre_residual_score,
        "candidate_selection_post_solve_residual_score" => post_residual_score,
        "selected_candidate_source" => selected_source,
        "selected_candidate_value_source" => selected_source,
        "selected_candidate_is_post_solve" => selected_is_post,
        "selected_candidate_is_pre_solve_start" => selected_is_pre,
        "selected_candidate_available" => selected_candidate !== nothing,
        "selected_candidate_residual_feasible" =>
            _reduced_dcdfba_mpcc_candidate_metadata_bool(
                selected_candidate,
                "candidate_residual_feasible",
            ),
        "selected_candidate_trajectory_ready" =>
            _reduced_dcdfba_mpcc_candidate_metadata_bool(
                selected_candidate,
                "candidate_trajectory_extraction_ready",
            ),
        "selected_candidate_dominant_residual" =>
            selected_candidate === nothing ?
            missing : get(selected_candidate.metadata, "candidate_dominant_residual", missing),
        "pre_solve_candidate_available" => pre_available,
        "pre_solve_candidate_residual_feasible" => pre_residual_feasible,
        "pre_solve_candidate_trajectory_ready" => pre_trajectory_ready,
        "pre_solve_start_candidate_available" => pre_available,
        "pre_solve_start_candidate_residual_feasible" => pre_residual_feasible,
        "pre_solve_start_candidate_trajectory_ready" => pre_trajectory_ready,
        "post_solve_candidate_available" => post_available,
        "post_solve_candidate_residual_feasible" => post_residual_feasible,
        "post_solve_candidate_trajectory_ready" => post_trajectory_ready,
        "post_solve_candidate_accepted" => post_accepted,
        "post_solve_candidate_rejected" => post_available && !post_accepted,
        "post_solve_candidate_rejection_reason" => post_rejection_reason,
    )
    merge!(
        metadata,
        _reduced_dcdfba_mpcc_prefixed_dynamic_control_candidate_metadata(
            pre_solve_candidate,
            "pre_solve_candidate",
        ),
    )
    merge!(
        metadata,
        _reduced_dcdfba_mpcc_prefixed_dynamic_control_candidate_metadata(
            post_solve_candidate,
            "post_solve_candidate",
        ),
    )
    merge!(
        metadata,
        _reduced_dcdfba_mpcc_post_solve_dynamic_control_delta_metadata(
            pre_solve_candidate,
            post_solve_candidate,
        ),
    )
    return (candidate = selected_candidate, metadata = metadata)
end

function _reduced_dcdfba_mpcc_candidate_diagnostics_or_nothing(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    smoke_result::ReducedDCDFBAMPCCSmokeResult,
)::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics}
    JuMP.result_count(problem.smoke_problem.nlp.jump_model) > 0 || return nothing
    candidate_values = _reduced_dcdfba_mpcc_candidate_value_arrays(problem.smoke_problem)
    candidate_values === nothing && return nothing
    return _reduced_dcdfba_mpcc_candidate_diagnostics_from_values(
        problem.smoke_problem,
        smoke_result,
        problem.residual_thresholds,
        candidate_values,
        "post_solve_values",
    )
end

function _reduced_dcdfba_mpcc_candidate_value_arrays(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)
    state_boundary = _reduced_dcdfba_value_array_or_nothing(problem.nlp.state_boundary)
    state_collocation = _reduced_dcdfba_value_array_or_nothing(problem.nlp.state_collocation)
    state_derivative = _reduced_dcdfba_value_array_or_nothing(problem.nlp.state_derivative)
    flux = _reduced_dcdfba_value_array_or_nothing(problem.nlp.flux)
    lower_bound_duals =
        _reduced_dcdfba_value_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_bound_duals =
        _reduced_dcdfba_value_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_balance_duals =
        _reduced_dcdfba_value_array_or_nothing(problem.stationarity.mass_balance_duals)
    dynamic_control_values =
        _reduced_dcdfba_mpcc_dynamic_control_solution_candidate_values_or_nothing(problem)
    any(
        value -> value === nothing,
        (
            state_boundary,
            state_collocation,
            state_derivative,
            flux,
            lower_bound_duals,
            upper_bound_duals,
            mass_balance_duals,
            dynamic_control_values,
        ),
    ) && return nothing
    return (
        state_boundary = state_boundary,
        state_collocation = state_collocation,
        state_derivative = state_derivative,
        flux = flux,
        lower_bound_duals = lower_bound_duals,
        upper_bound_duals = upper_bound_duals,
        mass_balance_duals = mass_balance_duals,
        dynamic_control_temperature_C = copy(dynamic_control_values.temperature_C),
        dynamic_control_fda_g_L = copy(dynamic_control_values.fda_g_L),
        dynamic_control_organic_g_L = copy(dynamic_control_values.organic_g_L),
    )
end

function _reduced_dcdfba_mpcc_candidate_diagnostics_from_values(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    smoke_result::ReducedDCDFBAMPCCSmokeResult,
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
    candidate_values,
    value_source::AbstractString,
)::ReducedDCDFBAMPCCCandidateDiagnostics
    dynamic_control_values =
        _reduced_dcdfba_mpcc_candidate_dynamic_control_values(candidate_values)
    diagnostics = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        candidate_values.flux,
        candidate_values.lower_bound_duals,
        candidate_values.upper_bound_duals,
        candidate_values.mass_balance_duals,
        candidate_values.state_collocation,
        dynamic_control_values = dynamic_control_values,
    )
    rhs_residual = problem.rhs_residuals === nothing ? NaN :
                   _reduced_dcdfba_mpcc_rhs_residual_from_values(
        problem,
        candidate_values.state_collocation,
        candidate_values.state_derivative,
        candidate_values.flux,
        dynamic_control_values = dynamic_control_values,
    )
    residual_values = Dict{String, Float64}(
        "max_rhs_residual" => rhs_residual,
        "max_mass_balance_residual" => diagnostics.max_mass_balance_residual,
        "max_lower_bound_violation" => diagnostics.max_lower_bound_violation,
        "max_upper_bound_violation" => diagnostics.max_upper_bound_violation,
        "max_stationarity_residual" => diagnostics.max_stationarity_residual,
        "max_lower_complementarity_residual" => diagnostics.max_lower_complementarity_residual,
        "max_upper_complementarity_residual" => diagnostics.max_upper_complementarity_residual,
    )
    residual_thresholds = _reduced_dcdfba_mpcc_effective_threshold_values(
        problem,
        thresholds,
    )
    residual_ratios = _reduced_dcdfba_mpcc_residual_ratios(residual_values, residual_thresholds)
    ranked_residuals = _reduced_dcdfba_mpcc_ranked_residuals(residual_ratios)
    residuals_available = all(isfinite, values(residual_values))
    residual_thresholds_satisfied =
        residuals_available &&
        all(key -> abs(residual_values[key]) <= residual_thresholds[key], keys(residual_values))

    summary = _reduced_dcdfba_mpcc_candidate_summary(
        problem,
        candidate_values,
        dynamic_control_values = dynamic_control_values,
    )
    status_allows_candidate =
        _reduced_dcdfba_mpcc_status_allows_trajectory_candidate(smoke_result.status)
    primal_status_allows_candidate =
        _reduced_dcdfba_mpcc_primal_status_allows_residual_candidate(smoke_result.primal_status)
    residual_feasible_candidate =
        residuals_available && residual_thresholds_satisfied && primal_status_allows_candidate
    trajectory_extraction_ready = status_allows_candidate && residual_feasible_candidate
    iteration_limit_residual_feasible =
        smoke_result.status == MOI.ITERATION_LIMIT && residual_feasible_candidate
    warnings = _reduced_dcdfba_mpcc_candidate_warnings(
        summary,
        residuals_available,
        residual_thresholds_satisfied,
        residual_ratios,
        status_allows_candidate,
        residual_feasible_candidate,
        iteration_limit_residual_feasible,
    )
    metadata = _reduced_dcdfba_mpcc_candidate_metadata(
        smoke_result,
        value_source,
        residuals_available,
        residual_thresholds_satisfied,
        ranked_residuals,
        status_allows_candidate,
        primal_status_allows_candidate,
        residual_feasible_candidate,
        trajectory_extraction_ready,
        iteration_limit_residual_feasible,
        warnings,
        summary,
    )

    return ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(candidate_values.state_boundary),
        copy(candidate_values.state_collocation),
        copy(candidate_values.state_derivative),
        copy(candidate_values.flux),
        copy(candidate_values.lower_bound_duals),
        copy(candidate_values.upper_bound_duals),
        copy(candidate_values.mass_balance_duals),
        residual_values,
        residual_thresholds,
        residual_ratios,
        ranked_residuals,
        warnings,
        metadata,
    )
end

function _reduced_dcdfba_mpcc_candidate_metadata(
    candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
)::Dict{String, Any}
    candidate === nothing && return Dict{String, Any}(
        "candidate_extraction_performed" => false,
        "candidate_values_available" => false,
        "candidate_is_scientific_simulation" => false,
        "candidate_trajectory_extraction_ready" => false,
        "candidate_residual_feasible" => false,
        "candidate_iteration_limit_residual_feasible" => false,
        "solved_trajectory_claimed" => false,
    )
    return copy(candidate.metadata)
end

function _reduced_dcdfba_mpcc_candidate_metadata(
    smoke_result::ReducedDCDFBAMPCCSmokeResult,
    value_source::AbstractString,
    residuals_available::Bool,
    residual_thresholds_satisfied::Bool,
    ranked_residuals::Vector{String},
    status_allows_candidate::Bool,
    primal_status_allows_candidate::Bool,
    residual_feasible_candidate::Bool,
    trajectory_extraction_ready::Bool,
    iteration_limit_residual_feasible::Bool,
    warnings::Vector{String},
    summary::Dict{String, Any},
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "candidate_extraction_performed" => true,
        "candidate_values_available" => true,
        "candidate_values_source" => String(value_source),
        "candidate_solver_status" => string(smoke_result.status),
        "candidate_primal_status" => string(smoke_result.primal_status),
        "candidate_status_allows_trajectory_candidate" => status_allows_candidate,
        "candidate_primal_status_allows_residual_candidate" => primal_status_allows_candidate,
        "candidate_residuals_available" => residuals_available,
        "candidate_residual_thresholds_satisfied" => residual_thresholds_satisfied,
        "candidate_residual_feasible" => residual_feasible_candidate,
        "candidate_trajectory_extraction_ready" => trajectory_extraction_ready,
        "candidate_iteration_limit_residual_feasible" => iteration_limit_residual_feasible,
        "candidate_dominant_residual" =>
            isempty(ranked_residuals) ? "unavailable" : first(ranked_residuals),
        "max_lower_complementarity_product" =>
            get(smoke_result.metadata, "max_lower_complementarity_product", NaN),
        "max_upper_complementarity_product" =>
            get(smoke_result.metadata, "max_upper_complementarity_product", NaN),
        "max_complementarity_tau_violation" =>
            get(smoke_result.metadata, "max_complementarity_tau_violation", NaN),
        "max_complementarity_tau_violation_raw" =>
            get(smoke_result.metadata, "max_complementarity_tau_violation_raw", NaN),
        "complementarity_tau_gate_tolerance" =>
            get(smoke_result.metadata, "complementarity_tau_gate_tolerance", missing),
        "complementarity_tau_gate_tolerance_source" =>
            get(smoke_result.metadata, "complementarity_tau_gate_tolerance_source", missing),
        "complementarity_tau_gate_pass" =>
            get(smoke_result.metadata, "complementarity_tau_gate_pass", false),
        "complementarity_mode" =>
            get(smoke_result.metadata, "complementarity_mode", "exact"),
        "complementarity_tau" =>
            get(smoke_result.metadata, "complementarity_tau", missing),
        "complementarity_residual_gate_policy" =>
            _reduced_dcdfba_mpcc_complementarity_residual_gate_policy(smoke_result.metadata),
        "candidate_warning_count" => length(warnings),
        "candidate_warnings" => copy(warnings),
        "candidate_is_scientific_simulation" => false,
        "candidate_is_validated_trajectory" => false,
        "solved_trajectory_claimed" => false,
        "model_scope" => "reduced",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
    merge!(metadata, summary)
    return metadata
end

function _reduced_dcdfba_mpcc_candidate_summary(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate_values,
    ;
    dynamic_control_values = _reduced_dcdfba_mpcc_candidate_dynamic_control_values(candidate_values),
)::Dict{String, Any}
    summary = Dict{String, Any}()
    grid = problem.nlp.kkt_problem.grid
    model = problem.nlp.kkt_problem.model
    summary["candidate_model_id"] = model.model_id
    summary["candidate_grid_tspan"] = grid.tspan
    summary["candidate_grid_nfe"] = grid.nfe
    summary["candidate_collocation_degree"] = grid.scheme.degree
    summary["candidate_boundary_times"] = _reduced_dcdfba_mpcc_boundary_times(grid)
    summary["candidate_collocation_times"] = _reduced_dcdfba_mpcc_collocation_times_vector(grid)
    summary["candidate_state_names"] = copy(DEFAULT_SIMULATION_STATE_NAMES)
    summary["candidate_flux_rxn_ids"] = copy(model.rxn_ids)
    summary["candidate_flux_reaction_count"] = length(model.rxn_ids)
    summary["candidate_contains_r0001_flux"] = has_reaction(model, "r_0001")
    summary["candidate_contains_r1992_flux"] = has_reaction(model, "r_1992")
    summary["candidate_r0001_used_as_oxygen"] = false
    _merge_reduced_dcdfba_candidate_array_summary!(
        summary,
        "candidate_state_boundary",
        candidate_values.state_boundary,
    )
    _merge_reduced_dcdfba_candidate_array_summary!(
        summary,
        "candidate_state_collocation",
        candidate_values.state_collocation,
    )
    _merge_reduced_dcdfba_candidate_array_summary!(
        summary,
        "candidate_state_derivative",
        candidate_values.state_derivative,
    )
    _merge_reduced_dcdfba_candidate_array_summary!(summary, "candidate_flux", candidate_values.flux)
    _merge_reduced_dcdfba_candidate_array_summary!(
        summary,
        "candidate_lower_bound_dual",
        candidate_values.lower_bound_duals,
    )
    _merge_reduced_dcdfba_candidate_array_summary!(
        summary,
        "candidate_upper_bound_dual",
        candidate_values.upper_bound_duals,
    )
    _merge_reduced_dcdfba_candidate_array_summary!(
        summary,
        "candidate_mass_balance_dual",
        candidate_values.mass_balance_duals,
    )
    merge!(
        summary,
        _reduced_dcdfba_mpcc_candidate_dynamic_control_summary(dynamic_control_values),
    )
    merge!(
        summary,
        _reduced_dcdfba_mpcc_candidate_flux_bound_summary(
            problem,
            candidate_values,
            dynamic_control_values = dynamic_control_values,
        ),
    )
    merge!(summary, _reduced_dcdfba_mpcc_candidate_dual_sign_summary(candidate_values))
    merge!(
        summary,
        _reduced_dcdfba_mpcc_candidate_dynamic_residual_summary(
            problem,
            candidate_values,
            dynamic_control_values = dynamic_control_values,
        ),
    )
    return summary
end

function _reduced_dcdfba_mpcc_candidate_dynamic_control_summary(
    dynamic_control_values,
)::Dict{String, Any}
    summary = Dict{String, Any}(
        "candidate_dynamic_control_values_captured" => dynamic_control_values !== nothing,
    )
    dynamic_control_values === nothing && return summary
    summary["candidate_dynamic_control_temperature_C_values"] =
        copy(dynamic_control_values.temperature_C)
    summary["candidate_dynamic_control_fda_g_L_values"] = copy(dynamic_control_values.fda_g_L)
    summary["candidate_dynamic_control_organic_g_L_values"] =
        copy(dynamic_control_values.organic_g_L)
    _merge_reduced_dcdfba_candidate_array_summary!(
        summary,
        "candidate_dynamic_control_temperature_C",
        dynamic_control_values.temperature_C,
    )
    _merge_reduced_dcdfba_candidate_array_summary!(
        summary,
        "candidate_dynamic_control_fda_g_L",
        dynamic_control_values.fda_g_L,
    )
    _merge_reduced_dcdfba_candidate_array_summary!(
        summary,
        "candidate_dynamic_control_organic_g_L",
        dynamic_control_values.organic_g_L,
    )
    return summary
end

function _reduced_dcdfba_mpcc_boundary_times(grid::FiniteElementGrid)::Vector{Float64}
    times = Vector{Float64}(undef, grid.nfe + 1)
    times[1] = Float64(first(grid.element_bounds)[1])
    for e in 1:grid.nfe
        times[e + 1] = Float64(grid.element_bounds[e][2])
    end
    return times
end

function _reduced_dcdfba_mpcc_collocation_times_vector(grid::FiniteElementGrid)::Vector{Float64}
    times = Float64[]
    sizehint!(times, grid.nfe * grid.scheme.degree)
    for e in 1:grid.nfe, j in 1:grid.scheme.degree
        push!(times, Float64(grid.collocation_times[e, j]))
    end
    return times
end

function _merge_reduced_dcdfba_candidate_array_summary!(
    metadata::Dict{String, Any},
    prefix::AbstractString,
    array,
)
    flat = Float64.(vec(array))
    finite_values = [value for value in flat if isfinite(value)]
    metadata["$(prefix)_total_count"] = length(flat)
    metadata["$(prefix)_finite_count"] = length(finite_values)
    metadata["$(prefix)_nonfinite_count"] = length(flat) - length(finite_values)
    if isempty(finite_values)
        metadata["$(prefix)_min"] = NaN
        metadata["$(prefix)_max"] = NaN
        metadata["$(prefix)_abs_max"] = NaN
        metadata["$(prefix)_negative_count"] = 0
    else
        metadata["$(prefix)_min"] = minimum(finite_values)
        metadata["$(prefix)_max"] = maximum(finite_values)
        metadata["$(prefix)_abs_max"] = maximum(abs.(finite_values))
        metadata["$(prefix)_negative_count"] = count(value -> value < -1.0e-8, finite_values)
    end
    return metadata
end

function _reduced_dcdfba_mpcc_candidate_flux_bound_summary(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate_values,
    ;
    dynamic_control_values = _reduced_dcdfba_mpcc_candidate_dynamic_control_values(candidate_values),
)::Dict{String, Any}
    active_tol = 1.0e-8
    violation_tol = 1.0e-8
    flux = candidate_values.flux
    n_reactions, nfe, degree = size(flux)
    max_lower_violation = 0.0
    max_upper_violation = 0.0
    lower_violation_count = 0
    upper_violation_count = 0
    active_lower_count = 0
    active_upper_count = 0
    for e in 1:nfe, j in 1:degree
        bounds = _reduced_dcdfba_numeric_flux_bounds(
            problem,
            e,
            j,
            candidate_values.state_collocation,
            dynamic_control_values = dynamic_control_values,
        )
        lower_violation = max.(bounds.lb .- flux[:, e, j], 0.0)
        upper_violation = max.(flux[:, e, j] .- bounds.ub, 0.0)
        max_lower_violation = max(max_lower_violation, maximum(lower_violation))
        max_upper_violation = max(max_upper_violation, maximum(upper_violation))
        lower_violation_count += count(value -> value > violation_tol, lower_violation)
        upper_violation_count += count(value -> value > violation_tol, upper_violation)
        active_lower_count += count(abs.(flux[:, e, j] .- bounds.lb) .<= active_tol)
        active_upper_count += count(abs.(flux[:, e, j] .- bounds.ub) .<= active_tol)
    end
    return Dict{String, Any}(
        "candidate_flux_bound_check_performed" => true,
        "candidate_flux_bound_total_count" => n_reactions * nfe * degree,
        "candidate_flux_max_lower_bound_violation" => Float64(max_lower_violation),
        "candidate_flux_max_upper_bound_violation" => Float64(max_upper_violation),
        "candidate_flux_lower_bound_violation_count" => lower_violation_count,
        "candidate_flux_upper_bound_violation_count" => upper_violation_count,
        "candidate_flux_active_lower_bound_count" => active_lower_count,
        "candidate_flux_active_upper_bound_count" => active_upper_count,
    )
end

function _reduced_dcdfba_mpcc_candidate_dual_sign_summary(candidate_values)::Dict{String, Any}
    lower_duals = Float64.(vec(candidate_values.lower_bound_duals))
    upper_duals = Float64.(vec(candidate_values.upper_bound_duals))
    return Dict{String, Any}(
        "candidate_lower_bound_dual_positive_count" =>
            count(value -> isfinite(value) && value > 1.0e-8, lower_duals),
        "candidate_upper_bound_dual_negative_count" =>
            count(value -> isfinite(value) && value < -1.0e-8, upper_duals),
    )
end

function _reduced_dcdfba_mpcc_candidate_dynamic_residual_summary(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate_values,
    ;
    dynamic_control_values = _reduced_dcdfba_mpcc_candidate_dynamic_control_values(candidate_values),
)::Dict{String, Any}
    residual_inputs = (
        state_boundary = candidate_values.state_boundary,
        state_collocation = candidate_values.state_collocation,
        state_derivative = candidate_values.state_derivative,
        flux = candidate_values.flux,
        lower_dual = candidate_values.lower_bound_duals,
        upper_dual = candidate_values.upper_bound_duals,
        mass_dual = candidate_values.mass_balance_duals,
    )
    collocation_residuals =
        _reduced_dcdfba_collocation_integration_start_residuals(problem, residual_inputs)
    continuity_residuals = _reduced_dcdfba_continuity_start_residuals(problem, residual_inputs)
    initial_residuals = _reduced_dcdfba_initial_condition_start_residuals(problem, residual_inputs)
    rhs_residuals = problem.rhs_residuals === nothing ? Float64[] :
                    _reduced_dcdfba_rhs_start_residuals(
        problem,
        residual_inputs,
        dynamic_control_values = dynamic_control_values,
    )
    return Dict{String, Any}(
        "candidate_max_collocation_integration_residual" =>
            _reduced_dcdfba_vector_abs_max_or_nan(collocation_residuals),
        "candidate_max_continuity_residual" =>
            _reduced_dcdfba_vector_abs_max_or_nan(continuity_residuals),
        "candidate_max_initial_condition_residual" =>
            _reduced_dcdfba_vector_abs_max_or_nan(initial_residuals),
        "candidate_max_rhs_residual_from_arrays" =>
            isempty(rhs_residuals) ? NaN : _reduced_dcdfba_vector_abs_max_or_nan(rhs_residuals),
    )
end

function _reduced_dcdfba_mpcc_push_top_location_row!(
    rows::Vector{Dict{String, Any}},
    row::Dict{String, Any},
    score_key::AbstractString,
    top_n::Int,
)
    top_n <= 0 && return rows
    score = _reduced_dcdfba_float64_or_nan(get(row, String(score_key), NaN))
    isfinite(score) && score > 0.0 || return rows
    if length(rows) < top_n
        push!(rows, row)
        return rows
    end

    min_index = 1
    min_score = _reduced_dcdfba_float64_or_nan(get(rows[1], String(score_key), NaN))
    for index in 2:length(rows)
        candidate_score =
            _reduced_dcdfba_float64_or_nan(get(rows[index], String(score_key), NaN))
        if !isfinite(min_score) || (isfinite(candidate_score) && candidate_score < min_score)
            min_index = index
            min_score = candidate_score
        end
    end
    if !isfinite(min_score) || score > min_score
        rows[min_index] = row
    end
    return rows
end

"""
    reduced_dcdfba_mpcc_bound_violation_location_rows(problem, candidate; top_n = 50)

Return the largest lower/upper flux-bound violations in a reduced MPCC
candidate. Rows identify the reaction, element, collocation time, flux, bound,
distance to bound, and positive violation magnitude behind the dominant primal
infeasibility.
"""
function reduced_dcdfba_mpcc_bound_violation_location_rows(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics};
    top_n::Int = 50,
)::Vector{Dict{String, Any}}
    top_n <= 0 && return Dict{String, Any}[]
    candidate === nothing && return Dict{String, Any}[]
    dynamic_control_values =
        _reduced_dcdfba_mpcc_candidate_dynamic_control_values_from_metadata(candidate.metadata)
    return _reduced_dcdfba_mpcc_bound_violation_location_rows(
        problem,
        (
            state_collocation = candidate.state_collocation,
            flux = candidate.flux,
        );
        dynamic_control_values = dynamic_control_values,
        top_n = top_n,
    )
end

function _reduced_dcdfba_mpcc_bound_violation_location_rows(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate_values;
    dynamic_control_values = _reduced_dcdfba_mpcc_candidate_dynamic_control_values(candidate_values),
    top_n::Int = 50,
)::Vector{Dict{String, Any}}
    top_n <= 0 && return Dict{String, Any}[]
    grid = problem.nlp.kkt_problem.grid
    model = problem.nlp.kkt_problem.model
    rows = Dict{String, Any}[]
    sizehint!(rows, top_n)
    for element_index in 1:grid.nfe
        element_left_h, element_right_h = element_bounds(grid, element_index)
        for collocation_index in 1:grid.scheme.degree
            bounds = _reduced_dcdfba_numeric_flux_bounds(
                problem,
                element_index,
                collocation_index,
                candidate_values.state_collocation,
                dynamic_control_values = dynamic_control_values,
            )
            time_h = collocation_time(grid, element_index, collocation_index)
            for reaction_index in eachindex(model.rxn_ids)
                flux_value = Float64(
                    candidate_values.flux[reaction_index, element_index, collocation_index],
                )
                lb_value = Float64(bounds.lb[reaction_index])
                ub_value = Float64(bounds.ub[reaction_index])
                lower_distance = flux_value - lb_value
                upper_distance = ub_value - flux_value
                lower_violation = max(lb_value - flux_value, 0.0)
                upper_violation = max(flux_value - ub_value, 0.0)
                _reduced_dcdfba_mpcc_push_top_location_row!(
                    rows,
                    Dict{String, Any}(
                        "residual_type" => "lower_bound_violation",
                        "element_index" => element_index,
                        "collocation_index" => collocation_index,
                        "time_h" => Float64(time_h),
                        "element_left_h" => Float64(element_left_h),
                        "element_right_h" => Float64(element_right_h),
                        "reaction_index" => reaction_index,
                        "reaction_id" => String(model.rxn_ids[reaction_index]),
                        "flux_value" => flux_value,
                        "bound_value" => lb_value,
                        "distance_to_bound" => Float64(lower_distance),
                        "violation" => Float64(lower_violation),
                    ),
                    "violation",
                    top_n,
                )
                _reduced_dcdfba_mpcc_push_top_location_row!(
                    rows,
                    Dict{String, Any}(
                        "residual_type" => "upper_bound_violation",
                        "element_index" => element_index,
                        "collocation_index" => collocation_index,
                        "time_h" => Float64(time_h),
                        "element_left_h" => Float64(element_left_h),
                        "element_right_h" => Float64(element_right_h),
                        "reaction_index" => reaction_index,
                        "reaction_id" => String(model.rxn_ids[reaction_index]),
                        "flux_value" => flux_value,
                        "bound_value" => ub_value,
                        "distance_to_bound" => Float64(upper_distance),
                        "violation" => Float64(upper_violation),
                    ),
                    "violation",
                    top_n,
                )
            end
        end
    end
    sort!(
        rows;
        by = row -> _reduced_dcdfba_float64_or_nan(get(row, "violation", NaN)),
        rev = true,
    )
    return rows
end

function _reduced_dcdfba_mpcc_bound_violation_location_metadata(
    rows::Vector{Dict{String, Any}},
)::Dict{String, Any}
    top = isempty(rows) ? Dict{String, Any}() : rows[1]
    return Dict{String, Any}(
        "bound_violation_location_rows" => rows,
        "bound_violation_location_row_count" => length(rows),
        "top_bound_violation_location" => top,
        "top_bound_violation_location_residual_type" =>
            get(top, "residual_type", "missing"),
        "top_bound_violation_location_reaction_id" =>
            get(top, "reaction_id", "missing"),
        "top_bound_violation_location_element_index" =>
            get(top, "element_index", 0),
        "top_bound_violation_location_collocation_index" =>
            get(top, "collocation_index", 0),
        "top_bound_violation_location_time_h" =>
            _reduced_dcdfba_float64_or_nan(get(top, "time_h", NaN)),
        "top_bound_violation_location_violation" =>
            _reduced_dcdfba_float64_or_nan(get(top, "violation", NaN)),
    )
end

"""
    reduced_dcdfba_mpcc_rhs_residual_location_rows(problem, candidate; top_n = 50)

Return the largest RHS residuals in a reduced MPCC candidate. Rows identify the
state, element, collocation time, state value, derivative value, expected RHS
derivative, signed residual, and absolute residual.
"""
function reduced_dcdfba_mpcc_rhs_residual_location_rows(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics};
    top_n::Int = 50,
)::Vector{Dict{String, Any}}
    top_n <= 0 && return Dict{String, Any}[]
    candidate === nothing && return Dict{String, Any}[]
    problem.rhs_residuals === nothing && return Dict{String, Any}[]
    dynamic_control_values =
        _reduced_dcdfba_mpcc_candidate_dynamic_control_values_from_metadata(candidate.metadata)
    return _reduced_dcdfba_mpcc_rhs_residual_location_rows(
        problem,
        (
            state_collocation = candidate.state_collocation,
            state_derivative = candidate.state_derivative,
            flux = candidate.flux,
        );
        dynamic_control_values = dynamic_control_values,
        top_n = top_n,
    )
end

function _reduced_dcdfba_mpcc_rhs_residual_location_rows(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate_values;
    dynamic_control_values = _reduced_dcdfba_mpcc_candidate_dynamic_control_values(candidate_values),
    top_n::Int = 50,
)::Vector{Dict{String, Any}}
    top_n <= 0 && return Dict{String, Any}[]
    problem.rhs_residuals === nothing && return Dict{String, Any}[]
    grid = problem.nlp.kkt_problem.grid
    rows = Dict{String, Any}[]
    sizehint!(rows, top_n)
    state_names = copy(DEFAULT_SIMULATION_STATE_NAMES)
    for element_index in 1:grid.nfe
        element_left_h, element_right_h = element_bounds(grid, element_index)
        for collocation_index in 1:grid.scheme.degree
            expected = _reduced_dcdfba_mpcc_rhs_expected_vector(
                problem,
                candidate_values.state_collocation,
                candidate_values.flux,
                element_index,
                collocation_index,
                dynamic_control_values = dynamic_control_values,
            )
            time_h = collocation_time(grid, element_index, collocation_index)
            for state_index in eachindex(expected)
                derivative_value = Float64(
                    candidate_values.state_derivative[
                        state_index,
                        element_index,
                        collocation_index,
                    ],
                )
                expected_value = Float64(expected[state_index])
                residual = derivative_value - expected_value
                _reduced_dcdfba_mpcc_push_top_location_row!(
                    rows,
                    Dict{String, Any}(
                        "residual_type" => "rhs",
                        "element_index" => element_index,
                        "collocation_index" => collocation_index,
                        "time_h" => Float64(time_h),
                        "element_left_h" => Float64(element_left_h),
                        "element_right_h" => Float64(element_right_h),
                        "state_index" => state_index,
                        "state_name" =>
                            state_index <= length(state_names) ?
                            String(state_names[state_index]) :
                            "state_$state_index",
                        "state_value" => Float64(
                            candidate_values.state_collocation[
                                state_index,
                                element_index,
                                collocation_index,
                            ],
                        ),
                        "derivative_value" => derivative_value,
                        "expected_derivative_value" => expected_value,
                        "residual" => Float64(residual),
                        "abs_residual" => Float64(abs(residual)),
                    ),
                    "abs_residual",
                    top_n,
                )
            end
        end
    end
    sort!(
        rows;
        by = row -> _reduced_dcdfba_float64_or_nan(get(row, "abs_residual", NaN)),
        rev = true,
    )
    return rows
end

function _reduced_dcdfba_mpcc_rhs_residual_location_metadata(
    rows::Vector{Dict{String, Any}},
)::Dict{String, Any}
    top = isempty(rows) ? Dict{String, Any}() : rows[1]
    return Dict{String, Any}(
        "rhs_residual_location_rows" => rows,
        "rhs_residual_location_row_count" => length(rows),
        "top_rhs_residual_location" => top,
        "top_rhs_residual_location_state_name" =>
            get(top, "state_name", "missing"),
        "top_rhs_residual_location_element_index" =>
            get(top, "element_index", 0),
        "top_rhs_residual_location_collocation_index" =>
            get(top, "collocation_index", 0),
        "top_rhs_residual_location_time_h" =>
            _reduced_dcdfba_float64_or_nan(get(top, "time_h", NaN)),
        "top_rhs_residual_location_abs_residual" =>
            _reduced_dcdfba_float64_or_nan(get(top, "abs_residual", NaN)),
    )
end

"""
    reduced_dcdfba_mpcc_complementarity_location_rows(problem, candidate; top_n = 50)

Return the largest lower/upper bound-complementarity products in a reduced
MPCC candidate. Rows identify the reaction, element, collocation time, flux,
active bound, dual, and product behind the dominant complementarity residuals.
"""
function reduced_dcdfba_mpcc_complementarity_location_rows(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics};
    top_n::Int = 50,
)::Vector{Dict{String, Any}}
    top_n <= 0 && return Dict{String, Any}[]
    candidate === nothing && return Dict{String, Any}[]
    dynamic_control_values =
        _reduced_dcdfba_mpcc_candidate_dynamic_control_values_from_metadata(candidate.metadata)
    return _reduced_dcdfba_mpcc_complementarity_location_rows(
        problem,
        (
            state_collocation = candidate.state_collocation,
            flux = candidate.flux,
            lower_bound_duals = candidate.lower_bound_duals,
            upper_bound_duals = candidate.upper_bound_duals,
        );
        dynamic_control_values = dynamic_control_values,
        top_n = top_n,
    )
end

function _reduced_dcdfba_mpcc_complementarity_location_rows(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    candidate_values;
    dynamic_control_values = _reduced_dcdfba_mpcc_candidate_dynamic_control_values(candidate_values),
    top_n::Int = 50,
)::Vector{Dict{String, Any}}
    top_n <= 0 && return Dict{String, Any}[]
    grid = problem.nlp.kkt_problem.grid
    model = problem.nlp.kkt_problem.model
    rows = Dict{String, Any}[]
    sizehint!(rows, 2 * length(model.rxn_ids) * grid.nfe * grid.scheme.degree)
    for element_index in 1:grid.nfe
        element_left_h, element_right_h = element_bounds(grid, element_index)
        for collocation_index in 1:grid.scheme.degree
            bounds = _reduced_dcdfba_numeric_flux_bounds(
                problem,
                element_index,
                collocation_index,
                candidate_values.state_collocation,
                dynamic_control_values = dynamic_control_values,
            )
            time_h = collocation_time(grid, element_index, collocation_index)
            for reaction_index in eachindex(model.rxn_ids)
                flux_value = Float64(
                    candidate_values.flux[reaction_index, element_index, collocation_index],
                )
                lb_value = Float64(bounds.lb[reaction_index])
                ub_value = Float64(bounds.ub[reaction_index])
                lower_dual_value = Float64(
                    candidate_values.lower_bound_duals[
                        reaction_index,
                        element_index,
                        collocation_index,
                    ],
                )
                upper_dual_value = Float64(
                    candidate_values.upper_bound_duals[
                        reaction_index,
                        element_index,
                        collocation_index,
                    ],
                )
                lower_distance = flux_value - lb_value
                upper_distance = ub_value - flux_value
                lower_product = lower_distance * lower_dual_value
                upper_product = (flux_value - ub_value) * upper_dual_value
                push!(
                    rows,
                    Dict{String, Any}(
                        "residual_type" => "lower_complementarity",
                        "element_index" => element_index,
                        "collocation_index" => collocation_index,
                        "time_h" => Float64(time_h),
                        "element_left_h" => Float64(element_left_h),
                        "element_right_h" => Float64(element_right_h),
                        "reaction_index" => reaction_index,
                        "reaction_id" => String(model.rxn_ids[reaction_index]),
                        "flux_value" => flux_value,
                        "bound_value" => lb_value,
                        "dual_value" => lower_dual_value,
                        "distance_to_bound" => Float64(lower_distance),
                        "bound_violation" => Float64(max(lb_value - flux_value, 0.0)),
                        "product" => Float64(lower_product),
                        "abs_product" => Float64(abs(lower_product)),
                    ),
                )
                push!(
                    rows,
                    Dict{String, Any}(
                        "residual_type" => "upper_complementarity",
                        "element_index" => element_index,
                        "collocation_index" => collocation_index,
                        "time_h" => Float64(time_h),
                        "element_left_h" => Float64(element_left_h),
                        "element_right_h" => Float64(element_right_h),
                        "reaction_index" => reaction_index,
                        "reaction_id" => String(model.rxn_ids[reaction_index]),
                        "flux_value" => flux_value,
                        "bound_value" => ub_value,
                        "dual_value" => upper_dual_value,
                        "distance_to_bound" => Float64(upper_distance),
                        "bound_violation" => Float64(max(flux_value - ub_value, 0.0)),
                        "product" => Float64(upper_product),
                        "abs_product" => Float64(abs(upper_product)),
                    ),
                )
            end
        end
    end
    sort!(
        rows;
        by = row -> _reduced_dcdfba_float64_or_nan(get(row, "abs_product", NaN)),
        rev = true,
    )
    return first(rows, min(top_n, length(rows)))
end

function _reduced_dcdfba_mpcc_complementarity_location_metadata(
    rows::Vector{Dict{String, Any}},
)::Dict{String, Any}
    top = isempty(rows) ? Dict{String, Any}() : rows[1]
    return Dict{String, Any}(
        "complementarity_location_rows" => rows,
        "complementarity_location_row_count" => length(rows),
        "top_complementarity_location" => top,
        "top_complementarity_location_residual_type" =>
            get(top, "residual_type", "missing"),
        "top_complementarity_location_reaction_id" =>
            get(top, "reaction_id", "missing"),
        "top_complementarity_location_element_index" =>
            get(top, "element_index", 0),
        "top_complementarity_location_collocation_index" =>
            get(top, "collocation_index", 0),
        "top_complementarity_location_time_h" =>
            _reduced_dcdfba_float64_or_nan(get(top, "time_h", NaN)),
        "top_complementarity_location_abs_product" =>
            _reduced_dcdfba_float64_or_nan(get(top, "abs_product", NaN)),
    )
end

function _reduced_dcdfba_vector_abs_max_or_nan(values)::Float64
    isempty(values) && return NaN
    return try
        Float64(maximum(abs.(values)))
    catch
        NaN
    end
end

function _reduced_dcdfba_mpcc_candidate_warnings(
    summary::Dict{String, Any},
    residuals_available::Bool,
    residual_thresholds_satisfied::Bool,
    residual_ratios::Dict{String, Float64},
    status_allows_candidate::Bool,
    residual_feasible_candidate::Bool,
    iteration_limit_residual_feasible::Bool,
)::Vector{String}
    warnings = String[]
    residuals_available || push!(warnings, "candidate_residuals_unavailable")
    residual_thresholds_satisfied || push!(warnings, "candidate_residual_thresholds_not_satisfied")
    for key in sort(collect(keys(residual_ratios)))
        ratio = residual_ratios[key]
        if isinf(ratio) || (isfinite(ratio) && ratio > 1.0)
            push!(warnings, "candidate_$(key)_above_threshold")
        elseif isnan(ratio)
            push!(warnings, "candidate_$(key)_ratio_unavailable")
        end
    end
    get(summary, "candidate_state_boundary_nonfinite_count", 0) > 0 &&
        push!(warnings, "candidate_state_boundary_nonfinite")
    get(summary, "candidate_state_collocation_nonfinite_count", 0) > 0 &&
        push!(warnings, "candidate_state_collocation_nonfinite")
    get(summary, "candidate_state_collocation_negative_count", 0) > 0 &&
        push!(warnings, "candidate_state_collocation_negative")
    get(summary, "candidate_flux_nonfinite_count", 0) > 0 &&
        push!(warnings, "candidate_flux_nonfinite")
    get(summary, "candidate_flux_lower_bound_violation_count", 0) > 0 &&
        push!(warnings, "candidate_flux_lower_bound_violations")
    get(summary, "candidate_flux_upper_bound_violation_count", 0) > 0 &&
        push!(warnings, "candidate_flux_upper_bound_violations")
    get(summary, "candidate_lower_bound_dual_positive_count", 0) > 0 &&
        push!(warnings, "candidate_lower_bound_dual_sign_violations")
    get(summary, "candidate_upper_bound_dual_negative_count", 0) > 0 &&
        push!(warnings, "candidate_upper_bound_dual_sign_violations")
    residual_feasible_candidate && !status_allows_candidate &&
        push!(warnings, "candidate_solver_status_blocks_trajectory_extraction")
    iteration_limit_residual_feasible &&
        push!(warnings, "candidate_iteration_limit_residual_feasible")
    return unique(warnings)
end

function _reduced_dcdfba_mpcc_candidate_time_vector(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
    key::String,
)::Vector{Float64}
    value = get(candidate.metadata, key, nothing)
    value isa AbstractVector || throw(
        ArgumentError("Reduced MPCC candidate metadata must include vector $(key)."),
    )
    times = Float64.(value)
    all(isfinite, times) || throw(
        ArgumentError("Reduced MPCC candidate metadata $(key) must contain finite times."),
    )
    return times
end

function _reduced_dcdfba_flatten_candidate_collocation_values(values)::Matrix{Float64}
    n_rows, nfe, degree = size(values)
    flattened = Matrix{Float64}(undef, n_rows, nfe * degree)
    column = 1
    for e in 1:nfe, j in 1:degree
        flattened[:, column] .= values[:, e, j]
        column += 1
    end
    return flattened
end

function _reduced_dcdfba_mpcc_trajectory_candidate_metadata(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
    require_trajectory_ready::Bool,
    trajectory_ready::Bool,
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "problem_type" => "reduced_dcdfba_mpcc_trajectory_candidate",
        "problem_scope" => "guarded_reduced_mpcc_trajectory_candidate_diagnostics",
        "trajectory_candidate_extraction_performed" => true,
        "trajectory_candidate_required_ready_status" => require_trajectory_ready,
        "trajectory_candidate_ready" => trajectory_ready,
        "trajectory_candidate_extracted_despite_not_ready" => !trajectory_ready,
        "trajectory_candidate_is_scientific_simulation" => false,
        "trajectory_candidate_is_validated_simulation" => false,
        "trajectory_candidate_is_validated_trajectory" => false,
        "trajectory_candidate_solved_trajectory_claimed" => false,
        "trajectory_candidate_boundary_result_available" => true,
        "trajectory_candidate_collocation_result_available" => true,
        "trajectory_candidate_boundary_result_has_fluxes" => false,
        "trajectory_candidate_collocation_result_has_fluxes" => false,
        "trajectory_candidate_flux_storage" => "candidate_diagnostics.flux",
        "trajectory_candidate_flux_policy" =>
            "full_reduced_flux_array_kept_in_candidate_diagnostics_not_simulation_result",
        "trajectory_candidate_full_flux_vector_available" => true,
        "trajectory_candidate_flux_export_deferred" => true,
        "trajectory_candidate_flux_export_deferred_reason" =>
            "reduced_model_contains_r_0001_and_export_flux_guard_forbids_r_0001",
        "is_scientific_simulation" => false,
        "is_validated_simulation" => false,
        "solved_trajectory_claimed" => false,
        "model_scope" => "reduced",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "retcode" => get(candidate.metadata, "candidate_solver_status", "unknown"),
        "termination_reason" => (
            trajectory_ready ? "mpcc_candidate_trajectory_ready" :
            "mpcc_candidate_diagnostic_only_solver_status_blocks_trajectory"
        ),
    )
    for (key, value) in candidate.metadata
        metadata[key] = value
    end
    metadata["model_id"] = get(candidate.metadata, "candidate_model_id", missing)
    metadata["state_names"] = get(
        candidate.metadata,
        "candidate_state_names",
        copy(DEFAULT_SIMULATION_STATE_NAMES),
    )
    metadata["mpcc_candidate_flux_rxn_ids"] = get(
        candidate.metadata,
        "candidate_flux_rxn_ids",
        String[],
    )
    metadata["min_state_value"] = minimum(candidate.state_boundary)
    metadata["has_negative_saved_states"] = any(candidate.state_boundary .< 0.0)
    metadata["max_mass_balance_residual"] =
        get(candidate.residual_values, "max_mass_balance_residual", NaN)
    metadata["max_lower_bound_violation"] =
        get(candidate.residual_values, "max_lower_bound_violation", NaN)
    metadata["max_upper_bound_violation"] =
        get(candidate.residual_values, "max_upper_bound_violation", NaN)
    metadata["max_rhs_residual"] = get(candidate.residual_values, "max_rhs_residual", NaN)
    metadata["max_stationarity_residual"] =
        get(candidate.residual_values, "max_stationarity_residual", NaN)
    metadata["max_lower_complementarity_residual"] =
        get(candidate.residual_values, "max_lower_complementarity_residual", NaN)
    metadata["max_upper_complementarity_residual"] =
        get(candidate.residual_values, "max_upper_complementarity_residual", NaN)
    return metadata
end

function _reduced_dcdfba_mpcc_start_residual_values(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)::Dict{String, Float64}
    state_boundary_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_boundary)
    state_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    derivative_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_derivative)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)

    if any(
        value -> value === nothing,
        (
            state_boundary_values,
            state_values,
            derivative_values,
            flux_values,
            lower_dual_values,
            upper_dual_values,
            mass_dual_values,
        ),
    )
        return _reduced_dcdfba_mpcc_nan_residual_values()
    end

    starts = (
        state_boundary = state_boundary_values,
        state_collocation = state_values,
        state_derivative = derivative_values,
        flux = flux_values,
        lower_dual = lower_dual_values,
        upper_dual = upper_dual_values,
        mass_dual = mass_dual_values,
    )
    diagnostics = _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )
    rhs_residual = problem.rhs_residuals === nothing ? NaN :
                   _reduced_dcdfba_mpcc_rhs_residual_from_values(
        problem,
        state_values,
        derivative_values,
        flux_values,
    )
    return Dict{String, Float64}(
        "max_rhs_residual" => rhs_residual,
        "max_collocation_integration_residual" => _reduced_dcdfba_abs_max_or_nan(
            _reduced_dcdfba_collocation_integration_start_residuals(problem, starts),
        ),
        "max_continuity_residual" => _reduced_dcdfba_abs_max_or_nan(
            _reduced_dcdfba_continuity_start_residuals(problem, starts),
        ),
        "max_initial_condition_residual" => _reduced_dcdfba_abs_max_or_nan(
            _reduced_dcdfba_initial_condition_start_residuals(problem, starts),
        ),
        "max_mass_balance_residual" => diagnostics.max_mass_balance_residual,
        "max_lower_bound_violation" => diagnostics.max_lower_bound_violation,
        "max_upper_bound_violation" => diagnostics.max_upper_bound_violation,
        "max_stationarity_residual" => diagnostics.max_stationarity_residual,
        "max_lower_complementarity_residual" => diagnostics.max_lower_complementarity_residual,
        "max_upper_complementarity_residual" => diagnostics.max_upper_complementarity_residual,
    )
end

function _reduced_dcdfba_mpcc_result_residual_values(
    result::ReducedDCDFBAMPCCSolveAttemptResult,
)::Dict{String, Float64}
    return Dict{String, Float64}(
        "max_rhs_residual" =>
            _reduced_dcdfba_float64_or_nan(get(result.residual_report, "max_rhs_residual", NaN)),
        "max_collocation_integration_residual" => _reduced_dcdfba_float64_or_nan(
            get(result.residual_report, "max_collocation_integration_residual", NaN),
        ),
        "max_continuity_residual" =>
            _reduced_dcdfba_float64_or_nan(get(result.residual_report, "max_continuity_residual", NaN)),
        "max_initial_condition_residual" => _reduced_dcdfba_float64_or_nan(
            get(result.residual_report, "max_initial_condition_residual", NaN),
        ),
        "max_mass_balance_residual" => result.smoke_result.max_mass_balance_residual,
        "max_lower_bound_violation" => result.smoke_result.max_lower_bound_violation,
        "max_upper_bound_violation" => result.smoke_result.max_upper_bound_violation,
        "max_stationarity_residual" => result.smoke_result.max_stationarity_residual,
        "max_lower_complementarity_residual" =>
            result.smoke_result.max_lower_complementarity_residual,
        "max_upper_complementarity_residual" =>
            result.smoke_result.max_upper_complementarity_residual,
    )
end

function _reduced_dcdfba_mpcc_nan_residual_values()::Dict{String, Float64}
    return Dict{String, Float64}(
        "max_rhs_residual" => NaN,
        "max_collocation_integration_residual" => NaN,
        "max_continuity_residual" => NaN,
        "max_initial_condition_residual" => NaN,
        "max_mass_balance_residual" => NaN,
        "max_lower_bound_violation" => NaN,
        "max_upper_bound_violation" => NaN,
        "max_stationarity_residual" => NaN,
        "max_lower_complementarity_residual" => NaN,
        "max_upper_complementarity_residual" => NaN,
    )
end

function _reduced_dcdfba_mpcc_threshold_values(
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
)::Dict{String, Float64}
    return Dict{String, Float64}(
        "max_rhs_residual" => thresholds.max_rhs_residual,
        "max_collocation_integration_residual" => thresholds.max_rhs_residual,
        "max_continuity_residual" => thresholds.max_rhs_residual,
        "max_initial_condition_residual" => thresholds.max_rhs_residual,
        "max_mass_balance_residual" => thresholds.max_mass_balance_residual,
        "max_lower_bound_violation" => thresholds.max_lower_bound_violation,
        "max_upper_bound_violation" => thresholds.max_upper_bound_violation,
        "max_stationarity_residual" => thresholds.max_stationarity_residual,
        "max_lower_complementarity_residual" => thresholds.max_lower_complementarity_residual,
        "max_upper_complementarity_residual" => thresholds.max_upper_complementarity_residual,
    )
end

function _reduced_dcdfba_mpcc_effective_threshold_values(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
)::Dict{String, Float64}
    return _reduced_dcdfba_mpcc_effective_threshold_values(
        problem.metadata,
        thresholds,
    )
end

function _reduced_dcdfba_mpcc_effective_threshold_values(
    metadata::Dict,
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
)::Dict{String, Float64}
    values = _reduced_dcdfba_mpcc_threshold_values(thresholds)
    String(
        get(
            metadata,
            "complementarity_mode",
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_EXACT,
        ),
    ) == REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES || return values

    tau = _reduced_dcdfba_float64_or_nan(
        get(
            metadata,
            "complementarity_tau",
            REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU,
        ),
    )
    gate_tolerance =
        _reduced_dcdfba_mpcc_complementarity_tau_gate_tolerance(metadata, tau)
    effective_threshold = tau + gate_tolerance.tolerance
    if isfinite(effective_threshold) && effective_threshold >= 0.0
        values["max_lower_complementarity_residual"] = effective_threshold
        values["max_upper_complementarity_residual"] = effective_threshold
    end
    return values
end

function _reduced_dcdfba_mpcc_complementarity_residual_gate_policy(
    metadata::Dict,
)::String
    mode = String(
        get(
            metadata,
            "complementarity_mode",
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_EXACT,
        ),
    )
    return mode == REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES ?
           "scholtes_product_threshold_tau_plus_gate_tolerance" :
           "exact_product_threshold_from_residual_thresholds"
end

function _reduced_dcdfba_mpcc_residual_ratios(
    residuals::Dict{String, Float64},
    thresholds::Dict{String, Float64},
)::Dict{String, Float64}
    ratios = Dict{String, Float64}()
    for key in keys(residuals)
        residual = residuals[key]
        threshold = thresholds[key]
        ratios[key] = !isfinite(residual) ? NaN :
                      threshold == 0.0 ? (residual == 0.0 ? 0.0 : Inf) :
                      abs(residual) / threshold
    end
    return ratios
end

function _reduced_dcdfba_mpcc_ranked_residuals(
    ratios::Dict{String, Float64},
)::Vector{String}
    return sort(
        collect(keys(ratios));
        by = key -> isnan(ratios[key]) ? -Inf : ratios[key],
        rev = true,
    )
end

function _reduced_dcdfba_mpcc_start_scaling_summary(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)::Dict{String, Float64}
    state_boundary_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_boundary)
    state_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    derivative_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_derivative)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)

    dynamic_bounds = problem.dynamic_bounds
    return Dict{String, Float64}(
        "state_boundary_start_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(state_boundary_values),
        "state_collocation_start_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(state_values),
        "state_derivative_start_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(derivative_values),
        "flux_start_abs_max" => _reduced_dcdfba_abs_max_or_nan(flux_values),
        "lower_bound_dual_start_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(lower_dual_values),
        "upper_bound_dual_start_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(upper_dual_values),
        "mass_balance_dual_start_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(mass_dual_values),
        "objective_coefficient_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(problem.stationarity.objective_coefficients),
        "base_lower_bound_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(problem.nlp.kkt_problem.model.lb),
        "base_upper_bound_abs_max" =>
            _reduced_dcdfba_abs_max_or_nan(problem.nlp.kkt_problem.model.ub),
        "state_collocation_positive_scale_spread" =>
            _reduced_dcdfba_positive_scale_spread(state_values),
        "flux_start_positive_scale_spread" =>
            _reduced_dcdfba_positive_scale_spread(flux_values),
        "dynamic_lower_bound_reaction_count" =>
            dynamic_bounds === nothing ? 0.0 : Float64(length(dynamic_bounds.lower_bound_reaction_indices)),
        "dynamic_upper_bound_reaction_count" =>
            dynamic_bounds === nothing ? 0.0 : Float64(length(dynamic_bounds.upper_bound_reaction_indices)),
        "dynamic_objective_reaction_count" =>
            dynamic_bounds === nothing ? 0.0 : Float64(length(dynamic_bounds.objective_reaction_indices)),
        "dynamic_flux_lp_start_collocation_points" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "dynamic_flux_lp_start_collocation_points", 0.0),
            ),
        "dynamic_flux_lp_start_optimal_count" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "dynamic_flux_lp_start_optimal_count", 0.0),
            ),
        "dynamic_flux_lp_start_max_mass_balance_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "dynamic_flux_lp_start_max_mass_balance_residual", 0.0),
            ),
        "dynamic_flux_lp_start_max_lower_bound_violation" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "dynamic_flux_lp_start_max_lower_bound_violation", 0.0),
            ),
        "dynamic_flux_lp_start_max_upper_bound_violation" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "dynamic_flux_lp_start_max_upper_bound_violation", 0.0),
            ),
        "dynamic_flux_lp_start_max_adjustment_from_previous" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "dynamic_flux_lp_start_max_adjustment_from_previous", 0.0),
            ),
        "dynamic_flux_start_projection_changed_count" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "dynamic_flux_start_projection_changed_count", 0.0),
            ),
        "dynamic_flux_start_projection_max_adjustment" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "dynamic_flux_start_projection_max_adjustment", 0.0),
            ),
        "dynamic_flux_start_projection_max_lower_bound_violation_before" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "dynamic_flux_start_projection_max_lower_bound_violation_before",
                    0.0,
                ),
            ),
        "dynamic_flux_start_projection_max_upper_bound_violation_before" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "dynamic_flux_start_projection_max_upper_bound_violation_before",
                    0.0,
                ),
            ),
        "stationarity_dual_start_collocation_points" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_collocation_points", 0.0),
            ),
        "stationarity_dual_start_optimal_count" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_optimal_count", 0.0),
            ),
        "stationarity_dual_start_max_stationarity_residual_before" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_max_stationarity_residual_before", NaN),
            ),
        "stationarity_dual_start_max_stationarity_residual_after" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_max_stationarity_residual_after", NaN),
            ),
        "stationarity_dual_start_max_lower_complementarity_residual_after" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "stationarity_dual_start_max_lower_complementarity_residual_after",
                    NaN,
                ),
            ),
        "stationarity_dual_start_max_upper_complementarity_residual_after" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "stationarity_dual_start_max_upper_complementarity_residual_after",
                    NaN,
                ),
            ),
        "stationarity_dual_start_max_mass_balance_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_max_mass_balance_residual", 0.0),
            ),
        "stationarity_dual_start_max_lower_bound_violation" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_max_lower_bound_violation", 0.0),
            ),
        "stationarity_dual_start_max_upper_bound_violation" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_max_upper_bound_violation", 0.0),
            ),
        "stationarity_dual_start_max_flux_adjustment_from_previous" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_max_flux_adjustment_from_previous", 0.0),
            ),
        "stationarity_dual_start_mass_balance_dual_abs_max" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_mass_balance_dual_abs_max", NaN),
            ),
        "stationarity_dual_start_lower_bound_dual_abs_max" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_lower_bound_dual_abs_max", NaN),
            ),
        "stationarity_dual_start_upper_bound_dual_abs_max" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_upper_bound_dual_abs_max", NaN),
            ),
        "stationarity_dual_start_max_dual_sign_clipping" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "stationarity_dual_start_max_dual_sign_clipping", 0.0),
            ),
        "rhs_consistent_derivative_start_collocation_points" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "rhs_consistent_derivative_start_collocation_points", 0.0),
            ),
        "rhs_consistent_derivative_start_max_adjustment" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "rhs_consistent_derivative_start_max_adjustment", 0.0),
            ),
        "rhs_consistent_derivative_start_max_abs_value" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "rhs_consistent_derivative_start_max_abs_value", 0.0),
            ),
        "rhs_consistent_derivative_start_max_rhs_residual_after" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "rhs_consistent_derivative_start_max_rhs_residual_after", NaN),
            ),
        "collocation_consistent_state_start_iterations" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_iterations", 0.0),
            ),
        "collocation_consistent_state_start_max_iterations" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_max_iterations", 0.0),
            ),
        "collocation_consistent_state_start_converged" =>
            get(problem.metadata, "collocation_consistent_state_start_converged", true) === true ? 1.0 :
            0.0,
        "collocation_consistent_state_start_initial_collocation_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_initial_collocation_residual",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_initial_continuity_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_initial_continuity_residual",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_initial_rhs_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_initial_rhs_residual",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_final_collocation_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_final_collocation_residual",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_final_continuity_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_final_continuity_residual",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_final_rhs_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_final_rhs_residual",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_max_state_collocation_adjustment" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_max_state_collocation_adjustment",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_max_state_boundary_adjustment" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_max_state_boundary_adjustment",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_initial_max_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_initial_max_residual", 0.0),
            ),
        "collocation_consistent_state_start_final_max_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_final_max_residual", 0.0),
            ),
        "collocation_consistent_state_start_last_residual_improvement" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_last_residual_improvement",
                    NaN,
                ),
            ),
        "collocation_consistent_state_start_restore_best_enabled" =>
            get(problem.metadata, "collocation_consistent_state_start_restore_best_enabled", true) ===
            true ? 1.0 : 0.0,
        "collocation_consistent_state_start_monotone_enabled" =>
            get(problem.metadata, "collocation_consistent_state_start_monotone_enabled", true) ===
            true ? 1.0 : 0.0,
        "collocation_consistent_state_start_trace_substeps_enabled" =>
            get(problem.metadata, "collocation_consistent_state_start_trace_substeps_enabled", false) ===
            true ? 1.0 : 0.0,
        "collocation_consistent_state_start_final_state_refresh_enabled" =>
            get(problem.metadata, "collocation_consistent_state_start_final_state_refresh_enabled", false) ===
            true ? 1.0 : 0.0,
        "collocation_consistent_state_start_final_flux_projection_enabled" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_flux_projection_enabled",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_final_dual_fit_enabled" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_final_dual_fit_enabled",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_flux_refresh_guard_enabled" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_flux_refresh_guard_enabled",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_flux_refresh_guard_accepted" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_flux_refresh_guard_accepted",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_flux_refresh_guard_before_score" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_flux_refresh_guard_before_score",
                    NaN,
                ),
            ),
        "collocation_consistent_state_start_flux_refresh_guard_after_score" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_flux_refresh_guard_after_score",
                    NaN,
                ),
            ),
        "collocation_consistent_state_start_flux_refresh_guard_restored_score" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_flux_refresh_guard_restored_score",
                    NaN,
                ),
            ),
        "collocation_consistent_state_start_flux_refresh_max_iterations" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_flux_refresh_max_iterations",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_monotone_acceptance_tolerance" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_monotone_acceptance_tolerance",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_trial_count" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_trial_count", 0.0),
            ),
        "collocation_consistent_state_start_rejected_trial_count" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_rejected_trial_count", 0.0),
            ),
        "collocation_consistent_state_start_last_accepted_damping_factor" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_last_accepted_damping_factor",
                    NaN,
                ),
            ),
        "collocation_consistent_state_start_min_accepted_damping_factor" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_min_accepted_damping_factor",
                    NaN,
                ),
            ),
        "collocation_consistent_state_start_last_rejected_damping_factor" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_last_rejected_damping_factor",
                    NaN,
                ),
            ),
        "collocation_consistent_state_start_last_rejected_max_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_last_rejected_max_residual",
                    NaN,
                ),
            ),
        "collocation_consistent_state_start_stopped_by_monotone_guard" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_stopped_by_monotone_guard",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_last_final_state_refresh_applied" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_last_final_state_refresh_applied",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_last_final_flux_projection_applied" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_last_final_flux_projection_applied",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_last_final_dual_fit_applied" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_last_final_dual_fit_applied",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_last_dynamic_flux_refresh_applied" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_last_dynamic_flux_refresh_applied",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_last_final_state_collocation_adjustment" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_last_final_state_collocation_adjustment",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_last_final_state_boundary_adjustment" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_last_final_state_boundary_adjustment",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_best_iteration" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_best_iteration", 0.0),
            ),
        "collocation_consistent_state_start_best_max_residual" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_best_max_residual", 0.0),
            ),
        "collocation_consistent_state_start_restored_best_iteration" =>
            get(problem.metadata, "collocation_consistent_state_start_restored_best_iteration", false) ===
            true ? 1.0 : 0.0,
        "collocation_consistent_state_start_restore_best_improvement" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_restore_best_improvement",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_stagnation_tolerance" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_stagnation_tolerance", 0.0),
            ),
        "collocation_consistent_state_start_stagnation_iterations" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_stagnation_iterations", 0.0),
            ),
        "collocation_consistent_state_start_stagnation_counter" =>
            _reduced_dcdfba_float64_or_nan(
                get(problem.metadata, "collocation_consistent_state_start_stagnation_counter", 0.0),
            ),
        "collocation_consistent_state_start_stopped_by_stagnation" =>
            get(
                problem.metadata,
                "collocation_consistent_state_start_stopped_by_stagnation",
                false,
            ) === true ? 1.0 : 0.0,
        "collocation_consistent_state_start_last_dynamic_flux_lp_attempt_count" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_last_dynamic_flux_lp_attempt_count",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_last_dynamic_flux_lp_total_solve_elapsed_seconds" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_last_dynamic_flux_lp_total_solve_elapsed_seconds",
                    0.0,
                ),
            ),
        "collocation_consistent_state_start_last_dynamic_flux_lp_max_solve_elapsed_seconds" =>
            _reduced_dcdfba_float64_or_nan(
                get(
                    problem.metadata,
                    "collocation_consistent_state_start_last_dynamic_flux_lp_max_solve_elapsed_seconds",
                    0.0,
                ),
            ),
    )
end

function _validate_reduced_dcdfba_mpcc_scaling_parameters(
    target_abs_max::Real,
    min_scale::Real,
    max_scale::Real,
)::Tuple{Float64, Float64, Float64}
    target = Float64(target_abs_max)
    min_factor = Float64(min_scale)
    max_factor = Float64(max_scale)
    isfinite(target) && target > 0.0 || throw(
        ArgumentError("Reduced DC-dFBA MPCC scaling target_abs_max must be finite and positive."),
    )
    isfinite(min_factor) && min_factor > 0.0 || throw(
        ArgumentError("Reduced DC-dFBA MPCC scaling min_scale must be finite and positive."),
    )
    isfinite(max_factor) && max_factor >= min_factor || throw(
        ArgumentError("Reduced DC-dFBA MPCC scaling max_scale must be finite and >= min_scale."),
    )
    return target, min_factor, max_factor
end

function _reduced_dcdfba_mpcc_scaling_start_values(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)
    state_boundary = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_boundary)
    state_collocation = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    state_derivative = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_derivative)
    flux = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual = _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual = _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual = _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)
    any(
        value -> value === nothing,
        (state_boundary, state_collocation, state_derivative, flux, lower_dual, upper_dual, mass_dual),
    ) && throw(
        ArgumentError("Reduced DC-dFBA MPCC scaling plan requires complete finite start values."),
    )
    return (
        state_boundary = state_boundary,
        state_collocation = state_collocation,
        state_derivative = state_derivative,
        flux = flux,
        lower_dual = lower_dual,
        upper_dual = upper_dual,
        mass_dual = mass_dual,
    )
end

function _reduced_dcdfba_mpcc_variable_scale_blocks(
    starts,
    target_abs_max::Float64,
    min_scale::Float64,
    max_scale::Float64,
)::Dict{String, ReducedDCDFBAMPCCScaleBlock}
    return Dict{String, ReducedDCDFBAMPCCScaleBlock}(
        "state_boundary" => _reduced_dcdfba_mpcc_scale_block(
            "state_boundary",
            starts.state_boundary,
            target_abs_max,
            min_scale,
            max_scale,
        ),
        "state_collocation" => _reduced_dcdfba_mpcc_scale_block(
            "state_collocation",
            starts.state_collocation,
            target_abs_max,
            min_scale,
            max_scale,
        ),
        "state_derivative" => _reduced_dcdfba_mpcc_scale_block(
            "state_derivative",
            starts.state_derivative,
            target_abs_max,
            min_scale,
            max_scale,
        ),
        "flux" => _reduced_dcdfba_mpcc_scale_block(
            "flux",
            starts.flux,
            target_abs_max,
            min_scale,
            max_scale,
        ),
        "mass_balance_dual" => _reduced_dcdfba_mpcc_scale_block(
            "mass_balance_dual",
            starts.mass_dual,
            target_abs_max,
            min_scale,
            max_scale,
        ),
        "lower_bound_dual" => _reduced_dcdfba_mpcc_scale_block(
            "lower_bound_dual",
            starts.lower_dual,
            target_abs_max,
            min_scale,
            max_scale,
        ),
        "upper_bound_dual" => _reduced_dcdfba_mpcc_scale_block(
            "upper_bound_dual",
            starts.upper_dual,
            target_abs_max,
            min_scale,
            max_scale,
        ),
    )
end

function _reduced_dcdfba_mpcc_constraint_scale_blocks(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    starts,
    target_abs_max::Float64,
    min_scale::Float64,
    max_scale::Float64,
)::Dict{String, ReducedDCDFBAMPCCScaleBlock}
    values = _reduced_dcdfba_mpcc_constraint_start_values(problem, starts)
    return Dict{String, ReducedDCDFBAMPCCScaleBlock}(
        name => _reduced_dcdfba_mpcc_scale_block(
            name,
            block_values,
            target_abs_max,
            min_scale,
            max_scale,
        ) for (name, block_values) in values
    )
end

function _reduced_dcdfba_mpcc_scale_block(
    name::AbstractString,
    values,
    target_abs_max::Float64,
    min_scale::Float64,
    max_scale::Float64,
)::ReducedDCDFBAMPCCScaleBlock
    flat_values = vec(Float64.(values))
    abs_values = abs.(flat_values)
    abs_max = isempty(abs_values) ? 0.0 : maximum(abs_values)
    positive_values = abs_values[abs_values .> 0.0]
    positive_abs_min = isempty(positive_values) ? 0.0 : minimum(positive_values)
    positive_abs_max = isempty(positive_values) ? 0.0 : maximum(positive_values)
    positive_scale_spread =
        positive_abs_min == 0.0 ? 0.0 : positive_abs_max / positive_abs_min
    recommended_scale =
        abs_max == 0.0 ? 1.0 : clamp(target_abs_max / abs_max, min_scale, max_scale)
    return ReducedDCDFBAMPCCScaleBlock(
        String(name),
        Float64(abs_max),
        Float64(positive_abs_min),
        Float64(positive_abs_max),
        Float64(positive_scale_spread),
        Float64(recommended_scale),
        Float64(abs_max * recommended_scale),
        length(abs_values),
        count(value -> value > 0.0, abs_values),
    )
end

function _reduced_dcdfba_mpcc_constraint_start_values(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    starts,
)::Dict{String, Vector{Float64}}
    values = Dict{String, Vector{Float64}}(
        "collocation_integration" =>
            _reduced_dcdfba_collocation_integration_start_residuals(problem, starts),
        "continuity" =>
            _reduced_dcdfba_continuity_start_residuals(problem, starts),
        "initial_condition" =>
            _reduced_dcdfba_initial_condition_start_residuals(problem, starts),
    )
    if problem.rhs_residuals !== nothing
        values["rhs"] = _reduced_dcdfba_rhs_start_residuals(problem, starts)
    end

    fba_values = _reduced_dcdfba_fba_kkt_start_residual_blocks(problem, starts)
    for (name, block_values) in fba_values
        values[name] = block_values
    end
    return values
end

function _reduced_dcdfba_collocation_integration_start_residuals(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    starts,
)::Vector{Float64}
    grid = problem.nlp.kkt_problem.grid
    integration_matrix = grid.scheme.integration_matrix
    n_states = problem.nlp.dimensions.n_states
    values = Float64[]
    sizehint!(values, n_states * grid.nfe * grid.scheme.degree)
    for e in 1:grid.nfe
        h = element_length(grid, e)
        for i in 1:n_states, j in 1:grid.scheme.degree
            residual =
                starts.state_collocation[i, e, j] -
                (
                    starts.state_boundary[i, e] +
                    h * sum(
                        integration_matrix[j, k] * starts.state_derivative[i, e, k] for
                        k in 1:grid.scheme.degree
                    )
                )
            push!(values, residual)
        end
    end
    return values
end

function _reduced_dcdfba_continuity_start_residuals(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    starts,
)::Vector{Float64}
    grid = problem.nlp.kkt_problem.grid
    continuity_weights = grid.scheme.continuity_weights
    n_states = problem.nlp.dimensions.n_states
    values = Float64[]
    sizehint!(values, n_states * grid.nfe)
    for e in 1:grid.nfe
        h = element_length(grid, e)
        for i in 1:n_states
            residual =
                starts.state_boundary[i, e + 1] -
                (
                    starts.state_boundary[i, e] +
                    h * sum(
                        continuity_weights[k] * starts.state_derivative[i, e, k] for
                        k in 1:grid.scheme.degree
                    )
                )
            push!(values, residual)
        end
    end
    return values
end

function _reduced_dcdfba_initial_condition_start_residuals(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    starts,
)::Vector{Float64}
    return Float64.(starts.state_boundary[:, 1] .- problem.nlp.initial_state)
end

function _reduced_dcdfba_rhs_start_residuals(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    starts,
    ;
    dynamic_control_values = nothing,
)::Vector{Float64}
    values = Float64[]
    n_states = problem.nlp.dimensions.n_states
    nfe = problem.nlp.dimensions.nfe
    degree = problem.nlp.dimensions.collocation_degree
    sizehint!(values, n_states * nfe * degree)
    for e in 1:nfe, j in 1:degree
        expected = _reduced_dcdfba_mpcc_rhs_expected_vector(
            problem,
            starts.state_collocation,
            starts.flux,
            e,
            j,
            dynamic_control_values = dynamic_control_values,
        )
        append!(values, starts.state_derivative[:, e, j] .- expected)
    end
    return values
end

function _reduced_dcdfba_fba_kkt_start_residual_blocks(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    starts,
)::Dict{String, Vector{Float64}}
    model = problem.nlp.kkt_problem.model
    n_reactions = problem.nlp.dimensions.n_reactions
    nfe = problem.nlp.dimensions.nfe
    degree = problem.nlp.dimensions.collocation_degree

    values = Dict{String, Vector{Float64}}(
        "mass_balance" => Float64[],
        "lower_bound" => Float64[],
        "upper_bound" => Float64[],
        "stationarity" => Float64[],
        "lower_complementarity" => Float64[],
        "upper_complementarity" => Float64[],
    )
    sizehint!(values["mass_balance"], size(model.S, 1) * nfe * degree)
    for name in ("lower_bound", "upper_bound", "stationarity", "lower_complementarity", "upper_complementarity")
        sizehint!(values[name], n_reactions * nfe * degree)
    end

    for e in 1:nfe, j in 1:degree
        flux = starts.flux[:, e, j]
        lower_dual = starts.lower_dual[:, e, j]
        upper_dual = starts.upper_dual[:, e, j]
        mass_dual = starts.mass_dual[:, e, j]
        bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, starts.state_collocation)
        coefficients =
            _reduced_dcdfba_numeric_stationarity_coefficients(problem, e, j, starts.state_collocation)

        append!(values["mass_balance"], model.S * flux)
        append!(values["lower_bound"], bounds.lb .- flux)
        append!(values["upper_bound"], flux .- bounds.ub)
        append!(
            values["stationarity"],
            coefficients .+ transpose(model.S) * mass_dual .+ lower_dual .+ upper_dual,
        )
        append!(values["lower_complementarity"], (flux .- bounds.lb) .* lower_dual)
        append!(values["upper_complementarity"], (flux .- bounds.ub) .* upper_dual)
    end
    return values
end

function _reduced_dcdfba_mpcc_scaling_plan_warnings(
    variable_blocks::Dict{String, ReducedDCDFBAMPCCScaleBlock},
    constraint_blocks::Dict{String, ReducedDCDFBAMPCCScaleBlock},
)::Vector{String}
    warnings = String[]
    get(variable_blocks, "flux", nothing) !== nothing &&
        variable_blocks["flux"].positive_scale_spread > 1.0e6 &&
        push!(warnings, "scaling_plan_flux_variable_positive_scale_spread_large")
    get(variable_blocks, "state_collocation", nothing) !== nothing &&
        variable_blocks["state_collocation"].positive_scale_spread > 1.0e6 &&
        push!(warnings, "scaling_plan_state_collocation_positive_scale_spread_large")
    get(constraint_blocks, "collocation_integration", nothing) !== nothing &&
        constraint_blocks["collocation_integration"].abs_max > 1.0e-6 &&
        push!(warnings, "collocation_integration_start_residual_large")
    get(constraint_blocks, "continuity", nothing) !== nothing &&
        constraint_blocks["continuity"].abs_max > 1.0e-6 &&
        push!(warnings, "continuity_start_residual_large")
    get(constraint_blocks, "initial_condition", nothing) !== nothing &&
        constraint_blocks["initial_condition"].abs_max > 1.0e-8 &&
        push!(warnings, "initial_condition_start_residual_large")
    return unique(warnings)
end

function _reduced_dcdfba_mpcc_scaling_plan_metadata(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    target_abs_max::Float64,
    min_scale::Float64,
    max_scale::Float64,
    variable_blocks::Dict{String, ReducedDCDFBAMPCCScaleBlock},
    constraint_blocks::Dict{String, ReducedDCDFBAMPCCScaleBlock},
    warnings::Vector{String},
)::Dict{String, Any}
    variable_scales = [block.recommended_scale for block in values(variable_blocks)]
    constraint_scales = [block.recommended_scale for block in values(constraint_blocks)]
    blocking_warnings = _reduced_dcdfba_mpcc_scaling_plan_blocking_warnings(warnings)
    review_warnings = _reduced_dcdfba_mpcc_scaling_plan_review_warnings(warnings)
    return Dict{String, Any}(
        "problem_type" => "reduced_dcdfba_mpcc_scaling_plan",
        "problem_scope" => "pre_solve_reduced_mpcc_scaling_diagnostics",
        "model_scope" => "reduced",
        "model_id" => problem.nlp.kkt_problem.model.model_id,
        "scaling_plan_built" => true,
        "scaling_plan_mutates_model" => false,
        "scaling_plan_calls_solver" => false,
        "solver_call_performed" => false,
        "ipopt_user_scaling_applied" => false,
        "hsl_required" => false,
        "ma57_required" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "scaling_target_abs_max" => target_abs_max,
        "scaling_min_scale" => min_scale,
        "scaling_max_scale" => max_scale,
        "scaling_variable_block_count" => length(variable_blocks),
        "scaling_constraint_block_count" => length(constraint_blocks),
        "scaling_warning_count" => length(warnings),
        "scaling_blocking_warning_count" => length(blocking_warnings),
        "scaling_review_warning_count" => length(review_warnings),
        "scaling_blocking_warnings" => blocking_warnings,
        "scaling_review_warnings" => review_warnings,
        "scaling_positive_scale_spread_warning_policy" =>
            "review_only_after_block_scale_factors",
        "scaling_min_variable_scale" => minimum(variable_scales),
        "scaling_max_variable_scale" => maximum(variable_scales),
        "scaling_min_constraint_scale" => minimum(constraint_scales),
        "scaling_max_constraint_scale" => maximum(constraint_scales),
        "scaling_flux_variable_recommended_scale" =>
            variable_blocks["flux"].recommended_scale,
        "scaling_flux_variable_positive_scale_spread" =>
            variable_blocks["flux"].positive_scale_spread,
        "scaling_collocation_integration_abs_max" =>
            constraint_blocks["collocation_integration"].abs_max,
        "scaling_continuity_abs_max" => constraint_blocks["continuity"].abs_max,
        "scaling_initial_condition_abs_max" =>
            constraint_blocks["initial_condition"].abs_max,
        "scaling_plan_ready_for_guarded_solve_attempt" => isempty(blocking_warnings),
        "scaling_plan_is_scientific_simulation" => false,
    )
end

function _reduced_dcdfba_mpcc_scaling_plan_blocking_warnings(
    warnings::Vector{String},
)::Vector{String}
    return [warning for warning in warnings if !_reduced_dcdfba_mpcc_scaling_review_warning(warning)]
end

function _reduced_dcdfba_mpcc_scaling_plan_review_warnings(
    warnings::Vector{String},
)::Vector{String}
    return [warning for warning in warnings if _reduced_dcdfba_mpcc_scaling_review_warning(warning)]
end

function _reduced_dcdfba_mpcc_scaling_review_warning(warning::String)::Bool
    return warning in (
        "scaling_plan_flux_variable_positive_scale_spread_large",
        "scaling_plan_state_collocation_positive_scale_spread_large",
    )
end

function _reduced_dcdfba_mpcc_scaling_plan_summary(
    plan::ReducedDCDFBAMPCCScalingPlan,
)::Dict{String, Float64}
    return Dict{String, Float64}(
        "scaling_plan_variable_block_count" => Float64(length(plan.variable_blocks)),
        "scaling_plan_constraint_block_count" => Float64(length(plan.constraint_blocks)),
        "scaling_plan_warning_count" => Float64(length(plan.warnings)),
        "scaling_plan_blocking_warning_count" =>
            _reduced_dcdfba_float64_or_nan(
                get(plan.metadata, "scaling_blocking_warning_count", NaN),
            ),
        "scaling_plan_review_warning_count" =>
            _reduced_dcdfba_float64_or_nan(
                get(plan.metadata, "scaling_review_warning_count", NaN),
            ),
        "scaling_plan_ready_for_guarded_solve_attempt" =>
            get(plan.metadata, "scaling_plan_ready_for_guarded_solve_attempt", false) === true ? 1.0 :
            0.0,
        "scaling_plan_flux_variable_recommended_scale" =>
            _reduced_dcdfba_scale_block_field_or_nan(plan.variable_blocks, "flux", :recommended_scale),
        "scaling_plan_flux_variable_scaled_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(plan.variable_blocks, "flux", :scaled_abs_max),
        "scaling_plan_flux_variable_positive_scale_spread" =>
            _reduced_dcdfba_scale_block_field_or_nan(plan.variable_blocks, "flux", :positive_scale_spread),
        "scaling_plan_state_collocation_recommended_scale" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.variable_blocks,
                "state_collocation",
                :recommended_scale,
            ),
        "scaling_plan_state_collocation_scaled_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.variable_blocks,
                "state_collocation",
                :scaled_abs_max,
            ),
        "scaling_plan_state_derivative_recommended_scale" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.variable_blocks,
                "state_derivative",
                :recommended_scale,
            ),
        "scaling_plan_state_derivative_scaled_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.variable_blocks,
                "state_derivative",
                :scaled_abs_max,
            ),
        "scaling_plan_mass_balance_dual_recommended_scale" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.variable_blocks,
                "mass_balance_dual",
                :recommended_scale,
            ),
        "scaling_plan_mass_balance_dual_scaled_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.variable_blocks,
                "mass_balance_dual",
                :scaled_abs_max,
            ),
        "scaling_plan_collocation_integration_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.constraint_blocks,
                "collocation_integration",
                :abs_max,
            ),
        "scaling_plan_continuity_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(plan.constraint_blocks, "continuity", :abs_max),
        "scaling_plan_initial_condition_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.constraint_blocks,
                "initial_condition",
                :abs_max,
            ),
        "scaling_plan_rhs_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(plan.constraint_blocks, "rhs", :abs_max),
        "scaling_plan_mass_balance_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.constraint_blocks,
                "mass_balance",
                :abs_max,
            ),
        "scaling_plan_stationarity_abs_max" =>
            _reduced_dcdfba_scale_block_field_or_nan(
                plan.constraint_blocks,
                "stationarity",
                :abs_max,
            ),
        "scaling_plan_max_variable_scaled_abs_max" =>
            _reduced_dcdfba_mpcc_max_scaled_abs_max(plan.variable_blocks),
        "scaling_plan_max_constraint_scaled_abs_max" =>
            _reduced_dcdfba_mpcc_max_scaled_abs_max(plan.constraint_blocks),
    )
end

function _merge_reduced_dcdfba_mpcc_scaling_plan_diagnostic_metadata!(
    metadata::Dict{String, Any},
    plan::ReducedDCDFBAMPCCScalingPlan,
)
    for key in (
        "scaling_plan_ready_for_guarded_solve_attempt",
        "scaling_blocking_warning_count",
        "scaling_review_warning_count",
        "scaling_blocking_warnings",
        "scaling_review_warnings",
        "scaling_positive_scale_spread_warning_policy",
    )
        if haskey(plan.metadata, key)
            metadata[key] = plan.metadata[key]
        end
    end
    return metadata
end

function _reduced_dcdfba_mpcc_max_scaled_abs_max(
    blocks::Dict{String, ReducedDCDFBAMPCCScaleBlock},
)::Float64
    isempty(blocks) && return NaN
    return maximum(block.scaled_abs_max for block in values(blocks))
end

function _reduced_dcdfba_scale_block_field_or_nan(
    blocks::Dict{String, ReducedDCDFBAMPCCScaleBlock},
    name::AbstractString,
    field::Symbol,
)::Float64
    haskey(blocks, String(name)) || return NaN
    return Float64(getfield(blocks[String(name)], field))
end

function _reduced_dcdfba_mpcc_diagnostic_warnings(
    residuals_available::Bool,
    residual_thresholds_satisfied::Bool,
    ratios::Dict{String, Float64},
    scaling_summary::Dict{String, Float64},
)::Vector{String}
    warnings = String[]
    residuals_available || push!(warnings, "residuals_unavailable")
    for key in sort(collect(keys(ratios)))
        ratio = ratios[key]
        if isinf(ratio) || (isfinite(ratio) && ratio > 1.0)
            push!(warnings, "$(key)_above_threshold")
        elseif isnan(ratio)
            push!(warnings, "$(key)_ratio_unavailable")
        end
    end
    if !residual_thresholds_satisfied && isempty(warnings)
        push!(warnings, "residual_thresholds_not_satisfied")
    end

    for key in sort(collect(keys(scaling_summary)))
        value = scaling_summary[key]
        if !isfinite(value)
            push!(warnings, "$(key)_unavailable")
        end
    end
    get(scaling_summary, "state_collocation_positive_scale_spread", 0.0) > 1.0e6 &&
        push!(warnings, "state_collocation_start_scale_spread_large")
    get(scaling_summary, "flux_start_positive_scale_spread", 0.0) > 1.0e6 &&
        push!(warnings, "flux_start_scale_spread_large")
    get(scaling_summary, "state_derivative_start_abs_max", 0.0) > 1.0e6 &&
        push!(warnings, "state_derivative_start_abs_max_large")
    get(scaling_summary, "flux_start_abs_max", 0.0) > 1.0e6 &&
        push!(warnings, "flux_start_abs_max_large")
    get(scaling_summary, "objective_coefficient_abs_max", 0.0) > 1.0e6 &&
        push!(warnings, "objective_coefficient_abs_max_large")
    get(scaling_summary, "dynamic_flux_lp_start_max_mass_balance_residual", 0.0) > 1.0e-6 &&
        push!(warnings, "dynamic_flux_lp_start_mass_balance_residual_large")
    get(scaling_summary, "dynamic_flux_lp_start_max_lower_bound_violation", 0.0) > 1.0e-6 &&
        push!(warnings, "dynamic_flux_lp_start_lower_bound_violation_large")
    get(scaling_summary, "dynamic_flux_lp_start_max_upper_bound_violation", 0.0) > 1.0e-6 &&
        push!(warnings, "dynamic_flux_lp_start_upper_bound_violation_large")
    get(scaling_summary, "stationarity_dual_start_max_mass_balance_residual", 0.0) > 1.0e-6 &&
        push!(warnings, "stationarity_dual_start_mass_balance_residual_large")
    get(scaling_summary, "stationarity_dual_start_max_lower_bound_violation", 0.0) > 1.0e-6 &&
        push!(warnings, "stationarity_dual_start_lower_bound_violation_large")
    get(scaling_summary, "stationarity_dual_start_max_upper_bound_violation", 0.0) > 1.0e-6 &&
        push!(warnings, "stationarity_dual_start_upper_bound_violation_large")
    get(scaling_summary, "stationarity_dual_start_max_dual_sign_clipping", 0.0) > 1.0e-8 &&
        push!(warnings, "stationarity_dual_start_dual_sign_clipping_large")
    get(scaling_summary, "rhs_consistent_derivative_start_max_rhs_residual_after", 0.0) > 1.0e-6 &&
        push!(warnings, "rhs_consistent_derivative_start_rhs_residual_large")
    get(scaling_summary, "collocation_consistent_state_start_converged", 1.0) == 0.0 &&
        push!(warnings, "collocation_consistent_state_start_not_converged")
    get(scaling_summary, "collocation_consistent_state_start_final_collocation_residual", 0.0) > 1.0e-6 &&
        push!(warnings, "collocation_consistent_state_start_collocation_residual_large")
    get(scaling_summary, "collocation_consistent_state_start_final_continuity_residual", 0.0) > 1.0e-6 &&
        push!(warnings, "collocation_consistent_state_start_continuity_residual_large")
    get(scaling_summary, "collocation_consistent_state_start_final_rhs_residual", 0.0) > 1.0e-6 &&
        push!(warnings, "collocation_consistent_state_start_rhs_residual_large")
    return unique(warnings)
end

function _reduced_dcdfba_mpcc_diagnostic_metadata(
    diagnostic_source::String,
    source_metadata::Dict{String, Any},
    residuals_available::Bool,
    residual_thresholds_satisfied::Bool,
    dominant_residual::String,
    warning_count::Int,
)::Dict{String, Any}
    metadata = copy(source_metadata)
    merge!(
        metadata,
        Dict{String, Any}(
            "diagnostic_report_built" => true,
            "diagnostic_report_type" => "reduced_dcdfba_mpcc_solve_attempt",
            "diagnostic_source" => diagnostic_source,
            "dominant_residual" => dominant_residual,
            "residuals_available" => residuals_available,
            "residual_thresholds_satisfied" => residual_thresholds_satisfied,
            "complementarity_residual_gate_policy" =>
                _reduced_dcdfba_mpcc_complementarity_residual_gate_policy(source_metadata),
            "diagnostic_warning_count" => warning_count,
            "diagnostic_report_is_scientific_simulation" => false,
            "solve_attempt_is_scientific_simulation" => false,
            "residual_thresholds_are_scientific_acceptance_criteria" => false,
            "model_scope" => "reduced",
            "first_mpcc_target" => "reduced_dfba",
            "full_model_kkt_deferred" => true,
            "dfvb_kkt_deferred" => true,
            "hsl_required" => false,
            "ma57_required" => false,
            "indices_reacciones_used" => false,
            "r0001_used_as_oxygen" => false,
        ),
    )
    return metadata
end

function _reduced_dcdfba_mpcc_rhs_residual(problem::ReducedDCDFBAMPCCSmokeProblem)::Float64
    problem.rhs_residuals === nothing && return NaN
    state_values = _reduced_dcdfba_value_array_or_nothing(problem.nlp.state_collocation)
    derivative_values = _reduced_dcdfba_value_array_or_nothing(problem.nlp.state_derivative)
    flux_values = _reduced_dcdfba_value_array_or_nothing(problem.nlp.flux)
    any(x -> x === nothing, (state_values, derivative_values, flux_values)) && return NaN
    return _reduced_dcdfba_mpcc_rhs_residual_from_values(
        problem,
        state_values,
        derivative_values,
        flux_values,
    )
end

function _reduced_dcdfba_mpcc_rhs_residual_from_values(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    state_values,
    derivative_values,
    flux_values,
    ;
    dynamic_control_values = nothing,
)::Float64
    max_residual = 0.0

    for e in 1:problem.nlp.dimensions.nfe, j in 1:problem.nlp.dimensions.collocation_degree
        expected = _reduced_dcdfba_mpcc_rhs_expected_vector(
            problem,
            state_values,
            flux_values,
            e,
            j,
            dynamic_control_values = dynamic_control_values,
        )
        max_residual = max(
            max_residual,
            maximum(abs.(derivative_values[:, e, j] .- expected)),
        )
    end
    return Float64(max_residual)
end

function _reduced_dcdfba_mpcc_rhs_expected_vector(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    state_values,
    flux_values,
    element_index::Int,
    collocation_index::Int,
    ;
    dynamic_control_values = nothing,
)::Vector{Float64}
    params = _reduced_dcdfba_mpcc_effective_params(
        problem,
        element_index,
        collocation_index,
        dynamic_control_values = dynamic_control_values,
    )
    reaction_indices = problem.rhs_residuals.reaction_indices
    e = element_index
    j = collocation_index

    state_vector = Float64.(state_values[:, e, j])
    time_h = _reduced_dcdfba_mpcc_collocation_time(problem.nlp, e, j)
    dynamic_terms = problem.dynamic_control_decisions === nothing ?
                    _reduced_dcdfba_mpcc_dynamic_control_rhs_terms(
                        problem.dynamic_control_schedule,
                        params,
                        state_vector,
                        time_h,
                    ) :
                    dynamic_control_values === nothing ?
                    _reduced_dcdfba_mpcc_dynamic_control_rhs_terms_from_values(
                        problem.dynamic_control_decisions,
                        params,
                        state_vector,
                        time_h,
                    ) :
                    _reduced_dcdfba_mpcc_dynamic_control_rhs_terms_from_values(
                        problem.dynamic_control_decisions,
                        dynamic_control_values,
                        params,
                        state_vector,
                        time_h,
                    )
    biomass = state_values[1, e, j]
    protein = state_values[7, e, j]
    carbohydrate = state_values[8, e, j]

    v_biomass = flux_values[reaction_indices.biomass_growth, e, j]
    v_glucose = flux_values[reaction_indices.glucose_exchange, e, j]
    v_fructose = flux_values[reaction_indices.fructose_exchange, e, j]
    v_ethanol = flux_values[reaction_indices.ethanol_exchange, e, j]
    v_protein = flux_values[reaction_indices.protein_exchange, e, j]

    expected = zeros(Float64, KKT_DFBA_STATE_COUNT)
    expected[1] = v_biomass * biomass
    expected[2] = sum(
        flux_values[reaction_indices.nitrogen_sources[k], e, j] *
        params.nitrogen_atom_counts[k] *
        params.MW_N *
        biomass for k in eachindex(reaction_indices.nitrogen_sources)
    ) + dynamic_terms.free_nitrogen_rate_gN_L_h
    expected[3] = params.MW_GLU * v_glucose * biomass
    expected[4] = params.MW_FRU * v_fructose * biomass
    expected[5] = params.MW_ETH * v_ethanol * biomass
    expected[6] = 0.0
    expected[7] =
        v_biomass * biomass * params.PROT_CONTENT_0 -
        protein * params.K_DEATH +
        params.XA_FRACTION * biomass * v_protein -
        params.TURNOVER_LAMBDA * protein
    expected[8] = v_biomass * biomass * params.CARB_CONTENT_0 - carbohydrate * params.K_DEATH
    for k in 1:5
        expected[8 + k] =
            biomass * flux_values[reaction_indices.amino_acids[k], e, j] +
            dynamic_terms.amino_acid_state_rates_per_h[k]
    end
    for k in 1:6
        expected[13 + k] =
            params.aroma_molecular_weights[k] *
            flux_values[reaction_indices.aromas[k], e, j] *
            biomass - dynamic_terms.aroma_loss_rates_g_L_h[k]
    end
    return expected
end

function _reduced_dcdfba_mpcc_smoke_diagnostics(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    has_primal::Bool,
)
    if !has_primal
        return (
            max_mass_balance_residual = NaN,
            max_lower_bound_violation = NaN,
            max_upper_bound_violation = NaN,
            max_stationarity_residual = NaN,
            max_lower_complementarity_residual = NaN,
            max_upper_complementarity_residual = NaN,
        )
    end

    flux_values = _reduced_dcdfba_value_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_value_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_value_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_value_array_or_nothing(problem.stationarity.mass_balance_duals)
    state_values = problem.dynamic_bounds === nothing ?
                   nothing :
                   _reduced_dcdfba_value_array_or_nothing(problem.nlp.state_collocation)

    any(x -> x === nothing, (flux_values, lower_dual_values, upper_dual_values, mass_dual_values)) && return (
        max_mass_balance_residual = NaN,
        max_lower_bound_violation = NaN,
        max_upper_bound_violation = NaN,
        max_stationarity_residual = NaN,
        max_lower_complementarity_residual = NaN,
        max_upper_complementarity_residual = NaN,
    )
    problem.dynamic_bounds !== nothing && state_values === nothing && return (
        max_mass_balance_residual = NaN,
        max_lower_bound_violation = NaN,
        max_upper_bound_violation = NaN,
        max_stationarity_residual = NaN,
        max_lower_complementarity_residual = NaN,
        max_upper_complementarity_residual = NaN,
    )

    return _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
        problem,
        flux_values,
        lower_dual_values,
        upper_dual_values,
        mass_dual_values,
        state_values,
    )
end

function _reduced_dcdfba_mpcc_smoke_diagnostics_from_values(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    flux_values,
    lower_dual_values,
    upper_dual_values,
    mass_dual_values,
    state_values,
    ;
    dynamic_control_values = nothing,
)
    model = problem.nlp.kkt_problem.model
    nfe = problem.nlp.dimensions.nfe
    degree = problem.nlp.dimensions.collocation_degree

    max_mass_balance_residual = 0.0
    max_lower_bound_violation = 0.0
    max_upper_bound_violation = 0.0
    max_stationarity_residual = 0.0
    max_lower_complementarity_residual = 0.0
    max_upper_complementarity_residual = 0.0

    for e in 1:nfe, j in 1:degree
        flux = flux_values[:, e, j]
        lower_dual = lower_dual_values[:, e, j]
        upper_dual = upper_dual_values[:, e, j]
        mass_dual = mass_dual_values[:, e, j]
        bounds = _reduced_dcdfba_numeric_flux_bounds(
            problem,
            e,
            j,
            state_values,
            dynamic_control_values = dynamic_control_values,
        )
        coefficients =
            _reduced_dcdfba_numeric_stationarity_coefficients(problem, e, j, state_values)

        max_mass_balance_residual =
            max(max_mass_balance_residual, maximum(abs.(model.S * flux)))
        max_lower_bound_violation =
            max(max_lower_bound_violation, maximum(max.(bounds.lb .- flux, 0.0)))
        max_upper_bound_violation =
            max(max_upper_bound_violation, maximum(max.(flux .- bounds.ub, 0.0)))
        max_stationarity_residual = max(
            max_stationarity_residual,
            maximum(abs.(coefficients .+ transpose(model.S) * mass_dual .+ lower_dual .+ upper_dual)),
        )
        max_lower_complementarity_residual = max(
            max_lower_complementarity_residual,
            maximum(abs.((flux .- bounds.lb) .* lower_dual)),
        )
        max_upper_complementarity_residual = max(
            max_upper_complementarity_residual,
            maximum(abs.((flux .- bounds.ub) .* upper_dual)),
        )
    end

    return (
        max_mass_balance_residual = Float64(max_mass_balance_residual),
        max_lower_bound_violation = Float64(max_lower_bound_violation),
        max_upper_bound_violation = Float64(max_upper_bound_violation),
        max_stationarity_residual = Float64(max_stationarity_residual),
        max_lower_complementarity_residual = Float64(max_lower_complementarity_residual),
        max_upper_complementarity_residual = Float64(max_upper_complementarity_residual),
    )
end

function _reduced_dcdfba_mpcc_complementarity_tau_status(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    max_lower_product::Real,
    max_upper_product::Real,
)
    mode = get(
        problem.metadata,
        "complementarity_mode",
        REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_EXACT,
    )
    String(mode) == REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES || return (
        max_complementarity_tau_violation = 0.0,
        max_complementarity_tau_violation_raw = 0.0,
        complementarity_tau_gate_tolerance = 0.0,
        complementarity_tau_gate_tolerance_source = "not_applicable_exact",
        complementarity_tau_gate_pass = true,
    )
    tau = _reduced_dcdfba_float64_or_nan(
        get(
            problem.metadata,
            "complementarity_tau",
            REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU,
        ),
    )
    gate_tolerance = _reduced_dcdfba_mpcc_complementarity_tau_gate_tolerance(
        problem.metadata,
        tau,
    )
    max_product = max(Float64(max_lower_product), Float64(max_upper_product))
    raw_violation = isfinite(max_product) && isfinite(tau) ? max_product - tau : NaN
    violation = isfinite(raw_violation) ? max(raw_violation, 0.0) : NaN
    return (
        max_complementarity_tau_violation = Float64(violation),
        max_complementarity_tau_violation_raw = Float64(raw_violation),
        complementarity_tau_gate_tolerance = gate_tolerance.tolerance,
        complementarity_tau_gate_tolerance_source = gate_tolerance.source,
        complementarity_tau_gate_pass =
            isfinite(raw_violation) && raw_violation <= gate_tolerance.tolerance,
    )
end

function _reduced_dcdfba_mpcc_complementarity_tau_gate_problem_metadata(
    complementarity_mode::Symbol,
    complementarity_tau::Float64,
    complementarity_tau_gate_tol::Union{Nothing, Float64},
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "complementarity_tau_gate_tolerance_override" =>
            complementarity_tau_gate_tol === nothing ? missing : complementarity_tau_gate_tol,
        "complementarity_tau_gate_tolerance_env" =>
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_TAU_GATE_TOL_ENV,
        "complementarity_tau_gate_abs_tolerance_default" =>
            REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU_GATE_ABS_TOL,
        "complementarity_tau_gate_rel_tolerance_default" =>
            REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU_GATE_REL_TOL,
    )
    if complementarity_mode == :scholtes
        gate_tolerance = _reduced_dcdfba_mpcc_complementarity_tau_gate_tolerance(
            metadata,
            complementarity_tau,
        )
        metadata["complementarity_tau_gate_tolerance"] = gate_tolerance.tolerance
        metadata["complementarity_tau_gate_tolerance_source"] = gate_tolerance.source
    else
        metadata["complementarity_tau_gate_tolerance"] = missing
        metadata["complementarity_tau_gate_tolerance_source"] = "not_applicable_exact"
    end
    return metadata
end

function _reduced_dcdfba_mpcc_complementarity_tau_gate_tolerance(
    metadata::Dict{String, Any},
    tau::Real,
)
    override = get(metadata, "complementarity_tau_gate_tolerance_override", missing)
    if override !== missing
        tolerance = _reduced_dcdfba_mpcc_validate_complementarity_tau_gate_tol(override)
        tolerance === nothing && error(
            "Reduced MPCC complementarity tau-gate tolerance override cannot be nothing.",
        )
        return (tolerance = tolerance, source = "argument_or_env")
    end
    tolerance = _reduced_dcdfba_mpcc_default_complementarity_tau_gate_tolerance(tau)
    return (tolerance = tolerance, source = "auto_abs_rel")
end

function _reduced_dcdfba_mpcc_default_complementarity_tau_gate_tolerance(
    tau::Real,
)::Float64
    value = Float64(tau)
    isfinite(value) && value >= 0.0 || return NaN
    return max(
        REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU_GATE_ABS_TOL,
        REDUCED_DCDFBA_MPCC_DEFAULT_COMPLEMENTARITY_TAU_GATE_REL_TOL * value,
    )
end

function _reduced_dcdfba_numeric_flux_bounds(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    element_index::Int,
    collocation_index::Int,
    state_values,
    ;
    dynamic_control_values = nothing,
)
    model = problem.nlp.kkt_problem.model
    lb = copy(model.lb)
    ub = copy(model.ub)
    problem.dynamic_bounds === nothing && return (lb = lb, ub = ub)

    y = Float64.(state_values[:, element_index, collocation_index])
    _reduced_dcdfba_numeric_growth_bound_updates!(
        lb,
        ub,
        problem,
        y,
        element_index,
        collocation_index,
        dynamic_control_values = dynamic_control_values,
    )
    if problem.dynamic_bounds.mode == :smooth_phase
        _reduced_dcdfba_numeric_smooth_phase_bound_updates!(
            lb,
            ub,
            problem,
            y,
            element_index,
            collocation_index,
            dynamic_control_values = dynamic_control_values,
        )
    end
    return (lb = lb, ub = ub)
end

function _reduced_dcdfba_numeric_growth_bound_updates!(
    lb::Vector{Float64},
    ub::Vector{Float64},
    problem::ReducedDCDFBAMPCCSmokeProblem,
    state_vector::Vector{Float64},
    element_index::Int,
    collocation_index::Int,
    ;
    dynamic_control_values = nothing,
)
    model = problem.nlp.kkt_problem.model
    params = _reduced_dcdfba_mpcc_effective_params(
        problem,
        element_index,
        collocation_index,
        dynamic_control_values = dynamic_control_values,
    )
    indices = _reduced_dcdfba_rhs_reaction_indices(problem.nlp.kkt_problem)
    state = zenteno_state_from_vector(state_vector)
    rates = zenteno_kinetic_rates(state, params)

    lb[indices.glucose_exchange] = -max(0.0, rates.vg / params.MW_GLU)
    lb[indices.fructose_exchange] = -max(0.0, rates.vf / params.MW_FRU)
    ub[indices.ethanol_exchange] = max(0.0, rates.ve)
    for k in eachindex(indices.nitrogen_sources)
        lb[indices.nitrogen_sources[k]] =
            -max(0.0, rates.vn) * params.nitrogen_distribution_weights[k]
    end
    for k in eachindex(indices.aromas)
        lb[indices.aromas[k]] = rates.v_aroma_forced[k]
    end
    for k in eachindex(indices.amino_acids)
        lb[indices.amino_acids[k]] =
            -max(
                0.0,
                params.K_AA_UPTAKE_GROWTH * state.amino_acids[k] /
                max(state.biomass, params.EPS),
            )
    end
    return nothing
end

function _reduced_dcdfba_numeric_smooth_phase_bound_updates!(
    lb::Vector{Float64},
    ub::Vector{Float64},
    problem::ReducedDCDFBAMPCCSmokeProblem,
    state_vector::Vector{Float64},
    element_index::Int,
    collocation_index::Int,
    ;
    dynamic_control_values = nothing,
)
    model = problem.nlp.kkt_problem.model
    params = _reduced_dcdfba_mpcc_effective_params(
        problem,
        element_index,
        collocation_index,
        dynamic_control_values = dynamic_control_values,
    )
    indices = _reduced_dcdfba_rhs_reaction_indices(problem.nlp.kkt_problem)
    growth_weight = _reduced_dcdfba_numeric_smooth_growth_phase_weight(problem, state_vector)
    turnover_weight = 1.0 - growth_weight
    biomass = max(state_vector[1], params.EPS)
    protein = max(state_vector[7], 0.0)

    for k in eachindex(indices.amino_acids)
        amino_acid = max(state_vector[8 + k], 0.0)
        growth_lb =
            -max(0.0, params.K_AA_UPTAKE_GROWTH * amino_acid / biomass)
        turnover_lb =
            -max(
                0.0,
                params.TURNOVER_LAMBDA *
                protein *
                params.AA_alpha /
                max(params.XA_FRACTION * biomass, params.EPS),
            )
        lb[indices.amino_acids[k]] = growth_weight * growth_lb + turnover_weight * turnover_lb
    end
    ub[indices.biomass_growth] = growth_weight * model.ub[indices.biomass_growth]
    lb[indices.atp_maintenance] =
        growth_weight * model.lb[indices.atp_maintenance] +
        turnover_weight * params.ATP_LB_TURNOVER
    ub[indices.atp_maintenance] =
        growth_weight * model.ub[indices.atp_maintenance] +
        turnover_weight * params.ATP_UB_TURNOVER
    return nothing
end

function _reduced_dcdfba_numeric_smooth_growth_phase_weight(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    state_vector::Vector{Float64},
)::Float64
    params = problem.nlp.kkt_problem.params
    width = Float64(get(problem.dynamic_bounds.metadata, "dynamic_phase_smoothing_width", 2.0e-4))
    proxy_mode = _reduced_dcdfba_phase_proxy_mode(
        get(problem.dynamic_bounds.metadata, "dynamic_phase_proxy_mode", "total_molecular_weight"),
    )
    proxy = _reduced_dcdfba_numeric_phase_proxy(params, state_vector, proxy_mode)
    return 1.0 / (1.0 + exp(-(proxy - params.TURNOVER_THRESHOLD) / width))
end

function _reduced_dcdfba_numeric_phase_proxy(
    params::ZentenoKineticParameters,
    state_vector::Vector{Float64},
    phase_proxy_mode::Symbol,
)::Float64
    mode = _reduced_dcdfba_phase_proxy_mode(phase_proxy_mode)
    if mode == :free_nitrogen
        return state_vector[2]
    elseif mode == :nitrogen_equivalent
        proxy = state_vector[2]
        for k in eachindex(params.amino_acid_molecular_weights)
            proxy += state_vector[8 + k] * params.MW_N
        end
        return proxy
    elseif mode == :total_molecular_weight
        proxy = state_vector[2]
        for k in eachindex(params.amino_acid_molecular_weights)
            proxy += state_vector[8 + k] * params.amino_acid_molecular_weights[k]
        end
        return proxy
    else
        throw(ArgumentError("Unsupported reduced DC-dFBA phase proxy mode: $phase_proxy_mode."))
    end
end

function _reduced_dcdfba_numeric_stationarity_coefficients(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    element_index::Int,
    collocation_index::Int,
    state_values,
)::Vector{Float64}
    coefficients = copy(problem.stationarity.objective_coefficients)
    isempty(problem.stationarity.objective_coefficient_expressions) && return coefficients
    problem.dynamic_bounds === nothing && return coefficients

    state_vector = Float64.(state_values[:, element_index, collocation_index])
    if problem.dynamic_bounds.mode == :smooth_phase
        indices = _reduced_dcdfba_rhs_reaction_indices(problem.nlp.kkt_problem)
        growth_weight = _reduced_dcdfba_numeric_smooth_growth_phase_weight(problem, state_vector)
        turnover_weight = 1.0 - growth_weight
        coefficients[indices.biomass_growth] = -growth_weight
        for reaction_index_value in indices.amino_acids
            coefficients[reaction_index_value] = growth_weight
        end
        coefficients[indices.atp_maintenance] = -turnover_weight
        coefficients[indices.protein_exchange] = -turnover_weight
    end
    return coefficients
end

function _reduced_dcdfba_value_array_or_nothing(variables)
    return try
        Float64.(JuMP.value.(variables))
    catch
        nothing
    end
end

function _reduced_dcdfba_start_array_or_nothing(variables)
    return try
        starts = JuMP.start_value.(variables)
        any(value -> value === nothing, starts) && return nothing
        Float64.(starts)
    catch
        nothing
    end
end

function _reduced_dcdfba_float64_or_nan(value)::Float64
    return try
        Float64(value)
    catch
        NaN
    end
end

function _reduced_dcdfba_abs_max_or_nan(values)::Float64
    values === nothing && return NaN
    return try
        Float64(maximum(abs.(values)))
    catch
        NaN
    end
end

function _reduced_dcdfba_positive_scale_spread(values)::Float64
    values === nothing && return NaN
    abs_values = abs.(vec(Float64.(values)))
    max_value = maximum(abs_values)
    max_value == 0.0 && return 0.0
    positive_values = abs_values[abs_values .> 0.0]
    isempty(positive_values) && return 0.0
    return Float64(max_value / minimum(positive_values))
end

function _reduced_dcdfba_objective_value_or_nan(jump_model::JuMP.Model)::Float64
    return try
        Float64(JuMP.objective_value(jump_model))
    catch
        NaN
    end
end

function _reduced_dcdfba_solver_name(jump_model::JuMP.Model)::String
    return try
        JuMP.solver_name(jump_model)
    catch
        "unknown"
    end
end

function _reduced_dcdfba_mpcc_nlp_block_violation_rows(
    problem::ReducedDCDFBAMPCCSmokeProblem,
)::Vector{Dict{String, Any}}
    jump_model = problem.nlp.jump_model
    has_values = JuMP.result_count(jump_model) > 0
    rows = Vector{Dict{String, Any}}()
    known_constraints = Set{Any}()

    _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
        rows,
        known_constraints,
        "collocation_integration",
        problem.nlp.collocation_integration_constraints;
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
        rows,
        known_constraints,
        "continuity",
        problem.nlp.continuity_constraints;
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
        rows,
        known_constraints,
        "initial_condition",
        problem.nlp.initial_condition_constraints;
        has_values = has_values,
    )
    if problem.rhs_residuals !== nothing
        _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
            rows,
            known_constraints,
            "rhs_residual",
            problem.rhs_residuals.constraints;
            has_values = has_values,
        )
    end
    _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
        rows,
        known_constraints,
        "mass_balance",
        problem.primal_feasibility.mass_balance_constraints;
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
        rows,
        known_constraints,
        "lower_bound_feasibility",
        problem.bound_feasibility.lower_bound_constraints;
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
        rows,
        known_constraints,
        "upper_bound_feasibility",
        problem.bound_feasibility.upper_bound_constraints;
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
        rows,
        known_constraints,
        "stationarity",
        problem.stationarity.stationarity_constraints;
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
        rows,
        known_constraints,
        "lower_complementarity",
        problem.complementarity.lower_bound_complementarity_constraints;
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
        rows,
        known_constraints,
        "upper_complementarity",
        problem.complementarity.upper_bound_complementarity_constraints;
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_extra_constraint_violation_row!(
        rows,
        jump_model,
        known_constraints;
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_variable_bound_violation_row!(
        rows,
        "all_variable_bounds",
        JuMP.all_variables(jump_model);
        has_values = has_values,
    )
    _push_reduced_dcdfba_mpcc_variable_bound_violation_row!(
        rows,
        "trust_region_slack_bounds",
        filter(
            variable -> startswith(
                JuMP.name(variable),
                "global_polish_trust_region_",
            ),
            JuMP.all_variables(jump_model),
        );
        has_values = has_values,
    )
    return rows
end

function _reduced_dcdfba_mpcc_nlp_block_violation_summary(
    rows::Vector{Dict{String, Any}},
)::Dict{String, Any}
    best_block = "missing"
    best_violation = -Inf
    for row in rows
        violation = get(row, "max_violation", NaN)
        isfinite(violation) || continue
        if violation > best_violation
            best_violation = violation
            best_block = String(get(row, "block", "missing"))
        end
    end
    summary = Dict{String, Any}(
        "nlp_block_violations_available" => !isempty(rows),
        "nlp_block_violation_row_count" => length(rows),
        "nlp_block_max_violation" => isfinite(best_violation) ? best_violation : NaN,
        "nlp_block_max_violation_block" => best_block,
        "nlp_block_extra_constraint_max_violation" => NaN,
        "nlp_block_violation_report_skipped" => false,
        "nlp_block_violation_report_skip_reason" => missing,
    )
    for row in rows
        String(get(row, "block", "")) == "extra_constraints" || continue
        summary["nlp_block_extra_constraint_max_violation"] =
            get(row, "max_violation", NaN)
        break
    end
    return summary
end

function _reduced_dcdfba_mpcc_skip_nlp_block_violation_rows()::Bool
    return _reduced_dcdfba_env_bool(
        REDUCED_DCDFBA_MPCC_SKIP_NLP_BLOCK_VIOLATION_ROWS_ENV,
        false,
    )
end

function _reduced_dcdfba_mpcc_skipped_nlp_block_violation_summary()::Dict{String, Any}
    return Dict{String, Any}(
        "nlp_block_violations_available" => false,
        "nlp_block_violation_row_count" => 0,
        "nlp_block_max_violation" => NaN,
        "nlp_block_max_violation_block" => "skipped",
        "nlp_block_extra_constraint_max_violation" => NaN,
        "nlp_block_violation_report_skipped" => true,
        "nlp_block_violation_report_skip_reason" =>
            REDUCED_DCDFBA_MPCC_SKIP_NLP_BLOCK_VIOLATION_ROWS_ENV,
    )
end

function _reduced_dcdfba_mpcc_apply_structural_nlp_residual_gate!(
    residual_report::Dict{String, Any},
    rows::Vector{Dict{String, Any}},
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
)::Dict{String, Any}
    residual_values, threshold_values =
        _reduced_dcdfba_mpcc_structural_nlp_residual_gate_values(
            residual_report,
            rows,
            thresholds,
            residual_report,
        )
    within = Dict{String, Bool}(
        key => isfinite(residual_values[key]) &&
               residual_values[key] <= threshold_values[key] for key in keys(residual_values)
    )
    residuals_available = all(value -> isfinite(value), values(residual_values))
    residual_thresholds_satisfied = residuals_available && all(values(within))
    ratios = _reduced_dcdfba_mpcc_residual_ratios(residual_values, threshold_values)
    ranked_residuals = _reduced_dcdfba_mpcc_ranked_residuals(ratios)

    residual_report["residuals_available"] = residuals_available
    residual_report["residual_thresholds_satisfied"] = residual_thresholds_satisfied
    residual_report["residual_threshold_report"] = within
    residual_report["residual_ratios"] = ratios
    residual_report["ranked_residuals"] = ranked_residuals
    residual_report["dominant_residual"] =
        isempty(ranked_residuals) ? "unavailable" : first(ranked_residuals)
    residual_report["structural_nlp_residual_gate_applied"] = true
    residual_report["structural_nlp_residual_gate_threshold_source"] =
        "max_rhs_residual_threshold"
    residual_report["complementarity_residual_gate_policy"] =
        _reduced_dcdfba_mpcc_complementarity_residual_gate_policy(residual_report)
    for key in keys(residual_values)
        residual_report[key] = residual_values[key]
        residual_report["$(key)_threshold"] = threshold_values[key]
        residual_report["$(key)_ratio"] = ratios[key]
        residual_report["$(key)_within_threshold"] = within[key]
    end
    return residual_report
end

function _reduced_dcdfba_mpcc_apply_structural_nlp_candidate_gate!(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
    smoke_result::ReducedDCDFBAMPCCSmokeResult,
    rows::Vector{Dict{String, Any}},
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
)::ReducedDCDFBAMPCCCandidateDiagnostics
    residual_values, threshold_values =
        _reduced_dcdfba_mpcc_structural_nlp_residual_gate_values(
            candidate.residual_values,
            rows,
            thresholds,
            candidate.metadata,
        )
    empty!(candidate.residual_values)
    merge!(candidate.residual_values, residual_values)
    empty!(candidate.residual_thresholds)
    merge!(candidate.residual_thresholds, threshold_values)
    residual_ratios = _reduced_dcdfba_mpcc_residual_ratios(residual_values, threshold_values)
    empty!(candidate.residual_ratios)
    merge!(candidate.residual_ratios, residual_ratios)
    ranked_residuals = _reduced_dcdfba_mpcc_ranked_residuals(residual_ratios)
    empty!(candidate.ranked_residuals)
    append!(candidate.ranked_residuals, ranked_residuals)

    residuals_available = all(value -> isfinite(value), values(residual_values))
    residual_thresholds_satisfied =
        residuals_available &&
        all(key -> residual_values[key] <= threshold_values[key], keys(residual_values))
    status_allows_candidate =
        _reduced_dcdfba_mpcc_status_allows_trajectory_candidate(smoke_result.status)
    primal_status_allows_candidate =
        _reduced_dcdfba_mpcc_primal_status_allows_residual_candidate(smoke_result.primal_status)
    residual_feasible_candidate =
        residuals_available && residual_thresholds_satisfied && primal_status_allows_candidate
    trajectory_extraction_ready = status_allows_candidate && residual_feasible_candidate
    iteration_limit_residual_feasible =
        smoke_result.status == MOI.ITERATION_LIMIT && residual_feasible_candidate

    candidate.metadata["candidate_residuals_available"] = residuals_available
    candidate.metadata["candidate_residual_thresholds_satisfied"] =
        residual_thresholds_satisfied
    candidate.metadata["candidate_residual_feasible"] = residual_feasible_candidate
    candidate.metadata["candidate_trajectory_extraction_ready"] = trajectory_extraction_ready
    candidate.metadata["candidate_iteration_limit_residual_feasible"] =
        iteration_limit_residual_feasible
    candidate.metadata["candidate_dominant_residual"] =
        isempty(ranked_residuals) ? "unavailable" : first(ranked_residuals)
    candidate.metadata["candidate_structural_nlp_residual_gate_applied"] = true
    candidate.metadata["candidate_structural_nlp_residual_gate_threshold_source"] =
        "max_rhs_residual_threshold"
    candidate.metadata["complementarity_residual_gate_policy"] =
        _reduced_dcdfba_mpcc_complementarity_residual_gate_policy(candidate.metadata)
    for key in keys(residual_values)
        candidate.metadata[key] = residual_values[key]
        candidate.metadata["$(key)_threshold"] = threshold_values[key]
        candidate.metadata["$(key)_ratio"] = residual_ratios[key]
        candidate.metadata["$(key)_within_threshold"] =
            isfinite(residual_values[key]) && residual_values[key] <= threshold_values[key]
    end
    if !residual_thresholds_satisfied &&
       !("candidate_structural_nlp_residual_thresholds_not_satisfied" in candidate.warnings)
        push!(candidate.warnings, "candidate_structural_nlp_residual_thresholds_not_satisfied")
    end
    return candidate
end

function _reduced_dcdfba_mpcc_structural_nlp_residual_gate_values(
    values_source::Dict,
    rows::Vector{Dict{String, Any}},
    thresholds::ReducedDCDFBAMPCCResidualThresholds,
    metadata::Dict = values_source,
)::Tuple{Dict{String, Float64}, Dict{String, Float64}}
    residual_values = Dict{String, Float64}()
    threshold_values = Dict{String, Float64}()
    base_thresholds = _reduced_dcdfba_mpcc_effective_threshold_values(metadata, thresholds)
    for (key, threshold) in base_thresholds
        value = get(values_source, key, NaN)
        value isa Real || (value = NaN)
        residual_values[key] = Float64(value)
        threshold_values[key] = threshold
    end
    structural_threshold = thresholds.max_rhs_residual
    for (block, key) in (
        "collocation_integration" => "max_collocation_integration_residual",
        "continuity" => "max_continuity_residual",
        "initial_condition" => "max_initial_condition_residual",
    )
        residual_values[key] = _reduced_dcdfba_mpcc_nlp_block_max_violation(rows, block)
        threshold_values[key] = structural_threshold
    end
    return residual_values, threshold_values
end

function _reduced_dcdfba_mpcc_nlp_block_max_violation(
    rows::Vector{Dict{String, Any}},
    block::AbstractString,
)::Float64
    for row in rows
        String(get(row, "block", "")) == String(block) || continue
        value = get(row, "max_violation", NaN)
        return value isa Real ? Float64(value) : NaN
    end
    return NaN
end

function _push_reduced_dcdfba_mpcc_constraint_block_violation_row!(
    rows::Vector{Dict{String, Any}},
    known_constraints::Set{Any},
    block::AbstractString,
    constraints;
    has_values::Bool,
)
    for constraint in constraints
        push!(known_constraints, constraint)
    end
    push!(
        rows,
        _reduced_dcdfba_mpcc_constraint_violation_row(
            block,
            constraints;
            kind = "known_constraint_block",
            has_values = has_values,
        ),
    )
    return rows
end

function _push_reduced_dcdfba_mpcc_extra_constraint_violation_row!(
    rows::Vector{Dict{String, Any}},
    jump_model::JuMP.Model,
    known_constraints::Set{Any};
    has_values::Bool,
)
    constraints = Any[]
    for (function_type, set_type) in JuMP.list_of_constraint_types(jump_model)
        function_type == JuMP.VariableRef && continue
        for constraint in JuMP.all_constraints(jump_model, function_type, set_type)
            (constraint in known_constraints) && continue
            push!(constraints, constraint)
        end
    end
    push!(
        rows,
        _reduced_dcdfba_mpcc_constraint_violation_row(
            "extra_constraints",
            constraints;
            kind = "unmapped_constraint_block",
            has_values = has_values,
        ),
    )
    return rows
end

function _reduced_dcdfba_mpcc_constraint_violation_row(
    block::AbstractString,
    constraints;
    kind::AbstractString,
    has_values::Bool,
)::Dict{String, Any}
    total_count = 0
    finite_count = 0
    evaluation_error_count = 0
    max_violation = -Inf
    max_abs_body_value = -Inf
    sum_violation = 0.0
    sumsq_violation = 0.0
    worst_index = "missing"
    worst_set = "missing"

    for (index, constraint) in pairs(constraints)
        total_count += 1
        if !has_values
            evaluation_error_count += 1
            continue
        end
        violation, abs_body_value, set_name = try
            _reduced_dcdfba_mpcc_constraint_violation(constraint)
        catch
            evaluation_error_count += 1
            continue
        end
        isfinite(violation) || continue
        finite_count += 1
        sum_violation += violation
        sumsq_violation += violation^2
        if isfinite(abs_body_value)
            max_abs_body_value = max(max_abs_body_value, abs_body_value)
        end
        if violation > max_violation
            max_violation = violation
            worst_index = string(index)
            worst_set = set_name
        end
    end
    return Dict{String, Any}(
        "block" => String(block),
        "kind" => String(kind),
        "total_count" => total_count,
        "finite_count" => finite_count,
        "evaluation_error_count" => evaluation_error_count,
        "max_violation" => finite_count > 0 ? max_violation : NaN,
        "mean_violation" => finite_count > 0 ? sum_violation / finite_count : NaN,
        "rms_violation" => finite_count > 0 ? sqrt(sumsq_violation / finite_count) : NaN,
        "max_abs_body_value" =>
            isfinite(max_abs_body_value) ? max_abs_body_value : NaN,
        "worst_index" => worst_index,
        "worst_set" => worst_set,
    )
end

function _reduced_dcdfba_mpcc_constraint_violation(constraint)
    object = JuMP.constraint_object(constraint)
    body_value = JuMP.value(object.func)
    violation = _reduced_dcdfba_mpcc_constraint_set_violation(body_value, object.set)
    return violation, _reduced_dcdfba_mpcc_abs_value_max(body_value), string(typeof(object.set))
end

function _reduced_dcdfba_mpcc_constraint_set_violation(value, set)::Float64
    if set isa MOI.EqualTo
        return abs(Float64(value) - Float64(set.value))
    elseif set isa MOI.LessThan
        return max(0.0, Float64(value) - Float64(set.upper))
    elseif set isa MOI.GreaterThan
        return max(0.0, Float64(set.lower) - Float64(value))
    elseif set isa MOI.Interval
        value_float = Float64(value)
        return max(
            max(0.0, Float64(set.lower) - value_float),
            max(0.0, value_float - Float64(set.upper)),
        )
    elseif set isa MOI.Zeros
        return maximum(abs.(Float64.(value)))
    elseif set isa MOI.Nonnegatives
        return max(0.0, -minimum(Float64.(value)))
    elseif set isa MOI.Nonpositives
        return max(0.0, maximum(Float64.(value)))
    end
    return NaN
end

function _reduced_dcdfba_mpcc_abs_value_max(value)::Float64
    if value isa Number
        return abs(Float64(value))
    end
    values = Float64.(value)
    isempty(values) && return 0.0
    return maximum(abs.(values))
end

function _reduced_dcdfba_metadata_float(
    metadata::Dict{String, Any},
    key::AbstractString,
    default::Float64,
)::Float64
    value = get(metadata, String(key), default)
    try
        parsed = Float64(value)
        return isfinite(parsed) ? parsed : default
    catch
        return default
    end
end

function _reduced_dcdfba_variable_value_or_nan(variable)::Float64
    try
        value = Float64(JuMP.value(variable))
        return isfinite(value) ? value : NaN
    catch
        return NaN
    end
end

function _reduced_dcdfba_named_variable_value_or_nan(
    jump_model::JuMP.Model,
    variable_name::AbstractString,
)::Float64
    variable = JuMP.variable_by_name(jump_model, String(variable_name))
    variable === nothing && return NaN
    return _reduced_dcdfba_variable_value_or_nan(variable)
end

function _reduced_dcdfba_dynamic_control_objective_component_metadata(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    has_values::Bool,
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "dynamic_control_objective_component_values_available" => false,
    )
    has_values || return metadata

    nlp = problem.nlp
    model_metadata = problem.metadata
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree
    jump_model = nlp.jump_model

    base_mode = String(
        get(
            nlp.metadata,
            "base_objective_mode",
            get(
                model_metadata,
                "base_objective_mode",
                REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_STATE_DERIVATIVE_L2,
            ),
        ),
    )
    base_value = 0.0
    if base_mode != REDUCED_DCDFBA_MPCC_BASE_OBJECTIVE_MODE_ZERO
        for variable in nlp.state_derivative
            value = _reduced_dcdfba_variable_value_or_nan(variable)
            isfinite(value) && (base_value += value^2)
        end
    end

    terminal_reward_value = 0.0
    terminal_reward_weight = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_terminal_reward_effective_weight",
        _reduced_dcdfba_metadata_float(
            model_metadata,
            "dynamic_control_objective_terminal_reward_weight",
            0.0,
        ),
    )
    component_names = get(
        model_metadata,
        "dynamic_control_objective_target_component_names",
        String[],
    )
    component_weights = get(
        model_metadata,
        "dynamic_control_objective_target_component_weights",
        Float64[],
    )
    component_scales = get(
        model_metadata,
        "dynamic_control_objective_target_component_scales_g_L",
        Float64[],
    )
    if terminal_reward_weight > 0.0 &&
       length(component_names) == length(component_weights) == length(component_scales)
        state_names = copy(DEFAULT_SIMULATION_STATE_NAMES)
        terminal_reward_expression = 0.0
        component_weight_sum = 0.0
        for (name, weight, scale) in zip(component_names, component_weights, component_scales)
            index = findfirst(==(String(name)), state_names)
            index === nothing && continue
            value =
                _reduced_dcdfba_variable_value_or_nan(nlp.state_boundary[index, nfe + 1])
            if isfinite(value)
                terminal_reward_expression += Float64(weight) * value / Float64(scale)
                component_weight_sum += Float64(weight)
            end
        end
        component_weight_sum > 0.0 &&
            (terminal_reward_value =
                -terminal_reward_weight * terminal_reward_expression / component_weight_sum)
    end
    final_target_state_value = NaN
    if length(component_names) == 1
        target_index = findfirst(==(String(only(component_names))), DEFAULT_SIMULATION_STATE_NAMES)
        if target_index !== nothing
            final_target_state_value = _reduced_dcdfba_variable_value_or_nan(
                nlp.state_boundary[target_index, nfe + 1],
            )
        end
    end

    final_glucose = _reduced_dcdfba_variable_value_or_nan(nlp.state_boundary[3, nfe + 1])
    final_fructose = _reduced_dcdfba_variable_value_or_nan(nlp.state_boundary[4, nfe + 1])
    final_sugar = final_glucose + final_fructose

    terminal_sugar_weight = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_terminal_sugar_weight",
        0.0,
    )
    terminal_sugar_scale = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_terminal_sugar_scale_g_L",
        100.0,
    )
    terminal_sugar_value =
        isfinite(final_sugar) ?
        terminal_sugar_weight * (final_sugar / terminal_sugar_scale)^2 :
        NaN

    integrated_sugar_value = 0.0
    integrated_sugar_weight = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_integrated_sugar_weight",
        0.0,
    )
    if integrated_sugar_weight > 0.0
        scale = _reduced_dcdfba_metadata_float(
            model_metadata,
            "dynamic_control_objective_integrated_sugar_scale_g_L",
            100.0,
        )
        integrated_sugar_policy = String(
            get(
                model_metadata,
                "dynamic_control_objective_integrated_sugar_policy",
                "radau_time_average_of_squared_total_sugar",
            ),
        )
        weights = nlp.kkt_problem.grid.scheme.weights
        expression = 0.0
        horizon_h = 0.0
        if integrated_sugar_policy ==
           "radau_time_average_of_squared_total_sugar_excess_slack"
            expression_is_finite = true
            for e in 1:nfe
                h = element_length(nlp.kkt_problem.grid, e)
                horizon_h += h
                for j in 1:degree
                    slack = _reduced_dcdfba_named_variable_value_or_nan(
                        jump_model,
                        "dynamic_control_integrated_sugar_excess_slack[$e,$j]",
                    )
                    if isfinite(slack)
                        expression += h * weights[j] * (slack / scale)^2
                    else
                        expression_is_finite = false
                    end
                end
            end
            integrated_sugar_value =
                horizon_h > 0.0 && expression_is_finite ?
                integrated_sugar_weight * expression / horizon_h :
                NaN
        else
            for e in 1:nfe
                h = element_length(nlp.kkt_problem.grid, e)
                horizon_h += h
                for j in 1:degree
                    glucose =
                        _reduced_dcdfba_variable_value_or_nan(nlp.state_collocation[3, e, j])
                    fructose =
                        _reduced_dcdfba_variable_value_or_nan(nlp.state_collocation[4, e, j])
                    sugar = glucose + fructose
                    isfinite(sugar) && (expression += h * weights[j] * (sugar / scale)^2)
                end
            end
            integrated_sugar_value =
                horizon_h > 0.0 ? integrated_sugar_weight * expression / horizon_h : NaN
        end
    end

    aroma_deficit_slack = _reduced_dcdfba_named_variable_value_or_nan(
        jump_model,
        "dynamic_control_aroma_deficit_slack",
    )
    aroma_deficit_weight = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_aroma_deficit_weight",
        0.0,
    )
    aroma_deficit_scale = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_aroma_deficit_scale_g_L",
        1.0e-4,
    )
    aroma_deficit_target = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_aroma_deficit_target_g_L",
        0.0,
    )
    aroma_deficit_required =
        isfinite(final_target_state_value) ?
        max(0.0, aroma_deficit_target - final_target_state_value) :
        NaN
    aroma_deficit_slack_minus_required =
        isfinite(aroma_deficit_slack) && isfinite(aroma_deficit_required) ?
        aroma_deficit_slack - aroma_deficit_required :
        NaN
    aroma_deficit_constraint_violation =
        isfinite(aroma_deficit_slack_minus_required) ?
        max(0.0, -aroma_deficit_slack_minus_required) :
        NaN
    aroma_deficit_value =
        isfinite(aroma_deficit_slack) ?
        aroma_deficit_weight * (aroma_deficit_slack / aroma_deficit_scale)^2 :
        0.0

    terminal_sugar_excess_slack = _reduced_dcdfba_named_variable_value_or_nan(
        jump_model,
        "dynamic_control_terminal_sugar_excess_slack",
    )
    terminal_sugar_excess_weight = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_terminal_sugar_excess_weight",
        0.0,
    )
    terminal_sugar_excess_scale = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_terminal_sugar_excess_scale_g_L",
        5.0,
    )
    terminal_sugar_excess_max = _reduced_dcdfba_metadata_float(
        model_metadata,
        "dynamic_control_objective_terminal_sugar_max_g_L",
        5.0,
    )
    terminal_sugar_excess_required =
        isfinite(final_sugar) ? max(0.0, final_sugar - terminal_sugar_excess_max) : NaN
    terminal_sugar_excess_slack_minus_required =
        isfinite(terminal_sugar_excess_slack) && isfinite(terminal_sugar_excess_required) ?
        terminal_sugar_excess_slack - terminal_sugar_excess_required :
        NaN
    terminal_sugar_excess_constraint_violation =
        isfinite(terminal_sugar_excess_slack_minus_required) ?
        max(0.0, -terminal_sugar_excess_slack_minus_required) :
        NaN
    terminal_sugar_excess_value =
        isfinite(terminal_sugar_excess_slack) ?
        terminal_sugar_excess_weight *
        (terminal_sugar_excess_slack / terminal_sugar_excess_scale)^2 :
        0.0

    nutrient_value = 0.0
    thermal_value = 0.0
    smoothness_value = 0.0
    direct_temperature_reward_value = 0.0
    direct_fda_reward_value = 0.0
    direct_organic_reward_value = 0.0
    decisions = problem.dynamic_control_decisions
    if decisions !== nothing
        nutrient_weight = _reduced_dcdfba_metadata_float(
            model_metadata,
            "dynamic_control_objective_nutrient_weight",
            0.0,
        )
        fda_weight = _reduced_dcdfba_metadata_float(
            model_metadata,
            "dynamic_control_objective_fda_weight",
            1.0,
        )
        organic_weight = _reduced_dcdfba_metadata_float(
            model_metadata,
            "dynamic_control_objective_organic_weight",
            1.0,
        )
        nutrient_scale = _reduced_dcdfba_metadata_float(
            model_metadata,
            "dynamic_control_objective_nutrient_scale_g_L",
            1.0,
        )
        fda_sum = 0.0
        for variable in decisions.fda_variables
            value = _reduced_dcdfba_variable_value_or_nan(variable)
            isfinite(value) && (fda_sum += value)
        end
        organic_sum = 0.0
        for variable in decisions.organic_variables
            value = _reduced_dcdfba_variable_value_or_nan(variable)
            isfinite(value) && (organic_sum += value)
        end
        nutrient_value = nutrient_weight *
                         (fda_weight * fda_sum + organic_weight * organic_sum) /
                         nutrient_scale
        direct_fda_reward_weight = _reduced_dcdfba_metadata_float(
            model_metadata,
            "dynamic_control_objective_direct_fda_reward_weight",
            0.0,
        )
        direct_organic_reward_weight = _reduced_dcdfba_metadata_float(
            model_metadata,
            "dynamic_control_objective_direct_organic_reward_weight",
            0.0,
        )
        direct_fda_reward_value = -direct_fda_reward_weight * fda_sum / nutrient_scale
        direct_organic_reward_value =
            -direct_organic_reward_weight * organic_sum / nutrient_scale

        temperatures = Float64[]
        for variable in decisions.temperature_variables
            value = _reduced_dcdfba_variable_value_or_nan(variable)
            isfinite(value) && push!(temperatures, value)
        end
        if !isempty(temperatures)
            thermal_weight = _reduced_dcdfba_metadata_float(
                model_metadata,
                "dynamic_control_objective_thermal_energy_weight",
                0.0,
            )
            ambient = _reduced_dcdfba_metadata_float(
                model_metadata,
                "dynamic_control_objective_ambient_temperature_C",
                20.0,
            )
            temperature_scale = _reduced_dcdfba_metadata_float(
                model_metadata,
                "dynamic_control_objective_temperature_scale_C",
                10.0,
            )
            thermal_expression = sum(
                ((temperature - ambient) / temperature_scale)^2 for
                temperature in temperatures
            )
            thermal_value = thermal_weight * thermal_expression / length(temperatures)
            direct_temperature_reward_weight = _reduced_dcdfba_metadata_float(
                model_metadata,
                "dynamic_control_objective_direct_temperature_reward_weight",
                0.0,
            )
            direct_temperature_expression = sum(
                (temperature - ambient) / temperature_scale for temperature in temperatures
            )
            direct_temperature_reward_value =
                -direct_temperature_reward_weight *
                direct_temperature_expression /
                length(temperatures)
        end
        if length(temperatures) > 1
            smoothness_weight = _reduced_dcdfba_metadata_float(
                model_metadata,
                "dynamic_control_objective_temperature_smoothness_weight",
                0.0,
            )
            smoothness_scale = _reduced_dcdfba_metadata_float(
                model_metadata,
                "dynamic_control_objective_temperature_smoothness_scale_C",
                5.0,
            )
            smoothness_expression = sum(
                (
                    (temperatures[index] - temperatures[index - 1]) /
                    smoothness_scale
                )^2 for index in 2:length(temperatures)
            )
            smoothness_value =
                smoothness_weight * smoothness_expression / (length(temperatures) - 1)
        end
    end

    dynamic_sum =
        terminal_reward_value +
        terminal_sugar_value +
        integrated_sugar_value +
        aroma_deficit_value +
        terminal_sugar_excess_value +
        nutrient_value +
        thermal_value +
        smoothness_value +
        direct_temperature_reward_value +
        direct_fda_reward_value +
        direct_organic_reward_value

    merge!(
        metadata,
        Dict{String, Any}(
            "dynamic_control_objective_component_values_available" => true,
            "dynamic_control_objective_base_value_estimate" => base_value,
            "dynamic_control_objective_terminal_reward_value_estimate" =>
                terminal_reward_value,
            "dynamic_control_objective_terminal_sugar_value_estimate" =>
                terminal_sugar_value,
            "dynamic_control_objective_integrated_sugar_value_estimate" =>
                integrated_sugar_value,
            "dynamic_control_objective_aroma_deficit_slack_value_g_L" =>
                aroma_deficit_slack,
            "dynamic_control_objective_final_target_state_value_g_L" =>
                final_target_state_value,
            "dynamic_control_objective_aroma_deficit_required_g_L" =>
                aroma_deficit_required,
            "dynamic_control_objective_aroma_deficit_slack_minus_required_g_L" =>
                aroma_deficit_slack_minus_required,
            "dynamic_control_objective_aroma_deficit_constraint_violation_g_L" =>
                aroma_deficit_constraint_violation,
            "dynamic_control_objective_aroma_deficit_value_estimate" =>
                aroma_deficit_value,
            "dynamic_control_objective_terminal_sugar_excess_slack_value_g_L" =>
                terminal_sugar_excess_slack,
            "dynamic_control_objective_final_total_sugar_value_g_L" => final_sugar,
            "dynamic_control_objective_terminal_sugar_excess_required_g_L" =>
                terminal_sugar_excess_required,
            "dynamic_control_objective_terminal_sugar_excess_slack_minus_required_g_L" =>
                terminal_sugar_excess_slack_minus_required,
            "dynamic_control_objective_terminal_sugar_excess_constraint_violation_g_L" =>
                terminal_sugar_excess_constraint_violation,
            "dynamic_control_objective_terminal_sugar_excess_value_estimate" =>
                terminal_sugar_excess_value,
            "dynamic_control_objective_nutrient_value_estimate" => nutrient_value,
            "dynamic_control_objective_thermal_energy_value_estimate" => thermal_value,
            "dynamic_control_objective_temperature_smoothness_value_estimate" =>
                smoothness_value,
            "dynamic_control_objective_direct_temperature_reward_value_estimate" =>
                direct_temperature_reward_value,
            "dynamic_control_objective_direct_fda_reward_value_estimate" =>
                direct_fda_reward_value,
            "dynamic_control_objective_direct_organic_reward_value_estimate" =>
                direct_organic_reward_value,
            "dynamic_control_objective_dynamic_value_estimate" => dynamic_sum,
            "dynamic_control_objective_reconstructed_total_value_estimate" =>
                base_value + dynamic_sum,
        ),
    )
    return metadata
end

function _push_reduced_dcdfba_mpcc_variable_bound_violation_row!(
    rows::Vector{Dict{String, Any}},
    block::AbstractString,
    variables;
    has_values::Bool,
)
    total_count = 0
    finite_count = 0
    evaluation_error_count = 0
    max_violation = -Inf
    sum_violation = 0.0
    sumsq_violation = 0.0
    worst_index = "missing"

    for (index, variable) in pairs(variables)
        total_count += 1
        if !has_values
            evaluation_error_count += 1
            continue
        end
        value = try
            Float64(JuMP.value(variable))
        catch
            evaluation_error_count += 1
            continue
        end
        violation = 0.0
        if JuMP.is_fixed(variable)
            fixed_value = Float64(JuMP.fix_value(variable))
            violation = max(violation, abs(value - fixed_value))
        else
            JuMP.has_lower_bound(variable) &&
                (violation = max(violation, Float64(JuMP.lower_bound(variable)) - value))
            JuMP.has_upper_bound(variable) &&
                (violation = max(violation, value - Float64(JuMP.upper_bound(variable))))
            violation = max(0.0, violation)
        end
        isfinite(violation) || continue
        finite_count += 1
        sum_violation += violation
        sumsq_violation += violation^2
        if violation > max_violation
            max_violation = violation
            worst_index = string(index)
        end
    end
    push!(
        rows,
        Dict{String, Any}(
            "block" => String(block),
            "kind" => "variable_bound_block",
            "total_count" => total_count,
            "finite_count" => finite_count,
            "evaluation_error_count" => evaluation_error_count,
            "max_violation" => finite_count > 0 ? max_violation : NaN,
            "mean_violation" => finite_count > 0 ? sum_violation / finite_count : NaN,
            "rms_violation" => finite_count > 0 ? sqrt(sumsq_violation / finite_count) : NaN,
            "max_abs_body_value" => NaN,
            "worst_index" => worst_index,
            "worst_set" => "VariableBounds",
        ),
    )
    return rows
end

function _reduced_dcdfba_model_attribute_or_missing(jump_model::JuMP.Model, attr)
    return try
        MOI.get(JuMP.backend(jump_model), attr)
    catch
        missing
    end
end

function _validate_reduced_dcdfba_stationarity_inputs(
    nlp::ReducedDCDFBACollocationNLP,
    bound_feasibility::ReducedDCDFBABoundFeasibilityScaffold,
)
    bound_feasibility.nlp === nlp || throw(
        ArgumentError("Reduced DC-dFBA stationarity requires bound-feasibility variables from the same NLP."),
    )
    get(nlp.metadata, "mass_balance_constraints_built", false) || throw(
        ArgumentError("Reduced DC-dFBA stationarity requires primal feasibility rows before stationarity."),
    )
    get(nlp.metadata, "bound_feasibility_constraints_built", false) || throw(
        ArgumentError("Reduced DC-dFBA stationarity requires bound feasibility rows before stationarity."),
    )
    size(bound_feasibility.lower_bound_duals) == size(nlp.flux) || throw(
        ArgumentError("Reduced DC-dFBA stationarity lower-bound dual dimensions must match flux dimensions."),
    )
    size(bound_feasibility.upper_bound_duals) == size(nlp.flux) || throw(
        ArgumentError("Reduced DC-dFBA stationarity upper-bound dual dimensions must match flux dimensions."),
    )
    return nothing
end

function _reduced_dcdfba_stationarity_objective_coefficients(
    nlp::ReducedDCDFBACollocationNLP,
    objective_coefficients::Union{Nothing, AbstractVector{<:Real}},
    objective_coefficient_expressions::Union{Nothing, Dict{Tuple{Int, Int, Int}, Any}} =
        nothing,
)::Tuple{Vector{Float64}, Dict{Tuple{Int, Int, Int}, Any}, String}
    n_reactions = nlp.dimensions.n_reactions
    expressions = objective_coefficient_expressions === nothing ?
                  Dict{Tuple{Int, Int, Int}, Any}() :
                  copy(objective_coefficient_expressions)
    _validate_reduced_dcdfba_stationarity_objective_expressions(nlp, expressions)

    if objective_coefficients === nothing
        policy = isempty(expressions) ? "zero_default" : "dynamic_collocation_minimization_coefficients"
        return zeros(Float64, n_reactions), expressions, policy
    end

    length(objective_coefficients) == n_reactions || throw(
        ArgumentError(
            "Reduced DC-dFBA stationarity objective_coefficients must have $n_reactions entries.",
        ),
    )
    coefficients = Float64.(objective_coefficients)
    all(isfinite, coefficients) || throw(
        ArgumentError("Reduced DC-dFBA stationarity objective_coefficients must be finite."),
    )
    policy = isempty(expressions) ?
             "fixed_linear_minimization_coefficients" :
             "fixed_plus_dynamic_collocation_minimization_coefficients"
    return coefficients, expressions, policy
end

function _validate_reduced_dcdfba_stationarity_objective_expressions(
    nlp::ReducedDCDFBACollocationNLP,
    expressions::Dict{Tuple{Int, Int, Int}, Any},
)
    n_reactions = nlp.dimensions.n_reactions
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree
    for (reaction_index_value, element_index, collocation_index) in keys(expressions)
        1 <= reaction_index_value <= n_reactions || throw(
            ArgumentError("Reduced DC-dFBA stationarity objective expression reaction index out of range."),
        )
        1 <= element_index <= nfe || throw(
            ArgumentError("Reduced DC-dFBA stationarity objective expression finite-element index out of range."),
        )
        1 <= collocation_index <= degree || throw(
            ArgumentError("Reduced DC-dFBA stationarity objective expression collocation index out of range."),
        )
    end
    return nothing
end

function _set_reduced_dcdfba_mass_balance_dual_starts!(
    mass_balance_duals::Array{JuMP.VariableRef, 3},
)
    for dual in mass_balance_duals
        JuMP.set_start_value(dual, 0.0)
    end
    return nothing
end

function _add_reduced_dcdfba_stationarity_constraints!(
    stationarity_constraints::Array{JuMP.ConstraintRef, 3},
    nlp::ReducedDCDFBACollocationNLP,
    bound_feasibility::ReducedDCDFBABoundFeasibilityScaffold,
    mass_balance_duals::Array{JuMP.VariableRef, 3},
    column_entries::Vector{Vector{Tuple{Int, Float64}}},
    objective_coefficients::Vector{Float64},
    objective_coefficient_expressions::Dict{Tuple{Int, Int, Int}, Any},
)
    jump_model = nlp.jump_model
    n_reactions = nlp.dimensions.n_reactions
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree

    for r in 1:n_reactions, e in 1:nfe, j in 1:degree
        expression = get(
            objective_coefficient_expressions,
            (r, e, j),
            objective_coefficients[r],
        )
        for (metabolite_index, coefficient) in column_entries[r]
            expression = expression + coefficient * mass_balance_duals[metabolite_index, e, j]
        end
        expression = expression + bound_feasibility.lower_bound_duals[r, e, j]
        expression = expression + bound_feasibility.upper_bound_duals[r, e, j]
        stationarity_constraints[r, e, j] = JuMP.@constraint(jump_model, expression == 0.0)
    end
    return nothing
end

function _reduced_dcdfba_stationarity_metadata(
    layout::ReducedDCDFBAStationarityLayout,
    objective_policy::AbstractString,
    objective_coefficients::Vector{Float64},
    objective_coefficient_expressions::Dict{Tuple{Int, Int, Int}, Any},
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold},
)::Dict{String, Any}
    dynamic_applied = dynamic_bounds !== nothing
    return Dict{String, Any}(
        "stationarity_constraints_built" => true,
        "reduced_fba_stationarity_built" => true,
        "dual_feasibility_constraints_built" => true,
        "stationarity_component" => "c + S'lambda + alpha_L + alpha_U = 0 at each collocation point",
        "stationarity_objective_convention" => "minimize c'v",
        "stationarity_max_objective_policy" => "pass negated objective weights for a max c'v FBA objective",
        "stationarity_objective_coefficients_policy" => String(objective_policy),
        "stationarity_nonzero_objective_coefficients" => count(x -> !iszero(x), objective_coefficients),
        "stationarity_objective_expression_count" => length(objective_coefficient_expressions),
        "stationarity_total_constraints" => layout.n_stationarity_constraints,
        "stationarity_reaction_count" => layout.n_reactions,
        "mass_balance_dual_variables_built" => true,
        "mass_balance_dual_sign" => "free",
        "mass_balance_dual_variables" => layout.n_mass_balance_dual_variables,
        "kkt_constraints_built" => false,
        "mpcc_complementarity_built" => false,
        "lower_bound_complementarity_built" => false,
        "upper_bound_complementarity_built" => false,
        "dynamic_flux_bounds_applied" => dynamic_applied,
        "dynamic_flux_bound_mode" => dynamic_applied ? String(dynamic_bounds.mode) : "none",
        "solver_call_performed" => false,
        "sequential_initialization_built" => false,
        "dfvb_kkt_deferred" => true,
        "full_model_kkt_deferred" => true,
        "first_mpcc_target" => "reduced_dfba",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
end

function _validate_reduced_dcdfba_bound_feasibility_model(nlp::ReducedDCDFBACollocationNLP)
    model = nlp.kkt_problem.model
    n_reactions = nlp.dimensions.n_reactions
    length(model.lb) == n_reactions || throw(
        ArgumentError(
            "Reduced DC-dFBA bound-feasibility lower-bound vector length does not match flux dimensions.",
        ),
    )
    length(model.ub) == n_reactions || throw(
        ArgumentError(
            "Reduced DC-dFBA bound-feasibility upper-bound vector length does not match flux dimensions.",
        ),
    )
    all(isfinite, model.lb) || throw(
        ArgumentError("Reduced DC-dFBA bound-feasibility lower bounds must be finite."),
    )
    all(isfinite, model.ub) || throw(
        ArgumentError("Reduced DC-dFBA bound-feasibility upper bounds must be finite."),
    )
    all(model.lb .<= model.ub) || throw(
        ArgumentError("Reduced DC-dFBA bound-feasibility requires lb <= ub."),
    )
    return nothing
end

function _validate_reduced_dcdfba_dynamic_bounds_attachment(
    nlp::ReducedDCDFBACollocationNLP,
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold},
)
    dynamic_bounds === nothing && return nothing
    dynamic_bounds.nlp === nlp || throw(
        ArgumentError("Reduced DC-dFBA dynamic bounds must belong to the same NLP."),
    )
    dynamic_bounds.mode in (:growth, :smooth_phase) || throw(
        ArgumentError("Reduced DC-dFBA bound feasibility accepts mode=:growth or :smooth_phase dynamic bounds only."),
    )
    dynamic_bounds.layout.n_reactions == nlp.dimensions.n_reactions || throw(
        ArgumentError("Reduced DC-dFBA dynamic bound reaction count does not match flux dimensions."),
    )
    dynamic_bounds.layout.nfe == nlp.dimensions.nfe || throw(
        ArgumentError("Reduced DC-dFBA dynamic bound finite-element count does not match flux dimensions."),
    )
    dynamic_bounds.layout.collocation_degree == nlp.dimensions.collocation_degree || throw(
        ArgumentError("Reduced DC-dFBA dynamic bound collocation degree does not match flux dimensions."),
    )
    return nothing
end

function _reduced_dcdfba_lower_bound_expression(
    nlp::ReducedDCDFBACollocationNLP,
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold},
    reaction_index_value::Int,
    element_index::Int,
    collocation_index::Int,
)
    dynamic_bounds === nothing && return nlp.kkt_problem.model.lb[reaction_index_value]
    return get(
        dynamic_bounds.lower_bound_expressions,
        (reaction_index_value, element_index, collocation_index),
        nlp.kkt_problem.model.lb[reaction_index_value],
    )
end

function _reduced_dcdfba_upper_bound_expression(
    nlp::ReducedDCDFBACollocationNLP,
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold},
    reaction_index_value::Int,
    element_index::Int,
    collocation_index::Int,
)
    dynamic_bounds === nothing && return nlp.kkt_problem.model.ub[reaction_index_value]
    return get(
        dynamic_bounds.upper_bound_expressions,
        (reaction_index_value, element_index, collocation_index),
        nlp.kkt_problem.model.ub[reaction_index_value],
    )
end

function _set_reduced_dcdfba_bound_dual_starts!(
    lower_bound_duals::Array{JuMP.VariableRef, 3},
    upper_bound_duals::Array{JuMP.VariableRef, 3},
)
    for index in eachindex(lower_bound_duals)
        JuMP.set_start_value(lower_bound_duals[index], 0.0)
        JuMP.set_start_value(upper_bound_duals[index], 0.0)
    end
    return nothing
end

function _add_reduced_dcdfba_bound_feasibility_constraints!(
    lower_bound_constraints::Array{JuMP.ConstraintRef, 3},
    upper_bound_constraints::Array{JuMP.ConstraintRef, 3},
    nlp::ReducedDCDFBACollocationNLP,
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold},
)
    jump_model = nlp.jump_model
    flux = nlp.flux
    n_reactions = nlp.dimensions.n_reactions
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree

    for r in 1:n_reactions, e in 1:nfe, j in 1:degree
        lower_bound = _reduced_dcdfba_lower_bound_expression(nlp, dynamic_bounds, r, e, j)
        upper_bound = _reduced_dcdfba_upper_bound_expression(nlp, dynamic_bounds, r, e, j)
        lower_bound_constraints[r, e, j] =
            JuMP.@constraint(jump_model, lower_bound - flux[r, e, j] <= 0.0)
        upper_bound_constraints[r, e, j] =
            JuMP.@constraint(jump_model, flux[r, e, j] - upper_bound <= 0.0)
    end
    return nothing
end

function _reduced_dcdfba_bound_feasibility_metadata(
    layout::ReducedDCDFBABoundFeasibilityLayout,
    dynamic_bounds::Union{Nothing, ReducedDCDFBADynamicBoundsScaffold},
)::Dict{String, Any}
    dynamic_applied = dynamic_bounds !== nothing
    return Dict{String, Any}(
        "bound_feasibility_constraints_built" => true,
        "reduced_fba_bound_feasibility_built" => true,
        "bound_feasibility_component" =>
            dynamic_applied ?
            "dynamic-or-base lb <= v <= dynamic-or-base ub at each collocation point" :
            "lb <= v <= ub at each collocation point",
        "lower_bound_feasibility_form" =>
            dynamic_applied ? "lb_dynamic_or_base - v <= 0" : "lb - v <= 0",
        "upper_bound_feasibility_form" =>
            dynamic_applied ? "v - ub_dynamic_or_base <= 0" : "v - ub <= 0",
        "lower_bound_dual_variables_built" => true,
        "upper_bound_dual_variables_built" => true,
        "lower_bound_dual_sign" => "nonpositive",
        "upper_bound_dual_sign" => "nonnegative",
        "bound_feasibility_lower_constraints" => layout.n_lower_bound_constraints,
        "bound_feasibility_upper_constraints" => layout.n_upper_bound_constraints,
        "bound_feasibility_total_constraints" => layout.n_total_bound_feasibility_constraints,
        "bound_feasibility_total_dual_variables" => layout.n_total_bound_dual_variables,
        "stationarity_constraints_built" => false,
        "kkt_constraints_built" => false,
        "mpcc_complementarity_built" => false,
        "lower_bound_complementarity_built" => false,
        "upper_bound_complementarity_built" => false,
        "dynamic_flux_bounds_applied" => dynamic_applied,
        "dynamic_flux_bound_mode" => dynamic_applied ? String(dynamic_bounds.mode) : "none",
        "dynamic_lower_bound_reaction_count" =>
            dynamic_applied ? dynamic_bounds.layout.n_lower_bound_reactions : 0,
        "dynamic_upper_bound_reaction_count" =>
            dynamic_applied ? dynamic_bounds.layout.n_upper_bound_reactions : 0,
        "solver_call_performed" => false,
        "sequential_initialization_built" => false,
        "dfvb_kkt_deferred" => true,
        "full_model_kkt_deferred" => true,
        "first_mpcc_target" => "reduced_dfba",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
end

function _reduced_dcdfba_rhs_reaction_indices(
    kkt_problem::KKTDFBAProblem,
)::ReducedDCDFBARHSReactionIndices
    model = kkt_problem.model
    roles = kkt_problem.reaction_roles
    return ReducedDCDFBARHSReactionIndices(
        reaction_index(model, roles.biomass_growth),
        reaction_index(model, roles.glucose_exchange),
        reaction_index(model, roles.fructose_exchange),
        reaction_index(model, roles.ethanol_exchange),
        reaction_index(model, roles.atp_maintenance),
        reaction_index(model, roles.protein_exchange),
        reaction_index(model, roles.carbohydrate_exchange),
        reaction_indices(model, roles.nitrogen_sources),
        reaction_indices(model, roles.amino_acids),
        reaction_indices(model, roles.aromas),
    )
end

function _build_reduced_dcdfba_growth_dynamic_bound_expressions!(
    lower_bound_expressions::Dict{Tuple{Int, Int, Int}, Any},
    upper_bound_expressions::Dict{Tuple{Int, Int, Int}, Any},
    nlp::ReducedDCDFBACollocationNLP,
    reaction_indices::ReducedDCDFBARHSReactionIndices,
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule} = nothing,
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold} =
        nothing,
)
    degree = nlp.dimensions.collocation_degree
    nfe = nlp.dimensions.nfe
    y = nlp.state_collocation

    for e in 1:nfe, j in 1:degree
        params = _reduced_dcdfba_mpcc_effective_params(nlp, dynamic_control_schedule, e, j)
        rates = _reduced_dcdfba_growth_kinetic_expressions(
            nlp,
            e,
            j;
            dynamic_control_schedule = dynamic_control_schedule,
            dynamic_control_decisions = dynamic_control_decisions,
        )

        lower_bound_expressions[(reaction_indices.glucose_exchange, e, j)] =
            -rates.vg / params.MW_GLU
        lower_bound_expressions[(reaction_indices.fructose_exchange, e, j)] =
            -rates.vf / params.MW_FRU
        upper_bound_expressions[(reaction_indices.ethanol_exchange, e, j)] =
            rates.ve

        for k in eachindex(reaction_indices.nitrogen_sources)
            lower_bound_expressions[(reaction_indices.nitrogen_sources[k], e, j)] =
                -rates.vn * params.nitrogen_distribution_weights[k]
        end
        for k in eachindex(reaction_indices.aromas)
            lower_bound_expressions[(reaction_indices.aromas[k], e, j)] =
                rates.v_aroma_forced[k]
        end
        for k in eachindex(reaction_indices.amino_acids)
            amino_acid = y[8 + k, e, j]
            biomass = y[1, e, j]
            lower_bound_expressions[(reaction_indices.amino_acids[k], e, j)] =
                -params.K_AA_UPTAKE_GROWTH * amino_acid / (biomass + params.EPS)
        end
    end
    return nothing
end

function _build_reduced_dcdfba_smooth_phase_dynamic_bound_expressions!(
    lower_bound_expressions::Dict{Tuple{Int, Int, Int}, Any},
    upper_bound_expressions::Dict{Tuple{Int, Int, Int}, Any},
    objective_coefficient_expressions::Dict{Tuple{Int, Int, Int}, Any},
    nlp::ReducedDCDFBACollocationNLP,
    reaction_indices::ReducedDCDFBARHSReactionIndices,
    phase_smoothing_width::Float64,
    phase_proxy_mode::Symbol,
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule} = nothing,
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold} =
        nothing,
)
    model = nlp.kkt_problem.model
    degree = nlp.dimensions.collocation_degree
    nfe = nlp.dimensions.nfe
    y = nlp.state_collocation

    _build_reduced_dcdfba_growth_dynamic_bound_expressions!(
        lower_bound_expressions,
        upper_bound_expressions,
        nlp,
        reaction_indices,
        dynamic_control_schedule,
        dynamic_control_decisions,
    )

    for e in 1:nfe, j in 1:degree
        params = _reduced_dcdfba_mpcc_effective_params(nlp, dynamic_control_schedule, e, j)
        growth_weight =
            _reduced_dcdfba_smooth_growth_phase_weight(
                nlp,
                e,
                j,
                phase_smoothing_width,
                phase_proxy_mode,
            )
        turnover_weight = 1.0 - growth_weight
        biomass = y[1, e, j]
        protein = y[7, e, j]

        for k in eachindex(reaction_indices.amino_acids)
            amino_acid = y[8 + k, e, j]
            growth_lb = -params.K_AA_UPTAKE_GROWTH * amino_acid / (biomass + params.EPS)
            turnover_lb =
                -params.TURNOVER_LAMBDA *
                protein *
                params.AA_alpha /
                (params.XA_FRACTION * biomass + params.EPS)
            lower_bound_expressions[(reaction_indices.amino_acids[k], e, j)] =
                growth_weight * growth_lb + turnover_weight * turnover_lb
            objective_coefficient_expressions[(reaction_indices.amino_acids[k], e, j)] =
                growth_weight
        end

        objective_coefficient_expressions[(reaction_indices.biomass_growth, e, j)] =
            -growth_weight
        objective_coefficient_expressions[(reaction_indices.atp_maintenance, e, j)] =
            -turnover_weight
        objective_coefficient_expressions[(reaction_indices.protein_exchange, e, j)] =
            -turnover_weight

        upper_bound_expressions[(reaction_indices.biomass_growth, e, j)] =
            growth_weight * model.ub[reaction_indices.biomass_growth]
        lower_bound_expressions[(reaction_indices.atp_maintenance, e, j)] =
            growth_weight * model.lb[reaction_indices.atp_maintenance] +
            turnover_weight * params.ATP_LB_TURNOVER
        upper_bound_expressions[(reaction_indices.atp_maintenance, e, j)] =
            growth_weight * model.ub[reaction_indices.atp_maintenance] +
            turnover_weight * params.ATP_UB_TURNOVER
    end
    return nothing
end

function _reduced_dcdfba_phase_proxy_expression(
    nlp::ReducedDCDFBACollocationNLP,
    element_index::Int,
    collocation_index::Int,
    phase_proxy_mode::Symbol,
)
    params = nlp.kkt_problem.params
    y = nlp.state_collocation
    mode = _reduced_dcdfba_phase_proxy_mode(phase_proxy_mode)
    if mode == :free_nitrogen
        return y[2, element_index, collocation_index]
    end
    proxy = y[2, element_index, collocation_index]
    if mode == :nitrogen_equivalent
        for k in eachindex(params.amino_acid_molecular_weights)
            proxy = proxy + y[8 + k, element_index, collocation_index] * params.MW_N
        end
    elseif mode == :total_molecular_weight
        for k in eachindex(params.amino_acid_molecular_weights)
            proxy =
                proxy +
                y[8 + k, element_index, collocation_index] *
                params.amino_acid_molecular_weights[k]
        end
    else
        throw(ArgumentError("Unsupported reduced DC-dFBA phase proxy mode: $phase_proxy_mode."))
    end
    return proxy
end

function _reduced_dcdfba_smooth_growth_phase_weight(
    nlp::ReducedDCDFBACollocationNLP,
    element_index::Int,
    collocation_index::Int,
    phase_smoothing_width::Float64,
    phase_proxy_mode::Symbol,
)
    params = nlp.kkt_problem.params
    proxy = _reduced_dcdfba_phase_proxy_expression(
        nlp,
        element_index,
        collocation_index,
        phase_proxy_mode,
    )
    return 1.0 / (1.0 + exp(-(proxy - params.TURNOVER_THRESHOLD) / phase_smoothing_width))
end

function _reduced_dcdfba_growth_kinetic_expressions(
    nlp::ReducedDCDFBACollocationNLP,
    element_index::Int,
    collocation_index::Int,
    ;
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule} = nothing,
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold} =
        nothing,
)
    params = _reduced_dcdfba_mpcc_effective_params(
        nlp,
        dynamic_control_schedule,
        element_index,
        collocation_index,
    )
    y = nlp.state_collocation
    cN = y[2, element_index, collocation_index]
    cG = y[3, element_index, collocation_index]
    cF = y[4, element_index, collocation_index]
    cE = y[5, element_index, collocation_index]
    eps = params.EPS
    time_h = _reduced_dcdfba_mpcc_collocation_time(nlp, element_index, collocation_index)
    T = dynamic_control_decisions === nothing ?
        params.temperature_K :
        _reduced_dcdfba_dynamic_control_temperature_K_expression(
            dynamic_control_decisions,
            time_h,
        )
    R = params.R

    mu_T = exp(59453.0 * (T - 300.0) / (300.0 * R * T))
    Kg_T = exp(46055.0 * (T - 293.15) / (293.15 * R * T))
    b_T = exp(11000.0 * (T - 296.15) / (296.15 * R * T))
    mrate = params.MRATE_0 * exp(37681.0 * (T - 293.30) / (293.30 * R * T))

    mu = params.MU0 * mu_T * (cN / (cN + params.Kn0 * Kg_T + eps))
    betaG =
        params.betaG0 *
        b_T *
        (cG / (cG + params.Kg0 * Kg_T + eps)) *
        (params.Kie0 * Kg_T / (cE + params.Kie0 * Kg_T + eps))
    betaF =
        params.betaF0 *
        b_T *
        (cF / (cF + params.Kf0 * Kg_T + eps)) *
        (params.Kig0 * Kg_T / (cG + params.Kig0 * Kg_T + eps)) *
        (params.Kie0 * Kg_T / (cE + params.Kie0 * Kg_T + eps))

    fermentation_hexose =
        betaG / max(params.YEG * params.MW_GLU, eps) +
        betaF / max(params.YEF * params.MW_FRU, eps)
    hexose_total = cG + cF + eps
    vg = mu / params.YXG + betaG / params.YEG + mrate * (cG / hexose_total)
    vf = mu / params.YXF + betaF / params.YEF + mrate * (cF / hexose_total)
    vn = mu / params.YXN
    ve = (betaG + betaF) / params.MW_ETH

    km_aroma = 0.002
    floor_val = 0.05
    v_aroma_forced = Vector{Any}(undef, 6)
    for k in 1:5
        c_aa_gN = y[8 + k, element_index, collocation_index] * params.MW_N
        f_aroma = floor_val + (1.0 - floor_val) * (c_aa_gN / (c_aa_gN + km_aroma + eps))
        v_aroma_forced[k] = params.aroma_forcing_constants[k] * fermentation_hexose * f_aroma
    end
    v_aroma_forced[6] = params.aroma_forcing_constants[6] * fermentation_hexose

    return (
        vg = vg,
        vf = vf,
        vn = vn,
        ve = ve,
        v_aroma_forced = v_aroma_forced,
    )
end

function _build_reduced_dcdfba_growth_objective_coefficients!(
    objective_coefficients::Vector{Float64},
    reaction_indices::ReducedDCDFBARHSReactionIndices,
)
    objective_coefficients[reaction_indices.biomass_growth] = -1.0
    for reaction_index_value in reaction_indices.amino_acids
        objective_coefficients[reaction_index_value] = 1.0
    end
    return nothing
end

function _reduced_dcdfba_dynamic_objective_reactions(
    objective_coefficients::Vector{Float64},
    objective_coefficient_expressions::Dict{Tuple{Int, Int, Int}, Any},
)::Vector{Int}
    reactions = Set{Int}(findall(!iszero, objective_coefficients))
    for (reaction_index_value, _, _) in keys(objective_coefficient_expressions)
        push!(reactions, reaction_index_value)
    end
    return sort!(collect(reactions))
end

function _unique_sorted_first_indices(expressions::Dict{Tuple{Int, Int, Int}, Any})::Vector{Int}
    return sort!(collect(Set(key[1] for key in keys(expressions))))
end

function _reduced_dcdfba_dynamic_bounds_metadata(
    nlp::ReducedDCDFBACollocationNLP,
    reaction_indices::ReducedDCDFBARHSReactionIndices,
    lower_reactions::Vector{Int},
    upper_reactions::Vector{Int},
    objective_reactions::Vector{Int},
    layout::ReducedDCDFBADynamicBoundsLayout,
    mode::Symbol,
    phase_smoothing_width::Float64,
    phase_proxy_mode::Symbol,
    objective_coefficient_expressions::Dict{Tuple{Int, Int, Int}, Any},
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule},
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold},
)::Dict{String, Any}
    model = nlp.kkt_problem.model
    lower_reaction_ids = model.rxn_ids[lower_reactions]
    upper_reaction_ids = model.rxn_ids[upper_reactions]
    objective_reaction_ids = model.rxn_ids[objective_reactions]
    proxy_definition = _reduced_dcdfba_phase_proxy_definition(phase_proxy_mode)
    metadata = Dict{String, Any}(
        "dynamic_flux_bounds_built" => true,
        "dynamic_flux_bounds_applied" => false,
        "dynamic_flux_bound_mode" => String(mode),
        "dynamic_flux_bound_policy" =>
            mode == :growth ?
            "smooth_growth_mode_positive_domain_no_max" :
            "smooth_phase_growth_turnover_$(String(phase_proxy_mode))_logistic",
        "dynamic_phase_smoothing_width" => mode == :smooth_phase ? phase_smoothing_width : missing,
        "dynamic_phase_proxy_mode" => mode == :smooth_phase ? String(phase_proxy_mode) : missing,
        "dynamic_phase_proxy_definition" => mode == :smooth_phase ? proxy_definition : missing,
        "dynamic_turnover_threshold" => nlp.kkt_problem.params.TURNOVER_THRESHOLD,
        "dynamic_flux_bound_component" =>
            "state-dependent Zenteno lower/upper bound expressions for reduced FBA KKT rows",
        "dynamic_lower_bound_reaction_count" => layout.n_lower_bound_reactions,
        "dynamic_upper_bound_reaction_count" => layout.n_upper_bound_reactions,
        "dynamic_lower_bound_expression_count" => layout.n_lower_bound_expressions,
        "dynamic_upper_bound_expression_count" => layout.n_upper_bound_expressions,
        "dynamic_lower_bound_reaction_ids" => lower_reaction_ids,
        "dynamic_upper_bound_reaction_ids" => upper_reaction_ids,
        "dynamic_objective_coefficients_built" => true,
        "dynamic_objective_convention" => "minimize -w'v for sequential max w'v",
        "dynamic_objective_reaction_count" => layout.n_objective_reactions,
        "dynamic_objective_reaction_ids" => objective_reaction_ids,
        "dynamic_objective_coefficients_nonzero" => layout.n_objective_reactions,
        "dynamic_objective_expression_count" => length(objective_coefficient_expressions),
        "dynamic_growth_biomass_objective_coefficient" => -1.0,
        "dynamic_growth_amino_acid_objective_coefficient" => 1.0,
        "dynamic_turnover_atp_objective_coefficient" => mode == :smooth_phase ? -1.0 : missing,
        "dynamic_turnover_protein_objective_coefficient" => mode == :smooth_phase ? -1.0 : missing,
        "dynamic_growth_glucose_lower_bound_reaction_id" =>
            model.rxn_ids[reaction_indices.glucose_exchange],
        "dynamic_growth_fructose_lower_bound_reaction_id" =>
            model.rxn_ids[reaction_indices.fructose_exchange],
        "dynamic_growth_ethanol_upper_bound_reaction_id" =>
            model.rxn_ids[reaction_indices.ethanol_exchange],
        "dynamic_growth_nitrogen_source_count" => length(reaction_indices.nitrogen_sources),
        "dynamic_growth_amino_acid_count" => length(reaction_indices.amino_acids),
        "dynamic_growth_aroma_count" => length(reaction_indices.aromas),
        "oxygen_exchange_bound_updated" => false,
        "carbohydrate_exchange_bound_updated" => false,
        "carbohydrate_exchange_note" =>
            "r_4048 remains present but has no Zenteno dynamic bound update in the reduced growth scaffold.",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "turnover_mode_deferred" => mode != :smooth_phase,
        "smooth_turnover_mode_embedded" => mode == :smooth_phase,
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
    )
    merge!(
        metadata,
        _reduced_dcdfba_mpcc_dynamic_control_metadata(
            dynamic_control_schedule;
            applied_to_dynamic_bounds = true,
        ),
    )
    if dynamic_control_decisions !== nothing
        merge!(metadata, dynamic_control_decisions.metadata)
        metadata["mpcc_dynamic_control_variable_policy"] =
            "coupled_control_decision_variables"
        metadata["mpcc_dynamic_control_variables_coupled_to_dynamic_bounds"] = true
        metadata["dynamic_flux_bounds_use_control_decision_variables"] = true
        metadata["fully_simultaneous_controls"] = true
    else
        metadata["dynamic_flux_bounds_use_control_decision_variables"] = false
    end
    metadata["dynamic_flux_bounds_temperature_policy"] =
        dynamic_control_decisions !== nothing ?
        "coupled_dynamic_control_temperature_variables_at_collocation_points" :
        dynamic_control_schedule === nothing ?
        "static_params_temperature_K" :
        "fixed_dynamic_control_schedule_temperature_at_collocation_points"
    return metadata
end

function _reduced_dcdfba_phase_proxy_definition(phase_proxy_mode::Symbol)::String
    mode = _reduced_dcdfba_phase_proxy_mode(phase_proxy_mode)
    if mode == :free_nitrogen
        return "N_free"
    elseif mode == :nitrogen_equivalent
        return "N_free + sum(amino_acids * MW_N)"
    elseif mode == :total_molecular_weight
        return "N_free + sum(amino_acids * amino_acid_molecular_weights)"
    end
    throw(ArgumentError("Unsupported reduced DC-dFBA phase proxy mode: $phase_proxy_mode."))
end

function _reduced_dcdfba_rhs_residual_layout(
    dimensions::ReducedDCDFBACollocationNLPDimensions,
)::ReducedDCDFBARHSResidualLayout
    ncp = dimensions.n_collocation_points
    return ReducedDCDFBARHSResidualLayout(
        ncp,
        ncp,
        ncp,
        ncp,
        ncp,
        ncp,
        ncp,
        ncp,
        5 * ncp,
        6 * ncp,
        KKT_DFBA_STATE_COUNT * ncp,
    )
end

function _add_reduced_dcdfba_growth_rhs_constraints!(
    constraints::Array{JuMP.ConstraintRef, 3},
    nlp::ReducedDCDFBACollocationNLP,
    reaction_indices::ReducedDCDFBARHSReactionIndices,
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule} = nothing,
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold} =
        nothing,
)
    jump_model = nlp.jump_model
    y = nlp.state_collocation
    dy = nlp.state_derivative
    flux = nlp.flux
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree

    for e in 1:nfe, j in 1:degree
        params = _reduced_dcdfba_mpcc_effective_params(nlp, dynamic_control_schedule, e, j)
        time_h = _reduced_dcdfba_mpcc_collocation_time(nlp, e, j)
        state_vector = [y[i, e, j] for i in 1:KKT_DFBA_STATE_COUNT]
        dynamic_terms = _reduced_dcdfba_mpcc_dynamic_control_rhs_terms(
            dynamic_control_decisions === nothing ? dynamic_control_schedule : dynamic_control_decisions,
            params,
            state_vector,
            time_h,
        )
        biomass = y[1, e, j]
        protein = y[7, e, j]
        carbohydrate = y[8, e, j]

        v_biomass = flux[reaction_indices.biomass_growth, e, j]
        v_glucose = flux[reaction_indices.glucose_exchange, e, j]
        v_fructose = flux[reaction_indices.fructose_exchange, e, j]
        v_ethanol = flux[reaction_indices.ethanol_exchange, e, j]
        v_protein = flux[reaction_indices.protein_exchange, e, j]

        constraints[1, e, j] = JuMP.@constraint(jump_model, dy[1, e, j] == v_biomass * biomass)
        constraints[2, e, j] = JuMP.@constraint(
            jump_model,
            dy[2, e, j] ==
            sum(
                flux[reaction_indices.nitrogen_sources[k], e, j] *
                params.nitrogen_atom_counts[k] *
                params.MW_N *
                biomass for k in eachindex(reaction_indices.nitrogen_sources)
            ) + dynamic_terms.free_nitrogen_rate_gN_L_h,
        )
        constraints[3, e, j] =
            JuMP.@constraint(jump_model, dy[3, e, j] == params.MW_GLU * v_glucose * biomass)
        constraints[4, e, j] =
            JuMP.@constraint(jump_model, dy[4, e, j] == params.MW_FRU * v_fructose * biomass)
        constraints[5, e, j] =
            JuMP.@constraint(jump_model, dy[5, e, j] == params.MW_ETH * v_ethanol * biomass)
        constraints[6, e, j] = JuMP.@constraint(jump_model, dy[6, e, j] == 0.0)
        constraints[7, e, j] = JuMP.@constraint(
            jump_model,
            dy[7, e, j] ==
            v_biomass * biomass * params.PROT_CONTENT_0 -
            protein * params.K_DEATH +
            params.XA_FRACTION * biomass * v_protein -
            params.TURNOVER_LAMBDA * protein,
        )
        constraints[8, e, j] = JuMP.@constraint(
            jump_model,
            dy[8, e, j] ==
            v_biomass * biomass * params.CARB_CONTENT_0 -
            carbohydrate * params.K_DEATH,
        )
        for k in 1:5
            state_index = 8 + k
            constraints[state_index, e, j] = JuMP.@constraint(
                jump_model,
                dy[state_index, e, j] ==
                biomass * flux[reaction_indices.amino_acids[k], e, j] +
                dynamic_terms.amino_acid_state_rates_per_h[k],
            )
        end
        for k in 1:6
            state_index = 13 + k
            constraints[state_index, e, j] = JuMP.@constraint(
                jump_model,
                dy[state_index, e, j] ==
                params.aroma_molecular_weights[k] *
                flux[reaction_indices.aromas[k], e, j] *
                biomass - dynamic_terms.aroma_loss_rates_g_L_h[k],
            )
        end
    end
    return nothing
end

function _validate_reduced_dcdfba_initial_state(initial_state::AbstractVector)
    length(initial_state) == KKT_DFBA_STATE_COUNT || throw(
        ArgumentError(
            "Reduced DC-dFBA collocation NLP initial_state must have " *
            "$(KKT_DFBA_STATE_COUNT) entries, got $(length(initial_state)).",
        ),
    )
    all(isfinite, initial_state) ||
        throw(ArgumentError("Reduced DC-dFBA collocation NLP initial_state must be finite."))
    return nothing
end

function _set_reduced_dcdfba_state_nonnegative_bounds!(
    state_boundary::Matrix{JuMP.VariableRef},
    state_collocation::Array{JuMP.VariableRef, 3};
    enabled::Bool,
)::Dict{String, Any}
    boundary_count = 0
    collocation_count = 0
    if enabled
        for variable in state_boundary
            JuMP.set_lower_bound(variable, 0.0)
            boundary_count += 1
        end
        for variable in state_collocation
            JuMP.set_lower_bound(variable, 0.0)
            collocation_count += 1
        end
    end
    return Dict{String, Any}(
        "state_nonnegative_bounds_enabled" => enabled,
        "state_nonnegative_boundary_lower_bound_count" => boundary_count,
        "state_nonnegative_collocation_lower_bound_count" => collocation_count,
        "state_nonnegative_derivative_lower_bound_count" => 0,
    )
end

function _reduced_dcdfba_clamp_state_starts_to_nonnegative_bounds!(
    nlp::ReducedDCDFBACollocationNLP;
    requested::Bool,
)::Dict{String, Any}
    bounds_enabled = get(nlp.metadata, "state_nonnegative_bounds_enabled", false) === true
    metadata = Dict{String, Any}(
        "state_nonnegative_start_clamp_requested" => requested,
        "state_nonnegative_start_clamp_applied" => false,
        "state_nonnegative_start_clamp_policy" =>
            requested ?
            (bounds_enabled ? "clamp_negative_state_starts_to_zero" : "skipped_bounds_disabled") :
            "disabled",
        "state_nonnegative_start_clamp_boundary_negative_count_before" => 0,
        "state_nonnegative_start_clamp_collocation_negative_count_before" => 0,
        "state_nonnegative_start_clamp_boundary_negative_count_after" => 0,
        "state_nonnegative_start_clamp_collocation_negative_count_after" => 0,
        "state_nonnegative_start_clamp_boundary_min_before" => NaN,
        "state_nonnegative_start_clamp_collocation_min_before" => NaN,
        "state_nonnegative_start_clamp_boundary_min_after" => NaN,
        "state_nonnegative_start_clamp_collocation_min_after" => NaN,
        "state_nonnegative_start_clamp_max_boundary_adjustment" => 0.0,
        "state_nonnegative_start_clamp_max_collocation_adjustment" => 0.0,
    )
    requested && bounds_enabled || return metadata

    boundary_values = _reduced_dcdfba_start_array_or_nothing(nlp.state_boundary)
    collocation_values = _reduced_dcdfba_start_array_or_nothing(nlp.state_collocation)
    if boundary_values === nothing || collocation_values === nothing
        metadata["state_nonnegative_start_clamp_policy"] =
            "skipped_nonfinite_or_missing_state_starts"
        return metadata
    end

    boundary_negative_count_before = count(<(0.0), boundary_values)
    collocation_negative_count_before = count(<(0.0), collocation_values)
    boundary_min_before = minimum(boundary_values)
    collocation_min_before = minimum(collocation_values)
    max_boundary_adjustment = 0.0
    max_collocation_adjustment = 0.0

    if boundary_negative_count_before > 0
        for index in eachindex(boundary_values)
            value = boundary_values[index]
            if value < 0.0
                max_boundary_adjustment = max(max_boundary_adjustment, -value)
                JuMP.set_start_value(nlp.state_boundary[index], 0.0)
                boundary_values[index] = 0.0
            end
        end
    end
    if collocation_negative_count_before > 0
        for index in eachindex(collocation_values)
            value = collocation_values[index]
            if value < 0.0
                max_collocation_adjustment = max(max_collocation_adjustment, -value)
                JuMP.set_start_value(nlp.state_collocation[index], 0.0)
                collocation_values[index] = 0.0
            end
        end
    end

    metadata["state_nonnegative_start_clamp_applied"] =
        boundary_negative_count_before > 0 || collocation_negative_count_before > 0
    metadata["state_nonnegative_start_clamp_boundary_negative_count_before"] =
        boundary_negative_count_before
    metadata["state_nonnegative_start_clamp_collocation_negative_count_before"] =
        collocation_negative_count_before
    metadata["state_nonnegative_start_clamp_boundary_negative_count_after"] =
        count(<(0.0), boundary_values)
    metadata["state_nonnegative_start_clamp_collocation_negative_count_after"] =
        count(<(0.0), collocation_values)
    metadata["state_nonnegative_start_clamp_boundary_min_before"] =
        boundary_min_before
    metadata["state_nonnegative_start_clamp_collocation_min_before"] =
        collocation_min_before
    metadata["state_nonnegative_start_clamp_boundary_min_after"] = minimum(boundary_values)
    metadata["state_nonnegative_start_clamp_collocation_min_after"] =
        minimum(collocation_values)
    metadata["state_nonnegative_start_clamp_max_boundary_adjustment"] =
        max_boundary_adjustment
    metadata["state_nonnegative_start_clamp_max_collocation_adjustment"] =
        max_collocation_adjustment
    return metadata
end

function _set_reduced_dcdfba_variable_starts!(
    state_boundary::Matrix{JuMP.VariableRef},
    state_collocation::Array{JuMP.VariableRef, 3},
    state_derivative::Array{JuMP.VariableRef, 3},
    flux::Array{JuMP.VariableRef, 3},
    initial_state::AbstractVector,
    model::MetabolicModel,
)
    n_states, nfe_plus_one = size(state_boundary)
    nfe = size(state_collocation, 2)
    degree = size(state_collocation, 3)
    n_reactions = size(flux, 1)

    for i in 1:n_states
        initial_value = Float64(initial_state[i])
        for e in 1:nfe_plus_one
            JuMP.set_start_value(state_boundary[i, e], initial_value)
        end
        for e in 1:nfe, j in 1:degree
            JuMP.set_start_value(state_collocation[i, e, j], initial_value)
            JuMP.set_start_value(state_derivative[i, e, j], 0.0)
        end
    end

    for r in 1:n_reactions, e in 1:nfe, j in 1:degree
        JuMP.set_start_value(flux[r, e, j], clamp(0.0, model.lb[r], model.ub[r]))
    end
    return nothing
end

function _set_reduced_dcdfba_flux_bounds!(
    flux::Array{JuMP.VariableRef, 3},
    model::MetabolicModel;
    defer_fixed_bounds::Bool = false,
)
    n_reactions = size(flux, 1)
    nfe = size(flux, 2)
    degree = size(flux, 3)
    fixed_reaction_indices = Int[
        r for r in 1:n_reactions if _reduced_dcdfba_is_fixed_flux_bound(model, r)
    ]
    fixed_flux_variable_count = length(fixed_reaction_indices) * nfe * degree
    lower_bound_count = 0
    upper_bound_count = 0
    skipped_lower_bound_count = 0
    skipped_upper_bound_count = 0

    for r in 1:n_reactions, e in 1:nfe, j in 1:degree
        if defer_fixed_bounds && _reduced_dcdfba_is_fixed_flux_bound(model, r)
            skipped_lower_bound_count += 1
            skipped_upper_bound_count += 1
            continue
        end
        JuMP.set_lower_bound(flux[r, e, j], model.lb[r])
        JuMP.set_upper_bound(flux[r, e, j], model.ub[r])
        lower_bound_count += 1
        upper_bound_count += 1
    end

    deferred = defer_fixed_bounds && fixed_flux_variable_count > 0
    return Dict{String, Any}(
        "base_flux_bounds_applied" => !deferred,
        "base_flux_bounds_partially_applied" => deferred,
        "base_flux_bounds_applied_to_nonfixed_fluxes" => true,
        "fixed_flux_variable_bounds_deferred" => deferred,
        "fixed_flux_variable_bound_policy" =>
            deferred ?
            "lb_eq_ub_enforced_by_bound_feasibility_rows_not_variable_bounds" :
            "apply_model_bounds_as_variable_bounds",
        "fixed_flux_bound_rows_required" => deferred,
        "fixed_flux_bounds_enforced_by_bound_feasibility_rows" => false,
        "fixed_flux_reaction_count" => length(fixed_reaction_indices),
        "fixed_flux_reaction_ids" => model.rxn_ids[fixed_reaction_indices],
        "fixed_flux_collocation_variable_count" => fixed_flux_variable_count,
        "flux_variable_lower_bound_count" => lower_bound_count,
        "flux_variable_upper_bound_count" => upper_bound_count,
        "fixed_flux_variable_lower_bound_skipped_count" => skipped_lower_bound_count,
        "fixed_flux_variable_upper_bound_skipped_count" => skipped_upper_bound_count,
    )
end

_reduced_dcdfba_is_fixed_flux_bound(model::MetabolicModel, reaction_index::Int)::Bool =
    model.lb[reaction_index] == model.ub[reaction_index]

function _add_reduced_dcdfba_collocation_constraints!(
    collocation_integration_constraints::Array{JuMP.ConstraintRef, 3},
    continuity_constraints::Matrix{JuMP.ConstraintRef},
    initial_condition_constraints::Vector{JuMP.ConstraintRef},
    jump_model::JuMP.Model,
    grid::FiniteElementGrid,
    state_boundary::Matrix{JuMP.VariableRef},
    state_collocation::Array{JuMP.VariableRef, 3},
    state_derivative::Array{JuMP.VariableRef, 3},
    initial_state::AbstractVector,
)
    n_states = size(state_boundary, 1)
    nfe = grid.nfe
    degree = grid.scheme.degree
    integration_matrix = grid.scheme.integration_matrix
    continuity_weights = grid.scheme.continuity_weights

    for i in 1:n_states
        initial_condition_constraints[i] =
            JuMP.@constraint(jump_model, state_boundary[i, 1] == Float64(initial_state[i]))
    end

    for e in 1:nfe
        h = element_length(grid, e)
        for i in 1:n_states
            for j in 1:degree
                collocation_integration_constraints[i, e, j] = JuMP.@constraint(
                    jump_model,
                    state_collocation[i, e, j] ==
                    state_boundary[i, e] +
                    h * sum(integration_matrix[j, k] * state_derivative[i, e, k] for k in 1:degree),
                )
            end
            continuity_constraints[i, e] = JuMP.@constraint(
                jump_model,
                state_boundary[i, e + 1] ==
                state_boundary[i, e] +
                h * sum(continuity_weights[k] * state_derivative[i, e, k] for k in 1:degree),
            )
        end
    end

    return nothing
end

function _reduced_dcdfba_collocation_nlp_metadata(
    kkt_problem::KKTDFBAProblem,
    dimensions::ReducedDCDFBACollocationNLPDimensions,
)::Dict{String, Any}
    roles = kkt_problem.reaction_roles
    return Dict{String, Any}(
        "problem_type" => "reduced_dcdfba_collocation_nlp_scaffold",
        "model_scope" => "reduced",
        "model_id" => kkt_problem.model.model_id,
        "grid_tspan" => kkt_problem.grid.tspan,
        "grid_nfe" => kkt_problem.grid.nfe,
        "collocation_degree" => kkt_problem.grid.scheme.degree,
        "collocation_points" => dimensions.n_collocation_points,
        "jump_model_built" => true,
        "solver_call_performed" => false,
        "optimizer" => "Ipopt",
        "linear_solver" => "mumps",
        "ipopt_required" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "state_variables_built" => true,
        "state_derivative_variables_built" => true,
        "flux_variables_built" => true,
        "base_flux_bounds_applied" => true,
        "dynamic_flux_bounds_built" => false,
        "dynamic_flux_bounds_applied" => false,
        "dynamic_objective_coefficients_built" => false,
        "collocation_integration_constraints_built" => true,
        "finite_element_continuity_constraints_built" => true,
        "initial_condition_constraints_built" => true,
        "ode_rhs_constraints_built" => false,
        "mass_balance_constraints_built" => false,
        "bound_feasibility_constraints_built" => false,
        "stationarity_constraints_built" => false,
        "kkt_constraints_built" => false,
        "mpcc_complementarity_built" => false,
        "direct_collocation_dynamic_constraints_built" => false,
        "objective_description" => "zero-derivative regularization only",
        "sequential_initialization_built" => false,
        "dfvb_kkt_deferred" => true,
        "full_model_kkt_deferred" => true,
        "first_mpcc_target" => "reduced_dfba",
        "sequential_scientific_baseline" => "full_dfba_cold",
        "persistent_lp_warm_start_policy" => "diagnostic_only_not_scientific_equivalence",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "oxygen_exchange_reaction_id" => roles.oxygen_exchange,
        "oxygen_exchange_present" => false,
        "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
        "carbohydrate_exchange_reaction_id" => roles.carbohydrate_exchange,
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "weighted_objective_value_is_biomass_flux" => false,
    )
end

function _reduced_dcdfba_rhs_residual_metadata(
    nlp::ReducedDCDFBACollocationNLP,
    layout::ReducedDCDFBARHSResidualLayout,
    dynamic_control_schedule::Union{Nothing, DynamicControlSchedule} = nothing,
    dynamic_control_decisions::Union{Nothing, ReducedDCDFBADynamicControlDecisionScaffold} =
        nothing,
)::Dict{String, Any}
    roles = nlp.kkt_problem.reaction_roles
    metadata = Dict{String, Any}(
        "ode_rhs_constraints_built" => true,
        "direct_collocation_dynamic_constraints_built" => true,
        "rhs_residual_scaffold_built" => true,
        "rhs_residual_mode_policy" => "fixed_growth_mode_only",
        "rhs_residual_smoothness_policy" => "smooth_sign_assumed_no_max_operators",
        "rhs_residual_total_constraints" => layout.total_rhs_residual_constraints,
        "rhs_residual_state_count" => KKT_DFBA_STATE_COUNT,
        "rhs_residual_uses_flux_variables" => true,
        "rhs_residual_uses_state_collocation_variables" => true,
        "rhs_residual_uses_state_derivative_variables" => true,
        "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
        "oxygen_exchange_reaction_id" => roles.oxygen_exchange,
        "oxygen_exchange_present" => false,
        "carbohydrate_exchange_reaction_id" => roles.carbohydrate_exchange,
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "carbohydrate_exchange_flux_used_in_rhs" => false,
        "dynamic_flux_bounds_applied" => false,
        "mass_balance_constraints_built" => false,
        "bound_feasibility_constraints_built" => false,
        "stationarity_constraints_built" => false,
        "kkt_constraints_built" => false,
        "mpcc_complementarity_built" => false,
        "solver_call_performed" => false,
        "sequential_initialization_built" => false,
        "dfvb_kkt_deferred" => true,
        "full_model_kkt_deferred" => true,
        "first_mpcc_target" => "reduced_dfba",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
    merge!(
        metadata,
        _reduced_dcdfba_mpcc_dynamic_control_metadata(
            dynamic_control_schedule;
            applied_to_rhs = true,
        ),
    )
    if dynamic_control_decisions !== nothing
        merge!(metadata, dynamic_control_decisions.metadata)
        metadata["mpcc_dynamic_control_variable_policy"] =
            "coupled_control_decision_variables"
        metadata["mpcc_dynamic_control_variables_coupled_to_rhs"] = true
        metadata["rhs_residual_uses_control_decision_variables"] = true
        metadata["fully_simultaneous_controls"] = true
    else
        metadata["rhs_residual_uses_control_decision_variables"] = false
    end
    metadata["rhs_residual_dynamic_control_policy"] =
        dynamic_control_decisions !== nothing ?
        "coupled_dynamic_control_temperature_nutrient_and_volatilization_rhs_rates" :
        dynamic_control_schedule === nothing ?
        "static_temperature_no_control_rhs_rates" :
        "fixed_dynamic_control_schedule_temperature_nutrient_and_volatilization_rhs_rates"
    return metadata
end
