"""
    validate_model_files(paths; throw_on_error=true)

Check that the required reduced-model files exist.
"""
function validate_model_files(paths::ReducedModelPaths; throw_on_error::Bool = true)
    expected = Dict(
        "S" => paths.s_path,
        "lb" => paths.lb_path,
        "ub" => paths.ub_path,
        "rxn_list" => paths.rxn_list_path,
        "met_list" => paths.met_list_path,
    )
    if paths.indices_path !== nothing
        expected["indices"] = paths.indices_path
    end

    missing = Dict{String, String}()
    for (label, path) in expected
        if !isfile(path)
            missing[label] = path
        end
    end

    if throw_on_error && !isempty(missing)
        details = join(["$label => $path" for (label, path) in sort(collect(missing))], ", ")
        error("Missing reduced-model files: $details")
    end

    return (ok = isempty(missing), missing = missing)
end

"""
    validate_model_files(paths::FullModelPaths; throw_on_error=true)

Check that the required full-model files exist.
"""
function validate_model_files(paths::FullModelPaths; throw_on_error::Bool = true)
    expected = Dict(
        "S" => paths.s_path,
        "lb" => paths.lb_path,
        "ub" => paths.ub_path,
    )

    missing = Dict{String, String}()
    for (label, path) in expected
        if !isfile(path)
            missing[label] = path
        end
    end

    if throw_on_error && !isempty(missing)
        details = join(["$label => $path" for (label, path) in sort(collect(missing))], ", ")
        error("Missing full-model files: $details")
    end

    return (ok = isempty(missing), missing = missing)
end

function validate_model_files(config_path::AbstractString; throw_on_error::Bool = true)
    return validate_model_files(load_reduced_model_paths(config_path); throw_on_error = throw_on_error)
end
