"""
    load_full_model(paths)

Load a full metabolic model from CSV artifacts where reaction IDs are stored
as `S_matrix.csv` headers and metabolite IDs are stored in `metabolite_id`.
"""
function load_full_model(paths::FullModelPaths)::MetabolicModel
    validate_model_files(paths)

    S, rxn_ids, met_ids = _read_full_stoichiometric_matrix(paths.s_path)
    lb = _read_full_numeric_vector(paths.lb_path, "lb")
    ub = _read_full_numeric_vector(paths.ub_path, "ub")

    model = MetabolicModel(S, lb, ub, rxn_ids, met_ids; model_id = paths.model_id)
    validate_full_model_dimensions(model; throw_on_error = true)
    return model
end

function load_full_model(config_path::AbstractString)
    return load_full_model(load_full_model_paths(config_path))
end

"""
    validate_full_model_dimensions(model; throw_on_error=false)

Validate consistency among full-model S, bounds, reaction IDs, and metabolite
IDs.
"""
function validate_full_model_dimensions(model::MetabolicModel; throw_on_error::Bool = false)
    errors = String[]
    n_mets, n_rxns = size(model.S)

    if n_rxns != length(model.rxn_ids)
        push!(errors, "S has $n_rxns columns but rxn_ids has $(length(model.rxn_ids)) entries.")
    end
    if n_mets != length(model.met_ids)
        push!(errors, "S has $n_mets rows but met_ids has $(length(model.met_ids)) entries.")
    end
    if length(model.lb) != length(model.rxn_ids)
        push!(errors, "lb has $(length(model.lb)) entries but rxn_ids has $(length(model.rxn_ids)) entries.")
    end
    if length(model.ub) != length(model.rxn_ids)
        push!(errors, "ub has $(length(model.ub)) entries but rxn_ids has $(length(model.rxn_ids)) entries.")
    end
    _append_id_validation_errors!(errors, model.rxn_ids, "reaction IDs")
    _append_id_validation_errors!(errors, model.met_ids, "metabolite IDs")
    if any(!isfinite, model.lb)
        push!(errors, "lb contains NaN or Inf values.")
    end
    if any(!isfinite, model.ub)
        push!(errors, "ub contains NaN or Inf values.")
    end
    if any(!isfinite, nonzeros(model.S))
        push!(errors, "S contains NaN or Inf values.")
    end
    if length(model.lb) == length(model.ub) && any(model.lb .> model.ub)
        bad_count = count(model.lb .> model.ub)
        push!(errors, "Found $bad_count bound pairs with lb > ub.")
    end

    if throw_on_error && !isempty(errors)
        error("Invalid full model dimensions: " * join(errors, " "))
    end

    return (ok = isempty(errors), errors = errors)
end

function _read_full_stoichiometric_matrix(path::AbstractString)
    raw_header = _read_full_csv_header(path)
    length(raw_header) >= 2 || error("Full S matrix must include metabolite_id and at least one reaction column: $path")
    raw_header[1] == "metabolite_id" || error(
        "Full S matrix first column must be metabolite_id, got $(raw_header[1]) in $path",
    )

    rxn_ids = String.(strip.(raw_header[2:end]))
    _validate_id_vector!(rxn_ids, "reaction IDs", path)

    table = DataFrame(CSV.File(path))
    ncol(table) == length(raw_header) || error(
        "Full S matrix parsed column count $(ncol(table)) does not match header count $(length(raw_header)) in $path",
    )
    names(table)[1] == "metabolite_id" || error(
        "Full S matrix parsed first column must be metabolite_id, got $(names(table)[1]) in $path",
    )

    met_ids = _read_full_metabolite_ids(table[!, 1], path)
    reaction_columns = names(table)[2:end]
    size(table, 2) - 1 == length(rxn_ids) || error(
        "Full S matrix has $(size(table, 2) - 1) reaction columns but $(length(rxn_ids)) reaction IDs.",
    )

    S = Matrix{Float64}(undef, nrow(table), length(reaction_columns))
    for (j, column_name) in enumerate(reaction_columns)
        S[:, j] = _to_finite_float_vector(table[!, column_name], path, column_name)
    end
    return S, rxn_ids, met_ids
end

function _read_full_csv_header(path::AbstractString)
    isfile(path) || error("Full S matrix file not found: $path")
    header_line = readline(path)
    isempty(strip(header_line)) && error("Full S matrix header is empty: $path")
    return String.(strip.(split(header_line, ",")))
end

function _read_full_metabolite_ids(values, path::AbstractString)
    ids = String[]
    for (i, value) in enumerate(values)
        ismissing(value) && error("Missing metabolite ID in $path row $i")
        id = strip(String(value))
        isempty(id) && error("Empty metabolite ID in $path row $i")
        push!(ids, id)
    end
    _validate_id_vector!(ids, "metabolite IDs", path)
    return ids
end

function _read_full_numeric_vector(path::AbstractString, label::AbstractString)
    table = DataFrame(CSV.File(path; header = false))
    ncol(table) >= 1 || error("Expected at least one column in full-model $label vector file: $path")

    candidates = Vector{Float64}[]
    for column_name in names(table)
        parsed = try
            _parse_full_numeric_vector_column(table[!, column_name], path, column_name)
        catch
            nothing
        end
        parsed === nothing && continue
        push!(candidates, parsed)
    end
    isempty(candidates) && error("No numeric columns found in full-model $label vector file: $path")

    lengths = length.(candidates)
    return candidates[findlast(==(maximum(lengths)), lengths)]
end

function _parse_full_numeric_vector_column(values, path::AbstractString, column_name)
    output = Float64[]
    skipped_header = false
    for (i, value) in enumerate(values)
        ismissing(value) && error("Missing numeric value in $path column $column_name row $i")
        parsed = if value isa Real
            Float64(value)
        else
            tryparse(Float64, strip(String(value)))
        end

        if parsed === nothing
            if i == 1 && !skipped_header
                skipped_header = true
                continue
            end
            error("Non-numeric value in $path column $column_name row $i: $value")
        end
        isfinite(parsed) || error("Non-finite numeric value in $path column $column_name row $i: $value")
        push!(output, parsed)
    end
    isempty(output) && error("No numeric values found in $path column $column_name")
    return output
end

function _to_finite_float_vector(values, path::AbstractString, column_name)
    output = _to_float_vector(values, path, column_name)
    bad_index = findfirst(value -> !isfinite(value), output)
    bad_index === nothing || error(
        "Non-finite numeric value in $path column $column_name row $bad_index: $(output[bad_index])",
    )
    return output
end

function _validate_id_vector!(ids::AbstractVector{String}, label::AbstractString, path::AbstractString)
    errors = String[]
    _append_id_validation_errors!(errors, ids, label)
    isempty(errors) || error("Invalid $label in $path: " * join(errors, " "))
    return nothing
end

function _append_id_validation_errors!(
    errors::Vector{String},
    ids::AbstractVector{<:AbstractString},
    label::AbstractString,
)
    cleaned = String.(strip.(ids))
    empty_indices = findall(isempty, cleaned)
    if !isempty(empty_indices)
        push!(errors, "$label contain empty entries at indices $(empty_indices).")
    end

    seen = Set{String}()
    duplicated = Set{String}()
    for id in cleaned
        id in seen && push!(duplicated, id)
        push!(seen, id)
    end
    if !isempty(duplicated)
        push!(errors, "$label contain duplicated entries: $(join(sort(collect(duplicated)), ", ")).")
    end
    return errors
end
