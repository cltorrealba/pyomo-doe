"""
    load_reduced_model(paths; model_id="reduced_model")

Load a reduced metabolic model from MATLAB-exported CSV artifacts.
"""
function load_reduced_model(paths::ReducedModelPaths; model_id::AbstractString = "reduced_model")
    validate_model_files(paths)

    rxn_ids = _read_id_list(paths.rxn_list_path)
    met_ids = _read_id_list(paths.met_list_path)
    S = _read_stoichiometric_matrix(paths.s_path, length(rxn_ids))
    lb = _read_numeric_vector(paths.lb_path)
    ub = _read_numeric_vector(paths.ub_path)

    model = MetabolicModel(S, lb, ub, rxn_ids, met_ids; model_id = model_id)
    validate_reduced_model_dimensions(model; throw_on_error = true)
    return model
end

function load_reduced_model(config_path::AbstractString)
    config = load_config(config_path)
    model_id = get(config["reduced_model"], "model_id", "reduced_model")
    return load_reduced_model(load_reduced_model_paths(config_path); model_id = model_id)
end

"""
    validate_reduced_model_dimensions(model; throw_on_error=false)

Validate consistency among S, bounds, reaction IDs, and metabolite IDs.
"""
function validate_reduced_model_dimensions(model::MetabolicModel; throw_on_error::Bool = false)
    errors = String[]
    n_mets, n_rxns = size(model.S)

    if n_rxns != length(model.rxn_ids)
        push!(errors, "S has $n_rxns columns but rxn_ids has $(length(model.rxn_ids)) entries.")
    end
    if n_mets != length(model.met_ids)
        push!(errors, "S has $n_mets rows but met_ids has $(length(model.met_ids)) entries.")
    end
    if length(model.lb) != length(model.rxn_ids)
        push!(errors, "lb has $(length(model.lb)) entries but rxn_ids has $(length(model.rxn_ids)) entries.")
    end
    if length(model.ub) != length(model.rxn_ids)
        push!(errors, "ub has $(length(model.ub)) entries but rxn_ids has $(length(model.rxn_ids)) entries.")
    end
    if length(model.lb) == length(model.ub) && any(model.lb .> model.ub)
        bad_count = count(model.lb .> model.ub)
        push!(errors, "Found $bad_count bound pairs with lb > ub.")
    end

    if throw_on_error && !isempty(errors)
        error("Invalid reduced model dimensions: " * join(errors, " "))
    end

    return (ok = isempty(errors), errors = errors)
end

function _read_id_list(path::AbstractString)
    table = DataFrame(CSV.File(path))
    ncol(table) >= 1 || error("Expected at least one column in ID file: $path")
    values = table[!, 1]
    ids = String[]
    for value in values
        if !ismissing(value)
            id = strip(String(value))
            if !isempty(id)
                push!(ids, id)
            end
        end
    end
    return ids
end

function _read_numeric_vector(path::AbstractString)
    table = DataFrame(CSV.File(path))
    ncol(table) >= 1 || error("Expected at least one column in numeric vector file: $path")

    columns = names(table)
    selected = if ncol(table) == 1
        columns[1]
    else
        numeric_columns = [name for name in columns if _is_numeric_column(table[!, name])]
        isempty(numeric_columns) && error("No numeric columns found in $path")
        last(numeric_columns)
    end

    return _to_float_vector(table[!, selected], path, selected)
end

function _read_stoichiometric_matrix(path::AbstractString, expected_n_rxns::Integer)
    table = DataFrame(CSV.File(path))
    columns = names(table)

    selected_columns = if length(columns) == expected_n_rxns
        columns
    elseif length(columns) == expected_n_rxns + 1
        columns[2:end]
    else
        numeric_columns = [name for name in columns if _is_numeric_column(table[!, name])]
        if length(numeric_columns) == expected_n_rxns
            numeric_columns
        else
            error(
                "S matrix column count does not match reaction IDs. " *
                "Found $(length(columns)) CSV columns, $(length(numeric_columns)) numeric columns, " *
                "and $expected_n_rxns reaction IDs.",
            )
        end
    end

    n_rows = nrow(table)
    matrix = Matrix{Float64}(undef, n_rows, length(selected_columns))
    for (j, column_name) in enumerate(selected_columns)
        matrix[:, j] = _to_float_vector(table[!, column_name], path, column_name)
    end
    return matrix
end

function _to_float_vector(values, path::AbstractString, column_name)
    output = Vector{Float64}(undef, length(values))
    for (i, value) in enumerate(values)
        if ismissing(value)
            error("Missing numeric value in $path column $column_name row $i")
        elseif value isa Real
            output[i] = Float64(value)
        else
            parsed = tryparse(Float64, strip(String(value)))
            parsed === nothing && error("Non-numeric value in $path column $column_name row $i: $value")
            output[i] = parsed
        end
    end
    return output
end

function _is_numeric_column(values)
    for value in values
        if ismissing(value)
            return false
        elseif value isa Real
            continue
        elseif tryparse(Float64, strip(String(value))) === nothing
            return false
        end
    end
    return true
end
