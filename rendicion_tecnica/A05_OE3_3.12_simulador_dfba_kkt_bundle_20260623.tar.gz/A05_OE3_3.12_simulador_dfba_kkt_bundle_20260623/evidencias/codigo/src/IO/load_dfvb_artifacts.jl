const DFVB_ARTIFACT_CONFIG_KEYS = (
    "manifest",
    "reaction_order",
    "reduced_dfba_reaction_order",
    "exchange_partition",
    "exchange_partition_active_alpha",
    "n_sparse_triplets",
    "n_column_metadata",
    "n_active_alpha_sparse_triplets",
    "n_active_alpha_column_metadata",
    "active_alpha_indices",
    "alpha_bounds",
    "alpha_bounds_active",
    "alpha_trajectories",
    "alpha_trajectories_active",
    "state_trajectories",
    "inactive_reactions",
    "inactive_reactions_active_alpha",
)

const DFVB_ARTIFACT_STATE_COLUMNS = [
    "time",
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

const DFVB_ARTIFACT_OXYGEN_MAPPING_NOTE =
    "DFVB exchange partition marks r_0001 as exchange; this is not used as oxygen. " *
    "Oxygen reaction r_1992 remains a fermentation oxygen exchange identifier in dFBA policies."
const DFVB_ARTIFACT_EXCHANGE_PARTITION_NOTE =
    "The exported MATLAB exchange partition contains only one exchange reaction; review before DFVB biological interpretation."
const DFVB_ARTIFACT_REDUCED_ORDER_NOTE =
    "MATLAB DFVB-derived reduced reaction order is distinct from current Julia reduced model reaction list until validated."

"""
    load_dfvb_artifact_paths(config_path)

Load and resolve MATLAB-exported DFVB artifact paths from a TOML config.
"""
function load_dfvb_artifact_paths(config_path::AbstractString)::DFVBArtifactPaths
    config = load_config(config_path)
    project_root = _config_project_root(config_path)
    artifact_id = _required_config_value(config, "artifact_id", config_path)
    base_dir = _resolve_path(project_root, _required_config_value(config, "base_dir", config_path))

    for key in DFVB_ARTIFACT_CONFIG_KEYS
        _required_config_value(config, key, config_path)
    end

    return DFVBArtifactPaths(
        artifact_id,
        _resolve_path(base_dir, config["manifest"]),
        _resolve_path(base_dir, config["reaction_order"]),
        _resolve_path(base_dir, config["reduced_dfba_reaction_order"]),
        _resolve_path(base_dir, config["exchange_partition"]),
        _resolve_path(base_dir, config["exchange_partition_active_alpha"]),
        _resolve_path(base_dir, config["n_sparse_triplets"]),
        _resolve_path(base_dir, config["n_column_metadata"]),
        _resolve_path(base_dir, config["n_active_alpha_sparse_triplets"]),
        _resolve_path(base_dir, config["n_active_alpha_column_metadata"]),
        _resolve_path(base_dir, config["active_alpha_indices"]),
        _resolve_path(base_dir, config["alpha_bounds"]),
        _resolve_path(base_dir, config["alpha_bounds_active"]),
        _resolve_path(base_dir, config["alpha_trajectories"]),
        _resolve_path(base_dir, config["alpha_trajectories_active"]),
        _resolve_path(base_dir, config["state_trajectories"]),
        _resolve_path(base_dir, config["inactive_reactions"]),
        _resolve_path(base_dir, config["inactive_reactions_active_alpha"]),
    )
end

"""
    validate_dfvb_artifact_files(paths; throw_on_error=true)

Check that every configured DFVB artifact file exists.
"""
function validate_dfvb_artifact_files(paths::DFVBArtifactPaths; throw_on_error::Bool = true)
    expected = Dict(
        "manifest" => paths.manifest_path,
        "reaction_order" => paths.reaction_order_path,
        "reduced_dfba_reaction_order" => paths.reduced_dfba_reaction_order_path,
        "exchange_partition" => paths.exchange_partition_path,
        "exchange_partition_active_alpha" => paths.exchange_partition_active_alpha_path,
        "n_sparse_triplets" => paths.n_sparse_triplets_path,
        "n_column_metadata" => paths.n_column_metadata_path,
        "n_active_alpha_sparse_triplets" => paths.n_active_alpha_sparse_triplets_path,
        "n_active_alpha_column_metadata" => paths.n_active_alpha_column_metadata_path,
        "active_alpha_indices" => paths.active_alpha_indices_path,
        "alpha_bounds" => paths.alpha_bounds_path,
        "alpha_bounds_active" => paths.alpha_bounds_active_path,
        "alpha_trajectories" => paths.alpha_trajectories_path,
        "alpha_trajectories_active" => paths.alpha_trajectories_active_path,
        "state_trajectories" => paths.state_trajectories_path,
        "inactive_reactions" => paths.inactive_reactions_path,
        "inactive_reactions_active_alpha" => paths.inactive_reactions_active_alpha_path,
    )

    missing = Dict{String, String}()
    for (label, path) in expected
        isfile(path) || (missing[label] = path)
    end

    if throw_on_error && !isempty(missing)
        details = join(["$label => $path" for (label, path) in sort(collect(missing))], ", ")
        error("Missing DFVB artifact files: $details")
    end

    return (ok = isempty(missing), missing = missing)
end

"""
    load_dfvb_artifact_manifest(path)

Load the flat MATLAB-exported DFVB JSON manifest without adding a JSON package.
"""
function load_dfvb_artifact_manifest(path::AbstractString)::DFVBArtifactManifest
    raw = _parse_dfvb_flat_json_manifest(read(path, String), path)
    required = (
        "n_reactions",
        "n_metabolites",
        "n_null_basis_columns",
        "n_exchange_reactions",
        "n_internal_reactions",
        "n_dfvb_time_points",
        "has_active_alpha_subset",
        "n_active_alpha_columns",
    )
    for key in required
        haskey(raw, key) || error("Missing required DFVB manifest key $key in $path")
    end

    return DFVBArtifactManifest(
        _manifest_positive_int(raw, "n_reactions"),
        _manifest_positive_int(raw, "n_metabolites"),
        _manifest_positive_int(raw, "n_null_basis_columns"),
        _manifest_positive_int(raw, "n_exchange_reactions"),
        _manifest_positive_int(raw, "n_internal_reactions"),
        _manifest_positive_int(raw, "n_dfvb_time_points"),
        _manifest_bool(raw, "has_active_alpha_subset"),
        _manifest_positive_int(raw, "n_active_alpha_columns"),
        raw,
    )
end

"""
    load_dfvb_artifacts(paths; kwargs...)

Load MATLAB-exported DFVB artifacts. This only loads and validates artifact
shape contracts; it does not build or solve a DFVB optimization problem.
"""
function load_dfvb_artifacts(
    paths::DFVBArtifactPaths;
    load_alpha_trajectories::Bool = true,
    load_active_alpha_trajectories::Bool = true,
    load_state_trajectories::Bool = true,
)::DFVBArtifacts
    validate_dfvb_artifact_files(paths)
    manifest = load_dfvb_artifact_manifest(paths.manifest_path)

    reaction_order = _load_dfvb_table(
        paths.reaction_order_path,
        [
            "reaction_index",
            "reaction_id",
            "is_exchange",
            "is_internal",
            "exchange_position",
            "internal_position",
            "is_active_exchange",
            "is_active_internal",
            "is_inactive_exchange",
            "is_inactive_internal",
            "model_scope",
        ],
    )
    reduced_dfba_reaction_order = _load_dfvb_table(
        paths.reduced_dfba_reaction_order_path,
        ["reduced_reaction_index", "original_reaction_index", "reaction_id"],
    )
    exchange_partition = _load_dfvb_table(
        paths.exchange_partition_path,
        ["model_scope", "partition", "partition_position", "reaction_index", "reaction_id", "is_active", "is_inactive_forced_zero"],
    )
    exchange_partition_active_alpha = _load_dfvb_table(
        paths.exchange_partition_active_alpha_path,
        ["model_scope", "partition", "partition_position", "reaction_index", "reaction_id", "is_active", "is_inactive_forced_zero"],
    )

    N = _load_sparse_triplet_matrix(
        paths.n_sparse_triplets_path,
        manifest.n_reactions,
        manifest.n_null_basis_columns,
    )
    N_column_metadata = _load_dfvb_table(
        paths.n_column_metadata_path,
        ["alpha_index", "source_alpha_index", "source_alpha_id", "is_active", "model_scope"],
    )
    N_active = _load_sparse_triplet_matrix(
        paths.n_active_alpha_sparse_triplets_path,
        manifest.n_reactions,
        manifest.n_active_alpha_columns,
    )
    N_active_column_metadata = _load_dfvb_table(
        paths.n_active_alpha_column_metadata_path,
        ["alpha_index", "source_alpha_index", "source_alpha_id", "is_active", "model_scope"],
    )
    active_alpha_indices = _load_dfvb_table(
        paths.active_alpha_indices_path,
        ["active_alpha_index", "source_alpha_index", "source_alpha_id"],
    )
    alpha_bounds = _load_dfvb_table(
        paths.alpha_bounds_path,
        ["alpha_index", "source_alpha_index", "source_alpha_id", "lower_bound", "upper_bound", "model_scope"],
    )
    alpha_bounds_active = _load_dfvb_table(
        paths.alpha_bounds_active_path,
        ["alpha_index", "source_alpha_index", "source_alpha_id", "lower_bound", "upper_bound", "model_scope"],
    )
    alpha_trajectories = load_alpha_trajectories ? _load_dfvb_table(paths.alpha_trajectories_path, ["time"]) : nothing
    alpha_trajectories_active =
        load_active_alpha_trajectories ? _load_dfvb_table(paths.alpha_trajectories_active_path, ["time"]) : nothing
    state_trajectories = load_state_trajectories ? _load_dfvb_table(paths.state_trajectories_path, DFVB_ARTIFACT_STATE_COLUMNS) : nothing
    inactive_reactions = _load_dfvb_table(paths.inactive_reactions_path, ["model_scope", "partition", "reaction_id"])
    inactive_reactions_active_alpha =
        _load_dfvb_table(paths.inactive_reactions_active_alpha_path, ["model_scope", "partition", "reaction_id"])

    metadata = Dict{String, Any}(
        "artifact_id" => paths.artifact_id,
        "model_scope" => "matlab_full_dfvb_export",
        "n_reactions" => manifest.n_reactions,
        "n_metabolites" => manifest.n_metabolites,
        "n_null_basis_columns" => manifest.n_null_basis_columns,
        "n_active_alpha_columns" => manifest.n_active_alpha_columns,
        "n_exchange_reactions" => manifest.n_exchange_reactions,
        "n_internal_reactions" => manifest.n_internal_reactions,
        "n_dfvb_time_points" => manifest.n_dfvb_time_points,
        "indices_are_matlab_1_based" => true,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "oxygen_mapping_note" => DFVB_ARTIFACT_OXYGEN_MAPPING_NOTE,
        "exchange_partition_note" => DFVB_ARTIFACT_EXCHANGE_PARTITION_NOTE,
        "reduced_dfba_reaction_order_note" => DFVB_ARTIFACT_REDUCED_ORDER_NOTE,
        "dfvb_solve_implemented" => false,
    )

    return DFVBArtifacts(
        paths,
        manifest,
        reaction_order,
        reduced_dfba_reaction_order,
        exchange_partition,
        exchange_partition_active_alpha,
        N,
        N_column_metadata,
        N_active,
        N_active_column_metadata,
        active_alpha_indices,
        alpha_bounds,
        alpha_bounds_active,
        alpha_trajectories,
        alpha_trajectories_active,
        state_trajectories,
        inactive_reactions,
        inactive_reactions_active_alpha,
        metadata,
    )
end

function load_dfvb_artifacts(config_path::AbstractString; kwargs...)::DFVBArtifacts
    return load_dfvb_artifacts(load_dfvb_artifact_paths(config_path); kwargs...)
end

"""
    validate_dfvb_artifacts(artifacts)

Validate loaded DFVB artifact dimensions and report scientific caveats.
"""
function validate_dfvb_artifacts(artifacts::DFVBArtifacts)::DFVBArtifactValidationReport
    errors = String[]
    warnings = String[]
    manifest = artifacts.manifest

    _check_equal!(errors, size(artifacts.N), (manifest.n_reactions, manifest.n_null_basis_columns), "N size")
    _check_equal!(errors, size(artifacts.N_active), (manifest.n_reactions, manifest.n_active_alpha_columns), "N_active size")
    _check_equal!(errors, nrow(artifacts.reaction_order), manifest.n_reactions, "reaction_order row count")
    _check_equal!(errors, nrow(artifacts.exchange_partition), manifest.n_reactions, "exchange_partition row count")
    _check_equal!(errors, nrow(artifacts.N_column_metadata), manifest.n_null_basis_columns, "N_column_metadata row count")
    _check_equal!(errors, nrow(artifacts.N_active_column_metadata), manifest.n_active_alpha_columns, "N_active_column_metadata row count")
    _check_equal!(errors, nrow(artifacts.active_alpha_indices), manifest.n_active_alpha_columns, "active_alpha_indices row count")
    _check_equal!(errors, nrow(artifacts.alpha_bounds), manifest.n_null_basis_columns, "alpha_bounds row count")
    _check_equal!(errors, nrow(artifacts.alpha_bounds_active), manifest.n_active_alpha_columns, "alpha_bounds_active row count")

    if artifacts.alpha_trajectories !== nothing
        _check_equal!(errors, nrow(artifacts.alpha_trajectories), manifest.n_dfvb_time_points, "alpha_trajectories row count")
        _check_equal!(
            errors,
            ncol(artifacts.alpha_trajectories),
            manifest.n_null_basis_columns + 1,
            "alpha_trajectories column count",
        )
    end
    if artifacts.alpha_trajectories_active !== nothing
        _check_equal!(
            errors,
            nrow(artifacts.alpha_trajectories_active),
            manifest.n_dfvb_time_points,
            "alpha_trajectories_active row count",
        )
        _check_equal!(
            errors,
            ncol(artifacts.alpha_trajectories_active),
            manifest.n_active_alpha_columns + 1,
            "alpha_trajectories_active column count",
        )
    end
    if artifacts.state_trajectories !== nothing
        _check_equal!(errors, nrow(artifacts.state_trajectories), manifest.n_dfvb_time_points, "state_trajectories row count")
        missing_state_columns = setdiff(DFVB_ARTIFACT_STATE_COLUMNS, names(artifacts.state_trajectories))
        isempty(missing_state_columns) || push!(
            errors,
            "state_trajectories is missing expected columns: $(join(missing_state_columns, ", ")).",
        )
    end

    critical = _dfvb_critical_reaction_statuses(artifacts)
    exchange_ids = _dfvb_exchange_reaction_ids(artifacts.exchange_partition)
    if exchange_ids == ["r_0001"]
        push!(warnings, "DFVB exchange partition contains only r_0001 as exchange; do not interpret r_0001 as oxygen.")
    elseif "r_0001" in exchange_ids
        push!(warnings, "DFVB exchange partition includes r_0001; do not interpret r_0001 as oxygen.")
    end
    if get(get(critical, "r_1992", Dict{String, Any}()), "is_internal", false) == true
        push!(warnings, "DFVB reaction r_1992 is marked internal in the exported partition.")
    end
    if get(get(critical, "r_4048", Dict{String, Any}()), "is_internal", false) == true
        push!(warnings, "DFVB reaction r_4048 is marked internal in the exported partition.")
    end
    if nrow(artifacts.reduced_dfba_reaction_order) != 1488
        push!(
            warnings,
            "dfvb_reduced_dfba_reaction_order.csv has $(nrow(artifacts.reduced_dfba_reaction_order)) rows, distinct from the current Julia reduced model count 1488.",
        )
    end
    push!(warnings, "DFVB artifact loader validates exported files and preserves MATLAB trajectory tables; dynamic RHS and report code are separate.")

    summary = Dict{String, Any}(
        "artifact_id" => artifacts.paths.artifact_id,
        "n_reactions" => manifest.n_reactions,
        "n_metabolites" => manifest.n_metabolites,
        "n_null_basis_columns" => manifest.n_null_basis_columns,
        "n_active_alpha_columns" => manifest.n_active_alpha_columns,
        "n_exchange_reactions" => manifest.n_exchange_reactions,
        "n_internal_reactions" => manifest.n_internal_reactions,
        "n_dfvb_time_points" => manifest.n_dfvb_time_points,
        "N_size" => size(artifacts.N),
        "N_nnz" => nnz(artifacts.N),
        "N_active_size" => size(artifacts.N_active),
        "N_active_nnz" => nnz(artifacts.N_active),
        "critical_reactions" => critical,
        "r0001_used_as_oxygen" => false,
        "indices_reacciones_used" => false,
    )
    return DFVBArtifactValidationReport(isempty(errors), errors, warnings, summary)
end

function _load_dfvb_table(path::AbstractString, required_columns::AbstractVector{<:AbstractString})::DataFrame
    table = DataFrame(CSV.File(path))
    missing_columns = setdiff(String.(required_columns), names(table))
    isempty(missing_columns) || error(
        "DFVB artifact table $path is missing required columns: $(join(missing_columns, ", ")).",
    )
    return table
end

function _load_sparse_triplet_matrix(path::AbstractString, n_rows::Int, n_cols::Int)::SparseMatrixCSC{Float64, Int}
    table = _load_dfvb_table(path, ["row_index", "column_index", "value"])
    rows = Vector{Int}(undef, nrow(table))
    cols = Vector{Int}(undef, nrow(table))
    vals = Vector{Float64}(undef, nrow(table))
    for i in axes(table, 1)
        row = _dfvb_required_int(table[i, "row_index"], path, "row_index", i)
        col = _dfvb_required_int(table[i, "column_index"], path, "column_index", i)
        val = _dfvb_required_float(table[i, "value"], path, "value", i)
        1 <= row <= n_rows || error("Sparse triplet row_index $row outside 1:$n_rows in $path row $i.")
        1 <= col <= n_cols || error("Sparse triplet column_index $col outside 1:$n_cols in $path row $i.")
        rows[i] = row
        cols[i] = col
        vals[i] = val
    end
    return sparse(rows, cols, vals, n_rows, n_cols)
end

function _manifest_positive_int(raw::Dict{String, Any}, key::AbstractString)::Int
    value = raw[String(key)]
    int_value = if value isa Integer
        Int(value)
    elseif value isa AbstractFloat && isinteger(value)
        Int(value)
    else
        error("DFVB manifest key $key must be an integer, got $(repr(value)).")
    end
    int_value > 0 || error("DFVB manifest key $key must be positive, got $int_value.")
    return int_value
end

function _manifest_bool(raw::Dict{String, Any}, key::AbstractString)::Bool
    value = raw[String(key)]
    value isa Bool || error("DFVB manifest key $key must be a Bool, got $(repr(value)).")
    return value
end

function _dfvb_required_int(value, path::AbstractString, column::AbstractString, row::Integer)::Int
    ismissing(value) && error("Missing integer value in $path column $column row $row.")
    if value isa Integer
        return Int(value)
    elseif value isa AbstractFloat && isinteger(value)
        return Int(value)
    else
        parsed = tryparse(Int, strip(String(value)))
        parsed === nothing && error("Non-integer value in $path column $column row $row: $value")
        return parsed
    end
end

function _dfvb_required_float(value, path::AbstractString, column::AbstractString, row::Integer)::Float64
    ismissing(value) && error("Missing numeric value in $path column $column row $row.")
    parsed = value isa Real ? Float64(value) : tryparse(Float64, strip(String(value)))
    parsed === nothing && error("Non-numeric value in $path column $column row $row: $value")
    isfinite(parsed) || error("Non-finite numeric value in $path column $column row $row: $value")
    return parsed
end

function _check_equal!(errors::Vector{String}, observed, expected, label::AbstractString)
    observed == expected || push!(errors, "$label expected $expected, got $observed.")
    return errors
end

function _dfvb_exchange_reaction_ids(exchange_partition::DataFrame)::Vector{String}
    return String.(
        exchange_partition[
            String.(exchange_partition[!, "partition"]) .== "exchange",
            "reaction_id",
        ],
    )
end

function _dfvb_critical_reaction_statuses(artifacts::DFVBArtifacts)::Dict{String, Any}
    output = Dict{String, Any}()
    for reaction_id in ("r_0001", "r_1992", "r_2111", "r_4048")
        output[reaction_id] = _dfvb_reaction_status(artifacts, reaction_id)
    end
    return output
end

function _dfvb_reaction_status(artifacts::DFVBArtifacts, reaction_id::AbstractString)::Dict{String, Any}
    row_index = findfirst(==(String(reaction_id)), String.(artifacts.reaction_order[!, "reaction_id"]))
    partition_row_index = findfirst(==(String(reaction_id)), String.(artifacts.exchange_partition[!, "reaction_id"]))
    status = Dict{String, Any}(
        "reaction_id" => String(reaction_id),
        "found" => row_index !== nothing,
        "partition_found" => partition_row_index !== nothing,
    )
    if row_index !== nothing
        row = artifacts.reaction_order[row_index, :]
        status["reaction_index"] = Int(row["reaction_index"])
        status["is_exchange"] = Bool(row["is_exchange"])
        status["is_internal"] = Bool(row["is_internal"])
        status["is_active_exchange"] = Bool(row["is_active_exchange"])
        status["is_active_internal"] = Bool(row["is_active_internal"])
    end
    if partition_row_index !== nothing
        row = artifacts.exchange_partition[partition_row_index, :]
        status["partition"] = String(row["partition"])
        status["partition_position"] = Int(row["partition_position"])
        status["partition_is_active"] = Bool(row["is_active"])
        status["partition_is_inactive_forced_zero"] = Bool(row["is_inactive_forced_zero"])
    end
    return status
end

function _parse_dfvb_flat_json_manifest(text::AbstractString, path::AbstractString)::Dict{String, Any}
    parser = Ref((text = String(text), index = firstindex(String(text)), path = String(path)))
    return _dfvb_json_parse_object!(parser)
end

function _dfvb_json_parse_object!(parser)::Dict{String, Any}
    _dfvb_json_skip_ws!(parser)
    _dfvb_json_take!(parser, '{')
    output = Dict{String, Any}()
    _dfvb_json_skip_ws!(parser)
    if _dfvb_json_peek(parser) == '}'
        _dfvb_json_take!(parser, '}')
        return output
    end
    while true
        _dfvb_json_skip_ws!(parser)
        key = _dfvb_json_parse_string!(parser)
        _dfvb_json_skip_ws!(parser)
        _dfvb_json_take!(parser, ':')
        output[key] = _dfvb_json_parse_value!(parser)
        _dfvb_json_skip_ws!(parser)
        next_char = _dfvb_json_peek(parser)
        if next_char == ','
            _dfvb_json_take!(parser, ',')
        elseif next_char == '}'
            _dfvb_json_take!(parser, '}')
            _dfvb_json_skip_ws!(parser)
            _dfvb_json_eof(parser) || _dfvb_json_error(parser, "Unexpected trailing content.")
            return output
        else
            _dfvb_json_error(parser, "Expected comma or object terminator.")
        end
    end
end

function _dfvb_json_parse_value!(parser)
    _dfvb_json_skip_ws!(parser)
    char = _dfvb_json_peek(parser)
    if char == '"'
        return _dfvb_json_parse_string!(parser)
    elseif char == '['
        return _dfvb_json_parse_array!(parser)
    elseif char == 't'
        _dfvb_json_take_literal!(parser, "true")
        return true
    elseif char == 'f'
        _dfvb_json_take_literal!(parser, "false")
        return false
    elseif char == 'n'
        _dfvb_json_take_literal!(parser, "null")
        return nothing
    elseif char == '{'
        _dfvb_json_error(parser, "Nested JSON objects are not supported by the DFVB manifest parser.")
    else
        return _dfvb_json_parse_number!(parser)
    end
end

function _dfvb_json_parse_array!(parser)::Vector{Any}
    _dfvb_json_take!(parser, '[')
    values = Any[]
    _dfvb_json_skip_ws!(parser)
    if _dfvb_json_peek(parser) == ']'
        _dfvb_json_take!(parser, ']')
        return values
    end
    while true
        push!(values, _dfvb_json_parse_value!(parser))
        _dfvb_json_skip_ws!(parser)
        next_char = _dfvb_json_peek(parser)
        if next_char == ','
            _dfvb_json_take!(parser, ',')
        elseif next_char == ']'
            _dfvb_json_take!(parser, ']')
            return values
        else
            _dfvb_json_error(parser, "Expected comma or array terminator.")
        end
    end
end

function _dfvb_json_parse_string!(parser)::String
    _dfvb_json_take!(parser, '"')
    io = IOBuffer()
    while !_dfvb_json_eof(parser)
        char = _dfvb_json_next!(parser)
        if char == '"'
            return String(take!(io))
        elseif char == '\\'
            escaped = _dfvb_json_next!(parser)
            if escaped == '"' || escaped == '\\' || escaped == '/'
                print(io, escaped)
            elseif escaped == 'n'
                print(io, '\n')
            elseif escaped == 'r'
                print(io, '\r')
            elseif escaped == 't'
                print(io, '\t')
            else
                _dfvb_json_error(parser, "Unsupported JSON string escape \\$escaped.")
            end
        else
            print(io, char)
        end
    end
    _dfvb_json_error(parser, "Unterminated JSON string.")
end

function _dfvb_json_parse_number!(parser)
    start = parser[].index
    while !_dfvb_json_eof(parser)
        char = _dfvb_json_peek(parser)
        if isdigit(char) || char in ('-', '+', '.', 'e', 'E')
            _dfvb_json_next!(parser)
        else
            break
        end
    end
    token = parser[].text[start:prevind(parser[].text, parser[].index)]
    isempty(token) && _dfvb_json_error(parser, "Expected JSON value.")
    if occursin(r"[\.eE]", token)
        parsed_float = tryparse(Float64, token)
        parsed_float === nothing && _dfvb_json_error(parser, "Invalid JSON number $token.")
        return parsed_float
    end
    parsed_int = tryparse(Int, token)
    parsed_int === nothing && _dfvb_json_error(parser, "Invalid JSON integer $token.")
    return parsed_int
end

function _dfvb_json_skip_ws!(parser)
    while !_dfvb_json_eof(parser) && isspace(_dfvb_json_peek(parser))
        _dfvb_json_next!(parser)
    end
    return nothing
end

function _dfvb_json_take!(parser, expected::Char)
    actual = _dfvb_json_next!(parser)
    actual == expected || _dfvb_json_error(parser, "Expected '$expected', got '$actual'.")
    return actual
end

function _dfvb_json_take_literal!(parser, literal::AbstractString)
    for expected in literal
        _dfvb_json_take!(parser, expected)
    end
    return nothing
end

function _dfvb_json_peek(parser)::Char
    _dfvb_json_eof(parser) && _dfvb_json_error(parser, "Unexpected end of JSON.")
    return parser[].text[parser[].index]
end

function _dfvb_json_next!(parser)::Char
    char = _dfvb_json_peek(parser)
    parser[] = (text = parser[].text, index = nextind(parser[].text, parser[].index), path = parser[].path)
    return char
end

function _dfvb_json_eof(parser)::Bool
    return parser[].index > lastindex(parser[].text)
end

function _dfvb_json_error(parser, message::AbstractString)
    error("Invalid DFVB manifest JSON in $(parser[].path) at index $(parser[].index): $(String(message))")
end
