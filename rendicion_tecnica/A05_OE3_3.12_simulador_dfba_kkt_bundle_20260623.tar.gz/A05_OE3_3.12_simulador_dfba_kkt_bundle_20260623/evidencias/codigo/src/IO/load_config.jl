"""
    load_config(path)

Load a TOML configuration file.
"""
function load_config(path::AbstractString)
    return TOML.parsefile(path)
end

"""
    ReducedModelPaths

Resolved paths to the reduced metabolic model export files.
"""
struct ReducedModelPaths
    s_path::String
    lb_path::String
    ub_path::String
    rxn_list_path::String
    met_list_path::String
    indices_path::Union{Nothing, String}
end

function ReducedModelPaths(;
    s_path::AbstractString,
    lb_path::AbstractString,
    ub_path::AbstractString,
    rxn_list_path::AbstractString,
    met_list_path::AbstractString,
    indices_path = nothing,
)
    return ReducedModelPaths(
        String(s_path),
        String(lb_path),
        String(ub_path),
        String(rxn_list_path),
        String(met_list_path),
        indices_path === nothing ? nothing : String(indices_path),
    )
end

"""
    FullModelPaths

Resolved paths to the full metabolic model export files.
"""
struct FullModelPaths
    model_id::String
    s_path::String
    lb_path::String
    ub_path::String
end

function FullModelPaths(;
    model_id::AbstractString,
    s_path::AbstractString,
    lb_path::AbstractString,
    ub_path::AbstractString,
)
    return FullModelPaths(
        String(model_id),
        String(s_path),
        String(lb_path),
        String(ub_path),
    )
end

"""
    load_reduced_model_paths(config_path)

Load and resolve reduced-model file paths from a TOML configuration.
"""
function load_reduced_model_paths(config_path::AbstractString)
    config = load_config(config_path)
    reduced = config["reduced_model"]
    project_root = _config_project_root(config_path)
    base_dir = _resolve_path(project_root, reduced["base_dir"])

    indices_value = get(reduced, "indices", nothing)
    indices_path = indices_value === nothing ? nothing : _resolve_path(base_dir, indices_value)

    return ReducedModelPaths(
        s_path = _resolve_path(base_dir, reduced["s"]),
        lb_path = _resolve_path(base_dir, reduced["lb"]),
        ub_path = _resolve_path(base_dir, reduced["ub"]),
        rxn_list_path = _resolve_path(base_dir, reduced["rxn_list"]),
        met_list_path = _resolve_path(base_dir, reduced["met_list"]),
        indices_path = indices_path,
    )
end

"""
    load_full_model_paths(config_path)

Load and resolve full-model file paths from a TOML configuration.
"""
function load_full_model_paths(config_path::AbstractString)::FullModelPaths
    config = load_config(config_path)
    project_root = _config_project_root(config_path)
    model_id = _required_config_value(config, "model_id", config_path)
    base_dir = _resolve_path(project_root, _required_config_value(config, "base_dir", config_path))

    return FullModelPaths(
        model_id = model_id,
        s_path = _resolve_path(base_dir, _required_config_value(config, "s", config_path)),
        lb_path = _resolve_path(base_dir, _required_config_value(config, "lb", config_path)),
        ub_path = _resolve_path(base_dir, _required_config_value(config, "ub", config_path)),
    )
end

function _config_project_root(config_path::AbstractString)
    return normpath(joinpath(dirname(String(config_path)), ".."))
end

function _required_config_value(config::AbstractDict, key::AbstractString, config_path::AbstractString)
    haskey(config, String(key)) || error("Missing required key $key in config file: $config_path")
    value = config[String(key)]
    value isa AbstractString || error("Config key $key must be a string in: $config_path")
    isempty(strip(value)) && error("Config key $key must not be empty in: $config_path")
    return String(value)
end

function _resolve_path(base_dir::AbstractString, path_value::AbstractString)
    path_string = String(path_value)
    return isabspath(path_string) ? normpath(path_string) : normpath(joinpath(base_dir, path_string))
end
