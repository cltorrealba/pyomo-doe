const SIMULATION_SUMMARY_COLUMNS = [
    "model_id",
    "model_scope",
    "retcode",
    "termination_reason",
    "initial_time",
    "final_time",
    "termination_time",
    "n_saved_points",
    "n_states",
    "n_fluxes",
    "n_alphas",
    "alpha_scope",
    "initial_biomass",
    "final_biomass",
    "initial_glucose",
    "final_glucose",
    "initial_fructose",
    "final_fructose",
    "initial_total_sugar",
    "final_total_sugar",
    "sugar_consumed",
    "initial_ethanol",
    "final_ethanol",
    "ethanol_produced",
    "max_ethanol",
    "initial_oxygen",
    "final_oxygen",
    "initial_nitrogen",
    "final_nitrogen",
    "initial_protein",
    "final_protein",
    "initial_carbohydrate",
    "final_carbohydrate",
    "time_to_sugar_depletion",
    "mode_count_growth",
    "mode_count_turnover",
    "mode_count_sugar_depleted",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "min_state_value",
    "has_negative_saved_states",
    "oxygen_derivative_policy",
    "carbohydrate_derivative_policy",
    "simulation_elapsed_seconds",
    "ode_solve_elapsed_seconds",
    "rhs_elapsed_seconds",
    "history_reconstruction_elapsed_seconds",
    "rhs_call_count",
    "rhs_lp_solve_count",
    "flux_reconstruction_solve_count",
    "total_lp_solve_count",
    "reconstruct_fluxes",
    "lp_reuse",
    "lp_primal_start",
    "lp_basis_warm_start",
    "lp_reuse_highs_solver",
    "lp_simplex_strategy",
    "lp_reuse_strategy",
    "lp_warm_start_strategy",
    "lp_reuse_build_elapsed_seconds",
    "lp_reuse_update_elapsed_seconds",
    "lp_reuse_solve_elapsed_seconds",
    "lp_reuse_warm_start_applied_count",
    "lp_reuse_basis_warm_start_applied_count",
    "lp_reuse_basis_warm_start_failed_count",
    "lp_reuse_basis_capture_count",
    "lp_reuse_simplex_iterations",
    "elapsed_seconds",
]

"""
    simulation_summary_table(result; model_id=nothing, elapsed_seconds=nothing)

Return a one-row `DataFrame` with stable scalar summary columns for a
`SimulationResult`. When `elapsed_seconds` is not provided, the column falls
back to `result.metadata["simulation_elapsed_seconds"]` when available.
"""
function simulation_summary_table(
    result::SimulationResult;
    model_id = nothing,
    elapsed_seconds = nothing,
)::DataFrame
    summary = summarize_simulation(result)
    counts = get(summary, "mode_counts", Dict{Symbol, Int}())
    resolved_model_id = model_id === nothing ? get(result.metadata, "model_id", missing) : model_id
    resolved_elapsed_seconds = elapsed_seconds === nothing ?
        get(summary, "simulation_elapsed_seconds", missing) :
        elapsed_seconds

    values = Dict{String, Any}(
        "model_id" => resolved_model_id,
        "model_scope" => get(summary, "model_scope", "unknown"),
        "retcode" => get(summary, "retcode", nothing),
        "termination_reason" => get(summary, "termination_reason", nothing),
        "initial_time" => get(summary, "initial_time", nothing),
        "final_time" => get(summary, "final_time", nothing),
        "termination_time" => get(summary, "termination_time", nothing),
        "n_saved_points" => get(summary, "n_saved_points", nothing),
        "n_states" => get(summary, "n_states", nothing),
        "n_fluxes" => get(summary, "n_fluxes", nothing),
        "n_alphas" => get(summary, "n_alphas", nothing),
        "alpha_scope" => get(summary, "alpha_scope", nothing),
        "initial_biomass" => get(summary, "initial_biomass", nothing),
        "final_biomass" => get(summary, "final_biomass", nothing),
        "initial_glucose" => get(summary, "initial_glucose", nothing),
        "final_glucose" => get(summary, "final_glucose", nothing),
        "initial_fructose" => get(summary, "initial_fructose", nothing),
        "final_fructose" => get(summary, "final_fructose", nothing),
        "initial_total_sugar" => get(summary, "initial_total_sugar", nothing),
        "final_total_sugar" => get(summary, "final_total_sugar", nothing),
        "sugar_consumed" => get(summary, "sugar_consumed", nothing),
        "initial_ethanol" => get(summary, "initial_ethanol", nothing),
        "final_ethanol" => get(summary, "final_ethanol", nothing),
        "ethanol_produced" => get(summary, "ethanol_produced", nothing),
        "max_ethanol" => get(summary, "max_ethanol", nothing),
        "initial_oxygen" => get(summary, "initial_oxygen", nothing),
        "final_oxygen" => get(summary, "final_oxygen", nothing),
        "initial_nitrogen" => get(summary, "initial_nitrogen", nothing),
        "final_nitrogen" => get(summary, "final_nitrogen", nothing),
        "initial_protein" => get(summary, "initial_protein", nothing),
        "final_protein" => get(summary, "final_protein", nothing),
        "initial_carbohydrate" => get(summary, "initial_carbohydrate", nothing),
        "final_carbohydrate" => get(summary, "final_carbohydrate", nothing),
        "time_to_sugar_depletion" => get(summary, "time_to_sugar_depletion", nothing),
        "mode_count_growth" => _summary_mode_count(counts, :growth),
        "mode_count_turnover" => _summary_mode_count(counts, :turnover),
        "mode_count_sugar_depleted" => _summary_mode_count(counts, :sugar_depleted),
        "max_mass_balance_residual" => get(summary, "max_mass_balance_residual", nothing),
        "max_lower_bound_violation" => get(summary, "max_lower_bound_violation", nothing),
        "max_upper_bound_violation" => get(summary, "max_upper_bound_violation", nothing),
        "min_state_value" => get(summary, "min_state_value", nothing),
        "has_negative_saved_states" => get(summary, "has_negative_saved_states", nothing),
        "oxygen_derivative_policy" => get(summary, "oxygen_derivative_policy", nothing),
        "carbohydrate_derivative_policy" => get(summary, "carbohydrate_derivative_policy", nothing),
        "dynamic_control_schedule_enabled" => get(summary, "dynamic_control_schedule_enabled", missing),
        "dynamic_control_policy" => get(summary, "dynamic_control_policy", missing),
        "dynamic_control_fda_total_product_g_L" =>
            get(summary, "dynamic_control_fda_total_product_g_L", missing),
        "dynamic_control_organic_total_product_g_L" =>
            get(summary, "dynamic_control_organic_total_product_g_L", missing),
        "dynamic_control_penalty" => get(summary, "dynamic_control_penalty", missing),
        "dynamic_control_volatilization_enabled" =>
            get(summary, "dynamic_control_volatilization_enabled", missing),
        "simulation_elapsed_seconds" => get(summary, "simulation_elapsed_seconds", missing),
        "ode_solve_elapsed_seconds" => get(summary, "ode_solve_elapsed_seconds", missing),
        "rhs_elapsed_seconds" => get(summary, "rhs_elapsed_seconds", missing),
        "history_reconstruction_elapsed_seconds" =>
            get(summary, "history_reconstruction_elapsed_seconds", missing),
        "rhs_call_count" => get(summary, "rhs_call_count", missing),
        "rhs_lp_solve_count" => get(summary, "rhs_lp_solve_count", missing),
        "flux_reconstruction_solve_count" => get(summary, "flux_reconstruction_solve_count", missing),
        "total_lp_solve_count" => get(summary, "total_lp_solve_count", missing),
        "reconstruct_fluxes" => get(summary, "reconstruct_fluxes", missing),
        "lp_reuse" => get(summary, "lp_reuse", missing),
        "lp_primal_start" => get(summary, "lp_primal_start", missing),
        "lp_basis_warm_start" => get(summary, "lp_basis_warm_start", missing),
        "lp_reuse_highs_solver" => get(summary, "lp_reuse_highs_solver", missing),
        "lp_simplex_strategy" => get(summary, "lp_simplex_strategy", missing),
        "lp_reuse_strategy" => get(summary, "lp_reuse_strategy", missing),
        "lp_warm_start_strategy" => get(summary, "lp_warm_start_strategy", missing),
        "lp_reuse_build_elapsed_seconds" => get(summary, "lp_reuse_build_elapsed_seconds", missing),
        "lp_reuse_update_elapsed_seconds" => get(summary, "lp_reuse_update_elapsed_seconds", missing),
        "lp_reuse_solve_elapsed_seconds" => get(summary, "lp_reuse_solve_elapsed_seconds", missing),
        "lp_reuse_warm_start_applied_count" =>
            get(summary, "lp_reuse_warm_start_applied_count", missing),
        "lp_reuse_basis_warm_start_applied_count" =>
            get(summary, "lp_reuse_basis_warm_start_applied_count", missing),
        "lp_reuse_basis_warm_start_failed_count" =>
            get(summary, "lp_reuse_basis_warm_start_failed_count", missing),
        "lp_reuse_basis_capture_count" => get(summary, "lp_reuse_basis_capture_count", missing),
        "lp_reuse_simplex_iterations" => get(summary, "lp_reuse_simplex_iterations", missing),
        "elapsed_seconds" => resolved_elapsed_seconds,
    )

    return DataFrame((column => [_table_scalar(values[column])] for column in SIMULATION_SUMMARY_COLUMNS)...)
end

"""
    simulation_states_table(result)

Return a wide `DataFrame` with one row per saved time point and one column per
fermentation state.
"""
function simulation_states_table(result::SimulationResult)::DataFrame
    state_names = _export_state_names(result)
    n_time = length(result.time)
    size(result.states, 1) == length(state_names) || error(
        "SimulationResult state row count $(size(result.states, 1)) does not match " *
        "$(length(state_names)) state names.",
    )
    size(result.states, 2) == n_time || error(
        "SimulationResult states must be stored as n_states x n_time. " *
        "Got $(size(result.states, 2)) saved state columns for $n_time time points.",
    )

    table = DataFrame("time" => copy(result.time))
    for (i, name) in enumerate(state_names)
        table[!, name] = collect(view(result.states, i, :))
    end
    return table
end

"""
    simulation_fluxes_table(result)

Return a wide flux-history `DataFrame`, or `nothing` when no flux history is
stored in the `SimulationResult`.
"""
function simulation_fluxes_table(result::SimulationResult)::Union{Nothing, DataFrame}
    result.fluxes === nothing && return nothing

    flux_rxn_ids = _export_flux_rxn_ids(result)
    model_scope = String(get(result.metadata, "model_scope", "unknown"))
    "r_0001" in flux_rxn_ids && error(
        "SimulationResult flux_rxn_ids must not include r_0001 as an oxygen fallback.",
    )
    "r_1992" in flux_rxn_ids && !(model_scope in ("full", "dfvb")) && error(
        "SimulationResult flux_rxn_ids may include r_1992 only for model_scope = \"full\" or \"dfvb\".",
    )
    n_time = length(result.time)
    size(result.fluxes, 1) == length(flux_rxn_ids) || error(
        "SimulationResult flux row count $(size(result.fluxes, 1)) does not match " *
        "$(length(flux_rxn_ids)) flux reaction IDs.",
    )
    size(result.fluxes, 2) == n_time || error(
        "SimulationResult fluxes must be stored as n_fluxes x n_time. " *
        "Got $(size(result.fluxes, 2)) saved flux columns for $n_time time points.",
    )

    table = DataFrame("time" => copy(result.time))
    for (i, rxn_id) in enumerate(flux_rxn_ids)
        table[!, rxn_id] = collect(view(result.fluxes, i, :))
    end
    return table
end

"""
    simulation_alphas_table(result)

Return a wide alpha-history `DataFrame`, or `nothing` when no alpha history is
stored in the `SimulationResult`.
"""
function simulation_alphas_table(result::SimulationResult)::Union{Nothing, DataFrame}
    result.alphas === nothing && return nothing

    n_alpha = size(result.alphas, 1)
    n_time = length(result.time)
    size(result.alphas, 2) == n_time || error(
        "SimulationResult alphas must be stored as n_alpha x n_time. " *
        "Got $(size(result.alphas, 2)) saved alpha columns for $n_time time points.",
    )

    alpha_ids = _export_alpha_ids(result, n_alpha)
    table = DataFrame("time" => copy(result.time))
    for (i, alpha_id) in enumerate(alpha_ids)
        table[!, alpha_id] = collect(view(result.alphas, i, :))
    end
    return table
end

"""
    simulation_diagnostics_table(result)

Return a wide `DataFrame` with solver mode/status histories and compact LP
diagnostics aligned to saved time points.
"""
function simulation_diagnostics_table(result::SimulationResult)::DataFrame
    n_time = length(result.time)
    return DataFrame(
        "time" => copy(result.time),
        "mode" => _metadata_history_column(result, "mode_history", n_time; string_values = true),
        "rhs_status" => _metadata_history_column(result, "rhs_status_history", n_time; string_values = true),
        "mass_balance_residual" => _metadata_history_column(result, "mass_balance_residuals", n_time),
        "max_lower_bound_violation" =>
            _metadata_history_column(result, "max_lower_bound_violations", n_time),
        "max_upper_bound_violation" =>
            _metadata_history_column(result, "max_upper_bound_violations", n_time),
    )
end

"""
    export_simulation_result(result, output_dir; model_id=nothing, elapsed_seconds=nothing, overwrite=false)

Write CSV/TOML report files for a `SimulationResult` and return the generated
file paths keyed by logical artifact name.
"""
function export_simulation_result(
    result::SimulationResult,
    output_dir::AbstractString;
    model_id = nothing,
    elapsed_seconds = nothing,
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Simulation export output_dir exists and is not a directory: $output_path")
    end

    known_paths = Dict{String, String}(
        "summary" => joinpath(output_path, "summary.csv"),
        "states" => joinpath(output_path, "states.csv"),
        "fluxes" => joinpath(output_path, "fluxes.csv"),
        "alphas" => joinpath(output_path, "alphas.csv"),
        "diagnostics" => joinpath(output_path, "diagnostics.csv"),
        "metadata" => joinpath(output_path, "metadata.toml"),
    )
    paths = Dict{String, String}(
        "summary" => known_paths["summary"],
        "states" => known_paths["states"],
        "diagnostics" => known_paths["diagnostics"],
        "metadata" => known_paths["metadata"],
    )
    if result.fluxes !== nothing
        paths["fluxes"] = known_paths["fluxes"]
    end
    if result.alphas !== nothing
        paths["alphas"] = known_paths["alphas"]
    end

    existing_targets = [path for path in values(known_paths) if isfile(path)]
    if !overwrite && !isempty(existing_targets)
        error(
            "Simulation export target file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end

    mkpath(output_path)
    if overwrite
        for path in values(known_paths)
            isfile(path) && rm(path)
        end
    end
    CSV.write(paths["summary"], simulation_summary_table(result; model_id = model_id, elapsed_seconds = elapsed_seconds))
    CSV.write(paths["states"], simulation_states_table(result))
    CSV.write(paths["diagnostics"], simulation_diagnostics_table(result))
    if haskey(paths, "fluxes")
        CSV.write(paths["fluxes"], simulation_fluxes_table(result))
    end
    if haskey(paths, "alphas")
        CSV.write(paths["alphas"], simulation_alphas_table(result))
    end
    open(paths["metadata"], "w") do io
        TOML.print(io, _export_metadata(result; model_id = model_id, elapsed_seconds = elapsed_seconds))
    end

    return paths
end

function _summary_mode_count(counts, mode::Symbol)::Int
    if counts isa AbstractDict
        return get(counts, mode, get(counts, String(mode), 0))
    end
    return 0
end

function _table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end

function _export_state_names(result::SimulationResult)::Vector{String}
    state_names = get(result.metadata, "state_names", nothing)
    state_names === nothing && return copy(DEFAULT_SIMULATION_STATE_NAMES)
    return String.(state_names)
end

function _export_flux_rxn_ids(result::SimulationResult)::Vector{String}
    value = get(result.metadata, "flux_rxn_ids", nothing)
    value isa AbstractVector || error(
        "SimulationResult metadata must include a vector flux_rxn_ids when fluxes are present.",
    )
    return String.(value)
end

function _export_alpha_ids(result::SimulationResult, n_alpha::Integer)::Vector{String}
    value = get(result.metadata, "alpha_ids", nothing)
    alpha_ids = value isa AbstractVector ? String.(value) : ["alpha_$i" for i in 1:Int(n_alpha)]
    length(alpha_ids) == Int(n_alpha) || error(
        "SimulationResult metadata alpha_ids length $(length(alpha_ids)) does not match " *
        "alpha row count $(Int(n_alpha)).",
    )
    return alpha_ids
end

function _metadata_history_column(
    result::SimulationResult,
    key::String,
    n_time::Int;
    string_values::Bool = false,
)
    value = get(result.metadata, key, nothing)
    value === nothing && return fill(missing, n_time)
    value isa AbstractVector || error("SimulationResult metadata key $key must be a vector when present.")
    if isempty(value) && n_time > 0 && get(result.metadata, "reconstruct_fluxes", true) == false
        return fill(missing, n_time)
    end
    length(value) == n_time || error(
        "SimulationResult metadata key $key has length $(length(value)), expected $n_time.",
    )

    if string_values
        return [_history_string(value_i) for value_i in value]
    end
    return collect(value)
end

function _history_string(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return String(value)
    end
end

function _export_metadata(
    result::SimulationResult;
    model_id = nothing,
    elapsed_seconds = nothing,
)::Dict{String, Any}
    raw_metadata = Dict{String, Any}(result.metadata)
    if model_id !== nothing
        raw_metadata["model_id"] = model_id
    end
    if elapsed_seconds !== nothing
        raw_metadata["elapsed_seconds"] = elapsed_seconds
    end

    normalized = Dict{String, Any}()
    for key in sort(collect(keys(raw_metadata)))
        normalized_value = _toml_normalize(raw_metadata[key])
        normalized_value === nothing && continue
        normalized[String(key)] = normalized_value
    end
    return normalized
end

function _toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _toml_normalize_real(value)
    elseif value isa Tuple
        return _toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end
