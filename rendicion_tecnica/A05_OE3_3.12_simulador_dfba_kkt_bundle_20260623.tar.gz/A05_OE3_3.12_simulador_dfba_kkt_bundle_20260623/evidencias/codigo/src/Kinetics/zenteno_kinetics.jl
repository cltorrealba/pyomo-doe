const ZENTENO_AMINO_ACID_ROLES = (
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
)

const ZENTENO_AROMA_ROLES = (
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
)

"""
    ZentenoState

Fermentation state used by the reduced Zenteno kinetic-bound layer.
"""
struct ZentenoState
    biomass::Float64
    nitrogen::Float64
    glucose::Float64
    fructose::Float64
    ethanol::Float64
    oxygen::Float64
    protein::Float64
    carbohydrate::Float64
    amino_acids::Vector{Float64}
    aromas::Vector{Float64}
end

function ZentenoState(
    biomass::Real,
    nitrogen::Real,
    glucose::Real,
    fructose::Real,
    ethanol::Real,
    oxygen::Real,
    protein::Real,
    carbohydrate::Real,
    amino_acids::AbstractVector,
    aromas::AbstractVector,
)
    length(amino_acids) == 5 || error("Expected 5 amino acid state values, got $(length(amino_acids)).")
    length(aromas) == 6 || error("Expected 6 aroma state values, got $(length(aromas)).")

    return ZentenoState(
        Float64(biomass),
        Float64(nitrogen),
        Float64(glucose),
        Float64(fructose),
        Float64(ethanol),
        Float64(oxygen),
        Float64(protein),
        Float64(carbohydrate),
        Float64.(amino_acids),
        Float64.(aromas),
    )
end

"""
    ZentenoKineticParameters

Nominal MATLAB Zenteno kinetic parameters and constants for the reduced model.

The nitrogen distribution weights are preserved exactly from the current
`nitrogen.mat` inference. They are not normalized in this commit because their
units and interpretation must be revisited against the MATLAB baseline.
"""
struct ZentenoKineticParameters
    MU0::Float64
    YXN::Float64
    YXG::Float64
    YXF::Float64
    YEG::Float64
    YEF::Float64
    Kn0::Float64
    Kg0::Float64
    Kf0::Float64
    Kig0::Float64
    Kie0::Float64
    Kd0::Float64
    betaG0::Float64
    betaF0::Float64
    MW_GLU::Float64
    MW_FRU::Float64
    MW_ETH::Float64
    MW_O2::Float64
    MW_N::Float64
    K_DEATH::Float64
    TURNOVER_LAMBDA::Float64
    PROT_CONTENT_0::Float64
    CARB_CONTENT_0::Float64
    XA_FRACTION::Float64
    TURNOVER_THRESHOLD::Float64
    phase_proxy_mode::Symbol
    ATP_LB_TURNOVER::Float64
    ATP_UB_TURNOVER::Float64
    K_AA_UPTAKE_GROWTH::Float64
    AA_alpha::Float64
    temperature_K::Float64
    R::Float64
    MRATE_0::Float64
    EPS::Float64
    amino_acid_molecular_weights::Vector{Float64}
    aroma_molecular_weights::Vector{Float64}
    aroma_forcing_constants::Vector{Float64}
    nitrogen_source_ids::Vector{String}
    nitrogen_distribution_weights::Vector{Float64}
    nitrogen_atom_counts::Vector{Int}
end

function _zenteno_phase_proxy_mode(mode::Union{Symbol, AbstractString})::Symbol
    normalized = Symbol(lowercase(replace(strip(String(mode)), '-' => '_')))
    aliases = Dict(
        :legacy => :total_molecular_weight,
        :current => :total_molecular_weight,
        :total => :total_molecular_weight,
        :total_nitrogen => :total_molecular_weight,
        :total_nitrogen_proxy => :total_molecular_weight,
        :molecular_weight => :total_molecular_weight,
        :total_molecular_weight => :total_molecular_weight,
        :free_n => :free_nitrogen,
        :free_nitrogen => :free_nitrogen,
        :nitrogen => :free_nitrogen,
        :nitrogen_equivalent => :nitrogen_equivalent,
        :n_equivalent => :nitrogen_equivalent,
        :aa_nitrogen_equivalent => :nitrogen_equivalent,
    )
    haskey(aliases, normalized) || throw(
        ArgumentError(
            "Zenteno phase proxy mode must be total_molecular_weight, " *
            "free_nitrogen, or nitrogen_equivalent. Got: $mode.",
        ),
    )
    return aliases[normalized]
end

function _zenteno_phase_proxy_definition(phase_proxy_mode::Symbol)::String
    mode = _zenteno_phase_proxy_mode(phase_proxy_mode)
    mode == :free_nitrogen && return "N_free"
    mode == :nitrogen_equivalent && return "N_free + sum(amino_acids .* MW_N)"
    mode == :total_molecular_weight &&
        return "N_free + sum(amino_acids .* amino_acid_molecular_weights)"
    throw(ArgumentError("Unsupported Zenteno phase proxy mode: $phase_proxy_mode."))
end

function _zenteno_phase_proxy(state::ZentenoState, params::ZentenoKineticParameters)::Float64
    mode = _zenteno_phase_proxy_mode(params.phase_proxy_mode)
    mode == :free_nitrogen && return state.nitrogen
    if mode == :nitrogen_equivalent
        return state.nitrogen + sum(state.amino_acids .* params.MW_N)
    elseif mode == :total_molecular_weight
        return state.nitrogen + sum(state.amino_acids .* params.amino_acid_molecular_weights)
    else
        throw(ArgumentError("Unsupported Zenteno phase proxy mode: $(params.phase_proxy_mode)."))
    end
end

function ZentenoKineticParameters(;
    MU0::Real = 0.1800,
    YXN::Real = 19.6900,
    YXG::Real = 1.6000,
    YXF::Real = 1.6000,
    YEG::Real = 0.4900,
    YEF::Real = 0.4900,
    Kn0::Real = 0.0100,
    Kg0::Real = 7.5000,
    Kf0::Real = 7.5000,
    Kig0::Real = 55.0,
    Kie0::Real = 40.0,
    Kd0::Real = 4.4000e-04,
    betaG0::Real = 0.2250,
    betaF0::Real = 0.2250,
    MW_GLU::Real = 0.180156,
    MW_FRU::Real = 0.180156,
    MW_ETH::Real = 0.046070,
    MW_O2::Real = 0.032,
    MW_N::Real = 0.014007,
    K_DEATH::Real = 0.005,
    TURNOVER_LAMBDA::Real = 0.03,
    PROT_CONTENT_0::Real = 0.46,
    CARB_CONTENT_0::Real = 0.37,
    XA_FRACTION::Real = 1.0,
    TURNOVER_THRESHOLD::Real = 0.001,
    phase_proxy_mode::Union{Symbol, AbstractString} = :total_molecular_weight,
    ATP_LB_TURNOVER::Real = 0.7,
    ATP_UB_TURNOVER::Real = 1.0e3,
    K_AA_UPTAKE_GROWTH::Real = 0.08,
    AA_alpha::Real = 1 / 6,
    temperature_K::Real = 293.15,
    R::Real = 8.314,
    MRATE_0::Real = 0.01,
    EPS::Real = 1.0e-9,
    amino_acid_molecular_weights::AbstractVector = [0.16519, 0.13117, 0.11715, 0.14921, 0.18119],
    aroma_molecular_weights::AbstractVector = [0.12217, 0.08815, 0.07412, 0.10619, 0.13816, 0.08811],
    aroma_forcing_constants::AbstractVector = [0.0, 2.0e-5, 0.0, 2.0e-5, 0.0, 2.0e-4],
    nitrogen_source_ids::AbstractVector = [
        "r_1654",
        "r_1879",
        "r_1891",
        "r_1889",
        "r_1906",
        "r_1911",
        "r_1873",
        "r_1912",
        "r_1899",
    ],
    nitrogen_distribution_weights::AbstractVector = [
        24.98750625,
        3.56964375,
        3.56964375,
        3.56964375,
        3.56964375,
        3.56964375,
        3.56964375,
        3.56964375,
        3.56964375,
    ],
    nitrogen_atom_counts::AbstractVector = [1, 4, 2, 1, 1, 1, 1, 2, 1],
)
    length(amino_acid_molecular_weights) == 5 || error("Expected 5 amino acid molecular weights.")
    length(aroma_molecular_weights) == 6 || error("Expected 6 aroma molecular weights.")
    length(aroma_forcing_constants) == 6 || error("Expected 6 aroma forcing constants.")
    length(nitrogen_source_ids) == 9 || error("Expected 9 nitrogen source reaction IDs.")
    length(nitrogen_distribution_weights) == 9 || error("Expected 9 nitrogen distribution weights.")
    length(nitrogen_atom_counts) == 9 || error("Expected 9 nitrogen atom counts.")

    return ZentenoKineticParameters(
        Float64(MU0),
        Float64(YXN),
        Float64(YXG),
        Float64(YXF),
        Float64(YEG),
        Float64(YEF),
        Float64(Kn0),
        Float64(Kg0),
        Float64(Kf0),
        Float64(Kig0),
        Float64(Kie0),
        Float64(Kd0),
        Float64(betaG0),
        Float64(betaF0),
        Float64(MW_GLU),
        Float64(MW_FRU),
        Float64(MW_ETH),
        Float64(MW_O2),
        Float64(MW_N),
        Float64(K_DEATH),
        Float64(TURNOVER_LAMBDA),
        Float64(PROT_CONTENT_0),
        Float64(CARB_CONTENT_0),
        Float64(XA_FRACTION),
        Float64(TURNOVER_THRESHOLD),
        _zenteno_phase_proxy_mode(phase_proxy_mode),
        Float64(ATP_LB_TURNOVER),
        Float64(ATP_UB_TURNOVER),
        Float64(K_AA_UPTAKE_GROWTH),
        Float64(AA_alpha),
        Float64(temperature_K),
        Float64(R),
        Float64(MRATE_0),
        Float64(EPS),
        Float64.(amino_acid_molecular_weights),
        Float64.(aroma_molecular_weights),
        Float64.(aroma_forcing_constants),
        String.(nitrogen_source_ids),
        Float64.(nitrogen_distribution_weights),
        Int.(nitrogen_atom_counts),
    )
end

"""
    ZentenoKineticRates

Computed reduced Zenteno kinetic rates before any LP solve.
"""
struct ZentenoKineticRates
    mu_T::Float64
    Kg_T::Float64
    b_T::Float64
    mrate::Float64
    mu::Float64
    betaG::Float64
    betaF::Float64
    fermentation_hexose::Float64
    vg::Float64
    vf::Float64
    vn::Float64
    ve::Float64
    v_aroma_forced::Vector{Float64}
    total_nitrogen_proxy::Float64
end

"""
    ZentenoDynamicBounds

Reaction-ID keyed dynamic bound and objective updates for a single state.
"""
struct ZentenoDynamicBounds
    mode::Symbol
    lb_updates::Dict{String, Float64}
    ub_updates::Dict{String, Float64}
    objective_weights::Dict{String, Float64}
    rates::ZentenoKineticRates
    metadata::Dict{String, Any}
end

"""
    default_zenteno_initial_state()

Return the MATLAB initial condition as a `ZentenoState`.
"""
function default_zenteno_initial_state()::ZentenoState
    return zenteno_state_from_vector([
        0.5,
        0.07,
        110.0,
        110.0,
        0.0,
        0.0,
        0.23,
        0.1850,
        0.9995,
        0.9995,
        0.9995,
        0.9995,
        0.9995,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
    ])
end

"""
    zenteno_state_from_vector(y)

Convert a 19-element MATLAB-order fermentation state vector to `ZentenoState`.
"""
function zenteno_state_from_vector(y::AbstractVector)::ZentenoState
    length(y) == 19 || error("Expected a 19-element Zenteno state vector, got $(length(y)).")
    return ZentenoState(y[1], y[2], y[3], y[4], y[5], y[6], y[7], y[8], y[9:13], y[14:19])
end

"""
    zenteno_state_to_vector(state)

Convert a `ZentenoState` to the 19-element MATLAB-order fermentation state vector.
"""
function zenteno_state_to_vector(state::ZentenoState)::Vector{Float64}
    length(state.amino_acids) == 5 ||
        error("Expected 5 amino acid state values, got $(length(state.amino_acids)).")
    length(state.aromas) == 6 || error("Expected 6 aroma state values, got $(length(state.aromas)).")

    return Float64[
        state.biomass,
        state.nitrogen,
        state.glucose,
        state.fructose,
        state.ethanol,
        state.oxygen,
        state.protein,
        state.carbohydrate,
        state.amino_acids...,
        state.aromas...,
    ]
end

"""
    default_zenteno_parameters()

Return nominal MATLAB parameters for reduced Zenteno kinetic-bound calculations.
"""
function default_zenteno_parameters(; kwargs...)::ZentenoKineticParameters
    return ZentenoKineticParameters(; kwargs...)
end

"""
    zenteno_kinetic_rates(state, params=default_zenteno_parameters())

Compute Zenteno-style fermentation kinetic rates without solving an LP.
"""
function zenteno_kinetic_rates(
    state::ZentenoState,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
)::ZentenoKineticRates
    cN = state.nitrogen
    cG = state.glucose
    cF = state.fructose
    cE = state.ethanol
    T = params.temperature_K
    R = params.R
    eps = params.EPS

    mu_T = exp(59453.0 * (T - 300.0) / (300.0 * R * T))
    Kg_T = exp(46055.0 * (T - 293.15) / (293.15 * R * T))
    b_T = exp(11000.0 * (T - 296.15) / (296.15 * R * T))
    mrate = params.MRATE_0 * exp(37681.0 * (T - 293.30) / (293.30 * R * T))

    mu = params.MU0 * mu_T * (cN / (cN + params.Kn0 * Kg_T + eps))
    betaG = params.betaG0 *
        b_T *
        (cG / (cG + params.Kg0 * Kg_T + eps)) *
        (params.Kie0 * Kg_T / (cE + params.Kie0 * Kg_T + eps))
    betaF = params.betaF0 *
        b_T *
        (cF / (cF + params.Kf0 * Kg_T + eps)) *
        (params.Kig0 * Kg_T / (cG + params.Kig0 * Kg_T + eps)) *
        (params.Kie0 * Kg_T / (cE + params.Kie0 * Kg_T + eps))

    fermentation_hexose =
        betaG / max(params.YEG * params.MW_GLU, eps) +
        betaF / max(params.YEF * params.MW_FRU, eps)

    hexose_total = cG + cF + eps
    vg = mu / params.YXG + betaG / params.YEG + mrate * (cG / hexose_total)
    vf = mu / params.YXF + betaF / params.YEF + mrate * (cF / hexose_total)
    vn = mu / params.YXN
    ve = (betaG + betaF) / params.MW_ETH

    c_aa_gN = max.(0.0, state.amino_acids) .* params.MW_N
    km_aroma = 0.002
    floor_val = 0.05
    sat_func(c) = floor_val + (1.0 - floor_val) * (c / (c + km_aroma + eps))
    f_aroma = [
        sat_func(c_aa_gN[1]),
        sat_func(c_aa_gN[2]),
        sat_func(c_aa_gN[3]),
        sat_func(c_aa_gN[4]),
        sat_func(c_aa_gN[5]),
        1.0,
    ]
    v_aroma_forced =
        params.aroma_forcing_constants .* max(0.0, fermentation_hexose) .* f_aroma

    total_nitrogen_proxy =
        state.nitrogen + sum(state.amino_acids .* params.amino_acid_molecular_weights)

    return ZentenoKineticRates(
        mu_T,
        Kg_T,
        b_T,
        mrate,
        mu,
        betaG,
        betaF,
        fermentation_hexose,
        vg,
        vf,
        vn,
        ve,
        Float64.(v_aroma_forced),
        total_nitrogen_proxy,
    )
end

"""
    zenteno_dynamic_bounds(model, reaction_map, state, params=default_zenteno_parameters())

Compute dynamic bound and objective updates for one reduced-model state.

All updates are keyed by reaction ID. `Indices_reacciones.csv` and positional
MATLAB indices are intentionally not used.
"""
function zenteno_dynamic_bounds(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    state::ZentenoState,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
)::ZentenoDynamicBounds
    validate_reduced_model_dimensions(model; throw_on_error = true)

    rates = zenteno_kinetic_rates(state, params)
    phase_proxy = _zenteno_phase_proxy(state, params)
    mode = phase_proxy > params.TURNOVER_THRESHOLD ? :growth : :turnover

    lb_updates = Dict{String, Float64}()
    ub_updates = Dict{String, Float64}()
    objective_weights = Dict{String, Float64}()

    glucose_id = _required_core_reaction_id(reaction_map, "glucose_exchange")
    fructose_id = _required_core_reaction_id(reaction_map, "fructose_exchange")
    ethanol_id = _required_core_reaction_id(reaction_map, "ethanol_exchange")
    biomass_id = _required_core_reaction_id(reaction_map, "biomass_growth")
    atp_id = _required_core_reaction_id(reaction_map, "atp_maintenance")
    protein_id = _required_core_reaction_id(reaction_map, "protein_exchange")

    lb_updates[glucose_id] = -max(0.0, rates.vg / params.MW_GLU)
    lb_updates[fructose_id] = -max(0.0, rates.vf / params.MW_FRU)
    ub_updates[ethanol_id] = max(0.0, rates.ve)

    for (i, rxn_id) in enumerate(params.nitrogen_source_ids)
        _require_group_reaction_id(reaction_map.nitrogen_sources, rxn_id, "nitrogen_sources")
        lb_updates[rxn_id] = -max(0.0, rates.vn) * params.nitrogen_distribution_weights[i]
    end

    aroma_ids = [_required_group_role_id(reaction_map.aromas, role, "aromas") for role in ZENTENO_AROMA_ROLES]
    for (rxn_id, value) in zip(aroma_ids, rates.v_aroma_forced)
        lb_updates[rxn_id] = value
    end

    amino_acid_ids = [
        _required_group_role_id(reaction_map.amino_acids, role, "amino_acids") for
        role in ZENTENO_AMINO_ACID_ROLES
    ]

    if mode == :growth
        objective_weights[biomass_id] = 1.0
        for (rxn_id, aa_concentration) in zip(amino_acid_ids, state.amino_acids)
            objective_weights[rxn_id] = -1.0
            uptake = params.K_AA_UPTAKE_GROWTH * aa_concentration / max(state.biomass, params.EPS)
            lb_updates[rxn_id] = -max(0.0, uptake)
        end
    else
        lb_updates[biomass_id] = 0.0
        ub_updates[biomass_id] = 0.0
        lb_updates[atp_id] = params.ATP_LB_TURNOVER
        ub_updates[atp_id] = params.ATP_UB_TURNOVER
        objective_weights[atp_id] = 1.0
        objective_weights[protein_id] = 1.0

        active_biomass = params.XA_FRACTION * state.biomass
        for rxn_id in amino_acid_ids
            uptake =
                params.TURNOVER_LAMBDA *
                state.protein *
                params.AA_alpha /
                max(active_biomass, params.EPS)
            lb_updates[rxn_id] = -max(0.0, uptake)
        end
    end

    _ensure_model_has_reactions(model, keys(lb_updates), "lower-bound update")
    _ensure_model_has_reactions(model, keys(ub_updates), "upper-bound update")
    _ensure_model_has_reactions(model, keys(objective_weights), "objective weight")

    metadata = Dict{String, Any}(
        "oxygen_exchange_bound_updated" => false,
        "oxygen_exchange_skipped_reason" => "oxygen_exchange r_1992 is disabled or absent from the reduced model.",
        "carbohydrate_exchange_bound_updated" => false,
        "carbohydrate_exchange_note" => "carbohydrate_exchange r_4048 is required in the reduced model but has no MATLAB kinetic bound update.",
        "indices_reacciones_used" => false,
        "nitrogen_distribution_weights_normalized" => false,
        "phase_proxy_mode" => String(params.phase_proxy_mode),
        "phase_proxy_definition" => _zenteno_phase_proxy_definition(params.phase_proxy_mode),
        "phase_proxy_value" => phase_proxy,
        "turnover_threshold" => params.TURNOVER_THRESHOLD,
        "total_nitrogen_proxy_definition" =>
            "state.nitrogen + sum(state.amino_acids .* params.amino_acid_molecular_weights)",
        "total_nitrogen_proxy_value" => rates.total_nitrogen_proxy,
    )

    return ZentenoDynamicBounds(mode, lb_updates, ub_updates, objective_weights, rates, metadata)
end

"""
    apply_dynamic_bounds(model, bounds)

Return a new `MetabolicModel` with dynamic lower and upper bound updates applied.
"""
function apply_dynamic_bounds(model::MetabolicModel, bounds::ZentenoDynamicBounds)::MetabolicModel
    validate_reduced_model_dimensions(model; throw_on_error = true)

    updated_lb = copy(model.lb)
    updated_ub = copy(model.ub)

    for (rxn_id, value) in bounds.lb_updates
        updated_lb[reaction_index(model, rxn_id)] = value
    end
    for (rxn_id, value) in bounds.ub_updates
        updated_ub[reaction_index(model, rxn_id)] = value
    end

    if any(updated_lb .> updated_ub)
        bad_count = count(updated_lb .> updated_ub)
        error("Dynamic bounds produced $bad_count bound pairs with lb > ub.")
    end

    return MetabolicModel(
        model.S,
        updated_lb,
        updated_ub,
        model.rxn_ids,
        model.met_ids;
        model_id = model.model_id,
    )
end

function _required_core_reaction_id(reaction_map::ReactionMap, role::AbstractString)::String
    return _required_group_role_id(reaction_map.core, role, "core")
end

function _required_group_role_id(
    group::Dict{String, String},
    role::AbstractString,
    group_name::AbstractString,
)::String
    haskey(group, String(role)) || error("Missing required $group_name reaction-map role: $role")
    rxn_id = strip(group[String(role)])
    isempty(rxn_id) && error("Reaction-map role $role in $group_name has an empty reaction ID.")
    return rxn_id
end

function _require_group_reaction_id(
    group::Dict{String, String},
    rxn_id::AbstractString,
    group_name::AbstractString,
)::String
    cleaned_id = strip(String(rxn_id))
    cleaned_id in values(group) || error("Reaction ID $cleaned_id is not configured in reaction-map group $group_name.")
    return cleaned_id
end

function _ensure_model_has_reactions(model::MetabolicModel, rxn_ids, update_label::AbstractString)
    for rxn_id in rxn_ids
        has_reaction(model, rxn_id) || error("Cannot apply $update_label for missing reaction ID: $rxn_id")
    end
    return nothing
end
