"""
    ReactionMap

Mapping between fermentation state roles and reduced-model reaction IDs.

Disabled reactions are allowed when the biological role exists in the dynamic
state contract but no usable reaction is present in the reduced model.
"""
struct ReactionMap
    core::Dict{String, String}
    nitrogen_sources::Dict{String, String}
    amino_acids::Dict{String, String}
    aromas::Dict{String, String}
    disabled_reactions::Dict{String, String}
    disabled_reaction_reasons::Dict{String, String}
end

function ReactionMap(;
    core = Dict{String, String}(),
    nitrogen_sources = Dict{String, String}(),
    amino_acids = Dict{String, String}(),
    aromas = Dict{String, String}(),
    disabled_reactions = Dict{String, String}(),
    disabled_reaction_reasons = Dict{String, String}(),
)
    return ReactionMap(
        _string_dict(core),
        _string_dict(nitrogen_sources),
        _string_dict(amino_acids),
        _string_dict(aromas),
        _string_dict(disabled_reactions),
        _string_dict(disabled_reaction_reasons),
    )
end

"""
    ReactionMapValidationReport

Structured reaction-map validation result.
"""
struct ReactionMapValidationReport
    found_required_reactions::Dict{String, String}
    missing_required_reactions::Dict{String, String}
    disabled_reactions::Dict{String, String}
    unknown_reaction_ids::Dict{String, String}
    ok::Bool
end

function _string_dict(values)::Dict{String, String}
    output = Dict{String, String}()
    for (key, value) in values
        output[String(key)] = String(value)
    end
    return output
end

function _active_reaction_roles(reaction_map::ReactionMap)
    roles = Dict{String, String}()
    for group in (
        reaction_map.core,
        reaction_map.nitrogen_sources,
        reaction_map.amino_acids,
        reaction_map.aromas,
    )
        merge!(roles, group)
    end
    return roles
end

"""
    default_reduced_reaction_map()

Return the reduced Sauvignon Blanc fermentation reaction-map template.
"""
function default_reduced_reaction_map()
    return ReactionMap(
        core = Dict(
            "biomass_growth" => "r_2111",
            "glucose_exchange" => "r_1714",
            "fructose_exchange" => "r_1709",
            "ethanol_exchange" => "r_1761",
            "oxygen_exchange" => "r_1992",
            "atp_maintenance" => "r_4046",
            "protein_exchange" => "r_4047",
            "carbohydrate_exchange" => "r_4048",
        ),
        nitrogen_sources = Dict(
            "n_source_r_1654" => "r_1654",
            "n_source_r_1879" => "r_1879",
            "n_source_r_1891" => "r_1891",
            "n_source_r_1889" => "r_1889",
            "n_source_r_1906" => "r_1906",
            "n_source_r_1911" => "r_1911",
            "n_source_r_1873" => "r_1873",
            "n_source_r_1912" => "r_1912",
            "n_source_r_1899" => "r_1899",
        ),
        amino_acids = Dict(
            "phenylalanine" => "r_1903",
            "leucine" => "r_1897",
            "valine" => "r_1914",
            "methionine" => "r_1902",
            "tyrosine" => "r_1913",
        ),
        aromas = Dict(
            "phenylethanol" => "r_1589",
            "isoamyl_alcohol" => "r_1862",
            "isobutanol" => "r_1866",
            "methionol" => "r_4668",
            "tyrosol" => "r_4677",
            "ethyl_acetate" => "r_1765",
        ),
        disabled_reactions = Dict(
            "oxygen_exchange" => "r_1992",
        ),
        disabled_reaction_reasons = Dict(
            "oxygen_exchange" => "Oxygen exchange r_1992 is absent from the reduced model export.",
        ),
    )
end

"""
    load_reaction_map(path)

Load a reaction map from a TOML file.
"""
function load_reaction_map(path::AbstractString)
    data = TOML.parsefile(path)
    return ReactionMap(
        core = get(data, "core", Dict{String, String}()),
        nitrogen_sources = get(data, "nitrogen_sources", Dict{String, String}()),
        amino_acids = get(data, "amino_acids", Dict{String, String}()),
        aromas = get(data, "aromas", Dict{String, String}()),
        disabled_reactions = get(data, "disabled_reactions", Dict{String, String}()),
        disabled_reaction_reasons = get(data, "disabled_reaction_reasons", Dict{String, String}()),
    )
end

"""
    validate_reaction_map(model, reaction_map)

Validate that active reaction-map entries are present in the model reaction IDs.

Explicitly disabled reactions are reported but do not cause validation failure.
"""
function validate_reaction_map(model::MetabolicModel, reaction_map::ReactionMap)
    model_rxns = Set(model.rxn_ids)
    disabled_roles = Set(keys(reaction_map.disabled_reactions))
    found = Dict{String, String}()
    missing = Dict{String, String}()
    unknown = Dict{String, String}()

    for (role, rxn_id) in _active_reaction_roles(reaction_map)
        if role in disabled_roles
            continue
        end

        cleaned_id = strip(rxn_id)
        if isempty(cleaned_id)
            missing[role] = rxn_id
            unknown[role] = rxn_id
        elseif cleaned_id in model_rxns
            found[role] = cleaned_id
        else
            missing[role] = cleaned_id
            unknown[role] = cleaned_id
        end
    end

    disabled = copy(reaction_map.disabled_reactions)
    return ReactionMapValidationReport(found, missing, disabled, unknown, isempty(missing) && isempty(unknown))
end
