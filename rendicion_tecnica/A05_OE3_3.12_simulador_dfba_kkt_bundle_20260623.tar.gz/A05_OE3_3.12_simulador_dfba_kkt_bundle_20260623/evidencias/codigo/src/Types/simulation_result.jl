"""
    SimulationResult

Container for future sequential or simultaneous fermentation simulations.
"""
struct SimulationResult
    time::Vector{Float64}
    states::Matrix{Float64}
    fluxes::Union{Nothing, Matrix{Float64}}
    alphas::Union{Nothing, Matrix{Float64}}
    metadata::Dict{String, Any}
end

function SimulationResult(
    time::AbstractVector,
    states::AbstractMatrix;
    fluxes = nothing,
    alphas = nothing,
    metadata = Dict{String, Any}(),
)
    converted_time = Float64.(time)
    converted_states = Matrix{Float64}(states)
    converted_fluxes = fluxes === nothing ? nothing : Matrix{Float64}(fluxes)
    converted_alphas = alphas === nothing ? nothing : Matrix{Float64}(alphas)

    length(converted_time) == size(converted_states, 2) || error(
        "SimulationResult states must be stored as n_states x n_time. " *
        "Got $(size(converted_states, 2)) saved state columns for $(length(converted_time)) time points.",
    )
    if converted_fluxes !== nothing
        size(converted_fluxes, 2) == length(converted_time) || error(
            "SimulationResult fluxes must be stored as n_fluxes x n_time. " *
            "Got $(size(converted_fluxes, 2)) saved flux columns for $(length(converted_time)) time points.",
        )
    end
    if converted_alphas !== nothing
        size(converted_alphas, 2) == length(converted_time) || error(
            "SimulationResult alphas must be stored as n_alpha x n_time. " *
            "Got $(size(converted_alphas, 2)) saved alpha columns for $(length(converted_time)) time points.",
        )
    end

    return SimulationResult(
        converted_time,
        converted_states,
        converted_fluxes,
        converted_alphas,
        Dict{String, Any}(metadata),
    )
end
