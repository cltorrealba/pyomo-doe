"""
    MetabolicModel

Metabolic model data exported from MATLAB.

The stoichiometric matrix `S` is stored as a sparse Float64 matrix. Reaction
identifiers are stored separately from the sparse matrix values.
"""
struct MetabolicModel
    S::SparseMatrixCSC{Float64, Int}
    lb::Vector{Float64}
    ub::Vector{Float64}
    rxn_ids::Vector{String}
    met_ids::Vector{String}
    model_id::String
end

function MetabolicModel(
    S::AbstractMatrix,
    lb::AbstractVector,
    ub::AbstractVector,
    rxn_ids::AbstractVector,
    met_ids::AbstractVector;
    model_id::AbstractString = "reduced_model",
)
    return MetabolicModel(
        sparse(Float64.(S)),
        Float64.(lb),
        Float64.(ub),
        String.(rxn_ids),
        String.(met_ids),
        String(model_id),
    )
end

"""
    reaction_index(model, rxn_id)

Return the 1-based index of `rxn_id` in `model.rxn_ids`.
"""
function reaction_index(model::MetabolicModel, rxn_id::AbstractString)::Int
    cleaned_id = strip(String(rxn_id))
    index = findfirst(==(cleaned_id), model.rxn_ids)
    index === nothing && error("Reaction ID not found in model $(model.model_id): $cleaned_id")
    return index
end

"""
    has_reaction(model, rxn_id)

Return true when `rxn_id` is present in `model.rxn_ids`.
"""
function has_reaction(model::MetabolicModel, rxn_id::AbstractString)::Bool
    cleaned_id = strip(String(rxn_id))
    return findfirst(==(cleaned_id), model.rxn_ids) !== nothing
end

"""
    reaction_indices(model, rxn_ids)

Return 1-based indices for all reaction IDs in `rxn_ids`.
"""
function reaction_indices(model::MetabolicModel, rxn_ids::AbstractVector{<:AbstractString})::Vector{Int}
    return [reaction_index(model, rxn_id) for rxn_id in rxn_ids]
end
