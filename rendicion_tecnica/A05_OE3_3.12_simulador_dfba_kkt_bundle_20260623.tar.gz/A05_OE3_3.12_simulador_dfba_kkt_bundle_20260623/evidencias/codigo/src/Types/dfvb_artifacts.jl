"""
    DFVBArtifactPaths

Resolved paths for the MATLAB-exported DFVB artifact bundle.
"""
struct DFVBArtifactPaths
    artifact_id::String
    manifest_path::String
    reaction_order_path::String
    reduced_dfba_reaction_order_path::String
    exchange_partition_path::String
    exchange_partition_active_alpha_path::String
    n_sparse_triplets_path::String
    n_column_metadata_path::String
    n_active_alpha_sparse_triplets_path::String
    n_active_alpha_column_metadata_path::String
    active_alpha_indices_path::String
    alpha_bounds_path::String
    alpha_bounds_active_path::String
    alpha_trajectories_path::String
    alpha_trajectories_active_path::String
    state_trajectories_path::String
    inactive_reactions_path::String
    inactive_reactions_active_alpha_path::String
end

"""
    DFVBArtifactManifest

Core dimensions and raw metadata from `dfvb_artifact_manifest.json`.
"""
struct DFVBArtifactManifest
    n_reactions::Int
    n_metabolites::Int
    n_null_basis_columns::Int
    n_exchange_reactions::Int
    n_internal_reactions::Int
    n_dfvb_time_points::Int
    has_active_alpha_subset::Bool
    n_active_alpha_columns::Int
    raw::Dict{String, Any}
end

"""
    DFVBArtifacts

Loaded MATLAB-exported DFVB artifacts. This is a data contract only; no DFVB
optimization problem or RHS solve is constructed here.
"""
struct DFVBArtifacts
    paths::DFVBArtifactPaths
    manifest::DFVBArtifactManifest
    reaction_order::DataFrame
    reduced_dfba_reaction_order::DataFrame
    exchange_partition::DataFrame
    exchange_partition_active_alpha::DataFrame
    N::SparseMatrixCSC{Float64, Int}
    N_column_metadata::DataFrame
    N_active::SparseMatrixCSC{Float64, Int}
    N_active_column_metadata::DataFrame
    active_alpha_indices::DataFrame
    alpha_bounds::DataFrame
    alpha_bounds_active::DataFrame
    alpha_trajectories::Union{Nothing, DataFrame}
    alpha_trajectories_active::Union{Nothing, DataFrame}
    state_trajectories::Union{Nothing, DataFrame}
    inactive_reactions::DataFrame
    inactive_reactions_active_alpha::DataFrame
    metadata::Dict{String, Any}
end

"""
    DFVBArtifactValidationReport

Validation result for a loaded DFVB artifact bundle. `ok` means structural
dimension checks passed. Scientific caveats are reported as warnings.
"""
struct DFVBArtifactValidationReport
    ok::Bool
    errors::Vector{String}
    warnings::Vector{String}
    summary::Dict{String, Any}
end
