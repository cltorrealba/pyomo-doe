import HiGHS
import JuMP
import MathOptInterface as MOI

const REDUCED_DFBA_WARM_START_BENCHMARK_NAME = "reduced_dfba_lp_reuse_warm_start"
const REDUCED_DFBA_WARM_START_SCENARIOS = [
    "cold_rebuild",
    "persistent_no_start",
    "persistent_primal_start",
    "persistent_basis_primal_simplex",
]

const REDUCED_DFBA_WARM_START_SUMMARY_COLUMNS = [
    "scenario_id",
    "lp_strategy",
    "model_reuse",
    "primal_start",
    "basis_warm_start",
    "highs_solver",
    "highs_simplex_strategy",
    "n_evaluations",
    "successful_solves",
    "one_time_build_elapsed_seconds",
    "total_elapsed_seconds",
    "total_update_elapsed_seconds",
    "total_solve_elapsed_seconds",
    "mean_elapsed_seconds",
    "mean_update_elapsed_seconds",
    "mean_solve_elapsed_seconds",
    "total_simplex_iterations",
    "mean_simplex_iterations",
    "warm_start_applied_count",
    "basis_warm_start_applied_count",
    "basis_warm_start_failed_count",
    "basis_capture_count",
    "final_objective_value",
    "final_biomass_flux",
    "max_abs_objective_difference_vs_cold",
    "max_abs_flux_difference_vs_cold",
    "max_abs_dy_difference_vs_cold",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "notes",
]

const REDUCED_DFBA_WARM_START_SOLVE_COLUMNS = [
    "scenario_id",
    "eval_index",
    "mode",
    "objective_value",
    "biomass_flux",
    "elapsed_seconds",
    "update_elapsed_seconds",
    "solve_elapsed_seconds",
    "solver_reported_solve_time_seconds",
    "simplex_iterations",
    "warm_start_applied",
    "basis_warm_start_applied",
    "basis_warm_start_failed",
    "basis_capture_succeeded",
    "mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "objective_difference_vs_cold",
    "max_abs_flux_difference_vs_cold",
    "max_abs_dy_difference_vs_cold",
]

"""
    ReducedDFBAWarmStartBenchmarkResult

Plotting-free benchmark result for reduced DFBA LP rebuild versus persistent
JuMP/HiGHS model reuse with optional primal starts.
"""
struct ReducedDFBAWarmStartBenchmarkResult
    summary_table::DataFrame
    solve_table::DataFrame
    metadata::Dict{String, Any}
end

mutable struct _ReusableReducedDFBALP
    model::MetabolicModel
    reaction_map::ReactionMap
    jump_model::JuMP.Model
    flux_variables::Vector{JuMP.VariableRef}
    absolute_flux_variables::Union{Nothing, Vector{JuMP.VariableRef}}
    base_lb::Vector{Float64}
    base_ub::Vector{Float64}
    current_lb::Vector{Float64}
    current_ub::Vector{Float64}
    current_dynamic_indices::Set{Int}
    previous_fluxes::Union{Nothing, Vector{Float64}}
    previous_basis_colstatus::Union{Nothing, Vector{HiGHS.HighsInt}}
    previous_basis_rowstatus::Union{Nothing, Vector{HiGHS.HighsInt}}
    fba_variant::String
    quadratic_penalty::Float64
    l1_penalty::Float64
    qpfba_persistent_fallback_count::Base.RefValue{Int}
    build_elapsed_seconds::Float64
end

"""
    benchmark_reduced_dfba_warm_start(model, reaction_map; kwargs...)

Evaluate reduced DFBA RHS LP performance for three strategies:
`cold_rebuild`, `persistent_no_start`, and `persistent_primal_start`.
The benchmark is diagnostic only; it does not change the default simulator.
"""
function benchmark_reduced_dfba_warm_start(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    n_evaluations::Integer = 8,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    optimizer = HiGHS.Optimizer,
    highs_solver::AbstractString = "simplex",
    highs_simplex_strategy::AbstractString = "default",
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
)::ReducedDFBAWarmStartBenchmarkResult
    n = Int(n_evaluations)
    n > 0 || error("Reduced DFBA warm-start benchmark n_evaluations must be positive.")
    tolerance = Float64(lp_atol)
    isfinite(tolerance) && tolerance > 0.0 ||
        error("Reduced DFBA warm-start benchmark lp_atol must be finite and positive, got $lp_atol.")
    validate_reduced_model_dimensions(model; throw_on_error = true)
    validate_reaction_map(model, reaction_map).ok ||
        error("Reduced DFBA warm-start benchmark requires a valid reduced reaction map.")
    _assert_dfba_oxygen_not_r0001(reaction_map)

    state_grid = _reduced_dfba_warm_start_state_grid(y0, n)
    normalized_simplex_strategy = _reduced_dfba_warm_start_simplex_strategy_label(highs_simplex_strategy)
    basis_simplex_strategy = normalized_simplex_strategy == "default" ? "primal" : normalized_simplex_strategy
    optimizer_factory = _reduced_dfba_warm_start_optimizer(
        optimizer,
        highs_solver;
        highs_simplex_strategy = normalized_simplex_strategy,
    )
    basis_optimizer_factory = _reduced_dfba_warm_start_optimizer(
        optimizer,
        highs_solver;
        highs_simplex_strategy = basis_simplex_strategy,
    )
    normalized_solver = _reduced_dfba_warm_start_solver_label(highs_solver)

    cold_rows, cold_results = _run_reduced_dfba_warm_start_cold_scenario(
        model,
        reaction_map,
        state_grid;
        params = params,
        optimizer = optimizer_factory,
        silent = silent,
        lp_atol = tolerance,
        highs_solver = normalized_solver,
        highs_simplex_strategy = normalized_simplex_strategy,
    )
    no_start_rows = _run_reduced_dfba_warm_start_persistent_scenario(
        "persistent_no_start",
        model,
        reaction_map,
        state_grid,
        cold_results;
        params = params,
        optimizer = optimizer_factory,
        silent = silent,
        lp_atol = tolerance,
        highs_solver = normalized_solver,
        highs_simplex_strategy = normalized_simplex_strategy,
        primal_start = false,
        basis_warm_start = false,
    )
    primal_start_rows = _run_reduced_dfba_warm_start_persistent_scenario(
        "persistent_primal_start",
        model,
        reaction_map,
        state_grid,
        cold_results;
        params = params,
        optimizer = optimizer_factory,
        silent = silent,
        lp_atol = tolerance,
        highs_solver = normalized_solver,
        highs_simplex_strategy = normalized_simplex_strategy,
        primal_start = true,
        basis_warm_start = false,
    )
    basis_start_rows = _run_reduced_dfba_warm_start_persistent_scenario(
        "persistent_basis_primal_simplex",
        model,
        reaction_map,
        state_grid,
        cold_results;
        params = params,
        optimizer = basis_optimizer_factory,
        silent = silent,
        lp_atol = tolerance,
        highs_solver = normalized_solver,
        highs_simplex_strategy = basis_simplex_strategy,
        primal_start = false,
        basis_warm_start = true,
    )

    rows = vcat(cold_rows, no_start_rows, primal_start_rows, basis_start_rows)
    solve_table = _reduced_dfba_warm_start_solve_table(rows)
    summary_table = _reduced_dfba_warm_start_summary_table(rows)
    metadata = Dict{String, Any}(
        "benchmark_name" => REDUCED_DFBA_WARM_START_BENCHMARK_NAME,
        "model_id" => model.model_id,
        "scenario_ids" => copy(REDUCED_DFBA_WARM_START_SCENARIOS),
        "n_evaluations" => n,
        "highs_solver" => normalized_solver,
        "highs_simplex_strategy" => normalized_simplex_strategy,
        "basis_highs_simplex_strategy" => basis_simplex_strategy,
        "lp_atol" => tolerance,
        "state_grid_policy" => "deterministic_reduced_fermentation_state_grid_from_default_y0",
        "model_reuse_included" => true,
        "primal_start_included" => true,
        "basis_warm_start_included" => true,
        "default_simulation_path_changed" => false,
        "ode_simulation_lp_reuse_guarded" => true,
        "rhs_equivalence_checked" => true,
        "trajectory_equivalence_checked" => false,
        "trajectory_equivalence_passed" => false,
        "experimental_lp_reuse" => true,
        "scientific_output_equivalent" => false,
        "gurobi_required" => false,
        "interpretation_note" =>
            "Diagnostic reduced DFBA RHS LP benchmark only. Persistent JuMP model reuse, primal starts, and HiGHS basis warm starts are evaluated on isolated RHS states and do not prove ODE trajectory equivalence.",
        "rhs_equivalence_note" =>
            "max_abs_dy_difference_vs_cold compares isolated RHS evaluations on a deterministic state grid; adaptive ODE trajectories remain guarded unless explicitly opted into as experimental diagnostics.",
        "basis_warm_start_note" =>
            "HiGHS basis warm starts reuse the previous simplex basis with solver=simplex and simplex_strategy=primal by default for the basis scenario.",
        "oxygen_reaction_id" => "r_1992",
        "r0001_used_as_oxygen" => false,
        "carbohydrate_policy_note" => "carbohydrate dy[8] remains empirical and is not driven by r_4048",
    )

    return ReducedDFBAWarmStartBenchmarkResult(summary_table, solve_table, metadata)
end

"""
    export_reduced_dfba_warm_start_benchmark(result, output_dir; overwrite=false)

Write CSV/TOML artifacts for the reduced DFBA LP reuse and primal-start
benchmark.
"""
function export_reduced_dfba_warm_start_benchmark(
    result::ReducedDFBAWarmStartBenchmarkResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Reduced DFBA warm-start benchmark output_dir exists and is not a directory: $output_path")
    end
    paths = Dict{String, String}(
        "summary" => joinpath(output_path, "reduced_dfba_warm_start_benchmark_summary.csv"),
        "solves" => joinpath(output_path, "reduced_dfba_warm_start_benchmark_solves.csv"),
        "metadata" => joinpath(output_path, "reduced_dfba_warm_start_benchmark_metadata.toml"),
    )
    existing_targets = [path for path in values(paths) if isfile(path)]
    if !overwrite && !isempty(existing_targets)
        error(
            "Reduced DFBA warm-start benchmark target file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end

    mkpath(output_path)
    if overwrite
        for path in values(paths)
            isfile(path) && rm(path)
        end
    end

    CSV.write(paths["summary"], result.summary_table)
    CSV.write(paths["solves"], result.solve_table)
    open(paths["metadata"], "w") do io
        TOML.print(io, _reduced_dfba_warm_start_toml_normalize(result.metadata))
    end
    return paths
end

function _reduced_dfba_warm_start_optimizer(
    optimizer,
    highs_solver::AbstractString;
    highs_simplex_strategy::AbstractString = "default",
)
    solver = String(strip(String(highs_solver)))
    simplex_strategy = _reduced_dfba_warm_start_simplex_strategy_value(highs_simplex_strategy)
    attributes = Pair{String, Any}[]
    if !(isempty(solver) || lowercase(solver) == "default")
        push!(attributes, "solver" => solver)
    end
    if simplex_strategy !== nothing
        push!(attributes, "simplex_strategy" => simplex_strategy)
    end
    isempty(attributes) && return optimizer
    return JuMP.optimizer_with_attributes(optimizer, attributes...)
end

function _reduced_dfba_warm_start_optimizer(
    optimizer::MOI.OptimizerWithAttributes,
    highs_solver::AbstractString;
    highs_simplex_strategy::AbstractString = "default",
)
    solver = String(strip(String(highs_solver)))
    simplex_strategy = _reduced_dfba_warm_start_simplex_strategy_value(highs_simplex_strategy)
    attributes = Pair{String, Any}[]
    if !(isempty(solver) || lowercase(solver) == "default")
        push!(attributes, "solver" => solver)
    end
    if simplex_strategy !== nothing
        push!(attributes, "simplex_strategy" => simplex_strategy)
    end
    isempty(attributes) && return optimizer
    return JuMP.optimizer_with_attributes(
        optimizer.optimizer_constructor,
        optimizer.params...,
        attributes...,
    )
end

function _reduced_dfba_warm_start_solver_label(highs_solver::AbstractString)::String
    solver = strip(String(highs_solver))
    isempty(solver) && return "default"
    return solver
end

function _reduced_dfba_warm_start_simplex_strategy_label(highs_simplex_strategy::AbstractString)::String
    normalized = lowercase(strip(String(highs_simplex_strategy)))
    isempty(normalized) && return "default"
    normalized == "default" && return "default"
    if normalized in ("choose", "0")
        return "choose"
    elseif normalized in ("dual", "dual_plain", "1")
        return "dual"
    elseif normalized in ("dual_tasks", "2")
        return "dual_tasks"
    elseif normalized in ("dual_multi", "3")
        return "dual_multi"
    elseif normalized in ("primal", "4")
        return "primal"
    end
    error(
        "Unsupported HiGHS simplex strategy: $highs_simplex_strategy. " *
        "Use default, choose, dual, dual_tasks, dual_multi, primal, or integer 0:4.",
    )
end

function _reduced_dfba_warm_start_simplex_strategy_value(highs_simplex_strategy::AbstractString)
    label = _reduced_dfba_warm_start_simplex_strategy_label(highs_simplex_strategy)
    label == "default" && return nothing
    label == "choose" && return 0
    label == "dual" && return 1
    label == "dual_tasks" && return 2
    label == "dual_multi" && return 3
    label == "primal" && return 4
    error("Unsupported normalized HiGHS simplex strategy label: $label.")
end

function _reduced_dfba_warm_start_state_grid(y0::AbstractVector, n::Int)::Matrix{Float64}
    base = Float64.(y0)
    length(base) == 19 || error("Reduced DFBA warm-start benchmark y0 must have length 19.")
    states = Matrix{Float64}(undef, 19, n)
    denominator = max(n - 1, 1)
    for k in 1:n
        fraction = (k - 1) / denominator
        state = copy(base)
        state[1] = max(0.0, base[1] * (1.0 + 0.04 * fraction))
        state[2] = max(0.002, base[2] * (1.0 - 0.20 * fraction))
        state[3] = max(0.0, base[3] * (1.0 - 0.08 * fraction))
        state[4] = max(0.0, base[4] * (1.0 - 0.08 * fraction))
        state[5] = max(0.0, base[5] + 0.08 * fraction)
        state[6] = 0.0
        state[7] = max(0.0, base[7] * (1.0 + 0.01 * fraction))
        state[8] = max(0.0, base[8] * (1.0 + 0.01 * fraction))
        for i in 9:13
            state[i] = max(0.0, base[i] * (1.0 - 0.05 * fraction))
        end
        for i in 14:19
            state[i] = max(0.0, base[i] + 1.0e-4 * fraction)
        end
        states[:, k] .= state
    end
    return states
end

function _run_reduced_dfba_warm_start_cold_scenario(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    state_grid::AbstractMatrix;
    params::ZentenoKineticParameters,
    optimizer,
    silent::Bool,
    lp_atol::Float64,
    highs_solver::AbstractString,
    highs_simplex_strategy::AbstractString,
)
    rows = Dict{String, Any}[]
    results = DFBARHSResult[]
    biomass_id = _dfba_required_core_reaction_id(reaction_map, "biomass_growth")
    for k in axes(state_grid, 2)
        rhs_result = nothing
        elapsed = @elapsed begin
            rhs_result = compute_dfba_rhs(
                model,
                reaction_map,
                view(state_grid, :, k);
                params = params,
                optimizer = optimizer,
                silent = silent,
                atol = lp_atol,
            )
        end
        push!(results, rhs_result)
        push!(
            rows,
            _reduced_dfba_warm_start_solve_row(
                "cold_rebuild",
                k,
                rhs_result,
                biomass_id;
                elapsed_seconds = elapsed,
                update_elapsed_seconds = missing,
                solve_elapsed_seconds = missing,
                warm_start_applied = false,
                basis_warm_start_applied = false,
                basis_warm_start_failed = false,
                basis_capture_succeeded = false,
                highs_solver = highs_solver,
                highs_simplex_strategy = highs_simplex_strategy,
                lp_strategy = "cold_rebuild",
                model_reuse = false,
                primal_start = false,
                basis_warm_start = false,
                one_time_build_elapsed_seconds = missing,
                cold_result = rhs_result,
            ),
        )
    end
    return rows, results
end

function _run_reduced_dfba_warm_start_persistent_scenario(
    scenario_id::AbstractString,
    model::MetabolicModel,
    reaction_map::ReactionMap,
    state_grid::AbstractMatrix,
    cold_results::Vector{DFBARHSResult};
    params::ZentenoKineticParameters,
    optimizer,
    silent::Bool,
    lp_atol::Float64,
    highs_solver::AbstractString,
    highs_simplex_strategy::AbstractString,
    primal_start::Bool,
    basis_warm_start::Bool,
)
    cache = _build_reusable_reduced_dfba_lp(
        model,
        reaction_map;
        optimizer = optimizer,
        silent = silent,
        basis_warm_start = basis_warm_start,
    )
    rows = Dict{String, Any}[]
    biomass_id = _dfba_required_core_reaction_id(reaction_map, "biomass_growth")
    for k in axes(state_grid, 2)
        rhs_result = nothing
        timings = nothing
        elapsed = @elapsed begin
            rhs_result, timings = _compute_reusable_reduced_dfba_rhs!(
                cache,
                view(state_grid, :, k);
                params = params,
                lp_atol = lp_atol,
                primal_start = primal_start,
                basis_warm_start = basis_warm_start,
            )
        end
        push!(
            rows,
            _reduced_dfba_warm_start_solve_row(
                scenario_id,
                k,
                rhs_result,
                biomass_id;
                elapsed_seconds = elapsed,
                update_elapsed_seconds = timings.update_elapsed_seconds,
                solve_elapsed_seconds = timings.solve_elapsed_seconds,
                warm_start_applied = timings.warm_start_applied,
                basis_warm_start_applied = timings.basis_warm_start_applied,
                basis_warm_start_failed = timings.basis_warm_start_failed,
                basis_capture_succeeded = timings.basis_capture_succeeded,
                highs_solver = highs_solver,
                highs_simplex_strategy = highs_simplex_strategy,
                lp_strategy = "persistent_model",
                model_reuse = true,
                primal_start = primal_start,
                basis_warm_start = basis_warm_start,
                one_time_build_elapsed_seconds = cache.build_elapsed_seconds,
                cold_result = cold_results[k],
            ),
        )
    end
    return rows
end

function _build_reusable_reduced_dfba_lp(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    optimizer,
    silent::Bool,
    basis_warm_start::Bool = false,
    fba_variant::AbstractString = "fba",
    quadratic_penalty::Real = 0.0,
    l1_penalty::Real = 0.0,
)::_ReusableReducedDFBALP
    biomass_id = _dfba_required_core_reaction_id(reaction_map, "biomass_growth")
    normalized_fba_variant = _normalize_dfba_fba_variant(fba_variant)
    qp_penalty = normalized_fba_variant == "qpfba" ?
        _validate_qp_regularized_fba_penalty(quadratic_penalty) :
        0.0
    l1_regularization_penalty = normalized_fba_variant == "l1pfba" ?
        _validate_l1_regularized_fba_penalty(l1_penalty) :
        0.0
    normalized_fba_variant == "qpfba" && basis_warm_start && error(
        "Reusable DFBA qpfba cache does not support HiGHS basis warm starts.",
    )
    problem = nothing
    build_elapsed_seconds = @elapsed begin
        problem = if normalized_fba_variant == "qpfba"
            build_qp_regularized_fba_problem(
                model;
                objective_weights = Dict(biomass_id => 1.0),
                quadratic_penalty = qp_penalty,
                optimizer = optimizer,
                silent = silent,
            )
        elseif normalized_fba_variant == "l1pfba"
            build_l1_regularized_fba_problem(
                model;
                objective_weights = Dict(biomass_id => 1.0),
                l1_penalty = l1_regularization_penalty,
                optimizer = optimizer,
                silent = silent,
            )
        else
            build_fba_problem(
                model;
                objective_weights = Dict(biomass_id => 1.0),
                optimizer = optimizer,
                silent = silent,
            )
        end
    end
    basis_warm_start && _assert_reusable_reduced_dfba_basis_supported(problem.jump_model)
    return _ReusableReducedDFBALP(
        model,
        reaction_map,
        problem.jump_model,
        collect(problem.fluxes),
        hasproperty(problem, :absolute_fluxes) ? collect(problem.absolute_fluxes) : nothing,
        copy(model.lb),
        copy(model.ub),
        copy(model.lb),
        copy(model.ub),
        Set{Int}(),
        nothing,
        nothing,
        nothing,
        normalized_fba_variant,
        qp_penalty,
        l1_regularization_penalty,
        Ref(0),
        build_elapsed_seconds,
    )
end

function _compute_reusable_reduced_dfba_rhs!(
    cache::_ReusableReducedDFBALP,
    y::AbstractVector;
    params::ZentenoKineticParameters,
    lp_atol::Float64,
    primal_start::Bool,
    basis_warm_start::Bool = false,
)
    state = zenteno_state_from_vector(y)
    bounds = zenteno_dynamic_bounds(cache.model, cache.reaction_map, state, params)
    timings = _solve_reusable_reduced_dfba_lp!(
        cache,
        bounds;
        lp_atol = lp_atol,
        primal_start = primal_start,
        basis_warm_start = basis_warm_start,
    )
    _assert_dfba_fba_optimal(timings.fba)
    rhs_result = _dfba_rhs_result_from_fba(cache.model, cache.reaction_map, state, bounds, timings.fba, params)
    return rhs_result, timings
end

function _solve_reusable_reduced_dfba_lp!(
    cache::_ReusableReducedDFBALP,
    bounds::ZentenoDynamicBounds;
    lp_atol::Float64,
    primal_start::Bool,
    basis_warm_start::Bool = false,
)
    warm_start_applied = false
    basis_warm_start_applied = false
    basis_warm_start_failed = false
    basis_capture_succeeded = false
    basis_warm_start_return_code = missing
    update_elapsed_seconds = @elapsed begin
        _update_reusable_reduced_dfba_bounds!(cache, bounds)
        _update_reusable_reduced_dfba_objective!(cache, bounds)
        if basis_warm_start && cache.previous_basis_colstatus !== nothing
            basis_result = _apply_reusable_reduced_dfba_basis_start!(cache)
            basis_warm_start_applied = basis_result.applied
            basis_warm_start_failed = !basis_result.applied
            basis_warm_start_return_code = basis_result.return_code
        end
        if primal_start && cache.previous_fluxes !== nothing
            for i in eachindex(cache.flux_variables)
                JuMP.set_start_value(cache.flux_variables[i], cache.previous_fluxes[i])
            end
            warm_start_applied = true
        elseif primal_start
            _clear_reusable_reduced_dfba_primal_start!(cache)
        end
    end
    solve_elapsed_seconds = @elapsed JuMP.optimize!(cache.jump_model)

    status = JuMP.termination_status(cache.jump_model)
    primal_status = JuMP.primal_status(cache.jump_model)
    dual_status = JuMP.dual_status(cache.jump_model)
    has_primal = primal_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT)
    fluxes = has_primal ? Float64.(JuMP.value.(cache.flux_variables)) : Float64[]
    objective_value = has_primal ? Float64(JuMP.objective_value(cache.jump_model)) : NaN
    mass_balance_residual = has_primal ? check_mass_balance(cache.model, fluxes; atol = lp_atol) : Inf
    max_lower_bound_violation = has_primal ? maximum(max.(0.0, cache.current_lb .- fluxes)) : Inf
    max_upper_bound_violation = has_primal ? maximum(max.(0.0, fluxes .- cache.current_ub)) : Inf
    if has_primal
        cache.previous_fluxes = copy(fluxes)
        if basis_warm_start
            basis_capture_succeeded = _capture_reusable_reduced_dfba_basis!(cache)
            if !basis_capture_succeeded
                cache.previous_basis_colstatus = nothing
                cache.previous_basis_rowstatus = nothing
            end
        end
    else
        cache.previous_fluxes = nothing
        cache.previous_basis_colstatus = nothing
        cache.previous_basis_rowstatus = nothing
    end

    objective = _normalize_fba_objective(
        cache.model;
        objective_rxn_id = nothing,
        objective_weights = bounds.objective_weights,
    )
    extra_metadata = Dict{String, Any}(
            "sense" => :max,
            "primal_status" => primal_status,
            "dual_status" => dual_status,
            "solver_name" => _solver_name(cache.jump_model),
            "solver_reported_solve_time_seconds" =>
                _moi_model_attribute_or_missing(cache.jump_model, MOI.SolveTimeSec()),
            "simplex_iterations" => _moi_model_attribute_or_missing(cache.jump_model, MOI.SimplexIterations()),
            "raw_status_string" => _moi_model_attribute_or_missing(cache.jump_model, MOI.RawStatusString()),
            "objective_type" => objective.objective_type,
            "n_objective_terms" => length(objective.objective_weights),
            "model_reuse" => true,
            "lp_reuse_validity_scope" => "rhs_diagnostic_only",
            "trajectory_equivalence_checked" => false,
            "scientific_output_equivalent" => false,
            "primal_start_requested" => primal_start,
            "basis_warm_start_requested" => basis_warm_start,
            "warm_start_applied" => warm_start_applied,
            "basis_warm_start_applied" => basis_warm_start_applied,
            "basis_warm_start_failed" => basis_warm_start_failed,
            "basis_capture_succeeded" => basis_capture_succeeded,
            "basis_warm_start_return_code" => basis_warm_start_return_code,
            "lp_update_elapsed_seconds" => update_elapsed_seconds,
            "lp_solve_elapsed_seconds" => solve_elapsed_seconds,
    )
    fba = if cache.fba_variant == "qpfba"
        delete!(extra_metadata, "sense")
        delete!(extra_metadata, "objective_type")
        problem = (
            jump_model = cache.jump_model,
            fluxes = cache.flux_variables,
            objective_rxn_id = objective.objective_rxn_id,
            objective_index = objective.objective_index,
            objective_weights = objective.objective_weights,
            objective_description = objective.objective_description,
            objective_type = objective.objective_type,
            quadratic_penalty = cache.quadratic_penalty,
        )
        qpfba = _qp_regularized_fba_result_from_problem(
            cache.model,
            problem;
            atol = lp_atol,
            model_reuse = true,
            extra_metadata = extra_metadata,
        )
        if _reusable_qpfba_result_acceptable(qpfba)
            qpfba
        else
            cache.qpfba_persistent_fallback_count[] += 1
            fallback_elapsed = 0.0
            fallback = nothing
            fallback_elapsed = @elapsed begin
                fallback = solve_qp_regularized_fba(
                    apply_dynamic_bounds(cache.model, bounds);
                    objective_weights = bounds.objective_weights,
                    quadratic_penalty = cache.quadratic_penalty,
                    optimizer = HiGHS.Optimizer,
                    silent = true,
                    atol = lp_atol,
                )
            end
            fallback_metadata = copy(fallback.metadata)
            merge!(fallback.metadata, extra_metadata)
            for key in (
                "primal_status",
                "dual_status",
                "solver_name",
                "solver_reported_solve_time_seconds",
                "simplex_iterations",
                "raw_status_string",
                "objective_type",
                "fba_variant",
                "quadratic_penalty",
                "primary_objective_value",
                "quadratic_penalty_value",
                "regularized_objective_value",
                "solver_min_objective_value",
            )
                haskey(fallback_metadata, key) && (fallback.metadata[key] = fallback_metadata[key])
            end
            fallback.metadata["qpfba_persistent_fallback"] = true
            fallback.metadata["qpfba_persistent_fallback_reason"] =
                "persistent_qpfba_status_or_violation_not_acceptable"
            fallback.metadata["qpfba_persistent_status"] = qpfba.status
            fallback.metadata["qpfba_persistent_primal_status"] =
                get(qpfba.metadata, "primal_status", missing)
            fallback.metadata["qpfba_persistent_dual_status"] =
                get(qpfba.metadata, "dual_status", missing)
            fallback.metadata["qpfba_persistent_mass_balance_residual"] = qpfba.mass_balance_residual
            fallback.metadata["qpfba_persistent_max_lower_bound_violation"] =
                qpfba.max_lower_bound_violation
            fallback.metadata["qpfba_persistent_max_upper_bound_violation"] =
                qpfba.max_upper_bound_violation
            fallback.metadata["qpfba_persistent_fallback_elapsed_seconds"] = fallback_elapsed
            fallback.metadata["model_reuse"] = false
            fallback
        end
    elseif cache.fba_variant == "l1pfba"
        cache.absolute_flux_variables === nothing && error(
            "Reusable DFBA l1pfba cache is missing absolute-flux variables.",
        )
        delete!(extra_metadata, "sense")
        delete!(extra_metadata, "objective_type")
        problem = (
            jump_model = cache.jump_model,
            fluxes = cache.flux_variables,
            absolute_fluxes = cache.absolute_flux_variables,
            objective_rxn_id = objective.objective_rxn_id,
            objective_index = objective.objective_index,
            objective_weights = objective.objective_weights,
            objective_description = objective.objective_description,
            objective_type = objective.objective_type,
            l1_penalty = cache.l1_penalty,
        )
        _l1_regularized_fba_result_from_problem(
            cache.model,
            problem;
            atol = lp_atol,
            model_reuse = true,
            extra_metadata = extra_metadata,
        )
    else
        FBAResult(
            status,
            objective_value,
            fluxes,
            objective.objective_rxn_id,
            objective.objective_index,
            copy(objective.objective_weights),
            objective.objective_description,
            mass_balance_residual,
            max_lower_bound_violation,
            max_upper_bound_violation,
            extra_metadata,
        )
    end
    return (
        fba = fba,
        update_elapsed_seconds = update_elapsed_seconds,
        solve_elapsed_seconds = solve_elapsed_seconds,
        warm_start_applied = warm_start_applied,
        basis_warm_start_applied = basis_warm_start_applied,
        basis_warm_start_failed = basis_warm_start_failed,
        basis_capture_succeeded = basis_capture_succeeded,
    )
end

function _assert_reusable_reduced_dfba_basis_supported(jump_model::JuMP.Model)
    backend = try
        JuMP.unsafe_backend(jump_model)
    catch err
        error("HiGHS basis warm start requires direct access to a HiGHS optimizer backend. $(sprint(showerror, err))")
    end
    backend isa HiGHS.Optimizer || error(
        "HiGHS basis warm start requires HiGHS. Got backend $(typeof(backend)).",
    )
    return nothing
end

function _clear_reusable_reduced_dfba_primal_start!(cache::_ReusableReducedDFBALP)
    for variable in cache.flux_variables
        JuMP.set_start_value(variable, nothing)
    end
    return nothing
end

function _apply_reusable_reduced_dfba_basis_start!(cache::_ReusableReducedDFBALP)
    if cache.previous_basis_colstatus === nothing || cache.previous_basis_rowstatus === nothing
        return (applied = false, return_code = missing)
    end
    backend = JuMP.unsafe_backend(cache.jump_model)
    backend isa HiGHS.Optimizer || return (applied = false, return_code = missing)
    return_code = HiGHS.Highs_setBasis(
        backend,
        cache.previous_basis_colstatus,
        cache.previous_basis_rowstatus,
    )
    return (applied = return_code == HiGHS.kHighsStatusOk, return_code = Int(return_code))
end

function _capture_reusable_reduced_dfba_basis!(cache::_ReusableReducedDFBALP)::Bool
    backend = JuMP.unsafe_backend(cache.jump_model)
    backend isa HiGHS.Optimizer || return false
    colstatus = backend.solution.colstatus
    rowstatus = backend.solution.rowstatus
    isempty(colstatus) && return false
    isempty(rowstatus) && return false
    cache.previous_basis_colstatus = copy(colstatus)
    cache.previous_basis_rowstatus = copy(rowstatus)
    return true
end

function _update_reusable_reduced_dfba_bounds!(
    cache::_ReusableReducedDFBALP,
    bounds::ZentenoDynamicBounds,
)
    touched = Set{Int}()
    for rxn_id in sort(collect(keys(bounds.lb_updates)))
        push!(touched, reaction_index(cache.model, rxn_id))
    end
    for rxn_id in sort(collect(keys(bounds.ub_updates)))
        push!(touched, reaction_index(cache.model, rxn_id))
    end
    reset_indices = sort!(collect(union(cache.current_dynamic_indices, touched)))
    for index in reset_indices
        desired_lb = cache.base_lb[index]
        desired_ub = cache.base_ub[index]
        cache.current_lb[index] = desired_lb
        cache.current_ub[index] = desired_ub
    end
    for rxn_id in sort(collect(keys(bounds.lb_updates)))
        value = bounds.lb_updates[rxn_id]
        cache.current_lb[reaction_index(cache.model, rxn_id)] = value
    end
    for rxn_id in sort(collect(keys(bounds.ub_updates)))
        value = bounds.ub_updates[rxn_id]
        cache.current_ub[reaction_index(cache.model, rxn_id)] = value
    end
    for index in reset_indices
        cache.current_lb[index] <= cache.current_ub[index] || error(
            "Reusable reduced DFBA LP dynamic bounds produced lb > ub for $(cache.model.rxn_ids[index]).",
        )
        JuMP.set_lower_bound(cache.flux_variables[index], cache.current_lb[index])
        JuMP.set_upper_bound(cache.flux_variables[index], cache.current_ub[index])
    end
    cache.current_dynamic_indices = touched
    return nothing
end

function _update_reusable_reduced_dfba_objective!(
    cache::_ReusableReducedDFBALP,
    bounds::ZentenoDynamicBounds,
)
    objective_expression = _fba_objective_expression(cache.model, cache.flux_variables, bounds.objective_weights)
    if cache.fba_variant == "qpfba"
        JuMP.set_objective_sense(cache.jump_model, MOI.MIN_SENSE)
        JuMP.set_objective_function(
            cache.jump_model,
            -objective_expression + cache.quadratic_penalty * sum(v^2 for v in cache.flux_variables),
        )
    elseif cache.fba_variant == "l1pfba"
        cache.absolute_flux_variables === nothing && error(
            "Reusable DFBA l1pfba cache is missing absolute-flux variables.",
        )
        JuMP.set_objective_sense(cache.jump_model, MOI.MIN_SENSE)
        JuMP.set_objective_function(
            cache.jump_model,
            -objective_expression +
            cache.l1_penalty * sum(z for z in cache.absolute_flux_variables),
        )
    else
        JuMP.set_objective_sense(cache.jump_model, MOI.MAX_SENSE)
        JuMP.set_objective_function(cache.jump_model, objective_expression)
    end
    return nothing
end

function _reusable_qpfba_result_acceptable(fba::FBAResult)::Bool
    return fba.status == MOI.OPTIMAL || _dfba_accept_qpfba_near_optimal(fba)
end

function _reduced_dfba_warm_start_solve_row(
    scenario_id::AbstractString,
    eval_index::Integer,
    rhs_result::DFBARHSResult,
    biomass_id::AbstractString;
    elapsed_seconds,
    update_elapsed_seconds,
    solve_elapsed_seconds,
    warm_start_applied::Bool,
    basis_warm_start_applied::Bool,
    basis_warm_start_failed::Bool,
    basis_capture_succeeded::Bool,
    highs_solver::AbstractString,
    highs_simplex_strategy::AbstractString,
    lp_strategy::AbstractString,
    model_reuse::Bool,
    primal_start::Bool,
    basis_warm_start::Bool,
    one_time_build_elapsed_seconds,
    cold_result::DFBARHSResult,
)::Dict{String, Any}
    objective_difference = rhs_result.fba.objective_value - cold_result.fba.objective_value
    flux_difference = length(rhs_result.fba.fluxes) == length(cold_result.fba.fluxes) ?
        maximum(abs.(rhs_result.fba.fluxes .- cold_result.fba.fluxes)) :
        Inf
    dy_difference = maximum(abs.(rhs_result.dy .- cold_result.dy))
    return Dict{String, Any}(
        "scenario_id" => String(scenario_id),
        "eval_index" => Int(eval_index),
        "mode" => String(rhs_result.mode),
        "objective_value" => rhs_result.fba.objective_value,
        "biomass_flux" => rhs_result.fluxes_by_rxn[String(biomass_id)],
        "elapsed_seconds" => elapsed_seconds,
        "update_elapsed_seconds" => update_elapsed_seconds,
        "solve_elapsed_seconds" => solve_elapsed_seconds,
        "solver_reported_solve_time_seconds" =>
            get(rhs_result.fba.metadata, "solver_reported_solve_time_seconds", missing),
        "simplex_iterations" => get(rhs_result.fba.metadata, "simplex_iterations", missing),
        "warm_start_applied" => warm_start_applied,
        "basis_warm_start_applied" => basis_warm_start_applied,
        "basis_warm_start_failed" => basis_warm_start_failed,
        "basis_capture_succeeded" => basis_capture_succeeded,
        "mass_balance_residual" => rhs_result.fba.mass_balance_residual,
        "max_lower_bound_violation" => rhs_result.fba.max_lower_bound_violation,
        "max_upper_bound_violation" => rhs_result.fba.max_upper_bound_violation,
        "objective_difference_vs_cold" => objective_difference,
        "max_abs_flux_difference_vs_cold" => flux_difference,
        "max_abs_dy_difference_vs_cold" => dy_difference,
        "lp_strategy" => String(lp_strategy),
        "model_reuse" => model_reuse,
        "primal_start" => primal_start,
        "basis_warm_start" => basis_warm_start,
        "highs_solver" => String(highs_solver),
        "highs_simplex_strategy" => String(highs_simplex_strategy),
        "one_time_build_elapsed_seconds" => one_time_build_elapsed_seconds,
    )
end

function _reduced_dfba_warm_start_solve_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_dfba_warm_start_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DFBA_WARM_START_SOLVE_COLUMNS
        )...,
    )
end

function _reduced_dfba_warm_start_summary_table(rows::Vector{Dict{String, Any}})::DataFrame
    summary_rows = Dict{String, Any}[]
    for scenario_id in REDUCED_DFBA_WARM_START_SCENARIOS
        scenario_rows = [row for row in rows if row["scenario_id"] == scenario_id]
        isempty(scenario_rows) && continue
        n = length(scenario_rows)
        elapsed = Float64.([row["elapsed_seconds"] for row in scenario_rows])
        update_elapsed = _reduced_dfba_warm_start_numeric_values(scenario_rows, "update_elapsed_seconds")
        solve_elapsed = _reduced_dfba_warm_start_numeric_values(scenario_rows, "solve_elapsed_seconds")
        simplex_iterations = _reduced_dfba_warm_start_numeric_values(scenario_rows, "simplex_iterations")
        final_row = scenario_rows[end]
        push!(
            summary_rows,
            Dict{String, Any}(
                "scenario_id" => scenario_id,
                "lp_strategy" => final_row["lp_strategy"],
                "model_reuse" => final_row["model_reuse"],
                "primal_start" => final_row["primal_start"],
                "basis_warm_start" => final_row["basis_warm_start"],
                "highs_solver" => final_row["highs_solver"],
                "highs_simplex_strategy" => final_row["highs_simplex_strategy"],
                "n_evaluations" => n,
                "successful_solves" => n,
                "one_time_build_elapsed_seconds" => final_row["one_time_build_elapsed_seconds"],
                "total_elapsed_seconds" => sum(elapsed),
                "total_update_elapsed_seconds" => isempty(update_elapsed) ? missing : sum(update_elapsed),
                "total_solve_elapsed_seconds" => isempty(solve_elapsed) ? missing : sum(solve_elapsed),
                "mean_elapsed_seconds" => sum(elapsed) / n,
                "mean_update_elapsed_seconds" => isempty(update_elapsed) ? missing : sum(update_elapsed) / n,
                "mean_solve_elapsed_seconds" => isempty(solve_elapsed) ? missing : sum(solve_elapsed) / n,
                "total_simplex_iterations" => isempty(simplex_iterations) ? missing : sum(simplex_iterations),
                "mean_simplex_iterations" => isempty(simplex_iterations) ? missing : sum(simplex_iterations) / n,
                "warm_start_applied_count" => count(row -> row["warm_start_applied"] == true, scenario_rows),
                "basis_warm_start_applied_count" =>
                    count(row -> row["basis_warm_start_applied"] == true, scenario_rows),
                "basis_warm_start_failed_count" =>
                    count(row -> row["basis_warm_start_failed"] == true, scenario_rows),
                "basis_capture_count" => count(row -> row["basis_capture_succeeded"] == true, scenario_rows),
                "final_objective_value" => final_row["objective_value"],
                "final_biomass_flux" => final_row["biomass_flux"],
                "max_abs_objective_difference_vs_cold" =>
                    maximum(abs.(Float64.([row["objective_difference_vs_cold"] for row in scenario_rows]))),
                "max_abs_flux_difference_vs_cold" =>
                    maximum(Float64.([row["max_abs_flux_difference_vs_cold"] for row in scenario_rows])),
                "max_abs_dy_difference_vs_cold" =>
                    maximum(Float64.([row["max_abs_dy_difference_vs_cold"] for row in scenario_rows])),
                "max_mass_balance_residual" =>
                    maximum(Float64.([row["mass_balance_residual"] for row in scenario_rows])),
                "max_lower_bound_violation" =>
                    maximum(Float64.([row["max_lower_bound_violation"] for row in scenario_rows])),
                "max_upper_bound_violation" =>
                    maximum(Float64.([row["max_upper_bound_violation"] for row in scenario_rows])),
                "notes" => _reduced_dfba_warm_start_summary_note(scenario_id),
            ),
        )
    end
    return DataFrame(
        (
            column => [_reduced_dfba_warm_start_table_scalar(get(row, column, missing)) for row in summary_rows] for
            column in REDUCED_DFBA_WARM_START_SUMMARY_COLUMNS
        )...,
    )
end

function _reduced_dfba_warm_start_numeric_values(rows::Vector{Dict{String, Any}}, column::AbstractString)
    values = Float64[]
    for row in rows
        value = get(row, String(column), missing)
        (value === missing || value === nothing) && continue
        push!(values, Float64(value))
    end
    return values
end

function _reduced_dfba_warm_start_summary_note(scenario_id::AbstractString)::String
    if scenario_id == "cold_rebuild"
        return "Current reference path: rebuild a JuMP/HiGHS LP for each RHS evaluation."
    elseif scenario_id == "persistent_no_start"
        return "experimental_non_equivalent_ode: reuse one JuMP/HiGHS LP and update bounds/objective without primal starts for RHS diagnostics only."
    elseif scenario_id == "persistent_primal_start"
        return "experimental_non_equivalent_ode: reuse one JuMP/HiGHS LP and set previous primal fluxes as variable starts for RHS diagnostics only."
    elseif scenario_id == "persistent_basis_primal_simplex"
        return "experimental_non_equivalent_ode: reuse one JuMP/HiGHS LP, apply the previous HiGHS basis, and force primal simplex for RHS diagnostics only."
    end
    return "Unknown reduced DFBA warm-start benchmark scenario."
end

function _reduced_dfba_warm_start_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end

function _reduced_dfba_warm_start_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _reduced_dfba_warm_start_toml_normalize_real(value)
    elseif value isa Tuple
        return _reduced_dfba_warm_start_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _reduced_dfba_warm_start_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _reduced_dfba_warm_start_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _reduced_dfba_warm_start_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _reduced_dfba_warm_start_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _reduced_dfba_warm_start_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end
