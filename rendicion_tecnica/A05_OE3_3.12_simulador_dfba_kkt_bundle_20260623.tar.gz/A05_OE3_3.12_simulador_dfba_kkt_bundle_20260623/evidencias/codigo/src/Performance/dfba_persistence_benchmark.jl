import HiGHS
import JuMP
import MathOptInterface as MOI
import OrdinaryDiffEq

const DFBA_PERSISTENCE_BENCHMARK_NAME = "dfba_full_reduced_persistence"
const DFBA_PERSISTENCE_BENCHMARK_SCENARIOS = [
    "full_dfba_cold",
    "full_dfba_persistent",
    "reduced_dfba_persistent",
]

const DFBA_PERSISTENCE_BENCHMARK_SUMMARY_COLUMNS = [
    "scenario_id",
    "comparison_role",
    "model_scope",
    "matrix_scope",
    "model_id",
    "lp_reuse",
    "lp_primal_start",
    "lp_basis_warm_start",
    "lp_simplex_strategy",
    "fba_variant",
    "quadratic_penalty",
    "l1_penalty",
    "qpfba_persistent_fallback_count",
    "allow_experimental_lp_reuse",
    "retcode",
    "n_saved_points",
    "rhs_call_count",
    "rhs_lp_solve_count",
    "flux_reconstruction_solve_count",
    "total_lp_solve_count",
    "simulation_elapsed_seconds",
    "ode_solve_elapsed_seconds",
    "rhs_elapsed_seconds",
    "history_reconstruction_elapsed_seconds",
    "benchmark_elapsed_seconds",
    "final_biomass",
    "final_total_sugar",
    "final_ethanol",
    "final_oxygen",
    "max_abs_state_difference_vs_full_cold",
    "state_rmse_vs_full_cold",
    "final_biomass_difference_vs_full_cold",
    "final_total_sugar_difference_vs_full_cold",
    "final_ethanol_difference_vs_full_cold",
    "runtime_speedup_vs_full_cold",
    "max_abs_state_tolerance",
    "state_rmse_tolerance",
    "final_state_tolerance",
    "acceptance_required",
    "acceptance_passed_vs_full_cold",
    "notes",
]

"""
    DFBAPersistenceBenchmarkResult

Plotting-free benchmark result comparing full cold DFBA, full persistent DFBA,
and reduced persistent DFBA ODE simulations.
"""
struct DFBAPersistenceBenchmarkResult
    summary_table::DataFrame
    aligned_timeseries_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    benchmark_dfba_persistence(full_model, full_reaction_map, reduced_model, reduced_reaction_map; kwargs...)

Run a short ODE benchmark with three scenarios:
`full_dfba_cold`, `full_dfba_persistent`, and `reduced_dfba_persistent`.
The persistent scenarios opt into the guarded experimental LP reuse path and
are diagnostic until trajectory equivalence is established for the chosen
horizon and tolerances.
"""
function benchmark_dfba_persistence(
    full_model::MetabolicModel,
    full_reaction_map::ReactionMap,
    reduced_model::MetabolicModel,
    reduced_reaction_map::ReactionMap;
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    tspan::Tuple{Float64, Float64} = (0.0, 0.25),
    saveat = 0.25,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    algorithm = OrdinaryDiffEq.Tsit5(),
    algorithm_label::AbstractString = string(typeof(algorithm)),
    adaptive::Bool = true,
    dt = nothing,
    fba_variant::AbstractString = "fba",
    quadratic_penalty::Real = 0.0,
    l1_penalty::Real = 0.0,
    reconstruct_fluxes::Bool = false,
    persistent_primal_start::Bool = true,
    persistent_basis_warm_start::Bool = false,
    lp_reuse_highs_solver::AbstractString = "simplex",
    lp_simplex_strategy::AbstractString = "default",
    trajectory_match_atol::Real = 1.0e-5,
    benchmark_profile::AbstractString = "short",
    full_persistent_max_abs_state_tolerance::Real = trajectory_match_atol,
    full_persistent_state_rmse_tolerance::Real = trajectory_match_atol,
    full_persistent_final_state_tolerance::Real = trajectory_match_atol,
    reduced_similarity_max_abs_state_tolerance::Real = 1.0e-2,
    reduced_similarity_state_rmse_tolerance::Real = 1.0e-3,
    reduced_similarity_final_state_tolerance::Real = 1.0e-2,
    progress_interval_seconds::Real = 0.0,
    max_rhs_calls = nothing,
    max_walltime_seconds = nothing,
)::DFBAPersistenceBenchmarkResult
    _validate_dfba_persistence_benchmark_inputs(
        full_model,
        full_reaction_map,
        reduced_model,
        reduced_reaction_map,
        y0,
        tspan,
        trajectory_match_atol,
    )
    tolerance = Float64(lp_atol)
    isfinite(tolerance) && tolerance > 0.0 ||
        error("DFBA persistence benchmark lp_atol must be finite and positive, got $lp_atol.")
    match_atol = Float64(trajectory_match_atol)
    normalized_fba_variant = _normalize_dfba_fba_variant(fba_variant)
    qp_penalty = normalized_fba_variant == "qpfba" ?
        _validate_qp_regularized_fba_penalty(quadratic_penalty) :
        0.0
    l1_regularization_penalty = normalized_fba_variant == "l1pfba" ?
        _validate_l1_regularized_fba_penalty(l1_penalty) :
        0.0
    normalized_fba_variant == "qpfba" && persistent_basis_warm_start && error(
        "DFBA persistence qpfba benchmark does not support HiGHS basis warm starts.",
    )
    effective_optimizer = normalized_fba_variant == "qpfba" ?
        _dfba_persistence_qpfba_optimizer(optimizer) :
        optimizer
    effective_lp_reuse_highs_solver = normalized_fba_variant == "qpfba" ? "default" : String(lp_reuse_highs_solver)
    acceptance_tolerances = _dfba_persistence_acceptance_tolerances(
        full_persistent_max_abs_state_tolerance,
        full_persistent_state_rmse_tolerance,
        full_persistent_final_state_tolerance,
        reduced_similarity_max_abs_state_tolerance,
        reduced_similarity_state_rmse_tolerance,
        reduced_similarity_final_state_tolerance,
    )
    effective_simplex_strategy = persistent_basis_warm_start && strip(String(lp_simplex_strategy)) == "default" ?
        "primal" :
        String(lp_simplex_strategy)

    full_cold_result, full_cold_elapsed = _run_dfba_persistence_scenario(
        "full_dfba_cold",
        full_model,
        full_reaction_map;
        y0 = y0,
        tspan = tspan,
        saveat = saveat,
        params = params,
        optimizer = effective_optimizer,
        silent = silent,
        lp_atol = tolerance,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        algorithm = algorithm,
        adaptive = adaptive,
        dt = dt,
        fba_variant = normalized_fba_variant,
        quadratic_penalty = qp_penalty,
        l1_penalty = l1_regularization_penalty,
        reconstruct_fluxes = reconstruct_fluxes,
        model_scope = "full",
        lp_reuse = false,
        lp_primal_start = false,
        lp_reuse_highs_solver = effective_lp_reuse_highs_solver,
        lp_basis_warm_start = false,
        lp_simplex_strategy = "default",
        allow_experimental_lp_reuse = false,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
    )
    full_persistent_result, full_persistent_elapsed = _run_dfba_persistence_scenario(
        "full_dfba_persistent",
        full_model,
        full_reaction_map;
        y0 = y0,
        tspan = tspan,
        saveat = saveat,
        params = params,
        optimizer = effective_optimizer,
        silent = silent,
        lp_atol = tolerance,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        algorithm = algorithm,
        adaptive = adaptive,
        dt = dt,
        fba_variant = normalized_fba_variant,
        quadratic_penalty = qp_penalty,
        l1_penalty = l1_regularization_penalty,
        reconstruct_fluxes = reconstruct_fluxes,
        model_scope = "full",
        lp_reuse = true,
        lp_primal_start = persistent_primal_start,
        lp_reuse_highs_solver = effective_lp_reuse_highs_solver,
        lp_basis_warm_start = persistent_basis_warm_start,
        lp_simplex_strategy = effective_simplex_strategy,
        allow_experimental_lp_reuse = true,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
    )
    reduced_persistent_result, reduced_persistent_elapsed = _run_dfba_persistence_scenario(
        "reduced_dfba_persistent",
        reduced_model,
        reduced_reaction_map;
        y0 = y0,
        tspan = tspan,
        saveat = saveat,
        params = params,
        optimizer = effective_optimizer,
        silent = silent,
        lp_atol = tolerance,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        algorithm = algorithm,
        adaptive = adaptive,
        dt = dt,
        fba_variant = normalized_fba_variant,
        quadratic_penalty = qp_penalty,
        l1_penalty = l1_regularization_penalty,
        reconstruct_fluxes = reconstruct_fluxes,
        model_scope = "reduced",
        lp_reuse = true,
        lp_primal_start = persistent_primal_start,
        lp_reuse_highs_solver = effective_lp_reuse_highs_solver,
        lp_basis_warm_start = persistent_basis_warm_start,
        lp_simplex_strategy = effective_simplex_strategy,
        allow_experimental_lp_reuse = true,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
    )

    scenario_results = Dict(
        "full_dfba_cold" => full_cold_result,
        "full_dfba_persistent" => full_persistent_result,
        "reduced_dfba_persistent" => reduced_persistent_result,
    )
    scenario_elapsed = Dict(
        "full_dfba_cold" => full_cold_elapsed,
        "full_dfba_persistent" => full_persistent_elapsed,
        "reduced_dfba_persistent" => reduced_persistent_elapsed,
    )
    _assert_dfba_persistence_shared_time_grid(scenario_results)

    summary_table = _dfba_persistence_summary_table(
        scenario_results,
        scenario_elapsed;
        acceptance_tolerances = acceptance_tolerances,
    )
    aligned_timeseries_table = _dfba_persistence_aligned_timeseries_table(scenario_results)
    metadata = Dict{String, Any}(
        "benchmark_name" => DFBA_PERSISTENCE_BENCHMARK_NAME,
        "scenario_ids" => copy(DFBA_PERSISTENCE_BENCHMARK_SCENARIOS),
        "baseline_scenario_id" => "full_dfba_cold",
        "benchmark_profile" => String(benchmark_profile),
        "benchmark_duration_hours" => Float64(tspan[2] - tspan[1]),
        "scientific_model_baseline" => "full_S_DFBA_in_Julia",
        "performance_reference_scenario" => "full_dfba_cold",
        "full_persistent_candidate_scenario" => "full_dfba_persistent",
        "reduced_persistent_candidate_scenario" => "reduced_dfba_persistent",
        "matlab_role_note" =>
            "MATLAB/DFVB artifacts are treated as input generators for reduction matrices and alphas, not as the Julia trajectory baseline.",
        "dfvb_reduction_role_note" =>
            "DFVB-derived N/alpha artifacts define the reduced metabolic representation that is compared against full-S DFBA.",
        "mpcc_scope_note" =>
            "This benchmark prepares sequential references for future direct-collocation KKT/MPCC work; it does not build an MPCC.",
        "default_simulation_path_changed" => false,
        "persistence_ode_opt_in" => "allow_experimental_lp_reuse=true",
        "persistent_primal_start" => persistent_primal_start,
        "persistent_basis_warm_start" => persistent_basis_warm_start,
        "lp_reuse_highs_solver" => effective_lp_reuse_highs_solver,
        "lp_simplex_strategy" => effective_simplex_strategy,
        "reconstruct_fluxes" => reconstruct_fluxes,
        "tspan" => tspan,
        "saveat" => saveat,
        "algorithm_label" => String(algorithm_label),
        "adaptive" => adaptive,
        "dt" => dt,
        "fba_variant" => normalized_fba_variant,
        "quadratic_penalty" => qp_penalty,
        "l1_penalty" => l1_regularization_penalty,
        "regularization_note" => _dfba_persistence_regularization_note(
            normalized_fba_variant,
            qp_penalty,
            l1_regularization_penalty,
        ),
        "qpfba_solver_note" => normalized_fba_variant == "qpfba" ?
            "The qpfba benchmark forces HiGHS solver=ipm, run_crossover=off, and ipm_optimality_tolerance=1.0e-6 for QP robustness and runtime." :
            "not_applicable",
        "lp_atol" => tolerance,
        "ode_abstol" => Float64(ode_abstol),
        "ode_reltol" => Float64(ode_reltol),
        "trajectory_similarity_checked" => true,
        "trajectory_match_atol" => match_atol,
        "full_persistent_max_abs_state_tolerance" =>
            acceptance_tolerances["full_dfba_persistent"].max_abs_state_tolerance,
        "full_persistent_state_rmse_tolerance" =>
            acceptance_tolerances["full_dfba_persistent"].state_rmse_tolerance,
        "full_persistent_final_state_tolerance" =>
            acceptance_tolerances["full_dfba_persistent"].final_state_tolerance,
        "reduced_similarity_max_abs_state_tolerance" =>
            acceptance_tolerances["reduced_dfba_persistent"].max_abs_state_tolerance,
        "reduced_similarity_state_rmse_tolerance" =>
            acceptance_tolerances["reduced_dfba_persistent"].state_rmse_tolerance,
        "reduced_similarity_final_state_tolerance" =>
            acceptance_tolerances["reduced_dfba_persistent"].final_state_tolerance,
        "acceptance_required_scenarios" => [
            scenario_id for scenario_id in DFBA_PERSISTENCE_BENCHMARK_SCENARIOS if
            acceptance_tolerances[scenario_id].acceptance_required
        ],
        "progress_interval_seconds" => Float64(progress_interval_seconds),
        "max_rhs_calls" => max_rhs_calls,
        "max_walltime_seconds" => max_walltime_seconds,
        "long_horizon_profile_note" =>
            "Use benchmark_profile=72h or DFBA_PERSISTENCE_BENCH_PROFILE=72h for the 72 h sequential reference benchmark; default tests use short horizons only.",
        "gurobi_required" => false,
        "ipopt_required" => false,
        "hsl_required" => false,
        "oxygen_reaction_id" => "r_1992",
        "r0001_used_as_oxygen" => false,
        "carbohydrate_policy_note" => "carbohydrate dy[8] remains empirical and is not driven by r_4048",
    )
    return DFBAPersistenceBenchmarkResult(summary_table, aligned_timeseries_table, metadata)
end

"""
    export_dfba_persistence_benchmark(result, output_dir; overwrite=false)

Write CSV/TOML artifacts for `benchmark_dfba_persistence`.
"""
function export_dfba_persistence_benchmark(
    result::DFBAPersistenceBenchmarkResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("DFBA persistence benchmark output_dir exists and is not a directory: $output_path")
    end
    paths = Dict{String, String}(
        "summary" => joinpath(output_path, "dfba_persistence_benchmark_summary.csv"),
        "aligned_timeseries" => joinpath(output_path, "dfba_persistence_benchmark_aligned_timeseries.csv"),
        "metadata" => joinpath(output_path, "dfba_persistence_benchmark_metadata.toml"),
    )
    existing_targets = [path for path in values(paths) if isfile(path)]
    if !overwrite && !isempty(existing_targets)
        error(
            "DFBA persistence benchmark target file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end

    mkpath(output_path)
    if overwrite
        for path in values(paths)
            isfile(path) && rm(path)
        end
    end

    CSV.write(paths["summary"], result.summary_table)
    CSV.write(paths["aligned_timeseries"], result.aligned_timeseries_table)
    open(paths["metadata"], "w") do io
        TOML.print(io, _dfba_persistence_toml_normalize(result.metadata))
    end
    return paths
end

function _dfba_persistence_qpfba_optimizer(optimizer)
    return JuMP.optimizer_with_attributes(
        optimizer,
        "solver" => "ipm",
        "run_crossover" => "off",
        "ipm_optimality_tolerance" => 1.0e-6,
    )
end

function _dfba_persistence_qpfba_optimizer(optimizer::MOI.OptimizerWithAttributes)
    return JuMP.optimizer_with_attributes(
        optimizer.optimizer_constructor,
        optimizer.params...,
        "solver" => "ipm",
        "run_crossover" => "off",
        "ipm_optimality_tolerance" => 1.0e-6,
    )
end

function _dfba_persistence_regularization_note(
    fba_variant::AbstractString,
    quadratic_penalty::Real,
    l1_penalty::Real,
)::String
    if fba_variant == "qpfba"
        return "QP-regularized DFBA solves min -c'v + quadratic_penalty * sum(v.^2) with quadratic_penalty=$(Float64(quadratic_penalty)); this is an experimental pFBA-like tie-breaker, not the LP FBA baseline."
    elseif fba_variant == "l1pfba"
        return "L1-regularized DFBA solves the LP min -c'v + l1_penalty * sum(abs(v)) with l1_penalty=$(Float64(l1_penalty)); this remains an experimental pFBA-like tie-breaker, not the LP FBA baseline."
    else
        return "LP FBA baseline without regularization."
    end
end

function _validate_dfba_persistence_benchmark_inputs(
    full_model::MetabolicModel,
    full_reaction_map::ReactionMap,
    reduced_model::MetabolicModel,
    reduced_reaction_map::ReactionMap,
    y0::AbstractVector,
    tspan::Tuple{Float64, Float64},
    trajectory_match_atol::Real,
)
    validate_full_model_dimensions(full_model; throw_on_error = true)
    validate_reduced_model_dimensions(reduced_model; throw_on_error = true)
    validate_reaction_map(full_model, full_reaction_map).ok ||
        error("DFBA persistence benchmark requires a valid full reaction map.")
    validate_reaction_map(reduced_model, reduced_reaction_map).ok ||
        error("DFBA persistence benchmark requires a valid reduced reaction map.")
    length(y0) == 19 || error("DFBA persistence benchmark y0 must have length 19, got $(length(y0)).")
    tspan[2] > tspan[1] || error("DFBA persistence benchmark tspan must satisfy tspan[2] > tspan[1].")
    match_atol = Float64(trajectory_match_atol)
    isfinite(match_atol) && match_atol >= 0.0 ||
        error("DFBA persistence benchmark trajectory_match_atol must be finite and nonnegative.")
    _assert_dfba_oxygen_not_r0001(full_reaction_map)
    _assert_dfba_oxygen_not_r0001(reduced_reaction_map)
    return nothing
end

function _run_dfba_persistence_scenario(
    scenario_id::AbstractString,
    model::MetabolicModel,
    reaction_map::ReactionMap;
    y0::AbstractVector,
    tspan::Tuple{Float64, Float64},
    saveat,
    params::ZentenoKineticParameters,
    optimizer,
    silent::Bool,
    lp_atol::Real,
    ode_abstol::Real,
    ode_reltol::Real,
    algorithm,
    adaptive::Bool,
    dt,
    fba_variant::AbstractString,
    quadratic_penalty::Real,
    l1_penalty::Real,
    reconstruct_fluxes::Bool,
    model_scope::AbstractString,
    lp_reuse::Bool,
    lp_primal_start::Bool,
    lp_reuse_highs_solver::AbstractString,
    lp_basis_warm_start::Bool,
    lp_simplex_strategy::AbstractString,
    allow_experimental_lp_reuse::Bool,
    progress_interval_seconds::Real,
    max_rhs_calls,
    max_walltime_seconds,
)
    result = nothing
    elapsed = @elapsed begin
        if model_scope == "full"
            result = simulate_full_dfba(
                model,
                reaction_map;
                y0 = y0,
                tspan = tspan,
                params = params,
                optimizer = optimizer,
                silent = silent,
                lp_atol = lp_atol,
                ode_abstol = ode_abstol,
                ode_reltol = ode_reltol,
                saveat = saveat,
                algorithm = algorithm,
                adaptive = adaptive,
                dt = dt,
                fba_variant = fba_variant,
                quadratic_penalty = quadratic_penalty,
                l1_penalty = l1_penalty,
                reconstruct_fluxes = reconstruct_fluxes,
                lp_reuse = lp_reuse,
                lp_primal_start = lp_primal_start,
                lp_reuse_highs_solver = lp_reuse_highs_solver,
                lp_basis_warm_start = lp_basis_warm_start,
                lp_simplex_strategy = lp_simplex_strategy,
                allow_experimental_lp_reuse = allow_experimental_lp_reuse,
                progress_interval_seconds = progress_interval_seconds,
                max_rhs_calls = max_rhs_calls,
                max_walltime_seconds = max_walltime_seconds,
            )
        else
            result = simulate_reduced_dfba(
                model,
                reaction_map;
                y0 = y0,
                tspan = tspan,
                params = params,
                optimizer = optimizer,
                silent = silent,
                lp_atol = lp_atol,
                ode_abstol = ode_abstol,
                ode_reltol = ode_reltol,
                saveat = saveat,
                algorithm = algorithm,
                adaptive = adaptive,
                dt = dt,
                fba_variant = fba_variant,
                quadratic_penalty = quadratic_penalty,
                l1_penalty = l1_penalty,
                reconstruct_fluxes = reconstruct_fluxes,
                lp_reuse = lp_reuse,
                lp_primal_start = lp_primal_start,
                lp_reuse_highs_solver = lp_reuse_highs_solver,
                lp_basis_warm_start = lp_basis_warm_start,
                lp_simplex_strategy = lp_simplex_strategy,
                allow_experimental_lp_reuse = allow_experimental_lp_reuse,
                model_scope = "reduced",
                progress_interval_seconds = progress_interval_seconds,
                max_rhs_calls = max_rhs_calls,
                max_walltime_seconds = max_walltime_seconds,
            )
        end
    end
    result.metadata["benchmark_scenario_id"] = String(scenario_id)
    result.metadata["benchmark_elapsed_seconds"] = elapsed
    result.metadata["model_id"] = model.model_id
    return result, elapsed
end

function _assert_dfba_persistence_shared_time_grid(scenario_results::Dict{String, SimulationResult})
    baseline = scenario_results["full_dfba_cold"]
    for scenario_id in DFBA_PERSISTENCE_BENCHMARK_SCENARIOS
        result = scenario_results[scenario_id]
        length(result.time) == length(baseline.time) || error(
            "DFBA persistence benchmark scenario $scenario_id saved $(length(result.time)) points; baseline saved $(length(baseline.time)).",
        )
        all(isapprox(result.time[i], baseline.time[i]; rtol = 0.0, atol = 1.0e-10) for i in eachindex(baseline.time)) ||
            error("DFBA persistence benchmark scenario $scenario_id does not share the baseline saved-time grid.")
    end
    return nothing
end

function _dfba_persistence_summary_table(
    scenario_results::Dict{String, SimulationResult},
    scenario_elapsed::Dict{String, Float64};
    acceptance_tolerances,
)::DataFrame
    baseline = scenario_results["full_dfba_cold"]
    baseline_elapsed = max(scenario_elapsed["full_dfba_cold"], eps(Float64))
    rows = Dict{String, Any}[]
    for scenario_id in DFBA_PERSISTENCE_BENCHMARK_SCENARIOS
        result = scenario_results[scenario_id]
        summary = summarize_simulation(result)
        differences = _dfba_persistence_state_differences(result, baseline)
        tolerances = acceptance_tolerances[scenario_id]
        push!(
            rows,
            Dict{String, Any}(
                "scenario_id" => scenario_id,
                "comparison_role" => _dfba_persistence_comparison_role(scenario_id),
                "model_scope" => summary["model_scope"],
                "matrix_scope" => scenario_id == "reduced_dfba_persistent" ? "reduced_S" : "full_S",
                "model_id" => get(result.metadata, "model_id", get(result.metadata, "model_scope", "unknown")),
                "lp_reuse" => summary["lp_reuse"],
                "lp_primal_start" => summary["lp_primal_start"],
                "lp_basis_warm_start" => summary["lp_basis_warm_start"],
                "lp_simplex_strategy" => summary["lp_simplex_strategy"],
                "fba_variant" => get(result.metadata, "fba_variant", "fba"),
                "quadratic_penalty" => get(result.metadata, "quadratic_penalty", 0.0),
                "l1_penalty" => get(result.metadata, "l1_penalty", 0.0),
                "qpfba_persistent_fallback_count" =>
                    get(result.metadata, "qpfba_persistent_fallback_count", 0),
                "allow_experimental_lp_reuse" => summary["allow_experimental_lp_reuse"],
                "retcode" => summary["retcode"],
                "n_saved_points" => summary["n_saved_points"],
                "rhs_call_count" => summary["rhs_call_count"],
                "rhs_lp_solve_count" => summary["rhs_lp_solve_count"],
                "flux_reconstruction_solve_count" => summary["flux_reconstruction_solve_count"],
                "total_lp_solve_count" => summary["total_lp_solve_count"],
                "simulation_elapsed_seconds" => summary["simulation_elapsed_seconds"],
                "ode_solve_elapsed_seconds" => summary["ode_solve_elapsed_seconds"],
                "rhs_elapsed_seconds" => summary["rhs_elapsed_seconds"],
                "history_reconstruction_elapsed_seconds" => summary["history_reconstruction_elapsed_seconds"],
                "benchmark_elapsed_seconds" => scenario_elapsed[scenario_id],
                "final_biomass" => summary["final_biomass"],
                "final_total_sugar" => summary["final_total_sugar"],
                "final_ethanol" => summary["final_ethanol"],
                "final_oxygen" => summary["final_oxygen"],
                "max_abs_state_difference_vs_full_cold" => differences.max_abs_state_difference,
                "state_rmse_vs_full_cold" => differences.state_rmse,
                "final_biomass_difference_vs_full_cold" => differences.final_biomass_difference,
                "final_total_sugar_difference_vs_full_cold" => differences.final_total_sugar_difference,
                "final_ethanol_difference_vs_full_cold" => differences.final_ethanol_difference,
                "runtime_speedup_vs_full_cold" => baseline_elapsed / max(scenario_elapsed[scenario_id], eps(Float64)),
                "max_abs_state_tolerance" => tolerances.max_abs_state_tolerance,
                "state_rmse_tolerance" => tolerances.state_rmse_tolerance,
                "final_state_tolerance" => tolerances.final_state_tolerance,
                "acceptance_required" => tolerances.acceptance_required,
                "acceptance_passed_vs_full_cold" =>
                    _dfba_persistence_acceptance_passed(differences, tolerances),
                "notes" => _dfba_persistence_summary_note(scenario_id),
            ),
        )
    end
    return DataFrame(
        (
            column => [_dfba_persistence_table_scalar(get(row, column, missing)) for row in rows] for
            column in DFBA_PERSISTENCE_BENCHMARK_SUMMARY_COLUMNS
        )...,
    )
end

function _dfba_persistence_state_differences(result::SimulationResult, baseline::SimulationResult)
    diff = result.states .- baseline.states
    final_diff = view(diff, :, size(diff, 2))
    return (
        max_abs_state_difference = maximum(abs.(diff)),
        state_rmse = sqrt(sum(abs2, diff) / length(diff)),
        final_biomass_difference = final_diff[1],
        final_total_sugar_difference = final_diff[3] + final_diff[4],
        final_ethanol_difference = final_diff[5],
    )
end

function _dfba_persistence_acceptance_tolerances(
    full_persistent_max_abs_state_tolerance::Real,
    full_persistent_state_rmse_tolerance::Real,
    full_persistent_final_state_tolerance::Real,
    reduced_similarity_max_abs_state_tolerance::Real,
    reduced_similarity_state_rmse_tolerance::Real,
    reduced_similarity_final_state_tolerance::Real,
)
    return Dict(
        "full_dfba_cold" => _dfba_persistence_acceptance_tuple(0.0, 0.0, 0.0, true),
        "full_dfba_persistent" => _dfba_persistence_acceptance_tuple(
            full_persistent_max_abs_state_tolerance,
            full_persistent_state_rmse_tolerance,
            full_persistent_final_state_tolerance,
            true,
        ),
        "reduced_dfba_persistent" => _dfba_persistence_acceptance_tuple(
            reduced_similarity_max_abs_state_tolerance,
            reduced_similarity_state_rmse_tolerance,
            reduced_similarity_final_state_tolerance,
            false,
        ),
    )
end

function _dfba_persistence_acceptance_tuple(
    max_abs_state_tolerance::Real,
    state_rmse_tolerance::Real,
    final_state_tolerance::Real,
    acceptance_required::Bool,
)
    max_abs = Float64(max_abs_state_tolerance)
    rmse = Float64(state_rmse_tolerance)
    final_state = Float64(final_state_tolerance)
    if !(isfinite(max_abs) && max_abs >= 0.0)
        error("DFBA persistence max_abs_state_tolerance must be finite and nonnegative.")
    end
    if !(isfinite(rmse) && rmse >= 0.0)
        error("DFBA persistence state_rmse_tolerance must be finite and nonnegative.")
    end
    if !(isfinite(final_state) && final_state >= 0.0)
        error("DFBA persistence final_state_tolerance must be finite and nonnegative.")
    end
    return (
        max_abs_state_tolerance = max_abs,
        state_rmse_tolerance = rmse,
        final_state_tolerance = final_state,
        acceptance_required = acceptance_required,
    )
end

function _dfba_persistence_acceptance_passed(differences, tolerances)::Bool
    final_state_difference = maximum(
        abs.(
            (
                differences.final_biomass_difference,
                differences.final_total_sugar_difference,
                differences.final_ethanol_difference,
            ),
        ),
    )
    return differences.max_abs_state_difference <= tolerances.max_abs_state_tolerance &&
           differences.state_rmse <= tolerances.state_rmse_tolerance &&
           final_state_difference <= tolerances.final_state_tolerance
end

function _dfba_persistence_aligned_timeseries_table(
    scenario_results::Dict{String, SimulationResult},
)::DataFrame
    baseline = scenario_results["full_dfba_cold"]
    columns = Pair{String, Any}["time" => copy(baseline.time)]
    for state_index in eachindex(REDUCED_DFBA_STATE_NAMES)
        state_name = REDUCED_DFBA_STATE_NAMES[state_index]
        for scenario_id in DFBA_PERSISTENCE_BENCHMARK_SCENARIOS
            result = scenario_results[scenario_id]
            push!(columns, "$(state_name)_$(scenario_id)" => collect(view(result.states, state_index, :)))
        end
    end
    return DataFrame(columns...)
end

function _dfba_persistence_comparison_role(scenario_id::AbstractString)::String
    if scenario_id == "full_dfba_cold"
        return "baseline_reference"
    elseif scenario_id == "full_dfba_persistent"
        return "full_persistent_equivalence_candidate"
    elseif scenario_id == "reduced_dfba_persistent"
        return "reduced_model_similarity_candidate"
    end
    return "unknown"
end

function _dfba_persistence_summary_note(scenario_id::AbstractString)::String
    if scenario_id == "full_dfba_cold"
        return "Performance reference: full S DFBA with one rebuilt JuMP/HiGHS LP per RHS evaluation."
    elseif scenario_id == "full_dfba_persistent"
        return "Experimental candidate baseline: full S DFBA with persistent JuMP/HiGHS LP reuse and explicit ODE opt-in."
    elseif scenario_id == "reduced_dfba_persistent"
        return "Experimental reduced-model candidate: reduced S DFBA with persistent JuMP/HiGHS LP reuse and explicit ODE opt-in."
    end
    return "Unknown DFBA persistence benchmark scenario."
end

function _dfba_persistence_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end

function _dfba_persistence_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _dfba_persistence_toml_normalize_real(value)
    elseif value isa Tuple
        return _dfba_persistence_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _dfba_persistence_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _dfba_persistence_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _dfba_persistence_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _dfba_persistence_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _dfba_persistence_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end
