const REDUCED_DCDFBA_MPCC_SIMULATION_VIABILITY_TYPE =
    "reduced_dcdfba_mpcc_simulation_viability_gate"

const REDUCED_DCDFBA_MPCC_SIMULATION_VIABILITY_COLUMNS = [
    "candidate_id",
    "source_type",
    "source_row_status",
    "traffic_light",
    "viability_class",
    "simulation_viable",
    "trajectory_ready",
    "residual_feasible",
    "iteration_limit_residual_feasible",
    "residual_thresholds_satisfied",
    "residuals_pass",
    "state_drift_pass",
    "global_state_drift_pass",
    "guardrails_pass",
    "window_continuation_pass",
    "failed_source_row",
    "blocking_reasons",
    "review_reasons",
    "horizon",
    "nfe",
    "degree",
    "ipopt_max_iter",
    "window_index",
    "window_hours",
    "boundary_dt",
    "linear_solver",
    "ipopt_profile",
    "complementarity_mode",
    "complementarity_tau",
    "tau_schedule",
    "tau_continuation_stage_count",
    "tau_continuation_completed",
    "tau_continuation_final_residual_feasible",
    "tau_continuation_final_tau_gate_pass",
    "tau_continuation_blocking_stage",
    "tau_continuation_blocking_reason",
    "tau_continuation_stage_advance_count",
    "solver_status",
    "primal_status",
    "solve_elapsed_seconds",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_lower_complementarity_product",
    "max_upper_complementarity_product",
    "max_complementarity_tau_violation",
    "max_complementarity_tau_violation_raw",
    "complementarity_tau_gate_tolerance",
    "complementarity_tau_gate_tolerance_source",
    "complementarity_tau_gate_pass",
    "max_state_abs_difference",
    "max_state_relative_rmse",
    "global_max_state_abs_difference",
    "global_max_state_relative_rmse",
    "final_biomass_difference",
    "final_total_sugar_difference",
    "next_recommended_action",
    "full_dfba_cold_reference_deferred",
    "reduced_full_equivalence_claimed",
    "persistent_lp_baseline_used",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCSimulationViabilityThresholds

Numerical gates for classifying reduced MPCC diagnostics as simulation-viable
candidates. Residual defaults mirror the existing reduced MPCC diagnostic
thresholds. State-drift thresholds are diagnostic gates against reduced
sequential DFBA, not scientific acceptance criteria.
"""
struct ReducedDCDFBAMPCCSimulationViabilityThresholds
    max_rhs_residual::Float64
    max_mass_balance_residual::Float64
    max_lower_bound_violation::Float64
    max_upper_bound_violation::Float64
    max_stationarity_residual::Float64
    max_lower_complementarity_residual::Float64
    max_upper_complementarity_residual::Float64
    max_state_abs_difference::Float64
    max_state_relative_rmse::Float64
    max_global_state_abs_difference::Float64
    max_global_state_relative_rmse::Float64
end

"""
    ReducedDCDFBAMPCCSimulationViabilityReport

Traffic-light report for reduced MPCC diagnostics. Green rows are viable
diagnostic candidates for the next simulation step; yellow rows are
residual-feasible or promising but blocked by convergence/status review; red
rows fail a required gate. The report is diagnostic-only and does not claim a
scientifically validated simultaneous DFBA simulation.
"""
struct ReducedDCDFBAMPCCSimulationViabilityReport
    source_type::String
    viability_table::DataFrame
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds
    metadata::Dict{String, Any}
end

"""
    default_reduced_dcdfba_mpcc_simulation_viability_thresholds(; kwargs...)

Build default diagnostic thresholds for the reduced MPCC simulation-viability
gate. Residual thresholds come from `default_reduced_dcdfba_mpcc_residual_thresholds()`.
"""
function default_reduced_dcdfba_mpcc_simulation_viability_thresholds(;
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    max_state_abs_difference::Real = 1.0e-4,
    max_state_relative_rmse::Real = 2.0e-2,
    max_global_state_abs_difference::Real = 1.0e-4,
    max_global_state_relative_rmse::Real = 2.0e-2,
)::ReducedDCDFBAMPCCSimulationViabilityThresholds
    thresholds = ReducedDCDFBAMPCCSimulationViabilityThresholds(
        residual_thresholds.max_rhs_residual,
        residual_thresholds.max_mass_balance_residual,
        residual_thresholds.max_lower_bound_violation,
        residual_thresholds.max_upper_bound_violation,
        residual_thresholds.max_stationarity_residual,
        residual_thresholds.max_lower_complementarity_residual,
        residual_thresholds.max_upper_complementarity_residual,
        Float64(max_state_abs_difference),
        Float64(max_state_relative_rmse),
        Float64(max_global_state_abs_difference),
        Float64(max_global_state_relative_rmse),
    )
    _validate_reduced_mpcc_viability_thresholds(thresholds)
    return thresholds
end

"""
    assess_reduced_dcdfba_mpcc_simulation_viability(result; thresholds=...)

Assess reduced MPCC diagnostic outputs with a common traffic-light gate.
Supported sources are solve-attempt sweeps, Ipopt iteration sensitivity,
mesh-refinement sensitivity, and windowed-continuation diagnostics.
"""
function assess_reduced_dcdfba_mpcc_simulation_viability(
    result::ReducedDCDFBAMPCCSolveAttemptSweepResult;
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(),
)::ReducedDCDFBAMPCCSimulationViabilityReport
    return _reduced_mpcc_viability_report(
        _reduced_mpcc_viability_source_rows(
            result.scenario_table,
            "solve_attempt_sweep",
            "scenario_id",
            "scenario_status",
        ),
        "solve_attempt_sweep",
        thresholds,
    )
end

function assess_reduced_dcdfba_mpcc_simulation_viability(
    result::ReducedDCDFBAMPCCIpoptIterationSensitivityResult;
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(),
)::ReducedDCDFBAMPCCSimulationViabilityReport
    return _reduced_mpcc_viability_report(
        _reduced_mpcc_viability_source_rows(
            result.sensitivity_table,
            "ipopt_iteration_sensitivity",
            "iteration_case_id",
            "scenario_status",
        ),
        "ipopt_iteration_sensitivity",
        thresholds,
    )
end

function assess_reduced_dcdfba_mpcc_simulation_viability(
    result::ReducedDCDFBAMPCCMeshRefinementSensitivityResult;
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(),
)::ReducedDCDFBAMPCCSimulationViabilityReport
    return _reduced_mpcc_viability_report(
        _reduced_mpcc_viability_source_rows(
            result.mesh_table,
            "mesh_refinement_sensitivity",
            "mesh_case_id",
            "scenario_status",
        ),
        "mesh_refinement_sensitivity",
        thresholds,
    )
end

function assess_reduced_dcdfba_mpcc_simulation_viability(
    result::ReducedDCDFBAMPCCWindowedContinuationResult;
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(),
)::ReducedDCDFBAMPCCSimulationViabilityReport
    rows = Dict{String, Any}[]
    push!(rows, _reduced_mpcc_viability_window_global_row(result))
    append!(
        rows,
        _reduced_mpcc_viability_source_rows(
            result.window_table,
            "windowed_continuation_window",
            "window_id",
            "window_status",
        ),
    )
    return _reduced_mpcc_viability_report(rows, "windowed_continuation", thresholds)
end

function _validate_reduced_mpcc_viability_thresholds(
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)
    values = (
        thresholds.max_rhs_residual,
        thresholds.max_mass_balance_residual,
        thresholds.max_lower_bound_violation,
        thresholds.max_upper_bound_violation,
        thresholds.max_stationarity_residual,
        thresholds.max_lower_complementarity_residual,
        thresholds.max_upper_complementarity_residual,
        thresholds.max_state_abs_difference,
        thresholds.max_state_relative_rmse,
        thresholds.max_global_state_abs_difference,
        thresholds.max_global_state_relative_rmse,
    )
    all(value -> isfinite(value) && value >= 0.0, values) || throw(
        ArgumentError("Reduced MPCC simulation-viability thresholds must be finite and nonnegative."),
    )
    return thresholds
end

function _reduced_mpcc_viability_source_rows(
    table::DataFrame,
    source_type::AbstractString,
    id_column::AbstractString,
    status_column::AbstractString,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    for row in eachrow(table)
        dict = Dict{String, Any}(name => row[name] for name in names(table))
        dict["candidate_id"] = get(dict, String(id_column), "row_$(length(rows) + 1)")
        dict["source_type"] = String(source_type)
        dict["source_row_status"] = get(dict, String(status_column), missing)
        push!(rows, dict)
    end
    return rows
end

function _reduced_mpcc_viability_window_global_row(
    result::ReducedDCDFBAMPCCWindowedContinuationResult,
)::Dict{String, Any}
    metadata = result.metadata
    table = result.window_table
    return Dict{String, Any}(
        "candidate_id" => "windowed_global",
        "source_type" => "windowed_continuation_global",
        "source_row_status" =>
            get(metadata, "continuation_completed", false) === true ? "completed" : "incomplete",
        "candidate_residual_feasible" =>
            get(metadata, "all_completed_windows_residual_feasible", false),
        "candidate_iteration_limit_residual_feasible" =>
            get(metadata, "iteration_limit_residual_feasible_window_count", 0) > 0,
        "candidate_trajectory_ready" =>
            get(metadata, "all_completed_windows_trajectory_ready", false),
        "candidate_allows_continuation" =>
            get(metadata, "continuation_completed", false),
        "candidate_is_scientific_simulation" => false,
        "residual_thresholds_satisfied" =>
            _reduced_mpcc_viability_all_true(table, "residual_thresholds_satisfied"),
        "horizon" => get(metadata, "total_horizon_reached", missing),
        "window_hours" => get(metadata, "window_hours", missing),
        "nfe" => get(metadata, "nfe_per_window", missing),
        "degree" => get(metadata, "degree", missing),
        "boundary_dt" => get(metadata, "boundary_dt", missing),
        "linear_solver" => get(metadata, "linear_solver", missing),
        "ipopt_profile" => get(metadata, "ipopt_profile", missing),
        "complementarity_mode" => get(metadata, "complementarity_mode", missing),
        "complementarity_tau" => get(metadata, "complementarity_tau", missing),
        "tau_schedule" => get(metadata, "tau_schedule", missing),
        "tau_continuation_stage_count" =>
            _reduced_mpcc_viability_max(table, "tau_continuation_stage_count"),
        "tau_continuation_completed" =>
            _reduced_mpcc_viability_all_true(table, "tau_continuation_completed"),
        "tau_continuation_final_residual_feasible" =>
            _reduced_mpcc_viability_all_true(table, "tau_continuation_final_residual_feasible"),
        "tau_continuation_final_tau_gate_pass" =>
            _reduced_mpcc_viability_all_true(table, "tau_continuation_final_tau_gate_pass"),
        "tau_continuation_blocking_stage" =>
            _reduced_mpcc_viability_first_nonmissing(table, "tau_continuation_blocking_stage"),
        "tau_continuation_blocking_reason" =>
            _reduced_mpcc_viability_first_nonmissing(table, "tau_continuation_blocking_reason"),
        "tau_continuation_stage_advance_count" =>
            _reduced_mpcc_viability_sum(table, "tau_continuation_stage_advance_count"),
        "solver_status" => _reduced_mpcc_viability_status_label(
            get(metadata, "solver_status_counts", Dict{String, Int}()),
        ),
        "primal_status" => missing,
        "solve_elapsed_seconds" => _reduced_mpcc_viability_sum(table, "solve_elapsed_seconds"),
        "max_rhs_residual" => _reduced_mpcc_viability_max(table, "max_rhs_residual"),
        "max_mass_balance_residual" =>
            _reduced_mpcc_viability_max(table, "max_mass_balance_residual"),
        "max_lower_bound_violation" =>
            _reduced_mpcc_viability_max(table, "max_lower_bound_violation"),
        "max_upper_bound_violation" =>
            _reduced_mpcc_viability_max(table, "max_upper_bound_violation"),
        "max_stationarity_residual" =>
            _reduced_mpcc_viability_max(table, "max_stationarity_residual"),
        "max_lower_complementarity_residual" =>
            _reduced_mpcc_viability_max(table, "max_lower_complementarity_residual"),
        "max_upper_complementarity_residual" =>
            _reduced_mpcc_viability_max(table, "max_upper_complementarity_residual"),
        "max_lower_complementarity_product" =>
            _reduced_mpcc_viability_max(table, "max_lower_complementarity_product"),
        "max_upper_complementarity_product" =>
            _reduced_mpcc_viability_max(table, "max_upper_complementarity_product"),
        "max_complementarity_tau_violation" =>
            _reduced_mpcc_viability_max(table, "max_complementarity_tau_violation"),
        "max_complementarity_tau_violation_raw" =>
            _reduced_mpcc_viability_max(table, "max_complementarity_tau_violation_raw"),
        "complementarity_tau_gate_tolerance" =>
            _reduced_mpcc_viability_max(table, "complementarity_tau_gate_tolerance"),
        "complementarity_tau_gate_tolerance_source" =>
            _reduced_mpcc_viability_first_nonmissing(
                table,
                "complementarity_tau_gate_tolerance_source",
            ),
        "complementarity_tau_gate_pass" =>
            _reduced_mpcc_viability_all_true(table, "complementarity_tau_gate_pass"),
        "max_state_abs_difference" =>
            get(metadata, "global_max_state_abs_difference", missing),
        "max_state_relative_rmse" =>
            get(metadata, "global_max_state_relative_rmse", missing),
        "continuation_state_drift_gate_pass" =>
            get(metadata, "global_state_drift_scale_gate_pass", missing),
        "continuation_global_state_drift_gate_pass" =>
            get(metadata, "global_state_drift_scale_gate_pass", missing),
        "global_max_state_abs_difference" =>
            get(metadata, "global_max_state_abs_difference", missing),
        "global_max_state_relative_rmse" =>
            get(metadata, "global_max_state_relative_rmse", missing),
        "final_biomass_difference" =>
            get(metadata, "global_final_biomass_difference", missing),
        "final_total_sugar_difference" =>
            get(metadata, "global_final_total_sugar_difference", missing),
        "next_recommended_action" => missing,
        "full_dfba_cold_reference_deferred" =>
            get(metadata, "full_dfba_cold_reference_deferred", true),
        "reduced_full_equivalence_claimed" =>
            get(metadata, "reduced_full_equivalence_claimed", false),
        "persistent_lp_baseline_used" =>
            get(metadata, "persistent_lp_baseline_used", false),
        "hsl_required" => get(metadata, "hsl_required", false),
        "ma57_required" => get(metadata, "ma57_required", false),
        "indices_reacciones_used" => get(metadata, "indices_reacciones_used", false),
        "r0001_used_as_oxygen" => get(metadata, "r0001_used_as_oxygen", false),
        "error_type" => missing,
        "error_message" => missing,
    )
end

function _reduced_mpcc_viability_report(
    source_rows::Vector{Dict{String, Any}},
    source_type::AbstractString,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::ReducedDCDFBAMPCCSimulationViabilityReport
    isempty(source_rows) && throw(
        ArgumentError("Reduced MPCC simulation-viability assessment requires at least one diagnostic row."),
    )
    _validate_reduced_mpcc_viability_thresholds(thresholds)
    rows = [
        _reduced_mpcc_viability_assessed_row(row, thresholds) for row in source_rows
    ]
    table = _reduced_mpcc_viability_table(rows)
    metadata = _reduced_mpcc_viability_metadata(table, String(source_type), thresholds)
    return ReducedDCDFBAMPCCSimulationViabilityReport(
        String(source_type),
        table,
        thresholds,
        metadata,
    )
end

function _reduced_mpcc_viability_assessed_row(
    source::Dict{String, Any},
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Dict{String, Any}
    residuals_pass = _reduced_mpcc_viability_residuals_pass(source, thresholds)
    state_drift_pass = _reduced_mpcc_viability_state_drift_pass(source, thresholds)
    global_state_drift_pass =
        _reduced_mpcc_viability_global_state_drift_pass(source, thresholds)
    guardrails_pass = _reduced_mpcc_viability_guardrails_pass(source)
    window_continuation_pass =
        get(source, "source_type", "") == "windowed_continuation_global" ?
        get(source, "candidate_allows_continuation", false) === true :
        true
    failed_source_row =
        get(source, "source_row_status", missing) in ("failed", "incomplete")
    trajectory_ready = get(source, "candidate_trajectory_ready", false) === true
    residual_feasible = get(source, "candidate_residual_feasible", false) === true
    iteration_limit_residual_feasible =
        get(source, "candidate_iteration_limit_residual_feasible", false) === true

    blocking_reasons = String[]
    failed_source_row && push!(blocking_reasons, "source_row_not_completed")
    guardrails_pass || push!(blocking_reasons, "scientific_guardrail_violation")
    residual_feasible || push!(blocking_reasons, "candidate_not_residual_feasible")
    residuals_pass || push!(blocking_reasons, "residual_thresholds_failed")
    trajectory_ready || push!(blocking_reasons, "candidate_not_trajectory_ready")
    state_drift_pass || push!(blocking_reasons, "state_drift_too_large")
    global_state_drift_pass || push!(blocking_reasons, "global_state_drift_too_large")
    window_continuation_pass || push!(blocking_reasons, "window_continuation_incomplete")

    review_reasons = _reduced_mpcc_viability_review_reasons(
        source,
        residual_feasible,
        trajectory_ready,
        iteration_limit_residual_feasible,
    )
    simulation_viable =
        isempty(blocking_reasons) && residual_feasible && trajectory_ready &&
        residuals_pass && state_drift_pass && global_state_drift_pass &&
        guardrails_pass && window_continuation_pass
    viability_class, traffic_light = _reduced_mpcc_viability_class(
        source,
        simulation_viable,
        blocking_reasons,
        review_reasons,
        residual_feasible,
        iteration_limit_residual_feasible,
    )

    return Dict{String, Any}(
        "candidate_id" => get(source, "candidate_id", missing),
        "source_type" => get(source, "source_type", missing),
        "source_row_status" => get(source, "source_row_status", missing),
        "traffic_light" => traffic_light,
        "viability_class" => viability_class,
        "simulation_viable" => simulation_viable,
        "trajectory_ready" => trajectory_ready,
        "residual_feasible" => residual_feasible,
        "iteration_limit_residual_feasible" => iteration_limit_residual_feasible,
        "residual_thresholds_satisfied" =>
            get(source, "residual_thresholds_satisfied", missing),
        "residuals_pass" => residuals_pass,
        "state_drift_pass" => state_drift_pass,
        "global_state_drift_pass" => global_state_drift_pass,
        "guardrails_pass" => guardrails_pass,
        "window_continuation_pass" => window_continuation_pass,
        "failed_source_row" => failed_source_row,
        "blocking_reasons" => join(blocking_reasons, ";"),
        "review_reasons" => join(review_reasons, ";"),
        "horizon" => get(source, "horizon", missing),
        "nfe" => get(source, "nfe", missing),
        "degree" => get(source, "degree", missing),
        "ipopt_max_iter" => get(source, "ipopt_max_iter", missing),
        "window_index" => get(source, "window_index", missing),
        "window_hours" => get(source, "window_hours", missing),
        "boundary_dt" => get(source, "boundary_dt", missing),
        "linear_solver" => get(source, "linear_solver", missing),
        "ipopt_profile" => get(source, "ipopt_profile", missing),
        "complementarity_mode" => get(source, "complementarity_mode", missing),
        "complementarity_tau" => get(source, "complementarity_tau", missing),
        "tau_schedule" => get(source, "tau_schedule", missing),
        "tau_continuation_stage_count" =>
            get(source, "tau_continuation_stage_count", missing),
        "tau_continuation_completed" =>
            get(source, "tau_continuation_completed", missing),
        "tau_continuation_final_residual_feasible" =>
            get(source, "tau_continuation_final_residual_feasible", missing),
        "tau_continuation_final_tau_gate_pass" =>
            get(source, "tau_continuation_final_tau_gate_pass", missing),
        "tau_continuation_blocking_stage" =>
            get(source, "tau_continuation_blocking_stage", missing),
        "tau_continuation_blocking_reason" =>
            get(source, "tau_continuation_blocking_reason", missing),
        "tau_continuation_stage_advance_count" =>
            get(source, "tau_continuation_stage_advance_count", missing),
        "solver_status" => get(source, "solver_status", missing),
        "primal_status" => get(source, "primal_status", missing),
        "solve_elapsed_seconds" => get(source, "solve_elapsed_seconds", missing),
        "max_rhs_residual" => get(source, "max_rhs_residual", missing),
        "max_mass_balance_residual" =>
            get(source, "max_mass_balance_residual", missing),
        "max_lower_bound_violation" =>
            get(source, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" =>
            get(source, "max_upper_bound_violation", missing),
        "max_stationarity_residual" =>
            get(source, "max_stationarity_residual", missing),
        "max_lower_complementarity_residual" =>
            get(source, "max_lower_complementarity_residual", missing),
        "max_upper_complementarity_residual" =>
            get(source, "max_upper_complementarity_residual", missing),
        "max_lower_complementarity_product" =>
            get(source, "max_lower_complementarity_product", missing),
        "max_upper_complementarity_product" =>
            get(source, "max_upper_complementarity_product", missing),
        "max_complementarity_tau_violation" =>
            get(source, "max_complementarity_tau_violation", missing),
        "max_complementarity_tau_violation_raw" =>
            get(source, "max_complementarity_tau_violation_raw", missing),
        "complementarity_tau_gate_tolerance" =>
            get(source, "complementarity_tau_gate_tolerance", missing),
        "complementarity_tau_gate_tolerance_source" =>
            get(source, "complementarity_tau_gate_tolerance_source", missing),
        "complementarity_tau_gate_pass" =>
            get(source, "complementarity_tau_gate_pass", missing),
        "max_state_abs_difference" =>
            get(source, "max_state_abs_difference", missing),
        "max_state_relative_rmse" =>
            get(source, "max_state_relative_rmse", missing),
        "global_max_state_abs_difference" =>
            get(source, "global_max_state_abs_difference", missing),
        "global_max_state_relative_rmse" =>
            get(source, "global_max_state_relative_rmse", missing),
        "final_biomass_difference" =>
            get(source, "final_biomass_difference", missing),
        "final_total_sugar_difference" =>
            get(source, "final_total_sugar_difference", missing),
        "next_recommended_action" => get(source, "next_recommended_action", missing),
        "full_dfba_cold_reference_deferred" =>
            get(source, "full_dfba_cold_reference_deferred", true),
        "reduced_full_equivalence_claimed" =>
            get(source, "reduced_full_equivalence_claimed", false),
        "persistent_lp_baseline_used" =>
            get(source, "persistent_lp_baseline_used", false),
        "hsl_required" => get(source, "hsl_required", false),
        "ma57_required" => get(source, "ma57_required", false),
        "indices_reacciones_used" => get(source, "indices_reacciones_used", false),
        "r0001_used_as_oxygen" => get(source, "r0001_used_as_oxygen", false),
        "error_type" => get(source, "error_type", missing),
        "error_message" => get(source, "error_message", missing),
    )
end

function _reduced_mpcc_viability_class(
    source::Dict{String, Any},
    simulation_viable::Bool,
    blocking_reasons::Vector{String},
    review_reasons::Vector{String},
    residual_feasible::Bool,
    iteration_limit_residual_feasible::Bool,
)::Tuple{String, String}
    simulation_viable && return ("simulation_viable_candidate", "green")
    "scientific_guardrail_violation" in blocking_reasons &&
        return ("guardrail_violation", "red")
    "source_row_not_completed" in blocking_reasons &&
        return ("failed_diagnostic_row", "red")
    "global_state_drift_too_large" in blocking_reasons &&
        return ("windowed_drift_too_large", "red")
    "state_drift_too_large" in blocking_reasons &&
        return ("state_drift_too_large", "red")
    "residual_thresholds_failed" in blocking_reasons &&
        return ("residual_thresholds_failed", "red")
    "window_continuation_incomplete" in blocking_reasons &&
        return ("window_continuation_incomplete", "red")
    if residual_feasible && iteration_limit_residual_feasible
        return ("iteration_limit_residual_feasible_candidate", "yellow")
    elseif residual_feasible && "candidate_not_trajectory_ready" in blocking_reasons
        return ("residual_feasible_but_not_trajectory_ready", "yellow")
    elseif any(reason -> occursin("sensitivity", reason), review_reasons)
        return ("sensitivity_review_required", "yellow")
    else
        return ("not_viable_solver_status", "red")
    end
end

function _reduced_mpcc_viability_review_reasons(
    source::Dict{String, Any},
    residual_feasible::Bool,
    trajectory_ready::Bool,
    iteration_limit_residual_feasible::Bool,
)::Vector{String}
    reasons = String[]
    residual_feasible && !trajectory_ready &&
        push!(reasons, "residual_feasible_but_not_trajectory_ready")
    iteration_limit_residual_feasible &&
        push!(reasons, "iteration_limit_residual_feasible")
    get(source, "trajectory_ready_improved_vs_previous_iter", false) === true &&
        push!(reasons, "ipopt_iteration_sensitivity_improved_trajectory_ready")
    get(source, "residual_feasible_improved_vs_previous_iter", false) === true &&
        push!(reasons, "ipopt_iteration_sensitivity_improved_residual_feasible")
    get(source, "trajectory_ready_improved_vs_coarser_nfe", false) === true &&
        push!(reasons, "mesh_refinement_improved_trajectory_ready")
    get(source, "state_relative_rmse_improved_vs_coarser_nfe", false) === true &&
        push!(reasons, "mesh_refinement_improved_state_rmse")
    String(get(source, "source_type", "")) == "windowed_continuation_global" &&
        push!(reasons, "windowed_continuation_global_gate")
    push!(reasons, "full_dfba_cold_reference_deferred")
    return unique(reasons)
end

function _reduced_mpcc_viability_residuals_pass(
    source::Dict{String, Any},
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Bool
    residual_thresholds_satisfied = get(source, "residual_thresholds_satisfied", missing)
    residual_thresholds_satisfied === false && return false
    checks = (
        ("max_rhs_residual", thresholds.max_rhs_residual),
        ("max_mass_balance_residual", thresholds.max_mass_balance_residual),
        ("max_lower_bound_violation", thresholds.max_lower_bound_violation),
        ("max_upper_bound_violation", thresholds.max_upper_bound_violation),
        ("max_stationarity_residual", thresholds.max_stationarity_residual),
        (
            "max_lower_complementarity_residual",
            thresholds.max_lower_complementarity_residual,
        ),
        (
            "max_upper_complementarity_residual",
            thresholds.max_upper_complementarity_residual,
        ),
    )
    for (key, threshold) in checks
        value = get(source, key, missing)
        _reduced_mpcc_viability_isfinite_number(value) || return false
        abs(Float64(value)) <= threshold || return false
    end
    return true
end

function _reduced_mpcc_viability_state_drift_pass(
    source::Dict{String, Any},
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Bool
    continuation_gate = get(source, "continuation_state_drift_gate_pass", missing)
    continuation_gate isa Bool && return continuation_gate
    abs_difference = get(source, "max_state_abs_difference", missing)
    relative_rmse = get(source, "max_state_relative_rmse", missing)
    _reduced_mpcc_viability_isfinite_number(abs_difference) || return false
    _reduced_mpcc_viability_isfinite_number(relative_rmse) || return false
    return abs(Float64(abs_difference)) <= thresholds.max_state_abs_difference &&
           abs(Float64(relative_rmse)) <= thresholds.max_state_relative_rmse
end

function _reduced_mpcc_viability_global_state_drift_pass(
    source::Dict{String, Any},
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Bool
    continuation_gate = get(source, "continuation_global_state_drift_gate_pass", missing)
    continuation_gate isa Bool && return continuation_gate
    abs_difference = get(source, "global_max_state_abs_difference", missing)
    relative_rmse = get(source, "global_max_state_relative_rmse", missing)
    if abs_difference === missing && relative_rmse === missing
        return true
    end
    _reduced_mpcc_viability_isfinite_number(abs_difference) || return false
    _reduced_mpcc_viability_isfinite_number(relative_rmse) || return false
    return abs(Float64(abs_difference)) <= thresholds.max_global_state_abs_difference &&
           abs(Float64(relative_rmse)) <= thresholds.max_global_state_relative_rmse
end

function _reduced_mpcc_viability_guardrails_pass(source::Dict{String, Any})::Bool
    return get(source, "full_dfba_cold_reference_deferred", true) === true &&
           get(source, "reduced_full_equivalence_claimed", false) === false &&
           get(source, "persistent_lp_baseline_used", false) === false &&
           get(source, "hsl_required", false) === false &&
           get(source, "ma57_required", false) === false &&
           get(source, "indices_reacciones_used", false) === false &&
           get(source, "r0001_used_as_oxygen", false) === false
end

function _reduced_mpcc_viability_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_viability_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_SIMULATION_VIABILITY_COLUMNS
        )...,
    )
end

function _reduced_mpcc_viability_metadata(
    table::DataFrame,
    source_type::String,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Dict{String, Any}
    green_count = count(==("green"), String.(table[!, "traffic_light"]))
    yellow_count = count(==("yellow"), String.(table[!, "traffic_light"]))
    red_count = count(==("red"), String.(table[!, "traffic_light"]))
    hard_red_count = count(
        row -> String(row["viability_class"]) in (
            "guardrail_violation",
            "failed_diagnostic_row",
            "windowed_drift_too_large",
            "state_drift_too_large",
            "residual_thresholds_failed",
            "window_continuation_incomplete",
        ),
        eachrow(table),
    )
    viable_count = count(==(true), table[!, "simulation_viable"])
    overall = green_count > 0 ? "green" : hard_red_count > 0 ? "red" :
              yellow_count > 0 ? "yellow" : "red"
    best = _reduced_mpcc_viability_best_row(table)
    return Dict{String, Any}(
        "viability_type" => REDUCED_DCDFBA_MPCC_SIMULATION_VIABILITY_TYPE,
        "source_type" => source_type,
        "n_rows" => nrow(table),
        "green_count" => green_count,
        "yellow_count" => yellow_count,
        "red_count" => red_count,
        "hard_red_count" => hard_red_count,
        "simulation_viable_candidate_count" => viable_count,
        "overall_traffic_light" => overall,
        "overall_simulation_viable" => viable_count > 0,
        "best_candidate_id" => best === nothing ? missing : best["candidate_id"],
        "best_candidate_traffic_light" => best === nothing ? missing : best["traffic_light"],
        "best_candidate_viability_class" => best === nothing ? missing : best["viability_class"],
        "recommended_next_action" => _reduced_mpcc_viability_recommended_action(table),
        "threshold_max_rhs_residual" => thresholds.max_rhs_residual,
        "threshold_max_mass_balance_residual" => thresholds.max_mass_balance_residual,
        "threshold_max_lower_bound_violation" => thresholds.max_lower_bound_violation,
        "threshold_max_upper_bound_violation" => thresholds.max_upper_bound_violation,
        "threshold_max_stationarity_residual" => thresholds.max_stationarity_residual,
        "threshold_max_lower_complementarity_residual" =>
            thresholds.max_lower_complementarity_residual,
        "threshold_max_upper_complementarity_residual" =>
            thresholds.max_upper_complementarity_residual,
        "threshold_max_state_abs_difference" => thresholds.max_state_abs_difference,
        "threshold_max_state_relative_rmse" => thresholds.max_state_relative_rmse,
        "threshold_max_global_state_abs_difference" =>
            thresholds.max_global_state_abs_difference,
        "threshold_max_global_state_relative_rmse" =>
            thresholds.max_global_state_relative_rmse,
        "outputs_written" => false,
        "viability_report_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC simulation-viability traffic light; diagnostic only and not a scientific simulation claim.",
    )
end

function _reduced_mpcc_viability_best_row(table::DataFrame)
    nrow(table) == 0 && return nothing
    order = Dict("green" => 1, "yellow" => 2, "red" => 3)
    sort_index = sortperm([
        (
            get(order, String(row["traffic_light"]), 4),
            _reduced_mpcc_viability_float_or_inf(row["global_max_state_relative_rmse"]),
            _reduced_mpcc_viability_float_or_inf(row["max_state_relative_rmse"]),
            _reduced_mpcc_viability_float_or_inf(row["horizon"]),
        ) for row in eachrow(table)
    ])
    isempty(sort_index) && return nothing
    return table[first(sort_index), :]
end

function _reduced_mpcc_viability_recommended_action(table::DataFrame)::String
    classes = Set(String.(table[!, "viability_class"]))
    if "simulation_viable_candidate" in classes
        return "review_green_candidate_before_scientific_use"
    elseif "windowed_drift_too_large" in classes
        return "reduce_windowed_candidate_drift_before_simulation"
    elseif "state_drift_too_large" in classes
        return "reduce_state_drift_before_simulation"
    elseif "iteration_limit_residual_feasible_candidate" in classes ||
           "residual_feasible_but_not_trajectory_ready" in classes
        return "improve_solver_termination_before_simulation"
    elseif "residual_thresholds_failed" in classes
        return "repair_residual_feasibility_before_simulation"
    elseif "guardrail_violation" in classes
        return "fix_scientific_guardrails_before_simulation"
    else
        return "inspect_failed_diagnostics_before_simulation"
    end
end

function _reduced_mpcc_viability_all_true(table::DataFrame, column::AbstractString)::Bool
    String(column) in names(table) || return false
    nrow(table) > 0 || return false
    return all(value -> value === true, table[!, String(column)])
end

function _reduced_mpcc_viability_sum(table::DataFrame, column::AbstractString)
    String(column) in names(table) || return missing
    values = Float64[
        Float64(value) for value in table[!, String(column)] if
        _reduced_mpcc_viability_isfinite_number(value)
    ]
    isempty(values) && return missing
    return sum(values)
end

function _reduced_mpcc_viability_max(table::DataFrame, column::AbstractString)
    String(column) in names(table) || return missing
    values = Float64[
        Float64(value) for value in table[!, String(column)] if
        _reduced_mpcc_viability_isfinite_number(value)
    ]
    isempty(values) && return missing
    return maximum(values)
end

function _reduced_mpcc_viability_first_nonmissing(table::DataFrame, column::AbstractString)
    String(column) in names(table) || return missing
    for value in table[!, String(column)]
        value === missing && continue
        return value
    end
    return missing
end

function _reduced_mpcc_viability_status_label(counts)
    counts isa AbstractDict || return missing
    isempty(counts) && return missing
    keys_sorted = sort(String.(collect(keys(counts))))
    length(keys_sorted) == 1 && return first(keys_sorted)
    return "mixed:" * join(keys_sorted, ",")
end

function _reduced_mpcc_viability_float_or_inf(value)::Float64
    _reduced_mpcc_viability_isfinite_number(value) || return Inf
    return Float64(value)
end

function _reduced_mpcc_viability_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_viability_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
