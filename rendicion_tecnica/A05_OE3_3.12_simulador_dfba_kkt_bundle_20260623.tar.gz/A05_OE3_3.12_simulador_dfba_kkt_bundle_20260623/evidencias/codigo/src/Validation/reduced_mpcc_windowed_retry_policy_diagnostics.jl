import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_POLICY_DIAGNOSTIC_TYPE =
    "reduced_dcdfba_mpcc_windowed_retry_policy_diagnostics"

const REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_POLICY_COLUMNS = [
    "source_window_id",
    "source_window_index",
    "source_window_t0",
    "source_window_tfinal",
    "source_window_hours",
    "source_solver_status",
    "source_traffic_light",
    "source_viability_class",
    "source_residual_feasible",
    "source_trajectory_ready",
    "source_max_mass_balance_residual",
    "source_max_mass_balance_ratio",
    "source_max_state_relative_rmse",
    "source_blocking_reasons",
    "n_retry_cases",
    "green_retry_count",
    "yellow_retry_count",
    "red_retry_count",
    "residual_feasible_retry_count",
    "trajectory_ready_retry_count",
    "best_retry_case_id",
    "best_retry_ipopt_max_iter",
    "best_retry_solver_status",
    "best_retry_traffic_light",
    "best_retry_viability_class",
    "best_retry_residual_feasible",
    "best_retry_trajectory_ready",
    "best_retry_max_mass_balance_residual",
    "best_retry_max_mass_balance_ratio",
    "best_retry_max_state_relative_rmse",
    "recovered_residual_feasibility",
    "recovered_trajectory_ready",
    "recovered_green_window",
    "recommended_next_action",
]

"""
    ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult

Diagnostic summary for applying single-window retry diagnostics to several
non-green or non-trajectory-ready windows from one reduced MPCC windowed
attempt. This is diagnostic-only: it does not mutate the source attempt, write
outputs, relax thresholds, or validate a scientific simulation.
"""
struct ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult
    retry_policy_table::DataFrame
    retry_results::Vector{ReducedDCDFBAMPCCWindowRetryDiagnosticResult}
    source_attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    metadata::Dict{String, Any}
end

"""
    diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(attempt, retry_results; kwargs...)

Aggregate already-computed single-window retry diagnostics for one reduced
MPCC windowed attempt. This method is deterministic and useful for unit tests
or cached/manual retry summaries.
"""
function diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry_results::AbstractVector{<:ReducedDCDFBAMPCCWindowRetryDiagnosticResult};
    window_indices = nothing,
    selection_policy::AbstractString = "iteration_limit_or_not_ready",
    max_retry_windows::Int = length(retry_results),
    ipopt_max_iter_values = nothing,
)::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult
    max_retry_windows >= 0 || throw(
        ArgumentError("Reduced MPCC windowed retry policy max_retry_windows must be nonnegative."),
    )
    selected_indices = _reduced_mpcc_windowed_retry_policy_selected_indices(
        attempt,
        window_indices,
        selection_policy,
        max_retry_windows,
    )
    rows = [
        _reduced_mpcc_windowed_retry_policy_row(attempt, retry) for
        retry in retry_results
    ]
    table = _reduced_mpcc_windowed_retry_policy_table(rows)
    metadata = _reduced_mpcc_windowed_retry_policy_metadata(
        attempt,
        rows,
        selected_indices,
        collect(retry_results);
        selection_policy = selection_policy,
        ipopt_max_iter_values = ipopt_max_iter_values,
    )
    return ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult(
        table,
        collect(retry_results),
        attempt,
        metadata,
    )
end

"""
    diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(attempt, model, reaction_map; kwargs...)

Select windows from an already-computed reduced MPCC windowed attempt and rerun
single-window retries with alternate Ipopt iteration budgets. The source
attempt thresholds and reduced-model guardrails are preserved by default.
"""
function diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    model::MetabolicModel,
    reaction_map::ReactionMap;
    window_indices = nothing,
    selection_policy::AbstractString = "iteration_limit_or_not_ready",
    max_retry_windows::Int = 3,
    ipopt_max_iter_values = [200, 300],
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    tau_schedule = nothing,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        _reduced_mpcc_windowed_retry_policy_residual_thresholds(
            attempt.viability_report.thresholds,
        ),
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        attempt.viability_report.thresholds,
    silent::Bool = true,
    continue_on_error::Bool = true,
)::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult
    max_iter_values = _reduced_mpcc_retry_validate_max_iter_values(ipopt_max_iter_values)
    max_retry_windows >= 0 || throw(
        ArgumentError("Reduced MPCC windowed retry policy max_retry_windows must be nonnegative."),
    )
    selected_indices = _reduced_mpcc_windowed_retry_policy_selected_indices(
        attempt,
        window_indices,
        selection_policy,
        max_retry_windows,
    )
    retry_results = ReducedDCDFBAMPCCWindowRetryDiagnosticResult[]
    for index in selected_indices
        retry = diagnose_reduced_dcdfba_mpcc_window_retry(
            attempt,
            model,
            reaction_map;
            window_index = index,
            ipopt_max_iter_values = max_iter_values,
            params = params,
            sequential_optimizer = sequential_optimizer,
            sequential_algorithm = sequential_algorithm,
            sequential_ode_abstol = sequential_ode_abstol,
            sequential_ode_reltol = sequential_ode_reltol,
            sequential_lp_atol = sequential_lp_atol,
            sequential_adaptive = sequential_adaptive,
            sequential_dt = sequential_dt,
            sequential_nonnegative = sequential_nonnegative,
            sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
            sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
            mpcc_optimizer = mpcc_optimizer,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            tau_schedule = tau_schedule,
            require_pre_solve_ready = require_pre_solve_ready,
            residual_thresholds = residual_thresholds,
            viability_thresholds = viability_thresholds,
            silent = silent,
            continue_on_error = continue_on_error,
        )
        push!(retry_results, retry)
    end
    return diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        attempt,
        retry_results;
        window_indices = selected_indices,
        selection_policy = selection_policy,
        max_retry_windows = max_retry_windows,
        ipopt_max_iter_values = max_iter_values,
    )
end

function _reduced_mpcc_windowed_retry_policy_residual_thresholds(
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::ReducedDCDFBAMPCCResidualThresholds
    return default_reduced_dcdfba_mpcc_residual_thresholds(
        max_rhs_residual = thresholds.max_rhs_residual,
        max_mass_balance_residual = thresholds.max_mass_balance_residual,
        max_lower_bound_violation = thresholds.max_lower_bound_violation,
        max_upper_bound_violation = thresholds.max_upper_bound_violation,
        max_stationarity_residual = thresholds.max_stationarity_residual,
        max_lower_complementarity_residual =
            thresholds.max_lower_complementarity_residual,
        max_upper_complementarity_residual =
            thresholds.max_upper_complementarity_residual,
    )
end

function _reduced_mpcc_windowed_retry_policy_selected_indices(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    requested_indices,
    selection_policy::AbstractString,
    max_retry_windows::Int,
)::Vector{Int}
    max_retry_windows >= 0 || throw(
        ArgumentError("Reduced MPCC windowed retry policy max_retry_windows must be nonnegative."),
    )
    if requested_indices !== nothing
        indices = Int.(collect(requested_indices))
        all(index -> index > 0, indices) || throw(
            ArgumentError("Reduced MPCC windowed retry policy window indices must be positive."),
        )
        length(unique(indices)) == length(indices) || throw(
            ArgumentError("Reduced MPCC windowed retry policy window indices must be unique."),
        )
        _reduced_mpcc_windowed_retry_policy_validate_indices(attempt, indices)
        max_retry_windows == 0 && return Int[]
        return first(indices, min(length(indices), max_retry_windows))
    end
    policy = lowercase(String(selection_policy))
    policy in ("iteration_limit_or_not_ready", "iteration_limit", "not_trajectory_ready", "non_green") ||
        throw(
            ArgumentError(
                "Reduced MPCC windowed retry policy selection_policy must be one of " *
                "iteration_limit_or_not_ready, iteration_limit, not_trajectory_ready, non_green.",
            ),
        )
    max_retry_windows == 0 && return Int[]
    rows = _reduced_mpcc_windowed_retry_policy_window_rows(attempt)
    selected = Int[]
    for row in rows
        _reduced_mpcc_windowed_retry_policy_row_selected(row, policy) || continue
        index = _reduced_mpcc_retry_int_or_missing(get(row, "window_index", missing))
        index === missing && continue
        push!(selected, index)
        length(selected) >= max_retry_windows && break
    end
    return selected
end

function _reduced_mpcc_windowed_retry_policy_validate_indices(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    indices::Vector{Int},
)
    available = Set(
        Int(row["window_index"]) for row in _reduced_mpcc_windowed_retry_policy_window_rows(attempt) if
        _reduced_mpcc_retry_int_or_missing(get(row, "window_index", missing)) !== missing
    )
    all(index -> index in available, indices) || throw(
        ArgumentError("Reduced MPCC windowed retry policy requested a window not present in the attempt."),
    )
    return nothing
end

function _reduced_mpcc_windowed_retry_policy_window_rows(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
)
    return [
        row for row in eachrow(attempt.viability_report.viability_table) if
        String(get(row, "source_type", "")) == "windowed_continuation_window"
    ]
end

function _reduced_mpcc_windowed_retry_policy_row_selected(row, policy::String)::Bool
    solver_status = String(get(row, "solver_status", ""))
    trajectory_ready = get(row, "trajectory_ready", false) === true
    traffic_light = String(get(row, "traffic_light", ""))
    if policy == "iteration_limit_or_not_ready"
        return solver_status == "ITERATION_LIMIT" || !trajectory_ready
    elseif policy == "iteration_limit"
        return solver_status == "ITERATION_LIMIT"
    elseif policy == "not_trajectory_ready"
        return !trajectory_ready
    else
        return traffic_light != "green"
    end
end

function _reduced_mpcc_windowed_retry_policy_row(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry::ReducedDCDFBAMPCCWindowRetryDiagnosticResult,
)::Dict{String, Any}
    metadata = retry.metadata
    source_window_id = String(get(metadata, "source_window_id", ""))
    source_row = _reduced_mpcc_windowed_retry_policy_source_row(attempt, source_window_id)
    best = _reduced_mpcc_windowed_retry_policy_best_retry_row(retry)
    trajectory_count = count(
        row -> get(row, "trajectory_ready", false) === true,
        eachrow(retry.retry_table),
    )
    source_trajectory_ready =
        _reduced_mpcc_windowed_retry_policy_row_value(source_row, "trajectory_ready") === true
    best_trajectory_ready =
        _reduced_mpcc_windowed_retry_policy_row_value(best, "trajectory_ready") === true
    return Dict{String, Any}(
        "source_window_id" => get(metadata, "source_window_id", missing),
        "source_window_index" => get(metadata, "source_window_index", missing),
        "source_window_t0" => get(metadata, "source_window_t0", missing),
        "source_window_tfinal" => get(metadata, "source_window_tfinal", missing),
        "source_window_hours" => get(metadata, "source_window_hours", missing),
        "source_solver_status" => get(metadata, "source_solver_status", missing),
        "source_traffic_light" => get(metadata, "source_traffic_light", missing),
        "source_viability_class" => get(metadata, "source_viability_class", missing),
        "source_residual_feasible" => get(metadata, "source_residual_feasible", missing),
        "source_trajectory_ready" => source_trajectory_ready,
        "source_max_mass_balance_residual" =>
            get(metadata, "source_max_mass_balance_residual", missing),
        "source_max_mass_balance_ratio" =>
            get(metadata, "source_max_mass_balance_ratio", missing),
        "source_max_state_relative_rmse" =>
            _reduced_mpcc_windowed_retry_policy_row_value(
                source_row,
                "max_state_relative_rmse",
            ),
        "source_blocking_reasons" => get(metadata, "source_blocking_reasons", missing),
        "n_retry_cases" => get(metadata, "n_retry_cases", nrow(retry.retry_table)),
        "green_retry_count" => get(metadata, "green_retry_count", missing),
        "yellow_retry_count" => get(metadata, "yellow_retry_count", missing),
        "red_retry_count" => get(metadata, "red_retry_count", missing),
        "residual_feasible_retry_count" =>
            get(metadata, "residual_feasible_retry_count", missing),
        "trajectory_ready_retry_count" => trajectory_count,
        "best_retry_case_id" => get(metadata, "best_retry_case_id", missing),
        "best_retry_ipopt_max_iter" =>
            get(metadata, "best_retry_ipopt_max_iter", missing),
        "best_retry_solver_status" =>
            _reduced_mpcc_windowed_retry_policy_row_value(best, "solver_status"),
        "best_retry_traffic_light" =>
            get(metadata, "best_retry_traffic_light", missing),
        "best_retry_viability_class" =>
            get(metadata, "best_retry_viability_class", missing),
        "best_retry_residual_feasible" =>
            _reduced_mpcc_windowed_retry_policy_row_value(best, "residual_feasible"),
        "best_retry_trajectory_ready" => best_trajectory_ready,
        "best_retry_max_mass_balance_residual" =>
            get(metadata, "best_retry_max_mass_balance_residual", missing),
        "best_retry_max_mass_balance_ratio" =>
            get(metadata, "best_retry_max_mass_balance_ratio", missing),
        "best_retry_max_state_relative_rmse" =>
            _reduced_mpcc_windowed_retry_policy_row_value(
                best,
                "max_state_relative_rmse",
            ),
        "recovered_residual_feasibility" =>
            get(metadata, "retry_recovered_residual_feasibility", false),
        "recovered_trajectory_ready" => !source_trajectory_ready && trajectory_count > 0,
        "recovered_green_window" =>
            get(metadata, "retry_recovered_green_window", false),
        "recommended_next_action" =>
            _reduced_mpcc_windowed_retry_policy_row_action(
                get(metadata, "retry_recovered_green_window", false),
                !source_trajectory_ready && trajectory_count > 0,
                get(metadata, "retry_recovered_residual_feasibility", false),
            ),
    )
end

function _reduced_mpcc_windowed_retry_policy_source_row(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    source_window_id::AbstractString,
)
    isempty(source_window_id) && return nothing
    table = attempt.viability_report.viability_table
    nrow(table) == 0 && return nothing
    index = findfirst(==(String(source_window_id)), String.(table[!, "candidate_id"]))
    return index === nothing ? nothing : table[index, :]
end

function _reduced_mpcc_windowed_retry_policy_best_retry_row(
    retry::ReducedDCDFBAMPCCWindowRetryDiagnosticResult,
)
    case_id = get(retry.metadata, "best_retry_case_id", missing)
    case_id === missing && return nothing
    table = retry.retry_table
    nrow(table) == 0 && return nothing
    index = findfirst(==(String(case_id)), String.(table[!, "retry_case_id"]))
    return index === nothing ? nothing : table[index, :]
end

function _reduced_mpcc_windowed_retry_policy_row_action(
    recovered_green::Bool,
    recovered_trajectory::Bool,
    recovered_residual::Bool,
)::String
    recovered_green && return "rerun_windowed_attempt_with_retry_policy_for_this_window"
    recovered_trajectory && return "review_recovered_trajectory_ready_retry"
    recovered_residual && return "review_residual_feasible_retry_before_acceptance"
    return "inspect_solver_scaling_before_more_retry_budget"
end

function _reduced_mpcc_windowed_retry_policy_metadata(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    rows::Vector{Dict{String, Any}},
    selected_indices::Vector{Int},
    retry_results::Vector{ReducedDCDFBAMPCCWindowRetryDiagnosticResult};
    selection_policy::AbstractString,
    ipopt_max_iter_values,
)::Dict{String, Any}
    first_unrecovered = _reduced_mpcc_windowed_retry_policy_first_row(
        rows,
        row -> get(row, "recovered_green_window", false) !== true &&
               get(row, "recovered_trajectory_ready", false) !== true,
    )
    return Dict{String, Any}(
        "diagnostic_type" =>
            REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_POLICY_DIAGNOSTIC_TYPE,
        "target_horizon" => get(attempt.metadata, "target_horizon", missing),
        "horizon_reached" => get(attempt.metadata, "horizon_reached", missing),
        "target_completed" => get(attempt.metadata, "target_completed", missing),
        "attempt_traffic_light" =>
            get(attempt.metadata, "attempt_traffic_light", missing),
        "source_selection_policy" => String(selection_policy),
        "selected_window_indices" => copy(selected_indices),
        "ipopt_max_iter_values" =>
            ipopt_max_iter_values === nothing ? missing : collect(ipopt_max_iter_values),
        "n_selected_windows" => length(selected_indices),
        "n_retried_windows" => length(rows),
        "n_retry_results" => length(retry_results),
        "green_recovered_count" =>
            count(row -> get(row, "recovered_green_window", false) === true, rows),
        "trajectory_ready_recovered_count" =>
            count(row -> get(row, "recovered_trajectory_ready", false) === true, rows),
        "residual_feasible_recovered_count" =>
            count(row -> get(row, "recovered_residual_feasibility", false) === true, rows),
        "all_selected_windows_recovered_green" =>
            !isempty(rows) &&
            all(row -> get(row, "recovered_green_window", false) === true, rows),
        "all_selected_windows_recovered_trajectory_ready" =>
            !isempty(rows) &&
            all(row -> get(row, "recovered_trajectory_ready", false) === true, rows),
        "first_unrecovered_window_id" =>
            _reduced_mpcc_windowed_retry_policy_dict_value(
                first_unrecovered,
                "source_window_id",
            ),
        "first_unrecovered_window_index" =>
            _reduced_mpcc_windowed_retry_policy_dict_value(
                first_unrecovered,
                "source_window_index",
            ),
        "recommended_next_action" =>
            _reduced_mpcc_windowed_retry_policy_recommended_action(rows, selected_indices),
        "outputs_written" => false,
        "retry_policy_diagnostic_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC multi-window retry policy diagnostics; diagnostic only and not a validated scientific simulation.",
    )
end

function _reduced_mpcc_windowed_retry_policy_recommended_action(
    rows::Vector{Dict{String, Any}},
    selected_indices::Vector{Int},
)::String
    isempty(selected_indices) && return "no_retry_windows_selected_review_attempt_status"
    isempty(rows) && return "run_retry_policy_for_selected_windows"
    all(row -> get(row, "recovered_green_window", false) === true, rows) &&
        return "rerun_windowed_attempt_with_retry_policy_for_selected_windows"
    any(row -> get(row, "recovered_trajectory_ready", false) === true, rows) &&
        return "review_partial_trajectory_ready_retry_recovery"
    any(row -> get(row, "recovered_residual_feasibility", false) === true, rows) &&
        return "review_partial_residual_retry_recovery"
    return "inspect_solver_scaling_before_more_retry_budget"
end

function _reduced_mpcc_windowed_retry_policy_first_row(rows::Vector{Dict{String, Any}}, predicate)
    index = findfirst(predicate, rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_windowed_retry_policy_row_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_retry_policy_dict_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_retry_policy_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_windowed_retry_policy_table_scalar(get(row, column, missing)) for
                row in rows
            ] for column in REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_POLICY_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_retry_policy_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
