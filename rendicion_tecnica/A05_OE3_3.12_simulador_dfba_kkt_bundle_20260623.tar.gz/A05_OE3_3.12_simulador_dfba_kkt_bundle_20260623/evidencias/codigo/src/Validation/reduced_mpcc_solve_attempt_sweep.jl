import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_SWEEP_TYPE =
    "reduced_dcdfba_mpcc_solve_attempt_short_horizon_sweep"

const REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_SWEEP_COLUMNS = [
    "scenario_id",
    "scenario_status",
    "t0",
    "tfinal",
    "horizon",
    "nfe",
    "degree",
    "boundary_dt",
    "n_boundary_points",
    "n_collocation_points",
    "linear_solver",
    "ipopt_profile",
    "complementarity_mode",
    "complementarity_tau",
    "tau_schedule",
    "tau_continuation_stage_count",
    "tau_continuation_completed",
    "tau_continuation_final_residual_feasible",
    "tau_continuation_final_tau_gate_pass",
    "tau_continuation_blocking_stage",
    "tau_continuation_blocking_reason",
    "tau_continuation_stage_advance_count",
    "solver_status",
    "primal_status",
    "solve_elapsed_seconds",
    "candidate_residual_feasible",
    "candidate_iteration_limit_residual_feasible",
    "candidate_trajectory_ready",
    "candidate_is_scientific_simulation",
    "residual_thresholds_satisfied",
    "dominant_residual",
    "next_recommended_action",
    "candidate_warning_count",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_lower_complementarity_product",
    "max_upper_complementarity_product",
    "max_complementarity_tau_violation",
    "max_complementarity_tau_violation_raw",
    "complementarity_tau_gate_tolerance",
    "complementarity_tau_gate_tolerance_source",
    "complementarity_tau_gate_pass",
    "max_state_abs_difference",
    "max_state_rmse",
    "max_state_relative_rmse",
    "final_biomass_difference",
    "final_glucose_difference",
    "final_fructose_difference",
    "final_ethanol_difference",
    "final_total_sugar_difference",
    "min_candidate_state_value",
    "full_dfba_cold_reference_deferred",
    "reduced_full_equivalence_claimed",
    "persistent_lp_baseline_used",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCSolveAttemptSweepResult

In-memory diagnostic sweep over short reduced MPCC solve attempts. Each
completed scenario is produced by `compare_reduced_dcdfba_mpcc_to_sequential`,
so this object summarizes solver status, residuals, and reduced sequential
state mismatch without writing outputs or claiming a solved MPCC trajectory.
"""
struct ReducedDCDFBAMPCCSolveAttemptSweepResult
    scenario_table::DataFrame
    comparison_results::Vector{ReducedDCDFBAMPCCSequentialComparisonResult}
    metadata::Dict{String, Any}
end

"""
    sweep_reduced_dcdfba_mpcc_solve_attempts(comparisons)

Summarize already-computed reduced MPCC-vs-sequential comparison results as a
short-horizon solve-attempt sweep. This method is useful for deterministic unit
tests and for aggregating cached in-memory diagnostics.
"""
function sweep_reduced_dcdfba_mpcc_solve_attempts(
    comparisons::AbstractVector{<:ReducedDCDFBAMPCCSequentialComparisonResult},
)::ReducedDCDFBAMPCCSolveAttemptSweepResult
    isempty(comparisons) && throw(
        ArgumentError("Reduced MPCC solve-attempt sweep requires at least one comparison result."),
    )
    rows = Dict{String, Any}[]
    collected = ReducedDCDFBAMPCCSequentialComparisonResult[]
    for (index, comparison) in enumerate(comparisons)
        spec = _reduced_mpcc_sweep_inferred_spec(index, comparison)
        push!(rows, _reduced_mpcc_sweep_completed_row(spec, comparison))
        push!(collected, comparison)
    end
    table = _reduced_mpcc_sweep_table(rows)
    metadata = _reduced_mpcc_sweep_metadata(rows, collected)
    return ReducedDCDFBAMPCCSolveAttemptSweepResult(table, collected, metadata)
end

"""
    sweep_reduced_dcdfba_mpcc_solve_attempts(model, reaction_map; horizons, nfe_values, kwargs...)

Run a guarded reduced MPCC solve-attempt comparison for each `(horizon, nfe)`
scenario, then aggregate the resulting solver, residual, and state-mismatch
diagnostics. This is a diagnostic sweep only: no files are written, no full
model baseline is run, and no solved MPCC trajectory is claimed.
"""
function sweep_reduced_dcdfba_mpcc_solve_attempts(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    horizons = [0.25],
    nfe_values = [1],
    t0::Real = 0.0,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    tau_schedule = nothing,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    silent::Bool = true,
    continue_on_error::Bool = true,
)::ReducedDCDFBAMPCCSolveAttemptSweepResult
    specs = _reduced_mpcc_sweep_specs(t0, horizons, nfe_values, degree)
    rows = Dict{String, Any}[]
    comparisons = ReducedDCDFBAMPCCSequentialComparisonResult[]

    for spec in specs
        try
            comparison = _reduced_mpcc_sweep_run_scenario(
                model,
                reaction_map;
                spec = spec,
                y0 = y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = ipopt_max_iter,
                linear_solver = linear_solver,
                ipopt_profile = ipopt_profile,
                complementarity_mode = complementarity_mode,
                complementarity_tau = complementarity_tau,
                complementarity_tau_gate_tol = complementarity_tau_gate_tol,
                tau_schedule = tau_schedule,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                silent = silent,
            )
            push!(comparisons, comparison)
            push!(rows, _reduced_mpcc_sweep_completed_row(spec, comparison))
        catch err
            continue_on_error || rethrow()
            push!(rows, _reduced_mpcc_sweep_error_row(spec, err))
        end
    end

    table = _reduced_mpcc_sweep_table(rows)
    metadata = _reduced_mpcc_sweep_metadata(rows, comparisons)
    return ReducedDCDFBAMPCCSolveAttemptSweepResult(table, comparisons, metadata)
end

function _reduced_mpcc_sweep_run_scenario(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    spec,
    y0::AbstractVector,
    params::ZentenoKineticParameters,
    sequential_optimizer,
    sequential_algorithm,
    sequential_ode_abstol::Real,
    sequential_ode_reltol::Real,
    sequential_lp_atol::Real,
    sequential_adaptive::Bool,
    sequential_dt,
    sequential_nonnegative::Bool,
    sequential_stop_on_sugar_depletion::Bool,
    sequential_reconstruct_fluxes::Bool,
    mpcc_optimizer,
    ipopt_max_iter::Union{Nothing, Int},
    linear_solver::AbstractString,
    ipopt_profile::AbstractString,
    complementarity_mode::Union{Symbol, AbstractString},
    complementarity_tau::Real,
    complementarity_tau_gate_tol::Union{Nothing, Real},
    tau_schedule,
    require_pre_solve_ready::Bool,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds,
    silent::Bool,
)::ReducedDCDFBAMPCCSequentialComparisonResult
    saveat = spec.horizon / spec.nfe
    sequential_result = simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = (spec.t0, spec.tfinal),
        params = params,
        optimizer = sequential_optimizer,
        silent = silent,
        lp_atol = sequential_lp_atol,
        ode_abstol = sequential_ode_abstol,
        ode_reltol = sequential_ode_reltol,
        saveat = saveat,
        algorithm = sequential_algorithm,
        adaptive = sequential_adaptive,
        dt = sequential_dt,
        nonnegative = sequential_nonnegative,
        stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        reconstruct_fluxes = sequential_reconstruct_fluxes,
        model_scope = "reduced",
    )
    solve_attempt =
        tau_schedule === nothing ?
        solve_reduced_dcdfba_mpcc_solve_attempt(
            model,
            reaction_map;
            sequential_initialization = sequential_result,
            tspan = (spec.t0, spec.tfinal),
            nfe = spec.nfe,
            degree = spec.degree,
            residual_thresholds = residual_thresholds,
            optimizer = mpcc_optimizer,
            ipopt_max_iter = ipopt_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            complementarity_tau_gate_tol = complementarity_tau_gate_tol,
            require_pre_solve_ready = require_pre_solve_ready,
            silent = silent,
        ) :
        solve_reduced_dcdfba_mpcc_tau_continuation(
            model,
            reaction_map;
            sequential_initialization = sequential_result,
            tspan = (spec.t0, spec.tfinal),
            nfe = spec.nfe,
            degree = spec.degree,
            residual_thresholds = residual_thresholds,
            optimizer = mpcc_optimizer,
            ipopt_max_iter = ipopt_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau_gate_tol = complementarity_tau_gate_tol,
            tau_schedule = tau_schedule,
            require_pre_solve_ready = require_pre_solve_ready,
            silent = silent,
        ).final_result
    solve_attempt === nothing && throw(
        ArgumentError("Reduced MPCC tau continuation did not produce any solve-attempt result."),
    )
    trajectory_candidate = extract_reduced_dcdfba_mpcc_trajectory_candidate(solve_attempt)
    comparison = compare_reduced_dcdfba_mpcc_to_sequential(sequential_result, trajectory_candidate)
    _reduced_mpcc_sweep_merge_solve_attempt_metadata!(comparison, solve_attempt)
    return comparison
end

function _reduced_mpcc_sweep_merge_solve_attempt_metadata!(
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
    solve_attempt::ReducedDCDFBAMPCCSolveAttemptResult,
)
    candidate = comparison.trajectory_candidate
    for (key, value) in solve_attempt.metadata
        candidate.metadata[key] = value
        candidate.candidate_diagnostics.metadata[key] = value
    end
    for key in (
        "solve_elapsed_seconds",
        "post_solve_next_recommended_action",
        "post_solve_dominant_residual",
        "post_solve_residual_thresholds_satisfied",
        "post_solve_iteration_limit_residual_feasible_candidate",
        "trajectory_extraction_ready",
        "candidate_residual_thresholds_satisfied",
        "candidate_dominant_residual",
        "tau_schedule",
        "tau_continuation_stage_count",
        "tau_continuation_completed",
        "tau_continuation_allow_coarse_tau_fallback",
        "tau_continuation_final_residual_feasible",
        "tau_continuation_final_tau_gate_pass",
        "tau_continuation_blocking_stage",
        "tau_continuation_blocking_reason",
        "tau_continuation_stage_advance_count",
        "tau_continuation_final_tau",
        "tau_stage_max_iters",
        "tau_stage_max_iters_label",
        "tau_continuation_selected_stage_index",
        "tau_continuation_selected_tau",
        "tau_continuation_selected_reason",
        "tau_continuation_selected_by_best_stage_fallback",
        "tau_continuation_selected_by_coarse_tau_fallback",
        "tau_continuation_coarse_tau_fallback_applied",
        "tau_continuation_attempted_final_stage_index",
        "tau_continuation_attempted_final_tau",
        "tau_continuation_attempted_final_residual_feasible",
        "tau_continuation_attempted_final_tau_gate_pass",
        "tau_continuation_polish_attempted",
        "tau_continuation_polish_failed",
        "tau_continuation_final_retry_performed",
        "tau_continuation_final_retry_count",
        "tau_continuation_final_retry_window_count",
        "tau_continuation_final_retry_max_iter",
        "tau_continuation_final_retry_start_source",
        "cross_window_flux_dual_start_applied",
        "cross_window_flux_dual_start_policy",
        "cross_window_flux_dual_start_source",
        "cross_window_flux_dual_start_source_stage_index",
        "cross_window_flux_dual_start_source_tau",
        "cross_window_flux_dual_start_source_solver_status",
        "cross_window_flux_dual_start_source_residual_feasible",
        "cross_window_flux_dual_start_max_flux_projection_adjustment",
        "cross_window_flux_dual_start_max_lower_dual_sign_clipping",
        "cross_window_flux_dual_start_max_upper_dual_sign_clipping",
        "cross_window_flux_dual_start_rhs_derivatives_refreshed",
        "candidate_residual_feasible_source",
        "candidate_residual_feasible_strict_before_coarse_tau_fallback",
        "candidate_coarse_tau_stage_fallback_applied",
    )
        haskey(solve_attempt.metadata, key) &&
            (comparison.metadata[key] = solve_attempt.metadata[key])
    end
    return comparison
end

function _reduced_mpcc_sweep_specs(
    t0::Real,
    horizons,
    nfe_values,
    degree::Int,
)::Vector{NamedTuple}
    initial_time = Float64(t0)
    isfinite(initial_time) || throw(
        ArgumentError("Reduced MPCC solve-attempt sweep t0 must be finite."),
    )
    degree == 3 || throw(
        ArgumentError("Reduced MPCC solve-attempt sweep currently supports only degree == 3."),
    )

    horizon_values = Float64.(collect(horizons))
    isempty(horizon_values) && throw(
        ArgumentError("Reduced MPCC solve-attempt sweep horizons must not be empty."),
    )
    all(value -> isfinite(value) && value > 0.0, horizon_values) || throw(
        ArgumentError("Reduced MPCC solve-attempt sweep horizons must be finite and positive."),
    )

    finite_element_values = Int.(collect(nfe_values))
    isempty(finite_element_values) && throw(
        ArgumentError("Reduced MPCC solve-attempt sweep nfe_values must not be empty."),
    )
    all(value -> value > 0, finite_element_values) || throw(
        ArgumentError("Reduced MPCC solve-attempt sweep nfe_values must be positive integers."),
    )

    specs = NamedTuple[]
    index = 1
    for horizon in horizon_values, nfe in finite_element_values
        push!(
            specs,
            (
                scenario_id = _reduced_mpcc_sweep_scenario_id(index),
                t0 = initial_time,
                tfinal = initial_time + horizon,
                horizon = horizon,
                nfe = nfe,
                degree = degree,
            ),
        )
        index += 1
    end
    return specs
end

function _reduced_mpcc_sweep_inferred_spec(
    index::Int,
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
)
    metadata = comparison.metadata
    candidate_metadata = comparison.trajectory_candidate.metadata
    t0 = _reduced_mpcc_sweep_float_or_missing(get(metadata, "initial_time", first(comparison.sequential_result.time)))
    tfinal = _reduced_mpcc_sweep_float_or_missing(get(metadata, "final_time", last(comparison.sequential_result.time)))
    horizon = (t0 === missing || tfinal === missing) ? missing : tfinal - t0
    inferred_nfe = length(comparison.sequential_result.time) - 1
    nfe = _reduced_mpcc_sweep_int_or_missing(get(candidate_metadata, "candidate_grid_nfe", inferred_nfe))
    degree = _reduced_mpcc_sweep_int_or_missing(get(candidate_metadata, "candidate_collocation_degree", 3))
    return (
        scenario_id = _reduced_mpcc_sweep_scenario_id(index),
        t0 = t0,
        tfinal = tfinal,
        horizon = horizon,
        nfe = nfe,
        degree = degree,
    )
end

function _reduced_mpcc_sweep_completed_row(
    spec,
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
)::Dict{String, Any}
    comparison_metadata = comparison.metadata
    candidate = comparison.trajectory_candidate
    candidate_metadata = candidate.metadata
    residuals = candidate.candidate_diagnostics.residual_values
    nfe = spec.nfe
    degree = spec.degree
    horizon = spec.horizon
    boundary_dt = (horizon === missing || nfe === missing) ? missing : horizon / nfe
    n_collocation_points =
        (nfe === missing || degree === missing) ? missing : Int(nfe) * Int(degree)

    return Dict{String, Any}(
        "scenario_id" => spec.scenario_id,
        "scenario_status" => "completed",
        "t0" => spec.t0,
        "tfinal" => spec.tfinal,
        "horizon" => horizon,
        "nfe" => nfe,
        "degree" => degree,
        "boundary_dt" => boundary_dt,
        "n_boundary_points" => length(comparison.sequential_result.time),
        "n_collocation_points" => n_collocation_points,
        "linear_solver" => get(candidate_metadata, "linear_solver", missing),
        "ipopt_profile" => get(candidate_metadata, "ipopt_profile", missing),
        "complementarity_mode" => get(candidate_metadata, "complementarity_mode", missing),
        "complementarity_tau" => get(candidate_metadata, "complementarity_tau", missing),
        "tau_schedule" => get(candidate_metadata, "tau_schedule", missing),
        "tau_continuation_stage_count" =>
            get(candidate_metadata, "tau_continuation_stage_count", missing),
        "tau_continuation_completed" =>
            get(candidate_metadata, "tau_continuation_completed", missing),
        "tau_continuation_final_residual_feasible" =>
            get(candidate_metadata, "tau_continuation_final_residual_feasible", missing),
        "tau_continuation_final_tau_gate_pass" =>
            get(candidate_metadata, "tau_continuation_final_tau_gate_pass", missing),
        "tau_continuation_blocking_stage" =>
            get(candidate_metadata, "tau_continuation_blocking_stage", missing),
        "tau_continuation_blocking_reason" =>
            get(candidate_metadata, "tau_continuation_blocking_reason", missing),
        "tau_continuation_stage_advance_count" =>
            get(candidate_metadata, "tau_continuation_stage_advance_count", missing),
        "solver_status" => get(
            comparison_metadata,
            "candidate_solver_status",
            get(candidate_metadata, "candidate_solver_status", missing),
        ),
        "primal_status" => get(
            comparison_metadata,
            "candidate_primal_status",
            get(candidate_metadata, "candidate_primal_status", missing),
        ),
        "solve_elapsed_seconds" => get(
            candidate_metadata,
            "solve_elapsed_seconds",
            get(comparison_metadata, "solve_elapsed_seconds", missing),
        ),
        "candidate_residual_feasible" => get(
            comparison_metadata,
            "candidate_residual_feasible",
            get(candidate_metadata, "candidate_residual_feasible", missing),
        ),
        "candidate_iteration_limit_residual_feasible" => get(
            comparison_metadata,
            "candidate_iteration_limit_residual_feasible",
            get(candidate_metadata, "candidate_iteration_limit_residual_feasible", missing),
        ),
        "candidate_trajectory_ready" => get(
            comparison_metadata,
            "candidate_trajectory_ready",
            get(candidate_metadata, "trajectory_candidate_ready", missing),
        ),
        "candidate_is_scientific_simulation" => get(
            comparison_metadata,
            "candidate_is_scientific_simulation",
            get(candidate_metadata, "trajectory_candidate_is_scientific_simulation", false),
        ),
        "residual_thresholds_satisfied" => get(
            candidate_metadata,
            "candidate_residual_thresholds_satisfied",
            get(candidate_metadata, "post_solve_residual_thresholds_satisfied", missing),
        ),
        "dominant_residual" => get(
            candidate_metadata,
            "candidate_dominant_residual",
            get(candidate_metadata, "post_solve_dominant_residual", missing),
        ),
        "next_recommended_action" => get(
            candidate_metadata,
            "post_solve_next_recommended_action",
            get(comparison_metadata, "post_solve_next_recommended_action", missing),
        ),
        "candidate_warning_count" => get(comparison_metadata, "candidate_warning_count", missing),
        "max_rhs_residual" => get(residuals, "max_rhs_residual", missing),
        "max_mass_balance_residual" => get(residuals, "max_mass_balance_residual", missing),
        "max_lower_bound_violation" => get(residuals, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" => get(residuals, "max_upper_bound_violation", missing),
        "max_stationarity_residual" => get(residuals, "max_stationarity_residual", missing),
        "max_lower_complementarity_residual" =>
            get(residuals, "max_lower_complementarity_residual", missing),
        "max_upper_complementarity_residual" =>
            get(residuals, "max_upper_complementarity_residual", missing),
        "max_lower_complementarity_product" =>
            get(candidate_metadata, "max_lower_complementarity_product", missing),
        "max_upper_complementarity_product" =>
            get(candidate_metadata, "max_upper_complementarity_product", missing),
        "max_complementarity_tau_violation" =>
            get(candidate_metadata, "max_complementarity_tau_violation", missing),
        "max_complementarity_tau_violation_raw" =>
            get(candidate_metadata, "max_complementarity_tau_violation_raw", missing),
        "complementarity_tau_gate_tolerance" =>
            get(candidate_metadata, "complementarity_tau_gate_tolerance", missing),
        "complementarity_tau_gate_tolerance_source" =>
            get(candidate_metadata, "complementarity_tau_gate_tolerance_source", missing),
        "complementarity_tau_gate_pass" =>
            get(candidate_metadata, "complementarity_tau_gate_pass", missing),
        "max_state_abs_difference" => get(comparison_metadata, "max_state_abs_difference", missing),
        "max_state_rmse" => get(comparison_metadata, "max_state_rmse", missing),
        "max_state_relative_rmse" =>
            get(comparison_metadata, "max_state_relative_rmse", missing),
        "final_biomass_difference" =>
            _reduced_mpcc_sweep_final_difference(comparison, "biomass"),
        "final_glucose_difference" =>
            _reduced_mpcc_sweep_final_difference(comparison, "glucose"),
        "final_fructose_difference" =>
            _reduced_mpcc_sweep_final_difference(comparison, "fructose"),
        "final_ethanol_difference" =>
            _reduced_mpcc_sweep_final_difference(comparison, "ethanol"),
        "final_total_sugar_difference" =>
            _reduced_mpcc_sweep_final_difference(comparison, "total_sugar"),
        "min_candidate_state_value" =>
            get(candidate.boundary_result.metadata, "min_state_value", minimum(candidate.boundary_result.states)),
        "full_dfba_cold_reference_deferred" =>
            get(comparison_metadata, "full_dfba_cold_reference_deferred", true),
        "reduced_full_equivalence_claimed" =>
            get(comparison_metadata, "reduced_full_equivalence_claimed", false),
        "persistent_lp_baseline_used" =>
            get(comparison_metadata, "persistent_lp_baseline_used", false),
        "indices_reacciones_used" => get(comparison_metadata, "indices_reacciones_used", false),
        "r0001_used_as_oxygen" => get(comparison_metadata, "r0001_used_as_oxygen", false),
        "error_type" => missing,
        "error_message" => missing,
    )
end

function _reduced_mpcc_sweep_error_row(spec, err)::Dict{String, Any}
    row = Dict{String, Any}(column => missing for column in REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_SWEEP_COLUMNS)
    row["scenario_id"] = spec.scenario_id
    row["scenario_status"] = "failed"
    row["t0"] = spec.t0
    row["tfinal"] = spec.tfinal
    row["horizon"] = spec.horizon
    row["nfe"] = spec.nfe
    row["degree"] = spec.degree
    row["boundary_dt"] = spec.horizon / spec.nfe
    row["n_boundary_points"] = spec.nfe + 1
    row["n_collocation_points"] = spec.nfe * spec.degree
    row["full_dfba_cold_reference_deferred"] = true
    row["reduced_full_equivalence_claimed"] = false
    row["persistent_lp_baseline_used"] = false
    row["indices_reacciones_used"] = false
    row["r0001_used_as_oxygen"] = false
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_sweep_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_sweep_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_SWEEP_COLUMNS
        )...,
    )
end

function _reduced_mpcc_sweep_metadata(
    rows::Vector{Dict{String, Any}},
    comparisons::Vector{ReducedDCDFBAMPCCSequentialComparisonResult},
)::Dict{String, Any}
    completed_count = count(row -> get(row, "scenario_status", "") == "completed", rows)
    failed_count = count(row -> get(row, "scenario_status", "") == "failed", rows)
    best_row = _reduced_mpcc_sweep_best_state_match_row(rows)
    return Dict{String, Any}(
        "sweep_type" => REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_SWEEP_TYPE,
        "comparison_type" => REDUCED_DCDFBA_MPCC_SEQUENTIAL_COMPARISON_TYPE,
        "n_scenarios" => length(rows),
        "n_completed_scenarios" => completed_count,
        "n_failed_scenarios" => failed_count,
        "n_comparison_results" => length(comparisons),
        "scenario_status_counts" => _reduced_mpcc_sweep_value_counts(rows, "scenario_status"),
        "solver_status_counts" => _reduced_mpcc_sweep_value_counts(rows, "solver_status"),
        "recommended_action_counts" =>
            _reduced_mpcc_sweep_value_counts(rows, "next_recommended_action"),
        "residual_feasible_scenario_count" =>
            count(row -> get(row, "candidate_residual_feasible", false) === true, rows),
        "iteration_limit_residual_feasible_scenario_count" => count(
            row -> get(row, "candidate_iteration_limit_residual_feasible", false) === true,
            rows,
        ),
        "trajectory_ready_scenario_count" =>
            count(row -> get(row, "candidate_trajectory_ready", false) === true, rows),
        "best_state_match_scenario_id" =>
            best_row === nothing ? missing : best_row["scenario_id"],
        "best_state_match_max_state_relative_rmse" =>
            best_row === nothing ? missing : best_row["max_state_relative_rmse"],
        "best_state_match_max_state_abs_difference" =>
            best_row === nothing ? missing : best_row["max_state_abs_difference"],
        "max_horizon" => _reduced_mpcc_sweep_finite_max(rows, "horizon"),
        "max_nfe" => _reduced_mpcc_sweep_finite_max(rows, "nfe"),
        "max_collocation_points" => _reduced_mpcc_sweep_finite_max(rows, "n_collocation_points"),
        "outputs_written" => false,
        "sweep_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Short-horizon reduced MPCC solve-attempt sweep; diagnostic only and not a solved scientific simulation.",
    )
end

function _reduced_mpcc_sweep_final_difference(
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
    state_name::AbstractString,
)
    table = comparison.state_metrics_table
    index = findfirst(==(String(state_name)), String.(table[!, "state_name"]))
    index === nothing && return missing
    return table[index, "final_difference_mpcc_minus_sequential"]
end

function _reduced_mpcc_sweep_best_state_match_row(rows::Vector{Dict{String, Any}})
    completed = [
        row for row in rows if get(row, "scenario_status", "") == "completed" &&
                               _reduced_mpcc_sweep_isfinite_number(get(row, "max_state_relative_rmse", missing))
    ]
    isempty(completed) && return nothing
    order = sortperm([
        (
            Float64(row["max_state_relative_rmse"]),
            Float64(row["max_state_abs_difference"]),
            Float64(get(row, "horizon", Inf)),
        ) for row in completed
    ])
    return completed[first(order)]
end

function _reduced_mpcc_sweep_value_counts(rows::Vector{Dict{String, Any}}, key::AbstractString)
    counts = Dict{String, Int}()
    for row in rows
        value = get(row, String(key), missing)
        value === missing && continue
        label = string(value)
        counts[label] = get(counts, label, 0) + 1
    end
    return counts
end

function _reduced_mpcc_sweep_finite_max(rows::Vector{Dict{String, Any}}, key::AbstractString)
    values = Float64[
        Float64(get(row, String(key), NaN)) for row in rows if
        _reduced_mpcc_sweep_isfinite_number(get(row, String(key), missing))
    ]
    isempty(values) && return missing
    return maximum(values)
end

function _reduced_mpcc_sweep_scenario_id(index::Int)::String
    return "scenario_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_sweep_float_or_missing(value)
    value === missing && return missing
    value === nothing && return missing
    return try
        converted = Float64(value)
        isfinite(converted) ? converted : missing
    catch
        missing
    end
end

function _reduced_mpcc_sweep_int_or_missing(value)
    value === missing && return missing
    value === nothing && return missing
    return try
        Int(value)
    catch
        missing
    end
end

function _reduced_mpcc_sweep_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_sweep_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
