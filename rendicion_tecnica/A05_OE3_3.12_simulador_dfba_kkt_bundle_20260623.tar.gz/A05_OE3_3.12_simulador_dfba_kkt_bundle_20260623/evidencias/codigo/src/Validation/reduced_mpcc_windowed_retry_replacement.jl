const REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_REPLACEMENT_TYPE =
    "reduced_dcdfba_mpcc_windowed_retry_replacement"

const REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_REPLACEMENT_COLUMNS = [
    "source_window_id",
    "source_window_index",
    "is_terminal_window",
    "replacement_applied",
    "replacement_reason",
    "source_solver_status",
    "source_traffic_light",
    "source_trajectory_ready",
    "best_retry_case_id",
    "best_retry_ipopt_max_iter",
    "best_retry_solver_status",
    "best_retry_traffic_light",
    "best_retry_viability_class",
    "best_retry_residual_feasible",
    "best_retry_trajectory_ready",
    "source_max_mass_balance_residual",
    "best_retry_max_mass_balance_residual",
    "source_max_state_relative_rmse",
    "best_retry_max_state_relative_rmse",
]

const REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_CASCADE_REBUILD_TYPE =
    "reduced_dcdfba_mpcc_windowed_retry_cascade_rebuild"

const REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_CASCADE_COLUMNS = [
    "window_id",
    "window_index",
    "cascade_role",
    "window_status",
    "t0",
    "tfinal",
    "solver_status",
    "traffic_light",
    "viability_class",
    "candidate_residual_feasible",
    "candidate_trajectory_ready",
    "candidate_allows_continuation",
    "replacement_applied",
    "retry_case_id",
    "retry_ipopt_max_iter",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCWindowedRetryReplacementResult

Corrective diagnostic that applies accepted reduced MPCC single-window retry
comparisons to a source windowed attempt and rebuilds the in-memory windowed
candidate classification. By default only terminal-window replacements are
applied, because replacing an interior window without re-solving downstream
windows can break the continuation state chain.
"""
struct ReducedDCDFBAMPCCWindowedRetryReplacementResult
    source_attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    retry_policy_diagnostic::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult
    rebuilt_continuation::ReducedDCDFBAMPCCWindowedContinuationResult
    rebuilt_attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    replacement_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult

Corrective diagnostic that applies one accepted retry replacement, then
re-solves downstream reduced MPCC windows from the new boundary state. Only the
earliest accepted retry is applied in one cascade, because later retry
diagnostics were computed from the pre-cascade state chain.
"""
struct ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult
    source_attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    retry_policy_diagnostic::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult
    rebuilt_continuation::ReducedDCDFBAMPCCWindowedContinuationResult
    rebuilt_attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    replacement_table::DataFrame
    cascade_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    apply_reduced_dcdfba_mpcc_window_retry_replacements(attempt, retry_policy; kwargs...)

Apply accepted retry-policy replacements to an already-computed reduced MPCC
windowed attempt and reassess the rebuilt candidate. This function does not run
new NLP solves; it only consumes retry comparisons already stored in
`retry_policy.retry_results`.
"""
function apply_reduced_dcdfba_mpcc_window_retry_replacements(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult;
    acceptance_policy::AbstractString = "green_or_trajectory_ready",
    terminal_only::Bool = true,
    continuation_acceptance_policy::AbstractString = String(
        get(
            attempt.metadata,
            "continuation_acceptance_policy",
            REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
        ),
    ),
    continuation_state_relative_rmse_threshold::Real = Float64(
        get(
            attempt.metadata,
            "continuation_state_relative_rmse_threshold",
            REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
        ),
    ),
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        attempt.viability_report.thresholds,
)::ReducedDCDFBAMPCCWindowedRetryReplacementResult
    retry_policy.source_attempt === attempt || throw(
        ArgumentError(
            "Reduced MPCC window retry replacement requires retry_policy.source_attempt === attempt.",
        ),
    )
    policy = _reduced_mpcc_windowed_retry_replacement_validate_acceptance_policy(
        acceptance_policy,
    )
    continuation_policy = _reduced_mpcc_window_validate_continuation_policy(
        continuation_acceptance_policy,
    )
    state_threshold = _reduced_mpcc_window_validate_state_relative_rmse_threshold(
        continuation_state_relative_rmse_threshold,
    )

    source_comparisons = attempt.continuation_result.window_comparisons
    replacement_comparisons = copy(source_comparisons)
    rows = Dict{String, Any}[]
    applied_indices = Int[]

    for retry in retry_policy.retry_results
        row = _reduced_mpcc_windowed_retry_replacement_row(
            attempt,
            retry;
            acceptance_policy = policy,
            terminal_only = terminal_only,
        )
        if row["replacement_applied"] === true
            comparison = row["_replacement_comparison"]
            source_index = Int(row["source_window_index"])
            replacement_comparisons[source_index] = comparison
            push!(applied_indices, source_index)
        end
        delete!(row, "_replacement_comparison")
        push!(rows, row)
    end

    replacement_table = _reduced_mpcc_windowed_retry_replacement_table(rows)
    rebuilt_continuation = attempt.continuation_result
    rebuilt_attempt = attempt
    if !isempty(applied_indices)
        target_horizon = _reduced_mpcc_windowed_retry_replacement_target_horizon(attempt)
        rebuilt_continuation = run_reduced_dcdfba_mpcc_windowed_continuation(
            replacement_comparisons;
            sequential_reference = attempt.continuation_result.sequential_reference,
            continuation_acceptance_policy = continuation_policy,
            continuation_state_relative_rmse_threshold = state_threshold,
        )
        rebuilt_attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
            rebuilt_continuation;
            target_horizon = target_horizon,
            thresholds = thresholds,
        )
    end

    metadata = _reduced_mpcc_windowed_retry_replacement_metadata(
        attempt,
        retry_policy,
        rebuilt_attempt,
        rows,
        applied_indices;
        acceptance_policy = policy,
        terminal_only = terminal_only,
        continuation_acceptance_policy = continuation_policy,
        continuation_state_relative_rmse_threshold = state_threshold,
    )
    return ReducedDCDFBAMPCCWindowedRetryReplacementResult(
        attempt,
        retry_policy,
        rebuilt_continuation,
        rebuilt_attempt,
        replacement_table,
        metadata,
    )
end

"""
    cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(attempt, retry_policy, model, reaction_map; kwargs...)

Apply the earliest accepted retry replacement and re-solve downstream reduced
MPCC windows from the replacement's final boundary state. This is a corrective
diagnostic workflow: it may run additional reduced MPCC solves, but it writes
no outputs and does not validate a scientific simulation.
"""
function cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult,
    model::MetabolicModel,
    reaction_map::ReactionMap;
    acceptance_policy::AbstractString = "green_or_trajectory_ready",
    continuation_acceptance_policy::AbstractString = String(
        get(
            attempt.metadata,
            "continuation_acceptance_policy",
            REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
        ),
    ),
    continuation_state_relative_rmse_threshold::Real = Float64(
        get(
            attempt.metadata,
            "continuation_state_relative_rmse_threshold",
            REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
        ),
    ),
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        attempt.viability_report.thresholds,
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    tau_schedule = nothing,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        _reduced_mpcc_windowed_retry_policy_residual_thresholds(thresholds),
    silent::Bool = true,
    continue_on_error::Bool = true,
    window_callback = nothing,
)::ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult
    runner = function (spec, y0)
        return _reduced_mpcc_window_run_one(
            model,
            reaction_map;
            spec = spec,
            y0 = y0,
            params = params,
            sequential_optimizer = sequential_optimizer,
            sequential_algorithm = sequential_algorithm,
            sequential_ode_abstol = sequential_ode_abstol,
            sequential_ode_reltol = sequential_ode_reltol,
            sequential_lp_atol = sequential_lp_atol,
            sequential_adaptive = sequential_adaptive,
            sequential_dt = sequential_dt,
            sequential_nonnegative = sequential_nonnegative,
            sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
            sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
            mpcc_optimizer = mpcc_optimizer,
            ipopt_max_iter = ipopt_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            complementarity_tau_gate_tol = nothing,
            tau_schedule = tau_schedule,
            flux_dual_start_seed = nothing,
            require_pre_solve_ready = require_pre_solve_ready,
            residual_thresholds = residual_thresholds,
            silent = silent,
        )
    end
    return cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        retry_policy;
        window_runner = runner,
        acceptance_policy = acceptance_policy,
        continuation_acceptance_policy = continuation_acceptance_policy,
        continuation_state_relative_rmse_threshold =
            continuation_state_relative_rmse_threshold,
        thresholds = thresholds,
        continue_on_error = continue_on_error,
        window_callback = window_callback,
    )
end

"""
    cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(attempt, retry_policy; window_runner, kwargs...)

Deterministic/injected variant for cached diagnostics and unit tests. The
`window_runner(spec, y0)` callable must return one
`ReducedDCDFBAMPCCSequentialComparisonResult` for each downstream window.
"""
function cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult;
    window_runner = nothing,
    acceptance_policy::AbstractString = "green_or_trajectory_ready",
    continuation_acceptance_policy::AbstractString = String(
        get(
            attempt.metadata,
            "continuation_acceptance_policy",
            REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
        ),
    ),
    continuation_state_relative_rmse_threshold::Real = Float64(
        get(
            attempt.metadata,
            "continuation_state_relative_rmse_threshold",
            REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
        ),
    ),
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        attempt.viability_report.thresholds,
    continue_on_error::Bool = true,
    window_callback = nothing,
)::ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult
    retry_policy.source_attempt === attempt || throw(
        ArgumentError(
            "Reduced MPCC window retry cascade rebuild requires retry_policy.source_attempt === attempt.",
        ),
    )
    window_runner === nothing && throw(
        ArgumentError(
            "Reduced MPCC window retry cascade rebuild requires a window_runner or model/reaction_map overload.",
        ),
    )
    policy = _reduced_mpcc_windowed_retry_replacement_validate_acceptance_policy(
        acceptance_policy,
    )
    continuation_policy = _reduced_mpcc_window_validate_continuation_policy(
        continuation_acceptance_policy,
    )
    state_threshold = _reduced_mpcc_window_validate_state_relative_rmse_threshold(
        continuation_state_relative_rmse_threshold,
    )

    source_comparisons = attempt.continuation_result.window_comparisons
    candidate_rows = _reduced_mpcc_windowed_retry_cascade_candidate_rows(
        attempt,
        retry_policy;
        acceptance_policy = policy,
    )
    chosen = _reduced_mpcc_windowed_retry_cascade_choose_candidate(candidate_rows)
    if chosen === nothing
        replacement_rows = _reduced_mpcc_windowed_retry_cascade_materialize_rows(
            candidate_rows,
            nothing,
        )
        replacement_table = _reduced_mpcc_windowed_retry_replacement_table(replacement_rows)
        metadata = _reduced_mpcc_windowed_retry_cascade_metadata(
            attempt,
            retry_policy,
            attempt,
            replacement_rows,
            Dict{Int, String}(),
            nothing;
            acceptance_policy = policy,
            continuation_acceptance_policy = continuation_policy,
            continuation_state_relative_rmse_threshold = state_threshold,
            stopped_by_error = false,
        )
        return ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult(
            attempt,
            retry_policy,
            attempt.continuation_result,
            attempt,
            replacement_table,
            _reduced_mpcc_windowed_retry_cascade_table(
                attempt.continuation_result.window_table,
                attempt.viability_report.viability_table,
                Dict{Int, String}(),
                nothing,
            ),
            metadata,
        )
    end

    chosen_index = Int(chosen["source_window_index"])
    target_horizon = _reduced_mpcc_windowed_retry_replacement_target_horizon(attempt)
    roles = Dict{Int, String}()
    rows = Dict{String, Any}[]
    comparisons = ReducedDCDFBAMPCCSequentialComparisonResult[]
    stopped_by_error = false

    for index in 1:(chosen_index - 1)
        comparison = source_comparisons[index]
        roles[index] = "source_prefix"
        push!(comparisons, comparison)
        push!(
            rows,
            _reduced_mpcc_window_completed_row(
                index,
                comparison;
                continuation_acceptance_policy = continuation_policy,
                continuation_state_relative_rmse_threshold = state_threshold,
            ),
        )
    end

    replacement_comparison = chosen["_replacement_comparison"]
    roles[chosen_index] = "retry_replacement"
    push!(comparisons, replacement_comparison)
    replacement_row = _reduced_mpcc_window_completed_row(
        chosen_index,
        replacement_comparison;
        continuation_acceptance_policy = continuation_policy,
        continuation_state_relative_rmse_threshold = state_threshold,
    )
    push!(rows, replacement_row)
    _reduced_mpcc_window_maybe_callback(
        window_callback,
        replacement_row,
        length(rows),
        length(source_comparisons),
    )

    current_y0 = copy(replacement_comparison.trajectory_candidate.boundary_result.states[:, end])
    if _reduced_mpcc_window_allows_continuation(replacement_row, replacement_comparison)
        for index in (chosen_index + 1):length(source_comparisons)
            spec = _reduced_mpcc_windowed_retry_cascade_source_spec(attempt, index)
            try
                comparison = window_runner(spec, current_y0)
                roles[index] = "downstream_resolve"
                push!(comparisons, comparison)
                row = _reduced_mpcc_window_completed_row(
                    index,
                    comparison;
                    continuation_acceptance_policy = continuation_policy,
                    continuation_state_relative_rmse_threshold = state_threshold,
                )
                push!(rows, row)
                _reduced_mpcc_window_maybe_callback(
                    window_callback,
                    row,
                    length(rows),
                    length(source_comparisons),
                )
                _reduced_mpcc_window_allows_continuation(row, comparison) || break
                current_y0 = copy(comparison.trajectory_candidate.boundary_result.states[:, end])
            catch err
                continue_on_error || rethrow()
                roles[index] = "downstream_failed"
                error_row = _reduced_mpcc_window_error_row(spec, err)
                push!(rows, error_row)
                _reduced_mpcc_window_maybe_callback(
                    window_callback,
                    error_row,
                    length(rows),
                    length(source_comparisons),
                )
                stopped_by_error = true
                break
            end
        end
    end

    rebuilt_continuation = _reduced_mpcc_window_result(
        rows,
        comparisons;
        sequential_reference = nothing,
        n_requested_windows = length(source_comparisons),
        window_hours = get(attempt.metadata, "window_hours", missing),
        nfe_per_window = get(attempt.metadata, "nfe_per_window", missing),
        degree = get(attempt.metadata, "degree", missing),
        ipopt_profile = get(attempt.metadata, "ipopt_profile", missing),
        linear_solver = get(attempt.metadata, "linear_solver", missing),
        complementarity_mode = get(attempt.metadata, "complementarity_mode", missing),
        complementarity_tau = get(attempt.metadata, "complementarity_tau", missing),
        tau_schedule = get(attempt.metadata, "tau_schedule", missing),
        reference_source = "cascade_rebuilt_window_reduced_sequential_dfba",
        continuation_acceptance_policy = continuation_policy,
        continuation_state_relative_rmse_threshold = state_threshold,
    )
    rebuilt_attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        rebuilt_continuation;
        target_horizon = target_horizon,
        thresholds = thresholds,
    )

    replacement_rows = _reduced_mpcc_windowed_retry_cascade_materialize_rows(
        candidate_rows,
        chosen,
    )
    replacement_table = _reduced_mpcc_windowed_retry_replacement_table(replacement_rows)
    cascade_table = _reduced_mpcc_windowed_retry_cascade_table(
        rebuilt_continuation.window_table,
        rebuilt_attempt.viability_report.viability_table,
        roles,
        chosen,
    )
    metadata = _reduced_mpcc_windowed_retry_cascade_metadata(
        attempt,
        retry_policy,
        rebuilt_attempt,
        replacement_rows,
        roles,
        chosen;
        acceptance_policy = policy,
        continuation_acceptance_policy = continuation_policy,
        continuation_state_relative_rmse_threshold = state_threshold,
        stopped_by_error = stopped_by_error,
    )
    return ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult(
        attempt,
        retry_policy,
        rebuilt_continuation,
        rebuilt_attempt,
        replacement_table,
        cascade_table,
        metadata,
    )
end

function _reduced_mpcc_windowed_retry_replacement_row(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry::ReducedDCDFBAMPCCWindowRetryDiagnosticResult;
    acceptance_policy::String,
    terminal_only::Bool,
)::Dict{String, Any}
    best = _reduced_mpcc_windowed_retry_replacement_best_row(retry)
    source_index = _reduced_mpcc_windowed_retry_replacement_source_index(retry, best)
    source_row = _reduced_mpcc_windowed_retry_replacement_source_row(attempt, source_index)
    source_window_id = get(
        retry.metadata,
        "source_window_id",
        source_index === missing ? missing : _reduced_mpcc_window_id(Int(source_index)),
    )
    n_windows = length(attempt.continuation_result.window_comparisons)
    index_valid = source_index !== missing && 1 <= Int(source_index) <= n_windows
    is_terminal = index_valid && Int(source_index) == n_windows
    accepted = best === nothing ? false :
               _reduced_mpcc_windowed_retry_replacement_accepts(best, acceptance_policy)
    comparison = best === nothing ? nothing :
                 _reduced_mpcc_windowed_retry_replacement_comparison(retry, best)

    applied = false
    reason = "retry_not_accepted_by_policy"
    if best === nothing
        reason = "missing_best_retry_row"
    elseif !index_valid
        reason = "source_window_index_out_of_range"
    elseif terminal_only && !is_terminal
        reason = "nonterminal_replacement_deferred"
    elseif !accepted
        reason = "retry_not_accepted_by_policy"
    elseif comparison === nothing
        reason = "missing_retry_comparison"
    else
        applied = true
        reason = "accepted_retry_replacement"
    end

    return Dict{String, Any}(
        "source_window_id" => source_window_id,
        "source_window_index" => source_index,
        "is_terminal_window" => is_terminal,
        "replacement_applied" => applied,
        "replacement_reason" => reason,
        "source_solver_status" =>
            _reduced_mpcc_windowed_retry_replacement_source_value(
                retry,
                source_row,
                "source_solver_status",
                "solver_status",
            ),
        "source_traffic_light" =>
            _reduced_mpcc_windowed_retry_replacement_source_value(
                retry,
                source_row,
                "source_traffic_light",
                "traffic_light",
            ),
        "source_trajectory_ready" =>
            _reduced_mpcc_windowed_retry_replacement_source_value(
                retry,
                source_row,
                "source_trajectory_ready",
                "trajectory_ready",
            ),
        "best_retry_case_id" =>
            _reduced_mpcc_windowed_retry_replacement_row_value(best, "retry_case_id"),
        "best_retry_ipopt_max_iter" =>
            _reduced_mpcc_windowed_retry_replacement_row_value(best, "ipopt_max_iter"),
        "best_retry_solver_status" =>
            _reduced_mpcc_windowed_retry_replacement_row_value(best, "solver_status"),
        "best_retry_traffic_light" =>
            _reduced_mpcc_windowed_retry_replacement_row_value(best, "traffic_light"),
        "best_retry_viability_class" =>
            _reduced_mpcc_windowed_retry_replacement_row_value(best, "viability_class"),
        "best_retry_residual_feasible" =>
            _reduced_mpcc_windowed_retry_replacement_row_value(best, "residual_feasible"),
        "best_retry_trajectory_ready" =>
            _reduced_mpcc_windowed_retry_replacement_row_value(best, "trajectory_ready"),
        "source_max_mass_balance_residual" =>
            _reduced_mpcc_windowed_retry_replacement_source_value(
                retry,
                source_row,
                "source_max_mass_balance_residual",
                "max_mass_balance_residual",
            ),
        "best_retry_max_mass_balance_residual" =>
            _reduced_mpcc_windowed_retry_replacement_row_value(
                best,
                "max_mass_balance_residual",
            ),
        "source_max_state_relative_rmse" =>
            _reduced_mpcc_windowed_retry_replacement_source_value(
                retry,
                source_row,
                "source_max_state_relative_rmse",
                "max_state_relative_rmse",
            ),
        "best_retry_max_state_relative_rmse" =>
            _reduced_mpcc_windowed_retry_replacement_row_value(
                best,
                "max_state_relative_rmse",
            ),
        "_replacement_comparison" => comparison,
    )
end

function _reduced_mpcc_windowed_retry_cascade_candidate_rows(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult;
    acceptance_policy::String,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    for retry in retry_policy.retry_results
        push!(
            rows,
            _reduced_mpcc_windowed_retry_replacement_row(
                attempt,
                retry;
                acceptance_policy = acceptance_policy,
                terminal_only = false,
            ),
        )
    end
    return rows
end

function _reduced_mpcc_windowed_retry_cascade_choose_candidate(rows::Vector{Dict{String, Any}})
    candidates = [
        row for row in rows if
        get(row, "replacement_applied", false) === true &&
        get(row, "_replacement_comparison", nothing) !== nothing &&
        _reduced_mpcc_windowed_retry_replacement_int_or_missing(
            get(row, "source_window_index", missing),
        ) !== missing
    ]
    isempty(candidates) && return nothing
    order = sortperm([
        Int(row["source_window_index"]) for row in candidates
    ])
    return candidates[first(order)]
end

function _reduced_mpcc_windowed_retry_cascade_materialize_rows(
    rows::Vector{Dict{String, Any}},
    chosen,
)::Vector{Dict{String, Any}}
    materialized = Dict{String, Any}[]
    chosen_index =
        chosen === nothing ? missing : Int(get(chosen, "source_window_index", missing))
    for row in rows
        copied = copy(row)
        delete!(copied, "_replacement_comparison")
        if get(copied, "replacement_applied", false) === true
            row_index = Int(copied["source_window_index"])
            if chosen_index === missing || row_index != chosen_index
                copied["replacement_applied"] = false
                copied["replacement_reason"] =
                    "later_retry_not_applied_in_single_cascade_rebuild"
            else
                copied["replacement_reason"] = "accepted_retry_cascade_replacement"
            end
        end
        push!(materialized, copied)
    end
    return materialized
end

function _reduced_mpcc_windowed_retry_cascade_source_spec(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    index::Int,
)
    comparisons = attempt.continuation_result.window_comparisons
    1 <= index <= length(comparisons) || throw(
        ArgumentError(
            "Reduced MPCC retry cascade requested downstream window $(index), outside available comparisons.",
        ),
    )
    comparison = comparisons[index]
    t0 = Float64(first(comparison.sequential_result.time))
    tfinal = Float64(last(comparison.sequential_result.time))
    window_hours = tfinal - t0
    row = _reduced_mpcc_windowed_retry_replacement_source_row(attempt, index)
    inferred_nfe = max(length(comparison.sequential_result.time) - 1, 1)
    nfe = _reduced_mpcc_windowed_retry_replacement_int_or_missing(
        row === nothing ? missing : get(row, "nfe", missing),
    )
    degree = _reduced_mpcc_windowed_retry_replacement_int_or_missing(
        row === nothing ? missing : get(row, "degree", missing),
    )
    nfe = nfe === missing ? inferred_nfe : nfe
    degree = degree === missing ? 3 : degree
    nfe > 0 || throw(
        ArgumentError("Reduced MPCC retry cascade downstream nfe must be positive."),
    )
    degree == 3 || throw(
        ArgumentError("Reduced MPCC retry cascade currently supports only degree == 3."),
    )
    return (
        window_id = _reduced_mpcc_window_id(index),
        window_index = index,
        t0 = t0,
        tfinal = tfinal,
        window_hours = window_hours,
        nfe = nfe,
        degree = degree,
        boundary_dt = window_hours / nfe,
    )
end

function _reduced_mpcc_windowed_retry_cascade_table(
    window_table::DataFrame,
    viability_table::DataFrame,
    roles::Dict{Int, String},
    chosen,
)::DataFrame
    rows = Dict{String, Any}[]
    for row in eachrow(window_table)
        window_index = _reduced_mpcc_windowed_retry_replacement_int_or_missing(
            get(row, "window_index", missing),
        )
        candidate_id = get(row, "window_id", missing)
        viability_row =
            _reduced_mpcc_windowed_retry_cascade_viability_row(viability_table, candidate_id)
        role = window_index === missing ? missing :
               get(roles, Int(window_index), "source_unmodified")
        push!(
            rows,
            Dict{String, Any}(
                "window_id" => candidate_id,
                "window_index" => window_index,
                "cascade_role" => role,
                "window_status" => get(row, "window_status", missing),
                "t0" => get(row, "t0", missing),
                "tfinal" => get(row, "tfinal", missing),
                "solver_status" => get(row, "solver_status", missing),
                "traffic_light" =>
                    _reduced_mpcc_windowed_retry_cascade_row_value(
                        viability_row,
                        "traffic_light",
                    ),
                "viability_class" =>
                    _reduced_mpcc_windowed_retry_cascade_row_value(
                        viability_row,
                        "viability_class",
                    ),
                "candidate_residual_feasible" =>
                    get(row, "candidate_residual_feasible", missing),
                "candidate_trajectory_ready" =>
                    get(row, "candidate_trajectory_ready", missing),
                "candidate_allows_continuation" =>
                    get(row, "candidate_allows_continuation", missing),
                "replacement_applied" => role == "retry_replacement",
                "retry_case_id" =>
                    role == "retry_replacement" && chosen !== nothing ?
                    get(chosen, "best_retry_case_id", missing) : missing,
                "retry_ipopt_max_iter" =>
                    role == "retry_replacement" && chosen !== nothing ?
                    get(chosen, "best_retry_ipopt_max_iter", missing) : missing,
                "error_type" => get(row, "error_type", missing),
                "error_message" => get(row, "error_message", missing),
            ),
        )
    end
    return DataFrame(
        (
            column => [
                _reduced_mpcc_windowed_retry_replacement_table_scalar(
                    get(row, column, missing),
                ) for row in rows
            ] for column in REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_CASCADE_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_retry_cascade_metadata(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult,
    rebuilt_attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    replacement_rows::Vector{Dict{String, Any}},
    roles::Dict{Int, String},
    chosen;
    acceptance_policy::String,
    continuation_acceptance_policy::String,
    continuation_state_relative_rmse_threshold::Float64,
    stopped_by_error::Bool,
)::Dict{String, Any}
    base_light = String(get(attempt.metadata, "attempt_traffic_light", "red"))
    rebuilt_light = String(get(rebuilt_attempt.metadata, "attempt_traffic_light", base_light))
    replacement_applied = chosen !== nothing
    chosen_index = replacement_applied ? Int(chosen["source_window_index"]) : missing
    n_windows = length(attempt.continuation_result.window_comparisons)
    downstream_requested =
        chosen_index === missing ? 0 : max(n_windows - Int(chosen_index), 0)
    downstream_resolved = count(==("downstream_resolve"), values(roles))
    return Dict{String, Any}(
        "cascade_rebuild_type" =>
            REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_CASCADE_REBUILD_TYPE,
        "target_horizon" => get(attempt.metadata, "target_horizon", missing),
        "base_attempt_traffic_light" => base_light,
        "base_attempt_viable" => get(attempt.metadata, "attempt_viable", false) === true,
        "rebuilt_attempt_traffic_light" => rebuilt_light,
        "rebuilt_attempt_viable" =>
            get(rebuilt_attempt.metadata, "attempt_viable", false) === true,
        "rebuilt_horizon_reached" =>
            get(rebuilt_attempt.metadata, "horizon_reached", missing),
        "rebuilt_target_completed" =>
            get(rebuilt_attempt.metadata, "target_completed", missing),
        "improved_attempt_traffic_light" =>
            _reduced_mpcc_windowed_retry_replacement_light_rank(rebuilt_light) >
            _reduced_mpcc_windowed_retry_replacement_light_rank(base_light),
        "replacement_acceptance_policy" => acceptance_policy,
        "continuation_acceptance_policy" => continuation_acceptance_policy,
        "continuation_state_relative_rmse_threshold" =>
            continuation_state_relative_rmse_threshold,
        "n_replacement_candidates" => length(replacement_rows),
        "n_accepted_replacement_candidates" => count(
            row -> get(row, "replacement_applied", false) === true ||
                   get(row, "replacement_reason", "") ==
                   "later_retry_not_applied_in_single_cascade_rebuild",
            replacement_rows,
        ),
        "n_replacements_applied" => replacement_applied ? 1 : 0,
        "applied_window_indices" =>
            replacement_applied ? [Int(chosen_index)] : Int[],
        "cascade_replacement_window_index" => chosen_index,
        "cascade_replacement_window_id" =>
            replacement_applied ? get(chosen, "source_window_id", missing) : missing,
        "cascade_replacement_retry_case_id" =>
            replacement_applied ? get(chosen, "best_retry_case_id", missing) : missing,
        "cascade_replacement_retry_ipopt_max_iter" =>
            replacement_applied ? get(chosen, "best_retry_ipopt_max_iter", missing) : missing,
        "n_downstream_windows_requested" => downstream_requested,
        "n_downstream_windows_resolved" => downstream_resolved,
        "cascade_stopped_by_error" => stopped_by_error,
        "retry_replacement_applied" => replacement_applied,
        "cascade_rebuild_applied" => replacement_applied,
        "windowed_candidate_rebuilt" => replacement_applied,
        "retry_policy_diagnostic_type" =>
            get(retry_policy.metadata, "diagnostic_type", missing),
        "outputs_written" => false,
        "cascade_rebuild_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "recommended_next_action" =>
            _reduced_mpcc_windowed_retry_cascade_recommended_action(
                replacement_applied,
                rebuilt_light,
                stopped_by_error,
                downstream_requested,
                downstream_resolved,
            ),
        "interpretation_note" =>
            "Reduced MPCC retry cascade rebuild applies the earliest accepted retry and re-solves downstream reduced windows; this is not a validated scientific simulation.",
    )
end

function _reduced_mpcc_windowed_retry_cascade_recommended_action(
    replacement_applied::Bool,
    rebuilt_light::String,
    stopped_by_error::Bool,
    downstream_requested::Int,
    downstream_resolved::Int,
)::String
    replacement_applied || return "no_retry_replacement_candidates_available"
    stopped_by_error && return "inspect_failed_downstream_cascade_window"
    downstream_resolved < downstream_requested &&
        return "inspect_noncontinuable_downstream_cascade_window"
    rebuilt_light == "green" &&
        return "review_cascade_rebuilt_candidate_before_scientific_use"
    return "inspect_cascade_rebuilt_candidate_before_scaling"
end

function _reduced_mpcc_windowed_retry_cascade_viability_row(
    viability_table::DataFrame,
    candidate_id,
)
    candidate_id === missing && return nothing
    nrow(viability_table) == 0 && return nothing
    index = findfirst(==(String(candidate_id)), String.(viability_table[!, "candidate_id"]))
    return index === nothing ? nothing : viability_table[index, :]
end

function _reduced_mpcc_windowed_retry_cascade_row_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_retry_replacement_validate_acceptance_policy(
    policy::AbstractString,
)::String
    normalized = lowercase(strip(String(policy)))
    normalized in ("green", "green_or_trajectory_ready", "trajectory_ready") || throw(
        ArgumentError(
            "Reduced MPCC window retry replacement acceptance_policy must be one of " *
            "green, green_or_trajectory_ready, trajectory_ready.",
        ),
    )
    return normalized
end

function _reduced_mpcc_windowed_retry_replacement_accepts(row, policy::String)::Bool
    traffic_light = String(get(row, "traffic_light", ""))
    residual_feasible = get(row, "residual_feasible", false) === true
    trajectory_ready = get(row, "trajectory_ready", false) === true
    if policy == "green"
        return traffic_light == "green"
    elseif policy == "trajectory_ready"
        return residual_feasible && trajectory_ready
    else
        return traffic_light == "green" || (residual_feasible && trajectory_ready)
    end
end

function _reduced_mpcc_windowed_retry_replacement_best_row(
    retry::ReducedDCDFBAMPCCWindowRetryDiagnosticResult,
)
    table = retry.retry_table
    nrow(table) == 0 && return nothing
    case_id = get(retry.metadata, "best_retry_case_id", missing)
    if case_id !== missing
        index = findfirst(==(String(case_id)), String.(table[!, "retry_case_id"]))
        index === nothing || return table[index, :]
    end
    candidates = [
        row for row in eachrow(table) if
        String(get(row, "case_status", "completed")) != "failed"
    ]
    isempty(candidates) && return nothing
    order = sortperm([
        (
            get(row, "traffic_light", missing) == "green" ? 0 :
            get(row, "trajectory_ready", false) === true ? 1 :
            get(row, "residual_feasible", false) === true ? 2 : 3,
            _reduced_mpcc_windowed_retry_replacement_ratio_sort_value(
                get(row, "max_mass_balance_ratio", missing),
            ),
            _reduced_mpcc_windowed_retry_replacement_int_sort_value(
                get(row, "ipopt_max_iter", missing),
            ),
        ) for row in candidates
    ])
    return candidates[first(order)]
end

function _reduced_mpcc_windowed_retry_replacement_source_index(retry, best)
    for value in (
        best === nothing ? missing : get(best, "source_window_index", missing),
        get(retry.metadata, "source_window_index", missing),
    )
        parsed = _reduced_mpcc_windowed_retry_replacement_int_or_missing(value)
        parsed === missing || return parsed
    end
    return missing
end

function _reduced_mpcc_windowed_retry_replacement_source_row(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    source_index,
)
    source_index === missing && return nothing
    candidate_id = _reduced_mpcc_window_id(Int(source_index))
    table = attempt.viability_report.viability_table
    nrow(table) == 0 && return nothing
    index = findfirst(==(candidate_id), String.(table[!, "candidate_id"]))
    return index === nothing ? nothing : table[index, :]
end

function _reduced_mpcc_windowed_retry_replacement_comparison(
    retry::ReducedDCDFBAMPCCWindowRetryDiagnosticResult,
    best,
)
    case_id = get(best, "retry_case_id", missing)
    case_id === missing && return nothing
    completed_position = 0
    for row in eachrow(retry.retry_table)
        String(get(row, "case_status", "completed")) == "failed" && continue
        completed_position += 1
        String(get(row, "retry_case_id", "")) == String(case_id) || continue
        completed_position <= length(retry.retry_sweeps) || return nothing
        sweep = retry.retry_sweeps[completed_position]
        isempty(sweep.comparison_results) && return nothing
        return first(sweep.comparison_results)
    end
    return nothing
end

function _reduced_mpcc_windowed_retry_replacement_source_value(
    retry::ReducedDCDFBAMPCCWindowRetryDiagnosticResult,
    source_row,
    metadata_key::AbstractString,
    row_key::AbstractString,
)
    value = get(retry.metadata, String(metadata_key), missing)
    value === missing || return value
    source_row === nothing && return missing
    return get(source_row, String(row_key), missing)
end

function _reduced_mpcc_windowed_retry_replacement_row_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_retry_replacement_target_horizon(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
)::Float64
    value = get(attempt.metadata, "target_horizon", missing)
    value === missing && throw(
        ArgumentError(
            "Reduced MPCC window retry replacement requires source attempt target_horizon metadata.",
        ),
    )
    return _reduced_mpcc_windowed_attempt_target_horizon(Float64(value))
end

function _reduced_mpcc_windowed_retry_replacement_metadata(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult,
    rebuilt_attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    rows::Vector{Dict{String, Any}},
    applied_indices::Vector{Int};
    acceptance_policy::String,
    terminal_only::Bool,
    continuation_acceptance_policy::String,
    continuation_state_relative_rmse_threshold::Float64,
)::Dict{String, Any}
    base_light = String(get(attempt.metadata, "attempt_traffic_light", "red"))
    rebuilt_light = String(get(rebuilt_attempt.metadata, "attempt_traffic_light", base_light))
    replacement_applied = !isempty(applied_indices)
    return Dict{String, Any}(
        "replacement_type" => REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_REPLACEMENT_TYPE,
        "target_horizon" => get(attempt.metadata, "target_horizon", missing),
        "horizon_reached" => get(rebuilt_attempt.metadata, "horizon_reached", missing),
        "target_completed" => get(rebuilt_attempt.metadata, "target_completed", missing),
        "base_attempt_traffic_light" => base_light,
        "base_attempt_viable" => get(attempt.metadata, "attempt_viable", false) === true,
        "rebuilt_attempt_traffic_light" => rebuilt_light,
        "rebuilt_attempt_viable" =>
            get(rebuilt_attempt.metadata, "attempt_viable", false) === true,
        "rebuilt_horizon_reached" =>
            get(rebuilt_attempt.metadata, "horizon_reached", missing),
        "rebuilt_target_completed" =>
            get(rebuilt_attempt.metadata, "target_completed", missing),
        "improved_attempt_traffic_light" =>
            _reduced_mpcc_windowed_retry_replacement_light_rank(rebuilt_light) >
            _reduced_mpcc_windowed_retry_replacement_light_rank(base_light),
        "replacement_acceptance_policy" => acceptance_policy,
        "terminal_only" => terminal_only,
        "continuation_acceptance_policy" => continuation_acceptance_policy,
        "continuation_state_relative_rmse_threshold" =>
            continuation_state_relative_rmse_threshold,
        "n_replacement_candidates" => length(rows),
        "n_replacements_applied" => length(applied_indices),
        "applied_window_indices" => copy(applied_indices),
        "retry_replacement_applied" => replacement_applied,
        "windowed_candidate_rebuilt" => replacement_applied,
        "retry_policy_diagnostic_type" =>
            get(retry_policy.metadata, "diagnostic_type", missing),
        "outputs_written" => false,
        "replacement_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "recommended_next_action" =>
            _reduced_mpcc_windowed_retry_replacement_recommended_action(
                replacement_applied,
                rebuilt_light,
                rows,
            ),
        "interpretation_note" =>
            "Reduced MPCC retry replacements rebuild an in-memory reduced windowed candidate from accepted retry comparisons; this is not a validated scientific simulation.",
    )
end

function _reduced_mpcc_windowed_retry_replacement_recommended_action(
    replacement_applied::Bool,
    rebuilt_light::String,
    rows::Vector{Dict{String, Any}},
)::String
    if replacement_applied && rebuilt_light == "green"
        return "review_rebuilt_retry_replacement_candidate_before_scientific_use"
    elseif replacement_applied
        return "inspect_rebuilt_retry_replacement_candidate"
    elseif any(row -> get(row, "replacement_reason", "") == "nonterminal_replacement_deferred", rows)
        return "implement_retry_replacement_cascade_rebuild_for_nonterminal_windows"
    elseif !isempty(rows)
        return "inspect_nonapplied_retry_replacements"
    else
        return "no_retry_replacement_candidates_available"
    end
end

function _reduced_mpcc_windowed_retry_replacement_light_rank(light::AbstractString)::Int
    normalized = lowercase(String(light))
    normalized == "green" && return 3
    normalized == "yellow" && return 2
    normalized == "red" && return 1
    return 0
end

function _reduced_mpcc_windowed_retry_replacement_ratio_sort_value(value)::Float64
    _reduced_mpcc_retry_isfinite_number(value) || return Inf
    return Float64(value)
end

function _reduced_mpcc_windowed_retry_replacement_int_sort_value(value)::Int
    parsed = _reduced_mpcc_windowed_retry_replacement_int_or_missing(value)
    return parsed === missing ? typemax(Int) : parsed
end

function _reduced_mpcc_windowed_retry_replacement_int_or_missing(value)
    value === missing && return missing
    value === nothing && return missing
    return try
        Int(value)
    catch
        missing
    end
end

function _reduced_mpcc_windowed_retry_replacement_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_windowed_retry_replacement_table_scalar(
                    get(row, column, missing),
                ) for row in rows
            ] for column in REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_REPLACEMENT_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_retry_replacement_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
