import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_MESH_REFINEMENT_SENSITIVITY_TYPE =
    "reduced_dcdfba_mpcc_mesh_refinement_sensitivity"

const REDUCED_DCDFBA_MPCC_MESH_REFINEMENT_COLUMNS = [
    "mesh_case_id",
    "sweep_scenario_id",
    "scenario_status",
    "horizon",
    "nfe",
    "degree",
    "boundary_dt",
    "n_collocation_points",
    "solver_status",
    "primal_status",
    "solve_elapsed_seconds",
    "candidate_residual_feasible",
    "candidate_iteration_limit_residual_feasible",
    "candidate_trajectory_ready",
    "residual_thresholds_satisfied",
    "dominant_residual",
    "next_recommended_action",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_state_abs_difference",
    "max_state_rmse",
    "max_state_relative_rmse",
    "final_biomass_difference",
    "final_total_sugar_difference",
    "trajectory_ready_improved_vs_coarser_nfe",
    "state_relative_rmse_improved_vs_coarser_nfe",
    "coarser_nfe",
    "coarser_max_state_relative_rmse",
    "scientific_baseline",
    "full_dfba_cold_reference_deferred",
    "reduced_full_equivalence_claimed",
    "persistent_lp_baseline_used",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCMeshRefinementSensitivityResult

In-memory diagnostic result comparing reduced MPCC solve-attempt outcomes across
finite-element counts for fixed horizons. It is a mesh refinement diagnostic
only and does not change the formulation, solver, or scientific baseline.
"""
struct ReducedDCDFBAMPCCMeshRefinementSensitivityResult
    mesh_table::DataFrame
    sweep_result::ReducedDCDFBAMPCCSolveAttemptSweepResult
    metadata::Dict{String, Any}
end

"""
    sweep_reduced_dcdfba_mpcc_mesh_refinement(sweep_result)

Aggregate an already-computed reduced MPCC horizon/nfe sweep as a mesh
refinement sensitivity report.
"""
function sweep_reduced_dcdfba_mpcc_mesh_refinement(
    sweep_result::ReducedDCDFBAMPCCSolveAttemptSweepResult,
)::ReducedDCDFBAMPCCMeshRefinementSensitivityResult
    nrow(sweep_result.scenario_table) > 0 || throw(
        ArgumentError("Reduced MPCC mesh refinement sensitivity requires a nonempty sweep result."),
    )
    rows = _reduced_mpcc_mesh_rows(sweep_result)
    _reduced_mpcc_mesh_mark_improvements!(rows)
    table = _reduced_mpcc_mesh_table(rows)
    metadata = _reduced_mpcc_mesh_metadata(rows, sweep_result)
    return ReducedDCDFBAMPCCMeshRefinementSensitivityResult(table, sweep_result, metadata)
end

"""
    sweep_reduced_dcdfba_mpcc_mesh_refinement(model, reaction_map; horizons, nfe_values, kwargs...)

Run the reduced MPCC solve-attempt sweep for the requested horizons and finite
element counts, then summarize whether mesh refinement improves solver status,
residual feasibility, and state agreement against reduced sequential DFBA.
"""
function sweep_reduced_dcdfba_mpcc_mesh_refinement(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    horizons = [0.5],
    nfe_values = [1, 2],
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    silent::Bool = true,
    continue_on_error::Bool = true,
)::ReducedDCDFBAMPCCMeshRefinementSensitivityResult
    nfe_collection = collect(nfe_values)
    length(unique(Int.(nfe_collection))) >= 2 || throw(
        ArgumentError("Reduced MPCC mesh refinement sensitivity requires at least two distinct nfe values."),
    )
    sweep = sweep_reduced_dcdfba_mpcc_solve_attempts(
        model,
        reaction_map;
        horizons = horizons,
        nfe_values = nfe_values,
        degree = degree,
        y0 = y0,
        params = params,
        sequential_optimizer = sequential_optimizer,
        sequential_algorithm = sequential_algorithm,
        sequential_ode_abstol = sequential_ode_abstol,
        sequential_ode_reltol = sequential_ode_reltol,
        sequential_lp_atol = sequential_lp_atol,
        sequential_adaptive = sequential_adaptive,
        sequential_dt = sequential_dt,
        sequential_nonnegative = sequential_nonnegative,
        sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
        mpcc_optimizer = mpcc_optimizer,
        ipopt_max_iter = ipopt_max_iter,
        require_pre_solve_ready = require_pre_solve_ready,
        residual_thresholds = residual_thresholds,
        silent = silent,
        continue_on_error = continue_on_error,
    )
    return sweep_reduced_dcdfba_mpcc_mesh_refinement(sweep)
end

function _reduced_mpcc_mesh_rows(
    sweep::ReducedDCDFBAMPCCSolveAttemptSweepResult,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    for (index, row) in enumerate(eachrow(sweep.scenario_table))
        push!(
            rows,
            Dict{String, Any}(
                "mesh_case_id" => _reduced_mpcc_mesh_case_id(index),
                "sweep_scenario_id" => row["scenario_id"],
                "scenario_status" => row["scenario_status"],
                "horizon" => row["horizon"],
                "nfe" => row["nfe"],
                "degree" => row["degree"],
                "boundary_dt" => row["boundary_dt"],
                "n_collocation_points" => row["n_collocation_points"],
                "solver_status" => row["solver_status"],
                "primal_status" => row["primal_status"],
                "solve_elapsed_seconds" => row["solve_elapsed_seconds"],
                "candidate_residual_feasible" => row["candidate_residual_feasible"],
                "candidate_iteration_limit_residual_feasible" =>
                    row["candidate_iteration_limit_residual_feasible"],
                "candidate_trajectory_ready" => row["candidate_trajectory_ready"],
                "residual_thresholds_satisfied" => row["residual_thresholds_satisfied"],
                "dominant_residual" => row["dominant_residual"],
                "next_recommended_action" => row["next_recommended_action"],
                "max_rhs_residual" => row["max_rhs_residual"],
                "max_mass_balance_residual" => row["max_mass_balance_residual"],
                "max_lower_bound_violation" => row["max_lower_bound_violation"],
                "max_upper_bound_violation" => row["max_upper_bound_violation"],
                "max_stationarity_residual" => row["max_stationarity_residual"],
                "max_lower_complementarity_residual" =>
                    row["max_lower_complementarity_residual"],
                "max_upper_complementarity_residual" =>
                    row["max_upper_complementarity_residual"],
                "max_state_abs_difference" => row["max_state_abs_difference"],
                "max_state_rmse" => row["max_state_rmse"],
                "max_state_relative_rmse" => row["max_state_relative_rmse"],
                "final_biomass_difference" => row["final_biomass_difference"],
                "final_total_sugar_difference" => row["final_total_sugar_difference"],
                "trajectory_ready_improved_vs_coarser_nfe" => false,
                "state_relative_rmse_improved_vs_coarser_nfe" => false,
                "coarser_nfe" => missing,
                "coarser_max_state_relative_rmse" => missing,
                "scientific_baseline" => "full_dfba_cold_deferred",
                "full_dfba_cold_reference_deferred" =>
                    row["full_dfba_cold_reference_deferred"],
                "reduced_full_equivalence_claimed" => row["reduced_full_equivalence_claimed"],
                "persistent_lp_baseline_used" => row["persistent_lp_baseline_used"],
                "hsl_required" => false,
                "ma57_required" => false,
                "indices_reacciones_used" => row["indices_reacciones_used"],
                "r0001_used_as_oxygen" => row["r0001_used_as_oxygen"],
                "error_type" => row["error_type"],
                "error_message" => row["error_message"],
            ),
        )
    end
    return rows
end

function _reduced_mpcc_mesh_mark_improvements!(rows::Vector{Dict{String, Any}})
    groups = Dict{String, Vector{Dict{String, Any}}}()
    for row in rows
        push!(get!(groups, _reduced_mpcc_mesh_horizon_key(row), Dict{String, Any}[]), row)
    end
    for group_rows in values(groups)
        sort!(group_rows; by = row -> _reduced_mpcc_mesh_float_or_inf(get(row, "nfe", missing)))
        previous_ready = false
        previous_row = nothing
        for row in group_rows
            ready = row["candidate_trajectory_ready"] === true
            row["trajectory_ready_improved_vs_coarser_nfe"] =
                previous_row !== nothing && ready && !previous_ready
            if previous_row !== nothing
                row["coarser_nfe"] = previous_row["nfe"]
                row["coarser_max_state_relative_rmse"] = previous_row["max_state_relative_rmse"]
                if _reduced_mpcc_mesh_isfinite_number(row["max_state_relative_rmse"]) &&
                   _reduced_mpcc_mesh_isfinite_number(previous_row["max_state_relative_rmse"])
                    row["state_relative_rmse_improved_vs_coarser_nfe"] =
                        Float64(row["max_state_relative_rmse"]) <
                        Float64(previous_row["max_state_relative_rmse"])
                end
            end
            previous_ready |= ready
            previous_row = row
        end
    end
    return rows
end

function _reduced_mpcc_mesh_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_mesh_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_MESH_REFINEMENT_COLUMNS
        )...,
    )
end

function _reduced_mpcc_mesh_metadata(
    rows::Vector{Dict{String, Any}},
    sweep::ReducedDCDFBAMPCCSolveAttemptSweepResult,
)::Dict{String, Any}
    first_ready = _reduced_mpcc_mesh_first_ready_nfe_by_horizon(rows)
    best_nfe = _reduced_mpcc_mesh_best_nfe_by_horizon(rows)
    return Dict{String, Any}(
        "mesh_sensitivity_type" => REDUCED_DCDFBA_MPCC_MESH_REFINEMENT_SENSITIVITY_TYPE,
        "source_sweep_type" => get(sweep.metadata, "sweep_type", "unknown"),
        "n_rows" => length(rows),
        "n_completed_rows" => count(row -> get(row, "scenario_status", "") == "completed", rows),
        "n_failed_rows" => count(row -> get(row, "scenario_status", "") == "failed", rows),
        "n_horizons" => length(unique([_reduced_mpcc_mesh_horizon_key(row) for row in rows])),
        "nfe_values" => sort(unique([Int(row["nfe"]) for row in rows if _reduced_mpcc_mesh_isfinite_number(row["nfe"])])),
        "residual_feasible_row_count" =>
            count(row -> get(row, "candidate_residual_feasible", false) === true, rows),
        "trajectory_ready_row_count" =>
            count(row -> get(row, "candidate_trajectory_ready", false) === true, rows),
        "mesh_trajectory_ready_improvement_count" =>
            count(row -> get(row, "trajectory_ready_improved_vs_coarser_nfe", false) === true, rows),
        "mesh_state_relative_rmse_improvement_count" =>
            count(row -> get(row, "state_relative_rmse_improved_vs_coarser_nfe", false) === true, rows),
        "solver_status_counts" => _reduced_mpcc_mesh_value_counts(rows, "solver_status"),
        "recommended_action_counts" => _reduced_mpcc_mesh_value_counts(rows, "next_recommended_action"),
        "first_trajectory_ready_nfe_by_horizon" => first_ready,
        "best_state_match_nfe_by_horizon" => best_nfe,
        "horizons_with_trajectory_ready_count" => count(value -> value !== missing, values(first_ready)),
        "best_row_mesh_case_id" => _reduced_mpcc_mesh_best_row_value(rows, "mesh_case_id"),
        "best_row_horizon" => _reduced_mpcc_mesh_best_row_value(rows, "horizon"),
        "best_row_nfe" => _reduced_mpcc_mesh_best_row_value(rows, "nfe"),
        "best_row_max_state_relative_rmse" =>
            _reduced_mpcc_mesh_best_row_value(rows, "max_state_relative_rmse"),
        "outputs_written" => false,
        "mesh_sensitivity_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Mesh refinement sensitivity for reduced MPCC solve attempts; diagnostic only and not a solved scientific simulation.",
    )
end

function _reduced_mpcc_mesh_first_ready_nfe_by_horizon(rows::Vector{Dict{String, Any}})
    groups = _reduced_mpcc_mesh_rows_by_horizon(rows)
    result = Dict{String, Any}()
    for (horizon, group_rows) in groups
        ready = [
            row for row in group_rows if row["candidate_trajectory_ready"] === true &&
                                      _reduced_mpcc_mesh_isfinite_number(row["nfe"])
        ]
        result[horizon] = isempty(ready) ? missing : minimum(Int(row["nfe"]) for row in ready)
    end
    return result
end

function _reduced_mpcc_mesh_best_nfe_by_horizon(rows::Vector{Dict{String, Any}})
    groups = _reduced_mpcc_mesh_rows_by_horizon(rows)
    result = Dict{String, Any}()
    for (horizon, group_rows) in groups
        best = _reduced_mpcc_mesh_best_row(group_rows)
        result[horizon] = best === nothing ? missing : best["nfe"]
    end
    return result
end

function _reduced_mpcc_mesh_rows_by_horizon(rows::Vector{Dict{String, Any}})
    groups = Dict{String, Vector{Dict{String, Any}}}()
    for row in rows
        push!(get!(groups, _reduced_mpcc_mesh_horizon_key(row), Dict{String, Any}[]), row)
    end
    return groups
end

function _reduced_mpcc_mesh_best_row_value(rows::Vector{Dict{String, Any}}, key::AbstractString)
    best = _reduced_mpcc_mesh_best_row(rows)
    best === nothing && return missing
    return get(best, String(key), missing)
end

function _reduced_mpcc_mesh_best_row(rows::Vector{Dict{String, Any}})
    completed = [
        row for row in rows if get(row, "scenario_status", "") == "completed" &&
                               _reduced_mpcc_mesh_isfinite_number(get(row, "max_state_relative_rmse", missing))
    ]
    isempty(completed) && return nothing
    order = sortperm([
        (
            Float64(row["max_state_relative_rmse"]),
            Float64(get(row, "max_state_abs_difference", Inf)),
            Float64(get(row, "nfe", Inf)),
        ) for row in completed
    ])
    return completed[first(order)]
end

function _reduced_mpcc_mesh_horizon_key(row::Dict{String, Any})::String
    horizon = get(row, "horizon", missing)
    return "horizon=$(horizon)"
end

function _reduced_mpcc_mesh_case_id(index::Int)::String
    return "mesh_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_mesh_value_counts(rows::Vector{Dict{String, Any}}, key::AbstractString)
    counts = Dict{String, Int}()
    for row in rows
        value = get(row, String(key), missing)
        value === missing && continue
        label = string(value)
        counts[label] = get(counts, label, 0) + 1
    end
    return counts
end

function _reduced_mpcc_mesh_float_or_inf(value)::Float64
    _reduced_mpcc_mesh_isfinite_number(value) || return Inf
    return Float64(value)
end

function _reduced_mpcc_mesh_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_mesh_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
