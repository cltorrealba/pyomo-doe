import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_IPOPT_ITERATION_SENSITIVITY_TYPE =
    "reduced_dcdfba_mpcc_ipopt_iteration_sensitivity"

const REDUCED_DCDFBA_MPCC_IPOPT_ITERATION_SENSITIVITY_COLUMNS = [
    "iteration_case_id",
    "ipopt_max_iter",
    "sweep_scenario_id",
    "scenario_status",
    "horizon",
    "nfe",
    "degree",
    "boundary_dt",
    "n_collocation_points",
    "solver_status",
    "primal_status",
    "solve_elapsed_seconds",
    "candidate_residual_feasible",
    "candidate_iteration_limit_residual_feasible",
    "candidate_trajectory_ready",
    "residual_thresholds_satisfied",
    "dominant_residual",
    "next_recommended_action",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_state_abs_difference",
    "max_state_rmse",
    "max_state_relative_rmse",
    "final_biomass_difference",
    "final_total_sugar_difference",
    "trajectory_ready_improved_vs_previous_iter",
    "residual_feasible_improved_vs_previous_iter",
    "scientific_baseline",
    "full_dfba_cold_reference_deferred",
    "reduced_full_equivalence_claimed",
    "persistent_lp_baseline_used",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCIpoptIterationSensitivityResult

In-memory diagnostic result comparing reduced MPCC solve-attempt sweeps across
Ipopt `max_iter` settings. This does not change the MPCC formulation, add HSL,
write outputs, or claim a solved scientific trajectory.
"""
struct ReducedDCDFBAMPCCIpoptIterationSensitivityResult
    sensitivity_table::DataFrame
    sweep_results::Vector{ReducedDCDFBAMPCCSolveAttemptSweepResult}
    metadata::Dict{String, Any}
end

"""
    sweep_reduced_dcdfba_mpcc_ipopt_iterations(sweep_results; ipopt_max_iter_values)

Aggregate already-computed reduced MPCC horizon/nfe sweeps across Ipopt
iteration limits. This method is deterministic and is used by unit tests and
manual in-memory diagnostics.
"""
function sweep_reduced_dcdfba_mpcc_ipopt_iterations(
    sweep_results::AbstractVector{<:ReducedDCDFBAMPCCSolveAttemptSweepResult};
    ipopt_max_iter_values,
)::ReducedDCDFBAMPCCIpoptIterationSensitivityResult
    values = _reduced_mpcc_ipopt_iter_values(ipopt_max_iter_values)
    isempty(sweep_results) && throw(
        ArgumentError("Reduced MPCC Ipopt iteration sensitivity requires at least one sweep result."),
    )
    length(sweep_results) == length(values) || throw(
        ArgumentError(
            "Reduced MPCC Ipopt iteration sensitivity requires one sweep result per " *
            "ipopt_max_iter value. Got $(length(sweep_results)) sweeps and $(length(values)) iteration values.",
        ),
    )

    rows = Dict{String, Any}[]
    for (index, sweep) in enumerate(sweep_results)
        _reduced_mpcc_ipopt_iter_append_sweep_rows!(rows, sweep, values[index], index)
    end
    _reduced_mpcc_ipopt_iter_mark_improvements!(rows)
    table = _reduced_mpcc_ipopt_iter_table(rows)
    collected_sweeps = collect(sweep_results)
    metadata = _reduced_mpcc_ipopt_iter_metadata(rows, collected_sweeps, values)
    return ReducedDCDFBAMPCCIpoptIterationSensitivityResult(table, collected_sweeps, metadata)
end

"""
    sweep_reduced_dcdfba_mpcc_ipopt_iterations(model, reaction_map; ipopt_max_iter_values, kwargs...)

Run the same reduced MPCC horizon/nfe sweep for each requested Ipopt
`max_iter`, then aggregate solver status, residuals, and state mismatch. This
is a convergence diagnostic only.
"""
function sweep_reduced_dcdfba_mpcc_ipopt_iterations(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    ipopt_max_iter_values = [100, 200, 500, 1000],
    horizons = [0.25],
    nfe_values = [1],
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    silent::Bool = true,
    continue_on_error::Bool = true,
)::ReducedDCDFBAMPCCIpoptIterationSensitivityResult
    values = _reduced_mpcc_ipopt_iter_values(ipopt_max_iter_values)
    sweeps = ReducedDCDFBAMPCCSolveAttemptSweepResult[]
    for max_iter in values
        push!(
            sweeps,
            sweep_reduced_dcdfba_mpcc_solve_attempts(
                model,
                reaction_map;
                horizons = horizons,
                nfe_values = nfe_values,
                degree = degree,
                y0 = y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = max_iter,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                silent = silent,
                continue_on_error = continue_on_error,
            ),
        )
    end
    return sweep_reduced_dcdfba_mpcc_ipopt_iterations(
        sweeps;
        ipopt_max_iter_values = values,
    )
end

function _reduced_mpcc_ipopt_iter_values(values)::Vector{Int}
    collected = Int.(collect(values))
    isempty(collected) && throw(
        ArgumentError("Reduced MPCC Ipopt iteration sensitivity values must not be empty."),
    )
    all(value -> value >= 0, collected) || throw(
        ArgumentError("Reduced MPCC Ipopt iteration sensitivity values must be nonnegative."),
    )
    length(unique(collected)) == length(collected) || throw(
        ArgumentError("Reduced MPCC Ipopt iteration sensitivity values must be unique."),
    )
    return sort(collected)
end

function _reduced_mpcc_ipopt_iter_append_sweep_rows!(
    rows::Vector{Dict{String, Any}},
    sweep::ReducedDCDFBAMPCCSolveAttemptSweepResult,
    ipopt_max_iter::Int,
    iteration_index::Int,
)
    for row in eachrow(sweep.scenario_table)
        push!(
            rows,
            Dict{String, Any}(
                "iteration_case_id" =>
                    _reduced_mpcc_ipopt_iter_case_id(iteration_index, row["scenario_id"]),
                "ipopt_max_iter" => ipopt_max_iter,
                "sweep_scenario_id" => row["scenario_id"],
                "scenario_status" => row["scenario_status"],
                "horizon" => row["horizon"],
                "nfe" => row["nfe"],
                "degree" => row["degree"],
                "boundary_dt" => row["boundary_dt"],
                "n_collocation_points" => row["n_collocation_points"],
                "solver_status" => row["solver_status"],
                "primal_status" => row["primal_status"],
                "solve_elapsed_seconds" => row["solve_elapsed_seconds"],
                "candidate_residual_feasible" => row["candidate_residual_feasible"],
                "candidate_iteration_limit_residual_feasible" =>
                    row["candidate_iteration_limit_residual_feasible"],
                "candidate_trajectory_ready" => row["candidate_trajectory_ready"],
                "residual_thresholds_satisfied" => row["residual_thresholds_satisfied"],
                "dominant_residual" => row["dominant_residual"],
                "next_recommended_action" => row["next_recommended_action"],
                "max_rhs_residual" => row["max_rhs_residual"],
                "max_mass_balance_residual" => row["max_mass_balance_residual"],
                "max_lower_bound_violation" => row["max_lower_bound_violation"],
                "max_upper_bound_violation" => row["max_upper_bound_violation"],
                "max_stationarity_residual" => row["max_stationarity_residual"],
                "max_lower_complementarity_residual" =>
                    row["max_lower_complementarity_residual"],
                "max_upper_complementarity_residual" =>
                    row["max_upper_complementarity_residual"],
                "max_state_abs_difference" => row["max_state_abs_difference"],
                "max_state_rmse" => row["max_state_rmse"],
                "max_state_relative_rmse" => row["max_state_relative_rmse"],
                "final_biomass_difference" => row["final_biomass_difference"],
                "final_total_sugar_difference" => row["final_total_sugar_difference"],
                "trajectory_ready_improved_vs_previous_iter" => false,
                "residual_feasible_improved_vs_previous_iter" => false,
                "scientific_baseline" => "full_dfba_cold_deferred",
                "full_dfba_cold_reference_deferred" =>
                    row["full_dfba_cold_reference_deferred"],
                "reduced_full_equivalence_claimed" => row["reduced_full_equivalence_claimed"],
                "persistent_lp_baseline_used" => row["persistent_lp_baseline_used"],
                "hsl_required" => false,
                "ma57_required" => false,
                "indices_reacciones_used" => row["indices_reacciones_used"],
                "r0001_used_as_oxygen" => row["r0001_used_as_oxygen"],
                "error_type" => row["error_type"],
                "error_message" => row["error_message"],
            ),
        )
    end
    return rows
end

function _reduced_mpcc_ipopt_iter_mark_improvements!(rows::Vector{Dict{String, Any}})
    groups = Dict{String, Vector{Dict{String, Any}}}()
    for row in rows
        key = _reduced_mpcc_ipopt_iter_scenario_key(row)
        push!(get!(groups, key, Dict{String, Any}[]), row)
    end
    for group_rows in values(groups)
        sort!(group_rows; by = row -> Int(row["ipopt_max_iter"]))
        previous_trajectory_ready = false
        previous_residual_feasible = false
        for row in group_rows
            trajectory_ready = row["candidate_trajectory_ready"] === true
            residual_feasible = row["candidate_residual_feasible"] === true
            row["trajectory_ready_improved_vs_previous_iter"] =
                trajectory_ready && !previous_trajectory_ready
            row["residual_feasible_improved_vs_previous_iter"] =
                residual_feasible && !previous_residual_feasible
            previous_trajectory_ready |= trajectory_ready
            previous_residual_feasible |= residual_feasible
        end
    end
    return rows
end

function _reduced_mpcc_ipopt_iter_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_ipopt_iter_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_IPOPT_ITERATION_SENSITIVITY_COLUMNS
        )...,
    )
end

function _reduced_mpcc_ipopt_iter_metadata(
    rows::Vector{Dict{String, Any}},
    sweeps::Vector{ReducedDCDFBAMPCCSolveAttemptSweepResult},
    ipopt_max_iter_values::Vector{Int},
)::Dict{String, Any}
    first_ready = _reduced_mpcc_ipopt_iter_first_ready_by_scenario(rows)
    return Dict{String, Any}(
        "sensitivity_type" => REDUCED_DCDFBA_MPCC_IPOPT_ITERATION_SENSITIVITY_TYPE,
        "ipopt_max_iter_values" => copy(ipopt_max_iter_values),
        "n_ipopt_max_iter_values" => length(ipopt_max_iter_values),
        "n_sweep_results" => length(sweeps),
        "n_rows" => length(rows),
        "n_completed_rows" => count(row -> get(row, "scenario_status", "") == "completed", rows),
        "n_failed_rows" => count(row -> get(row, "scenario_status", "") == "failed", rows),
        "residual_feasible_row_count" =>
            count(row -> get(row, "candidate_residual_feasible", false) === true, rows),
        "trajectory_ready_row_count" =>
            count(row -> get(row, "candidate_trajectory_ready", false) === true, rows),
        "iteration_limit_residual_feasible_row_count" => count(
            row -> get(row, "candidate_iteration_limit_residual_feasible", false) === true,
            rows,
        ),
        "solver_status_counts" => _reduced_mpcc_ipopt_iter_value_counts(rows, "solver_status"),
        "recommended_action_counts" =>
            _reduced_mpcc_ipopt_iter_value_counts(rows, "next_recommended_action"),
        "first_trajectory_ready_ipopt_max_iter_by_scenario" => first_ready,
        "scenarios_with_trajectory_ready_count" =>
            count(value -> value !== missing, values(first_ready)),
        "best_row_iteration_case_id" =>
            _reduced_mpcc_ipopt_iter_best_row_value(rows, "iteration_case_id"),
        "best_row_ipopt_max_iter" =>
            _reduced_mpcc_ipopt_iter_best_row_value(rows, "ipopt_max_iter"),
        "best_row_max_state_relative_rmse" =>
            _reduced_mpcc_ipopt_iter_best_row_value(rows, "max_state_relative_rmse"),
        "outputs_written" => false,
        "sensitivity_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Ipopt max_iter sensitivity for reduced MPCC solve attempts; diagnostic only and not a solved scientific simulation.",
    )
end

function _reduced_mpcc_ipopt_iter_first_ready_by_scenario(rows::Vector{Dict{String, Any}})
    groups = Dict{String, Vector{Dict{String, Any}}}()
    for row in rows
        key = _reduced_mpcc_ipopt_iter_scenario_key(row)
        push!(get!(groups, key, Dict{String, Any}[]), row)
    end
    first_ready = Dict{String, Any}()
    for (key, group_rows) in groups
        ready_rows = [
            row for row in group_rows if row["candidate_trajectory_ready"] === true &&
                                      _reduced_mpcc_ipopt_iter_isfinite_number(row["ipopt_max_iter"])
        ]
        if isempty(ready_rows)
            first_ready[key] = missing
        else
            first_ready[key] = minimum(Int(row["ipopt_max_iter"]) for row in ready_rows)
        end
    end
    return first_ready
end

function _reduced_mpcc_ipopt_iter_best_row_value(rows::Vector{Dict{String, Any}}, key::AbstractString)
    best = _reduced_mpcc_ipopt_iter_best_row(rows)
    best === nothing && return missing
    return get(best, String(key), missing)
end

function _reduced_mpcc_ipopt_iter_best_row(rows::Vector{Dict{String, Any}})
    completed = [
        row for row in rows if get(row, "scenario_status", "") == "completed" &&
                               _reduced_mpcc_ipopt_iter_isfinite_number(get(row, "max_state_relative_rmse", missing))
    ]
    isempty(completed) && return nothing
    order = sortperm([
        (
            Float64(row["max_state_relative_rmse"]),
            Float64(get(row, "max_state_abs_difference", Inf)),
            Float64(get(row, "ipopt_max_iter", Inf)),
        ) for row in completed
    ])
    return completed[first(order)]
end

function _reduced_mpcc_ipopt_iter_scenario_key(row::Dict{String, Any})::String
    horizon = get(row, "horizon", missing)
    nfe = get(row, "nfe", missing)
    return "horizon=$(horizon);nfe=$(nfe)"
end

function _reduced_mpcc_ipopt_iter_case_id(iteration_index::Int, scenario_id)::String
    return "iter_" * lpad(string(iteration_index), 3, '0') * "_" * string(scenario_id)
end

function _reduced_mpcc_ipopt_iter_value_counts(rows::Vector{Dict{String, Any}}, key::AbstractString)
    counts = Dict{String, Int}()
    for row in rows
        value = get(row, String(key), missing)
        value === missing && continue
        label = string(value)
        counts[label] = get(counts, label, 0) + 1
    end
    return counts
end

function _reduced_mpcc_ipopt_iter_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_ipopt_iter_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
