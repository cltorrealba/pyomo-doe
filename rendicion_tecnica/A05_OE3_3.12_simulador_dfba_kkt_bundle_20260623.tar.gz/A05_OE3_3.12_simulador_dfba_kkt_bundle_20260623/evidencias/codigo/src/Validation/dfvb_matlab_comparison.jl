import HiGHS
import OrdinaryDiffEq

const DFVB_MATLAB_COMPARISON_TYPE = "julia_dfvb_vs_matlab_dfvb_baseline"
const DFVB_MATLAB_ALIGNMENT_LINEAR = "linear_interpolation_to_julia_times"
const DFVB_MATLAB_INTERPRETATION_NOTE =
    "This is a short diagnostic state comparison. MATLAB baseline and Julia DFVB trajectories may differ because of solver settings, time integration, LP degeneracy, active-set changes, artifact semantics, and implementation details. This is not a biological equivalence claim. Alpha and flux comparison are excluded by default."
const DFVB_MATLAB_OXYGEN_NOTE =
    "oxygen is forced zero in Julia DFVB; MATLAB baseline oxygen is numerical near-zero; r_0001 is not oxygen and oxygen remains r_1992"
const DFVB_MATLAB_CARBOHYDRATE_NOTE =
    "carbohydrate dy[8] remains empirical and is not driven by r_4048"
const DFVB_MATLAB_STATE_ONLY_NOTE =
    "state-only comparison; alpha and flux trajectories are not compared"

const DFVB_MATLAB_STATE_METRIC_COLUMNS = [
    "state_name",
    "initial_julia",
    "initial_matlab_aligned",
    "final_julia",
    "final_matlab_aligned",
    "final_difference_julia_minus_matlab",
    "max_abs_difference",
    "rmse",
    "relative_rmse",
    "julia_min",
    "julia_max",
    "matlab_aligned_min",
    "matlab_aligned_max",
    "notes",
]

const DFVB_MATLAB_SUMMARY_COLUMNS = [
    "source",
    "model_scope",
    "retcode",
    "initial_time",
    "final_time",
    "n_time_points",
    "n_states",
    "n_alphas",
    "initial_biomass",
    "final_biomass",
    "initial_glucose",
    "final_glucose",
    "initial_fructose",
    "final_fructose",
    "initial_total_sugar",
    "final_total_sugar",
    "initial_ethanol",
    "final_ethanol",
    "final_oxygen",
    "simulation_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
    "alpha_scope",
]

"""
    DFVBMatlabComparisonResult

State-only diagnostic comparison between a Julia sequential DFVB smoke
simulation and exported MATLAB DFVB baseline state trajectories. MATLAB states
are aligned to Julia saved times before metrics are computed. Alpha and flux
trajectories are intentionally not compared by this report type.
"""
struct DFVBMatlabComparisonResult
    julia_result::SimulationResult
    baseline_report::DFVBBaselineReport
    aligned_state_timeseries::DataFrame
    state_metrics::DataFrame
    summary_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    compare_dfvb_to_matlab_baseline(model, reaction_map, artifacts; kwargs...)

Run a short Julia sequential DFVB simulation, align exported MATLAB DFVB
baseline states to the Julia saved time grid, and compute state-only trajectory
metrics. This report does not compare alpha trajectories or flux histories.
"""
function compare_dfvb_to_matlab_baseline(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    artifacts::DFVBArtifacts;
    tspan::Tuple{Float64, Float64} = (0.0, 0.25),
    saveat = 0.25,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    algorithm = OrdinaryDiffEq.Tsit5(),
    use_active_alpha::Bool = true,
    reconstruct_alphas::Bool = true,
    reconstruct_fluxes::Bool = false,
    alignment_policy::AbstractString = DFVB_MATLAB_ALIGNMENT_LINEAR,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
)::DFVBMatlabComparisonResult
    baseline_report = build_dfvb_baseline_report(
        artifacts;
        include_full_alpha_summary = false,
        include_active_alpha_summary = false,
    )
    julia_result = simulate_dfvb(
        model,
        reaction_map,
        artifacts;
        y0 = y0,
        tspan = tspan,
        saveat = saveat,
        algorithm = algorithm,
        use_active_alpha = use_active_alpha,
        reconstruct_alphas = reconstruct_alphas,
        reconstruct_fluxes = reconstruct_fluxes,
        optimizer = optimizer,
        silent = silent,
        lp_atol = lp_atol,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
    )

    return _dfvb_matlab_comparison_from_results(
        julia_result,
        baseline_report;
        alignment_policy = alignment_policy,
        julia_tspan = tspan,
        julia_saveat = saveat,
        julia_algorithm_label = _dfvb_matlab_algorithm_label(algorithm),
        julia_reconstruct_alphas = reconstruct_alphas,
        julia_reconstruct_fluxes = reconstruct_fluxes,
        lp_atol = lp_atol,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
    )
end

"""
    export_dfvb_matlab_comparison(comparison, output_dir; overwrite=false)

Write CSV/TOML artifacts for a Julia-vs-MATLAB DFVB state trajectory
comparison. Only known target files are overwritten when `overwrite=true`.
"""
function export_dfvb_matlab_comparison(
    comparison::DFVBMatlabComparisonResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("DFVB MATLAB comparison output_dir exists and is not a directory: $output_path")
    end

    paths = Dict{String, String}(
        "summary" => joinpath(output_path, "dfvb_matlab_comparison_summary.csv"),
        "state_metrics" => joinpath(output_path, "dfvb_matlab_state_metrics.csv"),
        "aligned_timeseries" => joinpath(output_path, "dfvb_matlab_aligned_timeseries.csv"),
        "metadata" => joinpath(output_path, "dfvb_matlab_comparison_metadata.toml"),
    )
    existing_targets = [path for path in values(paths) if isfile(path)]
    if !overwrite && !isempty(existing_targets)
        error(
            "DFVB MATLAB comparison target file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end

    mkpath(output_path)
    if overwrite
        for path in values(paths)
            isfile(path) && rm(path)
        end
    end

    CSV.write(paths["summary"], comparison.summary_table)
    CSV.write(paths["state_metrics"], comparison.state_metrics)
    CSV.write(paths["aligned_timeseries"], comparison.aligned_state_timeseries)
    open(paths["metadata"], "w") do io
        TOML.print(io, _dfvb_matlab_toml_normalize(comparison.metadata))
    end
    return paths
end

function _dfvb_matlab_comparison_from_results(
    julia_result::SimulationResult,
    baseline_report::DFVBBaselineReport;
    alignment_policy::AbstractString = DFVB_MATLAB_ALIGNMENT_LINEAR,
    julia_tspan = (julia_result.time[begin], julia_result.time[end]),
    julia_saveat = length(julia_result.time) > 1 ? julia_result.time[2] - julia_result.time[1] : missing,
    julia_algorithm_label::AbstractString = String(get(julia_result.metadata, "algorithm", "unknown")),
    julia_reconstruct_alphas::Bool = get(julia_result.metadata, "reconstruct_alphas", false),
    julia_reconstruct_fluxes::Bool = get(julia_result.metadata, "reconstruct_fluxes", false),
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
)::DFVBMatlabComparisonResult
    normalized_policy = String(alignment_policy)
    normalized_policy == DFVB_MATLAB_ALIGNMENT_LINEAR || error(
        "Unsupported DFVB MATLAB comparison alignment_policy: $alignment_policy. " *
        "Only $DFVB_MATLAB_ALIGNMENT_LINEAR is currently implemented.",
    )

    state_names = _dfvb_matlab_state_names(julia_result, baseline_report)
    baseline_times = _dfvb_baseline_time_vector(baseline_report.state_timeseries, "state_trajectories")
    aligned_baseline = _interpolate_baseline_states_to_times(
        baseline_times,
        baseline_report.state_timeseries,
        julia_result.time,
        state_names,
    )
    aligned_state_timeseries = _dfvb_matlab_aligned_state_timeseries(
        julia_result,
        aligned_baseline,
        state_names,
    )
    state_metrics = _dfvb_matlab_state_metrics_table(julia_result, aligned_baseline, state_names)
    summary_table = _dfvb_matlab_summary_table(julia_result, aligned_baseline, baseline_report, state_names)
    metadata = _dfvb_matlab_comparison_metadata(
        julia_result,
        baseline_report,
        state_names,
        baseline_times;
        alignment_policy = normalized_policy,
        julia_tspan = julia_tspan,
        julia_saveat = julia_saveat,
        julia_algorithm_label = julia_algorithm_label,
        julia_reconstruct_alphas = julia_reconstruct_alphas,
        julia_reconstruct_fluxes = julia_reconstruct_fluxes,
        lp_atol = lp_atol,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
    )

    return DFVBMatlabComparisonResult(
        julia_result,
        baseline_report,
        aligned_state_timeseries,
        state_metrics,
        summary_table,
        metadata,
    )
end

function _interpolate_baseline_states_to_times(
    baseline_times::AbstractVector,
    baseline_states::DataFrame,
    target_times::AbstractVector,
    state_names::Vector{String},
)::DataFrame
    source_time = _dfvb_matlab_numeric_vector(baseline_times, "baseline_times")
    target_time = _dfvb_matlab_numeric_vector(target_times, "target_times")
    isempty(source_time) && error("DFVB MATLAB comparison baseline time grid must not be empty.")
    all(isfinite, source_time) || error("DFVB MATLAB comparison baseline time grid must be finite.")
    all(isfinite, target_time) || error("DFVB MATLAB comparison target time grid must be finite.")
    length(source_time) == nrow(baseline_states) || error(
        "DFVB MATLAB comparison baseline time length $(length(source_time)) does not match " *
        "baseline state row count $(nrow(baseline_states)).",
    )
    _dfvb_matlab_assert_strictly_increasing(source_time)
    _dfvb_matlab_assert_target_times_in_range(source_time, target_time)

    table = DataFrame("time" => copy(target_time))
    for state_name in state_names
        state_name in names(baseline_states) || error(
            "DFVB MATLAB comparison baseline states are missing state column $(String(state_name)).",
        )
        values = _dfvb_matlab_numeric_vector(baseline_states[!, state_name], "baseline_states.$state_name")
        table[!, state_name] = [
            _dfvb_matlab_linear_interpolate(source_time, values, target) for target in target_time
        ]
    end
    return table
end

function _dfvb_matlab_state_names(
    julia_result::SimulationResult,
    baseline_report::DFVBBaselineReport,
)::Vector{String}
    julia_state_names = _state_names(julia_result)
    length(julia_state_names) == 19 || error(
        "DFVB MATLAB comparison expects Julia DFVB result to have 19 state names, got $(length(julia_state_names)).",
    )
    size(julia_result.states, 1) == length(julia_state_names) || error(
        "DFVB MATLAB comparison Julia state row count $(size(julia_result.states, 1)) does not match " *
        "$(length(julia_state_names)) state names.",
    )
    size(julia_result.states, 2) == length(julia_result.time) || error(
        "DFVB MATLAB comparison Julia states must be n_states x n_time.",
    )

    baseline_names = String.(setdiff(names(baseline_report.state_timeseries), ["time"]))
    missing_baseline = setdiff(julia_state_names, baseline_names)
    isempty(missing_baseline) || error(
        "DFVB MATLAB comparison baseline states are missing Julia state names: $(join(missing_baseline, ", ")).",
    )
    return julia_state_names
end

function _dfvb_matlab_aligned_state_timeseries(
    julia_result::SimulationResult,
    aligned_baseline::DataFrame,
    state_names::Vector{String},
)::DataFrame
    table = DataFrame("time" => copy(julia_result.time))
    for (i, state_name) in enumerate(state_names)
        julia_values = collect(view(julia_result.states, i, :))
        matlab_values = _dfvb_matlab_numeric_vector(aligned_baseline[!, state_name], "aligned_baseline.$state_name")
        prefix = lowercase(String(state_name))
        table[!, "$(prefix)_julia"] = julia_values
        table[!, "$(prefix)_matlab"] = matlab_values
        table[!, "$(prefix)_difference_julia_minus_matlab"] = julia_values .- matlab_values
    end
    return table
end

function _dfvb_matlab_state_metrics_table(
    julia_result::SimulationResult,
    aligned_baseline::DataFrame,
    state_names::Vector{String},
)::DataFrame
    rows = [
        _dfvb_matlab_state_metric_row(
            state_name,
            view(julia_result.states, i, :),
            aligned_baseline[!, state_name],
        ) for (i, state_name) in enumerate(state_names)
    ]
    return DataFrame(
        (
            column => [_dfvb_matlab_table_scalar(get(row, column, missing)) for row in rows] for
            column in DFVB_MATLAB_STATE_METRIC_COLUMNS
        )...,
    )
end

function _dfvb_matlab_state_metric_row(
    state_name::AbstractString,
    julia_values,
    matlab_values,
)::Dict{String, Any}
    julia = Float64.(collect(julia_values))
    matlab = _dfvb_matlab_numeric_vector(matlab_values, "aligned_baseline.$state_name")
    length(julia) == length(matlab) || error(
        "DFVB MATLAB comparison state $(String(state_name)) has mismatched Julia/MATLAB lengths.",
    )
    difference = julia .- matlab
    rmse = sqrt(sum(abs2, difference) / length(difference))
    denominator = max(maximum(abs.(julia)), maximum(abs.(matlab)), eps(Float64))
    relative_rmse = rmse / denominator

    return Dict{String, Any}(
        "state_name" => String(state_name),
        "initial_julia" => julia[begin],
        "initial_matlab_aligned" => matlab[begin],
        "final_julia" => julia[end],
        "final_matlab_aligned" => matlab[end],
        "final_difference_julia_minus_matlab" => difference[end],
        "max_abs_difference" => maximum(abs.(difference)),
        "rmse" => rmse,
        "relative_rmse" => relative_rmse,
        "julia_min" => minimum(julia),
        "julia_max" => maximum(julia),
        "matlab_aligned_min" => minimum(matlab),
        "matlab_aligned_max" => maximum(matlab),
        "notes" => _dfvb_matlab_state_note(state_name),
    )
end

function _dfvb_matlab_summary_table(
    julia_result::SimulationResult,
    aligned_baseline::DataFrame,
    baseline_report::DFVBBaselineReport,
    state_names::Vector{String},
)::DataFrame
    rows = [
        _dfvb_matlab_julia_summary_row(julia_result),
        _dfvb_matlab_baseline_summary_row(aligned_baseline, baseline_report, state_names),
    ]
    return DataFrame(
        (
            column => [_dfvb_matlab_table_scalar(get(row, column, missing)) for row in rows] for
            column in DFVB_MATLAB_SUMMARY_COLUMNS
        )...,
    )
end

function _dfvb_matlab_julia_summary_row(result::SimulationResult)::Dict{String, Any}
    summary = summarize_simulation(result)
    return Dict{String, Any}(
        "source" => "julia_dfvb",
        "model_scope" => get(summary, "model_scope", "dfvb"),
        "retcode" => get(summary, "retcode", missing),
        "initial_time" => get(summary, "initial_time", missing),
        "final_time" => get(summary, "final_time", missing),
        "n_time_points" => get(summary, "n_saved_points", missing),
        "n_states" => get(summary, "n_states", missing),
        "n_alphas" => get(summary, "n_alphas", missing),
        "initial_biomass" => get(summary, "initial_biomass", missing),
        "final_biomass" => get(summary, "final_biomass", missing),
        "initial_glucose" => get(summary, "initial_glucose", missing),
        "final_glucose" => get(summary, "final_glucose", missing),
        "initial_fructose" => get(summary, "initial_fructose", missing),
        "final_fructose" => get(summary, "final_fructose", missing),
        "initial_total_sugar" => get(summary, "initial_total_sugar", missing),
        "final_total_sugar" => get(summary, "final_total_sugar", missing),
        "initial_ethanol" => get(summary, "initial_ethanol", missing),
        "final_ethanol" => get(summary, "final_ethanol", missing),
        "final_oxygen" => get(summary, "final_oxygen", missing),
        "simulation_elapsed_seconds" => get(summary, "simulation_elapsed_seconds", missing),
        "rhs_call_count" => get(summary, "rhs_call_count", missing),
        "total_lp_solve_count" => get(summary, "total_lp_solve_count", missing),
        "alpha_scope" => get(summary, "alpha_scope", missing),
    )
end

function _dfvb_matlab_baseline_summary_row(
    aligned_baseline::DataFrame,
    baseline_report::DFVBBaselineReport,
    state_names::Vector{String},
)::Dict{String, Any}
    state_value(name, row) = Float64(aligned_baseline[row, name])
    initial_index = firstindex(aligned_baseline[!, "time"])
    final_index = lastindex(aligned_baseline[!, "time"])
    initial_glucose = state_value("glucose", initial_index)
    final_glucose = state_value("glucose", final_index)
    initial_fructose = state_value("fructose", initial_index)
    final_fructose = state_value("fructose", final_index)

    return Dict{String, Any}(
        "source" => "matlab_dfvb_baseline",
        "model_scope" => "matlab_dfvb_baseline",
        "retcode" => "artifact",
        "initial_time" => aligned_baseline[initial_index, "time"],
        "final_time" => aligned_baseline[final_index, "time"],
        "n_time_points" => nrow(aligned_baseline),
        "n_states" => length(state_names),
        "n_alphas" => get(baseline_report.metadata, "n_active_alphas", missing),
        "initial_biomass" => state_value("biomass", initial_index),
        "final_biomass" => state_value("biomass", final_index),
        "initial_glucose" => initial_glucose,
        "final_glucose" => final_glucose,
        "initial_fructose" => initial_fructose,
        "final_fructose" => final_fructose,
        "initial_total_sugar" => initial_glucose + initial_fructose,
        "final_total_sugar" => final_glucose + final_fructose,
        "initial_ethanol" => state_value("ethanol", initial_index),
        "final_ethanol" => state_value("ethanol", final_index),
        "final_oxygen" => state_value("oxygen", final_index),
        "simulation_elapsed_seconds" => missing,
        "rhs_call_count" => missing,
        "total_lp_solve_count" => missing,
        "alpha_scope" => "not_compared",
    )
end

function _dfvb_matlab_comparison_metadata(
    julia_result::SimulationResult,
    baseline_report::DFVBBaselineReport,
    state_names::Vector{String},
    baseline_times::Vector{Float64};
    alignment_policy::AbstractString,
    julia_tspan,
    julia_saveat,
    julia_algorithm_label::AbstractString,
    julia_reconstruct_alphas::Bool,
    julia_reconstruct_fluxes::Bool,
    lp_atol::Real,
    ode_abstol::Real,
    ode_reltol::Real,
)::Dict{String, Any}
    return Dict{String, Any}(
        "comparison_type" => DFVB_MATLAB_COMPARISON_TYPE,
        "alignment_policy" => String(alignment_policy),
        "alpha_comparison_included" => false,
        "flux_comparison_included" => false,
        "julia_tspan" => julia_tspan,
        "julia_saveat" => julia_saveat,
        "julia_algorithm_label" => String(julia_algorithm_label),
        "julia_reconstruct_alphas" => julia_reconstruct_alphas,
        "julia_reconstruct_fluxes" => julia_reconstruct_fluxes,
        "julia_retcode" => get(julia_result.metadata, "retcode", missing),
        "julia_n_time_points" => length(julia_result.time),
        "julia_n_alphas" => get(julia_result.metadata, "n_alphas", missing),
        "julia_alpha_scope" => get(julia_result.metadata, "alpha_scope", missing),
        "lp_atol" => Float64(lp_atol),
        "ode_abstol" => Float64(ode_abstol),
        "ode_reltol" => Float64(ode_reltol),
        "baseline_time_start" => baseline_times[begin],
        "baseline_time_end" => baseline_times[end],
        "baseline_n_time_points" => length(baseline_times),
        "baseline_report_type" => get(baseline_report.metadata, "report_type", missing),
        "baseline_source" => get(baseline_report.metadata, "source", missing),
        "state_names" => copy(state_names),
        "n_states" => length(state_names),
        "r0001_used_as_oxygen" => false,
        "oxygen_reaction_id" => "r_1992",
        "oxygen_policy_note" => DFVB_MATLAB_OXYGEN_NOTE,
        "carbohydrate_policy_note" => DFVB_MATLAB_CARBOHYDRATE_NOTE,
        "alpha_mapping_note" => get(baseline_report.metadata, "alpha_mapping_note", DFVB_BASELINE_ALPHA_MAPPING_NOTE),
        "exchange_partition_note" => get(baseline_report.metadata, "exchange_partition_note", DFVB_ARTIFACT_EXCHANGE_PARTITION_NOTE),
        "indices_reacciones_used" => false,
        "dfvb_vs_dfba_comparison_included" => false,
        "kkt_mpcc_collocation_implemented" => false,
        "interpretation_note" => DFVB_MATLAB_INTERPRETATION_NOTE,
    )
end

function _dfvb_matlab_linear_interpolate(
    baseline_times::Vector{Float64},
    values::Vector{Float64},
    target::Float64,
)::Float64
    index = searchsortedfirst(baseline_times, target)
    if index <= length(baseline_times) && baseline_times[index] == target
        return values[index]
    elseif index == 1 || index > length(baseline_times)
        error("DFVB MATLAB comparison target time $target is outside the baseline interpolation range.")
    end

    left_index = index - 1
    right_index = index
    left_time = baseline_times[left_index]
    right_time = baseline_times[right_index]
    fraction = (target - left_time) / (right_time - left_time)
    return values[left_index] + fraction * (values[right_index] - values[left_index])
end

function _dfvb_matlab_assert_strictly_increasing(values::Vector{Float64})
    for i in 2:length(values)
        values[i] > values[i - 1] || error(
            "DFVB MATLAB comparison baseline time grid must be strictly increasing. " *
            "Found $(values[i - 1]) then $(values[i]) at positions $(i - 1), $i.",
        )
    end
    return nothing
end

function _dfvb_matlab_assert_target_times_in_range(
    baseline_times::Vector{Float64},
    target_times::Vector{Float64},
)
    min_time = baseline_times[begin]
    max_time = baseline_times[end]
    for target in target_times
        min_time <= target <= max_time || error(
            "DFVB MATLAB comparison target time $target is outside baseline range $min_time to $max_time. " *
            "Extrapolation is not performed.",
        )
    end
    return nothing
end

function _dfvb_matlab_numeric_vector(values, label::AbstractString)::Vector{Float64}
    output = Vector{Float64}(undef, length(values))
    for (i, value) in enumerate(values)
        ismissing(value) && error("Missing numeric value in DFVB MATLAB comparison $label row $i.")
        parsed = value isa Real ? Float64(value) : tryparse(Float64, strip(String(value)))
        parsed === nothing && error("Non-numeric value in DFVB MATLAB comparison $label row $i: $value")
        isfinite(parsed) || error("Non-finite value in DFVB MATLAB comparison $label row $i: $value")
        output[i] = parsed
    end
    return output
end

function _dfvb_matlab_state_note(state_name::AbstractString)::String
    name = String(state_name)
    if name == "oxygen"
        return DFVB_MATLAB_OXYGEN_NOTE * "; " * DFVB_MATLAB_STATE_ONLY_NOTE
    elseif name == "carbohydrate"
        return DFVB_MATLAB_CARBOHYDRATE_NOTE * "; " * DFVB_MATLAB_STATE_ONLY_NOTE
    end
    return DFVB_MATLAB_STATE_ONLY_NOTE
end

function _dfvb_matlab_algorithm_label(algorithm)::String
    algorithm === nothing && return "default"
    return String(nameof(typeof(algorithm)))
end

function _dfvb_matlab_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end

function _dfvb_matlab_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _dfvb_matlab_toml_normalize_real(value)
    elseif value isa Tuple
        return _dfvb_matlab_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _dfvb_matlab_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _dfvb_matlab_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _dfvb_matlab_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _dfvb_matlab_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _dfvb_matlab_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end
