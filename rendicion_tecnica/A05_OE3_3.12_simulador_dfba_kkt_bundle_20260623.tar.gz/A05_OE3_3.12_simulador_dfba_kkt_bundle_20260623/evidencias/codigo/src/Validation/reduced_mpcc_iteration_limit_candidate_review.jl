const REDUCED_DCDFBA_MPCC_ITERATION_LIMIT_CANDIDATE_REVIEW_TYPE =
    "reduced_dcdfba_mpcc_iteration_limit_candidate_review"

const REDUCED_DCDFBA_MPCC_ITERATION_LIMIT_CANDIDATE_REVIEW_COLUMNS = [
    "window_id",
    "window_index",
    "selected_for_review",
    "selection_reason",
    "review_decision",
    "diagnostic_extraction_allowed",
    "scientific_acceptance_allowed",
    "trajectory_candidate_available",
    "trajectory_candidate_ready",
    "trajectory_candidate_extracted_despite_not_ready",
    "solver_status",
    "primal_status",
    "traffic_light",
    "viability_class",
    "residual_feasible",
    "iteration_limit_residual_feasible",
    "residual_thresholds_satisfied",
    "residuals_pass",
    "state_drift_pass",
    "max_state_relative_rmse",
    "max_state_relative_rmse_threshold",
    "max_mass_balance_residual",
    "max_mass_balance_ratio",
    "dominant_residual",
    "blocking_reasons",
    "review_reasons",
    "recommended_next_action",
]

"""
    ReducedDCDFBAMPCCIterationLimitCandidateReviewResult

Diagnostic-only review of reduced MPCC window candidates that reached
`ITERATION_LIMIT` while satisfying residual-feasibility gates. Selected
candidates may be inspected as trajectory views, but they are not accepted as
scientific simulations and are not used to rebuild a windowed trajectory.
"""
struct ReducedDCDFBAMPCCIterationLimitCandidateReviewResult
    review_table::DataFrame
    trajectory_candidates::Vector{ReducedDCDFBAMPCCTrajectoryCandidate}
    source_attempt::Union{Nothing, ReducedDCDFBAMPCCWindowedSimulationAttemptResult}
    metadata::Dict{String, Any}
end

"""
    review_reduced_dcdfba_mpcc_iteration_limit_candidates(attempt; max_candidates=typemax(Int))

Review diagnostic trajectory candidates from a reduced MPCC windowed attempt
whose solver status is `ITERATION_LIMIT` and whose residual gates are satisfied.
The review is explicit and conservative: it permits in-memory diagnostic
inspection only, writes no outputs, and never marks the candidate as a
scientific simulation.
"""
function review_reduced_dcdfba_mpcc_iteration_limit_candidates(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult;
    max_candidates::Int = typemax(Int),
)::ReducedDCDFBAMPCCIterationLimitCandidateReviewResult
    max_candidates >= 0 || throw(
        ArgumentError("Reduced MPCC iteration-limit candidate review max_candidates must be nonnegative."),
    )
    thresholds = attempt.viability_report.thresholds
    rows = Dict{String, Any}[]
    candidates = ReducedDCDFBAMPCCTrajectoryCandidate[]
    for source_row in _reduced_mpcc_iteration_limit_review_window_rows(attempt)
        comparison = _reduced_mpcc_iteration_limit_review_comparison(attempt, source_row)
        row = _reduced_mpcc_iteration_limit_review_row(
            source_row,
            comparison,
            thresholds,
            length(candidates) < max_candidates,
        )
        push!(rows, row)
        if get(row, "diagnostic_extraction_allowed", false) === true
            push!(candidates, comparison.trajectory_candidate)
        end
    end
    table = _reduced_mpcc_iteration_limit_review_table(rows)
    metadata = _reduced_mpcc_iteration_limit_review_metadata(
        table,
        candidates,
        attempt;
        source_kind = "windowed_attempt",
        max_candidates = max_candidates,
    )
    return ReducedDCDFBAMPCCIterationLimitCandidateReviewResult(
        table,
        candidates,
        attempt,
        metadata,
    )
end

"""
    review_reduced_dcdfba_mpcc_iteration_limit_candidates(retry_aware_attempt; kwargs...)

Review iteration-limit residual-feasible candidates from the base attempt of a
retry-aware reduced MPCC diagnostic. Retry replacement is still not applied.
"""
function review_reduced_dcdfba_mpcc_iteration_limit_candidates(
    retry_aware_attempt::ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult;
    max_candidates::Int = typemax(Int),
)::ReducedDCDFBAMPCCIterationLimitCandidateReviewResult
    review = review_reduced_dcdfba_mpcc_iteration_limit_candidates(
        retry_aware_attempt.base_attempt;
        max_candidates = max_candidates,
    )
    metadata = copy(review.metadata)
    metadata["source_kind"] = "retry_aware_base_attempt"
    metadata["retry_aware_attempt_attached"] = true
    metadata["retry_replacement_recommended"] =
        get(retry_aware_attempt.metadata, "retry_replacement_recommended", missing)
    metadata["retry_replacement_applied"] =
        get(retry_aware_attempt.metadata, "retry_replacement_applied", false)
    metadata["windowed_candidate_rebuilt"] =
        get(retry_aware_attempt.metadata, "windowed_candidate_rebuilt", false)
    return ReducedDCDFBAMPCCIterationLimitCandidateReviewResult(
        review.review_table,
        review.trajectory_candidates,
        retry_aware_attempt.base_attempt,
        metadata,
    )
end

"""
    review_reduced_dcdfba_mpcc_iteration_limit_candidates(termination_diagnostic; kwargs...)

Review iteration-limit residual-feasible candidates from a solver-termination
diagnostic only when that diagnostic carries a retry-aware attempt.
"""
function review_reduced_dcdfba_mpcc_iteration_limit_candidates(
    termination_diagnostic::ReducedDCDFBAMPCCSolverTerminationDiagnosticResult;
    max_candidates::Int = typemax(Int),
)::ReducedDCDFBAMPCCIterationLimitCandidateReviewResult
    termination_diagnostic.retry_aware_attempt === nothing && throw(
        ArgumentError(
            "Reduced MPCC iteration-limit candidate review requires a retry-aware attempt when called from solver-termination diagnostics.",
        ),
    )
    review = review_reduced_dcdfba_mpcc_iteration_limit_candidates(
        termination_diagnostic.retry_aware_attempt;
        max_candidates = max_candidates,
    )
    metadata = copy(review.metadata)
    metadata["source_kind"] = "solver_termination_retry_aware_attempt"
    metadata["solver_termination_diagnostic_attached"] = true
    metadata["dominant_termination_blocker"] =
        get(termination_diagnostic.metadata, "dominant_termination_blocker", missing)
    metadata["solver_termination_recommended_next_action"] =
        get(termination_diagnostic.metadata, "recommended_next_action", missing)
    return ReducedDCDFBAMPCCIterationLimitCandidateReviewResult(
        review.review_table,
        review.trajectory_candidates,
        review.source_attempt,
        metadata,
    )
end

function _reduced_mpcc_iteration_limit_review_window_rows(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
)
    table = attempt.viability_report.viability_table
    nrow(table) == 0 && return DataFrameRow[]
    rows = [
        row for row in eachrow(table) if
        String(get(row, "source_type", "")) == "windowed_continuation_window"
    ]
    isempty(rows) ? collect(eachrow(table)) : rows
end

function _reduced_mpcc_iteration_limit_review_comparison(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    row,
)
    index = _reduced_mpcc_iteration_limit_review_int_or_missing(
        get(row, "window_index", missing),
    )
    comparisons = attempt.continuation_result.window_comparisons
    index === missing && return nothing
    1 <= index <= length(comparisons) || return nothing
    return comparisons[index]
end

function _reduced_mpcc_iteration_limit_review_row(
    row,
    comparison,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
    within_max_candidates::Bool,
)::Dict{String, Any}
    selected, reason = _reduced_mpcc_iteration_limit_review_selected(row)
    candidate_available = comparison !== nothing &&
                          comparison.trajectory_candidate isa ReducedDCDFBAMPCCTrajectoryCandidate
    allowed = selected && candidate_available && within_max_candidates
    trajectory_metadata = candidate_available ?
                          comparison.trajectory_candidate.metadata :
                          Dict{String, Any}()
    ready = get(trajectory_metadata, "trajectory_candidate_ready", false) === true
    max_mass = get(row, "max_mass_balance_residual", missing)
    mass_ratio = _reduced_mpcc_iteration_limit_review_ratio(
        max_mass,
        thresholds.max_mass_balance_residual,
    )
    decision = _reduced_mpcc_iteration_limit_review_decision(
        selected,
        allowed,
        candidate_available,
        within_max_candidates,
        ready,
        row,
    )
    return Dict{String, Any}(
        "window_id" => get(row, "candidate_id", missing),
        "window_index" => get(row, "window_index", missing),
        "selected_for_review" => selected,
        "selection_reason" => reason,
        "review_decision" => decision,
        "diagnostic_extraction_allowed" => allowed,
        "scientific_acceptance_allowed" => false,
        "trajectory_candidate_available" => candidate_available,
        "trajectory_candidate_ready" => ready,
        "trajectory_candidate_extracted_despite_not_ready" =>
            get(
                trajectory_metadata,
                "trajectory_candidate_extracted_despite_not_ready",
                false,
            ) === true,
        "solver_status" => get(row, "solver_status", missing),
        "primal_status" => get(row, "primal_status", missing),
        "traffic_light" => get(row, "traffic_light", missing),
        "viability_class" => get(row, "viability_class", missing),
        "residual_feasible" => get(row, "residual_feasible", false) === true,
        "iteration_limit_residual_feasible" =>
            get(row, "iteration_limit_residual_feasible", false) === true,
        "residual_thresholds_satisfied" =>
            _reduced_mpcc_iteration_limit_review_residuals_satisfied(row),
        "residuals_pass" => get(row, "residuals_pass", false) === true,
        "state_drift_pass" => get(row, "state_drift_pass", false) === true,
        "max_state_relative_rmse" => get(row, "max_state_relative_rmse", missing),
        "max_state_relative_rmse_threshold" => thresholds.max_state_relative_rmse,
        "max_mass_balance_residual" => max_mass,
        "max_mass_balance_ratio" => mass_ratio,
        "dominant_residual" => get(row, "dominant_residual", missing),
        "blocking_reasons" => get(row, "blocking_reasons", missing),
        "review_reasons" => get(row, "review_reasons", missing),
        "recommended_next_action" =>
            _reduced_mpcc_iteration_limit_review_row_action(
                selected,
                allowed,
                row,
            ),
    )
end

function _reduced_mpcc_iteration_limit_review_selected(row)
    solver_status = String(get(row, "solver_status", ""))
    residual_feasible = get(row, "residual_feasible", false) === true
    iteration_limit_residual_feasible =
        get(row, "iteration_limit_residual_feasible", false) === true
    trajectory_ready = get(row, "trajectory_ready", false) === true
    residuals_satisfied =
        _reduced_mpcc_iteration_limit_review_residuals_satisfied(row)
    if iteration_limit_residual_feasible ||
       (solver_status == "ITERATION_LIMIT" && residual_feasible && residuals_satisfied === true)
        trajectory_ready &&
            return (false, "already_trajectory_ready")
        return (true, "iteration_limit_residual_feasible")
    elseif solver_status == "ITERATION_LIMIT"
        return (false, "iteration_limit_but_not_residual_feasible")
    elseif trajectory_ready
        return (false, "trajectory_ready_candidate")
    else
        return (false, "not_iteration_limit_residual_feasible")
    end
end

function _reduced_mpcc_iteration_limit_review_decision(
    selected::Bool,
    allowed::Bool,
    candidate_available::Bool,
    within_max_candidates::Bool,
    ready::Bool,
    row,
)::String
    selected || return "not_selected"
    candidate_available || return "selected_but_candidate_unavailable"
    within_max_candidates || return "selected_but_max_candidates_reached"
    ready && return "already_ready_review_as_standard_candidate"
    get(row, "state_drift_pass", false) === true ||
        return "diagnostic_only_state_drift_review_required"
    return "diagnostic_only_iteration_limit_candidate_review"
end

function _reduced_mpcc_iteration_limit_review_row_action(
    selected::Bool,
    allowed::Bool,
    row,
)::String
    selected || return "no_iteration_limit_candidate_action"
    allowed || return "recover_candidate_before_iteration_limit_review"
    get(row, "state_drift_pass", false) === true ||
        return "review_state_drift_before_iteration_limit_policy_change"
    return "compare_iteration_limit_candidate_state_drift_before_policy_change"
end

function _reduced_mpcc_iteration_limit_review_metadata(
    table::DataFrame,
    candidates::Vector{ReducedDCDFBAMPCCTrajectoryCandidate},
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult;
    source_kind::AbstractString,
    max_candidates::Int,
)::Dict{String, Any}
    selected_count =
        nrow(table) == 0 ? 0 : count(value -> value === true, table[!, "selected_for_review"])
    allowed_count =
        nrow(table) == 0 ? 0 :
        count(value -> value === true, table[!, "diagnostic_extraction_allowed"])
    state_drift_review_count =
        nrow(table) == 0 ? 0 :
        count(
            row -> row["selected_for_review"] === true &&
                   row["state_drift_pass"] !== true,
            eachrow(table),
        )
    return Dict{String, Any}(
        "review_type" =>
            REDUCED_DCDFBA_MPCC_ITERATION_LIMIT_CANDIDATE_REVIEW_TYPE,
        "source_kind" => String(source_kind),
        "target_horizon" => get(attempt.metadata, "target_horizon", missing),
        "horizon_reached" => get(attempt.metadata, "horizon_reached", missing),
        "target_completed" => get(attempt.metadata, "target_completed", missing),
        "attempt_traffic_light" =>
            get(attempt.metadata, "attempt_traffic_light", missing),
        "max_candidates" => max_candidates,
        "n_window_rows_reviewed" => nrow(table),
        "selected_candidate_count" => selected_count,
        "diagnostic_extraction_allowed_count" => allowed_count,
        "trajectory_candidate_count" => length(candidates),
        "state_drift_review_required_count" => state_drift_review_count,
        "any_scientific_acceptance_allowed" =>
            nrow(table) > 0 &&
            any(value -> value === true, table[!, "scientific_acceptance_allowed"]),
        "recommended_next_action" =>
            _reduced_mpcc_iteration_limit_review_metadata_action(
                selected_count,
                allowed_count,
                state_drift_review_count,
            ),
        "outputs_written" => false,
        "iteration_limit_candidate_review_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "retry_replacement_applied" => false,
        "windowed_candidate_rebuilt" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC iteration-limit candidate review; diagnostic only and not a solved scientific trajectory.",
    )
end

function _reduced_mpcc_iteration_limit_review_metadata_action(
    selected_count::Int,
    allowed_count::Int,
    state_drift_review_count::Int,
)::String
    selected_count == 0 &&
        return "no_iteration_limit_residual_feasible_candidates_to_review"
    allowed_count == 0 && return "recover_candidate_objects_before_review"
    state_drift_review_count > 0 &&
        return "review_state_drift_before_iteration_limit_policy_change"
    return "compare_iteration_limit_candidate_state_drift_before_policy_change"
end

function _reduced_mpcc_iteration_limit_review_residuals_satisfied(row)
    if _reduced_mpcc_iteration_limit_review_has(row, "residual_thresholds_satisfied")
        return get(row, "residual_thresholds_satisfied", false) === true
    end
    if _reduced_mpcc_iteration_limit_review_has(row, "residuals_pass")
        return get(row, "residuals_pass", false) === true
    end
    return false
end

function _reduced_mpcc_iteration_limit_review_ratio(value, threshold)
    _reduced_mpcc_iteration_limit_review_isfinite_number(value) || return missing
    _reduced_mpcc_iteration_limit_review_isfinite_number(threshold) || return missing
    Float64(threshold) > 0.0 || return missing
    return abs(Float64(value)) / Float64(threshold)
end

function _reduced_mpcc_iteration_limit_review_has(row, column::AbstractString)::Bool
    key = String(column)
    try
        key in names(row) && return true
    catch
    end
    try
        haskey(row, key) && return true
    catch
    end
    try
        haskey(row, Symbol(key)) && return true
    catch
    end
    return false
end

function _reduced_mpcc_iteration_limit_review_int_or_missing(value)
    value === missing && return missing
    value === nothing && return missing
    return try
        Int(value)
    catch
        missing
    end
end

function _reduced_mpcc_iteration_limit_review_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_iteration_limit_review_table(
    rows::Vector{Dict{String, Any}},
)::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_iteration_limit_review_scalar(get(row, column, missing)) for
                row in rows
            ] for column in REDUCED_DCDFBA_MPCC_ITERATION_LIMIT_CANDIDATE_REVIEW_COLUMNS
        )...,
    )
end

function _reduced_mpcc_iteration_limit_review_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
