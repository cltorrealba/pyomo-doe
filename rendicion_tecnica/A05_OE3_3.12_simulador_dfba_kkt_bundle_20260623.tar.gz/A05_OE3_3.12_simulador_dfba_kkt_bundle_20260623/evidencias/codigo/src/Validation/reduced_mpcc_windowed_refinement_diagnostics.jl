const REDUCED_DCDFBA_MPCC_WINDOWED_REFINEMENT_DIAGNOSTIC_TYPE =
    "reduced_dcdfba_mpcc_windowed_refinement_diagnostics"

const REDUCED_DCDFBA_MPCC_WINDOWED_REFINEMENT_CORE_STATES = Set([
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "total_sugar",
])

const REDUCED_DCDFBA_MPCC_WINDOWED_REFINEMENT_AROMA_STATES = Set([
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
])

struct ReducedDCDFBAMPCCWindowedRefinementDiagnosticResult
    window_refinement_candidates::DataFrame
    state_window_errors::DataFrame
    boundary_jumps::DataFrame
    metadata::Dict{String, Any}
end

"""
    diagnose_reduced_dcdfba_mpcc_windowed_refinement(window_table, aligned_timeseries, state_metrics)

Build offline diagnostics for selective refinement of a completed windowed MPCC
run. The diagnostic ranks windows by coarse tau fallback, solver status, state
drift, and local slope changes around window boundaries. It does not rerun the
MPCC.
"""
function diagnose_reduced_dcdfba_mpcc_windowed_refinement(
    window_table::DataFrame,
    aligned_timeseries_table::DataFrame,
    state_metrics_table::DataFrame = DataFrame();
    boundary_relative_jump_threshold::Real = 2.0e-2,
    window_relative_rmse_threshold::Real = 5.0e-2,
    window_abs_difference_threshold::Real = 1.0e-1,
)::ReducedDCDFBAMPCCWindowedRefinementDiagnosticResult
    nrow(window_table) > 0 ||
        throw(ArgumentError("Windowed refinement diagnostics require a non-empty window_table."))
    nrow(aligned_timeseries_table) > 0 ||
        throw(ArgumentError("Windowed refinement diagnostics require a non-empty aligned_timeseries_table."))

    boundary_threshold = _reduced_mpcc_refinement_positive_threshold(
        boundary_relative_jump_threshold,
        "boundary_relative_jump_threshold",
    )
    rmse_threshold = _reduced_mpcc_refinement_positive_threshold(
        window_relative_rmse_threshold,
        "window_relative_rmse_threshold",
    )
    abs_threshold = _reduced_mpcc_refinement_positive_threshold(
        window_abs_difference_threshold,
        "window_abs_difference_threshold",
    )

    states = _reduced_mpcc_refinement_state_names(aligned_timeseries_table)
    state_window_errors =
        _reduced_mpcc_refinement_state_window_errors(window_table, aligned_timeseries_table, states)
    boundary_jumps =
        _reduced_mpcc_refinement_boundary_jumps(window_table, aligned_timeseries_table, states)
    candidates = _reduced_mpcc_refinement_candidates(
        window_table,
        state_window_errors,
        boundary_jumps;
        boundary_relative_jump_threshold = boundary_threshold,
        window_relative_rmse_threshold = rmse_threshold,
        window_abs_difference_threshold = abs_threshold,
    )

    metadata = Dict{String, Any}(
        "diagnostic_type" => REDUCED_DCDFBA_MPCC_WINDOWED_REFINEMENT_DIAGNOSTIC_TYPE,
        "diagnostic_is_scientific_simulation" => false,
        "mpcc_rerun_performed" => false,
        "n_windows" => nrow(window_table),
        "n_states" => length(states),
        "n_boundary_rows" => nrow(boundary_jumps),
        "n_state_window_rows" => nrow(state_window_errors),
        "n_refinement_candidate_rows" => nrow(candidates),
        "boundary_relative_jump_threshold" => boundary_threshold,
        "window_relative_rmse_threshold" => rmse_threshold,
        "window_abs_difference_threshold" => abs_threshold,
        "high_priority_window_count" =>
            count(==("high"), String.(candidates[!, "refinement_priority"])),
        "medium_priority_window_count" =>
            count(==("medium"), String.(candidates[!, "refinement_priority"])),
        "coarse_tau_fallback_window_count" =>
            count(_reduced_mpcc_refinement_bool, candidates[!, "coarse_tau_fallback"]),
        "max_refinement_score" =>
            nrow(candidates) == 0 ? 0.0 : maximum(Float64.(candidates[!, "refinement_score"])),
        "max_boundary_relative_jump" =>
            nrow(boundary_jumps) == 0 ? 0.0 :
            maximum(Float64.(boundary_jumps[!, "relative_delta_change_excess"])),
        "max_window_state_abs_difference" =>
            nrow(state_window_errors) == 0 ? 0.0 :
            maximum(Float64.(state_window_errors[!, "max_abs_difference"])),
    )
    if nrow(state_metrics_table) > 0
        metadata["global_metric_rows_available"] = true
        metadata["global_max_state_relative_rmse"] =
            _reduced_mpcc_refinement_column_max(state_metrics_table, "relative_rmse")
    else
        metadata["global_metric_rows_available"] = false
    end
    return ReducedDCDFBAMPCCWindowedRefinementDiagnosticResult(
        candidates,
        state_window_errors,
        boundary_jumps,
        metadata,
    )
end

"""
    diagnose_reduced_dcdfba_mpcc_windowed_refinement_artifacts(artifact_dir; output_dir=nothing)

Read an existing windowed MPCC artifact directory and build selective-refinement
diagnostics from its exported CSV files. `artifact_dir` may be either the
artifact root or its `diagnostics` subdirectory.
"""
function diagnose_reduced_dcdfba_mpcc_windowed_refinement_artifacts(
    artifact_dir::AbstractString;
    output_dir::Union{Nothing, AbstractString} = nothing,
    overwrite::Bool = false,
    boundary_relative_jump_threshold::Real = 2.0e-2,
    window_relative_rmse_threshold::Real = 5.0e-2,
    window_abs_difference_threshold::Real = 1.0e-1,
)::ReducedDCDFBAMPCCWindowedRefinementDiagnosticResult
    diagnostics_dir = _reduced_mpcc_refinement_diagnostics_dir(artifact_dir)
    window_table = CSV.read(joinpath(diagnostics_dir, "window_table.csv"), DataFrame)
    aligned_timeseries = CSV.read(joinpath(diagnostics_dir, "aligned_timeseries.csv"), DataFrame)
    state_metrics_path = joinpath(diagnostics_dir, "state_metrics.csv")
    state_metrics = isfile(state_metrics_path) ? CSV.read(state_metrics_path, DataFrame) : DataFrame()
    result = diagnose_reduced_dcdfba_mpcc_windowed_refinement(
        window_table,
        aligned_timeseries,
        state_metrics;
        boundary_relative_jump_threshold = boundary_relative_jump_threshold,
        window_relative_rmse_threshold = window_relative_rmse_threshold,
        window_abs_difference_threshold = window_abs_difference_threshold,
    )
    result.metadata["source_artifact_dir"] = normpath(String(artifact_dir))
    result.metadata["source_diagnostics_dir"] = diagnostics_dir
    if output_dir !== nothing
        export_reduced_dcdfba_mpcc_windowed_refinement_diagnostics(
            result,
            output_dir;
            overwrite = overwrite,
        )
    end
    return result
end

function export_reduced_dcdfba_mpcc_windowed_refinement_diagnostics(
    result::ReducedDCDFBAMPCCWindowedRefinementDiagnosticResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Reduced MPCC refinement output_dir exists and is not a directory: $output_path")
    end
    paths = Dict{String, String}(
        "window_refinement_candidates" => joinpath(output_path, "window_refinement_candidates.csv"),
        "state_window_errors" => joinpath(output_path, "state_window_errors.csv"),
        "boundary_jumps" => joinpath(output_path, "boundary_jumps.csv"),
        "metadata" => joinpath(output_path, "metadata.toml"),
        "window_refinement_score_plot" => joinpath(output_path, "window_refinement_score.svg"),
    )
    _reduced_mpcc_window_prepare_output_paths!(paths, overwrite)

    CSV.write(paths["window_refinement_candidates"], result.window_refinement_candidates)
    CSV.write(paths["state_window_errors"], result.state_window_errors)
    CSV.write(paths["boundary_jumps"], result.boundary_jumps)
    open(paths["metadata"], "w") do io
        TOML.print(io, _toml_normalize(result.metadata))
    end
    write(paths["window_refinement_score_plot"], _reduced_mpcc_refinement_score_svg(result))
    return paths
end

function _reduced_mpcc_refinement_positive_threshold(value::Real, name::AbstractString)::Float64
    parsed = Float64(value)
    isfinite(parsed) && parsed > 0.0 ||
        throw(ArgumentError("Reduced MPCC refinement $name must be finite and positive."))
    return parsed
end

function _reduced_mpcc_refinement_diagnostics_dir(artifact_dir::AbstractString)::String
    root = normpath(String(artifact_dir))
    direct = joinpath(root, "window_table.csv")
    nested = joinpath(root, "diagnostics", "window_table.csv")
    if isfile(direct)
        return root
    elseif isfile(nested)
        return normpath(joinpath(root, "diagnostics"))
    else
        error(
            "Reduced MPCC refinement diagnostics could not find window_table.csv in " *
            "$root or $root/diagnostics.",
        )
    end
end

function _reduced_mpcc_refinement_state_names(table::DataFrame)::Vector{String}
    column_names = names(table)
    states = String[]
    for column in column_names
        suffix = "_sequential"
        endswith(column, suffix) || continue
        state = first(column, lastindex(column) - length(suffix))
        if "$(state)_mpcc_candidate" in column_names
            push!(states, state)
        end
    end
    return sort(states)
end

function _reduced_mpcc_refinement_state_group(state::AbstractString)::String
    normalized = lowercase(String(state))
    if normalized in REDUCED_DCDFBA_MPCC_WINDOWED_REFINEMENT_AROMA_STATES
        return "aroma_trace"
    elseif normalized in REDUCED_DCDFBA_MPCC_WINDOWED_REFINEMENT_CORE_STATES
        return "core"
    else
        return "metabolite_trace"
    end
end

function _reduced_mpcc_refinement_state_window_errors(
    window_table::DataFrame,
    aligned_timeseries_table::DataFrame,
    states::AbstractVector{<:AbstractString},
)::DataFrame
    time = Float64.(aligned_timeseries_table[!, "time"])
    rows = Vector{Dict{String, Any}}()
    for window in eachrow(window_table)
        t0 = _reduced_mpcc_refinement_number(window, "t0", NaN)
        tfinal = _reduced_mpcc_refinement_number(window, "tfinal", NaN)
        isfinite(t0) && isfinite(tfinal) || continue
        indices = findall(t -> t >= t0 - 1.0e-8 && t <= tfinal + 1.0e-8, time)
        isempty(indices) && continue
        for state in states
            seq_col = "$(state)_sequential"
            mpcc_col = "$(state)_mpcc_candidate"
            sequential = Float64.(aligned_timeseries_table[indices, seq_col])
            mpcc = Float64.(aligned_timeseries_table[indices, mpcc_col])
            difference = mpcc .- sequential
            abs_difference = abs.(difference)
            max_index = argmax(abs_difference)
            scale = max(maximum(abs.(sequential)), maximum(abs.(mpcc)), eps(Float64))
            rmse = sqrt(sum(abs2, difference) / length(difference))
            push!(
                rows,
                Dict{String, Any}(
                    "window_id" => String(window["window_id"]),
                    "window_index" => Int(window["window_index"]),
                    "t0" => t0,
                    "tfinal" => tfinal,
                    "state_name" => String(state),
                    "state_group" => _reduced_mpcc_refinement_state_group(state),
                    "n_points" => length(indices),
                    "initial_sequential" => sequential[1],
                    "initial_mpcc_candidate" => mpcc[1],
                    "final_sequential" => sequential[end],
                    "final_mpcc_candidate" => mpcc[end],
                    "final_difference_mpcc_minus_sequential" => difference[end],
                    "max_abs_difference" => maximum(abs_difference),
                    "max_abs_difference_time" => time[indices[max_index]],
                    "rmse" => rmse,
                    "relative_rmse" => rmse / scale,
                    "sequential_net_change" => sequential[end] - sequential[1],
                    "mpcc_net_change" => mpcc[end] - mpcc[1],
                    "net_change_difference" =>
                        (mpcc[end] - mpcc[1]) - (sequential[end] - sequential[1]),
                ),
            )
        end
    end
    return DataFrame(rows)
end

function _reduced_mpcc_refinement_boundary_jumps(
    window_table::DataFrame,
    aligned_timeseries_table::DataFrame,
    states::AbstractVector{<:AbstractString},
)::DataFrame
    nrow(window_table) >= 2 || return DataFrame()
    time = Float64.(aligned_timeseries_table[!, "time"])
    rows = Vector{Dict{String, Any}}()
    ordered_windows = sort(window_table, :window_index)
    for boundary_index in 1:(nrow(ordered_windows) - 1)
        left = ordered_windows[boundary_index, :]
        right = ordered_windows[boundary_index + 1, :]
        boundary_time = Float64(left["tfinal"])
        time_index = findfirst(t -> abs(t - boundary_time) <= 1.0e-8, time)
        if time_index === nothing || time_index <= firstindex(time) || time_index >= lastindex(time)
            continue
        end
        previous_dt = time[time_index] - time[time_index - 1]
        next_dt = time[time_index + 1] - time[time_index]
        for state in states
            seq = Float64.(aligned_timeseries_table[!, "$(state)_sequential"])
            mpcc = Float64.(aligned_timeseries_table[!, "$(state)_mpcc_candidate"])
            difference = mpcc .- seq
            seq_prev_delta = seq[time_index] - seq[time_index - 1]
            seq_next_delta = seq[time_index + 1] - seq[time_index]
            mpcc_prev_delta = mpcc[time_index] - mpcc[time_index - 1]
            mpcc_next_delta = mpcc[time_index + 1] - mpcc[time_index]
            seq_delta_change = seq_next_delta - seq_prev_delta
            mpcc_delta_change = mpcc_next_delta - mpcc_prev_delta
            diff_delta_change =
                difference[time_index + 1] - 2.0 * difference[time_index] + difference[time_index - 1]
            scale = max(maximum(abs.(seq)), maximum(abs.(mpcc)), eps(Float64))
            push!(
                rows,
                Dict{String, Any}(
                    "left_window_id" => String(left["window_id"]),
                    "right_window_id" => String(right["window_id"]),
                    "left_window_index" => Int(left["window_index"]),
                    "right_window_index" => Int(right["window_index"]),
                    "boundary_time" => boundary_time,
                    "previous_dt" => previous_dt,
                    "next_dt" => next_dt,
                    "state_name" => String(state),
                    "state_group" => _reduced_mpcc_refinement_state_group(state),
                    "sequential_previous_delta" => seq_prev_delta,
                    "sequential_next_delta" => seq_next_delta,
                    "sequential_delta_change" => seq_delta_change,
                    "mpcc_previous_delta" => mpcc_prev_delta,
                    "mpcc_next_delta" => mpcc_next_delta,
                    "mpcc_delta_change" => mpcc_delta_change,
                    "absolute_delta_change_excess" => abs(mpcc_delta_change - seq_delta_change),
                    "relative_delta_change_excess" =>
                        abs(mpcc_delta_change - seq_delta_change) / scale,
                    "difference_delta_change" => diff_delta_change,
                    "difference_delta_change_abs" => abs(diff_delta_change),
                    "difference_at_boundary" => difference[time_index],
                    "abs_difference_at_boundary" => abs(difference[time_index]),
                ),
            )
        end
    end
    return DataFrame(rows)
end

function _reduced_mpcc_refinement_candidates(
    window_table::DataFrame,
    state_window_errors::DataFrame,
    boundary_jumps::DataFrame;
    boundary_relative_jump_threshold::Float64,
    window_relative_rmse_threshold::Float64,
    window_abs_difference_threshold::Float64,
)::DataFrame
    rows = Vector{Dict{String, Any}}()
    ordered_windows = sort(window_table, :window_index)
    for window in eachrow(ordered_windows)
        window_id = String(window["window_id"])
        window_index = Int(window["window_index"])
        state_rows = nrow(state_window_errors) == 0 ?
            DataFrame() :
            state_window_errors[state_window_errors.window_id .== window_id, :]
        boundary_rows = nrow(boundary_jumps) == 0 ?
            DataFrame() :
            boundary_jumps[
                (boundary_jumps.left_window_id .== window_id) .|
                (boundary_jumps.right_window_id .== window_id),
                :,
            ]
        core_rows = nrow(state_rows) == 0 ?
            DataFrame() :
            state_rows[state_rows.state_group .== "core", :]
        max_abs, abs_state = _reduced_mpcc_refinement_max_with_state(
            state_rows,
            "max_abs_difference",
        )
        max_rel, rel_state = _reduced_mpcc_refinement_max_with_state(
            core_rows,
            "relative_rmse",
        )
        trace_rows = nrow(state_rows) == 0 ?
            DataFrame() :
            state_rows[state_rows.state_group .!= "core", :]
        max_trace_rel, trace_state = _reduced_mpcc_refinement_max_with_state(
            trace_rows,
            "relative_rmse",
        )
        max_boundary, boundary_state = _reduced_mpcc_refinement_max_with_state(
            boundary_rows,
            "relative_delta_change_excess",
        )
        max_boundary_abs, boundary_abs_state = _reduced_mpcc_refinement_max_with_state(
            boundary_rows,
            "absolute_delta_change_excess",
        )
        trace_boundary_rows = nrow(boundary_rows) == 0 ?
            DataFrame() :
            boundary_rows[boundary_rows.state_group .!= "core", :]
        max_trace_boundary_abs, trace_boundary_state =
            _reduced_mpcc_refinement_max_with_state(
                trace_boundary_rows,
                "absolute_delta_change_excess",
            )
        selected_tau = _reduced_mpcc_refinement_number(
            window,
            "tau_continuation_selected_tau",
            _reduced_mpcc_refinement_number(window, "complementarity_tau", NaN),
        )
        coarse_fallback = _reduced_mpcc_refinement_bool(
            _reduced_mpcc_refinement_row_value(
                window,
                "tau_continuation_coarse_tau_fallback_applied",
                false,
            ),
        )
        trajectory_ready = _reduced_mpcc_refinement_bool(
            _reduced_mpcc_refinement_row_value(window, "candidate_trajectory_ready", false),
        )
        residual_feasible = _reduced_mpcc_refinement_bool(
            _reduced_mpcc_refinement_row_value(window, "candidate_residual_feasible", false),
        )
        solver_status = String(_reduced_mpcc_refinement_row_value(window, "solver_status", "missing"))
        score, reasons = _reduced_mpcc_refinement_score(
            selected_tau,
            coarse_fallback,
            solver_status,
            residual_feasible,
            trajectory_ready,
            max_abs,
            max_rel,
            max_trace_rel,
            max_boundary;
            max_boundary_abs = max_boundary_abs,
            max_trace_boundary_abs = max_trace_boundary_abs,
            boundary_relative_jump_threshold = boundary_relative_jump_threshold,
            window_relative_rmse_threshold = window_relative_rmse_threshold,
            window_abs_difference_threshold = window_abs_difference_threshold,
        )
        push!(
            rows,
            Dict{String, Any}(
                "window_id" => window_id,
                "window_index" => window_index,
                "t0" => _reduced_mpcc_refinement_number(window, "t0", NaN),
                "tfinal" => _reduced_mpcc_refinement_number(window, "tfinal", NaN),
                "solver_status" => solver_status,
                "primal_status" =>
                    String(_reduced_mpcc_refinement_row_value(window, "primal_status", "missing")),
                "residual_feasible" => residual_feasible,
                "trajectory_ready" => trajectory_ready,
                "accepted_tau" => selected_tau,
                "coarse_tau_fallback" => coarse_fallback,
                "dominant_residual" =>
                    String(_reduced_mpcc_refinement_row_value(window, "dominant_residual", "missing")),
                "max_window_state_abs_difference" => max_abs,
                "dominant_abs_state" => abs_state,
                "max_window_state_relative_rmse" => max_rel,
                "dominant_relative_state" => rel_state,
                "max_trace_state_relative_rmse" => max_trace_rel,
                "dominant_trace_state" => trace_state,
                "max_boundary_relative_jump" => max_boundary,
                "dominant_boundary_state" => boundary_state,
                "max_boundary_absolute_jump" => max_boundary_abs,
                "dominant_boundary_absolute_state" => boundary_abs_state,
                "max_trace_boundary_absolute_jump" => max_trace_boundary_abs,
                "dominant_trace_boundary_state" => trace_boundary_state,
                "refinement_score" => score,
                "refinement_priority" => _reduced_mpcc_refinement_priority(score),
                "refinement_reasons" => join(reasons, ";"),
                "recommended_action" => _reduced_mpcc_refinement_action(score, reasons),
            ),
        )
    end
    candidates = DataFrame(rows)
    nrow(candidates) == 0 && return candidates
    sort!(candidates, [:refinement_score, :window_index], rev = [true, false])
    candidates[!, "refinement_rank"] = collect(1:nrow(candidates))
    select!(candidates, "refinement_rank", Not("refinement_rank"))
    return candidates
end

function _reduced_mpcc_refinement_score(
    selected_tau::Float64,
    coarse_fallback::Bool,
    solver_status::AbstractString,
    residual_feasible::Bool,
    trajectory_ready::Bool,
    max_abs::Float64,
    max_rel::Float64,
    max_trace_rel::Float64,
    max_boundary::Float64;
    max_boundary_abs::Float64,
    max_trace_boundary_abs::Float64,
    boundary_relative_jump_threshold::Float64,
    window_relative_rmse_threshold::Float64,
    window_abs_difference_threshold::Float64,
)
    score = 0.0
    reasons = String[]
    if !residual_feasible
        score += 500.0
        push!(reasons, "residual_not_feasible")
    end
    if coarse_fallback
        score += 220.0
        push!(reasons, "coarse_tau_fallback")
    elseif isfinite(selected_tau) && selected_tau > 1.0e-4
        score += 120.0
        push!(reasons, "accepted_tau_above_1e-4")
    elseif isfinite(selected_tau) && selected_tau >= 1.0e-4
        score += 35.0
        push!(reasons, "accepted_tau_1e-4")
    end
    if !trajectory_ready
        score += 30.0
        push!(reasons, "trajectory_not_ready")
    end
    normalized_status = uppercase(String(solver_status))
    if occursin("ITERATION_LIMIT", normalized_status)
        score += 35.0
        push!(reasons, "iteration_limit")
    elseif occursin("ALMOST", normalized_status)
        score += 18.0
        push!(reasons, "almost_solved")
    elseif !(normalized_status in ("LOCALLY_SOLVED", "OPTIMAL", "FEASIBLE_POINT"))
        score += 45.0
        push!(reasons, "solver_status_review")
    end
    if isfinite(max_abs) && max_abs > window_abs_difference_threshold
        score += min(120.0, 45.0 * max_abs / window_abs_difference_threshold)
        push!(reasons, "large_state_abs_difference")
    end
    if isfinite(max_rel) && max_rel > window_relative_rmse_threshold
        score += min(120.0, 45.0 * max_rel / window_relative_rmse_threshold)
        push!(reasons, "large_state_relative_rmse")
    end
    if isfinite(max_trace_rel) && max_trace_rel > 5.0 * window_relative_rmse_threshold
        score += min(30.0, 10.0 * max_trace_rel / window_relative_rmse_threshold)
        push!(reasons, "trace_relative_rmse")
    end
    if isfinite(max_boundary_abs) && max_boundary_abs > window_abs_difference_threshold
        score += min(100.0, 35.0 * max_boundary_abs / window_abs_difference_threshold)
        push!(reasons, "boundary_state_delta_change")
    elseif isfinite(max_boundary) && max_boundary > boundary_relative_jump_threshold
        score += min(30.0, 8.0 * max_boundary / boundary_relative_jump_threshold)
        push!(reasons, "boundary_serrucho")
    end
    if isfinite(max_trace_boundary_abs) && max_trace_boundary_abs > 1.0e-2
        score += min(50.0, 25.0 * max_trace_boundary_abs / 1.0e-2)
        push!(reasons, "trace_boundary_serrucho")
    end
    isempty(reasons) && push!(reasons, "low_priority_review")
    return score, reasons
end

function _reduced_mpcc_refinement_priority(score::Real)::String
    score >= 260.0 && return "high"
    score >= 120.0 && return "medium"
    return "low"
end

function _reduced_mpcc_refinement_action(score::Real, reasons::Vector{String})::String
    if "residual_not_feasible" in reasons
        return "rerun_window_with_residual_focus"
    elseif "coarse_tau_fallback" in reasons || "accepted_tau_above_1e-4" in reasons
        return "rerun_window_with_finer_tau"
    elseif "boundary_serrucho" in reasons
        return "rerun_neighbor_windows_or_add_boundary_smoothing"
    elseif score >= 90.0
        return "inspect_window_before_global_refinement"
    else
        return "keep_for_now"
    end
end

function _reduced_mpcc_refinement_max_with_state(table::DataFrame, column::AbstractString)
    if nrow(table) == 0 || !(String(column) in names(table))
        return 0.0, "missing"
    end
    values = Float64.(table[!, String(column)])
    isempty(values) && return 0.0, "missing"
    index = argmax(values)
    state = "state_name" in names(table) ? String(table[index, "state_name"]) : "missing"
    return values[index], state
end

function _reduced_mpcc_refinement_number(row, column::AbstractString, default::Float64)::Float64
    value = _reduced_mpcc_refinement_row_value(row, column, default)
    value === missing && return default
    value isa Real && return Float64(value)
    parsed = tryparse(Float64, String(value))
    return parsed === nothing ? default : parsed
end

function _reduced_mpcc_refinement_row_value(row, column::AbstractString, default)
    return String(column) in propertynames(row) || String(column) in names(parent(row)) ?
           row[String(column)] :
           default
end

function _reduced_mpcc_refinement_bool(value)::Bool
    value === missing && return false
    value isa Bool && return value
    value isa Integer && return value != 0
    normalized = lowercase(strip(String(value)))
    return normalized in ("1", "true", "yes", "y", "on")
end

function _reduced_mpcc_refinement_column_max(table::DataFrame, column::AbstractString)::Float64
    String(column) in names(table) || return 0.0
    values = Float64.(table[!, String(column)])
    isempty(values) && return 0.0
    return maximum(values)
end

function _reduced_mpcc_refinement_score_svg(
    result::ReducedDCDFBAMPCCWindowedRefinementDiagnosticResult,
)::String
    table = sort(result.window_refinement_candidates, :window_index)
    width = 1040
    height = 430
    panel = (
        left = 72.0,
        top = 58.0,
        plot_width = width - 116.0,
        plot_height = height - 132.0,
    )
    scores = Float64.(table[!, "refinement_score"])
    y_min, y_max = _expanded_limits(0.0, max(maximum(scores), eps(Float64)))
    y_scale(value) = panel.top + (y_max - value) / (y_max - y_min) * panel.plot_height
    zero_y = y_scale(0.0)
    group_width = panel.plot_width / max(nrow(table), 1)
    bar_width = min(24.0, group_width * 0.62)

    io = IOBuffer()
    _write_svg_header(io, width, height)
    _write_text(io, width / 2, 28, "Window selective-refinement score"; anchor = "middle", class = "title")
    _write_reduced_mpcc_windowed_y_axis(io, panel, y_min, y_max, y_scale)
    for (i, row) in enumerate(eachrow(table))
        score = Float64(row["refinement_score"])
        x = panel.left + (i - 0.5) * group_width - bar_width / 2
        bar_height = max(1.0, zero_y - y_scale(score))
        color = row["refinement_priority"] == "high" ? "#dc2626" :
                row["refinement_priority"] == "medium" ? "#f59e0b" : "#64748b"
        println(io, "<rect x=\"$(round(x; digits = 2))\" y=\"$(round(zero_y - bar_height; digits = 2))\" width=\"$(round(bar_width; digits = 2))\" height=\"$(round(bar_height; digits = 2))\" fill=\"$color\" />")
        if i == 1 || i == nrow(table) || i % 4 == 0
            _write_text(io, x + bar_width / 2, zero_y + 18, string(row["window_index"]); anchor = "middle", class = "tick")
        end
    end
    _write_text(io, width / 2, height - 18, "window index"; anchor = "middle", class = "axis-label")
    _write_rotated_text(io, 18, panel.top + panel.plot_height / 2, "score")
    _write_svg_footer(io)
    return String(take!(io))
end
