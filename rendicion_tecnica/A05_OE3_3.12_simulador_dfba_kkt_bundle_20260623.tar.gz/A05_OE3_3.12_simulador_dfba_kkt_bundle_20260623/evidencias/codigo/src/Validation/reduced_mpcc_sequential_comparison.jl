import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_SEQUENTIAL_COMPARISON_TYPE =
    "reduced_dcdfba_mpcc_candidate_vs_reduced_sequential_dfba"
const REDUCED_DCDFBA_MPCC_SEQUENTIAL_EXACT_BOUNDARY_ALIGNMENT =
    "exact_finite_element_boundary_times"

const REDUCED_DCDFBA_MPCC_SEQUENTIAL_SUMMARY_COLUMNS = [
    "source",
    "model_scope",
    "result_kind",
    "retcode",
    "termination_reason",
    "initial_time",
    "final_time",
    "n_time_points",
    "n_states",
    "initial_biomass",
    "final_biomass",
    "initial_glucose",
    "final_glucose",
    "initial_fructose",
    "final_fructose",
    "initial_total_sugar",
    "final_total_sugar",
    "initial_ethanol",
    "final_ethanol",
    "final_oxygen",
    "min_state_value",
    "has_negative_saved_states",
    "is_scientific_baseline",
    "is_scientific_simulation",
    "trajectory_candidate_ready",
    "candidate_residual_feasible",
    "solver_status",
    "primal_status",
]

const REDUCED_DCDFBA_MPCC_SEQUENTIAL_STATE_METRIC_COLUMNS = [
    "state_name",
    "initial_sequential",
    "initial_mpcc_candidate",
    "final_sequential",
    "final_mpcc_candidate",
    "final_difference_mpcc_minus_sequential",
    "max_abs_difference",
    "rmse",
    "relative_rmse",
    "sequential_min",
    "sequential_max",
    "mpcc_candidate_min",
    "mpcc_candidate_max",
    "notes",
]

const REDUCED_DCDFBA_MPCC_SEQUENTIAL_INTERPRETATION_NOTE =
    "This compares a reduced MPCC trajectory candidate against reduced sequential DFBA. " *
    "It is a short diagnostic state comparison only; it is not a full-model scientific baseline."

"""
    ReducedDCDFBAMPCCSequentialComparisonResult

State-only comparison between a reduced MPCC trajectory candidate and a reduced
sequential DFBA reference on matching finite-element boundary times. Fluxes are
not compared by this report.
"""
struct ReducedDCDFBAMPCCSequentialComparisonResult
    sequential_result::SimulationResult
    trajectory_candidate::ReducedDCDFBAMPCCTrajectoryCandidate
    summary_table::DataFrame
    state_metrics_table::DataFrame
    aligned_timeseries_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    compare_reduced_dcdfba_mpcc_to_sequential(sequential_result, trajectory_candidate; kwargs...)

Compare a reduced MPCC trajectory candidate against an already-computed reduced
sequential DFBA result. The current alignment policy requires exact matching
finite-element boundary times.
"""
function compare_reduced_dcdfba_mpcc_to_sequential(
    sequential_result::SimulationResult,
    trajectory_candidate::ReducedDCDFBAMPCCTrajectoryCandidate;
    alignment_policy::AbstractString = REDUCED_DCDFBA_MPCC_SEQUENTIAL_EXACT_BOUNDARY_ALIGNMENT,
)::ReducedDCDFBAMPCCSequentialComparisonResult
    normalized_policy = _reduced_mpcc_seq_validate_alignment_policy(alignment_policy)
    state_names = _reduced_mpcc_seq_validate_results(sequential_result, trajectory_candidate)
    metric_names = vcat(state_names, "total_sugar")
    summary_table = _reduced_mpcc_seq_summary_table(sequential_result, trajectory_candidate)
    state_metrics_table = _reduced_mpcc_seq_state_metrics_table(
        sequential_result,
        trajectory_candidate.boundary_result,
        metric_names,
    )
    aligned_timeseries_table = _reduced_mpcc_seq_timeseries_table(
        sequential_result,
        trajectory_candidate.boundary_result,
        metric_names,
    )
    metadata = _reduced_mpcc_seq_metadata(
        sequential_result,
        trajectory_candidate,
        state_names,
        state_metrics_table;
        alignment_policy = normalized_policy,
    )

    return ReducedDCDFBAMPCCSequentialComparisonResult(
        sequential_result,
        trajectory_candidate,
        summary_table,
        state_metrics_table,
        aligned_timeseries_table,
        metadata,
    )
end

"""
    compare_reduced_dcdfba_mpcc_to_sequential(model, reaction_map; kwargs...)

Run a short reduced sequential DFBA reference, use it to initialize the reduced
MPCC solve attempt, extract a trajectory candidate, and compare boundary-state
values. This remains diagnostic and does not claim a solved MPCC simulation.
"""
function compare_reduced_dcdfba_mpcc_to_sequential(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    tspan::Tuple{Float64, Float64} = (0.0, 0.25),
    nfe::Int = 1,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_saveat = nothing,
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    silent::Bool = true,
)::ReducedDCDFBAMPCCSequentialComparisonResult
    nfe > 0 || throw(ArgumentError("Reduced MPCC sequential comparison nfe must be positive."))
    saveat = sequential_saveat === nothing ? (tspan[2] - tspan[1]) / nfe : sequential_saveat
    sequential_result = simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = tspan,
        params = params,
        optimizer = sequential_optimizer,
        silent = silent,
        lp_atol = sequential_lp_atol,
        ode_abstol = sequential_ode_abstol,
        ode_reltol = sequential_ode_reltol,
        saveat = saveat,
        algorithm = sequential_algorithm,
        adaptive = sequential_adaptive,
        dt = sequential_dt,
        nonnegative = sequential_nonnegative,
        stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        reconstruct_fluxes = sequential_reconstruct_fluxes,
        model_scope = "reduced",
    )
    solve_attempt = solve_reduced_dcdfba_mpcc_solve_attempt(
        model,
        reaction_map;
        sequential_initialization = sequential_result,
        tspan = tspan,
        nfe = nfe,
        degree = degree,
        residual_thresholds = residual_thresholds,
        optimizer = mpcc_optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        require_pre_solve_ready = require_pre_solve_ready,
        silent = silent,
    )
    trajectory_candidate = extract_reduced_dcdfba_mpcc_trajectory_candidate(solve_attempt)
    return compare_reduced_dcdfba_mpcc_to_sequential(sequential_result, trajectory_candidate)
end

function _reduced_mpcc_seq_validate_alignment_policy(alignment_policy::AbstractString)::String
    normalized = strip(String(alignment_policy))
    normalized == REDUCED_DCDFBA_MPCC_SEQUENTIAL_EXACT_BOUNDARY_ALIGNMENT || throw(
        ArgumentError(
            "Unsupported reduced MPCC sequential comparison alignment_policy: $(alignment_policy). " *
            "Only $(REDUCED_DCDFBA_MPCC_SEQUENTIAL_EXACT_BOUNDARY_ALIGNMENT) is implemented.",
        ),
    )
    return normalized
end

function _reduced_mpcc_seq_validate_results(
    sequential_result::SimulationResult,
    trajectory_candidate::ReducedDCDFBAMPCCTrajectoryCandidate,
)::Vector{String}
    candidate_result = trajectory_candidate.boundary_result
    _reduced_mpcc_seq_times_match(sequential_result.time, candidate_result.time) || throw(
        ArgumentError(
            "Reduced MPCC sequential comparison requires sequential saved times to match " *
            "MPCC finite-element boundary times. Got sequential=$(sequential_result.time) " *
            "and candidate=$(candidate_result.time).",
        ),
    )
    size(sequential_result.states, 1) == 19 || throw(
        ArgumentError(
            "Reduced MPCC sequential comparison expects sequential states to have 19 rows, " *
            "got $(size(sequential_result.states, 1)).",
        ),
    )
    size(candidate_result.states, 1) == 19 || throw(
        ArgumentError(
            "Reduced MPCC sequential comparison expects candidate states to have 19 rows, " *
            "got $(size(candidate_result.states, 1)).",
        ),
    )
    size(sequential_result.states, 2) == length(sequential_result.time) || throw(
        ArgumentError("Sequential state column count does not match saved times."),
    )
    size(candidate_result.states, 2) == length(candidate_result.time) || throw(
        ArgumentError("Candidate state column count does not match boundary times."),
    )

    sequential_names = _state_names(sequential_result)
    candidate_names = _state_names(candidate_result)
    sequential_names == candidate_names || throw(
        ArgumentError(
            "Reduced MPCC sequential comparison requires matching state names. " *
            "Got sequential=$(sequential_names) and candidate=$(candidate_names).",
        ),
    )
    length(sequential_names) == 19 || throw(
        ArgumentError(
            "Reduced MPCC sequential comparison expects 19 state names, got $(length(sequential_names)).",
        ),
    )
    return sequential_names
end

function _reduced_mpcc_seq_times_match(a::AbstractVector, b::AbstractVector)::Bool
    length(a) == length(b) || return false
    return all(isapprox(Float64(a[i]), Float64(b[i]); atol = 1.0e-10, rtol = 0.0) for i in eachindex(a))
end

function _reduced_mpcc_seq_summary_table(
    sequential_result::SimulationResult,
    trajectory_candidate::ReducedDCDFBAMPCCTrajectoryCandidate,
)::DataFrame
    rows = [
        _reduced_mpcc_seq_summary_row(
            "reduced_sequential_dfba",
            "sequential_reference",
            sequential_result,
            trajectory_candidate,
        ),
        _reduced_mpcc_seq_summary_row(
            "reduced_mpcc_trajectory_candidate",
            "mpcc_boundary_candidate",
            trajectory_candidate.boundary_result,
            trajectory_candidate,
        ),
    ]
    return DataFrame(
        (
            column => [_reduced_mpcc_seq_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_SEQUENTIAL_SUMMARY_COLUMNS
        )...,
    )
end

function _reduced_mpcc_seq_summary_row(
    source::AbstractString,
    result_kind::AbstractString,
    result::SimulationResult,
    trajectory_candidate::ReducedDCDFBAMPCCTrajectoryCandidate,
)::Dict{String, Any}
    summary = summarize_simulation(result)
    is_candidate = String(source) == "reduced_mpcc_trajectory_candidate"
    candidate_metadata = trajectory_candidate.metadata
    return Dict{String, Any}(
        "source" => String(source),
        "model_scope" => get(summary, "model_scope", "unknown"),
        "result_kind" => String(result_kind),
        "retcode" => get(summary, "retcode", missing),
        "termination_reason" => get(summary, "termination_reason", missing),
        "initial_time" => get(summary, "initial_time", missing),
        "final_time" => get(summary, "final_time", missing),
        "n_time_points" => get(summary, "n_saved_points", missing),
        "n_states" => get(summary, "n_states", missing),
        "initial_biomass" => get(summary, "initial_biomass", missing),
        "final_biomass" => get(summary, "final_biomass", missing),
        "initial_glucose" => get(summary, "initial_glucose", missing),
        "final_glucose" => get(summary, "final_glucose", missing),
        "initial_fructose" => get(summary, "initial_fructose", missing),
        "final_fructose" => get(summary, "final_fructose", missing),
        "initial_total_sugar" => get(summary, "initial_total_sugar", missing),
        "final_total_sugar" => get(summary, "final_total_sugar", missing),
        "initial_ethanol" => get(summary, "initial_ethanol", missing),
        "final_ethanol" => get(summary, "final_ethanol", missing),
        "final_oxygen" => get(summary, "final_oxygen", missing),
        "min_state_value" => get(summary, "min_state_value", missing),
        "has_negative_saved_states" => get(summary, "has_negative_saved_states", missing),
        "is_scientific_baseline" => false,
        "is_scientific_simulation" => get(result.metadata, "is_scientific_simulation", !is_candidate),
        "trajectory_candidate_ready" =>
            is_candidate ? get(candidate_metadata, "trajectory_candidate_ready", false) : missing,
        "candidate_residual_feasible" =>
            is_candidate ? get(candidate_metadata, "candidate_residual_feasible", false) : missing,
        "solver_status" =>
            is_candidate ? get(candidate_metadata, "candidate_solver_status", missing) : missing,
        "primal_status" =>
            is_candidate ? get(candidate_metadata, "candidate_primal_status", missing) : missing,
    )
end

function _reduced_mpcc_seq_state_metrics_table(
    sequential_result::SimulationResult,
    candidate_result::SimulationResult,
    metric_names::Vector{String},
)::DataFrame
    rows = [
        _reduced_mpcc_seq_state_metric_row(
            metric_name,
            _reduced_mpcc_seq_state_or_total_sugar(sequential_result, metric_name),
            _reduced_mpcc_seq_state_or_total_sugar(candidate_result, metric_name),
        ) for metric_name in metric_names
    ]
    return DataFrame(
        (
            column => [_reduced_mpcc_seq_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_SEQUENTIAL_STATE_METRIC_COLUMNS
        )...,
    )
end

function _reduced_mpcc_seq_state_metric_row(
    state_name::AbstractString,
    sequential_values::AbstractVector,
    candidate_values::AbstractVector,
)::Dict{String, Any}
    sequential = Float64.(collect(sequential_values))
    candidate = Float64.(collect(candidate_values))
    length(sequential) == length(candidate) || throw(
        ArgumentError("Reduced MPCC sequential comparison state $(String(state_name)) has mismatched lengths."),
    )
    difference = candidate .- sequential
    rmse = sqrt(sum(abs2, difference) / length(difference))
    denominator = max(maximum(abs.(sequential)), maximum(abs.(candidate)), eps(Float64))
    return Dict{String, Any}(
        "state_name" => String(state_name),
        "initial_sequential" => sequential[begin],
        "initial_mpcc_candidate" => candidate[begin],
        "final_sequential" => sequential[end],
        "final_mpcc_candidate" => candidate[end],
        "final_difference_mpcc_minus_sequential" => difference[end],
        "max_abs_difference" => maximum(abs.(difference)),
        "rmse" => rmse,
        "relative_rmse" => rmse / denominator,
        "sequential_min" => minimum(sequential),
        "sequential_max" => maximum(sequential),
        "mpcc_candidate_min" => minimum(candidate),
        "mpcc_candidate_max" => maximum(candidate),
        "notes" => _reduced_mpcc_seq_state_note(state_name),
    )
end

function _reduced_mpcc_seq_timeseries_table(
    sequential_result::SimulationResult,
    candidate_result::SimulationResult,
    metric_names::Vector{String},
)::DataFrame
    table = DataFrame("time" => copy(sequential_result.time))
    for metric_name in metric_names
        sequential = _reduced_mpcc_seq_state_or_total_sugar(sequential_result, metric_name)
        candidate = _reduced_mpcc_seq_state_or_total_sugar(candidate_result, metric_name)
        prefix = lowercase(String(metric_name))
        table[!, "$(prefix)_sequential"] = sequential
        table[!, "$(prefix)_mpcc_candidate"] = candidate
        table[!, "$(prefix)_difference_mpcc_minus_sequential"] = candidate .- sequential
    end
    return table
end

function _reduced_mpcc_seq_state_or_total_sugar(
    result::SimulationResult,
    state_name::AbstractString,
)::Vector{Float64}
    normalized = String(state_name)
    if normalized == "total_sugar"
        glucose_index = findfirst(==("glucose"), _state_names(result))
        fructose_index = findfirst(==("fructose"), _state_names(result))
        glucose_index === nothing && throw(ArgumentError("SimulationResult is missing glucose state."))
        fructose_index === nothing && throw(ArgumentError("SimulationResult is missing fructose state."))
        return Float64.(result.states[glucose_index, :] .+ result.states[fructose_index, :])
    end
    index = findfirst(==(normalized), _state_names(result))
    index === nothing && throw(ArgumentError("SimulationResult is missing state $(normalized)."))
    return Float64.(result.states[index, :])
end

function _reduced_mpcc_seq_metadata(
    sequential_result::SimulationResult,
    trajectory_candidate::ReducedDCDFBAMPCCTrajectoryCandidate,
    state_names::Vector{String},
    state_metrics_table::DataFrame;
    alignment_policy::AbstractString,
)::Dict{String, Any}
    candidate_metadata = trajectory_candidate.metadata
    return Dict{String, Any}(
        "comparison_type" => REDUCED_DCDFBA_MPCC_SEQUENTIAL_COMPARISON_TYPE,
        "reference_source" => "reduced_sequential_dfba",
        "candidate_source" => "reduced_mpcc_trajectory_candidate",
        "alignment_policy" => String(alignment_policy),
        "state_names" => copy(state_names),
        "metric_names" => vcat(state_names, "total_sugar"),
        "n_states" => length(state_names),
        "n_metric_rows" => nrow(state_metrics_table),
        "n_time_points" => length(sequential_result.time),
        "initial_time" => first(sequential_result.time),
        "final_time" => last(sequential_result.time),
        "reference_model_scope" => get(sequential_result.metadata, "model_scope", "unknown"),
        "candidate_model_scope" => get(trajectory_candidate.boundary_result.metadata, "model_scope", "unknown"),
        "reference_is_scientific_baseline" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "candidate_is_scientific_simulation" =>
            get(candidate_metadata, "trajectory_candidate_is_scientific_simulation", false),
        "candidate_is_validated_simulation" =>
            get(candidate_metadata, "trajectory_candidate_is_validated_simulation", false),
        "candidate_solved_trajectory_claimed" =>
            get(candidate_metadata, "trajectory_candidate_solved_trajectory_claimed", false),
        "candidate_trajectory_ready" =>
            get(candidate_metadata, "trajectory_candidate_ready", false),
        "candidate_residual_feasible" =>
            get(candidate_metadata, "candidate_residual_feasible", false),
        "candidate_iteration_limit_residual_feasible" =>
            get(candidate_metadata, "candidate_iteration_limit_residual_feasible", false),
        "candidate_solver_status" =>
            get(candidate_metadata, "candidate_solver_status", "unknown"),
        "candidate_primal_status" =>
            get(candidate_metadata, "candidate_primal_status", "unknown"),
        "candidate_warning_count" =>
            get(candidate_metadata, "candidate_warning_count", 0),
        "max_state_abs_difference" => maximum(Float64.(state_metrics_table[!, "max_abs_difference"])),
        "max_state_rmse" => maximum(Float64.(state_metrics_table[!, "rmse"])),
        "max_state_relative_rmse" => maximum(Float64.(state_metrics_table[!, "relative_rmse"])),
        "flux_comparison_included" => false,
        "flux_comparison_deferred_reason" =>
            "reduced MPCC full flux array remains in candidate_diagnostics.flux",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "oxygen_mapping_note" => SEQUENTIAL_DFBA_OXYGEN_NOTE,
        "carbohydrate_mapping_note" => SEQUENTIAL_DFBA_CARBOHYDRATE_NOTE,
        "interpretation_note" => REDUCED_DCDFBA_MPCC_SEQUENTIAL_INTERPRETATION_NOTE,
    )
end

function _reduced_mpcc_seq_state_note(state_name::AbstractString)::String
    normalized = String(state_name)
    if normalized == "oxygen"
        return SEQUENTIAL_DFBA_OXYGEN_NOTE
    elseif normalized == "carbohydrate"
        return SEQUENTIAL_DFBA_CARBOHYDRATE_NOTE
    elseif normalized == "total_sugar"
        return "total_sugar is glucose + fructose and is included as a derived comparison metric"
    else
        return ""
    end
end

function _reduced_mpcc_seq_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
