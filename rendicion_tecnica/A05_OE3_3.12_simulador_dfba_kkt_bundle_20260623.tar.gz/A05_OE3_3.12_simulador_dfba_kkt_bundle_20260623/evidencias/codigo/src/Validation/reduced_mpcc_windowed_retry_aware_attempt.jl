import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_AWARE_ATTEMPT_TYPE =
    "reduced_dcdfba_mpcc_windowed_retry_aware_attempt"

const REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_AWARE_ATTEMPT_COLUMNS = [
    "candidate_id",
    "source_type",
    "target_horizon",
    "horizon_reached",
    "target_completed",
    "base_attempt_traffic_light",
    "base_attempt_viable",
    "retry_aware_traffic_light",
    "retry_aware_viable",
    "retry_policy_applied",
    "retry_replacement_recommended",
    "retry_replacement_applied",
    "windowed_candidate_rebuilt",
    "n_selected_windows",
    "n_retried_windows",
    "green_recovered_count",
    "trajectory_ready_recovered_count",
    "residual_feasible_recovered_count",
    "all_selected_windows_recovered_green",
    "all_selected_windows_recovered_trajectory_ready",
    "first_unrecovered_window_id",
    "first_unrecovered_window_index",
    "recommended_next_action",
    "outputs_written",
    "retry_aware_attempt_is_scientific_simulation",
    "solved_trajectory_claimed",
    "first_mpcc_target",
    "full_model_kkt_deferred",
    "dfvb_kkt_deferred",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
]

"""
    ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult

Integrated diagnostic wrapper for a reduced MPCC windowed attempt plus
multi-window retry-policy diagnostics. It reports whether local retries appear
promising, but it does not replace window candidates, rebuild the windowed
trajectory, relax thresholds, write outputs, or validate a scientific
simulation.
"""
struct ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult
    base_attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    retry_policy_diagnostic::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult
    summary_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(attempt, retry_policy)

Combine an already-computed reduced MPCC windowed attempt with its retry-policy
diagnostic into one retry-aware attempt summary.
"""
function attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult,
)::ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult
    retry_policy.source_attempt === attempt || throw(
        ArgumentError("Reduced MPCC retry-aware windowed attempt requires retry_policy.source_attempt === attempt."),
    )
    metadata = _reduced_mpcc_windowed_retry_aware_metadata(attempt, retry_policy)
    return ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult(
        attempt,
        retry_policy,
        _reduced_mpcc_windowed_retry_aware_table(metadata),
        metadata,
    )
end

"""
    attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(model, reaction_map; kwargs...)

Run a reduced MPCC windowed target-horizon attempt, apply the retry-policy
diagnostic to selected problematic windows, and return an integrated summary.
This is still diagnostic-only: retry replacements are not applied to the
windowed candidate in this block.
"""
function attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    target_horizon::Real = 72.0,
    t0::Real = 0.0,
    window_hours::Real = 0.5,
    nfe_per_window::Int = 2,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    tau_schedule = nothing,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        ),
    retry_window_indices = nothing,
    retry_selection_policy::AbstractString = "iteration_limit_or_not_ready",
    retry_max_windows::Int = 3,
    retry_ipopt_max_iter_values = [200, 300],
    silent::Bool = true,
    continue_on_error::Bool = true,
    window_callback = nothing,
)::ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult
    base_attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        model,
        reaction_map;
        target_horizon = target_horizon,
        t0 = t0,
        window_hours = window_hours,
        nfe_per_window = nfe_per_window,
        degree = degree,
        y0 = y0,
        params = params,
        sequential_optimizer = sequential_optimizer,
        sequential_algorithm = sequential_algorithm,
        sequential_ode_abstol = sequential_ode_abstol,
        sequential_ode_reltol = sequential_ode_reltol,
        sequential_lp_atol = sequential_lp_atol,
        sequential_adaptive = sequential_adaptive,
        sequential_dt = sequential_dt,
        sequential_nonnegative = sequential_nonnegative,
        sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
        mpcc_optimizer = mpcc_optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        tau_schedule = tau_schedule,
        require_pre_solve_ready = require_pre_solve_ready,
        residual_thresholds = residual_thresholds,
        continuation_acceptance_policy = continuation_acceptance_policy,
        continuation_state_relative_rmse_threshold =
            continuation_state_relative_rmse_threshold,
        viability_thresholds = viability_thresholds,
        silent = silent,
        continue_on_error = continue_on_error,
        window_callback = window_callback,
    )
    retry_policy = diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        base_attempt,
        model,
        reaction_map;
        window_indices = retry_window_indices,
        selection_policy = retry_selection_policy,
        max_retry_windows = retry_max_windows,
        ipopt_max_iter_values = retry_ipopt_max_iter_values,
        params = params,
        sequential_optimizer = sequential_optimizer,
        sequential_algorithm = sequential_algorithm,
        sequential_ode_abstol = sequential_ode_abstol,
        sequential_ode_reltol = sequential_ode_reltol,
        sequential_lp_atol = sequential_lp_atol,
        sequential_adaptive = sequential_adaptive,
        sequential_dt = sequential_dt,
        sequential_nonnegative = sequential_nonnegative,
        sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
        mpcc_optimizer = mpcc_optimizer,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        tau_schedule = tau_schedule,
        require_pre_solve_ready = require_pre_solve_ready,
        residual_thresholds = residual_thresholds,
        viability_thresholds = viability_thresholds,
        silent = silent,
        continue_on_error = continue_on_error,
    )
    return attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
        base_attempt,
        retry_policy,
    )
end

function _reduced_mpcc_windowed_retry_aware_metadata(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult,
)::Dict{String, Any}
    retry_metadata = retry_policy.metadata
    base_light = String(get(attempt.metadata, "attempt_traffic_light", "red"))
    base_viable = get(attempt.metadata, "attempt_viable", false) === true
    selected_count = _reduced_mpcc_windowed_retry_aware_int(
        get(retry_metadata, "n_selected_windows", 0),
    )
    green_recovered_count = _reduced_mpcc_windowed_retry_aware_int(
        get(retry_metadata, "green_recovered_count", 0),
    )
    trajectory_recovered_count = _reduced_mpcc_windowed_retry_aware_int(
        get(retry_metadata, "trajectory_ready_recovered_count", 0),
    )
    all_recovered_green =
        get(retry_metadata, "all_selected_windows_recovered_green", false) === true
    all_recovered_trajectory =
        get(retry_metadata, "all_selected_windows_recovered_trajectory_ready", false) === true
    retry_policy_applied = selected_count > 0
    replacement_recommended =
        !base_viable && retry_policy_applied && (all_recovered_green || all_recovered_trajectory)
    retry_light = _reduced_mpcc_windowed_retry_aware_light(
        base_light,
        base_viable,
        retry_policy_applied,
        replacement_recommended,
        green_recovered_count,
        trajectory_recovered_count,
    )
    retry_viable = base_viable
    return Dict{String, Any}(
        "attempt_type" => REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_AWARE_ATTEMPT_TYPE,
        "candidate_id" => "retry_aware_windowed_attempt",
        "source_type" => "windowed_attempt_with_retry_policy",
        "target_horizon" => get(attempt.metadata, "target_horizon", missing),
        "horizon_reached" => get(attempt.metadata, "horizon_reached", missing),
        "target_completed" => get(attempt.metadata, "target_completed", missing),
        "base_attempt_traffic_light" => base_light,
        "base_attempt_viable" => base_viable,
        "retry_aware_traffic_light" => retry_light,
        "retry_aware_viable" => retry_viable,
        "retry_policy_applied" => retry_policy_applied,
        "retry_replacement_recommended" => replacement_recommended,
        "retry_replacement_applied" => false,
        "windowed_candidate_rebuilt" => false,
        "n_selected_windows" => selected_count,
        "n_retried_windows" => get(retry_metadata, "n_retried_windows", 0),
        "green_recovered_count" => green_recovered_count,
        "trajectory_ready_recovered_count" => trajectory_recovered_count,
        "residual_feasible_recovered_count" =>
            get(retry_metadata, "residual_feasible_recovered_count", 0),
        "all_selected_windows_recovered_green" => all_recovered_green,
        "all_selected_windows_recovered_trajectory_ready" => all_recovered_trajectory,
        "first_unrecovered_window_id" =>
            get(retry_metadata, "first_unrecovered_window_id", missing),
        "first_unrecovered_window_index" =>
            get(retry_metadata, "first_unrecovered_window_index", missing),
        "retry_policy_recommended_next_action" =>
            get(retry_metadata, "recommended_next_action", missing),
        "recommended_next_action" =>
            _reduced_mpcc_windowed_retry_aware_recommended_action(
                base_viable,
                retry_policy_applied,
                replacement_recommended,
                green_recovered_count,
                trajectory_recovered_count,
            ),
        "outputs_written" => false,
        "retry_aware_attempt_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC retry-aware windowed attempt; local retry results are summarized but not applied to rebuild the candidate trajectory.",
    )
end

function _reduced_mpcc_windowed_retry_aware_light(
    base_light::String,
    base_viable::Bool,
    retry_policy_applied::Bool,
    replacement_recommended::Bool,
    green_recovered_count::Int,
    trajectory_recovered_count::Int,
)::String
    base_viable && return "green"
    replacement_recommended && return "yellow"
    (green_recovered_count > 0 || trajectory_recovered_count > 0) && return "yellow"
    retry_policy_applied && return base_light == "green" ? "yellow" : base_light
    return base_light
end

function _reduced_mpcc_windowed_retry_aware_recommended_action(
    base_viable::Bool,
    retry_policy_applied::Bool,
    replacement_recommended::Bool,
    green_recovered_count::Int,
    trajectory_recovered_count::Int,
)::String
    base_viable && return "review_base_green_windowed_candidate_before_scientific_use"
    retry_policy_applied || return "inspect_base_windowed_attempt_without_retry_candidates"
    replacement_recommended && return "apply_retry_replacements_and_reassess_windowed_candidate"
    (green_recovered_count > 0 || trajectory_recovered_count > 0) &&
        return "review_partial_retry_recovery_before_replacement"
    return "inspect_solver_scaling_before_retry_replacement"
end

function _reduced_mpcc_windowed_retry_aware_int(value)::Int
    value === missing && return 0
    value === nothing && return 0
    return try
        Int(value)
    catch
        0
    end
end

function _reduced_mpcc_windowed_retry_aware_table(metadata::Dict{String, Any})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_windowed_retry_aware_table_scalar(get(metadata, column, missing))] for
            column in REDUCED_DCDFBA_MPCC_WINDOWED_RETRY_AWARE_ATTEMPT_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_retry_aware_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
