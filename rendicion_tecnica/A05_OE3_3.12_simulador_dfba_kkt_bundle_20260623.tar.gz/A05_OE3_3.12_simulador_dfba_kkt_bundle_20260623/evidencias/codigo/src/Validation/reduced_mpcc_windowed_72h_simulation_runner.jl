import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_72H_SIMULATION_RUNNER_TYPE =
    "reduced_dcdfba_mpcc_windowed_72h_simulation_runner"

const REDUCED_DCDFBA_MPCC_WINDOWED_72H_SIMULATION_RUNNER_COLUMNS = [
    "runner_id",
    "target_horizon",
    "target_is_72h",
    "window_hours",
    "nfe_per_window",
    "degree",
    "ipopt_profile",
    "ipopt_max_iter",
    "n_requested_windows",
    "n_completed_windows",
    "n_failed_windows",
    "horizon_reached",
    "horizon_gap",
    "target_completed",
    "runner_traffic_light",
    "runner_status",
    "runner_viable",
    "candidate_ready_for_review",
    "boundary_candidate_available",
    "sequential_reference_available",
    "global_state_metrics_available",
    "global_max_state_relative_rmse",
    "total_solve_elapsed_seconds",
    "recommended_next_action",
    "outputs_written",
    "runner_is_scientific_simulation",
    "solved_trajectory_claimed",
    "scientific_baseline",
    "first_mpcc_target",
    "full_model_kkt_deferred",
    "dfvb_kkt_deferred",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "global_monolithic_mpcc_solve_attempted",
    "global_polish_deferred",
]

"""
    ReducedDCDFBAMPCCWindowed72HSimulationRunnerResult

In-memory runner result for the reduced MPCC 72-hour windowed path. The runner
wraps a target-horizon windowed attempt, exposes the concatenated boundary
candidate and reduced sequential reference when available, and records that no
monolithic global polish, full-model KKT, DFVB KKT, HSL, file output, or
scientific simulation claim is introduced.
"""
struct ReducedDCDFBAMPCCWindowed72HSimulationRunnerResult
    attempt_result::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    boundary_result::Union{Nothing, SimulationResult}
    sequential_reference::Union{Nothing, SimulationResult}
    runner_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    run_reduced_dcdfba_mpcc_windowed_72h_simulation(attempt; expected_target_horizon=nothing)

Classify an already-computed reduced MPCC windowed target-horizon attempt as a
72-hour windowed simulation-runner result. This overload is deterministic and
does not run a solver.
"""
function run_reduced_dcdfba_mpcc_windowed_72h_simulation(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult;
    expected_target_horizon::Union{Nothing, Real} = nothing,
)::ReducedDCDFBAMPCCWindowed72HSimulationRunnerResult
    _reduced_mpcc_windowed_72h_runner_validate_expected_target(
        attempt,
        expected_target_horizon,
    )
    return _reduced_mpcc_windowed_72h_runner_result(attempt)
end

"""
    run_reduced_dcdfba_mpcc_windowed_72h_simulation(continuation; target_horizon=72.0, kwargs...)

Classify an existing reduced MPCC windowed continuation as a target-horizon
runner by first applying the simulation-viability semaphore. This overload does
not run a solver.
"""
function run_reduced_dcdfba_mpcc_windowed_72h_simulation(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult;
    target_horizon::Real = 72.0,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(),
)::ReducedDCDFBAMPCCWindowed72HSimulationRunnerResult
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = target_horizon,
        thresholds = thresholds,
    )
    return _reduced_mpcc_windowed_72h_runner_result(attempt)
end

"""
    run_reduced_dcdfba_mpcc_windowed_72h_simulation(model, reaction_map; target_horizon=72.0, kwargs...)

Run the reduced MPCC windowed path sized for a target horizon, defaulting to
72 hours. This is a serial windowed reduced-MPCC runner: each short window is
solved independently with chained boundary states, then the concatenated
candidate is classified in memory. It intentionally does not run the monolithic
global MPCC polish, does not write outputs, and does not claim a validated
scientific simultaneous DFBA simulation.
"""
function run_reduced_dcdfba_mpcc_windowed_72h_simulation(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    target_horizon::Real = 72.0,
    t0::Real = 0.0,
    window_hours::Real = 0.5,
    nfe_per_window::Int = 2,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    tau_schedule = nothing,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        ),
    silent::Bool = true,
    continue_on_error::Bool = true,
    window_callback = nothing,
)::ReducedDCDFBAMPCCWindowed72HSimulationRunnerResult
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        model,
        reaction_map;
        target_horizon = target_horizon,
        t0 = t0,
        window_hours = window_hours,
        nfe_per_window = nfe_per_window,
        degree = degree,
        y0 = y0,
        params = params,
        sequential_optimizer = sequential_optimizer,
        sequential_algorithm = sequential_algorithm,
        sequential_ode_abstol = sequential_ode_abstol,
        sequential_ode_reltol = sequential_ode_reltol,
        sequential_lp_atol = sequential_lp_atol,
        sequential_adaptive = sequential_adaptive,
        sequential_dt = sequential_dt,
        sequential_nonnegative = sequential_nonnegative,
        sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
        mpcc_optimizer = mpcc_optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        complementarity_tau_gate_tol = complementarity_tau_gate_tol,
        tau_schedule = tau_schedule,
        require_pre_solve_ready = require_pre_solve_ready,
        residual_thresholds = residual_thresholds,
        continuation_acceptance_policy = continuation_acceptance_policy,
        continuation_state_relative_rmse_threshold =
            continuation_state_relative_rmse_threshold,
        viability_thresholds = viability_thresholds,
        silent = silent,
        continue_on_error = continue_on_error,
        window_callback = window_callback,
    )
    return _reduced_mpcc_windowed_72h_runner_result(attempt)
end

function _reduced_mpcc_windowed_72h_runner_result(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
)::ReducedDCDFBAMPCCWindowed72HSimulationRunnerResult
    continuation = attempt.continuation_result
    boundary = continuation.boundary_candidate
    reference = continuation.sequential_reference
    metadata = _reduced_mpcc_windowed_72h_runner_metadata(attempt, boundary, reference)
    table = _reduced_mpcc_windowed_72h_runner_table(metadata)
    return ReducedDCDFBAMPCCWindowed72HSimulationRunnerResult(
        attempt,
        boundary,
        reference,
        table,
        metadata,
    )
end

function _reduced_mpcc_windowed_72h_runner_metadata(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    boundary,
    reference,
)::Dict{String, Any}
    attempt_metadata = attempt.metadata
    continuation_metadata = attempt.continuation_result.metadata
    target_horizon = get(attempt_metadata, "target_horizon", missing)
    target_completed = get(attempt_metadata, "target_completed", false) === true
    attempt_light = string(get(attempt_metadata, "attempt_traffic_light", "missing"))
    boundary_available = boundary !== nothing
    reference_available = reference !== nothing
    candidate_ready = target_completed && attempt_light == "green" && boundary_available
    runner_status = _reduced_mpcc_windowed_72h_runner_status(
        candidate_ready,
        target_completed,
        attempt_light,
        boundary_available,
    )

    return Dict{String, Any}(
        "runner_type" => REDUCED_DCDFBA_MPCC_WINDOWED_72H_SIMULATION_RUNNER_TYPE,
        "runner_strategy" => "serial_windowed_reduced_mpcc_continuation",
        "runner_scope" => "reduced_dfba_windowed_candidate",
        "attempt_type" => get(attempt_metadata, "attempt_type", missing),
        "target_horizon" => target_horizon,
        "target_is_72h" =>
            _reduced_mpcc_windowed_72h_runner_is_target_72h(target_horizon),
        "window_hours" => get(attempt_metadata, "window_hours", missing),
        "nfe_per_window" => get(attempt_metadata, "nfe_per_window", missing),
        "degree" => get(attempt_metadata, "degree", missing),
        "ipopt_profile" => get(attempt_metadata, "ipopt_profile", missing),
        "ipopt_profile_env" => get(
            attempt_metadata,
            "ipopt_profile_env",
            REDUCED_DCDFBA_MPCC_IPOPT_PROFILE_ENV,
        ),
        "ipopt_max_iter" =>
            _reduced_mpcc_windowed_72h_runner_first_solve_attempt_metadata(
                attempt,
                "solve_attempt_ipopt_max_iter",
            ),
        "n_requested_windows" => get(attempt_metadata, "n_requested_windows", missing),
        "n_completed_windows" => get(attempt_metadata, "n_completed_windows", missing),
        "n_failed_windows" => get(attempt_metadata, "n_failed_windows", missing),
        "horizon_reached" => get(attempt_metadata, "horizon_reached", missing),
        "horizon_gap" => get(attempt_metadata, "horizon_gap", missing),
        "target_completion_fraction" =>
            get(attempt_metadata, "target_completion_fraction", missing),
        "target_completed" => target_completed,
        "runner_traffic_light" => attempt_light,
        "runner_status" => runner_status,
        "runner_viable" => candidate_ready,
        "candidate_ready_for_review" => candidate_ready,
        "boundary_candidate_available" => boundary_available,
        "sequential_reference_available" => reference_available,
        "global_state_metrics_available" =>
            get(continuation_metadata, "global_state_metrics_available", false),
        "global_max_state_abs_difference" =>
            get(continuation_metadata, "global_max_state_abs_difference", missing),
        "global_max_state_relative_rmse" =>
            get(continuation_metadata, "global_max_state_relative_rmse", missing),
        "total_solve_elapsed_seconds" =>
            get(attempt_metadata, "total_solve_elapsed_seconds", missing),
        "continuation_acceptance_policy" =>
            get(attempt_metadata, "continuation_acceptance_policy", missing),
        "continuation_state_relative_rmse_threshold" =>
            get(attempt_metadata, "continuation_state_relative_rmse_threshold", missing),
        "continuation_state_drift_gate_enabled" =>
            get(attempt_metadata, "continuation_state_drift_gate_enabled", false),
        "window_green_count" => get(attempt_metadata, "window_green_count", missing),
        "window_yellow_count" => get(attempt_metadata, "window_yellow_count", missing),
        "window_red_count" => get(attempt_metadata, "window_red_count", missing),
        "first_non_green_window_id" =>
            get(attempt_metadata, "first_non_green_window_id", missing),
        "first_red_window_id" => get(attempt_metadata, "first_red_window_id", missing),
        "first_not_residual_feasible_window_id" =>
            get(attempt_metadata, "first_not_residual_feasible_window_id", missing),
        "recommended_next_action" =>
            _reduced_mpcc_windowed_72h_runner_recommended_action(
                candidate_ready,
                target_completed,
                target_horizon,
                get(attempt_metadata, "recommended_next_action", missing),
            ),
        "outputs_written" => false,
        "runner_is_scientific_simulation" => false,
        "runner_is_validated_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "uses_window_retries" => false,
        "uses_retry_replacement" => false,
        "uses_cascade_rebuild" => false,
        "global_monolithic_mpcc_solve_attempted" => false,
        "global_polish_deferred" => true,
        "global_polish_deferred_reason" => "monolithic_mumps_linear_algebra_cost",
        "interpretation_note" =>
            "Reduced MPCC 72h windowed simulation runner; diagnostic windowed candidate only, not a validated scientific simulation.",
    )
end

function _reduced_mpcc_windowed_72h_runner_table(
    metadata::Dict{String, Any},
)::DataFrame
    row = Dict{String, Any}(
        "runner_id" => "windowed_72h_runner",
        "target_horizon" => get(metadata, "target_horizon", missing),
        "target_is_72h" => get(metadata, "target_is_72h", false),
        "window_hours" => get(metadata, "window_hours", missing),
        "nfe_per_window" => get(metadata, "nfe_per_window", missing),
        "degree" => get(metadata, "degree", missing),
        "ipopt_profile" => get(metadata, "ipopt_profile", missing),
        "ipopt_max_iter" => get(metadata, "ipopt_max_iter", missing),
        "n_requested_windows" => get(metadata, "n_requested_windows", missing),
        "n_completed_windows" => get(metadata, "n_completed_windows", missing),
        "n_failed_windows" => get(metadata, "n_failed_windows", missing),
        "horizon_reached" => get(metadata, "horizon_reached", missing),
        "horizon_gap" => get(metadata, "horizon_gap", missing),
        "target_completed" => get(metadata, "target_completed", false),
        "runner_traffic_light" => get(metadata, "runner_traffic_light", missing),
        "runner_status" => get(metadata, "runner_status", missing),
        "runner_viable" => get(metadata, "runner_viable", false),
        "candidate_ready_for_review" =>
            get(metadata, "candidate_ready_for_review", false),
        "boundary_candidate_available" =>
            get(metadata, "boundary_candidate_available", false),
        "sequential_reference_available" =>
            get(metadata, "sequential_reference_available", false),
        "global_state_metrics_available" =>
            get(metadata, "global_state_metrics_available", false),
        "global_max_state_relative_rmse" =>
            get(metadata, "global_max_state_relative_rmse", missing),
        "total_solve_elapsed_seconds" =>
            get(metadata, "total_solve_elapsed_seconds", missing),
        "recommended_next_action" => get(metadata, "recommended_next_action", missing),
        "outputs_written" => get(metadata, "outputs_written", false),
        "runner_is_scientific_simulation" =>
            get(metadata, "runner_is_scientific_simulation", false),
        "solved_trajectory_claimed" =>
            get(metadata, "solved_trajectory_claimed", false),
        "scientific_baseline" => get(metadata, "scientific_baseline", missing),
        "first_mpcc_target" => get(metadata, "first_mpcc_target", missing),
        "full_model_kkt_deferred" => get(metadata, "full_model_kkt_deferred", true),
        "dfvb_kkt_deferred" => get(metadata, "dfvb_kkt_deferred", true),
        "hsl_required" => get(metadata, "hsl_required", false),
        "ma57_required" => get(metadata, "ma57_required", false),
        "indices_reacciones_used" => get(metadata, "indices_reacciones_used", false),
        "r0001_used_as_oxygen" => get(metadata, "r0001_used_as_oxygen", false),
        "global_monolithic_mpcc_solve_attempted" =>
            get(metadata, "global_monolithic_mpcc_solve_attempted", false),
        "global_polish_deferred" => get(metadata, "global_polish_deferred", true),
    )
    return DataFrame(
        (
            column => [
                _reduced_mpcc_windowed_72h_runner_table_scalar(get(row, column, missing)),
            ] for column in REDUCED_DCDFBA_MPCC_WINDOWED_72H_SIMULATION_RUNNER_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_72h_runner_validate_expected_target(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    expected_target_horizon::Union{Nothing, Real},
)::Nothing
    expected_target_horizon === nothing && return nothing
    expected = Float64(expected_target_horizon)
    isfinite(expected) && expected > 0.0 || throw(
        ArgumentError("Reduced MPCC 72h windowed runner expected_target_horizon must be finite and positive."),
    )
    actual = get(attempt.metadata, "target_horizon", missing)
    _reduced_mpcc_windowed_72h_runner_isfinite_number(actual) || throw(
        ArgumentError("Reduced MPCC 72h windowed runner attempt target_horizon is missing."),
    )
    isapprox(Float64(actual), expected; atol = 1.0e-8, rtol = 1.0e-8) || throw(
        ArgumentError(
            "Reduced MPCC 72h windowed runner expected target_horizon $(expected) " *
            "but attempt target_horizon is $(actual).",
        ),
    )
    return nothing
end

function _reduced_mpcc_windowed_72h_runner_status(
    candidate_ready::Bool,
    target_completed::Bool,
    attempt_light::String,
    boundary_available::Bool,
)::String
    candidate_ready && return "candidate_ready_for_review"
    boundary_available || return "no_boundary_candidate"
    target_completed || return "target_incomplete"
    attempt_light == "yellow" && return "target_reached_needs_review"
    attempt_light == "red" && return "target_reached_blocked"
    return "inspect_windowed_runner_candidate"
end

function _reduced_mpcc_windowed_72h_runner_recommended_action(
    candidate_ready::Bool,
    target_completed::Bool,
    target_horizon,
    attempt_action,
)::String
    if candidate_ready
        return _reduced_mpcc_windowed_72h_runner_is_target_72h(target_horizon) ?
               "review_72h_windowed_candidate_against_full_dfba_cold_before_scientific_use" :
               "extend_windowed_runner_to_72h"
    elseif !target_completed
        return "repair_or_extend_windowed_runner_to_target"
    elseif attempt_action !== missing
        return string(attempt_action)
    else
        return "inspect_windowed_runner_candidate"
    end
end

function _reduced_mpcc_windowed_72h_runner_first_solve_attempt_metadata(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    key::AbstractString,
)
    isempty(attempt.continuation_result.window_comparisons) && return missing
    comparison = first(attempt.continuation_result.window_comparisons)
    return get(comparison.metadata, String(key), missing)
end

function _reduced_mpcc_windowed_72h_runner_is_target_72h(value)::Bool
    _reduced_mpcc_windowed_72h_runner_isfinite_number(value) || return false
    return isapprox(Float64(value), 72.0; atol = 1.0e-8, rtol = 1.0e-8)
end

function _reduced_mpcc_windowed_72h_runner_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_windowed_72h_runner_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
