import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_HORIZON_SWEEP_TYPE =
    "reduced_dcdfba_mpcc_global_polish_horizon_sweep"

const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_HORIZON_SWEEP_COLUMNS = [
    "global_polish_case_id",
    "case_index",
    "case_status",
    "target_horizon",
    "source_mode",
    "window_hours",
    "n_windows",
    "nfe_per_window",
    "degree",
    "source_ipopt_max_iter",
    "retry_ipopt_max_iter_values",
    "cascade_ipopt_max_iter",
    "global_ipopt_max_iter",
    "ipopt_profile",
    "source_window_count",
    "source_continuation_completed",
    "source_all_residual_feasible",
    "source_all_trajectory_ready",
    "source_max_boundary_join_mismatch",
    "cascade_rebuild_applied",
    "cascade_replacement_window_index",
    "cascade_rebuilt_attempt_traffic_light",
    "global_nfe",
    "global_horizon",
    "nlp_structure_total_variables",
    "nlp_structure_equality_constraints",
    "nlp_structure_inequality_constraints",
    "nlp_structure_fixed_variable_count",
    "nlp_structure_nearly_fixed_variable_count",
    "nlp_structure_effective_variable_count",
    "nlp_structure_dof_balance",
    "nlp_structure_too_few_degrees_of_freedom_risk",
    "nlp_structure_fixed_variable_treatment_hint",
    "global_polish_traffic_light",
    "global_polish_viable",
    "global_target_completed",
    "solver_status",
    "primal_status",
    "almost_locally_solved_accepted",
    "acceptable_solver_status",
    "pre_solve_guard_passed",
    "candidate_values_available",
    "candidate_residual_feasible",
    "candidate_trajectory_ready",
    "candidate_iteration_limit_residual_feasible",
    "candidate_dominant_residual",
    "max_rhs_residual",
    "max_collocation_integration_residual",
    "max_continuity_residual",
    "max_initial_condition_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_state_relative_rmse",
    "final_total_sugar_difference",
    "solve_elapsed_seconds",
    "is_last_green",
    "is_first_non_green_after_green",
    "recommended_next_action",
    "outputs_written",
    "sweep_is_scientific_simulation",
    "solved_trajectory_claimed",
    "first_mpcc_target",
    "full_model_kkt_deferred",
    "dfvb_kkt_deferred",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult

Diagnostic sweep over reduced MPCC global-polish attempts. Each case first
builds a reduced windowed/cascade source candidate, uses it only as monolithic
start values, and then solves one global reduced MPCC over the target horizon.
"""
struct ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult
    global_polish_table::DataFrame
    global_polish_results::Vector{ReducedDCDFBAMPCCGlobalPolishResult}
    metadata::Dict{String, Any}
end

"""
    sweep_reduced_dcdfba_mpcc_global_polish_horizons(results)

Aggregate already-computed reduced MPCC global-polish results. This method is
intended for deterministic unit tests and cached in-memory diagnostics.
"""
function sweep_reduced_dcdfba_mpcc_global_polish_horizons(
    results::AbstractVector{<:ReducedDCDFBAMPCCGlobalPolishResult},
)::ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult
    collected = collect(results)
    isempty(collected) && throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep requires at least one polish result."),
    )
    rows = [
        _reduced_mpcc_global_polish_horizon_row(result, case_index) for
        (case_index, result) in enumerate(collected)
    ]
    _reduced_mpcc_global_polish_horizon_mark_boundary!(rows)
    table = _reduced_mpcc_global_polish_horizon_table(rows)
    metadata = _reduced_mpcc_global_polish_horizon_metadata(
        rows,
        collected;
        requested_case_count = length(rows),
        stopped_after_first_non_green = false,
    )
    return ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult(table, collected, metadata)
end

"""
    sweep_reduced_dcdfba_mpcc_global_polish_horizons(model, reaction_map; kwargs...)

Run a guarded horizon sweep where each target horizon is first initialized by
a reduced windowed/cascade candidate and then re-solved as one simultaneous
global reduced MPCC. No files are written and no scientific trajectory is
claimed.
"""
function sweep_reduced_dcdfba_mpcc_global_polish_horizons(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    target_horizons = [0.5],
    source_mode::AbstractString = "cascade",
    t0::Real = 0.0,
    window_hours::Real = 0.5,
    nfe_per_window::Int = 2,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    source_ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    retry_ipopt_max_iter_values = [200, 300, 500],
    retry_selection_policy::AbstractString = "iteration_limit_or_not_ready",
    retry_max_windows::Int = 2,
    cascade_ipopt_max_iter::Union{Nothing, Int} = nothing,
    replacement_acceptance_policy::AbstractString = "green_or_trajectory_ready",
    global_ipopt_max_iter::Union{Nothing, Int} = 500,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    tau_schedule = nothing,
    source_require_pre_solve_ready::Bool = true,
    global_require_pre_solve_ready::Bool = false,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        ),
    silent::Bool = true,
    continue_on_error::Bool = true,
    stop_after_first_non_green::Bool = false,
    case_callback = nothing,
)::ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult
    retry_iters =
        _reduced_mpcc_global_polish_horizon_validate_retry_iters(
            retry_ipopt_max_iter_values,
        )
    cascade_iter =
        _reduced_mpcc_global_polish_horizon_validate_optional_iter(
            cascade_ipopt_max_iter,
            maximum(retry_iters),
            "cascade_ipopt_max_iter",
        )
    global_iter =
        _reduced_mpcc_global_polish_horizon_validate_optional_iter(
            global_ipopt_max_iter,
            nothing,
            "global_ipopt_max_iter",
        )
    specs = _reduced_mpcc_global_polish_horizon_specs(
        target_horizons,
        source_mode,
        t0,
        window_hours,
        nfe_per_window,
        degree,
        source_ipopt_max_iter,
        retry_iters,
        cascade_iter,
        global_iter,
    )

    rows = Dict{String, Any}[]
    results = ReducedDCDFBAMPCCGlobalPolishResult[]
    stopped = false

    for spec in specs
        row = try
            polish = _reduced_mpcc_global_polish_horizon_run_case(
                model,
                reaction_map,
                spec;
                y0 = y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                linear_solver = linear_solver,
                ipopt_profile = ipopt_profile,
                complementarity_mode = complementarity_mode,
                complementarity_tau = complementarity_tau,
                tau_schedule = tau_schedule,
                retry_selection_policy = retry_selection_policy,
                retry_max_windows = retry_max_windows,
                replacement_acceptance_policy = replacement_acceptance_policy,
                source_require_pre_solve_ready = source_require_pre_solve_ready,
                global_require_pre_solve_ready = global_require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                continuation_acceptance_policy = continuation_acceptance_policy,
                continuation_state_relative_rmse_threshold =
                    continuation_state_relative_rmse_threshold,
                viability_thresholds = viability_thresholds,
                silent = silent,
                continue_on_error = continue_on_error,
            )
            push!(results, polish)
            _reduced_mpcc_global_polish_horizon_row(polish, spec.case_index; spec = spec)
        catch err
            continue_on_error || rethrow()
            _reduced_mpcc_global_polish_horizon_error_row(spec, err)
        end
        push!(rows, row)
        case_callback === nothing || case_callback(row, spec.case_index, length(specs))
        if stop_after_first_non_green &&
           get(row, "global_polish_traffic_light", missing) != "green"
            stopped = true
            break
        end
    end

    _reduced_mpcc_global_polish_horizon_mark_boundary!(rows)
    table = _reduced_mpcc_global_polish_horizon_table(rows)
    metadata = _reduced_mpcc_global_polish_horizon_metadata(
        rows,
        results;
        requested_case_count = length(specs),
        stopped_after_first_non_green = stopped,
    )
    return ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult(table, results, metadata)
end

function _reduced_mpcc_global_polish_horizon_run_case(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    spec;
    y0::AbstractVector,
    params::ZentenoKineticParameters,
    sequential_optimizer,
    sequential_algorithm,
    sequential_ode_abstol::Real,
    sequential_ode_reltol::Real,
    sequential_lp_atol::Real,
    sequential_adaptive::Bool,
    sequential_dt,
    sequential_nonnegative::Bool,
    sequential_stop_on_sugar_depletion::Bool,
    sequential_reconstruct_fluxes::Bool,
    mpcc_optimizer,
    linear_solver::AbstractString,
    ipopt_profile::AbstractString,
    complementarity_mode::Union{Symbol, AbstractString},
    complementarity_tau::Real,
    tau_schedule,
    retry_selection_policy::AbstractString,
    retry_max_windows::Int,
    replacement_acceptance_policy::AbstractString,
    source_require_pre_solve_ready::Bool,
    global_require_pre_solve_ready::Bool,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds,
    continuation_acceptance_policy::AbstractString,
    continuation_state_relative_rmse_threshold::Real,
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
    silent::Bool,
    continue_on_error::Bool,
)::ReducedDCDFBAMPCCGlobalPolishResult
    if spec.source_mode == "cascade"
        source = smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(
            model,
            reaction_map;
            target_horizons = [spec.target_horizon],
            t0 = spec.t0,
            window_hours = spec.window_hours,
            nfe_per_window = spec.nfe_per_window,
            degree = spec.degree,
            y0 = y0,
            params = params,
            sequential_optimizer = sequential_optimizer,
            sequential_algorithm = sequential_algorithm,
            sequential_ode_abstol = sequential_ode_abstol,
            sequential_ode_reltol = sequential_ode_reltol,
            sequential_lp_atol = sequential_lp_atol,
            sequential_adaptive = sequential_adaptive,
            sequential_dt = sequential_dt,
            sequential_nonnegative = sequential_nonnegative,
            sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
            sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
            mpcc_optimizer = mpcc_optimizer,
            source_ipopt_max_iter = spec.source_ipopt_max_iter,
            retry_ipopt_max_iter_values = spec.retry_ipopt_max_iter_values,
            cascade_ipopt_max_iter = spec.cascade_ipopt_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            tau_schedule = tau_schedule,
            retry_selection_policy = retry_selection_policy,
            retry_max_windows = retry_max_windows,
            replacement_acceptance_policy = replacement_acceptance_policy,
            require_pre_solve_ready = source_require_pre_solve_ready,
            residual_thresholds = residual_thresholds,
            continuation_acceptance_policy = continuation_acceptance_policy,
            continuation_state_relative_rmse_threshold =
                continuation_state_relative_rmse_threshold,
            viability_thresholds = viability_thresholds,
            silent = silent,
            continue_on_error = continue_on_error,
        )
        isempty(source.cascade_results) && throw(
            ArgumentError(
                "Reduced MPCC global-polish horizon sweep cascade source produced no completed cascade result.",
            ),
        )
        return polish_reduced_dcdfba_mpcc_windowed_candidate(
            model,
            reaction_map,
            first(source.cascade_results);
            residual_thresholds = residual_thresholds,
            params = params,
            optimizer = mpcc_optimizer,
            ipopt_max_iter = spec.global_ipopt_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            require_pre_solve_ready = global_require_pre_solve_ready,
            silent = silent,
        )
    else
        continuation = run_reduced_dcdfba_mpcc_windowed_continuation(
            model,
            reaction_map;
            t0 = spec.t0,
            window_hours = spec.window_hours,
            n_windows = spec.n_windows,
            nfe_per_window = spec.nfe_per_window,
            degree = spec.degree,
            y0 = y0,
            params = params,
            sequential_optimizer = sequential_optimizer,
            sequential_algorithm = sequential_algorithm,
            sequential_ode_abstol = sequential_ode_abstol,
            sequential_ode_reltol = sequential_ode_reltol,
            sequential_lp_atol = sequential_lp_atol,
            sequential_adaptive = sequential_adaptive,
            sequential_dt = sequential_dt,
            sequential_nonnegative = sequential_nonnegative,
            sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
            sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
            mpcc_optimizer = mpcc_optimizer,
            ipopt_max_iter = spec.source_ipopt_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            tau_schedule = tau_schedule,
            require_pre_solve_ready = source_require_pre_solve_ready,
            residual_thresholds = residual_thresholds,
            continuation_acceptance_policy = continuation_acceptance_policy,
            continuation_state_relative_rmse_threshold =
                continuation_state_relative_rmse_threshold,
            silent = silent,
            continue_on_error = continue_on_error,
        )
        return polish_reduced_dcdfba_mpcc_windowed_candidate(
            model,
            reaction_map,
            continuation;
            residual_thresholds = residual_thresholds,
            params = params,
            optimizer = mpcc_optimizer,
            ipopt_max_iter = spec.global_ipopt_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            require_pre_solve_ready = global_require_pre_solve_ready,
            silent = silent,
        )
    end
end

function _reduced_mpcc_global_polish_horizon_specs(
    target_horizons,
    source_mode::AbstractString,
    t0::Real,
    window_hours::Real,
    nfe_per_window::Int,
    degree::Int,
    source_ipopt_max_iter,
    retry_ipopt_max_iter_values::Vector{Int},
    cascade_ipopt_max_iter::Int,
    global_ipopt_max_iter,
)::Vector{NamedTuple}
    initial_time = Float64(t0)
    isfinite(initial_time) || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep t0 must be finite."),
    )
    mode = lowercase(strip(String(source_mode)))
    mode in ("cascade", "windowed") || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep source_mode must be cascade or windowed."),
    )
    duration = Float64(window_hours)
    isfinite(duration) && duration > 0.0 || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep window_hours must be finite and positive."),
    )
    nfe_per_window > 0 || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep nfe_per_window must be positive."),
    )
    degree == 3 || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep currently supports only degree == 3."),
    )
    source_ipopt_max_iter === nothing || source_ipopt_max_iter > 0 || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep source_ipopt_max_iter must be positive or nothing."),
    )
    global_ipopt_max_iter === nothing || global_ipopt_max_iter > 0 || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep global_ipopt_max_iter must be positive or nothing."),
    )
    horizons = Float64.(collect(target_horizons))
    isempty(horizons) && throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep target_horizons must not be empty."),
    )
    all(value -> isfinite(value) && value > 0.0, horizons) || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep target_horizons must be finite and positive."),
    )

    specs = NamedTuple[]
    for (case_index, target) in enumerate(horizons)
        n_windows = _reduced_mpcc_global_polish_horizon_n_windows(target, duration)
        push!(
            specs,
            (
                global_polish_case_id =
                    _reduced_mpcc_global_polish_horizon_case_id(case_index),
                case_index = case_index,
                t0 = initial_time,
                target_horizon = target,
                source_mode = mode,
                window_hours = duration,
                n_windows = n_windows,
                nfe_per_window = nfe_per_window,
                degree = degree,
                source_ipopt_max_iter = source_ipopt_max_iter,
                retry_ipopt_max_iter_values = copy(retry_ipopt_max_iter_values),
                cascade_ipopt_max_iter = cascade_ipopt_max_iter,
                global_ipopt_max_iter = global_ipopt_max_iter,
            ),
        )
    end
    return specs
end

function _reduced_mpcc_global_polish_horizon_row(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
    case_index::Int;
    spec = nothing,
)::Dict{String, Any}
    metadata = result.metadata
    start_metadata = result.windowed_start_values.metadata
    continuation_metadata = result.source_continuation.metadata
    light = _reduced_mpcc_global_polish_horizon_light(metadata)
    target_horizon = _reduced_mpcc_global_polish_horizon_spec_or_metadata(
        spec,
        metadata,
        "target_horizon",
        "global_horizon",
    )
    row = Dict{String, Any}(
        "global_polish_case_id" =>
            spec === nothing ? _reduced_mpcc_global_polish_horizon_case_id(case_index) :
            spec.global_polish_case_id,
        "case_index" => case_index,
        "case_status" => "completed",
        "target_horizon" => target_horizon,
        "source_mode" => spec === nothing ?
                         get(metadata, "global_polish_source_kind", missing) :
                         spec.source_mode,
        "window_hours" => spec === nothing ?
                          get(continuation_metadata, "window_hours", missing) :
                          spec.window_hours,
        "n_windows" => spec === nothing ?
                       get(continuation_metadata, "n_requested_windows", missing) :
                       spec.n_windows,
        "nfe_per_window" => spec === nothing ?
                            get(continuation_metadata, "nfe_per_window", missing) :
                            spec.nfe_per_window,
        "degree" => spec === nothing ?
                    get(continuation_metadata, "degree", missing) :
                    spec.degree,
        "source_ipopt_max_iter" =>
            spec === nothing ? missing : spec.source_ipopt_max_iter,
        "retry_ipopt_max_iter_values" =>
            spec === nothing ? missing : join(spec.retry_ipopt_max_iter_values, ","),
        "cascade_ipopt_max_iter" =>
            spec === nothing ? missing : spec.cascade_ipopt_max_iter,
        "global_ipopt_max_iter" =>
            spec === nothing ? missing : spec.global_ipopt_max_iter,
        "ipopt_profile" => get(metadata, "ipopt_profile", missing),
        "source_window_count" => get(metadata, "source_window_count", missing),
        "source_continuation_completed" =>
            get(metadata, "global_polish_source_continuation_completed", missing),
        "source_all_residual_feasible" =>
            get(start_metadata, "all_source_candidates_residual_feasible", missing),
        "source_all_trajectory_ready" =>
            get(start_metadata, "all_source_candidates_trajectory_ready", missing),
        "source_max_boundary_join_mismatch" =>
            get(metadata, "source_max_boundary_join_mismatch", missing),
        "cascade_rebuild_applied" =>
            get(metadata, "cascade_rebuild_applied", false),
        "cascade_replacement_window_index" =>
            get(metadata, "cascade_replacement_window_index", missing),
        "cascade_rebuilt_attempt_traffic_light" =>
            get(metadata, "cascade_rebuilt_attempt_traffic_light", missing),
        "global_nfe" => get(metadata, "global_nfe", missing),
        "global_horizon" => get(metadata, "global_horizon", missing),
        "nlp_structure_total_variables" =>
            get(metadata, "nlp_structure_total_variables", missing),
        "nlp_structure_equality_constraints" =>
            get(metadata, "nlp_structure_equality_constraints", missing),
        "nlp_structure_inequality_constraints" =>
            get(metadata, "nlp_structure_inequality_constraints", missing),
        "nlp_structure_fixed_variable_count" =>
            get(metadata, "nlp_structure_fixed_variable_count", missing),
        "nlp_structure_nearly_fixed_variable_count" =>
            get(metadata, "nlp_structure_nearly_fixed_variable_count", missing),
        "nlp_structure_effective_variable_count" =>
            get(metadata, "nlp_structure_effective_variable_count", missing),
        "nlp_structure_dof_balance" =>
            get(metadata, "nlp_structure_dof_balance", missing),
        "nlp_structure_too_few_degrees_of_freedom_risk" =>
            get(metadata, "nlp_structure_too_few_degrees_of_freedom_risk", missing),
        "nlp_structure_fixed_variable_treatment_hint" =>
            get(metadata, "nlp_structure_fixed_variable_treatment_hint", missing),
        "global_polish_traffic_light" => light,
        "global_polish_viable" => light == "green",
        "global_target_completed" =>
            _reduced_mpcc_global_polish_horizon_target_completed(
                target_horizon,
                get(metadata, "global_horizon", missing),
            ),
        "solver_status" => get(metadata, "solver_status", missing),
        "primal_status" => get(metadata, "primal_status", missing),
        "almost_locally_solved_accepted" =>
            get(metadata, "almost_locally_solved_accepted", missing),
        "acceptable_solver_status" =>
            get(metadata, "acceptable_solver_status", missing),
        "pre_solve_guard_passed" => get(metadata, "pre_solve_guard_passed", missing),
        "candidate_values_available" =>
            get(metadata, "candidate_values_available", missing),
        "candidate_residual_feasible" =>
            get(metadata, "candidate_residual_feasible", false),
        "candidate_trajectory_ready" =>
            get(metadata, "candidate_trajectory_ready", false),
        "candidate_iteration_limit_residual_feasible" =>
            get(metadata, "candidate_iteration_limit_residual_feasible", false),
        "candidate_dominant_residual" =>
            get(metadata, "candidate_dominant_residual", missing),
        "max_rhs_residual" => get(metadata, "max_rhs_residual", missing),
        "max_collocation_integration_residual" =>
            get(metadata, "max_collocation_integration_residual", missing),
        "max_continuity_residual" =>
            get(metadata, "max_continuity_residual", missing),
        "max_initial_condition_residual" =>
            get(metadata, "max_initial_condition_residual", missing),
        "max_mass_balance_residual" =>
            get(metadata, "max_mass_balance_residual", missing),
        "max_lower_bound_violation" =>
            get(metadata, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" =>
            get(metadata, "max_upper_bound_violation", missing),
        "max_stationarity_residual" =>
            get(metadata, "max_stationarity_residual", missing),
        "max_lower_complementarity_residual" =>
            get(metadata, "max_lower_complementarity_residual", missing),
        "max_upper_complementarity_residual" =>
            get(metadata, "max_upper_complementarity_residual", missing),
        "max_state_relative_rmse" =>
            get(metadata, "max_state_relative_rmse", missing),
        "final_total_sugar_difference" =>
            get(metadata, "final_total_sugar_difference", missing),
        "solve_elapsed_seconds" =>
            get(metadata, "solve_elapsed_seconds", missing),
        "is_last_green" => false,
        "is_first_non_green_after_green" => false,
        "recommended_next_action" =>
            get(metadata, "recommended_next_action", missing),
        "outputs_written" => false,
        "sweep_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "error_type" => missing,
        "error_message" => missing,
    )
    return row
end

function _reduced_mpcc_global_polish_horizon_error_row(spec, err)::Dict{String, Any}
    row = Dict{String, Any}(
        column => missing for column in
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_HORIZON_SWEEP_COLUMNS
    )
    row["global_polish_case_id"] = spec.global_polish_case_id
    row["case_index"] = spec.case_index
    row["case_status"] = "failed"
    row["target_horizon"] = spec.target_horizon
    row["source_mode"] = spec.source_mode
    row["window_hours"] = spec.window_hours
    row["n_windows"] = spec.n_windows
    row["nfe_per_window"] = spec.nfe_per_window
    row["degree"] = spec.degree
    row["source_ipopt_max_iter"] = spec.source_ipopt_max_iter
    row["retry_ipopt_max_iter_values"] = join(spec.retry_ipopt_max_iter_values, ",")
    row["cascade_ipopt_max_iter"] = spec.cascade_ipopt_max_iter
    row["global_ipopt_max_iter"] = spec.global_ipopt_max_iter
    row["ipopt_profile"] = missing
    row["global_polish_traffic_light"] = "red"
    row["global_polish_viable"] = false
    row["global_target_completed"] = false
    row["outputs_written"] = false
    row["sweep_is_scientific_simulation"] = false
    row["solved_trajectory_claimed"] = false
    row["first_mpcc_target"] = "reduced_dfba"
    row["full_model_kkt_deferred"] = true
    row["dfvb_kkt_deferred"] = true
    row["hsl_required"] = false
    row["ma57_required"] = false
    row["indices_reacciones_used"] = false
    row["r0001_used_as_oxygen"] = false
    row["recommended_next_action"] = "inspect_failed_global_polish_case"
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_global_polish_horizon_metadata(
    rows::Vector{Dict{String, Any}},
    results::Vector{ReducedDCDFBAMPCCGlobalPolishResult};
    requested_case_count::Int,
    stopped_after_first_non_green::Bool,
)::Dict{String, Any}
    best_green = _reduced_mpcc_global_polish_horizon_best_green_row(rows)
    first_non_green =
        _reduced_mpcc_global_polish_horizon_first_non_green_after_green_row(rows)
    max_horizon = _reduced_mpcc_global_polish_horizon_max_horizon_row(rows)
    green_count =
        count(row -> get(row, "global_polish_traffic_light", missing) == "green", rows)
    yellow_count =
        count(row -> get(row, "global_polish_traffic_light", missing) == "yellow", rows)
    red_count =
        count(row -> get(row, "global_polish_traffic_light", missing) == "red", rows)
    return Dict{String, Any}(
        "sweep_type" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_HORIZON_SWEEP_TYPE,
        "n_requested_cases" => requested_case_count,
        "n_cases" => length(rows),
        "n_completed_cases" =>
            count(row -> get(row, "case_status", "") == "completed", rows),
        "n_failed_cases" =>
            count(row -> get(row, "case_status", "") == "failed", rows),
        "n_global_polish_results" => length(results),
        "green_count" => green_count,
        "yellow_count" => yellow_count,
        "red_count" => red_count,
        "global_polish_viable_count" =>
            count(row -> get(row, "global_polish_viable", false) === true, rows),
        "target_completed_count" =>
            count(row -> get(row, "global_target_completed", false) === true, rows),
        "residual_feasible_count" =>
            count(row -> get(row, "candidate_residual_feasible", false) === true, rows),
        "trajectory_ready_count" =>
            count(row -> get(row, "candidate_trajectory_ready", false) === true, rows),
        "nlp_structure_dof_risk_count" => count(
            row -> get(row, "nlp_structure_too_few_degrees_of_freedom_risk", false) ===
                   true,
            rows,
        ),
        "nlp_structure_min_dof_balance" =>
            _reduced_mpcc_global_polish_horizon_min(
                rows,
                "nlp_structure_dof_balance",
            ),
        "iteration_limit_residual_feasible_count" => count(
            row -> get(row, "candidate_iteration_limit_residual_feasible", false) === true,
            rows,
        ),
        "traffic_light_counts" =>
            _reduced_mpcc_global_polish_horizon_value_counts(
                rows,
                "global_polish_traffic_light",
            ),
        "solver_status_counts" =>
            _reduced_mpcc_global_polish_horizon_value_counts(rows, "solver_status"),
        "source_mode_counts" =>
            _reduced_mpcc_global_polish_horizon_value_counts(rows, "source_mode"),
        "best_green_case_id" =>
            _reduced_mpcc_global_polish_horizon_value(best_green, "global_polish_case_id"),
        "best_green_target_horizon" =>
            _reduced_mpcc_global_polish_horizon_value(best_green, "target_horizon"),
        "best_green_global_horizon" =>
            _reduced_mpcc_global_polish_horizon_value(best_green, "global_horizon"),
        "best_green_global_nfe" =>
            _reduced_mpcc_global_polish_horizon_value(best_green, "global_nfe"),
        "best_green_max_state_relative_rmse" =>
            _reduced_mpcc_global_polish_horizon_value(
                best_green,
                "max_state_relative_rmse",
            ),
        "max_horizon_case_id" =>
            _reduced_mpcc_global_polish_horizon_value(max_horizon, "global_polish_case_id"),
        "max_horizon_reached" =>
            _reduced_mpcc_global_polish_horizon_value(max_horizon, "global_horizon"),
        "max_horizon_target_horizon" =>
            _reduced_mpcc_global_polish_horizon_value(max_horizon, "target_horizon"),
        "first_non_green_case_id" =>
            _reduced_mpcc_global_polish_horizon_value(
                first_non_green,
                "global_polish_case_id",
            ),
        "first_non_green_target_horizon" =>
            _reduced_mpcc_global_polish_horizon_value(first_non_green, "target_horizon"),
        "first_non_green_traffic_light" =>
            _reduced_mpcc_global_polish_horizon_value(
                first_non_green,
                "global_polish_traffic_light",
            ),
        "first_non_green_solver_status" =>
            _reduced_mpcc_global_polish_horizon_value(first_non_green, "solver_status"),
        "all_requested_cases_green" => !isempty(rows) && green_count == length(rows),
        "sweep_reached_green" => best_green !== nothing,
        "sweep_blocked" => first_non_green !== nothing,
        "stopped_after_first_non_green" => stopped_after_first_non_green,
        "total_solve_elapsed_seconds" =>
            _reduced_mpcc_global_polish_horizon_sum(rows, "solve_elapsed_seconds"),
        "recommended_next_action" =>
            _reduced_mpcc_global_polish_horizon_recommended_action(
                rows,
                best_green,
                first_non_green,
            ),
        "outputs_written" => false,
        "sweep_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC global-polish horizon sweep; cascade/windowed sources are used only as starts for simultaneous reduced MPCC solves.",
    )
end

function _reduced_mpcc_global_polish_horizon_recommended_action(
    rows::Vector{Dict{String, Any}},
    best_green,
    first_non_green,
)::String
    isempty(rows) && return "run_global_polish_horizon_smoke"
    best_green === nothing && return "recover_short_global_polish_case_before_scaling"
    first_non_green === nothing && return "extend_global_polish_horizon_grid"
    if _reduced_mpcc_global_polish_is_structural_residual(
        get(first_non_green, "candidate_dominant_residual", missing),
    )
        return "improve_global_structural_feasibility_before_biology"
    end
    light = string(get(first_non_green, "global_polish_traffic_light", "missing"))
    light == "yellow" && return "increase_global_polish_iterations_or_refine_scaling"
    return "inspect_first_non_green_global_polish_case"
end

function _reduced_mpcc_global_polish_horizon_mark_boundary!(
    rows::Vector{Dict{String, Any}},
)
    for row in rows
        row["is_last_green"] = false
        row["is_first_non_green_after_green"] = false
    end
    best_green_index = _reduced_mpcc_global_polish_horizon_best_green_index(rows)
    best_green_index !== nothing && (rows[best_green_index]["is_last_green"] = true)
    if best_green_index === nothing
        index = findfirst(
            row -> get(row, "global_polish_traffic_light", missing) != "green",
            rows,
        )
        index !== nothing && (rows[index]["is_first_non_green_after_green"] = true)
    else
        for index in (best_green_index + 1):length(rows)
            if get(rows[index], "global_polish_traffic_light", missing) != "green"
                rows[index]["is_first_non_green_after_green"] = true
                break
            end
        end
    end
    return rows
end

function _reduced_mpcc_global_polish_horizon_best_green_row(rows::Vector{Dict{String, Any}})
    index = _reduced_mpcc_global_polish_horizon_best_green_index(rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_global_polish_horizon_best_green_index(rows::Vector{Dict{String, Any}})
    candidates = [
        index for (index, row) in enumerate(rows) if
        get(row, "global_polish_traffic_light", missing) == "green"
    ]
    isempty(candidates) && return nothing
    return candidates[argmax([
        (
            _reduced_mpcc_global_polish_horizon_float_or_neginf(
                get(rows[index], "global_horizon", missing),
            ),
            _reduced_mpcc_global_polish_horizon_float_or_neginf(
                get(rows[index], "target_horizon", missing),
            ),
            -_reduced_mpcc_global_polish_horizon_float_or_inf(
                get(rows[index], "max_state_relative_rmse", missing),
            ),
        ) for index in candidates
    ])]
end

function _reduced_mpcc_global_polish_horizon_first_non_green_after_green_row(
    rows::Vector{Dict{String, Any}},
)
    isempty(rows) && return nothing
    best_green_index = _reduced_mpcc_global_polish_horizon_best_green_index(rows)
    if best_green_index === nothing
        index = findfirst(
            row -> get(row, "global_polish_traffic_light", missing) != "green",
            rows,
        )
        return index === nothing ? nothing : rows[index]
    end
    best_green_index == length(rows) && return nothing
    for index in (best_green_index + 1):length(rows)
        get(rows[index], "global_polish_traffic_light", missing) != "green" &&
            return rows[index]
    end
    return nothing
end

function _reduced_mpcc_global_polish_horizon_max_horizon_row(rows::Vector{Dict{String, Any}})
    isempty(rows) && return nothing
    index = argmax([
        _reduced_mpcc_global_polish_horizon_float_or_neginf(
            get(row, "global_horizon", missing),
        ) for row in rows
    ])
    return rows[index]
end

function _reduced_mpcc_global_polish_horizon_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_global_polish_horizon_table_scalar(
                    get(row, column, missing),
                ) for row in rows
            ] for column in REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_HORIZON_SWEEP_COLUMNS
        )...,
    )
end

function _reduced_mpcc_global_polish_horizon_light(metadata)::String
    residual_feasible = get(metadata, "candidate_residual_feasible", false) === true
    trajectory_ready = get(metadata, "candidate_trajectory_ready", false) === true
    iteration_limit_residual_feasible =
        get(metadata, "candidate_iteration_limit_residual_feasible", false) === true
    trajectory_ready && residual_feasible && return "green"
    (residual_feasible || iteration_limit_residual_feasible) && return "yellow"
    return "red"
end

function _reduced_mpcc_global_polish_horizon_target_completed(target, reached)::Bool
    _reduced_mpcc_global_polish_horizon_isfinite_number(target) || return false
    _reduced_mpcc_global_polish_horizon_isfinite_number(reached) || return false
    return Float64(reached) + 1.0e-10 >= Float64(target)
end

function _reduced_mpcc_global_polish_horizon_spec_or_metadata(
    spec,
    metadata,
    spec_key::AbstractString,
    metadata_key::AbstractString,
)
    if spec !== nothing
        symbol = Symbol(spec_key)
        haskey(spec, symbol) && return getfield(spec, symbol)
    end
    return get(metadata, String(metadata_key), missing)
end

function _reduced_mpcc_global_polish_horizon_n_windows(
    target_horizon::Float64,
    window_hours::Float64,
)::Int
    raw = target_horizon / window_hours
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || throw(
        ArgumentError(
            "Reduced MPCC global-polish horizon sweep target_horizon $(target_horizon) " *
            "is not an integer multiple of window_hours $(window_hours).",
        ),
    )
    n_windows > 0 || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep computed window count must be positive."),
    )
    return n_windows
end

function _reduced_mpcc_global_polish_horizon_validate_retry_iters(values)::Vector{Int}
    collection = Int.(collect(values))
    isempty(collection) && throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep retry_ipopt_max_iter_values must not be empty."),
    )
    all(value -> value > 0, collection) || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep retry_ipopt_max_iter_values must be positive."),
    )
    return collection
end

function _reduced_mpcc_global_polish_horizon_validate_optional_iter(
    value,
    default_value,
    label::AbstractString,
)
    selected = value === nothing ? default_value : Int(value)
    selected === nothing && return nothing
    selected > 0 || throw(
        ArgumentError("Reduced MPCC global-polish horizon sweep $(label) must be positive or nothing."),
    )
    return selected
end

function _reduced_mpcc_global_polish_horizon_case_id(index::Int)::String
    return "global_polish_horizon_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_global_polish_horizon_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_global_polish_horizon_value_counts(
    rows::Vector{Dict{String, Any}},
    key::AbstractString,
)::Dict{String, Int}
    counts = Dict{String, Int}()
    for row in rows
        value = get(row, String(key), missing)
        value === missing && continue
        label = string(value)
        counts[label] = get(counts, label, 0) + 1
    end
    return counts
end

function _reduced_mpcc_global_polish_horizon_sum(
    rows::Vector{Dict{String, Any}},
    key::AbstractString,
)::Float64
    total = 0.0
    for row in rows
        value = get(row, String(key), missing)
        _reduced_mpcc_global_polish_horizon_isfinite_number(value) || continue
        total += Float64(value)
    end
    return total
end

function _reduced_mpcc_global_polish_horizon_min(
    rows::Vector{Dict{String, Any}},
    key::AbstractString,
)
    values = Float64[]
    for row in rows
        value = get(row, String(key), missing)
        _reduced_mpcc_global_polish_horizon_isfinite_number(value) || continue
        push!(values, Float64(value))
    end
    return isempty(values) ? missing : minimum(values)
end

function _reduced_mpcc_global_polish_horizon_float_or_inf(value)::Float64
    _reduced_mpcc_global_polish_horizon_isfinite_number(value) || return Inf
    return Float64(value)
end

function _reduced_mpcc_global_polish_horizon_float_or_neginf(value)::Float64
    _reduced_mpcc_global_polish_horizon_isfinite_number(value) || return -Inf
    return Float64(value)
end

function _reduced_mpcc_global_polish_horizon_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_global_polish_horizon_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
