import HiGHS
import OrdinaryDiffEq

const SEQUENTIAL_MODEL_COMPARISON_TYPE = "sequential_dfba_dfvb_multimodel_comparison"
const SEQUENTIAL_MODEL_ALIGNMENT_LINEAR = "linear_interpolation_to_reference_times"
const SEQUENTIAL_MODEL_REFERENCE_TIME_SOURCE = "julia_common_grid"
const SEQUENTIAL_MODEL_SOURCES = [
    "reduced_dfba",
    "full_dfba",
    "julia_dfvb",
    "matlab_dfvb_baseline",
]

const SEQUENTIAL_MODEL_SUMMARY_COLUMNS = [
    "source",
    "model_scope",
    "retcode",
    "termination_reason",
    "initial_time",
    "final_time",
    "n_time_points",
    "n_states",
    "n_alphas",
    "initial_biomass",
    "final_biomass",
    "initial_glucose",
    "final_glucose",
    "initial_fructose",
    "final_fructose",
    "initial_total_sugar",
    "final_total_sugar",
    "initial_ethanol",
    "final_ethanol",
    "final_oxygen",
    "simulation_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
    "alpha_scope",
    "reconstruct_fluxes",
    "reconstruct_alphas",
]

const SEQUENTIAL_MODEL_STATE_METRIC_COLUMNS = [
    "state_name",
    "reduced_dfba_final",
    "full_dfba_final",
    "julia_dfvb_final",
    "matlab_dfvb_final_aligned",
    "full_minus_reduced",
    "julia_dfvb_minus_full",
    "julia_dfvb_minus_matlab",
    "rmse_reduced_vs_full",
    "rmse_julia_dfvb_vs_full",
    "rmse_julia_dfvb_vs_matlab",
    "relative_rmse_julia_dfvb_vs_matlab",
    "notes",
]

const SEQUENTIAL_MODEL_OXYGEN_NOTE =
    "reduced, full, and Julia DFVB oxygen states are forced zero; MATLAB baseline oxygen is expected to be numerical near-zero; r_0001 is not oxygen and oxygen remains r_1992"
const SEQUENTIAL_MODEL_CARBOHYDRATE_NOTE =
    "carbohydrate dy[8] remains empirical and is not driven by r_4048"
const SEQUENTIAL_MODEL_BIOMASS_FLUX_NOTE =
    "Weighted objective value is not biomass flux; biomass dynamics use solved or reconstructed r_2111."
const SEQUENTIAL_MODEL_INTERPRETATION_NOTE =
    "This is a diagnostic multimodel state trajectory comparison, not proof of biological equivalence. " *
    "Sources differ in network size, reduction, null-space basis, LP degeneracy, solver behavior, and artifact provenance. " *
    "Fluxes and alphas are excluded by default."

"""
    SequentialModelComparisonResult

Container for a consolidated short sequential state trajectory comparison
between reduced DFBA, full DFBA, Julia DFVB, and exported MATLAB DFVB baseline
trajectories. The comparison aligns MATLAB baseline states to the Julia common
time grid and intentionally excludes flux and alpha trajectory comparisons.
"""
struct SequentialModelComparisonResult
    reduced_dfba::SimulationResult
    full_dfba::SimulationResult
    julia_dfvb::SimulationResult
    matlab_dfvb_baseline::DFVBBaselineReport
    summary_table::DataFrame
    state_metrics_table::DataFrame
    aligned_timeseries_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    compare_sequential_models(reduced_model, reduced_reaction_map, full_model, full_reaction_map, dfvb_artifacts; kwargs...)

Run short reduced DFBA, full DFBA, and Julia DFVB sequential simulations on a
shared saved-time grid, align exported MATLAB DFVB baseline states to that grid,
and compute state-only multimodel diagnostics over the shared 19 fermentation
states. Fluxes and alphas are not reconstructed or compared by this report.
"""
function compare_sequential_models(
    reduced_model::MetabolicModel,
    reduced_reaction_map::ReactionMap,
    full_model::MetabolicModel,
    full_reaction_map::ReactionMap,
    dfvb_artifacts::DFVBArtifacts;
    tspan::Tuple{Float64, Float64} = (0.0, 0.25),
    saveat = 0.25,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    algorithm = OrdinaryDiffEq.Tsit5(),
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    reconstruct_fluxes::Bool = false,
    reconstruct_alphas::Bool = false,
    alignment_policy::AbstractString = SEQUENTIAL_MODEL_ALIGNMENT_LINEAR,
)::SequentialModelComparisonResult
    _sequential_model_validate_alignment_policy(alignment_policy)
    _sequential_model_validate_state_only_options(reconstruct_fluxes, reconstruct_alphas)
    _validate_sequential_dfba_reaction_map(reduced_model, reduced_reaction_map, "reduced")
    _validate_sequential_dfba_reaction_map(full_model, full_reaction_map, "full")
    _assert_sequential_dfba_oxygen_not_r0001(reduced_reaction_map, "reduced")
    _assert_sequential_dfba_oxygen_not_r0001(full_reaction_map, "full")

    reduced_lb = copy(reduced_model.lb)
    reduced_ub = copy(reduced_model.ub)
    full_lb = copy(full_model.lb)
    full_ub = copy(full_model.ub)

    common_kwargs = (
        y0 = y0,
        tspan = tspan,
        optimizer = optimizer,
        silent = silent,
        lp_atol = lp_atol,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        saveat = saveat,
        algorithm = algorithm,
        reconstruct_fluxes = false,
    )
    reduced_result = simulate_reduced_dfba(reduced_model, reduced_reaction_map; common_kwargs...)
    full_result = simulate_full_dfba(full_model, full_reaction_map; common_kwargs...)
    julia_dfvb_result = simulate_dfvb(
        full_model,
        full_reaction_map,
        dfvb_artifacts;
        y0 = y0,
        tspan = tspan,
        optimizer = optimizer,
        silent = silent,
        lp_atol = lp_atol,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        saveat = saveat,
        algorithm = algorithm,
        use_active_alpha = true,
        reconstruct_fluxes = false,
        reconstruct_alphas = false,
    )

    _assert_sequential_dfba_bounds_unchanged(reduced_model, reduced_lb, reduced_ub, "reduced")
    _assert_sequential_dfba_bounds_unchanged(full_model, full_lb, full_ub, "full")

    baseline_report = build_dfvb_baseline_report(
        dfvb_artifacts;
        include_full_alpha_summary = false,
        include_active_alpha_summary = false,
    )

    return _sequential_model_comparison_from_results(
        reduced_result,
        full_result,
        julia_dfvb_result,
        baseline_report;
        tspan = tspan,
        saveat = saveat,
        algorithm_label = _sequential_model_algorithm_label(algorithm),
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        lp_atol = lp_atol,
        reconstruct_fluxes = false,
        reconstruct_alphas = false,
        alignment_policy = alignment_policy,
        reduced_model_id = reduced_model.model_id,
        full_model_id = full_model.model_id,
        dfvb_artifact_id = dfvb_artifacts.paths.artifact_id,
    )
end

"""
    export_sequential_model_comparison(comparison, output_dir; overwrite=false)

Write CSV/TOML artifacts for a consolidated sequential DFBA/DFVB state-only
comparison. Only known target files are overwritten when `overwrite=true`.
"""
function export_sequential_model_comparison(
    comparison::SequentialModelComparisonResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Sequential model comparison output_dir exists and is not a directory: $output_path")
    end

    paths = Dict{String, String}(
        "summary" => joinpath(output_path, "sequential_model_comparison_summary.csv"),
        "state_metrics" => joinpath(output_path, "sequential_model_state_metrics.csv"),
        "aligned_timeseries" => joinpath(output_path, "sequential_model_aligned_timeseries.csv"),
        "metadata" => joinpath(output_path, "sequential_model_comparison_metadata.toml"),
    )
    existing_targets = [path for path in values(paths) if isfile(path)]
    if !overwrite && !isempty(existing_targets)
        error(
            "Sequential model comparison export target file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end

    mkpath(output_path)
    if overwrite
        for path in values(paths)
            isfile(path) && rm(path)
        end
    end

    CSV.write(paths["summary"], comparison.summary_table)
    CSV.write(paths["state_metrics"], comparison.state_metrics_table)
    CSV.write(paths["aligned_timeseries"], comparison.aligned_timeseries_table)
    open(paths["metadata"], "w") do io
        TOML.print(io, _sequential_model_toml_normalize(comparison.metadata))
    end
    return paths
end

function _sequential_model_comparison_from_results(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
    julia_dfvb_result::SimulationResult,
    baseline_report::DFVBBaselineReport;
    tspan::Tuple{Float64, Float64},
    saveat,
    algorithm_label::AbstractString,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    lp_atol::Real = 1.0e-8,
    reconstruct_fluxes::Bool = false,
    reconstruct_alphas::Bool = false,
    alignment_policy::AbstractString = SEQUENTIAL_MODEL_ALIGNMENT_LINEAR,
    reduced_model_id::AbstractString = String(get(reduced_result.metadata, "model_id", "unknown_reduced_model")),
    full_model_id::AbstractString = String(get(full_result.metadata, "model_id", "unknown_full_model")),
    dfvb_artifact_id::AbstractString = String(get(baseline_report.metadata, "artifact_id", "unknown_dfvb_artifact")),
)::SequentialModelComparisonResult
    normalized_policy = _sequential_model_validate_alignment_policy(alignment_policy)
    _sequential_model_validate_state_only_options(reconstruct_fluxes, reconstruct_alphas)

    state_names = _sequential_model_state_names(reduced_result, full_result, julia_dfvb_result, baseline_report)
    aligned_baseline = _sequential_model_aligned_matlab_baseline(
        baseline_report,
        julia_dfvb_result.time,
        state_names,
    )
    summary_table = _sequential_model_summary_table(
        reduced_result,
        full_result,
        julia_dfvb_result,
        aligned_baseline,
        state_names,
    )
    state_metrics_table = _sequential_model_state_metrics_table(
        reduced_result,
        full_result,
        julia_dfvb_result,
        aligned_baseline,
        state_names,
    )
    aligned_timeseries_table = _sequential_model_aligned_timeseries_table(
        reduced_result,
        full_result,
        julia_dfvb_result,
        aligned_baseline,
        state_names,
    )
    metadata = _sequential_model_metadata(
        reduced_result,
        full_result,
        julia_dfvb_result,
        baseline_report,
        state_names;
        tspan = tspan,
        saveat = saveat,
        algorithm_label = algorithm_label,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        lp_atol = lp_atol,
        reconstruct_fluxes = false,
        reconstruct_alphas = false,
        alignment_policy = normalized_policy,
        reduced_model_id = reduced_model_id,
        full_model_id = full_model_id,
        dfvb_artifact_id = dfvb_artifact_id,
    )

    return SequentialModelComparisonResult(
        reduced_result,
        full_result,
        julia_dfvb_result,
        baseline_report,
        summary_table,
        state_metrics_table,
        aligned_timeseries_table,
        metadata,
    )
end

function _sequential_model_validate_alignment_policy(alignment_policy::AbstractString)::String
    normalized_policy = strip(String(alignment_policy))
    normalized_policy == SEQUENTIAL_MODEL_ALIGNMENT_LINEAR || error(
        "Unsupported sequential model comparison alignment_policy: $alignment_policy. " *
        "Only $SEQUENTIAL_MODEL_ALIGNMENT_LINEAR is currently implemented.",
    )
    return normalized_policy
end

function _sequential_model_validate_state_only_options(
    reconstruct_fluxes::Bool,
    reconstruct_alphas::Bool,
)
    reconstruct_fluxes == false || error(
        "Sequential model comparison is state-only; reconstruct_fluxes must be false.",
    )
    reconstruct_alphas == false || error(
        "Sequential model comparison is state-only; reconstruct_alphas must be false.",
    )
    return nothing
end

function _sequential_model_state_names(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
    julia_dfvb_result::SimulationResult,
    baseline_report::DFVBBaselineReport,
)::Vector{String}
    reference_time = julia_dfvb_result.time
    reduced_result.time == reference_time || error(
        "Sequential model comparison requires reduced DFBA saved times to match Julia DFVB reference times.",
    )
    full_result.time == reference_time || error(
        "Sequential model comparison requires full DFBA saved times to match Julia DFVB reference times.",
    )

    results = (
        "reduced_dfba" => reduced_result,
        "full_dfba" => full_result,
        "julia_dfvb" => julia_dfvb_result,
    )
    for (source, result) in results
        size(result.states, 1) == 19 || error(
            "Sequential model comparison expects $source to have 19 state rows, got $(size(result.states, 1)).",
        )
        size(result.states, 2) == length(reference_time) || error(
            "Sequential model comparison $source state column count does not match reference time length.",
        )
    end

    reduced_names = _state_names(reduced_result)
    full_names = _state_names(full_result)
    julia_names = _state_names(julia_dfvb_result)
    reduced_names == full_names || error("Sequential model comparison requires reduced/full state names to match.")
    reduced_names == julia_names || error("Sequential model comparison requires reduced/Julia DFVB state names to match.")
    length(reduced_names) == 19 || error(
        "Sequential model comparison expects 19 state names, got $(length(reduced_names)).",
    )

    baseline_state_names = String.(setdiff(names(baseline_report.state_timeseries), ["time"]))
    missing_baseline = setdiff(reduced_names, baseline_state_names)
    isempty(missing_baseline) || error(
        "Sequential model comparison MATLAB baseline states are missing state names: " *
        join(missing_baseline, ", "),
    )
    return reduced_names
end

function _sequential_model_aligned_matlab_baseline(
    baseline_report::DFVBBaselineReport,
    reference_times::AbstractVector,
    state_names::Vector{String},
)::DataFrame
    baseline_times = _dfvb_baseline_time_vector(baseline_report.state_timeseries, "state_trajectories")
    return _interpolate_baseline_states_to_times(
        baseline_times,
        baseline_report.state_timeseries,
        reference_times,
        state_names,
    )
end

function _sequential_model_summary_table(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
    julia_dfvb_result::SimulationResult,
    aligned_baseline::DataFrame,
    state_names::Vector{String},
)::DataFrame
    rows = [
        _sequential_model_simulation_summary_row("reduced_dfba", reduced_result; reconstruct_alphas = false),
        _sequential_model_simulation_summary_row("full_dfba", full_result; reconstruct_alphas = false),
        _sequential_model_simulation_summary_row("julia_dfvb", julia_dfvb_result; reconstruct_alphas = false),
        _sequential_model_baseline_summary_row(aligned_baseline, state_names),
    ]
    return DataFrame(
        (
            column => [_sequential_model_table_scalar(get(row, column, missing)) for row in rows] for
            column in SEQUENTIAL_MODEL_SUMMARY_COLUMNS
        )...,
    )
end

function _sequential_model_simulation_summary_row(
    source::AbstractString,
    result::SimulationResult;
    reconstruct_alphas::Bool,
)::Dict{String, Any}
    summary = summarize_simulation(result)
    return Dict{String, Any}(
        "source" => String(source),
        "model_scope" => get(summary, "model_scope", "unknown"),
        "retcode" => get(summary, "retcode", missing),
        "termination_reason" => get(summary, "termination_reason", missing),
        "initial_time" => get(summary, "initial_time", missing),
        "final_time" => get(summary, "final_time", missing),
        "n_time_points" => get(summary, "n_saved_points", missing),
        "n_states" => get(summary, "n_states", missing),
        "n_alphas" => get(summary, "n_alphas", missing),
        "initial_biomass" => get(summary, "initial_biomass", missing),
        "final_biomass" => get(summary, "final_biomass", missing),
        "initial_glucose" => get(summary, "initial_glucose", missing),
        "final_glucose" => get(summary, "final_glucose", missing),
        "initial_fructose" => get(summary, "initial_fructose", missing),
        "final_fructose" => get(summary, "final_fructose", missing),
        "initial_total_sugar" => get(summary, "initial_total_sugar", missing),
        "final_total_sugar" => get(summary, "final_total_sugar", missing),
        "initial_ethanol" => get(summary, "initial_ethanol", missing),
        "final_ethanol" => get(summary, "final_ethanol", missing),
        "final_oxygen" => get(summary, "final_oxygen", missing),
        "simulation_elapsed_seconds" => get(summary, "simulation_elapsed_seconds", missing),
        "rhs_call_count" => get(summary, "rhs_call_count", missing),
        "total_lp_solve_count" => get(summary, "total_lp_solve_count", missing),
        "alpha_scope" => get(summary, "alpha_scope", missing),
        "reconstruct_fluxes" => get(summary, "reconstruct_fluxes", false),
        "reconstruct_alphas" => get(result.metadata, "reconstruct_alphas", reconstruct_alphas),
    )
end

function _sequential_model_baseline_summary_row(
    aligned_baseline::DataFrame,
    state_names::Vector{String},
)::Dict{String, Any}
    initial_index = firstindex(aligned_baseline[!, "time"])
    final_index = lastindex(aligned_baseline[!, "time"])
    state_value(name, row) = Float64(aligned_baseline[row, name])
    initial_glucose = state_value("glucose", initial_index)
    final_glucose = state_value("glucose", final_index)
    initial_fructose = state_value("fructose", initial_index)
    final_fructose = state_value("fructose", final_index)

    return Dict{String, Any}(
        "source" => "matlab_dfvb_baseline",
        "model_scope" => "matlab_dfvb_baseline",
        "retcode" => "artifact",
        "termination_reason" => "matlab_export",
        "initial_time" => aligned_baseline[initial_index, "time"],
        "final_time" => aligned_baseline[final_index, "time"],
        "n_time_points" => nrow(aligned_baseline),
        "n_states" => length(state_names),
        "n_alphas" => missing,
        "initial_biomass" => state_value("biomass", initial_index),
        "final_biomass" => state_value("biomass", final_index),
        "initial_glucose" => initial_glucose,
        "final_glucose" => final_glucose,
        "initial_fructose" => initial_fructose,
        "final_fructose" => final_fructose,
        "initial_total_sugar" => initial_glucose + initial_fructose,
        "final_total_sugar" => final_glucose + final_fructose,
        "initial_ethanol" => state_value("ethanol", initial_index),
        "final_ethanol" => state_value("ethanol", final_index),
        "final_oxygen" => state_value("oxygen", final_index),
        "simulation_elapsed_seconds" => missing,
        "rhs_call_count" => missing,
        "total_lp_solve_count" => missing,
        "alpha_scope" => "not_compared",
        "reconstruct_fluxes" => missing,
        "reconstruct_alphas" => missing,
    )
end

function _sequential_model_state_metrics_table(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
    julia_dfvb_result::SimulationResult,
    aligned_baseline::DataFrame,
    state_names::Vector{String},
)::DataFrame
    rows = [
        _sequential_model_state_metric_row(
            state_name,
            view(reduced_result.states, i, :),
            view(full_result.states, i, :),
            view(julia_dfvb_result.states, i, :),
            aligned_baseline[!, state_name],
        ) for (i, state_name) in enumerate(state_names)
    ]
    return DataFrame(
        (
            column => [_sequential_model_table_scalar(get(row, column, missing)) for row in rows] for
            column in SEQUENTIAL_MODEL_STATE_METRIC_COLUMNS
        )...,
    )
end

function _sequential_model_state_metric_row(
    state_name::AbstractString,
    reduced_values,
    full_values,
    julia_dfvb_values,
    matlab_values,
)::Dict{String, Any}
    reduced = Float64.(collect(reduced_values))
    full = Float64.(collect(full_values))
    julia = Float64.(collect(julia_dfvb_values))
    matlab = _dfvb_matlab_numeric_vector(matlab_values, "sequential_model_aligned_baseline.$state_name")
    length(reduced) == length(full) == length(julia) == length(matlab) || error(
        "Sequential model comparison state $(String(state_name)) has mismatched trajectory lengths.",
    )

    full_minus_reduced = full .- reduced
    julia_minus_full = julia .- full
    julia_minus_matlab = julia .- matlab
    rmse_reduced_full = _sequential_model_rmse(reduced, full)
    rmse_julia_full = _sequential_model_rmse(julia, full)
    rmse_julia_matlab = _sequential_model_rmse(julia, matlab)

    return Dict{String, Any}(
        "state_name" => String(state_name),
        "reduced_dfba_final" => reduced[end],
        "full_dfba_final" => full[end],
        "julia_dfvb_final" => julia[end],
        "matlab_dfvb_final_aligned" => matlab[end],
        "full_minus_reduced" => full_minus_reduced[end],
        "julia_dfvb_minus_full" => julia_minus_full[end],
        "julia_dfvb_minus_matlab" => julia_minus_matlab[end],
        "rmse_reduced_vs_full" => rmse_reduced_full,
        "rmse_julia_dfvb_vs_full" => rmse_julia_full,
        "rmse_julia_dfvb_vs_matlab" => rmse_julia_matlab,
        "relative_rmse_julia_dfvb_vs_matlab" =>
            _sequential_model_relative_rmse(rmse_julia_matlab, julia, matlab),
        "notes" => _sequential_model_state_note(state_name),
    )
end

function _sequential_model_aligned_timeseries_table(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
    julia_dfvb_result::SimulationResult,
    aligned_baseline::DataFrame,
    state_names::Vector{String},
)::DataFrame
    table = DataFrame("time" => copy(julia_dfvb_result.time))
    for (i, state_name) in enumerate(state_names)
        reduced = collect(view(reduced_result.states, i, :))
        full = collect(view(full_result.states, i, :))
        julia = collect(view(julia_dfvb_result.states, i, :))
        matlab = _dfvb_matlab_numeric_vector(aligned_baseline[!, state_name], "sequential_model_aligned_baseline.$state_name")
        prefix = lowercase(String(state_name))
        table[!, "$(prefix)_reduced_dfba"] = reduced
        table[!, "$(prefix)_full_dfba"] = full
        table[!, "$(prefix)_julia_dfvb"] = julia
        table[!, "$(prefix)_matlab_dfvb"] = matlab
        table[!, "$(prefix)_full_minus_reduced"] = full .- reduced
        table[!, "$(prefix)_julia_dfvb_minus_matlab"] = julia .- matlab
    end
    return table
end

function _sequential_model_metadata(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
    julia_dfvb_result::SimulationResult,
    baseline_report::DFVBBaselineReport,
    state_names::Vector{String};
    tspan::Tuple{Float64, Float64},
    saveat,
    algorithm_label::AbstractString,
    ode_abstol::Real,
    ode_reltol::Real,
    lp_atol::Real,
    reconstruct_fluxes::Bool,
    reconstruct_alphas::Bool,
    alignment_policy::AbstractString,
    reduced_model_id::AbstractString,
    full_model_id::AbstractString,
    dfvb_artifact_id::AbstractString,
)::Dict{String, Any}
    baseline_times = _dfvb_baseline_time_vector(baseline_report.state_timeseries, "state_trajectories")
    return Dict{String, Any}(
        "comparison_type" => SEQUENTIAL_MODEL_COMPARISON_TYPE,
        "sources" => copy(SEQUENTIAL_MODEL_SOURCES),
        "state_comparison_included" => true,
        "flux_comparison_included" => false,
        "alpha_comparison_included" => false,
        "alignment_policy" => String(alignment_policy),
        "reference_time_source" => SEQUENTIAL_MODEL_REFERENCE_TIME_SOURCE,
        "matlab_interpolation_used" => true,
        "tspan" => tspan,
        "saveat" => saveat,
        "algorithm_label" => String(algorithm_label),
        "ode_abstol" => Float64(ode_abstol),
        "ode_reltol" => Float64(ode_reltol),
        "lp_atol" => Float64(lp_atol),
        "reconstruct_fluxes" => reconstruct_fluxes,
        "reconstruct_alphas" => reconstruct_alphas,
        "state_names" => copy(state_names),
        "n_states" => length(state_names),
        "n_reference_time_points" => length(julia_dfvb_result.time),
        "reference_time_start" => julia_dfvb_result.time[begin],
        "reference_time_end" => julia_dfvb_result.time[end],
        "baseline_time_start" => baseline_times[begin],
        "baseline_time_end" => baseline_times[end],
        "baseline_n_time_points" => length(baseline_times),
        "matlab_baseline_n_active_alphas" => get(baseline_report.metadata, "n_active_alphas", missing),
        "matlab_baseline_n_full_alphas" => get(baseline_report.metadata, "n_full_alphas", missing),
        "reduced_model_id" => String(reduced_model_id),
        "full_model_id" => String(full_model_id),
        "dfvb_artifact_id" => String(dfvb_artifact_id),
        "reduced_retcode" => get(reduced_result.metadata, "retcode", missing),
        "full_retcode" => get(full_result.metadata, "retcode", missing),
        "julia_dfvb_retcode" => get(julia_dfvb_result.metadata, "retcode", missing),
        "matlab_baseline_retcode" => "artifact",
        "source_metadata" => Dict{String, Any}(
            "reduced_dfba" => Dict{String, Any}(reduced_result.metadata),
            "full_dfba" => Dict{String, Any}(full_result.metadata),
            "julia_dfvb" => Dict{String, Any}(julia_dfvb_result.metadata),
            "matlab_dfvb_baseline" => Dict{String, Any}(baseline_report.metadata),
        ),
        "r0001_used_as_oxygen" => false,
        "oxygen_reaction_id" => "r_1992",
        "oxygen_policy_note" => SEQUENTIAL_MODEL_OXYGEN_NOTE,
        "carbohydrate_policy_note" => SEQUENTIAL_MODEL_CARBOHYDRATE_NOTE,
        "biomass_flux_note" => SEQUENTIAL_MODEL_BIOMASS_FLUX_NOTE,
        "interpretation_note" => SEQUENTIAL_MODEL_INTERPRETATION_NOTE,
        "indices_reacciones_used" => false,
        "kkt_mpcc_collocation_implemented" => false,
    )
end

function _sequential_model_rmse(source_a::Vector{Float64}, source_b::Vector{Float64})::Float64
    length(source_a) == length(source_b) || error("RMSE vectors must have matching lengths.")
    difference = source_a .- source_b
    return sqrt(sum(abs2, difference) / length(difference))
end

function _sequential_model_relative_rmse(
    rmse::Real,
    source_a::Vector{Float64},
    source_b::Vector{Float64},
)::Float64
    denominator = max(maximum(abs.(source_a)), maximum(abs.(source_b)), eps(Float64))
    return Float64(rmse) / denominator
end

function _sequential_model_state_note(state_name::AbstractString)::String
    name = String(state_name)
    if name == "oxygen"
        return SEQUENTIAL_MODEL_OXYGEN_NOTE
    elseif name == "carbohydrate"
        return SEQUENTIAL_MODEL_CARBOHYDRATE_NOTE
    end
    return "compared on the shared 19-state fermentation trajectory grid"
end

function _sequential_model_algorithm_label(algorithm)::String
    algorithm === nothing && return "default"
    return String(nameof(typeof(algorithm)))
end

function _sequential_model_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end

function _sequential_model_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _sequential_model_toml_normalize_real(value)
    elseif value isa Tuple
        return _sequential_model_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _sequential_model_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _sequential_model_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _sequential_model_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _sequential_model_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _sequential_model_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end
