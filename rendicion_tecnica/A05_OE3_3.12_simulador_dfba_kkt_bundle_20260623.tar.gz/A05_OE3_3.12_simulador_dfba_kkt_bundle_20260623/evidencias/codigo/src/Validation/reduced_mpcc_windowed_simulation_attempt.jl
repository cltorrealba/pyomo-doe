import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_SIMULATION_ATTEMPT_TYPE =
    "reduced_dcdfba_mpcc_windowed_simulation_attempt"

const REDUCED_DCDFBA_MPCC_WINDOWED_SIMULATION_ATTEMPT_COLUMNS = [
    "candidate_id",
    "source_type",
    "is_global_candidate",
    "target_horizon",
    "horizon_reached",
    "horizon_gap",
    "target_completed",
    "attempt_traffic_light",
    "attempt_viable",
    "traffic_light",
    "viability_class",
    "simulation_viable",
    "window_index",
    "horizon",
    "window_hours",
    "nfe",
    "degree",
    "boundary_dt",
    "linear_solver",
    "ipopt_profile",
    "complementarity_mode",
    "complementarity_tau",
    "tau_schedule",
    "tau_continuation_stage_count",
    "tau_continuation_completed",
    "tau_continuation_final_residual_feasible",
    "tau_continuation_final_tau_gate_pass",
    "tau_continuation_blocking_stage",
    "tau_continuation_blocking_reason",
    "tau_continuation_stage_advance_count",
    "solver_status",
    "solve_elapsed_seconds",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_lower_complementarity_product",
    "max_upper_complementarity_product",
    "max_complementarity_tau_violation",
    "complementarity_tau_gate_pass",
    "max_state_abs_difference",
    "max_state_relative_rmse",
    "global_max_state_abs_difference",
    "global_max_state_relative_rmse",
    "blocking_reasons",
    "review_reasons",
    "full_dfba_cold_reference_deferred",
    "reduced_full_equivalence_claimed",
    "persistent_lp_baseline_used",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCWindowedSimulationAttemptResult

Diagnostic wrapper for an attempted reduced MPCC windowed simulation over a
target horizon, such as 72 hours. It combines the windowed-continuation result
with the simulation-viability semaphore and summarizes whether the requested
target horizon was reached. It writes no outputs and does not claim a
scientifically validated simultaneous DFBA simulation.
"""
struct ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    continuation_result::ReducedDCDFBAMPCCWindowedContinuationResult
    viability_report::ReducedDCDFBAMPCCSimulationViabilityReport
    attempt_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    attempt_reduced_dcdfba_mpcc_windowed_simulation(continuation; target_horizon, kwargs...)

Assess an existing reduced MPCC windowed-continuation diagnostic as an attempt
to reach a requested horizon. This method is useful for deterministic tests and
for reclassifying an in-memory continuation without rerunning the solver.
"""
function attempt_reduced_dcdfba_mpcc_windowed_simulation(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult;
    target_horizon::Real,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(),
)::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    target = _reduced_mpcc_windowed_attempt_target_horizon(target_horizon)
    report = assess_reduced_dcdfba_mpcc_simulation_viability(
        continuation;
        thresholds = thresholds,
    )
    return _reduced_mpcc_windowed_attempt_result(continuation, report, target)
end

"""
    attempt_reduced_dcdfba_mpcc_windowed_simulation(model, reaction_map; target_horizon=72.0, kwargs...)

Run a reduced MPCC windowed-continuation diagnostic sized from a target horizon
and then classify the result with the simulation-viability semaphore. This is
the guarded entry point for first 72-hour reduced MPCC attempts. It remains a
diagnostic workflow: no full-model baseline, DFVB KKT, HSL, generated output,
or scientific simulation claim is introduced.
"""
function attempt_reduced_dcdfba_mpcc_windowed_simulation(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    target_horizon::Real = 72.0,
    t0::Real = 0.0,
    window_hours::Real = 0.5,
    nfe_per_window::Int = 2,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    tau_schedule = nothing,
    propagate_flux_dual_starts::Bool = true,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_abs_difference_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_ABS_DIFFERENCE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        ),
    silent::Bool = true,
    continue_on_error::Bool = true,
    window_callback = nothing,
)::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    target = _reduced_mpcc_windowed_attempt_target_horizon(target_horizon)
    duration = _reduced_mpcc_windowed_attempt_window_hours(window_hours)
    n_windows = _reduced_mpcc_windowed_attempt_n_windows_from_target(target, duration)

    continuation = run_reduced_dcdfba_mpcc_windowed_continuation(
        model,
        reaction_map;
        t0 = t0,
        window_hours = duration,
        n_windows = n_windows,
        nfe_per_window = nfe_per_window,
        degree = degree,
        y0 = y0,
        params = params,
        sequential_optimizer = sequential_optimizer,
        sequential_algorithm = sequential_algorithm,
        sequential_ode_abstol = sequential_ode_abstol,
        sequential_ode_reltol = sequential_ode_reltol,
        sequential_lp_atol = sequential_lp_atol,
        sequential_adaptive = sequential_adaptive,
        sequential_dt = sequential_dt,
        sequential_nonnegative = sequential_nonnegative,
        sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
        mpcc_optimizer = mpcc_optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        complementarity_tau_gate_tol = complementarity_tau_gate_tol,
        tau_schedule = tau_schedule,
        propagate_flux_dual_starts = propagate_flux_dual_starts,
        require_pre_solve_ready = require_pre_solve_ready,
        residual_thresholds = residual_thresholds,
        continuation_acceptance_policy = continuation_acceptance_policy,
        continuation_state_abs_difference_threshold =
            continuation_state_abs_difference_threshold,
        continuation_state_relative_rmse_threshold =
            continuation_state_relative_rmse_threshold,
        silent = silent,
        continue_on_error = continue_on_error,
        window_callback = window_callback,
    )
    report = assess_reduced_dcdfba_mpcc_simulation_viability(
        continuation;
        thresholds = viability_thresholds,
    )
    return _reduced_mpcc_windowed_attempt_result(continuation, report, target)
end

function _reduced_mpcc_windowed_attempt_result(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    report::ReducedDCDFBAMPCCSimulationViabilityReport,
    target_horizon::Float64,
)::ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    metadata = _reduced_mpcc_windowed_attempt_metadata(
        continuation,
        report,
        target_horizon,
    )
    table = _reduced_mpcc_windowed_attempt_table(report, metadata)
    return ReducedDCDFBAMPCCWindowedSimulationAttemptResult(
        continuation,
        report,
        table,
        metadata,
    )
end

function _reduced_mpcc_windowed_attempt_metadata(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    report::ReducedDCDFBAMPCCSimulationViabilityReport,
    target_horizon::Float64,
)::Dict{String, Any}
    continuation_metadata = continuation.metadata
    table = report.viability_table
    global_row = _reduced_mpcc_windowed_attempt_global_row(table)
    window_rows = _reduced_mpcc_windowed_attempt_window_rows(table)
    horizon_reached = _reduced_mpcc_windowed_attempt_float_or_missing(
        get(continuation_metadata, "total_horizon_reached", missing),
    )
    horizon_gap =
        horizon_reached === missing ? missing : max(target_horizon - horizon_reached, 0.0)
    target_completed =
        horizon_reached !== missing &&
        isapprox(horizon_reached, target_horizon; atol = 1.0e-8, rtol = 1.0e-8) &&
        get(continuation_metadata, "continuation_completed", false) === true
    global_light = _reduced_mpcc_windowed_attempt_row_value(global_row, "traffic_light")
    all_windows_green =
        !isempty(window_rows) &&
        all(row -> String(row["traffic_light"]) == "green", window_rows)
    has_window_yellow = any(row -> String(row["traffic_light"]) == "yellow", window_rows)
    has_window_red = any(row -> String(row["traffic_light"]) == "red", window_rows)
    attempt_light = _reduced_mpcc_windowed_attempt_light(
        target_completed,
        global_light,
        all_windows_green,
        has_window_yellow,
        has_window_red,
    )
    attempt_viable = attempt_light == "green"
    first_non_green = _reduced_mpcc_windowed_attempt_first_non_green_window(window_rows)
    first_red = _reduced_mpcc_windowed_attempt_first_window_with_light(window_rows, "red")
    first_not_residual_feasible =
        _reduced_mpcc_windowed_attempt_first_window_not_residual_feasible(window_rows)

    return Dict{String, Any}(
        "attempt_type" => REDUCED_DCDFBA_MPCC_WINDOWED_SIMULATION_ATTEMPT_TYPE,
        "target_horizon" => target_horizon,
        "target_is_72h" => isapprox(target_horizon, 72.0; atol = 1.0e-8, rtol = 1.0e-8),
        "horizon_reached" => horizon_reached,
        "horizon_gap" => horizon_gap,
        "target_completion_fraction" =>
            horizon_reached === missing ? missing : horizon_reached / target_horizon,
        "target_completed" => target_completed,
        "attempt_traffic_light" => attempt_light,
        "attempt_viable" => attempt_viable,
        "attempt_is_scientific_simulation" => false,
        "attempt_is_validated_simulation" => false,
        "solved_trajectory_claimed" => false,
        "n_requested_windows" => get(continuation_metadata, "n_requested_windows", missing),
        "n_completed_windows" => get(continuation_metadata, "n_completed_windows", missing),
        "n_failed_windows" => get(continuation_metadata, "n_failed_windows", missing),
        "window_hours" => get(continuation_metadata, "window_hours", missing),
        "nfe_per_window" => get(continuation_metadata, "nfe_per_window", missing),
        "degree" => get(continuation_metadata, "degree", missing),
        "ipopt_profile" => get(continuation_metadata, "ipopt_profile", missing),
        "ipopt_profile_env" => get(
            continuation_metadata,
            "ipopt_profile_env",
            REDUCED_DCDFBA_MPCC_IPOPT_PROFILE_ENV,
        ),
        "linear_solver" => get(continuation_metadata, "linear_solver", missing),
        "linear_solver_env" => get(
            continuation_metadata,
            "linear_solver_env",
            IPOPT_LINEAR_SOLVER_ENV,
        ),
        "complementarity_mode" =>
            get(continuation_metadata, "complementarity_mode", missing),
        "complementarity_tau" =>
            get(continuation_metadata, "complementarity_tau", missing),
        "complementarity_mode_env" => get(
            continuation_metadata,
            "complementarity_mode_env",
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_ENV,
        ),
        "complementarity_tau_env" => get(
            continuation_metadata,
            "complementarity_tau_env",
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_TAU_ENV,
        ),
        "tau_schedule" => get(continuation_metadata, "tau_schedule", missing),
        "tau_schedule_env" => get(
            continuation_metadata,
            "tau_schedule_env",
            REDUCED_DCDFBA_MPCC_TAU_SCHEDULE_ENV,
        ),
        "tau_continuation_completed_window_count" =>
            get(continuation_metadata, "tau_continuation_completed_window_count", missing),
        "tau_continuation_final_tau_gate_pass_window_count" => get(
            continuation_metadata,
            "tau_continuation_final_tau_gate_pass_window_count",
            missing,
        ),
        "tau_continuation_blocking_reason_counts" =>
            get(continuation_metadata, "tau_continuation_blocking_reason_counts", missing),
        "tau_continuation_stage_advance_count" =>
            get(continuation_metadata, "tau_continuation_stage_advance_count", missing),
        "boundary_dt" => get(continuation_metadata, "boundary_dt", missing),
        "n_total_boundary_points" =>
            get(continuation_metadata, "n_total_boundary_points", missing),
        "n_total_collocation_points" =>
            get(continuation_metadata, "n_total_collocation_points", missing),
        "continuation_completed" =>
            get(continuation_metadata, "continuation_completed", false),
        "continuation_acceptance_policy" =>
            get(continuation_metadata, "continuation_acceptance_policy", missing),
        "continuation_state_relative_rmse_threshold" =>
            get(
                continuation_metadata,
                "continuation_state_relative_rmse_threshold",
                missing,
            ),
        "continuation_state_drift_gate_enabled" =>
            get(continuation_metadata, "continuation_state_drift_gate_enabled", false),
        "continuation_policy_reason_counts" =>
            get(continuation_metadata, "continuation_policy_reason_counts", Dict{String, Int}()),
        "continuation_policy_rejected_window_count" =>
            get(continuation_metadata, "continuation_policy_rejected_window_count", missing),
        "iteration_limit_policy_accepted_window_count" =>
            get(
                continuation_metadata,
                "iteration_limit_policy_accepted_window_count",
                missing,
            ),
        "state_drift_gate_pass_window_count" =>
            get(continuation_metadata, "state_drift_gate_pass_window_count", missing),
        "all_completed_windows_residual_feasible" =>
            get(continuation_metadata, "all_completed_windows_residual_feasible", false),
        "all_completed_windows_allow_continuation" =>
            get(continuation_metadata, "all_completed_windows_allow_continuation", false),
        "all_completed_windows_trajectory_ready" =>
            get(continuation_metadata, "all_completed_windows_trajectory_ready", false),
        "sequential_reference_available" =>
            get(continuation_metadata, "sequential_reference_available", false),
        "boundary_candidate_available" =>
            get(continuation_metadata, "boundary_candidate_available", false),
        "global_state_metrics_available" =>
            get(continuation_metadata, "global_state_metrics_available", false),
        "global_traffic_light" => global_light,
        "global_viability_class" =>
            _reduced_mpcc_windowed_attempt_row_value(global_row, "viability_class"),
        "global_simulation_viable" =>
            _reduced_mpcc_windowed_attempt_row_value(global_row, "simulation_viable"),
        "window_green_count" =>
            count(row -> String(row["traffic_light"]) == "green", window_rows),
        "window_yellow_count" =>
            count(row -> String(row["traffic_light"]) == "yellow", window_rows),
        "window_red_count" =>
            count(row -> String(row["traffic_light"]) == "red", window_rows),
        "all_windows_green" => all_windows_green,
        "first_non_green_window_id" =>
            _reduced_mpcc_windowed_attempt_row_value(first_non_green, "candidate_id"),
        "first_non_green_window_index" =>
            _reduced_mpcc_windowed_attempt_row_value(first_non_green, "window_index"),
        "first_non_green_window_light" =>
            _reduced_mpcc_windowed_attempt_row_value(first_non_green, "traffic_light"),
        "first_non_green_window_class" =>
            _reduced_mpcc_windowed_attempt_row_value(first_non_green, "viability_class"),
        "first_non_green_window_blocking_reasons" =>
            _reduced_mpcc_windowed_attempt_row_value(first_non_green, "blocking_reasons"),
        "first_red_window_id" =>
            _reduced_mpcc_windowed_attempt_row_value(first_red, "candidate_id"),
        "first_red_window_index" =>
            _reduced_mpcc_windowed_attempt_row_value(first_red, "window_index"),
        "first_red_window_class" =>
            _reduced_mpcc_windowed_attempt_row_value(first_red, "viability_class"),
        "first_red_window_blocking_reasons" =>
            _reduced_mpcc_windowed_attempt_row_value(first_red, "blocking_reasons"),
        "first_not_residual_feasible_window_id" =>
            _reduced_mpcc_windowed_attempt_row_value(
                first_not_residual_feasible,
                "candidate_id",
            ),
        "first_not_residual_feasible_window_index" =>
            _reduced_mpcc_windowed_attempt_row_value(
                first_not_residual_feasible,
                "window_index",
            ),
        "first_not_residual_feasible_window_class" =>
            _reduced_mpcc_windowed_attempt_row_value(
                first_not_residual_feasible,
                "viability_class",
            ),
        "first_not_residual_feasible_window_blocking_reasons" =>
            _reduced_mpcc_windowed_attempt_row_value(
                first_not_residual_feasible,
                "blocking_reasons",
            ),
        "viability_report_overall_traffic_light" =>
            get(report.metadata, "overall_traffic_light", missing),
        "viability_report_recommended_next_action" =>
            get(report.metadata, "recommended_next_action", missing),
        "total_solve_elapsed_seconds" =>
            _reduced_mpcc_windowed_attempt_sum(continuation.window_table, "solve_elapsed_seconds"),
        "outputs_written" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "recommended_next_action" => _reduced_mpcc_windowed_attempt_recommended_action(
            attempt_light,
            target_completed,
            global_row,
            first_non_green,
        ),
        "interpretation_note" =>
            "Reduced MPCC windowed target-horizon attempt; diagnostic only and not a validated scientific simulation.",
    )
end

function _reduced_mpcc_windowed_attempt_table(
    report::ReducedDCDFBAMPCCSimulationViabilityReport,
    metadata::Dict{String, Any},
)::DataFrame
    rows = [
        _reduced_mpcc_windowed_attempt_row(row, metadata) for
        row in eachrow(report.viability_table)
    ]
    return DataFrame(
        (
            column => [
                _reduced_mpcc_windowed_attempt_table_scalar(get(row, column, missing)) for
                row in rows
            ] for column in REDUCED_DCDFBA_MPCC_WINDOWED_SIMULATION_ATTEMPT_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_attempt_row(row, metadata::Dict{String, Any})
    source_type = String(get(row, "source_type", ""))
    return Dict{String, Any}(
        "candidate_id" => get(row, "candidate_id", missing),
        "source_type" => get(row, "source_type", missing),
        "is_global_candidate" => source_type == "windowed_continuation_global",
        "target_horizon" => metadata["target_horizon"],
        "horizon_reached" => metadata["horizon_reached"],
        "horizon_gap" => metadata["horizon_gap"],
        "target_completed" => metadata["target_completed"],
        "attempt_traffic_light" => metadata["attempt_traffic_light"],
        "attempt_viable" => metadata["attempt_viable"],
        "traffic_light" => get(row, "traffic_light", missing),
        "viability_class" => get(row, "viability_class", missing),
        "simulation_viable" => get(row, "simulation_viable", false),
        "window_index" => get(row, "window_index", missing),
        "horizon" => get(row, "horizon", missing),
        "window_hours" => get(row, "window_hours", missing),
        "nfe" => get(row, "nfe", missing),
        "degree" => get(row, "degree", missing),
        "boundary_dt" => get(row, "boundary_dt", missing),
        "linear_solver" => get(row, "linear_solver", get(metadata, "linear_solver", missing)),
        "ipopt_profile" => get(row, "ipopt_profile", get(metadata, "ipopt_profile", missing)),
        "complementarity_mode" =>
            get(row, "complementarity_mode", get(metadata, "complementarity_mode", missing)),
        "complementarity_tau" =>
            get(row, "complementarity_tau", get(metadata, "complementarity_tau", missing)),
        "tau_schedule" => get(row, "tau_schedule", get(metadata, "tau_schedule", missing)),
        "tau_continuation_stage_count" =>
            get(row, "tau_continuation_stage_count", missing),
        "tau_continuation_completed" =>
            get(row, "tau_continuation_completed", missing),
        "tau_continuation_final_residual_feasible" =>
            get(row, "tau_continuation_final_residual_feasible", missing),
        "tau_continuation_final_tau_gate_pass" =>
            get(row, "tau_continuation_final_tau_gate_pass", missing),
        "tau_continuation_blocking_stage" =>
            get(row, "tau_continuation_blocking_stage", missing),
        "tau_continuation_blocking_reason" =>
            get(row, "tau_continuation_blocking_reason", missing),
        "tau_continuation_stage_advance_count" =>
            get(row, "tau_continuation_stage_advance_count", missing),
        "solver_status" => get(row, "solver_status", missing),
        "solve_elapsed_seconds" => get(row, "solve_elapsed_seconds", missing),
        "max_rhs_residual" => get(row, "max_rhs_residual", missing),
        "max_mass_balance_residual" => get(row, "max_mass_balance_residual", missing),
        "max_lower_bound_violation" => get(row, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" => get(row, "max_upper_bound_violation", missing),
        "max_stationarity_residual" => get(row, "max_stationarity_residual", missing),
        "max_lower_complementarity_residual" =>
            get(row, "max_lower_complementarity_residual", missing),
        "max_upper_complementarity_residual" =>
            get(row, "max_upper_complementarity_residual", missing),
        "max_lower_complementarity_product" =>
            get(row, "max_lower_complementarity_product", missing),
        "max_upper_complementarity_product" =>
            get(row, "max_upper_complementarity_product", missing),
        "max_complementarity_tau_violation" =>
            get(row, "max_complementarity_tau_violation", missing),
        "complementarity_tau_gate_pass" =>
            get(row, "complementarity_tau_gate_pass", missing),
        "max_state_abs_difference" => get(row, "max_state_abs_difference", missing),
        "max_state_relative_rmse" => get(row, "max_state_relative_rmse", missing),
        "global_max_state_abs_difference" =>
            get(row, "global_max_state_abs_difference", missing),
        "global_max_state_relative_rmse" =>
            get(row, "global_max_state_relative_rmse", missing),
        "blocking_reasons" => get(row, "blocking_reasons", missing),
        "review_reasons" => get(row, "review_reasons", missing),
        "full_dfba_cold_reference_deferred" =>
            get(row, "full_dfba_cold_reference_deferred", true),
        "reduced_full_equivalence_claimed" =>
            get(row, "reduced_full_equivalence_claimed", false),
        "persistent_lp_baseline_used" => get(row, "persistent_lp_baseline_used", false),
        "hsl_required" => get(row, "hsl_required", false),
        "ma57_required" => get(row, "ma57_required", false),
        "indices_reacciones_used" => get(row, "indices_reacciones_used", false),
        "r0001_used_as_oxygen" => get(row, "r0001_used_as_oxygen", false),
        "error_type" => get(row, "error_type", missing),
        "error_message" => get(row, "error_message", missing),
    )
end

function _reduced_mpcc_windowed_attempt_target_horizon(value::Real)::Float64
    target = Float64(value)
    isfinite(target) && target > 0.0 || throw(
        ArgumentError("Reduced MPCC windowed simulation target_horizon must be finite and positive."),
    )
    return target
end

function _reduced_mpcc_windowed_attempt_window_hours(value::Real)::Float64
    duration = Float64(value)
    isfinite(duration) && duration > 0.0 || throw(
        ArgumentError("Reduced MPCC windowed simulation window_hours must be finite and positive."),
    )
    return duration
end

function _reduced_mpcc_windowed_attempt_n_windows_from_target(
    target_horizon::Real,
    window_hours::Real,
)::Int
    target = _reduced_mpcc_windowed_attempt_target_horizon(target_horizon)
    duration = _reduced_mpcc_windowed_attempt_window_hours(window_hours)
    raw = target / duration
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || throw(
        ArgumentError(
            "Reduced MPCC windowed simulation target_horizon $(target) is not an " *
            "integer multiple of window_hours $(duration).",
        ),
    )
    n_windows > 0 || throw(
        ArgumentError("Reduced MPCC windowed simulation computed window count must be positive."),
    )
    return n_windows
end

function _reduced_mpcc_windowed_attempt_global_row(table::DataFrame)
    index = findfirst(==("windowed_global"), String.(table[!, "candidate_id"]))
    return index === nothing ? nothing : table[index, :]
end

function _reduced_mpcc_windowed_attempt_window_rows(table::DataFrame)
    return [
        row for row in eachrow(table) if
        String(row["source_type"]) == "windowed_continuation_window"
    ]
end

function _reduced_mpcc_windowed_attempt_first_non_green_window(window_rows)
    index = findfirst(row -> String(row["traffic_light"]) != "green", window_rows)
    return index === nothing ? nothing : window_rows[index]
end

function _reduced_mpcc_windowed_attempt_first_window_with_light(
    window_rows,
    traffic_light::AbstractString,
)
    index = findfirst(row -> String(row["traffic_light"]) == String(traffic_light), window_rows)
    return index === nothing ? nothing : window_rows[index]
end

function _reduced_mpcc_windowed_attempt_first_window_not_residual_feasible(window_rows)
    index = findfirst(row -> row["residual_feasible"] !== true, window_rows)
    return index === nothing ? nothing : window_rows[index]
end

function _reduced_mpcc_windowed_attempt_light(
    target_completed::Bool,
    global_light,
    all_windows_green::Bool,
    has_window_yellow::Bool,
    has_window_red::Bool,
)::String
    if target_completed && String(global_light) == "green" && all_windows_green
        return "green"
    elseif has_window_red || String(global_light) == "red" || !target_completed
        return "red"
    elseif has_window_yellow || String(global_light) == "yellow"
        return "yellow"
    else
        return "red"
    end
end

function _reduced_mpcc_windowed_attempt_recommended_action(
    attempt_light::String,
    target_completed::Bool,
    global_row,
    first_non_green,
)::String
    attempt_light == "green" && return "review_windowed_target_candidate_before_scientific_use"
    target_completed || return "extend_or_repair_windowed_continuation_to_target"
    row = first_non_green === nothing ? global_row : first_non_green
    class = String(_reduced_mpcc_windowed_attempt_row_value(row, "viability_class"))
    if class == "windowed_drift_too_large" || class == "state_drift_too_large"
        return "reduce_windowed_candidate_drift_before_simulation"
    elseif class == "iteration_limit_residual_feasible_candidate" ||
           class == "residual_feasible_but_not_trajectory_ready"
        return "improve_window_solver_termination_before_simulation"
    elseif class == "residual_thresholds_failed"
        return "repair_window_residual_feasibility_before_simulation"
    elseif class == "guardrail_violation"
        return "fix_scientific_guardrails_before_simulation"
    else
        return "inspect_windowed_attempt_before_simulation"
    end
end

function _reduced_mpcc_windowed_attempt_row_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_attempt_sum(table::DataFrame, column::AbstractString)
    String(column) in names(table) || return missing
    values = Float64[
        Float64(value) for value in table[!, String(column)] if
        _reduced_mpcc_windowed_attempt_isfinite_number(value)
    ]
    isempty(values) && return missing
    return sum(values)
end

function _reduced_mpcc_windowed_attempt_float_or_missing(value)
    value === missing && return missing
    value === nothing && return missing
    return try
        converted = Float64(value)
        isfinite(converted) ? converted : missing
    catch
        missing
    end
end

function _reduced_mpcc_windowed_attempt_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_windowed_attempt_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
