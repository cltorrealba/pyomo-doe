import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_POLICY_HORIZON_SWEEP_TYPE =
    "reduced_dcdfba_mpcc_windowed_policy_horizon_sweep"

const REDUCED_DCDFBA_MPCC_WINDOWED_POLICY_HORIZON_SWEEP_COLUMNS = [
    "policy_case_id",
    "case_index",
    "case_status",
    "target_horizon",
    "window_hours",
    "nfe_per_window",
    "degree",
    "boundary_dt",
    "ipopt_max_iter",
    "linear_solver",
    "continuation_acceptance_policy",
    "continuation_state_relative_rmse_threshold",
    "continuation_state_drift_gate_enabled",
    "ipopt_profile",
    "complementarity_mode",
    "complementarity_tau",
    "tau_schedule",
    "tau_continuation_stage_count",
    "tau_continuation_completed",
    "tau_continuation_final_residual_feasible",
    "tau_continuation_final_tau_gate_pass",
    "tau_continuation_blocking_stage",
    "tau_continuation_blocking_reason",
    "tau_continuation_stage_advance_count",
    "n_requested_windows",
    "n_completed_windows",
    "n_failed_windows",
    "horizon_reached",
    "horizon_gap",
    "target_completion_fraction",
    "target_completed",
    "attempt_traffic_light",
    "attempt_viable",
    "global_traffic_light",
    "global_viability_class",
    "scale_readiness",
    "primary_blocker",
    "scale_recommended_next_action",
    "is_scale_candidate",
    "is_72h_ready_candidate",
    "next_target_horizon_hint",
    "is_last_green",
    "is_first_non_green_after_green",
    "window_green_count",
    "window_yellow_count",
    "window_red_count",
    "continuation_policy_rejected_window_count",
    "iteration_limit_policy_accepted_window_count",
    "state_drift_gate_pass_window_count",
    "first_non_green_window_id",
    "first_non_green_window_index",
    "first_non_green_window_class",
    "first_red_window_id",
    "first_red_window_index",
    "first_red_window_class",
    "first_not_residual_feasible_window_id",
    "first_not_residual_feasible_window_index",
    "first_not_residual_feasible_window_class",
    "solver_status",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_lower_complementarity_product",
    "max_upper_complementarity_product",
    "max_complementarity_tau_violation",
    "max_complementarity_tau_violation_raw",
    "complementarity_tau_gate_tolerance",
    "complementarity_tau_gate_tolerance_source",
    "complementarity_tau_gate_pass",
    "max_state_relative_rmse",
    "global_max_state_relative_rmse",
    "total_solve_elapsed_seconds",
    "recommended_next_action",
    "blocking_reasons",
    "review_reasons",
    "outputs_written",
    "sweep_is_scientific_simulation",
    "solved_trajectory_claimed",
    "first_mpcc_target",
    "full_model_kkt_deferred",
    "dfvb_kkt_deferred",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCWindowedPolicyHorizonSweepResult

Diagnostic sweep over reduced MPCC windowed target-horizon attempts while
varying horizon, window grid, and continuation-acceptance policy. It writes no
outputs, does not rebuild failed/yellow windows, and does not claim a validated
scientific simultaneous DFBA simulation.
"""
struct ReducedDCDFBAMPCCWindowedPolicyHorizonSweepResult
    policy_horizon_table::DataFrame
    attempt_results::Vector{ReducedDCDFBAMPCCWindowedSimulationAttemptResult}
    metadata::Dict{String, Any}
end

"""
    sweep_reduced_dcdfba_mpcc_windowed_policy_horizons(attempts)

Aggregate already-computed reduced MPCC windowed attempts into a
policy/horizon sweep table. This method is useful for deterministic tests and
cached diagnostics.
"""
function sweep_reduced_dcdfba_mpcc_windowed_policy_horizons(
    attempts::AbstractVector{<:ReducedDCDFBAMPCCWindowedSimulationAttemptResult},
)::ReducedDCDFBAMPCCWindowedPolicyHorizonSweepResult
    collected_attempts = collect(attempts)
    isempty(collected_attempts) && throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep requires at least one attempt."),
    )
    rows = [
        _reduced_mpcc_windowed_policy_horizon_row_from_attempt(attempt, case_index) for
        (case_index, attempt) in enumerate(collected_attempts)
    ]
    _reduced_mpcc_windowed_policy_horizon_mark_boundary!(rows)
    table = _reduced_mpcc_windowed_policy_horizon_table(rows)
    metadata = _reduced_mpcc_windowed_policy_horizon_metadata(
        rows,
        collected_attempts;
        requested_case_count = length(rows),
        stopped_after_first_non_green = false,
        ipopt_max_iter = missing,
    )
    return ReducedDCDFBAMPCCWindowedPolicyHorizonSweepResult(
        table,
        collected_attempts,
        metadata,
    )
end

"""
    sweep_reduced_dcdfba_mpcc_windowed_policy_horizons(model, reaction_map; kwargs...)

Run reduced MPCC windowed target-horizon attempts over a guarded grid of
target horizons, window sizes, finite elements per window, and continuation
policies. The sweep is diagnostic-only and keeps full/DFVB KKT, HSL/MA57, file
outputs, and scientific simulation claims out of scope.
"""
function sweep_reduced_dcdfba_mpcc_windowed_policy_horizons(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    target_horizons = [0.5],
    window_hours_values = [0.5],
    nfe_per_window_values = [2],
    continuation_acceptance_policies = [
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    ],
    continuation_state_relative_rmse_threshold_values = [
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    ],
    t0::Real = 0.0,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver_values = [ipopt_linear_solver_from_env()],
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau_values = [reduced_mpcc_complementarity_tau_from_env()],
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    tau_schedule = nothing,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        ),
    silent::Bool = true,
    continue_on_error::Bool = true,
    stop_after_first_non_green::Bool = false,
    case_callback = nothing,
)::ReducedDCDFBAMPCCWindowedPolicyHorizonSweepResult
    specs = _reduced_mpcc_windowed_policy_horizon_specs(
        t0,
        target_horizons,
        window_hours_values,
        nfe_per_window_values,
        continuation_acceptance_policies,
        continuation_state_relative_rmse_threshold_values,
        degree,
        ipopt_max_iter,
        linear_solver_values,
        complementarity_tau_values,
    )
    rows = Dict{String, Any}[]
    attempts = ReducedDCDFBAMPCCWindowedSimulationAttemptResult[]
    stopped = false

    for spec in specs
        row = try
            attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
                model,
                reaction_map;
                target_horizon = spec.target_horizon,
                t0 = spec.t0,
                window_hours = spec.window_hours,
                nfe_per_window = spec.nfe_per_window,
                degree = spec.degree,
                y0 = y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = ipopt_max_iter,
                linear_solver = spec.linear_solver,
                ipopt_profile = ipopt_profile,
                complementarity_mode = complementarity_mode,
                complementarity_tau = spec.complementarity_tau,
                complementarity_tau_gate_tol = complementarity_tau_gate_tol,
                tau_schedule = tau_schedule,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                continuation_acceptance_policy = spec.continuation_acceptance_policy,
                continuation_state_relative_rmse_threshold =
                    spec.continuation_state_relative_rmse_threshold,
                viability_thresholds = viability_thresholds,
                silent = silent,
                continue_on_error = continue_on_error,
            )
            push!(attempts, attempt)
            _reduced_mpcc_windowed_policy_horizon_row_from_attempt(
                attempt,
                spec.case_index;
                spec = spec,
            )
        catch err
            continue_on_error || rethrow()
            _reduced_mpcc_windowed_policy_horizon_error_row(spec, err)
        end
        push!(rows, row)
        case_callback === nothing || case_callback(row, spec.case_index, length(specs))
        if stop_after_first_non_green && get(row, "attempt_traffic_light", missing) != "green"
            stopped = true
            break
        end
    end

    _reduced_mpcc_windowed_policy_horizon_mark_boundary!(rows)
    table = _reduced_mpcc_windowed_policy_horizon_table(rows)
    metadata = _reduced_mpcc_windowed_policy_horizon_metadata(
        rows,
        attempts;
        requested_case_count = length(specs),
        stopped_after_first_non_green = stopped,
        ipopt_max_iter = ipopt_max_iter,
    )
    return ReducedDCDFBAMPCCWindowedPolicyHorizonSweepResult(table, attempts, metadata)
end

function _reduced_mpcc_windowed_policy_horizon_specs(
    t0::Real,
    target_horizons,
    window_hours_values,
    nfe_per_window_values,
    continuation_acceptance_policies,
    continuation_state_relative_rmse_threshold_values,
    degree::Int,
    ipopt_max_iter,
    linear_solver_values,
    complementarity_tau_values,
)::Vector{NamedTuple}
    initial_time = Float64(t0)
    isfinite(initial_time) || throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep t0 must be finite."),
    )
    degree == 3 || throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep currently supports only degree == 3."),
    )
    ipopt_max_iter === nothing || ipopt_max_iter > 0 || throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep ipopt_max_iter must be positive or nothing."),
    )
    horizons = _reduced_mpcc_windowed_policy_horizon_positive_values(
        target_horizons,
        "target_horizons",
    )
    window_hours = _reduced_mpcc_windowed_policy_horizon_positive_values(
        window_hours_values,
        "window_hours_values",
    )
    nfe_values = Int.(collect(nfe_per_window_values))
    isempty(nfe_values) && throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep nfe_per_window_values must not be empty."),
    )
    all(value -> value > 0, nfe_values) || throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep nfe_per_window_values must be positive."),
    )
    policies = [
        _reduced_mpcc_window_validate_continuation_policy(policy) for
        policy in collect(continuation_acceptance_policies)
    ]
    isempty(policies) && throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep continuation_acceptance_policies must not be empty."),
    )
    thresholds = [
        _reduced_mpcc_window_validate_state_relative_rmse_threshold(threshold) for
        threshold in collect(continuation_state_relative_rmse_threshold_values)
    ]
    isempty(thresholds) && throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep continuation_state_relative_rmse_threshold_values must not be empty."),
    )
    linear_solvers = [
        _canonical_ipopt_linear_solver(value) for value in collect(linear_solver_values)
    ]
    isempty(linear_solvers) && throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep linear_solver_values must not be empty."),
    )
    complementarity_taus = [
        _reduced_dcdfba_mpcc_validate_complementarity_tau(value) for
        value in collect(complementarity_tau_values)
    ]
    isempty(complementarity_taus) && throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep complementarity_tau_values must not be empty."),
    )

    specs = NamedTuple[]
    index = 0
    for target in horizons
        for duration in window_hours
            _reduced_mpcc_windowed_policy_horizon_n_windows(target, duration)
            for nfe in nfe_values
                for policy in policies
                    for threshold in thresholds
                        for linear_solver in linear_solvers
                            for complementarity_tau in complementarity_taus
                                index += 1
                                push!(
                                    specs,
                                    (
                                        policy_case_id =
                                            _reduced_mpcc_windowed_policy_horizon_case_id(index),
                                        case_index = index,
                                        t0 = initial_time,
                                        target_horizon = target,
                                        window_hours = duration,
                                        nfe_per_window = nfe,
                                        degree = degree,
                                        boundary_dt = duration / nfe,
                                        continuation_acceptance_policy = policy,
                                        continuation_state_relative_rmse_threshold = threshold,
                                        ipopt_max_iter = ipopt_max_iter,
                                        linear_solver = linear_solver,
                                        complementarity_tau = complementarity_tau,
                                    ),
                                )
                            end
                        end
                    end
                end
            end
        end
    end
    return specs
end

function _reduced_mpcc_windowed_policy_horizon_positive_values(values, label::AbstractString)
    collected = Float64.(collect(values))
    isempty(collected) && throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep $(label) must not be empty."),
    )
    all(value -> isfinite(value) && value > 0.0, collected) || throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep $(label) must be finite and positive."),
    )
    return collected
end

function _reduced_mpcc_windowed_policy_horizon_n_windows(
    target_horizon::Float64,
    window_hours::Float64,
)::Int
    raw = target_horizon / window_hours
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || throw(
        ArgumentError(
            "Reduced MPCC windowed policy/horizon sweep target_horizon $(target_horizon) " *
            "is not an integer multiple of window_hours $(window_hours).",
        ),
    )
    n_windows > 0 || throw(
        ArgumentError("Reduced MPCC windowed policy/horizon sweep computed window count must be positive."),
    )
    return n_windows
end

function _reduced_mpcc_windowed_policy_horizon_row_from_attempt(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    case_index::Int;
    spec = nothing,
)::Dict{String, Any}
    metadata = attempt.metadata
    global_row = _reduced_mpcc_windowed_policy_horizon_global_row(attempt.attempt_table)
    global_state_rmse =
        _reduced_mpcc_windowed_policy_horizon_global_state_relative_rmse(
            metadata,
            global_row,
        )
    window_hours = _reduced_mpcc_windowed_policy_horizon_spec_or_metadata(
        spec,
        metadata,
        "window_hours",
    )
    nfe = _reduced_mpcc_windowed_policy_horizon_spec_or_metadata(
        spec,
        metadata,
        "nfe_per_window",
    )
    row = Dict{String, Any}(
        "policy_case_id" =>
            spec === nothing ? _reduced_mpcc_windowed_policy_horizon_case_id(case_index) :
            spec.policy_case_id,
        "case_index" => case_index,
        "case_status" => "completed",
        "target_horizon" =>
            _reduced_mpcc_windowed_policy_horizon_spec_or_metadata(
                spec,
                metadata,
                "target_horizon",
            ),
        "window_hours" => window_hours,
        "nfe_per_window" => nfe,
        "degree" =>
            _reduced_mpcc_windowed_policy_horizon_spec_or_metadata(spec, metadata, "degree"),
        "boundary_dt" =>
            _reduced_mpcc_windowed_policy_horizon_boundary_dt(window_hours, nfe),
        "ipopt_max_iter" => spec === nothing ? missing : spec.ipopt_max_iter,
        "linear_solver" =>
            spec === nothing ? get(metadata, "linear_solver", missing) : spec.linear_solver,
        "continuation_acceptance_policy" =>
            get(metadata, "continuation_acceptance_policy", missing),
        "continuation_state_relative_rmse_threshold" =>
            get(metadata, "continuation_state_relative_rmse_threshold", missing),
        "continuation_state_drift_gate_enabled" =>
            get(metadata, "continuation_state_drift_gate_enabled", false),
        "ipopt_profile" => get(metadata, "ipopt_profile", missing),
        "complementarity_mode" => get(metadata, "complementarity_mode", missing),
        "complementarity_tau" =>
            spec === nothing ? get(metadata, "complementarity_tau", missing) :
            spec.complementarity_tau,
        "tau_schedule" => get(metadata, "tau_schedule", missing),
        "tau_continuation_stage_count" =>
            _reduced_mpcc_windowed_policy_horizon_row_or_metadata(
                metadata,
                global_row,
                "tau_continuation_stage_count",
            ),
        "tau_continuation_completed" =>
            _reduced_mpcc_windowed_policy_horizon_row_or_metadata(
                metadata,
                global_row,
                "tau_continuation_completed",
            ),
        "tau_continuation_final_residual_feasible" =>
            _reduced_mpcc_windowed_policy_horizon_row_or_metadata(
                metadata,
                global_row,
                "tau_continuation_final_residual_feasible",
            ),
        "tau_continuation_final_tau_gate_pass" =>
            _reduced_mpcc_windowed_policy_horizon_row_or_metadata(
                metadata,
                global_row,
                "tau_continuation_final_tau_gate_pass",
            ),
        "tau_continuation_blocking_stage" =>
            _reduced_mpcc_windowed_policy_horizon_row_or_metadata(
                metadata,
                global_row,
                "tau_continuation_blocking_stage",
            ),
        "tau_continuation_blocking_reason" =>
            _reduced_mpcc_windowed_policy_horizon_row_or_metadata(
                metadata,
                global_row,
                "tau_continuation_blocking_reason",
            ),
        "tau_continuation_stage_advance_count" =>
            _reduced_mpcc_windowed_policy_horizon_row_or_metadata(
                metadata,
                global_row,
                "tau_continuation_stage_advance_count",
            ),
        "n_requested_windows" => get(metadata, "n_requested_windows", missing),
        "n_completed_windows" => get(metadata, "n_completed_windows", missing),
        "n_failed_windows" => get(metadata, "n_failed_windows", missing),
        "horizon_reached" => get(metadata, "horizon_reached", missing),
        "horizon_gap" => get(metadata, "horizon_gap", missing),
        "target_completion_fraction" =>
            get(metadata, "target_completion_fraction", missing),
        "target_completed" => get(metadata, "target_completed", false),
        "attempt_traffic_light" => get(metadata, "attempt_traffic_light", missing),
        "attempt_viable" => get(metadata, "attempt_viable", false),
        "global_traffic_light" => get(metadata, "global_traffic_light", missing),
        "global_viability_class" => get(metadata, "global_viability_class", missing),
        "is_last_green" => false,
        "is_first_non_green_after_green" => false,
        "window_green_count" => get(metadata, "window_green_count", missing),
        "window_yellow_count" => get(metadata, "window_yellow_count", missing),
        "window_red_count" => get(metadata, "window_red_count", missing),
        "continuation_policy_rejected_window_count" =>
            get(metadata, "continuation_policy_rejected_window_count", missing),
        "iteration_limit_policy_accepted_window_count" =>
            get(metadata, "iteration_limit_policy_accepted_window_count", missing),
        "state_drift_gate_pass_window_count" =>
            get(metadata, "state_drift_gate_pass_window_count", missing),
        "first_non_green_window_id" =>
            get(metadata, "first_non_green_window_id", missing),
        "first_non_green_window_index" =>
            get(metadata, "first_non_green_window_index", missing),
        "first_non_green_window_class" =>
            get(metadata, "first_non_green_window_class", missing),
        "first_red_window_id" => get(metadata, "first_red_window_id", missing),
        "first_red_window_index" => get(metadata, "first_red_window_index", missing),
        "first_red_window_class" => get(metadata, "first_red_window_class", missing),
        "first_not_residual_feasible_window_id" =>
            get(metadata, "first_not_residual_feasible_window_id", missing),
        "first_not_residual_feasible_window_index" =>
            get(metadata, "first_not_residual_feasible_window_index", missing),
        "first_not_residual_feasible_window_class" =>
            get(metadata, "first_not_residual_feasible_window_class", missing),
        "solver_status" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(global_row, "solver_status"),
        "max_rhs_residual" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(global_row, "max_rhs_residual"),
        "max_mass_balance_residual" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_mass_balance_residual",
            ),
        "max_lower_bound_violation" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_lower_bound_violation",
            ),
        "max_upper_bound_violation" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_upper_bound_violation",
            ),
        "max_stationarity_residual" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_stationarity_residual",
            ),
        "max_lower_complementarity_residual" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_lower_complementarity_residual",
            ),
        "max_upper_complementarity_residual" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_upper_complementarity_residual",
            ),
        "max_lower_complementarity_product" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_lower_complementarity_product",
            ),
        "max_upper_complementarity_product" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_upper_complementarity_product",
            ),
        "max_complementarity_tau_violation" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_complementarity_tau_violation",
            ),
        "max_complementarity_tau_violation_raw" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_complementarity_tau_violation_raw",
            ),
        "complementarity_tau_gate_tolerance" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "complementarity_tau_gate_tolerance",
            ),
        "complementarity_tau_gate_tolerance_source" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "complementarity_tau_gate_tolerance_source",
            ),
        "complementarity_tau_gate_pass" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "complementarity_tau_gate_pass",
            ),
        "max_state_relative_rmse" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(
                global_row,
                "max_state_relative_rmse",
            ),
        "global_max_state_relative_rmse" =>
            global_state_rmse,
        "total_solve_elapsed_seconds" =>
            get(metadata, "total_solve_elapsed_seconds", missing),
        "recommended_next_action" => get(metadata, "recommended_next_action", missing),
        "blocking_reasons" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(global_row, "blocking_reasons"),
        "review_reasons" =>
            _reduced_mpcc_windowed_policy_horizon_row_value(global_row, "review_reasons"),
        "outputs_written" => get(metadata, "outputs_written", false),
        "sweep_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => get(metadata, "solved_trajectory_claimed", false),
        "first_mpcc_target" => get(metadata, "first_mpcc_target", "reduced_dfba"),
        "full_model_kkt_deferred" => get(metadata, "full_model_kkt_deferred", true),
        "dfvb_kkt_deferred" => get(metadata, "dfvb_kkt_deferred", true),
        "hsl_required" => get(metadata, "hsl_required", false),
        "ma57_required" => get(metadata, "ma57_required", false),
        "indices_reacciones_used" => get(metadata, "indices_reacciones_used", false),
        "r0001_used_as_oxygen" => get(metadata, "r0001_used_as_oxygen", false),
        "error_type" => missing,
        "error_message" => missing,
    )
    _reduced_mpcc_windowed_policy_horizon_annotate_scale_readiness!(row)
    return row
end

function _reduced_mpcc_windowed_policy_horizon_error_row(spec, err)::Dict{String, Any}
    row = Dict{String, Any}(
        column => missing for
        column in REDUCED_DCDFBA_MPCC_WINDOWED_POLICY_HORIZON_SWEEP_COLUMNS
    )
    row["policy_case_id"] = spec.policy_case_id
    row["case_index"] = spec.case_index
    row["case_status"] = "failed"
    row["target_horizon"] = spec.target_horizon
    row["window_hours"] = spec.window_hours
    row["nfe_per_window"] = spec.nfe_per_window
    row["degree"] = spec.degree
    row["boundary_dt"] = spec.boundary_dt
    row["ipopt_max_iter"] = spec.ipopt_max_iter
    row["linear_solver"] = spec.linear_solver
    row["continuation_acceptance_policy"] = spec.continuation_acceptance_policy
    row["continuation_state_relative_rmse_threshold"] =
        spec.continuation_state_relative_rmse_threshold
    row["complementarity_tau"] = spec.complementarity_tau
    row["continuation_state_drift_gate_enabled"] =
        spec.continuation_acceptance_policy ==
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_ITERATION_LIMIT_STATE_DRIFT
    row["n_requested_windows"] =
        _reduced_mpcc_windowed_policy_horizon_n_windows(
            spec.target_horizon,
            spec.window_hours,
        )
    row["n_completed_windows"] = 0
    row["n_failed_windows"] = 1
    row["horizon_reached"] = 0.0
    row["horizon_gap"] = spec.target_horizon
    row["target_completion_fraction"] = 0.0
    row["target_completed"] = false
    row["attempt_traffic_light"] = "red"
    row["attempt_viable"] = false
    row["global_traffic_light"] = "red"
    row["global_viability_class"] = "failed_diagnostic_row"
    row["scale_readiness"] = "blocked"
    row["primary_blocker"] = "failed_case"
    row["scale_recommended_next_action"] = "inspect_failed_policy_horizon_case"
    row["is_scale_candidate"] = false
    row["is_72h_ready_candidate"] = false
    row["next_target_horizon_hint"] = missing
    row["is_last_green"] = false
    row["is_first_non_green_after_green"] = false
    row["window_green_count"] = 0
    row["window_yellow_count"] = 0
    row["window_red_count"] = 0
    row["continuation_policy_rejected_window_count"] = 0
    row["iteration_limit_policy_accepted_window_count"] = 0
    row["state_drift_gate_pass_window_count"] = 0
    row["recommended_next_action"] = "inspect_failed_policy_horizon_case"
    row["blocking_reasons"] = "source_row_not_completed"
    row["review_reasons"] = "inspect_failed_diagnostics_before_simulation"
    row["outputs_written"] = false
    row["sweep_is_scientific_simulation"] = false
    row["solved_trajectory_claimed"] = false
    row["first_mpcc_target"] = "reduced_dfba"
    row["full_model_kkt_deferred"] = true
    row["dfvb_kkt_deferred"] = true
    row["hsl_required"] = false
    row["ma57_required"] = false
    row["indices_reacciones_used"] = false
    row["r0001_used_as_oxygen"] = false
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_windowed_policy_horizon_metadata(
    rows::Vector{Dict{String, Any}},
    attempts::Vector{ReducedDCDFBAMPCCWindowedSimulationAttemptResult};
    requested_case_count::Int,
    stopped_after_first_non_green::Bool,
    ipopt_max_iter,
)::Dict{String, Any}
    best_green = _reduced_mpcc_windowed_policy_horizon_best_green_row(rows)
    max_horizon = _reduced_mpcc_windowed_policy_horizon_max_horizon_row(rows)
    first_non_green =
        _reduced_mpcc_windowed_policy_horizon_first_non_green_after_green_row(rows)
    first_blocked = _reduced_mpcc_windowed_policy_horizon_first_blocked_row(rows)
    green_count = count(row -> get(row, "attempt_traffic_light", missing) == "green", rows)
    yellow_count = count(row -> get(row, "attempt_traffic_light", missing) == "yellow", rows)
    red_count = count(row -> get(row, "attempt_traffic_light", missing) == "red", rows)
    return Dict{String, Any}(
        "sweep_type" => REDUCED_DCDFBA_MPCC_WINDOWED_POLICY_HORIZON_SWEEP_TYPE,
        "n_requested_cases" => requested_case_count,
        "n_cases" => length(rows),
        "n_completed_cases" => count(row -> get(row, "case_status", "") == "completed", rows),
        "n_failed_cases" => count(row -> get(row, "case_status", "") == "failed", rows),
        "n_attempt_results" => length(attempts),
        "green_count" => green_count,
        "yellow_count" => yellow_count,
        "red_count" => red_count,
        "target_completed_count" =>
            count(row -> get(row, "target_completed", false) === true, rows),
        "attempt_viable_count" =>
            count(row -> get(row, "attempt_viable", false) === true, rows),
        "scale_candidate_count" =>
            count(row -> get(row, "is_scale_candidate", false) === true, rows),
        "review_before_scaling_count" =>
            count(row -> get(row, "scale_readiness", "") == "review_before_scaling", rows),
        "blocked_case_count" =>
            count(row -> get(row, "scale_readiness", "") == "blocked", rows),
        "scale_readiness_counts" =>
            _reduced_mpcc_windowed_policy_horizon_value_counts(rows, "scale_readiness"),
        "primary_blocker_counts" =>
            _reduced_mpcc_windowed_policy_horizon_value_counts(rows, "primary_blocker"),
        "policy_counts" =>
            _reduced_mpcc_windowed_policy_horizon_value_counts(
                rows,
                "continuation_acceptance_policy",
            ),
        "traffic_light_counts" =>
            _reduced_mpcc_windowed_policy_horizon_value_counts(
                rows,
                "attempt_traffic_light",
            ),
        "best_green_case_id" =>
            _reduced_mpcc_windowed_policy_horizon_value(best_green, "policy_case_id"),
        "best_green_target_horizon" =>
            _reduced_mpcc_windowed_policy_horizon_value(best_green, "target_horizon"),
        "best_green_horizon_reached" =>
            _reduced_mpcc_windowed_policy_horizon_value(best_green, "horizon_reached"),
        "best_green_policy" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                best_green,
                "continuation_acceptance_policy",
            ),
        "best_green_window_hours" =>
            _reduced_mpcc_windowed_policy_horizon_value(best_green, "window_hours"),
        "best_green_nfe_per_window" =>
            _reduced_mpcc_windowed_policy_horizon_value(best_green, "nfe_per_window"),
        "best_green_state_relative_rmse_threshold" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                best_green,
                "continuation_state_relative_rmse_threshold",
            ),
        "best_green_global_state_relative_rmse" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                best_green,
                "global_max_state_relative_rmse",
            ),
        "best_scale_candidate_case_id" =>
            _reduced_mpcc_windowed_policy_horizon_value(best_green, "policy_case_id"),
        "best_scale_candidate_next_target_horizon_hint" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                best_green,
                "next_target_horizon_hint",
            ),
        "best_scale_candidate_recommended_next_action" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                best_green,
                "scale_recommended_next_action",
            ),
        "max_horizon_case_id" =>
            _reduced_mpcc_windowed_policy_horizon_value(max_horizon, "policy_case_id"),
        "max_horizon_reached" =>
            _reduced_mpcc_windowed_policy_horizon_value(max_horizon, "horizon_reached"),
        "max_horizon_target_horizon" =>
            _reduced_mpcc_windowed_policy_horizon_value(max_horizon, "target_horizon"),
        "max_horizon_policy" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                max_horizon,
                "continuation_acceptance_policy",
            ),
        "first_non_green_case_id" =>
            _reduced_mpcc_windowed_policy_horizon_value(first_non_green, "policy_case_id"),
        "first_non_green_target_horizon" =>
            _reduced_mpcc_windowed_policy_horizon_value(first_non_green, "target_horizon"),
        "first_non_green_policy" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                first_non_green,
                "continuation_acceptance_policy",
            ),
        "first_non_green_traffic_light" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                first_non_green,
                "attempt_traffic_light",
            ),
        "first_non_green_viability_class" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                first_non_green,
                "global_viability_class",
            ),
        "first_non_green_blocking_reasons" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                first_non_green,
                "blocking_reasons",
            ),
        "first_blocked_case_id" =>
            _reduced_mpcc_windowed_policy_horizon_value(first_blocked, "policy_case_id"),
        "first_blocked_primary_blocker" =>
            _reduced_mpcc_windowed_policy_horizon_value(first_blocked, "primary_blocker"),
        "first_blocked_scale_recommended_next_action" =>
            _reduced_mpcc_windowed_policy_horizon_value(
                first_blocked,
                "scale_recommended_next_action",
            ),
        "all_requested_cases_green" => !isempty(rows) && green_count == length(rows),
        "sweep_reached_green" => best_green !== nothing,
        "sweep_blocked" => first_non_green !== nothing,
        "stopped_after_first_non_green" => stopped_after_first_non_green,
        "ipopt_max_iter" => ipopt_max_iter,
        "total_solve_elapsed_seconds" =>
            _reduced_mpcc_windowed_policy_horizon_sum(rows, "total_solve_elapsed_seconds"),
        "recommended_next_action" =>
            _reduced_mpcc_windowed_policy_horizon_recommended_action(
                best_green,
                first_non_green,
                rows,
            ),
        "outputs_written" => false,
        "sweep_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC windowed policy/horizon sweep; diagnostic only and not a validated scientific simulation.",
    )
end

function _reduced_mpcc_windowed_policy_horizon_recommended_action(
    best_green,
    first_non_green,
    rows::Vector{Dict{String, Any}},
)::String
    isempty(rows) && return "run_windowed_policy_horizon_smoke"
    best_green === nothing && return "recover_short_windowed_policy_case_before_scaling"
    first_non_green === nothing && return "extend_windowed_policy_horizon_grid"
    first_blocked = _reduced_mpcc_windowed_policy_horizon_first_blocked_row(rows)
    first_blocked !== nothing &&
        return string(get(first_blocked, "scale_recommended_next_action", "inspect_first_blocked_policy_horizon_case"))
    class = string(get(first_non_green, "global_viability_class", "unknown"))
    blocking = string(get(first_non_green, "blocking_reasons", ""))
    if occursin("state_drift", class) || occursin("state_drift", blocking)
        return "reduce_windowed_state_drift_before_72h"
    elseif class == "iteration_limit_residual_feasible_candidate" ||
           occursin("candidate_not_trajectory_ready", blocking)
        return "improve_solver_termination_or_retry_frontier_windows"
    elseif occursin("residual", class) || occursin("residual", blocking)
        return "repair_residual_feasibility_at_policy_frontier"
    else
        return "inspect_first_non_green_policy_horizon_case"
    end
end

function _reduced_mpcc_windowed_policy_horizon_annotate_scale_readiness!(
    row::Dict{String, Any},
)::Dict{String, Any}
    readiness, blocker, action = _reduced_mpcc_windowed_policy_horizon_scale_decision(row)
    row["scale_readiness"] = readiness
    row["primary_blocker"] = blocker
    row["scale_recommended_next_action"] = action
    row["is_scale_candidate"] = readiness == "scale_candidate"
    row["is_72h_ready_candidate"] =
        readiness == "scale_candidate" &&
        _reduced_mpcc_windowed_policy_horizon_float_or_neginf(
            get(row, "target_horizon", missing),
        ) >= 72.0
    row["next_target_horizon_hint"] =
        readiness == "scale_candidate" ?
        _reduced_mpcc_windowed_policy_horizon_next_target_hint(row) :
        missing
    return row
end

function _reduced_mpcc_windowed_policy_horizon_scale_decision(
    row::Dict{String, Any},
)::Tuple{String, String, String}
    get(row, "case_status", "") == "completed" ||
        return ("blocked", "failed_case", "inspect_failed_policy_horizon_case")

    target_completed = get(row, "target_completed", false) === true
    light = string(get(row, "attempt_traffic_light", "missing"))
    class = string(get(row, "global_viability_class", "missing"))
    blocking = string(get(row, "blocking_reasons", ""))
    review = string(get(row, "review_reasons", ""))

    if target_completed && light == "green"
        target = _reduced_mpcc_windowed_policy_horizon_float_or_neginf(
            get(row, "target_horizon", missing),
        )
        action = target >= 72.0 ?
                 "review_72h_candidate_before_scientific_use" :
                 "extend_windowed_policy_horizon_grid"
        return ("scale_candidate", "none", action)
    elseif occursin("state_drift", class) || occursin("state_drift", blocking)
        return ("blocked", "state_drift", "reduce_windowed_state_drift_before_72h")
    elseif class == "residual_thresholds_failed" ||
           occursin("candidate_not_residual_feasible", blocking) ||
           occursin("residual_thresholds_failed", blocking)
        return ("blocked", "residual_feasibility", "repair_residual_feasibility_at_policy_frontier")
    elseif light == "yellow" ||
           class == "iteration_limit_residual_feasible_candidate" ||
           class == "residual_feasible_but_not_trajectory_ready" ||
           occursin("candidate_not_trajectory_ready", blocking) ||
           occursin("trajectory", class) ||
           occursin("ITERATION_LIMIT", string(get(row, "solver_status", ""))) ||
           occursin("iteration_limit", review)
        return ("review_before_scaling", "solver_termination", "retry_or_improve_solver_termination_before_scaling")
    elseif _reduced_mpcc_windowed_policy_horizon_float_or_neginf(
        get(row, "continuation_policy_rejected_window_count", 0),
    ) > 0.0
        return ("blocked", "continuation_policy", "review_or_relax_continuation_policy")
    elseif !target_completed
        return ("blocked", "target_incomplete", "extend_or_repair_windowed_continuation_to_target")
    else
        return ("blocked", "unknown", "inspect_first_blocked_policy_horizon_case")
    end
end

function _reduced_mpcc_windowed_policy_horizon_next_target_hint(
    row::Dict{String, Any},
)
    target = _reduced_mpcc_windowed_policy_horizon_float_or_neginf(
        get(row, "target_horizon", missing),
    )
    window_hours = _reduced_mpcc_windowed_policy_horizon_float_or_neginf(
        get(row, "window_hours", missing),
    )
    target > 0.0 || return missing
    target >= 72.0 && return 72.0
    increment = window_hours > 0.0 ? window_hours : target
    return min(72.0, max(2.0 * target, target + increment))
end

function _reduced_mpcc_windowed_policy_horizon_mark_boundary!(
    rows::Vector{Dict{String, Any}},
)
    for row in rows
        row["is_last_green"] = false
        row["is_first_non_green_after_green"] = false
    end
    best_green_index = _reduced_mpcc_windowed_policy_horizon_best_green_index(rows)
    best_green_index !== nothing && (rows[best_green_index]["is_last_green"] = true)
    if best_green_index === nothing
        index = findfirst(row -> get(row, "attempt_traffic_light", missing) != "green", rows)
        index !== nothing && (rows[index]["is_first_non_green_after_green"] = true)
    else
        for index in (best_green_index + 1):length(rows)
            if get(rows[index], "attempt_traffic_light", missing) != "green"
                rows[index]["is_first_non_green_after_green"] = true
                break
            end
        end
    end
    return rows
end

function _reduced_mpcc_windowed_policy_horizon_best_green_row(rows::Vector{Dict{String, Any}})
    index = _reduced_mpcc_windowed_policy_horizon_best_green_index(rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_windowed_policy_horizon_best_green_index(rows::Vector{Dict{String, Any}})
    candidates = [
        index for (index, row) in enumerate(rows) if
        get(row, "attempt_traffic_light", missing) == "green"
    ]
    isempty(candidates) && return nothing
    return candidates[argmax([
        (
            _reduced_mpcc_windowed_policy_horizon_float_or_neginf(
                get(rows[index], "horizon_reached", missing),
            ),
            _reduced_mpcc_windowed_policy_horizon_float_or_neginf(
                get(rows[index], "target_horizon", missing),
            ),
            -_reduced_mpcc_windowed_policy_horizon_float_or_inf(
                get(rows[index], "global_max_state_relative_rmse", missing),
            ),
        ) for index in candidates
    ])]
end

function _reduced_mpcc_windowed_policy_horizon_max_horizon_row(rows::Vector{Dict{String, Any}})
    isempty(rows) && return nothing
    index = argmax([
        _reduced_mpcc_windowed_policy_horizon_float_or_neginf(
            get(row, "horizon_reached", missing),
        ) for row in rows
    ])
    return rows[index]
end

function _reduced_mpcc_windowed_policy_horizon_first_non_green_after_green_row(
    rows::Vector{Dict{String, Any}},
)
    isempty(rows) && return nothing
    best_green_index = _reduced_mpcc_windowed_policy_horizon_best_green_index(rows)
    if best_green_index === nothing
        index = findfirst(row -> get(row, "attempt_traffic_light", missing) != "green", rows)
        return index === nothing ? nothing : rows[index]
    end
    best_green_index == length(rows) && return nothing
    for index in (best_green_index + 1):length(rows)
        get(rows[index], "attempt_traffic_light", missing) != "green" && return rows[index]
    end
    return nothing
end

function _reduced_mpcc_windowed_policy_horizon_first_blocked_row(
    rows::Vector{Dict{String, Any}},
)
    index = findfirst(row -> get(row, "scale_readiness", "") == "blocked", rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_windowed_policy_horizon_table(
    rows::Vector{Dict{String, Any}},
)::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_windowed_policy_horizon_table_scalar(get(row, column, missing)) for
                row in rows
            ] for column in REDUCED_DCDFBA_MPCC_WINDOWED_POLICY_HORIZON_SWEEP_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_policy_horizon_global_row(table::DataFrame)
    nrow(table) == 0 && return nothing
    if "candidate_id" in names(table)
        index = findfirst(==("windowed_global"), String.(table[!, "candidate_id"]))
        index !== nothing && return table[index, :]
    end
    if "source_type" in names(table)
        index = findfirst(==("windowed_continuation_global"), String.(table[!, "source_type"]))
        index !== nothing && return table[index, :]
    end
    return table[1, :]
end

function _reduced_mpcc_windowed_policy_horizon_row_value(row, key::AbstractString)
    row === nothing && return missing
    column = String(key)
    column in names(parent(row)) || return missing
    return row[column]
end

function _reduced_mpcc_windowed_policy_horizon_row_or_metadata(
    metadata,
    row,
    key::AbstractString,
)
    row_value = _reduced_mpcc_windowed_policy_horizon_row_value(row, key)
    row_value === missing || return row_value
    return get(metadata, String(key), missing)
end

function _reduced_mpcc_windowed_policy_horizon_global_state_relative_rmse(
    metadata,
    global_row,
)
    metadata_value = get(metadata, "global_max_state_relative_rmse", missing)
    _reduced_mpcc_windowed_policy_horizon_isfinite_number(metadata_value) &&
        return metadata_value
    row_global =
        _reduced_mpcc_windowed_policy_horizon_row_value(
            global_row,
            "global_max_state_relative_rmse",
        )
    _reduced_mpcc_windowed_policy_horizon_isfinite_number(row_global) &&
        return row_global
    return _reduced_mpcc_windowed_policy_horizon_row_value(
        global_row,
        "max_state_relative_rmse",
    )
end

function _reduced_mpcc_windowed_policy_horizon_spec_or_metadata(spec, metadata, key::AbstractString)
    if spec !== nothing
        symbol = Symbol(key)
        haskey(spec, symbol) && return getfield(spec, symbol)
    end
    return get(metadata, String(key), missing)
end

function _reduced_mpcc_windowed_policy_horizon_boundary_dt(window_hours, nfe)
    _reduced_mpcc_windowed_policy_horizon_isfinite_number(window_hours) || return missing
    _reduced_mpcc_windowed_policy_horizon_isfinite_number(nfe) || return missing
    Int(nfe) > 0 || return missing
    return Float64(window_hours) / Int(nfe)
end

function _reduced_mpcc_windowed_policy_horizon_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_policy_horizon_value_counts(
    rows::Vector{Dict{String, Any}},
    key::AbstractString,
)::Dict{String, Int}
    counts = Dict{String, Int}()
    for row in rows
        value = get(row, String(key), missing)
        value === missing && continue
        label = string(value)
        counts[label] = get(counts, label, 0) + 1
    end
    return counts
end

function _reduced_mpcc_windowed_policy_horizon_sum(
    rows::Vector{Dict{String, Any}},
    key::AbstractString,
)::Float64
    total = 0.0
    for row in rows
        value = get(row, String(key), missing)
        _reduced_mpcc_windowed_policy_horizon_isfinite_number(value) || continue
        total += Float64(value)
    end
    return total
end

function _reduced_mpcc_windowed_policy_horizon_case_id(index::Int)::String
    return "window_policy_horizon_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_windowed_policy_horizon_float_or_inf(value)::Float64
    _reduced_mpcc_windowed_policy_horizon_isfinite_number(value) || return Inf
    return Float64(value)
end

function _reduced_mpcc_windowed_policy_horizon_float_or_neginf(value)::Float64
    _reduced_mpcc_windowed_policy_horizon_isfinite_number(value) || return -Inf
    return Float64(value)
end

function _reduced_mpcc_windowed_policy_horizon_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_windowed_policy_horizon_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
