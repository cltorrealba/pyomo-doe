import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_DIAGNOSTIC_TYPE =
    "reduced_dcdfba_mpcc_windowed_drift_diagnostics"

const REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_WINDOW_COLUMNS = [
    "window_id",
    "window_index",
    "t0",
    "tfinal",
    "window_hours",
    "solver_status",
    "primal_status",
    "residual_feasible",
    "iteration_limit_residual_feasible",
    "trajectory_ready",
    "allows_continuation",
    "traffic_light",
    "viability_class",
    "max_state_abs_difference",
    "max_state_abs_ratio",
    "max_state_relative_rmse",
    "max_state_relative_ratio",
    "state_drift_pass",
    "dominant_abs_state",
    "dominant_abs_difference",
    "dominant_abs_time",
    "dominant_relative_state",
    "dominant_relative_rmse",
    "dominant_relative_ratio",
    "dominant_final_state",
    "dominant_final_difference",
    "final_biomass_difference",
    "final_total_sugar_difference",
    "max_mass_balance_residual",
    "blocking_reasons",
    "review_reasons",
]

const REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_STATE_COLUMNS = [
    "scope",
    "window_id",
    "window_index",
    "state_name",
    "is_focus_state",
    "initial_sequential",
    "initial_mpcc_candidate",
    "final_sequential",
    "final_mpcc_candidate",
    "final_difference_mpcc_minus_sequential",
    "abs_final_difference",
    "max_abs_difference",
    "max_abs_ratio",
    "rmse",
    "relative_rmse",
    "relative_rmse_ratio",
    "abs_drift_pass",
    "relative_drift_pass",
    "state_drift_pass",
    "rank_abs_within_scope",
    "rank_relative_within_scope",
    "solver_status",
    "trajectory_ready",
    "notes",
]

const REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_TIMEPOINT_COLUMNS = [
    "scope",
    "window_id",
    "window_index",
    "time",
    "state_name",
    "is_focus_state",
    "sequential_value",
    "mpcc_candidate_value",
    "difference_mpcc_minus_sequential",
    "abs_difference",
    "abs_difference_ratio",
    "relative_difference",
    "is_window_max_abs_difference",
    "is_global_max_abs_difference",
]

const REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_FOCUS_STATES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "total_sugar",
    "ethanol",
    "protein",
    "carbohydrate",
]

"""
    ReducedDCDFBAMPCCWindowedDriftDiagnosticResult

Drift-oriented diagnostic for reduced MPCC windowed attempts. It ranks
state-drift by window, state, and time point against reduced sequential DFBA.
This is diagnostic-only: it writes no outputs, does not alter thresholds, and
does not validate a scientific simulation.
"""
struct ReducedDCDFBAMPCCWindowedDriftDiagnosticResult
    window_drift_table::DataFrame
    state_drift_table::DataFrame
    timepoint_drift_table::DataFrame
    attempt_result::Union{Nothing, ReducedDCDFBAMPCCWindowedSimulationAttemptResult}
    metadata::Dict{String, Any}
end

"""
    diagnose_reduced_dcdfba_mpcc_windowed_drift(attempt; thresholds=attempt.viability_report.thresholds)

Diagnose state drift in an already-computed reduced MPCC windowed target-horizon
attempt.
"""
function diagnose_reduced_dcdfba_mpcc_windowed_drift(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult;
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        attempt.viability_report.thresholds,
)::ReducedDCDFBAMPCCWindowedDriftDiagnosticResult
    return _reduced_mpcc_windowed_drift_result(
        attempt.continuation_result,
        thresholds,
        attempt,
    )
end

"""
    diagnose_reduced_dcdfba_mpcc_windowed_drift(continuation; thresholds=...)

Diagnose state drift in a reduced MPCC windowed-continuation diagnostic.
"""
function diagnose_reduced_dcdfba_mpcc_windowed_drift(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult;
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(),
)::ReducedDCDFBAMPCCWindowedDriftDiagnosticResult
    return _reduced_mpcc_windowed_drift_result(continuation, thresholds, nothing)
end

"""
    diagnose_reduced_dcdfba_mpcc_windowed_drift(model, reaction_map; kwargs...)

Run a reduced MPCC windowed attempt with a chosen mass-balance diagnostic gate
and return drift diagnostics. The model, KKT/MPCC formulation, Ipopt/MUMPS path,
and scientific guardrails are unchanged.
"""
function diagnose_reduced_dcdfba_mpcc_windowed_drift(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    max_mass_balance_residual::Real = 5.0e-6,
    target_horizon::Real = 8.0,
    t0::Real = 0.0,
    window_hours::Real = 0.5,
    nfe_per_window::Int = 2,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    tau_schedule = nothing,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_abs_difference_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_ABS_DIFFERENCE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    viability_thresholds::Union{Nothing, ReducedDCDFBAMPCCSimulationViabilityThresholds} =
        nothing,
    silent::Bool = true,
    continue_on_error::Bool = true,
    window_callback = nothing,
)::ReducedDCDFBAMPCCWindowedDriftDiagnosticResult
    mass_threshold = Float64(max_mass_balance_residual)
    isfinite(mass_threshold) && mass_threshold > 0.0 || throw(
        ArgumentError("Reduced MPCC windowed drift max_mass_balance_residual must be finite and positive."),
    )
    case_residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds(
        max_rhs_residual = residual_thresholds.max_rhs_residual,
        max_mass_balance_residual = mass_threshold,
        max_lower_bound_violation = residual_thresholds.max_lower_bound_violation,
        max_upper_bound_violation = residual_thresholds.max_upper_bound_violation,
        max_stationarity_residual = residual_thresholds.max_stationarity_residual,
        max_lower_complementarity_residual =
            residual_thresholds.max_lower_complementarity_residual,
        max_upper_complementarity_residual =
            residual_thresholds.max_upper_complementarity_residual,
    )
    case_viability_thresholds =
        viability_thresholds === nothing ?
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = case_residual_thresholds,
        ) :
        viability_thresholds
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        model,
        reaction_map;
        target_horizon = target_horizon,
        t0 = t0,
        window_hours = window_hours,
        nfe_per_window = nfe_per_window,
        degree = degree,
        y0 = y0,
        params = params,
        sequential_optimizer = sequential_optimizer,
        sequential_algorithm = sequential_algorithm,
        sequential_ode_abstol = sequential_ode_abstol,
        sequential_ode_reltol = sequential_ode_reltol,
        sequential_lp_atol = sequential_lp_atol,
        sequential_adaptive = sequential_adaptive,
        sequential_dt = sequential_dt,
        sequential_nonnegative = sequential_nonnegative,
        sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
        mpcc_optimizer = mpcc_optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        complementarity_tau_gate_tol = complementarity_tau_gate_tol,
        tau_schedule = tau_schedule,
        require_pre_solve_ready = require_pre_solve_ready,
        residual_thresholds = case_residual_thresholds,
        continuation_acceptance_policy = continuation_acceptance_policy,
        continuation_state_abs_difference_threshold =
            continuation_state_abs_difference_threshold,
        continuation_state_relative_rmse_threshold =
            continuation_state_relative_rmse_threshold,
        viability_thresholds = case_viability_thresholds,
        silent = silent,
        continue_on_error = continue_on_error,
        window_callback = window_callback,
    )
    return diagnose_reduced_dcdfba_mpcc_windowed_drift(
        attempt;
        thresholds = case_viability_thresholds,
    )
end

function _reduced_mpcc_windowed_drift_result(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
    attempt::Union{Nothing, ReducedDCDFBAMPCCWindowedSimulationAttemptResult},
)::ReducedDCDFBAMPCCWindowedDriftDiagnosticResult
    _validate_reduced_mpcc_viability_thresholds(thresholds)
    window_rows = _reduced_mpcc_windowed_drift_window_rows(continuation, attempt, thresholds)
    state_rows = _reduced_mpcc_windowed_drift_state_rows(continuation, thresholds)
    timepoint_rows = _reduced_mpcc_windowed_drift_timepoint_rows(continuation, thresholds)
    metadata =
        _reduced_mpcc_windowed_drift_metadata(continuation, attempt, window_rows, state_rows, timepoint_rows, thresholds)
    return ReducedDCDFBAMPCCWindowedDriftDiagnosticResult(
        _reduced_mpcc_windowed_drift_window_table(window_rows),
        _reduced_mpcc_windowed_drift_state_table(state_rows),
        _reduced_mpcc_windowed_drift_timepoint_table(timepoint_rows),
        attempt,
        metadata,
    )
end

function _reduced_mpcc_windowed_drift_window_rows(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    attempt::Union{Nothing, ReducedDCDFBAMPCCWindowedSimulationAttemptResult},
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Vector{Dict{String, Any}}
    viability_by_id =
        attempt === nothing ? Dict{String, Any}() :
        Dict(String(row["candidate_id"]) => row for row in eachrow(attempt.viability_report.viability_table))
    rows = Dict{String, Any}[]
    for (index, comparison) in enumerate(continuation.window_comparisons)
        window_id = _reduced_mpcc_windowed_drift_window_id(index)
        window_row = _reduced_mpcc_windowed_drift_window_table_row(
            continuation.window_table,
            window_id,
        )
        viability_row = get(viability_by_id, window_id, nothing)
        metrics = comparison.state_metrics_table
        dominant_abs = _reduced_mpcc_windowed_drift_max_row(metrics, "max_abs_difference")
        dominant_relative = _reduced_mpcc_windowed_drift_max_row(metrics, "relative_rmse")
        dominant_final =
            _reduced_mpcc_windowed_drift_max_abs_row(metrics, "final_difference_mpcc_minus_sequential")
        max_abs = _reduced_mpcc_windowed_drift_row_value(dominant_abs, "max_abs_difference")
        max_relative = _reduced_mpcc_windowed_drift_row_value(dominant_relative, "relative_rmse")
        push!(
            rows,
            Dict{String, Any}(
                "window_id" => window_id,
                "window_index" => index,
                "t0" => first(comparison.sequential_result.time),
                "tfinal" => last(comparison.sequential_result.time),
                "window_hours" =>
                    last(comparison.sequential_result.time) - first(comparison.sequential_result.time),
                "solver_status" =>
                    _reduced_mpcc_windowed_drift_source_value(
                        window_row,
                        comparison.metadata,
                        "solver_status",
                        "candidate_solver_status",
                    ),
                "primal_status" =>
                    _reduced_mpcc_windowed_drift_source_value(
                        window_row,
                        comparison.metadata,
                        "primal_status",
                        "candidate_primal_status",
                    ),
                "residual_feasible" =>
                    _reduced_mpcc_windowed_drift_bool_value(
                        window_row,
                        comparison.metadata,
                        "candidate_residual_feasible",
                    ),
                "iteration_limit_residual_feasible" =>
                    _reduced_mpcc_windowed_drift_bool_value(
                        window_row,
                        comparison.metadata,
                        "candidate_iteration_limit_residual_feasible",
                    ),
                "trajectory_ready" =>
                    _reduced_mpcc_windowed_drift_bool_value(
                        window_row,
                        comparison.metadata,
                        "candidate_trajectory_ready",
                    ),
                "allows_continuation" =>
                    _reduced_mpcc_windowed_drift_row_value(
                        window_row,
                        "candidate_allows_continuation",
                    ),
                "traffic_light" =>
                    viability_row === nothing ? missing :
                    get(viability_row, "traffic_light", missing),
                "viability_class" =>
                    viability_row === nothing ? missing :
                    get(viability_row, "viability_class", missing),
                "max_state_abs_difference" => max_abs,
                "max_state_abs_ratio" =>
                    _reduced_mpcc_windowed_drift_ratio(max_abs, thresholds.max_state_abs_difference),
                "max_state_relative_rmse" => max_relative,
                "max_state_relative_ratio" =>
                    _reduced_mpcc_windowed_drift_ratio(max_relative, thresholds.max_state_relative_rmse),
                "state_drift_pass" =>
                    _reduced_mpcc_windowed_drift_metrics_scale_pass(metrics, thresholds),
                "dominant_abs_state" =>
                    _reduced_mpcc_windowed_drift_row_value(dominant_abs, "state_name"),
                "dominant_abs_difference" => max_abs,
                "dominant_abs_time" =>
                    _reduced_mpcc_windowed_drift_dominant_time(
                        comparison.aligned_timeseries_table,
                        _reduced_mpcc_windowed_drift_row_value(dominant_abs, "state_name"),
                    ),
                "dominant_relative_state" =>
                    _reduced_mpcc_windowed_drift_row_value(dominant_relative, "state_name"),
                "dominant_relative_rmse" => max_relative,
                "dominant_relative_ratio" =>
                    _reduced_mpcc_windowed_drift_ratio(max_relative, thresholds.max_state_relative_rmse),
                "dominant_final_state" =>
                    _reduced_mpcc_windowed_drift_row_value(dominant_final, "state_name"),
                "dominant_final_difference" =>
                    _reduced_mpcc_windowed_drift_row_value(
                        dominant_final,
                        "final_difference_mpcc_minus_sequential",
                    ),
                "final_biomass_difference" =>
                    _reduced_mpcc_windowed_drift_state_value(metrics, "biomass", "final_difference_mpcc_minus_sequential"),
                "final_total_sugar_difference" =>
                    _reduced_mpcc_windowed_drift_state_value(metrics, "total_sugar", "final_difference_mpcc_minus_sequential"),
                "max_mass_balance_residual" =>
                    _reduced_mpcc_windowed_drift_row_value(window_row, "max_mass_balance_residual"),
                "blocking_reasons" =>
                    viability_row === nothing ? missing :
                    get(viability_row, "blocking_reasons", missing),
                "review_reasons" =>
                    viability_row === nothing ? missing :
                    get(viability_row, "review_reasons", missing),
            ),
        )
    end
    return rows
end

function _reduced_mpcc_windowed_drift_state_rows(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    for (index, comparison) in enumerate(continuation.window_comparisons)
        window_id = _reduced_mpcc_windowed_drift_window_id(index)
        window_row = _reduced_mpcc_windowed_drift_window_table_row(
            continuation.window_table,
            window_id,
        )
        _reduced_mpcc_windowed_drift_append_state_rows!(
            rows,
            comparison.state_metrics_table,
            thresholds;
            scope = "window",
            window_id = window_id,
            window_index = index,
            solver_status = _reduced_mpcc_windowed_drift_row_value(window_row, "solver_status"),
            trajectory_ready =
                _reduced_mpcc_windowed_drift_row_value(window_row, "candidate_trajectory_ready"),
        )
    end
    if nrow(continuation.state_metrics_table) > 0
        _reduced_mpcc_windowed_drift_append_state_rows!(
            rows,
            continuation.state_metrics_table,
            thresholds;
            scope = "global",
            window_id = "global",
            window_index = missing,
            solver_status = get(continuation.metadata, "solver_status_counts", missing),
            trajectory_ready = get(continuation.metadata, "all_completed_windows_trajectory_ready", false),
        )
    end
    _reduced_mpcc_windowed_drift_rank_state_rows!(rows)
    return rows
end

function _reduced_mpcc_windowed_drift_append_state_rows!(
    rows::Vector{Dict{String, Any}},
    metrics::DataFrame,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds;
    scope,
    window_id,
    window_index,
    solver_status,
    trajectory_ready,
)
    for row in eachrow(metrics)
        max_abs = get(row, "max_abs_difference", missing)
        relative = get(row, "relative_rmse", missing)
        abs_pass = _reduced_mpcc_windowed_drift_pass(max_abs, thresholds.max_state_abs_difference)
        relative_pass = _reduced_mpcc_windowed_drift_pass(relative, thresholds.max_state_relative_rmse)
        push!(
            rows,
            Dict{String, Any}(
                "scope" => scope,
                "window_id" => window_id,
                "window_index" => window_index,
                "state_name" => get(row, "state_name", missing),
                "is_focus_state" =>
                    String(get(row, "state_name", "")) in REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_FOCUS_STATES,
                "initial_sequential" => get(row, "initial_sequential", missing),
                "initial_mpcc_candidate" => get(row, "initial_mpcc_candidate", missing),
                "final_sequential" => get(row, "final_sequential", missing),
                "final_mpcc_candidate" => get(row, "final_mpcc_candidate", missing),
                "final_difference_mpcc_minus_sequential" =>
                    get(row, "final_difference_mpcc_minus_sequential", missing),
                "abs_final_difference" =>
                    _reduced_mpcc_windowed_drift_abs(
                        get(row, "final_difference_mpcc_minus_sequential", missing),
                    ),
                "max_abs_difference" => max_abs,
                "max_abs_ratio" =>
                    _reduced_mpcc_windowed_drift_ratio(max_abs, thresholds.max_state_abs_difference),
                "rmse" => get(row, "rmse", missing),
                "relative_rmse" => relative,
                "relative_rmse_ratio" =>
                    _reduced_mpcc_windowed_drift_ratio(relative, thresholds.max_state_relative_rmse),
                "abs_drift_pass" => abs_pass,
                "relative_drift_pass" => relative_pass,
                "state_drift_pass" => abs_pass || relative_pass,
                "rank_abs_within_scope" => missing,
                "rank_relative_within_scope" => missing,
                "solver_status" => solver_status,
                "trajectory_ready" => trajectory_ready,
                "notes" => get(row, "notes", missing),
            ),
        )
    end
    return nothing
end

function _reduced_mpcc_windowed_drift_timepoint_rows(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    for (index, comparison) in enumerate(continuation.window_comparisons)
        _reduced_mpcc_windowed_drift_append_timepoint_rows!(
            rows,
            comparison.aligned_timeseries_table,
            thresholds;
            scope = "window",
            window_id = _reduced_mpcc_windowed_drift_window_id(index),
            window_index = index,
        )
    end
    if nrow(continuation.aligned_timeseries_table) > 0
        _reduced_mpcc_windowed_drift_append_timepoint_rows!(
            rows,
            continuation.aligned_timeseries_table,
            thresholds;
            scope = "global",
            window_id = "global",
            window_index = missing,
        )
    end
    _reduced_mpcc_windowed_drift_mark_timepoint_maxima!(rows)
    return rows
end

function _reduced_mpcc_windowed_drift_append_timepoint_rows!(
    rows::Vector{Dict{String, Any}},
    table::DataFrame,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds;
    scope,
    window_id,
    window_index,
)
    nrow(table) == 0 && return nothing
    metric_names = _reduced_mpcc_windowed_drift_metric_names(table)
    for row in eachrow(table), state_name in metric_names
        seq_col = "$(state_name)_sequential"
        cand_col = "$(state_name)_mpcc_candidate"
        diff_col = "$(state_name)_difference_mpcc_minus_sequential"
        sequential = get(row, seq_col, missing)
        candidate = get(row, cand_col, missing)
        difference = get(row, diff_col, missing)
        abs_difference = _reduced_mpcc_windowed_drift_abs(difference)
        denominator = max(
            _reduced_mpcc_windowed_drift_abs_or_zero(sequential),
            _reduced_mpcc_windowed_drift_abs_or_zero(candidate),
            eps(Float64),
        )
        push!(
            rows,
            Dict{String, Any}(
                "scope" => scope,
                "window_id" => window_id,
                "window_index" => window_index,
                "time" => get(row, "time", missing),
                "state_name" => state_name,
                "is_focus_state" =>
                    state_name in REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_FOCUS_STATES,
                "sequential_value" => sequential,
                "mpcc_candidate_value" => candidate,
                "difference_mpcc_minus_sequential" => difference,
                "abs_difference" => abs_difference,
                "abs_difference_ratio" =>
                    _reduced_mpcc_windowed_drift_ratio(
                        abs_difference,
                        thresholds.max_state_abs_difference,
                    ),
                "relative_difference" =>
                    _reduced_mpcc_windowed_drift_isfinite_number(abs_difference) ?
                    Float64(abs_difference) / denominator : missing,
                "is_window_max_abs_difference" => false,
                "is_global_max_abs_difference" => false,
            ),
        )
    end
    return nothing
end

function _reduced_mpcc_windowed_drift_metadata(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    attempt::Union{Nothing, ReducedDCDFBAMPCCWindowedSimulationAttemptResult},
    window_rows::Vector{Dict{String, Any}},
    state_rows::Vector{Dict{String, Any}},
    timepoint_rows::Vector{Dict{String, Any}},
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Dict{String, Any}
    first_abs = _reduced_mpcc_windowed_drift_first_row(
        window_rows,
        row -> _reduced_mpcc_windowed_drift_ratio_exceeds(get(row, "max_state_abs_ratio", missing)),
    )
    first_relative = _reduced_mpcc_windowed_drift_first_row(
        window_rows,
        row -> _reduced_mpcc_windowed_drift_ratio_exceeds(get(row, "max_state_relative_ratio", missing)),
    )
    first_any = _reduced_mpcc_windowed_drift_first_row(
        window_rows,
        row -> get(row, "state_drift_pass", true) !== true,
    )
    first_not_ready = _reduced_mpcc_windowed_drift_first_row(
        window_rows,
        row -> get(row, "trajectory_ready", true) !== true,
    )
    first_iter_limit = _reduced_mpcc_windowed_drift_first_row(
        window_rows,
        row -> String(get(row, "solver_status", "")) == "ITERATION_LIMIT",
    )
    global_rows = [row for row in state_rows if get(row, "scope", "") == "global"]
    dominant_global_abs = _reduced_mpcc_windowed_drift_max_dict_row(global_rows, "max_abs_difference")
    dominant_global_relative =
        _reduced_mpcc_windowed_drift_max_dict_row(global_rows, "relative_rmse")
    dominant_global_final =
        _reduced_mpcc_windowed_drift_max_abs_dict_row(global_rows, "final_difference_mpcc_minus_sequential")
    dominant_timepoint =
        _reduced_mpcc_windowed_drift_max_dict_row(timepoint_rows, "abs_difference")
    return Dict{String, Any}(
        "diagnostic_type" => REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_DIAGNOSTIC_TYPE,
        "target_horizon" =>
            attempt === nothing ? missing : get(attempt.metadata, "target_horizon", missing),
        "horizon_reached" => get(continuation.metadata, "total_horizon_reached", missing),
        "target_completed" =>
            attempt === nothing ? missing : get(attempt.metadata, "target_completed", missing),
        "attempt_traffic_light" =>
            attempt === nothing ? missing : get(attempt.metadata, "attempt_traffic_light", missing),
        "n_requested_windows" => get(continuation.metadata, "n_requested_windows", missing),
        "n_completed_windows" => get(continuation.metadata, "n_completed_windows", missing),
        "continuation_completed" => get(continuation.metadata, "continuation_completed", missing),
        "all_completed_windows_trajectory_ready" =>
            get(continuation.metadata, "all_completed_windows_trajectory_ready", missing),
        "threshold_max_state_abs_difference" => thresholds.max_state_abs_difference,
        "threshold_max_state_relative_rmse" => thresholds.max_state_relative_rmse,
        "threshold_max_global_state_abs_difference" => thresholds.max_global_state_abs_difference,
        "threshold_max_global_state_relative_rmse" => thresholds.max_global_state_relative_rmse,
        "n_window_drift_rows" => length(window_rows),
        "n_state_drift_rows" => length(state_rows),
        "n_timepoint_drift_rows" => length(timepoint_rows),
        "first_abs_drift_window_id" =>
            _reduced_mpcc_windowed_drift_dict_value(first_abs, "window_id"),
        "first_abs_drift_window_index" =>
            _reduced_mpcc_windowed_drift_dict_value(first_abs, "window_index"),
        "first_relative_drift_window_id" =>
            _reduced_mpcc_windowed_drift_dict_value(first_relative, "window_id"),
        "first_relative_drift_window_index" =>
            _reduced_mpcc_windowed_drift_dict_value(first_relative, "window_index"),
        "first_state_drift_window_id" =>
            _reduced_mpcc_windowed_drift_dict_value(first_any, "window_id"),
        "first_state_drift_window_index" =>
            _reduced_mpcc_windowed_drift_dict_value(first_any, "window_index"),
        "first_not_trajectory_ready_window_id" =>
            _reduced_mpcc_windowed_drift_dict_value(first_not_ready, "window_id"),
        "first_not_trajectory_ready_window_index" =>
            _reduced_mpcc_windowed_drift_dict_value(first_not_ready, "window_index"),
        "first_iteration_limit_window_id" =>
            _reduced_mpcc_windowed_drift_dict_value(first_iter_limit, "window_id"),
        "first_iteration_limit_window_index" =>
            _reduced_mpcc_windowed_drift_dict_value(first_iter_limit, "window_index"),
        "dominant_global_abs_state" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_global_abs, "state_name"),
        "dominant_global_abs_difference" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_global_abs, "max_abs_difference"),
        "dominant_global_abs_ratio" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_global_abs, "max_abs_ratio"),
        "dominant_global_relative_state" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_global_relative, "state_name"),
        "dominant_global_relative_rmse" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_global_relative, "relative_rmse"),
        "dominant_global_relative_ratio" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_global_relative, "relative_rmse_ratio"),
        "dominant_global_final_state" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_global_final, "state_name"),
        "dominant_global_final_difference" =>
            _reduced_mpcc_windowed_drift_dict_value(
                dominant_global_final,
                "final_difference_mpcc_minus_sequential",
            ),
        "dominant_timepoint_scope" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_timepoint, "scope"),
        "dominant_timepoint_window_id" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_timepoint, "window_id"),
        "dominant_timepoint_time" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_timepoint, "time"),
        "dominant_timepoint_state" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_timepoint, "state_name"),
        "dominant_timepoint_abs_difference" =>
            _reduced_mpcc_windowed_drift_dict_value(dominant_timepoint, "abs_difference"),
        "drift_pattern" => _reduced_mpcc_windowed_drift_pattern(first_any),
        "drift_coincides_with_iteration_limit" =>
            first_any !== nothing &&
            String(get(first_any, "solver_status", "")) == "ITERATION_LIMIT",
        "recommended_next_action" =>
            _reduced_mpcc_windowed_drift_recommended_action(first_any, first_not_ready),
        "outputs_written" => false,
        "drift_diagnostic_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC windowed drift diagnostics against reduced sequential DFBA; diagnostic only and not a validated scientific simulation.",
    )
end

function _reduced_mpcc_windowed_drift_metric_names(table::DataFrame)::Vector{String}
    suffix = "_difference_mpcc_minus_sequential"
    names_out = String[]
    for column in names(table)
        endswith(column, suffix) || continue
        push!(names_out, first(column, length(column) - length(suffix)))
    end
    return names_out
end

function _reduced_mpcc_windowed_drift_dominant_time(table::DataFrame, state_name)
    state_name === missing && return missing
    diff_col = "$(String(state_name))_difference_mpcc_minus_sequential"
    diff_col in names(table) || return missing
    candidates = [
        (index, abs(Float64(table[index, diff_col]))) for index in 1:nrow(table) if
        _reduced_mpcc_windowed_drift_isfinite_number(table[index, diff_col])
    ]
    isempty(candidates) && return missing
    order = sortperm([(-value, index) for (index, value) in candidates])
    index, _ = candidates[first(order)]
    return table[index, "time"]
end

function _reduced_mpcc_windowed_drift_mark_timepoint_maxima!(rows::Vector{Dict{String, Any}})
    groups = Dict{Tuple{String, Any}, Vector{Int}}()
    for (index, row) in enumerate(rows)
        scope = String(get(row, "scope", ""))
        key = (scope, get(row, "window_id", missing))
        push!(get!(groups, key, Int[]), index)
    end
    for (key, indices) in groups
        best = _reduced_mpcc_windowed_drift_best_index(rows, indices, "abs_difference")
        best === nothing && continue
        if key[1] == "window"
            rows[best]["is_window_max_abs_difference"] = true
        elseif key[1] == "global"
            rows[best]["is_global_max_abs_difference"] = true
        end
    end
    return nothing
end

function _reduced_mpcc_windowed_drift_rank_state_rows!(rows::Vector{Dict{String, Any}})
    groups = Dict{Tuple{String, Any}, Vector{Int}}()
    for (index, row) in enumerate(rows)
        key = (String(get(row, "scope", "")), get(row, "window_id", missing))
        push!(get!(groups, key, Int[]), index)
    end
    for indices in values(groups)
        abs_order = sortperm([
            _reduced_mpcc_windowed_drift_sort_tuple(rows[index], "max_abs_difference") for
            index in indices
        ])
        rel_order = sortperm([
            _reduced_mpcc_windowed_drift_sort_tuple(rows[index], "relative_rmse") for
            index in indices
        ])
        for (rank, order_index) in enumerate(abs_order)
            rows[indices[order_index]]["rank_abs_within_scope"] = rank
        end
        for (rank, order_index) in enumerate(rel_order)
            rows[indices[order_index]]["rank_relative_within_scope"] = rank
        end
    end
    return nothing
end

function _reduced_mpcc_windowed_drift_sort_tuple(row::Dict{String, Any}, key::String)
    value = get(row, key, missing)
    score =
        _reduced_mpcc_windowed_drift_isfinite_number(value) ? -abs(Float64(value)) : Inf
    return (score, String(get(row, "state_name", "")))
end

function _reduced_mpcc_windowed_drift_window_table_row(table::DataFrame, window_id::String)
    nrow(table) == 0 && return nothing
    "window_id" in names(table) || return nothing
    index = findfirst(==(window_id), String.(table[!, "window_id"]))
    return index === nothing ? nothing : table[index, :]
end

function _reduced_mpcc_windowed_drift_source_value(row, metadata, row_key, metadata_key)
    value = _reduced_mpcc_windowed_drift_row_value(row, row_key)
    value === missing || return value
    return get(metadata, String(metadata_key), missing)
end

function _reduced_mpcc_windowed_drift_bool_value(row, metadata, key)
    value = _reduced_mpcc_windowed_drift_row_value(row, key)
    value === missing || return value
    return get(metadata, String(key), missing)
end

function _reduced_mpcc_windowed_drift_state_value(
    table::DataFrame,
    state_name::AbstractString,
    column::AbstractString,
)
    nrow(table) == 0 && return missing
    index = findfirst(==(String(state_name)), String.(table[!, "state_name"]))
    index === nothing && return missing
    return table[index, String(column)]
end

function _reduced_mpcc_windowed_drift_max_row(table::DataFrame, column::AbstractString)
    nrow(table) == 0 && return nothing
    candidates = [
        (index, Float64(table[index, String(column)])) for index in 1:nrow(table) if
        _reduced_mpcc_windowed_drift_isfinite_number(table[index, String(column)])
    ]
    isempty(candidates) && return nothing
    order = sortperm([(-abs(value), String(table[index, "state_name"])) for (index, value) in candidates])
    index, _ = candidates[first(order)]
    return table[index, :]
end

function _reduced_mpcc_windowed_drift_max_abs_row(table::DataFrame, column::AbstractString)
    return _reduced_mpcc_windowed_drift_max_row(table, column)
end

function _reduced_mpcc_windowed_drift_max_dict_row(rows::Vector{Dict{String, Any}}, key::String)
    candidates = [
        row for row in rows if
        _reduced_mpcc_windowed_drift_isfinite_number(get(row, key, missing))
    ]
    isempty(candidates) && return nothing
    order = sortperm([
        (-abs(Float64(get(row, key, 0.0))), String(get(row, "state_name", ""))) for
        row in candidates
    ])
    return candidates[first(order)]
end

function _reduced_mpcc_windowed_drift_max_abs_dict_row(rows::Vector{Dict{String, Any}}, key::String)
    return _reduced_mpcc_windowed_drift_max_dict_row(rows, key)
end

function _reduced_mpcc_windowed_drift_best_index(
    rows::Vector{Dict{String, Any}},
    indices::Vector{Int},
    key::String,
)
    candidates = [
        (index, get(rows[index], key, missing)) for index in indices if
        _reduced_mpcc_windowed_drift_isfinite_number(get(rows[index], key, missing))
    ]
    isempty(candidates) && return nothing
    order = sortperm([(-abs(Float64(value)), index) for (index, value) in candidates])
    return candidates[first(order)][1]
end

function _reduced_mpcc_windowed_drift_window_id(index::Int)::String
    return "window_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_windowed_drift_first_row(rows::Vector{Dict{String, Any}}, predicate)
    index = findfirst(predicate, rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_windowed_drift_pattern(first_drift)::String
    first_drift === nothing && return "within_state_drift_thresholds"
    index = get(first_drift, "window_index", missing)
    _reduced_mpcc_windowed_drift_isfinite_number(index) || return "state_drift_detected"
    Int(index) <= 1 && return "early_or_initial_window_drift"
    return "accumulated_windowed_drift"
end

function _reduced_mpcc_windowed_drift_recommended_action(first_drift, first_not_ready)::String
    if first_drift === nothing && first_not_ready === nothing
        return "review_windowed_candidate_before_scientific_use"
    elseif first_drift === nothing
        return "inspect_solver_termination_before_trajectory_use"
    elseif first_not_ready !== nothing &&
           get(first_not_ready, "window_index", missing) == get(first_drift, "window_index", missing)
        return "inspect_solver_termination_and_state_propagation_at_first_drift_window"
    else
        return "inspect_state_propagation_and_window_size_at_first_drift_window"
    end
end

function _reduced_mpcc_windowed_drift_row_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_drift_dict_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_drift_abs(value)
    _reduced_mpcc_windowed_drift_isfinite_number(value) || return missing
    return abs(Float64(value))
end

function _reduced_mpcc_windowed_drift_abs_or_zero(value)::Float64
    _reduced_mpcc_windowed_drift_isfinite_number(value) || return 0.0
    return abs(Float64(value))
end

function _reduced_mpcc_windowed_drift_ratio(value, threshold)
    _reduced_mpcc_windowed_drift_isfinite_number(value) || return missing
    _reduced_mpcc_windowed_drift_isfinite_number(threshold) || return missing
    Float64(threshold) > 0.0 || return missing
    return abs(Float64(value)) / Float64(threshold)
end

function _reduced_mpcc_windowed_drift_ratio_exceeds(value)::Bool
    _reduced_mpcc_windowed_drift_isfinite_number(value) || return false
    return Float64(value) > 1.0
end

function _reduced_mpcc_windowed_drift_pass(value, threshold)::Bool
    _reduced_mpcc_windowed_drift_isfinite_number(value) || return false
    return abs(Float64(value)) <= Float64(threshold)
end

function _reduced_mpcc_windowed_drift_metrics_scale_pass(
    metrics::DataFrame,
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Bool
    nrow(metrics) > 0 || return false
    for row in eachrow(metrics)
        abs_pass = _reduced_mpcc_windowed_drift_pass(
            get(row, "max_abs_difference", missing),
            thresholds.max_state_abs_difference,
        )
        relative_pass = _reduced_mpcc_windowed_drift_pass(
            get(row, "relative_rmse", missing),
            thresholds.max_state_relative_rmse,
        )
        (abs_pass || relative_pass) || return false
    end
    return true
end

function _reduced_mpcc_windowed_drift_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_windowed_drift_window_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_windowed_drift_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_WINDOW_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_drift_state_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_windowed_drift_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_STATE_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_drift_timepoint_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_windowed_drift_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_WINDOWED_DRIFT_TIMEPOINT_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_drift_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
