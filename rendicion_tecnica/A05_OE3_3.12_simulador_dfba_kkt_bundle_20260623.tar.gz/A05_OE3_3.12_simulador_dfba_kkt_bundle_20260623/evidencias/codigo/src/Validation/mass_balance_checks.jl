"""
    check_mass_balance(model, v; atol=1e-8)

Return the infinity norm of the steady-state residual `S * v`.
"""
function check_mass_balance(model::MetabolicModel, v::AbstractVector; atol::Real = 1e-8)
    length(v) == size(model.S, 2) || error("Flux vector length $(length(v)) does not match $(size(model.S, 2)) reactions.")
    return norm(model.S * Float64.(v), Inf)
end

"""
    is_mass_balanced(model, v; atol=1e-8)

Return true when the infinity norm of `S * v` is within `atol`.
"""
function is_mass_balanced(model::MetabolicModel, v::AbstractVector; atol::Real = 1e-8)
    return check_mass_balance(model, v; atol = atol) <= atol
end

"""
    check_bound_violations(model, v; atol=1e-8)

Return lower- and upper-bound violation diagnostics for a flux vector.
"""
function check_bound_violations(model::MetabolicModel, v::AbstractVector; atol::Real = 1e-8)
    n_rxns = length(model.rxn_ids)
    length(v) == n_rxns || error("Flux vector length $(length(v)) does not match $n_rxns reactions.")

    fluxes = Float64.(v)
    lower_violations = max.(model.lb .- fluxes, 0.0)
    upper_violations = max.(fluxes .- model.ub, 0.0)
    tolerance = Float64(atol)

    return (
        max_lower_violation = isempty(lower_violations) ? 0.0 : maximum(lower_violations),
        max_upper_violation = isempty(upper_violations) ? 0.0 : maximum(upper_violations),
        n_lower_violations = count(violation -> violation > tolerance, lower_violations),
        n_upper_violations = count(violation -> violation > tolerance, upper_violations),
    )
end
