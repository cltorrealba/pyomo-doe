const DEFAULT_STATIC_FBA_COMPARISON_REACTIONS = [
    "r_2111",
    "r_1714",
    "r_1709",
    "r_1761",
    "r_1992",
    "r_4046",
    "r_4047",
    "r_4048",
]

const STATIC_FBA_COMPARISON_SUMMARY_COLUMNS = [
    "model_scope",
    "model_id",
    "n_metabolites",
    "n_reactions",
    "objective_rxn_id",
    "solver_status",
    "objective_value",
    "mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "oxygen_policy",
    "carbohydrate_policy",
]

const STATIC_FBA_SELECTED_FLUX_COLUMNS = [
    "reaction_id",
    "role",
    "present_reduced",
    "present_full",
    "reduced_flux",
    "full_flux",
    "absolute_difference",
    "relative_difference",
    "reduced_lb",
    "reduced_ub",
    "full_lb",
    "full_ub",
    "notes",
]

const STATIC_FBA_REACTION_ROLES = Dict(
    "r_2111" => "biomass",
    "r_1714" => "glucose",
    "r_1709" => "fructose",
    "r_1761" => "ethanol",
    "r_1992" => "oxygen",
    "r_4046" => "ATP maintenance",
    "r_4047" => "protein",
    "r_4048" => "carbohydrate",
)

const STATIC_FBA_REDUCED_OXYGEN_POLICY = "absent_r_1992_forced_zero_in_dynamic_rhs"
const STATIC_FBA_FULL_OXYGEN_POLICY = "present_r_1992_closed_by_bounds"
const STATIC_FBA_CARBOHYDRATE_POLICY = "static_flux_reported_dynamic_rhs_empirical_not_r_4048"
const STATIC_FBA_INTERPRETATION_NOTE =
    "Full and reduced static FBA fluxes are diagnostic baselines. " *
    "Non-objective flux differences can reflect network differences and LP degeneracy. " *
    "This static FBA comparison is not a biological equivalence proof."

"""
    StaticFBAComparisonResult

Container for full-vs-reduced static FBA comparison reports.
"""
struct StaticFBAComparisonResult
    reduced_result::FBAResult
    full_result::FBAResult
    selected_reaction_ids::Vector{String}
    selected_flux_table::DataFrame
    summary_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    compare_static_fba_full_reduced(reduced_model, reduced_reaction_map, full_model, full_reaction_map; kwargs...)

Solve static FBA on the reduced and full models, then build summary and
selected-flux comparison tables keyed by reaction ID.
"""
function compare_static_fba_full_reduced(
    reduced_model::MetabolicModel,
    reduced_reaction_map::ReactionMap,
    full_model::MetabolicModel,
    full_reaction_map::ReactionMap;
    objective_rxn_id::AbstractString = "r_2111",
    selected_reaction_ids::Vector{String} = DEFAULT_STATIC_FBA_COMPARISON_REACTIONS,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1.0e-8,
)::StaticFBAComparisonResult
    objective_id = strip(String(objective_rxn_id))
    isempty(objective_id) && error("Static FBA comparison objective_rxn_id must not be empty.")
    selected_ids = String.(strip.(selected_reaction_ids))
    isempty(selected_ids) && error("Static FBA comparison requires at least one selected reaction ID.")
    any(isempty, selected_ids) && error("Static FBA comparison selected reaction IDs must not be empty.")

    _validate_static_fba_reaction_map(reduced_model, reduced_reaction_map, "reduced")
    _validate_static_fba_reaction_map(full_model, full_reaction_map, "full")
    _assert_static_fba_oxygen_not_r0001(reduced_reaction_map, "reduced")
    _assert_static_fba_oxygen_not_r0001(full_reaction_map, "full")

    reduced_lb = copy(reduced_model.lb)
    reduced_ub = copy(reduced_model.ub)
    full_lb = copy(full_model.lb)
    full_ub = copy(full_model.ub)

    reduced_result = solve_fba(
        reduced_model;
        objective_rxn_id = objective_id,
        sense = :max,
        optimizer = optimizer,
        silent = silent,
        atol = atol,
    )
    full_result = solve_fba(
        full_model;
        objective_rxn_id = objective_id,
        sense = :max,
        optimizer = optimizer,
        silent = silent,
        atol = atol,
    )

    _assert_static_fba_bounds_unchanged(reduced_model, reduced_lb, reduced_ub, "reduced")
    _assert_static_fba_bounds_unchanged(full_model, full_lb, full_ub, "full")

    selected_flux_table = _static_fba_selected_flux_table(
        reduced_model,
        reduced_result,
        reduced_reaction_map,
        full_model,
        full_result,
        full_reaction_map,
        selected_ids,
    )
    summary_table = _static_fba_summary_table(
        reduced_model,
        reduced_result,
        full_model,
        full_result,
        objective_id,
    )
    metadata = _static_fba_comparison_metadata(
        reduced_model,
        reduced_result,
        full_model,
        full_result,
        objective_id,
        selected_ids,
    )

    return StaticFBAComparisonResult(
        reduced_result,
        full_result,
        selected_ids,
        selected_flux_table,
        summary_table,
        metadata,
    )
end

"""
    export_static_fba_comparison(comparison, output_dir; overwrite=false)

Write CSV/TOML static FBA comparison report files and return their paths.
"""
function export_static_fba_comparison(
    comparison::StaticFBAComparisonResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Static FBA comparison output_dir exists and is not a directory: $output_path")
    end

    paths = Dict{String, String}(
        "summary" => joinpath(output_path, "static_fba_comparison_summary.csv"),
        "selected_fluxes" => joinpath(output_path, "static_fba_selected_fluxes.csv"),
        "metadata" => joinpath(output_path, "static_fba_comparison_metadata.toml"),
    )
    existing_targets = [path for path in values(paths) if isfile(path)]
    if !overwrite && !isempty(existing_targets)
        error(
            "Static FBA comparison export target file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end

    mkpath(output_path)
    if overwrite
        for path in values(paths)
            isfile(path) && rm(path)
        end
    end

    CSV.write(paths["summary"], comparison.summary_table)
    CSV.write(paths["selected_fluxes"], comparison.selected_flux_table)
    open(paths["metadata"], "w") do io
        TOML.print(io, _static_fba_toml_normalize(comparison.metadata))
    end
    return paths
end

function _validate_static_fba_reaction_map(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    model_scope::AbstractString,
)
    report = validate_reaction_map(model, reaction_map)
    report.ok || error(
        "Static FBA comparison $(String(model_scope)) reaction map validation failed. " *
        "Missing reactions: $(report.missing_required_reactions)",
    )
    return report
end

function _assert_static_fba_oxygen_not_r0001(reaction_map::ReactionMap, model_scope::AbstractString)
    oxygen_id = get(reaction_map.core, "oxygen_exchange", "")
    disabled_oxygen_id = get(reaction_map.disabled_reactions, "oxygen_exchange", "")
    if strip(oxygen_id) == "r_0001" || strip(disabled_oxygen_id) == "r_0001"
        error("Static FBA comparison $(String(model_scope)) oxygen_exchange must not map to r_0001.")
    end
    return nothing
end

function _assert_static_fba_bounds_unchanged(
    model::MetabolicModel,
    original_lb::Vector{Float64},
    original_ub::Vector{Float64},
    model_scope::AbstractString,
)
    model.lb == original_lb || error("Static FBA comparison mutated $(String(model_scope)) lower bounds.")
    model.ub == original_ub || error("Static FBA comparison mutated $(String(model_scope)) upper bounds.")
    return nothing
end

function _static_fba_summary_table(
    reduced_model::MetabolicModel,
    reduced_result::FBAResult,
    full_model::MetabolicModel,
    full_result::FBAResult,
    objective_rxn_id::AbstractString,
)::DataFrame
    rows = [
        _static_fba_summary_row(
            "reduced",
            reduced_model,
            reduced_result,
            objective_rxn_id,
            STATIC_FBA_REDUCED_OXYGEN_POLICY,
        ),
        _static_fba_summary_row(
            "full",
            full_model,
            full_result,
            objective_rxn_id,
            STATIC_FBA_FULL_OXYGEN_POLICY,
        ),
    ]
    return DataFrame(
        (
            column => [_static_fba_table_scalar(get(row, column, missing)) for row in rows] for
            column in STATIC_FBA_COMPARISON_SUMMARY_COLUMNS
        )...,
    )
end

function _static_fba_summary_row(
    model_scope::AbstractString,
    model::MetabolicModel,
    result::FBAResult,
    objective_rxn_id::AbstractString,
    oxygen_policy::AbstractString,
)::Dict{String, Any}
    return Dict{String, Any}(
        "model_scope" => String(model_scope),
        "model_id" => model.model_id,
        "n_metabolites" => length(model.met_ids),
        "n_reactions" => length(model.rxn_ids),
        "objective_rxn_id" => String(objective_rxn_id),
        "solver_status" => string(result.status),
        "objective_value" => result.objective_value,
        "mass_balance_residual" => result.mass_balance_residual,
        "max_lower_bound_violation" => result.max_lower_bound_violation,
        "max_upper_bound_violation" => result.max_upper_bound_violation,
        "oxygen_policy" => String(oxygen_policy),
        "carbohydrate_policy" => STATIC_FBA_CARBOHYDRATE_POLICY,
    )
end

function _static_fba_selected_flux_table(
    reduced_model::MetabolicModel,
    reduced_result::FBAResult,
    reduced_reaction_map::ReactionMap,
    full_model::MetabolicModel,
    full_result::FBAResult,
    full_reaction_map::ReactionMap,
    selected_reaction_ids::Vector{String},
)::DataFrame
    rows = [
        _static_fba_selected_flux_row(
            rxn_id,
            reduced_model,
            reduced_result,
            reduced_reaction_map,
            full_model,
            full_result,
            full_reaction_map,
        ) for rxn_id in selected_reaction_ids
    ]
    return DataFrame(
        (
            column => [_static_fba_table_scalar(get(row, column, missing)) for row in rows] for
            column in STATIC_FBA_SELECTED_FLUX_COLUMNS
        )...,
    )
end

function _static_fba_selected_flux_row(
    rxn_id::AbstractString,
    reduced_model::MetabolicModel,
    reduced_result::FBAResult,
    reduced_reaction_map::ReactionMap,
    full_model::MetabolicModel,
    full_result::FBAResult,
    full_reaction_map::ReactionMap,
)::Dict{String, Any}
    reaction_id = String(rxn_id)
    reduced_present = has_reaction(reduced_model, reaction_id)
    full_present = has_reaction(full_model, reaction_id)
    reduced_flux = _static_fba_flux_or_missing(reduced_model, reduced_result, reaction_id)
    full_flux = _static_fba_flux_or_missing(full_model, full_result, reaction_id)
    absolute_difference = _static_fba_absolute_difference(reduced_flux, full_flux)
    relative_difference = _static_fba_relative_difference(reduced_flux, full_flux)

    return Dict{String, Any}(
        "reaction_id" => reaction_id,
        "role" => get(STATIC_FBA_REACTION_ROLES, reaction_id, "selected"),
        "present_reduced" => reduced_present,
        "present_full" => full_present,
        "reduced_flux" => reduced_flux,
        "full_flux" => full_flux,
        "absolute_difference" => absolute_difference,
        "relative_difference" => relative_difference,
        "reduced_lb" => _static_fba_bound_or_missing(reduced_model, reaction_id, :lb),
        "reduced_ub" => _static_fba_bound_or_missing(reduced_model, reaction_id, :ub),
        "full_lb" => _static_fba_bound_or_missing(full_model, reaction_id, :lb),
        "full_ub" => _static_fba_bound_or_missing(full_model, reaction_id, :ub),
        "notes" => _static_fba_selected_flux_notes(
            reaction_id,
            reduced_model,
            reduced_reaction_map,
            full_model,
            full_reaction_map,
        ),
    )
end

function _static_fba_flux_or_missing(
    model::MetabolicModel,
    result::FBAResult,
    rxn_id::AbstractString,
)
    has_reaction(model, rxn_id) || return missing
    isempty(result.fluxes) && return missing
    return result.fluxes[reaction_index(model, rxn_id)]
end

function _static_fba_bound_or_missing(model::MetabolicModel, rxn_id::AbstractString, bound::Symbol)
    has_reaction(model, rxn_id) || return missing
    index = reaction_index(model, rxn_id)
    if bound == :lb
        return model.lb[index]
    elseif bound == :ub
        return model.ub[index]
    else
        error("Unsupported static FBA bound selector: $bound")
    end
end

function _static_fba_absolute_difference(reduced_flux, full_flux)
    (ismissing(reduced_flux) || ismissing(full_flux)) && return missing
    return abs(Float64(full_flux) - Float64(reduced_flux))
end

function _static_fba_relative_difference(reduced_flux, full_flux)
    (ismissing(reduced_flux) || ismissing(full_flux)) && return missing
    reduced_value = Float64(reduced_flux)
    full_value = Float64(full_flux)
    denominator = max(abs(full_value), abs(reduced_value), eps(Float64))
    return abs(full_value - reduced_value) / denominator
end

function _static_fba_selected_flux_notes(
    rxn_id::AbstractString,
    reduced_model::MetabolicModel,
    reduced_reaction_map::ReactionMap,
    full_model::MetabolicModel,
    full_reaction_map::ReactionMap,
)::String
    reaction_id = String(rxn_id)
    if reaction_id == "r_1992"
        reduced_note = _static_fba_oxygen_scope_note(reduced_model, reduced_reaction_map, "reduced")
        full_note = _static_fba_oxygen_scope_note(full_model, full_reaction_map, "full")
        return "$reduced_note; $full_note; r_0001 is not used as oxygen"
    elseif reaction_id == "r_4048"
        return "static r_4048 flux is reported; dynamic dy[8] remains empirical and not r_4048 flux-driven"
    elseif !has_reaction(reduced_model, reaction_id) || !has_reaction(full_model, reaction_id)
        return "reaction is missing in at least one model"
    else
        return "compared by reaction ID"
    end
end

function _static_fba_oxygen_scope_note(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    model_scope::AbstractString,
)::String
    disabled = get(reaction_map.disabled_reactions, "oxygen_exchange", "") == "r_1992"
    if !has_reaction(model, "r_1992")
        return "$(String(model_scope)) r_1992 absent" * (disabled ? "/disabled" : "")
    end

    index = reaction_index(model, "r_1992")
    closed = iszero(model.lb[index]) && iszero(model.ub[index])
    closed_note = closed ? "closed" : "not_closed"
    return "$(String(model_scope)) r_1992 present/$closed_note"
end

function _static_fba_comparison_metadata(
    reduced_model::MetabolicModel,
    reduced_result::FBAResult,
    full_model::MetabolicModel,
    full_result::FBAResult,
    objective_rxn_id::AbstractString,
    selected_reaction_ids::Vector{String},
)::Dict{String, Any}
    return Dict{String, Any}(
        "comparison_type" => "static_fba_full_vs_reduced",
        "objective_rxn_id" => String(objective_rxn_id),
        "selected_reaction_ids" => copy(selected_reaction_ids),
        "solver_label" => _static_fba_solver_label(reduced_result, full_result),
        "reduced_model_id" => reduced_model.model_id,
        "full_model_id" => full_model.model_id,
        "reduced_n_metabolites" => length(reduced_model.met_ids),
        "reduced_n_reactions" => length(reduced_model.rxn_ids),
        "full_n_metabolites" => length(full_model.met_ids),
        "full_n_reactions" => length(full_model.rxn_ids),
        "oxygen_mapping_note" =>
            "Reduced r_1992 is absent/disabled; full r_1992 is present and closed by bounds; r_0001 is not used as oxygen.",
        "carbohydrate_mapping_note" =>
            "r_4048 static flux is reported; dynamic carbohydrate RHS dy[8] remains empirical and not r_4048 flux-driven.",
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" => STATIC_FBA_INTERPRETATION_NOTE,
    )
end

function _static_fba_solver_label(reduced_result::FBAResult, full_result::FBAResult)::String
    reduced_solver = string(get(reduced_result.metadata, "solver_name", "unknown"))
    full_solver = string(get(full_result.metadata, "solver_name", "unknown"))
    reduced_solver == full_solver && return reduced_solver
    return "$reduced_solver,$full_solver"
end

function _static_fba_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end

function _static_fba_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _static_fba_toml_normalize_real(value)
    elseif value isa Tuple
        return _static_fba_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _static_fba_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _static_fba_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _static_fba_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _static_fba_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _static_fba_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end
