import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_TOLERANCE_SENSITIVITY_TYPE =
    "reduced_dcdfba_mpcc_windowed_tolerance_sensitivity"

const REDUCED_DCDFBA_MPCC_WINDOWED_TOLERANCE_SENSITIVITY_COLUMNS = [
    "tolerance_case_id",
    "case_status",
    "max_mass_balance_residual_threshold",
    "relaxed_vs_strictest",
    "target_horizon",
    "window_hours",
    "nfe_per_window",
    "degree",
    "ipopt_max_iter",
    "horizon_reached",
    "horizon_gap",
    "target_completion_fraction",
    "horizon_gain_vs_strictest",
    "horizon_gain_vs_previous",
    "target_completed",
    "attempt_traffic_light",
    "attempt_viable",
    "global_traffic_light",
    "global_viability_class",
    "n_requested_windows",
    "n_completed_windows",
    "n_failed_windows",
    "window_green_count",
    "window_yellow_count",
    "window_red_count",
    "first_non_green_window_id",
    "first_non_green_window_index",
    "first_non_green_window_class",
    "first_red_window_id",
    "first_red_window_index",
    "first_red_window_class",
    "first_not_residual_feasible_window_id",
    "first_not_residual_feasible_window_index",
    "first_not_residual_feasible_window_class",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_mass_balance_ratio",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "global_max_state_relative_rmse",
    "total_solve_elapsed_seconds",
    "recommended_next_action",
    "blocking_reasons",
    "review_reasons",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCWindowedToleranceSensitivityResult

Diagnostic sweep over reduced MPCC windowed-attempt residual thresholds. The
current sweep varies only `max_mass_balance_residual` and keeps the same model,
grid, initial state, Ipopt/MUMPS path, and scientific guardrails. It writes no
outputs and does not validate a scientific simulation.
"""
struct ReducedDCDFBAMPCCWindowedToleranceSensitivityResult
    sensitivity_table::DataFrame
    attempt_results::Vector{ReducedDCDFBAMPCCWindowedSimulationAttemptResult}
    metadata::Dict{String, Any}
end

"""
    sweep_reduced_dcdfba_mpcc_windowed_tolerances(attempts; max_mass_balance_residual_values)

Aggregate already-computed windowed-attempt results as a mass-balance threshold
sensitivity table. This method is useful for deterministic tests and cached
diagnostics.
"""
function sweep_reduced_dcdfba_mpcc_windowed_tolerances(
    attempts::AbstractVector{<:ReducedDCDFBAMPCCWindowedSimulationAttemptResult};
    max_mass_balance_residual_values,
)::ReducedDCDFBAMPCCWindowedToleranceSensitivityResult
    collected_attempts = collect(attempts)
    isempty(collected_attempts) && throw(
        ArgumentError("Reduced MPCC windowed tolerance sensitivity requires at least one attempt."),
    )
    thresholds = _reduced_mpcc_windowed_tol_validate_values(max_mass_balance_residual_values)
    length(collected_attempts) == length(thresholds) || throw(
        ArgumentError(
            "Reduced MPCC windowed tolerance sensitivity requires one threshold value per attempt.",
        ),
    )

    rows = Dict{String, Any}[]
    previous_horizon = missing
    strictest_horizon = missing
    for (case_index, (attempt, threshold)) in enumerate(zip(collected_attempts, thresholds))
        row = _reduced_mpcc_windowed_tol_row_from_attempt(
            attempt,
            case_index,
            threshold,
            strictest_horizon,
            previous_horizon,
        )
        push!(rows, row)
        case_index == 1 && (strictest_horizon = row["horizon_reached"])
        previous_horizon = row["horizon_reached"]
    end

    table = _reduced_mpcc_windowed_tol_table(rows)
    metadata = _reduced_mpcc_windowed_tol_metadata(rows, thresholds)
    return ReducedDCDFBAMPCCWindowedToleranceSensitivityResult(
        table,
        collected_attempts,
        metadata,
    )
end

"""
    sweep_reduced_dcdfba_mpcc_windowed_tolerances(model, reaction_map; kwargs...)

Run reduced MPCC windowed attempts for alternate `max_mass_balance_residual`
diagnostic thresholds. The threshold affects residual-feasibility
classification and window-continuation gating only; it does not change the
KKT/MPCC equations or add solver dependencies.
"""
function sweep_reduced_dcdfba_mpcc_windowed_tolerances(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    max_mass_balance_residual_values = [1.0e-6, 2.0e-6, 5.0e-6, 1.0e-5],
    target_horizon::Real = 72.0,
    t0::Real = 0.0,
    window_hours::Real = 0.5,
    nfe_per_window::Int = 2,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        ),
    silent::Bool = true,
    continue_on_error::Bool = true,
    case_callback = nothing,
)::ReducedDCDFBAMPCCWindowedToleranceSensitivityResult
    thresholds = _reduced_mpcc_windowed_tol_validate_values(max_mass_balance_residual_values)
    rows = Dict{String, Any}[]
    attempts = ReducedDCDFBAMPCCWindowedSimulationAttemptResult[]
    previous_horizon = missing
    strictest_horizon = missing

    for (case_index, threshold) in enumerate(thresholds)
        case_residual_thresholds =
            _reduced_mpcc_windowed_tol_residual_thresholds(residual_thresholds, threshold)
        case_viability_thresholds =
            _reduced_mpcc_windowed_tol_viability_thresholds(
                viability_thresholds,
                case_residual_thresholds,
            )
        row = try
            attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
                model,
                reaction_map;
                target_horizon = target_horizon,
                t0 = t0,
                window_hours = window_hours,
                nfe_per_window = nfe_per_window,
                degree = degree,
                y0 = y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = ipopt_max_iter,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = case_residual_thresholds,
                viability_thresholds = case_viability_thresholds,
                silent = silent,
                continue_on_error = continue_on_error,
            )
            push!(attempts, attempt)
            _reduced_mpcc_windowed_tol_row_from_attempt(
                attempt,
                case_index,
                threshold,
                strictest_horizon,
                previous_horizon,
            )
        catch err
            continue_on_error || rethrow()
            _reduced_mpcc_windowed_tol_error_row(
                case_index,
                threshold,
                target_horizon,
                window_hours,
                nfe_per_window,
                degree,
                ipopt_max_iter,
                strictest_horizon,
                previous_horizon,
                err,
            )
        end
        push!(rows, row)
        case_index == 1 && (strictest_horizon = row["horizon_reached"])
        previous_horizon = row["horizon_reached"]
        case_callback === nothing || case_callback(row, case_index, length(thresholds))
    end

    table = _reduced_mpcc_windowed_tol_table(rows)
    metadata = _reduced_mpcc_windowed_tol_metadata(rows, thresholds)
    return ReducedDCDFBAMPCCWindowedToleranceSensitivityResult(table, attempts, metadata)
end

function _reduced_mpcc_windowed_tol_residual_thresholds(
    base::ReducedDCDFBAMPCCResidualThresholds,
    max_mass_balance_residual::Float64,
)::ReducedDCDFBAMPCCResidualThresholds
    return default_reduced_dcdfba_mpcc_residual_thresholds(
        max_rhs_residual = base.max_rhs_residual,
        max_mass_balance_residual = max_mass_balance_residual,
        max_lower_bound_violation = base.max_lower_bound_violation,
        max_upper_bound_violation = base.max_upper_bound_violation,
        max_stationarity_residual = base.max_stationarity_residual,
        max_lower_complementarity_residual = base.max_lower_complementarity_residual,
        max_upper_complementarity_residual = base.max_upper_complementarity_residual,
    )
end

function _reduced_mpcc_windowed_tol_viability_thresholds(
    base::ReducedDCDFBAMPCCSimulationViabilityThresholds,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds,
)::ReducedDCDFBAMPCCSimulationViabilityThresholds
    return default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
        residual_thresholds = residual_thresholds,
        max_state_abs_difference = base.max_state_abs_difference,
        max_state_relative_rmse = base.max_state_relative_rmse,
        max_global_state_abs_difference = base.max_global_state_abs_difference,
        max_global_state_relative_rmse = base.max_global_state_relative_rmse,
    )
end

function _reduced_mpcc_windowed_tol_row_from_attempt(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    case_index::Int,
    threshold::Float64,
    strictest_horizon,
    previous_horizon,
)::Dict{String, Any}
    metadata = attempt.metadata
    global_row = _reduced_mpcc_windowed_tol_global_row(attempt.attempt_table)
    horizon = get(metadata, "horizon_reached", missing)
    mass = _reduced_mpcc_windowed_tol_row_value(global_row, "max_mass_balance_residual")
    return Dict{String, Any}(
        "tolerance_case_id" => _reduced_mpcc_windowed_tol_case_id(case_index),
        "case_status" => "completed",
        "max_mass_balance_residual_threshold" => threshold,
        "relaxed_vs_strictest" => case_index > 1,
        "target_horizon" => get(metadata, "target_horizon", missing),
        "window_hours" => get(metadata, "window_hours", missing),
        "nfe_per_window" => get(metadata, "nfe_per_window", missing),
        "degree" => get(metadata, "degree", missing),
        "ipopt_max_iter" => _reduced_mpcc_windowed_tol_row_value(global_row, "ipopt_max_iter"),
        "horizon_reached" => horizon,
        "horizon_gap" => get(metadata, "horizon_gap", missing),
        "target_completion_fraction" => get(metadata, "target_completion_fraction", missing),
        "horizon_gain_vs_strictest" =>
            _reduced_mpcc_windowed_tol_difference(horizon, strictest_horizon),
        "horizon_gain_vs_previous" =>
            _reduced_mpcc_windowed_tol_difference(horizon, previous_horizon),
        "target_completed" => get(metadata, "target_completed", false),
        "attempt_traffic_light" => get(metadata, "attempt_traffic_light", missing),
        "attempt_viable" => get(metadata, "attempt_viable", false),
        "global_traffic_light" => get(metadata, "global_traffic_light", missing),
        "global_viability_class" => get(metadata, "global_viability_class", missing),
        "n_requested_windows" => get(metadata, "n_requested_windows", missing),
        "n_completed_windows" => get(metadata, "n_completed_windows", missing),
        "n_failed_windows" => get(metadata, "n_failed_windows", missing),
        "window_green_count" => get(metadata, "window_green_count", missing),
        "window_yellow_count" => get(metadata, "window_yellow_count", missing),
        "window_red_count" => get(metadata, "window_red_count", missing),
        "first_non_green_window_id" => get(metadata, "first_non_green_window_id", missing),
        "first_non_green_window_index" =>
            get(metadata, "first_non_green_window_index", missing),
        "first_non_green_window_class" =>
            get(metadata, "first_non_green_window_class", missing),
        "first_red_window_id" => get(metadata, "first_red_window_id", missing),
        "first_red_window_index" => get(metadata, "first_red_window_index", missing),
        "first_red_window_class" => get(metadata, "first_red_window_class", missing),
        "first_not_residual_feasible_window_id" =>
            get(metadata, "first_not_residual_feasible_window_id", missing),
        "first_not_residual_feasible_window_index" =>
            get(metadata, "first_not_residual_feasible_window_index", missing),
        "first_not_residual_feasible_window_class" =>
            get(metadata, "first_not_residual_feasible_window_class", missing),
        "max_rhs_residual" => _reduced_mpcc_windowed_tol_row_value(global_row, "max_rhs_residual"),
        "max_mass_balance_residual" => mass,
        "max_mass_balance_ratio" => _reduced_mpcc_windowed_tol_ratio(mass, threshold),
        "max_lower_bound_violation" =>
            _reduced_mpcc_windowed_tol_row_value(global_row, "max_lower_bound_violation"),
        "max_upper_bound_violation" =>
            _reduced_mpcc_windowed_tol_row_value(global_row, "max_upper_bound_violation"),
        "max_stationarity_residual" =>
            _reduced_mpcc_windowed_tol_row_value(global_row, "max_stationarity_residual"),
        "max_lower_complementarity_residual" =>
            _reduced_mpcc_windowed_tol_row_value(global_row, "max_lower_complementarity_residual"),
        "max_upper_complementarity_residual" =>
            _reduced_mpcc_windowed_tol_row_value(global_row, "max_upper_complementarity_residual"),
        "global_max_state_relative_rmse" =>
            get(metadata, "global_max_state_relative_rmse", missing),
        "total_solve_elapsed_seconds" => get(metadata, "total_solve_elapsed_seconds", missing),
        "recommended_next_action" => get(metadata, "recommended_next_action", missing),
        "blocking_reasons" => _reduced_mpcc_windowed_tol_row_value(global_row, "blocking_reasons"),
        "review_reasons" => _reduced_mpcc_windowed_tol_row_value(global_row, "review_reasons"),
        "error_type" => missing,
        "error_message" => missing,
    )
end

function _reduced_mpcc_windowed_tol_error_row(
    case_index::Int,
    threshold::Float64,
    target_horizon::Real,
    window_hours::Real,
    nfe_per_window::Int,
    degree::Int,
    ipopt_max_iter,
    strictest_horizon,
    previous_horizon,
    err,
)::Dict{String, Any}
    row = Dict{String, Any}(
        column => missing for
        column in REDUCED_DCDFBA_MPCC_WINDOWED_TOLERANCE_SENSITIVITY_COLUMNS
    )
    row["tolerance_case_id"] = _reduced_mpcc_windowed_tol_case_id(case_index)
    row["case_status"] = "failed"
    row["max_mass_balance_residual_threshold"] = threshold
    row["relaxed_vs_strictest"] = case_index > 1
    row["target_horizon"] = Float64(target_horizon)
    row["window_hours"] = Float64(window_hours)
    row["nfe_per_window"] = nfe_per_window
    row["degree"] = degree
    row["ipopt_max_iter"] = ipopt_max_iter
    row["horizon_gain_vs_strictest"] =
        _reduced_mpcc_windowed_tol_difference(missing, strictest_horizon)
    row["horizon_gain_vs_previous"] =
        _reduced_mpcc_windowed_tol_difference(missing, previous_horizon)
    row["target_completed"] = false
    row["attempt_traffic_light"] = "red"
    row["attempt_viable"] = false
    row["recommended_next_action"] = "inspect_failed_tolerance_case"
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_windowed_tol_metadata(
    rows::Vector{Dict{String, Any}},
    thresholds::Vector{Float64},
)::Dict{String, Any}
    best = _reduced_mpcc_windowed_tol_best_row(rows)
    strictest = isempty(rows) ? nothing : rows[1]
    first_extension =
        _reduced_mpcc_windowed_tol_first_row(rows, row -> _reduced_mpcc_windowed_tol_positive(get(row, "horizon_gain_vs_strictest", missing)))
    first_target =
        _reduced_mpcc_windowed_tol_first_row(rows, row -> get(row, "target_completed", false) === true)
    first_green =
        _reduced_mpcc_windowed_tol_first_row(rows, row -> get(row, "attempt_traffic_light", missing) == "green")
    return Dict{String, Any}(
        "sensitivity_type" => REDUCED_DCDFBA_MPCC_WINDOWED_TOLERANCE_SENSITIVITY_TYPE,
        "varied_threshold" => "max_mass_balance_residual",
        "max_mass_balance_residual_values" => copy(thresholds),
        "strictest_max_mass_balance_residual" => first(thresholds),
        "loosest_max_mass_balance_residual" => last(thresholds),
        "n_cases" => length(rows),
        "n_completed_cases" => count(row -> get(row, "case_status", "") == "completed", rows),
        "n_failed_cases" => count(row -> get(row, "case_status", "") == "failed", rows),
        "green_count" => count(row -> get(row, "attempt_traffic_light", missing) == "green", rows),
        "yellow_count" => count(row -> get(row, "attempt_traffic_light", missing) == "yellow", rows),
        "red_count" => count(row -> get(row, "attempt_traffic_light", missing) == "red", rows),
        "strictest_horizon_reached" => _reduced_mpcc_windowed_tol_value(strictest, "horizon_reached"),
        "strictest_attempt_traffic_light" =>
            _reduced_mpcc_windowed_tol_value(strictest, "attempt_traffic_light"),
        "best_tolerance_case_id" => _reduced_mpcc_windowed_tol_value(best, "tolerance_case_id"),
        "best_max_mass_balance_residual_threshold" =>
            _reduced_mpcc_windowed_tol_value(best, "max_mass_balance_residual_threshold"),
        "best_horizon_reached" => _reduced_mpcc_windowed_tol_value(best, "horizon_reached"),
        "best_target_completed" => _reduced_mpcc_windowed_tol_value(best, "target_completed"),
        "best_attempt_traffic_light" => _reduced_mpcc_windowed_tol_value(best, "attempt_traffic_light"),
        "best_max_mass_balance_ratio" =>
            _reduced_mpcc_windowed_tol_value(best, "max_mass_balance_ratio"),
        "first_horizon_extension_case_id" =>
            _reduced_mpcc_windowed_tol_value(first_extension, "tolerance_case_id"),
        "first_horizon_extension_threshold" =>
            _reduced_mpcc_windowed_tol_value(first_extension, "max_mass_balance_residual_threshold"),
        "first_target_completed_case_id" =>
            _reduced_mpcc_windowed_tol_value(first_target, "tolerance_case_id"),
        "first_target_completed_threshold" =>
            _reduced_mpcc_windowed_tol_value(first_target, "max_mass_balance_residual_threshold"),
        "first_green_case_id" => _reduced_mpcc_windowed_tol_value(first_green, "tolerance_case_id"),
        "first_green_threshold" =>
            _reduced_mpcc_windowed_tol_value(first_green, "max_mass_balance_residual_threshold"),
        "horizon_extended_by_relaxation" => first_extension !== nothing,
        "target_recovered_by_relaxation" =>
            first_target !== nothing &&
            get(first_target, "relaxed_vs_strictest", false) === true,
        "green_recovered_by_relaxation" =>
            first_green !== nothing &&
            get(first_green, "relaxed_vs_strictest", false) === true,
        "total_solve_elapsed_seconds" => sum(
            Float64(get(row, "total_solve_elapsed_seconds", 0.0)) for row in rows if
            _reduced_mpcc_windowed_tol_isfinite_number(
                get(row, "total_solve_elapsed_seconds", missing),
            )
        ),
        "recommended_next_action" =>
            _reduced_mpcc_windowed_tol_recommended_action(
                strictest,
                first_target,
                first_extension,
                best,
            ),
        "outputs_written" => false,
        "sensitivity_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC windowed tolerance sensitivity; diagnostic-only mass-balance threshold sweep.",
    )
end

function _reduced_mpcc_windowed_tol_best_row(rows::Vector{Dict{String, Any}})
    candidates = [
        row for row in rows if
        _reduced_mpcc_windowed_tol_isfinite_number(get(row, "horizon_reached", missing))
    ]
    isempty(candidates) && return nothing
    order = sortperm([
        (
            -(get(row, "target_completed", false) === true ? 1 : 0),
            -Float64(row["horizon_reached"]),
            _reduced_mpcc_windowed_tol_light_rank(get(row, "attempt_traffic_light", missing)),
            _reduced_mpcc_windowed_tol_ratio_sort_value(get(row, "max_mass_balance_ratio", missing)),
            Float64(get(row, "max_mass_balance_residual_threshold", Inf)),
        ) for row in candidates
    ])
    return candidates[first(order)]
end

function _reduced_mpcc_windowed_tol_recommended_action(
    strictest,
    first_target,
    first_extension,
    best,
)::String
    strictest !== nothing &&
        get(strictest, "target_completed", false) === true &&
        get(strictest, "attempt_traffic_light", missing) == "green" &&
        return "review_strict_tolerance_candidate_before_scientific_use"
    strictest !== nothing && get(strictest, "target_completed", false) === true &&
        return "inspect_strict_tolerance_target_completion_blockers"
    first_target !== nothing &&
        get(first_target, "attempt_traffic_light", missing) == "green" &&
        return "review_relaxed_tolerance_candidate_before_scientific_use"
    first_target !== nothing && return "inspect_relaxed_tolerance_target_completion_blockers"
    first_extension !== nothing &&
        return "continue_tolerance_sensitivity_with_failure_diagnostics_at_new_frontier"
    best !== nothing && return "inspect_mass_balance_scaling_before_relaxing_thresholds"
    return "inspect_failed_tolerance_sensitivity_cases"
end

function _reduced_mpcc_windowed_tol_validate_values(values)::Vector{Float64}
    thresholds = Float64.(collect(values))
    isempty(thresholds) && throw(
        ArgumentError("Reduced MPCC windowed tolerance sensitivity values must not be empty."),
    )
    all(value -> isfinite(value) && value > 0.0, thresholds) || throw(
        ArgumentError(
            "Reduced MPCC windowed tolerance sensitivity values must be finite and positive.",
        ),
    )
    length(unique(thresholds)) == length(thresholds) || throw(
        ArgumentError("Reduced MPCC windowed tolerance sensitivity values must be unique."),
    )
    issorted(thresholds) || throw(
        ArgumentError(
            "Reduced MPCC windowed tolerance sensitivity values must be sorted ascending.",
        ),
    )
    return thresholds
end

function _reduced_mpcc_windowed_tol_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_windowed_tol_table_scalar(get(row, column, missing)) for
                row in rows
            ] for column in REDUCED_DCDFBA_MPCC_WINDOWED_TOLERANCE_SENSITIVITY_COLUMNS
        )...,
    )
end

function _reduced_mpcc_windowed_tol_global_row(table::DataFrame)
    if "candidate_id" in names(table)
        index = findfirst(==("windowed_global"), String.(table[!, "candidate_id"]))
        index === nothing || return table[index, :]
    end
    nrow(table) == 0 && return nothing
    return table[1, :]
end

function _reduced_mpcc_windowed_tol_row_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_tol_difference(value, baseline)
    _reduced_mpcc_windowed_tol_isfinite_number(value) || return missing
    _reduced_mpcc_windowed_tol_isfinite_number(baseline) || return missing
    return Float64(value) - Float64(baseline)
end

function _reduced_mpcc_windowed_tol_ratio(value, threshold)
    _reduced_mpcc_windowed_tol_isfinite_number(value) || return missing
    _reduced_mpcc_windowed_tol_isfinite_number(threshold) || return missing
    Float64(threshold) > 0.0 || return missing
    return abs(Float64(value)) / Float64(threshold)
end

function _reduced_mpcc_windowed_tol_positive(value)::Bool
    _reduced_mpcc_windowed_tol_isfinite_number(value) || return false
    return Float64(value) > 0.0
end

function _reduced_mpcc_windowed_tol_first_row(rows::Vector{Dict{String, Any}}, predicate)
    index = findfirst(predicate, rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_windowed_tol_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_windowed_tol_light_rank(value)::Int
    text = String(value)
    text == "green" && return 0
    text == "yellow" && return 1
    text == "red" && return 2
    return 3
end

function _reduced_mpcc_windowed_tol_ratio_sort_value(value)::Float64
    _reduced_mpcc_windowed_tol_isfinite_number(value) || return Inf
    return Float64(value)
end

function _reduced_mpcc_windowed_tol_case_id(index::Int)::String
    return "tolerance_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_windowed_tol_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_windowed_tol_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
