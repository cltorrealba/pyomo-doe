import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_CONTINUATION_TYPE =
    "reduced_dcdfba_mpcc_windowed_continuation_diagnostics"

const REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE =
    "residual_feasible"
const REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_TRAJECTORY_READY =
    "trajectory_ready"
const REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_ITERATION_LIMIT_STATE_DRIFT =
    "iteration_limit_residual_feasible_state_drift"
const REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_ABS_DIFFERENCE = 1.0e-4
const REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE = 2.0e-2
const REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_CANDIDATE = "candidate"
const REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_SEQUENTIAL = "sequential_reference"

const REDUCED_DCDFBA_MPCC_WINDOWED_CONTINUATION_COLUMNS = [
    "window_id",
    "window_index",
    "window_status",
    "t0",
    "tfinal",
    "window_hours",
    "nfe",
    "degree",
    "boundary_dt",
    "n_boundary_points",
    "n_collocation_points",
    "linear_solver",
    "ipopt_profile",
    "complementarity_mode",
    "complementarity_tau",
    "tau_schedule",
    "tau_stage_max_iters",
    "tau_continuation_selected_stage_index",
    "tau_continuation_selected_tau",
    "tau_continuation_selected_reason",
    "tau_continuation_selected_by_best_stage_fallback",
    "tau_continuation_selected_by_coarse_tau_fallback",
    "tau_continuation_coarse_tau_fallback_applied",
    "tau_continuation_attempted_final_tau",
    "tau_continuation_polish_failed",
    "tau_continuation_final_retry_performed",
    "tau_continuation_final_retry_count",
    "tau_continuation_stage_count",
    "tau_continuation_completed",
    "tau_continuation_final_residual_feasible",
    "tau_continuation_final_tau_gate_pass",
    "tau_continuation_blocking_stage",
    "tau_continuation_blocking_reason",
    "tau_continuation_stage_advance_count",
    "solver_call_performed",
    "pre_solve_guard_required",
    "pre_solve_guard_passed",
    "pre_solve_guard_failure_component",
    "pre_solve_residual_thresholds_satisfied",
    "pre_solve_scaling_plan_ready_for_guarded_solve_attempt",
    "pre_solve_scaling_blocking_warning_count",
    "pre_solve_scaling_review_warning_count",
    "pre_solve_warning_count",
    "pre_solve_first_warning",
    "guarded_solve_attempt_blocked",
    "solver_status",
    "primal_status",
    "solve_elapsed_seconds",
    "candidate_residual_feasible",
    "candidate_iteration_limit_residual_feasible",
    "candidate_residual_feasible_source",
    "candidate_residual_feasible_strict_before_coarse_tau_fallback",
    "candidate_trajectory_ready",
    "candidate_allows_continuation",
    "continuation_acceptance_policy",
    "continuation_acceptance_reason",
    "continuation_state_drift_gate_pass",
    "continuation_state_drift_blocks_continuation",
    "continuation_state_drift_gate_mode",
    "continuation_state_drift_max_abs_difference_threshold",
    "continuation_state_drift_max_relative_rmse_threshold",
    "iteration_limit_policy_accepted",
    "candidate_is_scientific_simulation",
    "residual_thresholds_satisfied",
    "dominant_residual",
    "next_recommended_action",
    "candidate_warning_count",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_lower_complementarity_product",
    "max_upper_complementarity_product",
    "max_complementarity_tau_violation",
    "max_complementarity_tau_violation_raw",
    "complementarity_tau_gate_tolerance",
    "complementarity_tau_gate_tolerance_source",
    "complementarity_tau_gate_pass",
    "cross_window_flux_dual_start_applied",
    "cross_window_flux_dual_start_policy",
    "cross_window_flux_dual_start_source",
    "cross_window_flux_dual_start_source_stage_index",
    "cross_window_flux_dual_start_source_tau",
    "cross_window_flux_dual_start_source_solver_status",
    "cross_window_flux_dual_start_source_residual_feasible",
    "cross_window_flux_dual_start_max_flux_projection_adjustment",
    "cross_window_flux_dual_start_max_lower_dual_sign_clipping",
    "cross_window_flux_dual_start_max_upper_dual_sign_clipping",
    "cross_window_flux_dual_start_rhs_derivatives_refreshed",
    "window_initial_state_propagation_policy",
    "window_initial_state_primary_source",
    "window_initial_state_retry_applied",
    "window_initial_state_retry_source",
    "max_state_abs_difference",
    "max_state_rmse",
    "max_state_relative_rmse",
    "final_biomass_difference",
    "final_total_sugar_difference",
    "initial_state_source",
    "next_initial_state_source",
    "full_dfba_cold_reference_deferred",
    "reduced_full_equivalence_claimed",
    "persistent_lp_baseline_used",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCWindowedContinuationResult

In-memory diagnostic result for chained short-window reduced MPCC solve
attempts. Each completed window is initialized from a local reduced sequential
DFBA trajectory, and the next window can use the previous MPCC boundary
candidate final state as its initial condition. This is a continuation
diagnostic only; it is not a solved scientific simultaneous trajectory.
"""
struct ReducedDCDFBAMPCCWindowedContinuationResult
    window_table::DataFrame
    window_comparisons::Vector{ReducedDCDFBAMPCCSequentialComparisonResult}
    sequential_reference::Union{Nothing, SimulationResult}
    boundary_candidate::Union{Nothing, SimulationResult}
    state_metrics_table::DataFrame
    aligned_timeseries_table::DataFrame
    metadata::Dict{String, Any}
end

struct ReducedDCDFBAMPCCWindowNoCandidateError <: Exception
    solve_attempt::ReducedDCDFBAMPCCSolveAttemptResult
end

function Base.showerror(io::IO, err::ReducedDCDFBAMPCCWindowNoCandidateError)
    metadata = err.solve_attempt.metadata
    print(io, "Reduced DC-dFBA MPCC solve-attempt result has no extracted candidate")
    if get(metadata, "guarded_solve_attempt_blocked", false) === true
        print(io, " after pre-solve guard block")
    end
    dominant = get(metadata, "dominant_residual", get(metadata, "pre_solve_dominant_residual", missing))
    dominant === missing || print(io, "; dominant_residual=$(dominant)")
end

"""
    export_reduced_dcdfba_mpcc_windowed_continuation(result, output_dir; overwrite=false)

Write CSV/TOML diagnostic artifacts for a reduced MPCC windowed-continuation
result. This export is diagnostic only and does not mark the candidate as a
validated scientific simulation.
"""
function export_reduced_dcdfba_mpcc_windowed_continuation(
    result::ReducedDCDFBAMPCCWindowedContinuationResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Reduced MPCC windowed output_dir exists and is not a directory: $output_path")
    end

    paths = Dict{String, String}(
        "window_table" => joinpath(output_path, "window_table.csv"),
        "state_metrics" => joinpath(output_path, "state_metrics.csv"),
        "aligned_timeseries" => joinpath(output_path, "aligned_timeseries.csv"),
        "metadata" => joinpath(output_path, "metadata.toml"),
    )
    _reduced_mpcc_window_prepare_output_paths!(paths, overwrite)

    CSV.write(paths["window_table"], result.window_table)
    CSV.write(paths["state_metrics"], result.state_metrics_table)
    CSV.write(paths["aligned_timeseries"], result.aligned_timeseries_table)
    open(paths["metadata"], "w") do io
        TOML.print(io, _toml_normalize(result.metadata))
    end
    return paths
end

function _reduced_mpcc_window_prepare_output_paths!(
    paths::Dict{String, String},
    overwrite::Bool,
)
    parent_dirs = unique(dirname(path) for path in values(paths))
    for dir in parent_dirs
        !isempty(dir) && mkpath(dir)
    end
    existing_targets = [path for path in values(paths) if isfile(path)]
    if !overwrite && !isempty(existing_targets)
        error(
            "Reduced MPCC windowed output file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end
    if overwrite
        for path in values(paths)
            isfile(path) && rm(path)
        end
    end
    return nothing
end

"""
    run_reduced_dcdfba_mpcc_windowed_continuation(comparisons; sequential_reference=nothing)

Aggregate already-computed reduced MPCC-vs-sequential window comparisons as a
windowed-continuation diagnostic. If `sequential_reference` is omitted, the
window-local reduced sequential references are concatenated for the state
comparison.
"""
function run_reduced_dcdfba_mpcc_windowed_continuation(
    comparisons::AbstractVector{<:ReducedDCDFBAMPCCSequentialComparisonResult};
    sequential_reference = nothing,
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_abs_difference_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_ABS_DIFFERENCE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
)::ReducedDCDFBAMPCCWindowedContinuationResult
    isempty(comparisons) && throw(
        ArgumentError("Reduced MPCC windowed continuation requires at least one window comparison."),
    )
    policy = _reduced_mpcc_window_validate_continuation_policy(
        continuation_acceptance_policy,
    )
    state_threshold =
        _reduced_mpcc_window_validate_state_relative_rmse_threshold(
            continuation_state_relative_rmse_threshold,
        )
    abs_threshold =
        _reduced_mpcc_window_validate_state_abs_difference_threshold(
            continuation_state_abs_difference_threshold,
        )
    collected = collect(comparisons)
    rows = [
        _reduced_mpcc_window_completed_row(
            index,
            comparison;
            continuation_acceptance_policy = policy,
            continuation_state_abs_difference_threshold = abs_threshold,
            continuation_state_relative_rmse_threshold = state_threshold,
        ) for
        (index, comparison) in enumerate(collected)
    ]
    return _reduced_mpcc_window_result(
        rows,
        collected;
        sequential_reference = sequential_reference,
        n_requested_windows = length(collected),
        reference_source = sequential_reference === nothing ?
                           "concatenated_window_reduced_sequential_dfba" :
                           "provided_reduced_sequential_dfba",
        continuation_acceptance_policy = policy,
        continuation_state_abs_difference_threshold = abs_threshold,
        continuation_state_relative_rmse_threshold = state_threshold,
    )
end

"""
    run_reduced_dcdfba_mpcc_windowed_continuation(model, reaction_map; kwargs...)

Run chained short reduced MPCC solve attempts over uniform windows. A completed
window can pass its final boundary candidate state to the next window only when
the candidate is residual-feasible and finite. The concatenated boundary
candidate is compared with a reduced sequential DFBA reference over the reached
horizon. No full model, DFVB KKT, HSL, generated output, or scientific
simulation claim is introduced.
"""
function run_reduced_dcdfba_mpcc_windowed_continuation(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    t0::Real = 0.0,
    window_hours::Real = 0.25,
    n_windows::Int = 2,
    nfe_per_window::Int = 1,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    tau_schedule = nothing,
    tau_stage_max_iters = reduced_mpcc_tau_stage_max_iters_from_env(),
    tau_final_retry_max_iter = reduced_mpcc_tau_final_retry_max_iter_from_env(),
    allow_coarse_tau_fallback::Bool = false,
    propagate_flux_dual_starts::Bool = true,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_abs_difference_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_ABS_DIFFERENCE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    initial_state_propagation_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_CANDIDATE,
    silent::Bool = true,
    continue_on_error::Bool = true,
    window_callback = nothing,
    tau_stage_callback = nothing,
)::ReducedDCDFBAMPCCWindowedContinuationResult
    policy = _reduced_mpcc_window_validate_continuation_policy(
        continuation_acceptance_policy,
    )
    initial_state_policy =
        _reduced_mpcc_window_validate_initial_state_propagation_policy(
            initial_state_propagation_policy,
        )
    state_threshold =
        _reduced_mpcc_window_validate_state_relative_rmse_threshold(
            continuation_state_relative_rmse_threshold,
        )
    abs_threshold =
        _reduced_mpcc_window_validate_state_abs_difference_threshold(
            continuation_state_abs_difference_threshold,
        )
    specs = _reduced_mpcc_window_specs(t0, window_hours, n_windows, nfe_per_window, degree)
    rows = Dict{String, Any}[]
    comparisons = ReducedDCDFBAMPCCSequentialComparisonResult[]
    initial_y0 = Float64.(collect(y0))
    current_y0 = copy(initial_y0)
    previous_flux_dual_start_seed = nothing
    global_start_reference =
        initial_state_policy ==
        REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_SEQUENTIAL ?
        simulate_reduced_dfba(
            model,
            reaction_map;
            y0 = initial_y0,
            tspan = (Float64(t0), last(specs).tfinal),
            params = params,
            optimizer = sequential_optimizer,
            silent = silent,
            lp_atol = sequential_lp_atol,
            ode_abstol = sequential_ode_abstol,
            ode_reltol = sequential_ode_reltol,
            saveat = Float64(window_hours) / nfe_per_window,
            algorithm = sequential_algorithm,
            adaptive = sequential_adaptive,
            dt = sequential_dt,
            nonnegative = sequential_nonnegative,
            stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
            reconstruct_fluxes = sequential_reconstruct_fluxes,
            model_scope = "reduced",
        ) :
        nothing

    for spec in specs
        try
            primary_state_source =
                spec.window_index == 1 ? "provided_y0" :
                initial_state_policy ==
                REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_SEQUENTIAL ?
                "previous_window_local_sequential_final_state" :
                "previous_candidate_final_boundary_state"
            comparison = _reduced_mpcc_window_run_one(
                model,
                reaction_map;
                spec = spec,
                y0 = current_y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = ipopt_max_iter,
                linear_solver = linear_solver,
                ipopt_profile = ipopt_profile,
                complementarity_mode = complementarity_mode,
                complementarity_tau = complementarity_tau,
                complementarity_tau_gate_tol = complementarity_tau_gate_tol,
                tau_schedule = tau_schedule,
                tau_stage_max_iters = tau_stage_max_iters,
                tau_final_retry_max_iter = tau_final_retry_max_iter,
                allow_coarse_tau_fallback = allow_coarse_tau_fallback,
                flux_dual_start_seed =
                    propagate_flux_dual_starts ? previous_flux_dual_start_seed : nothing,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                silent = silent,
                tau_stage_callback = _reduced_mpcc_window_tau_stage_callback(
                    tau_stage_callback,
                    spec,
                    "primary",
                ),
            )
            row = _reduced_mpcc_window_completed_row(
                spec.window_index,
                comparison;
                continuation_acceptance_policy = policy,
                continuation_state_abs_difference_threshold = abs_threshold,
                continuation_state_relative_rmse_threshold = state_threshold,
                state_drift_blocks_continuation =
                    initial_state_policy ==
                    REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_CANDIDATE,
            )
            if !_reduced_mpcc_window_allows_continuation(row, comparison) &&
               global_start_reference !== nothing &&
               spec.window_index > 1
                try
                    fallback_y0 = _reduced_mpcc_window_reference_state_at_time(
                        global_start_reference,
                        spec.t0,
                    )
                    fallback_comparison = _reduced_mpcc_window_run_one(
                        model,
                        reaction_map;
                        spec = spec,
                        y0 = fallback_y0,
                        params = params,
                        sequential_optimizer = sequential_optimizer,
                        sequential_algorithm = sequential_algorithm,
                        sequential_ode_abstol = sequential_ode_abstol,
                        sequential_ode_reltol = sequential_ode_reltol,
                        sequential_lp_atol = sequential_lp_atol,
                        sequential_adaptive = sequential_adaptive,
                        sequential_dt = sequential_dt,
                        sequential_nonnegative = sequential_nonnegative,
                        sequential_stop_on_sugar_depletion =
                            sequential_stop_on_sugar_depletion,
                        sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                        mpcc_optimizer = mpcc_optimizer,
                        ipopt_max_iter = ipopt_max_iter,
                        linear_solver = linear_solver,
                        ipopt_profile = ipopt_profile,
                        complementarity_mode = complementarity_mode,
                        complementarity_tau = complementarity_tau,
                        complementarity_tau_gate_tol = complementarity_tau_gate_tol,
                        tau_schedule = tau_schedule,
                        tau_stage_max_iters = tau_stage_max_iters,
                        tau_final_retry_max_iter = tau_final_retry_max_iter,
                        allow_coarse_tau_fallback = allow_coarse_tau_fallback,
                        flux_dual_start_seed =
                            propagate_flux_dual_starts ? previous_flux_dual_start_seed : nothing,
                        require_pre_solve_ready = require_pre_solve_ready,
                        residual_thresholds = residual_thresholds,
                        silent = silent,
                        tau_stage_callback = _reduced_mpcc_window_tau_stage_callback(
                            tau_stage_callback,
                            spec,
                            "sequential_reference_retry",
                        ),
                    )
                    fallback_row = _reduced_mpcc_window_completed_row(
                        spec.window_index,
                        fallback_comparison;
                        continuation_acceptance_policy = policy,
                        continuation_state_abs_difference_threshold = abs_threshold,
                        continuation_state_relative_rmse_threshold = state_threshold,
                        state_drift_blocks_continuation = false,
                    )
                    if _reduced_mpcc_window_allows_continuation(
                        fallback_row,
                        fallback_comparison,
                    )
                        comparison = fallback_comparison
                        row = fallback_row
                        row["window_initial_state_retry_applied"] = true
                        row["window_initial_state_retry_source"] =
                            "global_sequential_reference_at_window_start"
                    else
                        row["window_initial_state_retry_applied"] = true
                        row["window_initial_state_retry_source"] =
                            "global_sequential_reference_at_window_start_rejected"
                    end
                catch fallback_err
                    row["window_initial_state_retry_applied"] = true
                    row["window_initial_state_retry_source"] =
                        "global_sequential_reference_at_window_start_errored"
                    row["window_initial_state_retry_error_type"] =
                        string(typeof(fallback_err))
                    row["window_initial_state_retry_error_message"] =
                        sprint(showerror, fallback_err)
                end
            end
            row["window_initial_state_primary_source"] = primary_state_source
            row["window_initial_state_retry_applied"] =
                get(row, "window_initial_state_retry_applied", false)
            row["window_initial_state_retry_source"] =
                get(row, "window_initial_state_retry_source", "not_attempted")
            row["window_initial_state_propagation_policy"] = initial_state_policy
            row["next_initial_state_source"] = get(row, "candidate_allows_continuation", false) === true ?
                (
                    initial_state_policy ==
                    REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_SEQUENTIAL ?
                    "window_local_sequential_final_state" :
                    "candidate_final_boundary_state"
                ) :
                "not_available"
            push!(comparisons, comparison)
            push!(rows, row)
            _reduced_mpcc_window_maybe_callback(
                window_callback,
                row,
                length(rows),
                n_windows,
            )
            _reduced_mpcc_window_allows_continuation(row, comparison) || break
            current_y0 =
                initial_state_policy ==
                REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_SEQUENTIAL ?
                copy(comparison.sequential_result.states[:, end]) :
                copy(comparison.trajectory_candidate.boundary_result.states[:, end])
            previous_flux_dual_start_seed =
                comparison.trajectory_candidate.candidate_diagnostics
        catch err
            continue_on_error || rethrow()
            row =
                err isa ReducedDCDFBAMPCCWindowNoCandidateError ?
                _reduced_mpcc_window_no_candidate_row(spec, err.solve_attempt, err) :
                _reduced_mpcc_window_error_row(spec, err)
            push!(rows, row)
            _reduced_mpcc_window_maybe_callback(
                window_callback,
                row,
                length(rows),
                n_windows,
            )
            break
        end
    end

    sequential_reference = nothing
    if !isempty(comparisons)
        actual_final_time = last(last(comparisons).trajectory_candidate.boundary_result.time)
        sequential_reference = simulate_reduced_dfba(
            model,
            reaction_map;
            y0 = initial_y0,
            tspan = (Float64(t0), actual_final_time),
            params = params,
            optimizer = sequential_optimizer,
            silent = silent,
            lp_atol = sequential_lp_atol,
            ode_abstol = sequential_ode_abstol,
            ode_reltol = sequential_ode_reltol,
            saveat = Float64(window_hours) / nfe_per_window,
            algorithm = sequential_algorithm,
            adaptive = sequential_adaptive,
            dt = sequential_dt,
            nonnegative = sequential_nonnegative,
            stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
            reconstruct_fluxes = sequential_reconstruct_fluxes,
            model_scope = "reduced",
        )
    end

    return _reduced_mpcc_window_result(
        rows,
        comparisons;
        sequential_reference = sequential_reference,
        n_requested_windows = n_windows,
        window_hours = Float64(window_hours),
        nfe_per_window = nfe_per_window,
        degree = degree,
        ipopt_profile = ipopt_profile,
        linear_solver = linear_solver,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        complementarity_tau_gate_tol = complementarity_tau_gate_tol,
        tau_schedule = tau_schedule,
        tau_stage_max_iters = tau_stage_max_iters,
        tau_final_retry_max_iter = tau_final_retry_max_iter,
        allow_coarse_tau_fallback = allow_coarse_tau_fallback,
        propagate_flux_dual_starts = propagate_flux_dual_starts,
        initial_state_propagation_policy = initial_state_policy,
        reference_source = "global_reduced_sequential_dfba_from_initial_y0",
        continuation_acceptance_policy = policy,
        continuation_state_abs_difference_threshold = abs_threshold,
        continuation_state_relative_rmse_threshold = state_threshold,
    )
end

function _reduced_mpcc_window_run_one(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    spec,
    y0::AbstractVector,
    params::ZentenoKineticParameters,
    sequential_optimizer,
    sequential_algorithm,
    sequential_ode_abstol::Real,
    sequential_ode_reltol::Real,
    sequential_lp_atol::Real,
    sequential_adaptive::Bool,
    sequential_dt,
    sequential_nonnegative::Bool,
    sequential_stop_on_sugar_depletion::Bool,
    sequential_reconstruct_fluxes::Bool,
    mpcc_optimizer,
    ipopt_max_iter::Union{Nothing, Int},
    linear_solver::AbstractString,
    ipopt_profile::AbstractString,
    complementarity_mode::Union{Symbol, AbstractString},
    complementarity_tau::Real,
    complementarity_tau_gate_tol::Union{Nothing, Real},
    tau_schedule,
    tau_stage_max_iters,
    tau_final_retry_max_iter,
    allow_coarse_tau_fallback::Bool,
    flux_dual_start_seed,
    require_pre_solve_ready::Bool,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds,
    silent::Bool,
    tau_stage_callback,
)::ReducedDCDFBAMPCCSequentialComparisonResult
    sequential_result = simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = (spec.t0, spec.tfinal),
        params = params,
        optimizer = sequential_optimizer,
        silent = silent,
        lp_atol = sequential_lp_atol,
        ode_abstol = sequential_ode_abstol,
        ode_reltol = sequential_ode_reltol,
        saveat = spec.boundary_dt,
        algorithm = sequential_algorithm,
        adaptive = sequential_adaptive,
        dt = sequential_dt,
        nonnegative = sequential_nonnegative,
        stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        reconstruct_fluxes = sequential_reconstruct_fluxes,
        model_scope = "reduced",
    )
    solve_attempt =
        tau_schedule === nothing ?
        solve_reduced_dcdfba_mpcc_solve_attempt(
            model,
            reaction_map;
            sequential_initialization = sequential_result,
            tspan = (spec.t0, spec.tfinal),
            nfe = spec.nfe,
            degree = spec.degree,
            params = params,
            residual_thresholds = residual_thresholds,
            optimizer = mpcc_optimizer,
            ipopt_max_iter = ipopt_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            complementarity_tau_gate_tol = complementarity_tau_gate_tol,
            flux_dual_start_seed = flux_dual_start_seed,
            require_pre_solve_ready = require_pre_solve_ready,
            silent = silent,
        ) :
        solve_reduced_dcdfba_mpcc_tau_continuation(
            model,
            reaction_map;
            sequential_initialization = sequential_result,
            tspan = (spec.t0, spec.tfinal),
            nfe = spec.nfe,
            degree = spec.degree,
            params = params,
            residual_thresholds = residual_thresholds,
            optimizer = mpcc_optimizer,
            ipopt_max_iter = ipopt_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau_gate_tol = complementarity_tau_gate_tol,
            tau_schedule = tau_schedule,
            tau_stage_max_iters = tau_stage_max_iters,
            tau_final_retry_max_iter = tau_final_retry_max_iter,
            allow_coarse_tau_fallback = allow_coarse_tau_fallback,
            flux_dual_start_seed = flux_dual_start_seed,
            require_pre_solve_ready = require_pre_solve_ready,
            silent = silent,
            tau_stage_callback = tau_stage_callback,
        ).final_result
    solve_attempt === nothing && throw(
        ArgumentError("Reduced MPCC tau continuation produced no final solve attempt."),
    )
    solve_attempt.candidate_diagnostics === nothing &&
        throw(ReducedDCDFBAMPCCWindowNoCandidateError(solve_attempt))
    trajectory_candidate = extract_reduced_dcdfba_mpcc_trajectory_candidate(solve_attempt)
    comparison = compare_reduced_dcdfba_mpcc_to_sequential(sequential_result, trajectory_candidate)
    _reduced_mpcc_sweep_merge_solve_attempt_metadata!(comparison, solve_attempt)
    return comparison
end

function _reduced_mpcc_window_specs(
    t0::Real,
    window_hours::Real,
    n_windows::Int,
    nfe_per_window::Int,
    degree::Int,
)::Vector{NamedTuple}
    initial_time = Float64(t0)
    duration = Float64(window_hours)
    isfinite(initial_time) || throw(
        ArgumentError("Reduced MPCC windowed continuation t0 must be finite."),
    )
    isfinite(duration) && duration > 0.0 || throw(
        ArgumentError("Reduced MPCC windowed continuation window_hours must be finite and positive."),
    )
    n_windows > 0 || throw(
        ArgumentError("Reduced MPCC windowed continuation n_windows must be positive."),
    )
    nfe_per_window > 0 || throw(
        ArgumentError("Reduced MPCC windowed continuation nfe_per_window must be positive."),
    )
    degree == 3 || throw(
        ArgumentError("Reduced MPCC windowed continuation currently supports only degree == 3."),
    )

    specs = NamedTuple[]
    for window_index in 1:n_windows
        left = initial_time + (window_index - 1) * duration
        right = left + duration
        push!(
            specs,
            (
                window_id = _reduced_mpcc_window_id(window_index),
                window_index = window_index,
                t0 = left,
                tfinal = right,
                window_hours = duration,
                nfe = nfe_per_window,
                degree = degree,
                boundary_dt = duration / nfe_per_window,
            ),
        )
    end
    return specs
end

function _reduced_mpcc_window_reference_state_at_time(
    reference::SimulationResult,
    target_time::Real;
    atol::Real = 1.0e-8,
)::Vector{Float64}
    time = Float64(target_time)
    index = findfirst(
        saved_time -> isapprox(Float64(saved_time), time; atol = Float64(atol), rtol = 0.0),
        reference.time,
    )
    index !== nothing || throw(
        ArgumentError(
            "Reduced MPCC windowed continuation could not find sequential " *
            "reference state at t=$(time). Available range is " *
            "[$(first(reference.time)), $(last(reference.time))].",
        ),
    )
    return copy(reference.states[:, index])
end

function _reduced_mpcc_window_maybe_callback(
    callback,
    row::Dict{String, Any},
    row_index::Int,
    n_requested_windows::Int,
)
    callback === nothing && return nothing
    callback(row, row_index, n_requested_windows)
    return nothing
end

function _reduced_mpcc_window_tau_stage_callback(callback, spec, attempt::AbstractString)
    callback === nothing && return nothing
    return event -> begin
        row = copy(event)
        row["window_id"] = spec.window_id
        row["window_index"] = spec.window_index
        row["t0"] = spec.t0
        row["tfinal"] = spec.tfinal
        row["nfe"] = spec.nfe
        row["window_attempt"] = String(attempt)
        callback(row)
        return nothing
    end
end

function _reduced_mpcc_window_completed_row(
    index::Int,
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
    ;
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_abs_difference_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_ABS_DIFFERENCE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    state_drift_blocks_continuation::Bool = true,
)::Dict{String, Any}
    spec = _reduced_mpcc_window_inferred_spec(index, comparison)
    base = _reduced_mpcc_sweep_completed_row(spec, comparison)
    candidate_metadata = comparison.trajectory_candidate.metadata
    finite_final_state = _reduced_mpcc_window_has_finite_final_state(comparison)
    policy = _reduced_mpcc_window_validate_continuation_policy(
        continuation_acceptance_policy,
    )
    state_threshold =
        _reduced_mpcc_window_validate_state_relative_rmse_threshold(
            continuation_state_relative_rmse_threshold,
        )
    abs_threshold =
        _reduced_mpcc_window_validate_state_abs_difference_threshold(
            continuation_state_abs_difference_threshold,
        )
    decision = _reduced_mpcc_window_continuation_decision(
        base,
        comparison.state_metrics_table,
        finite_final_state;
        continuation_acceptance_policy = policy,
        continuation_state_abs_difference_threshold = abs_threshold,
        continuation_state_relative_rmse_threshold = state_threshold,
        state_drift_blocks_continuation = state_drift_blocks_continuation,
    )
    return Dict{String, Any}(
        "window_id" => spec.scenario_id,
        "window_index" => index,
        "window_status" => "completed",
        "t0" => base["t0"],
        "tfinal" => base["tfinal"],
        "window_hours" => base["horizon"],
        "nfe" => base["nfe"],
        "degree" => base["degree"],
        "boundary_dt" => base["boundary_dt"],
        "n_boundary_points" => base["n_boundary_points"],
        "n_collocation_points" => base["n_collocation_points"],
        "linear_solver" => get(comparison.metadata, "linear_solver", missing),
        "ipopt_profile" => get(comparison.metadata, "solve_attempt_ipopt_profile", missing),
        "complementarity_mode" => get(comparison.metadata, "complementarity_mode", missing),
        "complementarity_tau" => get(comparison.metadata, "complementarity_tau", missing),
        "tau_schedule" => get(comparison.metadata, "tau_schedule", missing),
        "tau_stage_max_iters" => get(comparison.metadata, "tau_stage_max_iters", missing),
        "tau_continuation_selected_stage_index" =>
            get(comparison.metadata, "tau_continuation_selected_stage_index", missing),
        "tau_continuation_selected_tau" =>
            get(comparison.metadata, "tau_continuation_selected_tau", missing),
        "tau_continuation_selected_reason" =>
            get(comparison.metadata, "tau_continuation_selected_reason", missing),
        "tau_continuation_selected_by_best_stage_fallback" => get(
            comparison.metadata,
            "tau_continuation_selected_by_best_stage_fallback",
            missing,
        ),
        "tau_continuation_selected_by_coarse_tau_fallback" => get(
            comparison.metadata,
            "tau_continuation_selected_by_coarse_tau_fallback",
            get(candidate_metadata, "tau_continuation_selected_by_coarse_tau_fallback", missing),
        ),
        "tau_continuation_coarse_tau_fallback_applied" => get(
            comparison.metadata,
            "tau_continuation_coarse_tau_fallback_applied",
            get(candidate_metadata, "tau_continuation_coarse_tau_fallback_applied", missing),
        ),
        "tau_continuation_attempted_final_tau" =>
            get(comparison.metadata, "tau_continuation_attempted_final_tau", missing),
        "tau_continuation_polish_failed" =>
            get(comparison.metadata, "tau_continuation_polish_failed", missing),
        "tau_continuation_final_retry_performed" =>
            get(comparison.metadata, "tau_continuation_final_retry_performed", missing),
        "tau_continuation_final_retry_count" =>
            get(comparison.metadata, "tau_continuation_final_retry_count", missing),
        "tau_continuation_stage_count" =>
            get(comparison.metadata, "tau_continuation_stage_count", missing),
        "tau_continuation_completed" =>
            get(comparison.metadata, "tau_continuation_completed", missing),
        "tau_continuation_final_residual_feasible" =>
            get(comparison.metadata, "tau_continuation_final_residual_feasible", missing),
        "tau_continuation_final_tau_gate_pass" =>
            get(comparison.metadata, "tau_continuation_final_tau_gate_pass", missing),
        "tau_continuation_blocking_stage" =>
            get(comparison.metadata, "tau_continuation_blocking_stage", missing),
        "tau_continuation_blocking_reason" =>
            get(comparison.metadata, "tau_continuation_blocking_reason", missing),
        "tau_continuation_stage_advance_count" =>
            get(comparison.metadata, "tau_continuation_stage_advance_count", missing),
        "solver_call_performed" =>
            get(comparison.metadata, "solver_call_performed", missing),
        "pre_solve_guard_required" =>
            get(comparison.metadata, "pre_solve_guard_required", missing),
        "pre_solve_guard_passed" =>
            get(comparison.metadata, "pre_solve_guard_passed", missing),
        "pre_solve_guard_failure_component" =>
            get(comparison.metadata, "pre_solve_guard_failure_component", missing),
        "pre_solve_residual_thresholds_satisfied" =>
            get(comparison.metadata, "pre_solve_residual_thresholds_satisfied", missing),
        "pre_solve_scaling_plan_ready_for_guarded_solve_attempt" => get(
            comparison.metadata,
            "pre_solve_scaling_plan_ready_for_guarded_solve_attempt",
            missing,
        ),
        "pre_solve_scaling_blocking_warning_count" =>
            get(comparison.metadata, "pre_solve_scaling_blocking_warning_count", missing),
        "pre_solve_scaling_review_warning_count" =>
            get(comparison.metadata, "pre_solve_scaling_review_warning_count", missing),
        "pre_solve_warning_count" =>
            get(comparison.metadata, "pre_solve_warning_count", missing),
        "pre_solve_first_warning" =>
            get(comparison.metadata, "pre_solve_first_warning", missing),
        "guarded_solve_attempt_blocked" =>
            get(comparison.metadata, "guarded_solve_attempt_blocked", missing),
        "solver_status" => base["solver_status"],
        "primal_status" => base["primal_status"],
        "solve_elapsed_seconds" => base["solve_elapsed_seconds"],
        "candidate_residual_feasible" => base["candidate_residual_feasible"],
        "candidate_iteration_limit_residual_feasible" =>
            base["candidate_iteration_limit_residual_feasible"],
        "candidate_residual_feasible_source" => get(
            candidate_metadata,
            "candidate_residual_feasible_source",
            missing,
        ),
        "candidate_residual_feasible_strict_before_coarse_tau_fallback" => get(
            candidate_metadata,
            "candidate_residual_feasible_strict_before_coarse_tau_fallback",
            missing,
        ),
        "candidate_trajectory_ready" => base["candidate_trajectory_ready"],
        "candidate_allows_continuation" => decision.allows_continuation,
        "continuation_acceptance_policy" => policy,
        "continuation_acceptance_reason" => decision.reason,
        "continuation_state_drift_gate_pass" => decision.state_drift_gate_pass,
        "continuation_state_drift_blocks_continuation" =>
            state_drift_blocks_continuation,
        "continuation_state_drift_gate_mode" => "per_state_abs_or_relative",
        "continuation_state_drift_max_abs_difference_threshold" => abs_threshold,
        "continuation_state_drift_max_relative_rmse_threshold" => state_threshold,
        "iteration_limit_policy_accepted" => decision.iteration_limit_policy_accepted,
        "candidate_is_scientific_simulation" => base["candidate_is_scientific_simulation"],
        "residual_thresholds_satisfied" => base["residual_thresholds_satisfied"],
        "dominant_residual" => base["dominant_residual"],
        "next_recommended_action" => base["next_recommended_action"],
        "candidate_warning_count" => base["candidate_warning_count"],
        "max_rhs_residual" => base["max_rhs_residual"],
        "max_mass_balance_residual" => base["max_mass_balance_residual"],
        "max_lower_bound_violation" => base["max_lower_bound_violation"],
        "max_upper_bound_violation" => base["max_upper_bound_violation"],
        "max_stationarity_residual" => base["max_stationarity_residual"],
        "max_lower_complementarity_residual" =>
            base["max_lower_complementarity_residual"],
        "max_upper_complementarity_residual" =>
            base["max_upper_complementarity_residual"],
        "max_lower_complementarity_product" =>
            get(comparison.metadata, "max_lower_complementarity_product", missing),
        "max_upper_complementarity_product" =>
            get(comparison.metadata, "max_upper_complementarity_product", missing),
        "max_complementarity_tau_violation" =>
            get(comparison.metadata, "max_complementarity_tau_violation", missing),
        "max_complementarity_tau_violation_raw" =>
            get(comparison.metadata, "max_complementarity_tau_violation_raw", missing),
        "complementarity_tau_gate_tolerance" =>
            get(comparison.metadata, "complementarity_tau_gate_tolerance", missing),
        "complementarity_tau_gate_tolerance_source" =>
            get(comparison.metadata, "complementarity_tau_gate_tolerance_source", missing),
        "complementarity_tau_gate_pass" =>
            get(comparison.metadata, "complementarity_tau_gate_pass", missing),
        "cross_window_flux_dual_start_applied" =>
            get(comparison.metadata, "cross_window_flux_dual_start_applied", false),
        "cross_window_flux_dual_start_policy" =>
            get(comparison.metadata, "cross_window_flux_dual_start_policy", missing),
        "cross_window_flux_dual_start_source" =>
            get(comparison.metadata, "cross_window_flux_dual_start_source", missing),
        "cross_window_flux_dual_start_source_stage_index" =>
            get(comparison.metadata, "cross_window_flux_dual_start_source_stage_index", missing),
        "cross_window_flux_dual_start_source_tau" =>
            get(comparison.metadata, "cross_window_flux_dual_start_source_tau", missing),
        "cross_window_flux_dual_start_source_solver_status" =>
            get(comparison.metadata, "cross_window_flux_dual_start_source_solver_status", missing),
        "cross_window_flux_dual_start_source_residual_feasible" =>
            get(comparison.metadata, "cross_window_flux_dual_start_source_residual_feasible", missing),
        "cross_window_flux_dual_start_max_flux_projection_adjustment" => get(
            comparison.metadata,
            "cross_window_flux_dual_start_max_flux_projection_adjustment",
            missing,
        ),
        "cross_window_flux_dual_start_max_lower_dual_sign_clipping" => get(
            comparison.metadata,
            "cross_window_flux_dual_start_max_lower_dual_sign_clipping",
            missing,
        ),
        "cross_window_flux_dual_start_max_upper_dual_sign_clipping" => get(
            comparison.metadata,
            "cross_window_flux_dual_start_max_upper_dual_sign_clipping",
            missing,
        ),
        "cross_window_flux_dual_start_rhs_derivatives_refreshed" => get(
            comparison.metadata,
            "cross_window_flux_dual_start_rhs_derivatives_refreshed",
            missing,
        ),
        "window_initial_state_propagation_policy" =>
            get(
                comparison.metadata,
                "window_initial_state_propagation_policy",
                REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_CANDIDATE,
            ),
        "max_state_abs_difference" => base["max_state_abs_difference"],
        "max_state_rmse" => base["max_state_rmse"],
        "max_state_relative_rmse" => base["max_state_relative_rmse"],
        "final_biomass_difference" => base["final_biomass_difference"],
        "final_total_sugar_difference" => base["final_total_sugar_difference"],
        "initial_state_source" =>
            index == 1 ? "provided_y0" : "previous_candidate_final_boundary_state",
        "next_initial_state_source" =>
            decision.allows_continuation ? "candidate_final_boundary_state" : "not_available",
        "full_dfba_cold_reference_deferred" => base["full_dfba_cold_reference_deferred"],
        "reduced_full_equivalence_claimed" => base["reduced_full_equivalence_claimed"],
        "persistent_lp_baseline_used" => base["persistent_lp_baseline_used"],
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => base["indices_reacciones_used"],
        "r0001_used_as_oxygen" => base["r0001_used_as_oxygen"],
        "error_type" => missing,
        "error_message" => missing,
    )
end

function _reduced_mpcc_window_inferred_spec(
    index::Int,
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
)
    metadata = comparison.metadata
    candidate_metadata = comparison.trajectory_candidate.metadata
    t0 = _reduced_mpcc_window_float_or_missing(get(metadata, "initial_time", first(comparison.sequential_result.time)))
    tfinal = _reduced_mpcc_window_float_or_missing(get(metadata, "final_time", last(comparison.sequential_result.time)))
    horizon = (t0 === missing || tfinal === missing) ? missing : tfinal - t0
    inferred_nfe = length(comparison.trajectory_candidate.boundary_result.time) - 1
    nfe = _reduced_mpcc_window_int_or_missing(get(candidate_metadata, "candidate_grid_nfe", inferred_nfe))
    degree = _reduced_mpcc_window_int_or_missing(get(candidate_metadata, "candidate_collocation_degree", 3))
    return (
        scenario_id = _reduced_mpcc_window_id(index),
        t0 = t0,
        tfinal = tfinal,
        horizon = horizon,
        nfe = nfe,
        degree = degree,
    )
end

function _reduced_mpcc_window_no_candidate_row(
    spec,
    solve_attempt::ReducedDCDFBAMPCCSolveAttemptResult,
    err::ReducedDCDFBAMPCCWindowNoCandidateError,
)::Dict{String, Any}
    metadata = solve_attempt.metadata
    row = Dict{String, Any}(
        column => missing for column in REDUCED_DCDFBA_MPCC_WINDOWED_CONTINUATION_COLUMNS
    )
    row["window_id"] = spec.window_id
    row["window_index"] = spec.window_index
    row["window_status"] = "failed"
    row["t0"] = spec.t0
    row["tfinal"] = spec.tfinal
    row["window_hours"] = spec.window_hours
    row["nfe"] = spec.nfe
    row["degree"] = spec.degree
    row["boundary_dt"] = spec.boundary_dt
    row["n_boundary_points"] = spec.nfe + 1
    row["n_collocation_points"] = spec.nfe * spec.degree
    row["linear_solver"] = get(metadata, "linear_solver", missing)
    row["ipopt_profile"] = get(metadata, "solve_attempt_ipopt_profile", missing)
    row["complementarity_mode"] = get(metadata, "complementarity_mode", missing)
    row["complementarity_tau"] = get(metadata, "complementarity_tau", missing)
    row["tau_schedule"] = get(metadata, "tau_schedule", missing)
    row["tau_stage_max_iters"] = get(metadata, "tau_stage_max_iters", missing)
    row["tau_continuation_selected_stage_index"] =
        get(metadata, "tau_continuation_selected_stage_index", missing)
    row["tau_continuation_selected_tau"] =
        get(metadata, "tau_continuation_selected_tau", missing)
    row["tau_continuation_selected_reason"] =
        get(metadata, "tau_continuation_selected_reason", missing)
    row["tau_continuation_selected_by_best_stage_fallback"] =
        get(metadata, "tau_continuation_selected_by_best_stage_fallback", missing)
    row["tau_continuation_attempted_final_tau"] =
        get(metadata, "tau_continuation_attempted_final_tau", missing)
    row["tau_continuation_polish_failed"] =
        get(metadata, "tau_continuation_polish_failed", missing)
    row["tau_continuation_stage_count"] =
        get(metadata, "tau_continuation_stage_count", missing)
    row["tau_continuation_completed"] =
        get(metadata, "tau_continuation_completed", missing)
    row["tau_continuation_final_residual_feasible"] =
        get(metadata, "tau_continuation_final_residual_feasible", missing)
    row["tau_continuation_final_tau_gate_pass"] =
        get(metadata, "tau_continuation_final_tau_gate_pass", missing)
    row["tau_continuation_blocking_stage"] =
        get(metadata, "tau_continuation_blocking_stage", missing)
    row["tau_continuation_blocking_reason"] =
        get(metadata, "tau_continuation_blocking_reason", missing)
    row["tau_continuation_stage_advance_count"] =
        get(metadata, "tau_continuation_stage_advance_count", missing)
    row["solver_call_performed"] = get(metadata, "solver_call_performed", missing)
    row["pre_solve_guard_required"] = get(metadata, "pre_solve_guard_required", missing)
    row["pre_solve_guard_passed"] = get(metadata, "pre_solve_guard_passed", missing)
    row["pre_solve_guard_failure_component"] =
        get(metadata, "pre_solve_guard_failure_component", missing)
    row["pre_solve_residual_thresholds_satisfied"] =
        get(metadata, "pre_solve_residual_thresholds_satisfied", missing)
    row["pre_solve_scaling_plan_ready_for_guarded_solve_attempt"] = get(
        metadata,
        "pre_solve_scaling_plan_ready_for_guarded_solve_attempt",
        missing,
    )
    row["pre_solve_scaling_blocking_warning_count"] =
        get(metadata, "pre_solve_scaling_blocking_warning_count", missing)
    row["pre_solve_scaling_review_warning_count"] =
        get(metadata, "pre_solve_scaling_review_warning_count", missing)
    row["pre_solve_warning_count"] = get(metadata, "pre_solve_warning_count", missing)
    row["pre_solve_first_warning"] = get(metadata, "pre_solve_first_warning", missing)
    row["guarded_solve_attempt_blocked"] =
        get(metadata, "guarded_solve_attempt_blocked", missing)
    row["solver_status"] = get(metadata, "solver_status", string(solve_attempt.smoke_result.status))
    row["primal_status"] = get(metadata, "primal_status", string(solve_attempt.smoke_result.primal_status))
    row["solve_elapsed_seconds"] =
        get(metadata, "solve_elapsed_seconds", solve_attempt.smoke_result.solve_elapsed_seconds)
    row["candidate_residual_feasible"] =
        get(metadata, "candidate_residual_feasible", false)
    row["candidate_iteration_limit_residual_feasible"] =
        get(metadata, "candidate_iteration_limit_residual_feasible", false)
    row["candidate_trajectory_ready"] = false
    row["candidate_allows_continuation"] = false
    row["continuation_acceptance_policy"] = missing
    row["continuation_acceptance_reason"] =
        get(metadata, "guarded_solve_attempt_blocked", false) === true ?
        "pre_solve_guard_blocked_no_candidate" :
        "solve_attempt_no_extracted_candidate"
    row["continuation_state_drift_gate_pass"] = false
    row["continuation_state_drift_gate_mode"] = "not_evaluated_no_candidate"
    row["iteration_limit_policy_accepted"] = false
    row["candidate_is_scientific_simulation"] = false
    row["residual_thresholds_satisfied"] =
        get(metadata, "residual_thresholds_satisfied", solve_attempt.residual_thresholds_satisfied)
    row["dominant_residual"] =
        get(metadata, "dominant_residual", get(metadata, "pre_solve_dominant_residual", missing))
    row["next_recommended_action"] =
        get(metadata, "guarded_solve_attempt_blocked", false) === true ?
        "inspect_pre_solve_blocking_residuals" :
        "inspect_no_candidate_solve_attempt"
    row["candidate_warning_count"] = get(metadata, "candidate_warning_count", missing)
    row["max_rhs_residual"] = get(metadata, "max_rhs_residual", missing)
    row["max_mass_balance_residual"] = get(metadata, "max_mass_balance_residual", missing)
    row["max_lower_bound_violation"] = get(metadata, "max_lower_bound_violation", missing)
    row["max_upper_bound_violation"] = get(metadata, "max_upper_bound_violation", missing)
    row["max_stationarity_residual"] = get(metadata, "max_stationarity_residual", missing)
    row["max_lower_complementarity_residual"] =
        get(metadata, "max_lower_complementarity_residual", missing)
    row["max_upper_complementarity_residual"] =
        get(metadata, "max_upper_complementarity_residual", missing)
    row["max_lower_complementarity_product"] =
        get(metadata, "max_lower_complementarity_product", missing)
    row["max_upper_complementarity_product"] =
        get(metadata, "max_upper_complementarity_product", missing)
    row["max_complementarity_tau_violation"] =
        get(metadata, "max_complementarity_tau_violation", missing)
    row["max_complementarity_tau_violation_raw"] =
        get(metadata, "max_complementarity_tau_violation_raw", missing)
    row["complementarity_tau_gate_tolerance"] =
        get(metadata, "complementarity_tau_gate_tolerance", missing)
    row["complementarity_tau_gate_tolerance_source"] =
        get(metadata, "complementarity_tau_gate_tolerance_source", missing)
    row["complementarity_tau_gate_pass"] =
        get(metadata, "complementarity_tau_gate_pass", missing)
    row["cross_window_flux_dual_start_applied"] =
        get(metadata, "cross_window_flux_dual_start_applied", missing)
    row["cross_window_flux_dual_start_policy"] =
        get(metadata, "cross_window_flux_dual_start_policy", missing)
    row["cross_window_flux_dual_start_source"] =
        get(metadata, "cross_window_flux_dual_start_source", missing)
    row["cross_window_flux_dual_start_source_stage_index"] =
        get(metadata, "cross_window_flux_dual_start_source_stage_index", missing)
    row["cross_window_flux_dual_start_source_tau"] =
        get(metadata, "cross_window_flux_dual_start_source_tau", missing)
    row["cross_window_flux_dual_start_source_solver_status"] =
        get(metadata, "cross_window_flux_dual_start_source_solver_status", missing)
    row["cross_window_flux_dual_start_source_residual_feasible"] =
        get(metadata, "cross_window_flux_dual_start_source_residual_feasible", missing)
    row["initial_state_source"] =
        spec.window_index == 1 ? "provided_y0" : "previous_candidate_final_boundary_state"
    row["next_initial_state_source"] = "not_available"
    row["full_dfba_cold_reference_deferred"] = true
    row["reduced_full_equivalence_claimed"] = false
    row["persistent_lp_baseline_used"] = false
    row["hsl_required"] = false
    row["ma57_required"] = false
    row["indices_reacciones_used"] = false
    row["r0001_used_as_oxygen"] = false
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_window_error_row(spec, err)::Dict{String, Any}
    row = Dict{String, Any}(
        column => missing for column in REDUCED_DCDFBA_MPCC_WINDOWED_CONTINUATION_COLUMNS
    )
    row["window_id"] = spec.window_id
    row["window_index"] = spec.window_index
    row["window_status"] = "failed"
    row["t0"] = spec.t0
    row["tfinal"] = spec.tfinal
    row["window_hours"] = spec.window_hours
    row["nfe"] = spec.nfe
    row["degree"] = spec.degree
    row["boundary_dt"] = spec.boundary_dt
    row["n_boundary_points"] = spec.nfe + 1
    row["n_collocation_points"] = spec.nfe * spec.degree
    row["candidate_allows_continuation"] = false
    row["continuation_acceptance_policy"] = missing
    row["continuation_acceptance_reason"] = "failed_window"
    row["continuation_state_drift_gate_pass"] = false
    row["continuation_state_drift_max_relative_rmse_threshold"] = missing
    row["iteration_limit_policy_accepted"] = false
    row["initial_state_source"] =
        spec.window_index == 1 ? "provided_y0" : "previous_candidate_final_boundary_state"
    row["next_initial_state_source"] = "not_available"
    row["full_dfba_cold_reference_deferred"] = true
    row["reduced_full_equivalence_claimed"] = false
    row["persistent_lp_baseline_used"] = false
    row["hsl_required"] = false
    row["ma57_required"] = false
    row["indices_reacciones_used"] = false
    row["r0001_used_as_oxygen"] = false
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_window_result(
    rows::Vector{Dict{String, Any}},
    comparisons::Vector{ReducedDCDFBAMPCCSequentialComparisonResult};
    sequential_reference = nothing,
    n_requested_windows::Int = length(rows),
    window_hours = missing,
    nfe_per_window = missing,
    degree = missing,
    ipopt_profile = missing,
    linear_solver = missing,
    complementarity_mode = missing,
    complementarity_tau = missing,
    complementarity_tau_gate_tol = missing,
    tau_schedule = missing,
    tau_stage_max_iters = missing,
    tau_final_retry_max_iter = missing,
    allow_coarse_tau_fallback = false,
    propagate_flux_dual_starts = false,
    initial_state_propagation_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_CANDIDATE,
    reference_source::AbstractString = "unknown",
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_abs_difference_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_ABS_DIFFERENCE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
)::ReducedDCDFBAMPCCWindowedContinuationResult
    table = _reduced_mpcc_window_table(rows)
    boundary_candidate =
        isempty(comparisons) ? nothing : _reduced_mpcc_window_boundary_candidate(comparisons, rows)
    reference = sequential_reference
    if reference === nothing && !isempty(comparisons)
        reference = _reduced_mpcc_window_sequential_reference(comparisons, rows)
    end
    state_metrics_table, aligned_timeseries_table =
        _reduced_mpcc_window_global_tables(reference, boundary_candidate)
    metadata = _reduced_mpcc_window_metadata(
        rows,
        comparisons,
        reference,
        boundary_candidate,
        state_metrics_table;
        n_requested_windows = n_requested_windows,
        window_hours = window_hours,
        nfe_per_window = nfe_per_window,
        degree = degree,
        ipopt_profile = ipopt_profile,
        linear_solver = linear_solver,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        complementarity_tau_gate_tol = complementarity_tau_gate_tol,
        tau_schedule = tau_schedule,
        tau_stage_max_iters = tau_stage_max_iters,
        tau_final_retry_max_iter = tau_final_retry_max_iter,
        allow_coarse_tau_fallback = allow_coarse_tau_fallback,
        propagate_flux_dual_starts = propagate_flux_dual_starts,
        initial_state_propagation_policy = initial_state_propagation_policy,
        reference_source = reference_source,
        continuation_acceptance_policy = continuation_acceptance_policy,
        continuation_state_abs_difference_threshold =
            continuation_state_abs_difference_threshold,
        continuation_state_relative_rmse_threshold =
            continuation_state_relative_rmse_threshold,
    )
    return ReducedDCDFBAMPCCWindowedContinuationResult(
        table,
        comparisons,
        reference,
        boundary_candidate,
        state_metrics_table,
        aligned_timeseries_table,
        metadata,
    )
end

function _reduced_mpcc_window_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_window_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_WINDOWED_CONTINUATION_COLUMNS
        )...,
    )
end

function _reduced_mpcc_window_boundary_candidate(
    comparisons::Vector{ReducedDCDFBAMPCCSequentialComparisonResult},
    rows::Vector{Dict{String, Any}},
)::SimulationResult
    results = [comparison.trajectory_candidate.boundary_result for comparison in comparisons]
    metadata = _reduced_mpcc_window_concatenated_metadata(
        results,
        rows,
        "reduced_dcdfba_mpcc_windowed_boundary_candidate",
        "windowed_mpcc_boundary_candidate",
    )
    metadata["trajectory_candidate_ready"] =
        all(row -> get(row, "candidate_trajectory_ready", false) === true, rows)
    metadata["trajectory_candidate_is_scientific_simulation"] = false
    metadata["trajectory_candidate_is_validated_simulation"] = false
    metadata["trajectory_candidate_solved_trajectory_claimed"] = false
    metadata["is_scientific_simulation"] = false
    metadata["solved_trajectory_claimed"] = false
    return _reduced_mpcc_window_concatenate_results(results, metadata)
end

function _reduced_mpcc_window_sequential_reference(
    comparisons::Vector{ReducedDCDFBAMPCCSequentialComparisonResult},
    rows::Vector{Dict{String, Any}},
)::SimulationResult
    results = [comparison.sequential_result for comparison in comparisons]
    metadata = _reduced_mpcc_window_concatenated_metadata(
        results,
        rows,
        "reduced_dcdfba_mpcc_windowed_local_sequential_reference",
        "concatenated_window_reduced_sequential_dfba",
    )
    metadata["is_scientific_baseline"] = false
    metadata["is_scientific_simulation"] = false
    metadata["reference_is_full_dfba_cold"] = false
    return _reduced_mpcc_window_concatenate_results(results, metadata)
end

function _reduced_mpcc_window_concatenated_metadata(
    results::Vector{SimulationResult},
    rows::Vector{Dict{String, Any}},
    model_id::AbstractString,
    result_kind::AbstractString,
)::Dict{String, Any}
    first_result = first(results)
    return Dict{String, Any}(
        "model_id" => String(model_id),
        "model_scope" => "reduced",
        "result_kind" => String(result_kind),
        "retcode" => "WINDOWED_DIAGNOSTIC",
        "termination_reason" => "windowed_continuation_diagnostic_only",
        "state_names" => _state_names(first_result),
        "n_windows" => length(results),
        "window_ids" => [row["window_id"] for row in rows if get(row, "window_status", "") == "completed"],
        "min_state_value" => minimum(minimum(result.states) for result in results),
        "has_negative_saved_states" => any(any(result.states .< 0.0) for result in results),
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
    )
end

function _reduced_mpcc_window_concatenate_results(
    results::Vector{SimulationResult},
    metadata::Dict{String, Any},
)::SimulationResult
    isempty(results) && throw(
        ArgumentError("Reduced MPCC windowed continuation cannot concatenate empty results."),
    )
    state_names = _state_names(first(results))
    times = Float64[]
    state_columns = Vector{Float64}[]
    for (result_index, result) in enumerate(results)
        _state_names(result) == state_names || throw(
            ArgumentError("Reduced MPCC windowed continuation requires matching state names across windows."),
        )
        size(result.states, 1) == length(state_names) || throw(
            ArgumentError("Reduced MPCC windowed continuation state dimension does not match state names."),
        )
        if result_index > 1
            previous_time = last(times)
            isapprox(first(result.time), previous_time; atol = 1.0e-10, rtol = 0.0) || throw(
                ArgumentError(
                    "Reduced MPCC windowed continuation requires continuous window boundary times. " *
                    "Got previous=$(previous_time) and next=$(first(result.time)).",
                ),
            )
        end
        first_column = result_index == 1 ? 1 : 2
        for column in first_column:length(result.time)
            push!(times, Float64(result.time[column]))
            push!(state_columns, Float64.(result.states[:, column]))
        end
    end
    states = hcat(state_columns...)
    metadata["initial_time"] = first(times)
    metadata["final_time"] = last(times)
    metadata["n_saved_points"] = length(times)
    metadata["n_states"] = size(states, 1)
    metadata["min_state_value"] = minimum(states)
    metadata["has_negative_saved_states"] = any(states .< 0.0)
    return SimulationResult(times, states; metadata = metadata)
end

function _reduced_mpcc_window_global_tables(
    sequential_reference,
    boundary_candidate,
)::Tuple{DataFrame, DataFrame}
    if sequential_reference === nothing || boundary_candidate === nothing
        return (
            _reduced_mpcc_window_empty_state_metrics_table(),
            _reduced_mpcc_window_empty_aligned_timeseries_table(),
        )
    end
    _reduced_mpcc_seq_times_match(sequential_reference.time, boundary_candidate.time) || throw(
        ArgumentError(
            "Reduced MPCC windowed continuation requires reference and boundary candidate times to match. " *
            "Got reference=$(sequential_reference.time) and candidate=$(boundary_candidate.time).",
        ),
    )
    state_names = _state_names(sequential_reference)
    _state_names(boundary_candidate) == state_names || throw(
        ArgumentError("Reduced MPCC windowed continuation requires matching state names for global comparison."),
    )
    metric_names = vcat(state_names, "total_sugar")
    return (
        _reduced_mpcc_seq_state_metrics_table(sequential_reference, boundary_candidate, metric_names),
        _reduced_mpcc_seq_timeseries_table(sequential_reference, boundary_candidate, metric_names),
    )
end

function _reduced_mpcc_window_empty_state_metrics_table()::DataFrame
    return DataFrame(
        (column => Any[] for column in REDUCED_DCDFBA_MPCC_SEQUENTIAL_STATE_METRIC_COLUMNS)...,
    )
end

function _reduced_mpcc_window_empty_aligned_timeseries_table()::DataFrame
    return DataFrame("time" => Float64[])
end

function _reduced_mpcc_window_metadata(
    rows::Vector{Dict{String, Any}},
    comparisons::Vector{ReducedDCDFBAMPCCSequentialComparisonResult},
    sequential_reference,
    boundary_candidate,
    state_metrics_table::DataFrame;
    n_requested_windows::Int,
    window_hours,
    nfe_per_window,
    degree,
    ipopt_profile,
    linear_solver,
    complementarity_mode,
    complementarity_tau,
    complementarity_tau_gate_tol,
    tau_schedule,
    tau_stage_max_iters,
    tau_final_retry_max_iter,
    allow_coarse_tau_fallback,
    propagate_flux_dual_starts,
    initial_state_propagation_policy::AbstractString,
    reference_source::AbstractString,
    continuation_acceptance_policy::AbstractString,
    continuation_state_abs_difference_threshold::Real,
    continuation_state_relative_rmse_threshold::Real,
)::Dict{String, Any}
    completed_count = count(row -> get(row, "window_status", "") == "completed", rows)
    failed_count = count(row -> get(row, "window_status", "") == "failed", rows)
    all_residual_feasible =
        completed_count > 0 &&
        all(row -> get(row, "candidate_residual_feasible", false) === true,
            row for row in rows if get(row, "window_status", "") == "completed")
    all_allows_continuation =
        completed_count > 0 &&
        all(row -> get(row, "candidate_allows_continuation", false) === true,
            row for row in rows if get(row, "window_status", "") == "completed")
    all_trajectory_ready =
        completed_count > 0 &&
        all(row -> get(row, "candidate_trajectory_ready", false) === true,
            row for row in rows if get(row, "window_status", "") == "completed")
    continuation_completed =
        completed_count == n_requested_windows && failed_count == 0 && all_allows_continuation
    total_horizon_reached =
        boundary_candidate === nothing ? missing : last(boundary_candidate.time) - first(boundary_candidate.time)
    return Dict{String, Any}(
        "windowed_continuation_type" => REDUCED_DCDFBA_MPCC_WINDOWED_CONTINUATION_TYPE,
        "n_requested_windows" => n_requested_windows,
        "n_rows" => length(rows),
        "n_completed_windows" => completed_count,
        "n_failed_windows" => failed_count,
        "window_status_counts" => _reduced_mpcc_window_value_counts(rows, "window_status"),
        "solver_status_counts" => _reduced_mpcc_window_value_counts(rows, "solver_status"),
        "recommended_action_counts" =>
            _reduced_mpcc_window_value_counts(rows, "next_recommended_action"),
        "window_hours" => window_hours,
        "nfe_per_window" => nfe_per_window,
        "degree" => degree,
        "ipopt_profile" => ipopt_profile,
        "ipopt_profile_env" => REDUCED_DCDFBA_MPCC_IPOPT_PROFILE_ENV,
        "linear_solver" => linear_solver,
        "linear_solver_env" => IPOPT_LINEAR_SOLVER_ENV,
        "ipopt_warm_start_init_point" => ipopt_warm_start_init_point_from_env(),
        "ipopt_warm_start_init_point_env" => IPOPT_WARM_START_INIT_POINT_ENV,
        "ipopt_max_wall_time_seconds" =>
            ipopt_max_wall_time_from_env() === nothing ?
            missing :
            ipopt_max_wall_time_from_env(),
        "ipopt_max_wall_time_env" => IPOPT_MAX_WALL_TIME_ENV,
        "complementarity_mode" => complementarity_mode,
        "complementarity_tau" => complementarity_tau,
        "complementarity_tau_gate_tolerance_override" =>
            complementarity_tau_gate_tol === nothing ? missing : complementarity_tau_gate_tol,
        "complementarity_tau_gate_tolerance_env" =>
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_TAU_GATE_TOL_ENV,
        "complementarity_mode_env" => REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_ENV,
        "complementarity_tau_env" => REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_TAU_ENV,
        "tau_schedule" => tau_schedule,
        "tau_schedule_env" => REDUCED_DCDFBA_MPCC_TAU_SCHEDULE_ENV,
        "tau_stage_max_iters" =>
            (tau_stage_max_iters === nothing || tau_stage_max_iters === missing) ?
            missing : copy(tau_stage_max_iters),
        "tau_stage_max_iters_env" => REDUCED_DCDFBA_MPCC_TAU_STAGE_MAX_ITERS_ENV,
        "tau_stage_max_iters_label" =>
            _reduced_dcdfba_mpcc_tau_stage_max_iters_label(tau_stage_max_iters),
        "tau_final_retry_max_iter" =>
            (tau_final_retry_max_iter === nothing || tau_final_retry_max_iter === missing) ?
            missing : Int(tau_final_retry_max_iter),
        "tau_final_retry_max_iter_env" =>
            REDUCED_DCDFBA_MPCC_TAU_FINAL_RETRY_MAX_ITER_ENV,
        "tau_continuation_allow_coarse_tau_fallback" =>
            allow_coarse_tau_fallback === true,
        "cross_window_flux_dual_start_enabled" => propagate_flux_dual_starts,
        "window_initial_state_propagation_policy" => initial_state_propagation_policy,
        "cross_window_flux_dual_start_applied_window_count" => count(
            row -> get(row, "cross_window_flux_dual_start_applied", false) === true,
            rows,
        ),
        "cross_window_flux_dual_start_policy_counts" =>
            _reduced_mpcc_window_value_counts(rows, "cross_window_flux_dual_start_policy"),
        "tau_continuation_completed_window_count" => count(
            row -> get(row, "tau_continuation_completed", false) === true,
            rows,
        ),
        "tau_continuation_final_tau_gate_pass_window_count" => count(
            row -> get(row, "tau_continuation_final_tau_gate_pass", false) === true,
            rows,
        ),
        "tau_continuation_blocking_reason_counts" =>
            _reduced_mpcc_window_value_counts(rows, "tau_continuation_blocking_reason"),
        "tau_continuation_selected_reason_counts" =>
            _reduced_mpcc_window_value_counts(rows, "tau_continuation_selected_reason"),
        "tau_continuation_coarse_tau_fallback_window_count" => count(
            row -> get(row, "tau_continuation_coarse_tau_fallback_applied", false) === true,
            rows,
        ),
        "tau_continuation_polish_failed_window_count" => count(
            row -> get(row, "tau_continuation_polish_failed", false) === true,
            rows,
        ),
        "tau_continuation_final_retry_window_count" => count(
            row -> get(row, "tau_continuation_final_retry_performed", false) === true,
            rows,
        ),
        "tau_continuation_stage_advance_count" =>
            _reduced_mpcc_window_sum_finite(rows, "tau_continuation_stage_advance_count"),
        "boundary_dt" => _reduced_mpcc_window_first_nonmissing(rows, "boundary_dt"),
        "continuation_acceptance_policy" =>
            String(continuation_acceptance_policy),
        "continuation_state_drift_gate_mode" => "per_state_abs_or_relative",
        "continuation_state_abs_difference_threshold" =>
            Float64(continuation_state_abs_difference_threshold),
        "continuation_state_relative_rmse_threshold" =>
            Float64(continuation_state_relative_rmse_threshold),
        "continuation_state_drift_gate_enabled" =>
            String(continuation_acceptance_policy) ==
            REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_ITERATION_LIMIT_STATE_DRIFT,
        "continuation_policy_reason_counts" =>
            _reduced_mpcc_window_value_counts(rows, "continuation_acceptance_reason"),
        "continuation_policy_rejected_window_count" => count(
            row -> get(row, "window_status", "") == "completed" &&
                   get(row, "candidate_allows_continuation", false) !== true,
            rows,
        ),
        "iteration_limit_policy_accepted_window_count" => count(
            row -> get(row, "iteration_limit_policy_accepted", false) === true,
            rows,
        ),
        "state_drift_gate_pass_window_count" => count(
            row -> get(row, "continuation_state_drift_gate_pass", false) === true,
            rows,
        ),
        "n_total_boundary_points" =>
            boundary_candidate === nothing ? 0 : length(boundary_candidate.time),
        "n_total_collocation_points" =>
            sum(
                Int(row["n_collocation_points"]) for row in rows if
                _reduced_mpcc_window_isfinite_number(get(row, "n_collocation_points", missing))
            ),
        "total_horizon_reached" => total_horizon_reached,
        "continuation_completed" => continuation_completed,
        "all_completed_windows_residual_feasible" => all_residual_feasible,
        "all_completed_windows_allow_continuation" => all_allows_continuation,
        "all_completed_windows_trajectory_ready" => all_trajectory_ready,
        "residual_feasible_window_count" =>
            count(row -> get(row, "candidate_residual_feasible", false) === true, rows),
        "trajectory_ready_window_count" =>
            count(row -> get(row, "candidate_trajectory_ready", false) === true, rows),
        "iteration_limit_residual_feasible_window_count" => count(
            row -> get(row, "candidate_iteration_limit_residual_feasible", false) === true,
            rows,
        ),
        "first_failed_window_id" => _reduced_mpcc_window_first_failed_value(rows, "window_id"),
        "first_noncontinuable_window_id" =>
            _reduced_mpcc_window_first_noncontinuable_value(rows, "window_id"),
        "window_comparison_count" => length(comparisons),
        "sequential_reference_available" => sequential_reference !== nothing,
        "sequential_reference_source" => String(reference_source),
        "boundary_candidate_available" => boundary_candidate !== nothing,
        "global_state_metrics_available" => nrow(state_metrics_table) > 0,
        "global_max_state_abs_difference" =>
            _reduced_mpcc_window_metric_max(state_metrics_table, "max_abs_difference"),
        "global_max_state_rmse" =>
            _reduced_mpcc_window_metric_max(state_metrics_table, "rmse"),
        "global_max_state_relative_rmse" =>
            _reduced_mpcc_window_metric_max(state_metrics_table, "relative_rmse"),
        "global_state_drift_scale_gate_pass" =>
            _reduced_mpcc_window_state_scale_drift_pass(
                state_metrics_table,
                continuation_state_abs_difference_threshold,
                continuation_state_relative_rmse_threshold,
            ),
        "global_final_biomass_difference" =>
            _reduced_mpcc_window_metric_final_difference(state_metrics_table, "biomass"),
        "global_final_total_sugar_difference" =>
            _reduced_mpcc_window_metric_final_difference(state_metrics_table, "total_sugar"),
        "outputs_written" => false,
        "windowed_continuation_is_scientific_simulation" => false,
        "windowed_continuation_is_validated_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Windowed continuation of reduced MPCC solve attempts; diagnostic only and not a solved scientific simulation.",
    )
end

function _reduced_mpcc_window_validate_continuation_policy(
    policy::AbstractString,
)::String
    normalized = lowercase(strip(String(policy)))
    normalized in (
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_TRAJECTORY_READY,
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_ITERATION_LIMIT_STATE_DRIFT,
    ) || throw(
        ArgumentError(
            "Reduced MPCC windowed continuation acceptance policy must be one of " *
            "$(REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE), " *
            "$(REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_TRAJECTORY_READY), " *
            "$(REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_ITERATION_LIMIT_STATE_DRIFT).",
        ),
    )
    return normalized
end

function _reduced_mpcc_window_validate_initial_state_propagation_policy(
    policy::AbstractString,
)::String
    normalized = lowercase(strip(String(policy)))
    normalized == "sequential" &&
        return REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_SEQUENTIAL
    normalized in (
        REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_CANDIDATE,
        REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_SEQUENTIAL,
    ) || throw(
        ArgumentError(
            "Reduced MPCC window initial-state propagation policy must be " *
            "$(REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_CANDIDATE) or " *
            "$(REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_SEQUENTIAL). Got: $policy",
        ),
    )
    return normalized
end

function _reduced_mpcc_window_validate_state_relative_rmse_threshold(
    threshold::Real,
)::Float64
    value = Float64(threshold)
    isfinite(value) && value >= 0.0 || throw(
        ArgumentError(
            "Reduced MPCC windowed continuation state relative RMSE threshold must be finite and nonnegative.",
        ),
    )
    return value
end

function _reduced_mpcc_window_continuation_decision(
    base::Dict{String, Any},
    state_metrics_table::DataFrame,
    finite_final_state::Bool;
    continuation_acceptance_policy::AbstractString,
    continuation_state_abs_difference_threshold::Real,
    continuation_state_relative_rmse_threshold::Real,
    state_drift_blocks_continuation::Bool = true,
)
    policy = _reduced_mpcc_window_validate_continuation_policy(
        continuation_acceptance_policy,
    )
    threshold =
        _reduced_mpcc_window_validate_state_relative_rmse_threshold(
            continuation_state_relative_rmse_threshold,
        )
    abs_threshold =
        _reduced_mpcc_window_validate_state_abs_difference_threshold(
            continuation_state_abs_difference_threshold,
        )
    residual_feasible =
        get(base, "candidate_residual_feasible", false) === true
    trajectory_ready =
        get(base, "candidate_trajectory_ready", false) === true
    iteration_limit_residual_feasible =
        get(base, "candidate_iteration_limit_residual_feasible", false) === true
    state_drift_pass =
        _reduced_mpcc_window_state_scale_drift_pass(
            state_metrics_table,
            abs_threshold,
            threshold,
        )

    if !finite_final_state
        return (
            allows_continuation = false,
            reason = "nonfinite_final_state",
            state_drift_gate_pass = state_drift_pass,
            iteration_limit_policy_accepted = false,
        )
    elseif policy == REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE
        if residual_feasible
            return (
                allows_continuation = true,
                reason = trajectory_ready ? "trajectory_ready_residual_feasible" :
                         iteration_limit_residual_feasible ?
                         "iteration_limit_residual_feasible" :
                         "residual_feasible_candidate",
                state_drift_gate_pass = state_drift_pass,
                iteration_limit_policy_accepted = iteration_limit_residual_feasible &&
                                                  !trajectory_ready,
            )
        else
            return (
                allows_continuation = false,
                reason = "residual_feasibility_failed",
                state_drift_gate_pass = state_drift_pass,
                iteration_limit_policy_accepted = false,
            )
        end
    elseif policy == REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_TRAJECTORY_READY
        if trajectory_ready && residual_feasible
            return (
                allows_continuation = true,
                reason = "trajectory_ready",
                state_drift_gate_pass = state_drift_pass,
                iteration_limit_policy_accepted = false,
            )
        else
            return (
                allows_continuation = false,
                reason = trajectory_ready ? "residual_feasibility_failed" :
                         "trajectory_ready_required",
                state_drift_gate_pass = state_drift_pass,
                iteration_limit_policy_accepted = false,
            )
        end
    else
        drift_allowed = state_drift_pass || !state_drift_blocks_continuation
        status_allowed =
            trajectory_ready ||
            iteration_limit_residual_feasible ||
            (!state_drift_blocks_continuation && residual_feasible)
        candidate_allowed =
            residual_feasible &&
            drift_allowed &&
            status_allowed
        reason = if candidate_allowed && trajectory_ready
            state_drift_pass ? "trajectory_ready_state_drift_pass" :
            "trajectory_ready_state_drift_review_only"
        elseif candidate_allowed && iteration_limit_residual_feasible
            state_drift_pass ? "iteration_limit_residual_feasible_state_drift_pass" :
            "iteration_limit_residual_feasible_state_drift_review_only"
        elseif candidate_allowed
            state_drift_pass ? "residual_feasible_status_review_only" :
            "residual_feasible_state_drift_status_review_only"
        elseif !residual_feasible
            "residual_feasibility_failed"
        elseif state_drift_blocks_continuation && !state_drift_pass
            "state_drift_gate_failed"
        else
            "trajectory_ready_or_iteration_limit_required"
        end
        return (
            allows_continuation = candidate_allowed,
            reason = reason,
            state_drift_gate_pass = state_drift_pass,
            iteration_limit_policy_accepted = candidate_allowed &&
                                              iteration_limit_residual_feasible &&
                                              !trajectory_ready,
        )
    end
end

function _reduced_mpcc_window_validate_state_abs_difference_threshold(value::Real)::Float64
    converted = Float64(value)
    isfinite(converted) && converted >= 0.0 || throw(
        ArgumentError(
            "Reduced MPCC windowed continuation state absolute-difference threshold must be finite and nonnegative.",
        ),
    )
    return converted
end

function _reduced_mpcc_window_state_relative_rmse_pass(value, threshold::Real)::Bool
    _reduced_mpcc_window_isfinite_number(value) || return false
    return Float64(value) <= Float64(threshold)
end

function _reduced_mpcc_window_state_abs_difference_pass(value, threshold::Real)::Bool
    _reduced_mpcc_window_isfinite_number(value) || return false
    return abs(Float64(value)) <= Float64(threshold)
end

function _reduced_mpcc_window_state_scale_drift_pass(
    state_metrics_table::DataFrame,
    abs_threshold::Real,
    relative_threshold::Real,
)::Bool
    nrow(state_metrics_table) > 0 || return false
    for row in eachrow(state_metrics_table)
        abs_pass = _reduced_mpcc_window_state_abs_difference_pass(
            get(row, "max_abs_difference", missing),
            abs_threshold,
        )
        relative_pass = _reduced_mpcc_window_state_relative_rmse_pass(
            get(row, "relative_rmse", missing),
            relative_threshold,
        )
        (abs_pass || relative_pass) || return false
    end
    return true
end

function _reduced_mpcc_window_allows_continuation(
    row::Dict{String, Any},
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
)::Bool
    return get(row, "candidate_allows_continuation", false) === true &&
           _reduced_mpcc_window_has_finite_final_state(comparison)
end

function _reduced_mpcc_window_has_finite_final_state(
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
)::Bool
    final_state = comparison.trajectory_candidate.boundary_result.states[:, end]
    return all(isfinite, final_state)
end

function _reduced_mpcc_window_metric_max(table::DataFrame, column::AbstractString)
    nrow(table) == 0 && return missing
    values = Float64[
        Float64(value) for value in table[!, String(column)] if
        _reduced_mpcc_window_isfinite_number(value)
    ]
    isempty(values) && return missing
    return maximum(values)
end

function _reduced_mpcc_window_metric_final_difference(
    table::DataFrame,
    state_name::AbstractString,
)
    nrow(table) == 0 && return missing
    index = findfirst(==(String(state_name)), String.(table[!, "state_name"]))
    index === nothing && return missing
    return table[index, "final_difference_mpcc_minus_sequential"]
end

function _reduced_mpcc_window_first_failed_value(
    rows::Vector{Dict{String, Any}},
    key::AbstractString,
)
    row = findfirst(row -> get(row, "window_status", "") == "failed", rows)
    row === nothing && return missing
    return get(rows[row], String(key), missing)
end

function _reduced_mpcc_window_first_noncontinuable_value(
    rows::Vector{Dict{String, Any}},
    key::AbstractString,
)
    row = findfirst(
        row -> get(row, "window_status", "") == "completed" &&
               get(row, "candidate_allows_continuation", false) !== true,
        rows,
    )
    row === nothing && return missing
    return get(rows[row], String(key), missing)
end

function _reduced_mpcc_window_first_nonmissing(rows::Vector{Dict{String, Any}}, key::AbstractString)
    for row in rows
        value = get(row, String(key), missing)
        value === missing && continue
        return value
    end
    return missing
end

function _reduced_mpcc_window_sum_finite(rows::Vector{Dict{String, Any}}, key::AbstractString)
    values = Float64[]
    for row in rows
        value = get(row, String(key), missing)
        _reduced_mpcc_window_isfinite_number(value) || continue
        push!(values, Float64(value))
    end
    isempty(values) && return missing
    return sum(values)
end

function _reduced_mpcc_window_value_counts(rows::Vector{Dict{String, Any}}, key::AbstractString)
    counts = Dict{String, Int}()
    for row in rows
        value = get(row, String(key), missing)
        value === missing && continue
        label = string(value)
        counts[label] = get(counts, label, 0) + 1
    end
    return counts
end

function _reduced_mpcc_window_id(index::Int)::String
    return "window_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_window_float_or_missing(value)
    value === missing && return missing
    value === nothing && return missing
    return try
        converted = Float64(value)
        isfinite(converted) ? converted : missing
    catch
        missing
    end
end

function _reduced_mpcc_window_int_or_missing(value)
    value === missing && return missing
    value === nothing && return missing
    return try
        Int(value)
    catch
        missing
    end
end

function _reduced_mpcc_window_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_window_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
