const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_RETRY_TYPE =
    "reduced_dcdfba_mpcc_global_polish_iteration_limit_retry"

const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_RETRY_COLUMNS = [
    "global_polish_retry_case_id",
    "base_global_polish_case_id",
    "base_case_index",
    "target_horizon",
    "global_horizon",
    "global_nfe",
    "base_global_ipopt_max_iter",
    "base_global_polish_traffic_light",
    "base_solver_status",
    "base_candidate_residual_feasible",
    "base_candidate_trajectory_ready",
    "base_iteration_limit_residual_feasible",
    "base_max_mass_balance_residual",
    "base_max_state_relative_rmse",
    "base_solve_elapsed_seconds",
    "retry_attempt_index",
    "retry_ipopt_max_iter",
    "retry_status",
    "retry_global_polish_traffic_light",
    "retry_recovered",
    "retry_solver_status",
    "retry_primal_status",
    "retry_candidate_residual_feasible",
    "retry_candidate_trajectory_ready",
    "retry_iteration_limit_residual_feasible",
    "retry_max_mass_balance_residual",
    "retry_max_state_relative_rmse",
    "retry_solve_elapsed_seconds",
    "retry_recommended_next_action",
    "stop_on_green",
    "outputs_written",
    "retry_is_scientific_simulation",
    "solved_trajectory_claimed",
    "first_mpcc_target",
    "full_model_kkt_deferred",
    "dfvb_kkt_deferred",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCGlobalPolishRetryResult

Selective retry diagnostics for reduced MPCC global-polish cases that reached
finite residual-feasible candidates but stopped at `ITERATION_LIMIT`. The
retry reuses the already-built reduced windowed/cascade source continuation as
start values; it does not rerun the whole horizon grid.
"""
struct ReducedDCDFBAMPCCGlobalPolishRetryResult
    base_sweep::ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult
    retry_table::DataFrame
    retry_results::Vector{ReducedDCDFBAMPCCGlobalPolishResult}
    metadata::Dict{String, Any}
end

"""
    retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(model, reaction_map, base_sweep; kwargs...)

Retry only residual-feasible reduced MPCC global-polish cases that ended with
`ITERATION_LIMIT`. The base sweep supplies the source continuations and start
values; no full-model or DFVB KKT path is touched.
"""
function retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    base_sweep::ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult;
    retry_ipopt_max_iter_values = [1000],
    retry_policy::AbstractString = "residual_feasible_iteration_limit",
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    optimizer = nothing,
    require_pre_solve_ready::Bool = false,
    silent::Bool = true,
    stop_on_green::Bool = true,
    continue_on_error::Bool = true,
    retry_callback = nothing,
)::ReducedDCDFBAMPCCGlobalPolishRetryResult
    return retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
        base_sweep;
        retry_ipopt_max_iter_values = retry_ipopt_max_iter_values,
        retry_policy = retry_policy,
        stop_on_green = stop_on_green,
        continue_on_error = continue_on_error,
        retry_callback = retry_callback,
        retry_runner = function (base_result, retry_ipopt_max_iter, _, _)
            return polish_reduced_dcdfba_mpcc_windowed_candidate(
                model,
                reaction_map,
                base_result.source_continuation;
                residual_thresholds = residual_thresholds,
                optimizer = optimizer,
                ipopt_max_iter = retry_ipopt_max_iter,
                require_pre_solve_ready = require_pre_solve_ready,
                silent = silent,
            )
        end,
    )
end

"""
    retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(base_sweep; retry_runner, kwargs...)

Deterministic retry driver for tests and in-memory diagnostics. `retry_runner`
is called only for base cases selected by the retry policy and must return a
`ReducedDCDFBAMPCCGlobalPolishResult`.
"""
function retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
    base_sweep::ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult;
    retry_ipopt_max_iter_values = [1000],
    retry_policy::AbstractString = "residual_feasible_iteration_limit",
    retry_runner = nothing,
    stop_on_green::Bool = true,
    continue_on_error::Bool = true,
    retry_callback = nothing,
)::ReducedDCDFBAMPCCGlobalPolishRetryResult
    retry_runner === nothing && throw(
        ArgumentError("Reduced MPCC global-polish retry requires a retry_runner or model/reaction_map."),
    )
    retry_iters =
        _reduced_mpcc_global_polish_retry_validate_iters(retry_ipopt_max_iter_values)
    policy = _reduced_mpcc_global_polish_retry_validate_policy(retry_policy)
    base_entries = _reduced_mpcc_global_polish_retry_base_entries(base_sweep)
    retryable_entries = [
        entry for entry in base_entries if
        _reduced_mpcc_global_polish_retry_base_case_retryable(entry.row, policy)
    ]

    rows = Dict{String, Any}[]
    retry_results = ReducedDCDFBAMPCCGlobalPolishResult[]
    retry_attempt_index = 0

    for entry in retryable_entries
        case_recovered = false
        for retry_iter in retry_iters
            retry_attempt_index += 1
            row = try
                retry_result = retry_runner(
                    entry.result,
                    retry_iter,
                    retry_attempt_index,
                    entry.row,
                )
                push!(retry_results, retry_result)
                retry_row = _reduced_mpcc_global_polish_retry_row(
                    entry.row,
                    retry_result,
                    retry_attempt_index,
                    retry_iter,
                    stop_on_green,
                )
                case_recovered =
                    get(retry_row, "retry_global_polish_traffic_light", missing) ==
                    "green"
                retry_row
            catch err
                continue_on_error || rethrow()
                _reduced_mpcc_global_polish_retry_error_row(
                    entry.row,
                    retry_attempt_index,
                    retry_iter,
                    stop_on_green,
                    err,
                )
            end
            push!(rows, row)
            retry_callback === nothing ||
                retry_callback(row, retry_attempt_index, length(retryable_entries))
            if stop_on_green && case_recovered
                break
            end
        end
    end

    table = _reduced_mpcc_global_polish_retry_table(rows)
    metadata = _reduced_mpcc_global_polish_retry_metadata(
        base_sweep,
        retryable_entries,
        rows,
        retry_results;
        retry_policy = policy,
        retry_ipopt_max_iter_values = retry_iters,
        stop_on_green = stop_on_green,
        continue_on_error = continue_on_error,
    )
    return ReducedDCDFBAMPCCGlobalPolishRetryResult(
        base_sweep,
        table,
        retry_results,
        metadata,
    )
end

function _reduced_mpcc_global_polish_retry_base_entries(
    base_sweep::ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult,
)
    entries = NamedTuple[]
    completed_index = 0
    for row in eachrow(base_sweep.global_polish_table)
        row_dict = Dict(String(name) => row[name] for name in names(base_sweep.global_polish_table))
        if get(row_dict, "case_status", missing) == "completed"
            completed_index += 1
            completed_index <= length(base_sweep.global_polish_results) || throw(
                ArgumentError("Reduced MPCC global-polish retry base sweep has fewer results than completed rows."),
            )
            push!(
                entries,
                (
                    row = row_dict,
                    result = base_sweep.global_polish_results[completed_index],
                ),
            )
        else
            push!(entries, (row = row_dict, result = nothing))
        end
    end
    completed_index == length(base_sweep.global_polish_results) || throw(
        ArgumentError("Reduced MPCC global-polish retry base sweep has unused result entries."),
    )
    return entries
end

function _reduced_mpcc_global_polish_retry_base_case_retryable(
    row::Dict{String, Any},
    retry_policy::AbstractString,
)::Bool
    retry_policy == "residual_feasible_iteration_limit" || return false
    get(row, "case_status", missing) == "completed" || return false
    get(row, "global_polish_traffic_light", missing) == "yellow" || return false
    string(get(row, "solver_status", missing)) == "ITERATION_LIMIT" || return false
    get(row, "candidate_residual_feasible", false) === true || return false
    get(row, "candidate_trajectory_ready", false) === true && return false
    return true
end

function _reduced_mpcc_global_polish_retry_row(
    base_row::Dict{String, Any},
    retry_result::ReducedDCDFBAMPCCGlobalPolishResult,
    retry_attempt_index::Int,
    retry_ipopt_max_iter::Int,
    stop_on_green::Bool,
)::Dict{String, Any}
    retry_row = _reduced_mpcc_global_polish_horizon_row(
        retry_result,
        Int(base_row["case_index"]),
    )
    retry_light = get(retry_row, "global_polish_traffic_light", missing)
    return Dict{String, Any}(
        "global_polish_retry_case_id" =>
            _reduced_mpcc_global_polish_retry_case_id(retry_attempt_index),
        "base_global_polish_case_id" =>
            get(base_row, "global_polish_case_id", missing),
        "base_case_index" => get(base_row, "case_index", missing),
        "target_horizon" => get(base_row, "target_horizon", missing),
        "global_horizon" => get(base_row, "global_horizon", missing),
        "global_nfe" => get(base_row, "global_nfe", missing),
        "base_global_ipopt_max_iter" =>
            get(base_row, "global_ipopt_max_iter", missing),
        "base_global_polish_traffic_light" =>
            get(base_row, "global_polish_traffic_light", missing),
        "base_solver_status" => get(base_row, "solver_status", missing),
        "base_candidate_residual_feasible" =>
            get(base_row, "candidate_residual_feasible", missing),
        "base_candidate_trajectory_ready" =>
            get(base_row, "candidate_trajectory_ready", missing),
        "base_iteration_limit_residual_feasible" =>
            get(base_row, "candidate_iteration_limit_residual_feasible", missing),
        "base_max_mass_balance_residual" =>
            get(base_row, "max_mass_balance_residual", missing),
        "base_max_state_relative_rmse" =>
            get(base_row, "max_state_relative_rmse", missing),
        "base_solve_elapsed_seconds" =>
            get(base_row, "solve_elapsed_seconds", missing),
        "retry_attempt_index" => retry_attempt_index,
        "retry_ipopt_max_iter" => retry_ipopt_max_iter,
        "retry_status" => "completed",
        "retry_global_polish_traffic_light" => retry_light,
        "retry_recovered" => retry_light == "green",
        "retry_solver_status" => get(retry_row, "solver_status", missing),
        "retry_primal_status" => get(retry_row, "primal_status", missing),
        "retry_candidate_residual_feasible" =>
            get(retry_row, "candidate_residual_feasible", missing),
        "retry_candidate_trajectory_ready" =>
            get(retry_row, "candidate_trajectory_ready", missing),
        "retry_iteration_limit_residual_feasible" =>
            get(retry_row, "candidate_iteration_limit_residual_feasible", missing),
        "retry_max_mass_balance_residual" =>
            get(retry_row, "max_mass_balance_residual", missing),
        "retry_max_state_relative_rmse" =>
            get(retry_row, "max_state_relative_rmse", missing),
        "retry_solve_elapsed_seconds" =>
            get(retry_row, "solve_elapsed_seconds", missing),
        "retry_recommended_next_action" =>
            get(retry_row, "recommended_next_action", missing),
        "stop_on_green" => stop_on_green,
        "outputs_written" => false,
        "retry_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "error_type" => missing,
        "error_message" => missing,
    )
end

function _reduced_mpcc_global_polish_retry_error_row(
    base_row::Dict{String, Any},
    retry_attempt_index::Int,
    retry_ipopt_max_iter::Int,
    stop_on_green::Bool,
    err,
)::Dict{String, Any}
    row = Dict{String, Any}(
        column => missing for column in REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_RETRY_COLUMNS
    )
    row["global_polish_retry_case_id"] =
        _reduced_mpcc_global_polish_retry_case_id(retry_attempt_index)
    row["base_global_polish_case_id"] =
        get(base_row, "global_polish_case_id", missing)
    row["base_case_index"] = get(base_row, "case_index", missing)
    row["target_horizon"] = get(base_row, "target_horizon", missing)
    row["global_horizon"] = get(base_row, "global_horizon", missing)
    row["global_nfe"] = get(base_row, "global_nfe", missing)
    row["base_global_ipopt_max_iter"] =
        get(base_row, "global_ipopt_max_iter", missing)
    row["base_global_polish_traffic_light"] =
        get(base_row, "global_polish_traffic_light", missing)
    row["base_solver_status"] = get(base_row, "solver_status", missing)
    row["base_candidate_residual_feasible"] =
        get(base_row, "candidate_residual_feasible", missing)
    row["base_candidate_trajectory_ready"] =
        get(base_row, "candidate_trajectory_ready", missing)
    row["base_iteration_limit_residual_feasible"] =
        get(base_row, "candidate_iteration_limit_residual_feasible", missing)
    row["base_max_mass_balance_residual"] =
        get(base_row, "max_mass_balance_residual", missing)
    row["base_max_state_relative_rmse"] =
        get(base_row, "max_state_relative_rmse", missing)
    row["base_solve_elapsed_seconds"] =
        get(base_row, "solve_elapsed_seconds", missing)
    row["retry_attempt_index"] = retry_attempt_index
    row["retry_ipopt_max_iter"] = retry_ipopt_max_iter
    row["retry_status"] = "failed"
    row["retry_global_polish_traffic_light"] = "red"
    row["retry_recovered"] = false
    row["stop_on_green"] = stop_on_green
    row["outputs_written"] = false
    row["retry_is_scientific_simulation"] = false
    row["solved_trajectory_claimed"] = false
    row["first_mpcc_target"] = "reduced_dfba"
    row["full_model_kkt_deferred"] = true
    row["dfvb_kkt_deferred"] = true
    row["hsl_required"] = false
    row["ma57_required"] = false
    row["indices_reacciones_used"] = false
    row["r0001_used_as_oxygen"] = false
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_global_polish_retry_metadata(
    base_sweep::ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult,
    retryable_entries::Vector,
    rows::Vector{Dict{String, Any}},
    retry_results::Vector{ReducedDCDFBAMPCCGlobalPolishResult};
    retry_policy::AbstractString,
    retry_ipopt_max_iter_values::Vector{Int},
    stop_on_green::Bool,
    continue_on_error::Bool,
)::Dict{String, Any}
    retryable_ids = [
        string(get(entry.row, "global_polish_case_id", missing)) for
        entry in retryable_entries
    ]
    recovered_ids = unique([
        string(get(row, "base_global_polish_case_id", missing)) for row in rows if
        get(row, "retry_recovered", false) === true
    ])
    unrecovered_ids = setdiff(retryable_ids, recovered_ids)
    best_recovered = _reduced_mpcc_global_polish_retry_best_recovered_row(rows)
    return Dict{String, Any}(
        "retry_type" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_RETRY_TYPE,
        "retry_policy" => String(retry_policy),
        "retry_ipopt_max_iter_values" => copy(retry_ipopt_max_iter_values),
        "retry_ipopt_max_iter_values_label" => join(retry_ipopt_max_iter_values, ","),
        "stop_on_green" => stop_on_green,
        "continue_on_error" => continue_on_error,
        "base_n_cases" => get(base_sweep.metadata, "n_cases", missing),
        "base_green_count" => get(base_sweep.metadata, "green_count", missing),
        "base_yellow_count" => get(base_sweep.metadata, "yellow_count", missing),
        "base_red_count" => get(base_sweep.metadata, "red_count", missing),
        "base_best_green_target_horizon" =>
            get(base_sweep.metadata, "best_green_target_horizon", missing),
        "retryable_case_count" => length(retryable_entries),
        "retried_case_count" =>
            length(unique([get(row, "base_global_polish_case_id", missing) for row in rows])),
        "retry_attempt_count" => length(rows),
        "retry_completed_count" =>
            count(row -> get(row, "retry_status", missing) == "completed", rows),
        "retry_failed_count" =>
            count(row -> get(row, "retry_status", missing) == "failed", rows),
        "retry_green_count" =>
            count(row -> get(row, "retry_global_polish_traffic_light", missing) == "green", rows),
        "retry_yellow_count" =>
            count(row -> get(row, "retry_global_polish_traffic_light", missing) == "yellow", rows),
        "retry_red_count" =>
            count(row -> get(row, "retry_global_polish_traffic_light", missing) == "red", rows),
        "recovered_case_count" => length(recovered_ids),
        "unrecovered_case_count" => length(unrecovered_ids),
        "all_retryable_cases_recovered" =>
            !isempty(retryable_entries) && isempty(unrecovered_ids),
        "retryable_case_ids" => retryable_ids,
        "recovered_case_ids" => recovered_ids,
        "unrecovered_case_ids" => unrecovered_ids,
        "best_recovered_case_id" =>
            _reduced_mpcc_global_polish_retry_value(best_recovered, "base_global_polish_case_id"),
        "best_recovered_target_horizon" =>
            _reduced_mpcc_global_polish_retry_value(best_recovered, "target_horizon"),
        "best_recovered_global_horizon" =>
            _reduced_mpcc_global_polish_retry_value(best_recovered, "global_horizon"),
        "best_recovered_retry_ipopt_max_iter" =>
            _reduced_mpcc_global_polish_retry_value(best_recovered, "retry_ipopt_max_iter"),
        "max_recovered_target_horizon" =>
            _reduced_mpcc_global_polish_retry_value(best_recovered, "target_horizon"),
        "total_retry_solve_elapsed_seconds" =>
            _reduced_mpcc_global_polish_retry_sum(rows, "retry_solve_elapsed_seconds"),
        "total_base_solve_elapsed_seconds" =>
            get(base_sweep.metadata, "total_solve_elapsed_seconds", missing),
        "n_retry_results" => length(retry_results),
        "recommended_next_action" =>
            _reduced_mpcc_global_polish_retry_recommended_action(
                retryable_entries,
                recovered_ids,
                unrecovered_ids,
            ),
        "outputs_written" => false,
        "retry_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC global-polish retry reuses base sweep source continuations and retries only residual-feasible ITERATION_LIMIT cases.",
    )
end

function _reduced_mpcc_global_polish_retry_recommended_action(
    retryable_entries::Vector,
    recovered_ids,
    unrecovered_ids,
)::String
    isempty(retryable_entries) && return "extend_global_polish_horizon_grid"
    isempty(unrecovered_ids) && return "extend_global_polish_horizon_grid"
    !isempty(recovered_ids) && return "retry_remaining_iteration_limits_or_refine_scaling"
    return "inspect_global_polish_iteration_limit_retry_failures"
end

function _reduced_mpcc_global_polish_retry_best_recovered_row(
    rows::Vector{Dict{String, Any}},
)
    candidates = [
        index for (index, row) in enumerate(rows) if
        get(row, "retry_recovered", false) === true
    ]
    isempty(candidates) && return nothing
    index = candidates[argmax([
        (
            _reduced_mpcc_global_polish_retry_float_or_neginf(
                get(rows[index], "target_horizon", missing),
            ),
            _reduced_mpcc_global_polish_retry_float_or_neginf(
                get(rows[index], "global_horizon", missing),
            ),
            -_reduced_mpcc_global_polish_retry_float_or_inf(
                get(rows[index], "retry_max_state_relative_rmse", missing),
            ),
        ) for index in candidates
    ])]
    return rows[index]
end

function _reduced_mpcc_global_polish_retry_table(
    rows::Vector{Dict{String, Any}},
)::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_global_polish_retry_table_scalar(
                    get(row, column, missing),
                ) for row in rows
            ] for column in REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_RETRY_COLUMNS
        )...,
    )
end

function _reduced_mpcc_global_polish_retry_validate_iters(values)::Vector{Int}
    collection = Int.(collect(values))
    isempty(collection) && throw(
        ArgumentError("Reduced MPCC global-polish retry_ipopt_max_iter_values must not be empty."),
    )
    all(value -> value > 0, collection) || throw(
        ArgumentError("Reduced MPCC global-polish retry_ipopt_max_iter_values must be positive."),
    )
    return collection
end

function _reduced_mpcc_global_polish_retry_validate_policy(
    retry_policy::AbstractString,
)::String
    policy = lowercase(strip(String(retry_policy)))
    policy == "residual_feasible_iteration_limit" || throw(
        ArgumentError("Reduced MPCC global-polish retry_policy must be residual_feasible_iteration_limit."),
    )
    return policy
end

function _reduced_mpcc_global_polish_retry_case_id(index::Int)::String
    return "global_polish_retry_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_global_polish_retry_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_global_polish_retry_sum(
    rows::Vector{Dict{String, Any}},
    key::AbstractString,
)::Float64
    total = 0.0
    for row in rows
        value = get(row, String(key), missing)
        _reduced_mpcc_global_polish_retry_isfinite_number(value) || continue
        total += Float64(value)
    end
    return total
end

function _reduced_mpcc_global_polish_retry_float_or_inf(value)::Float64
    _reduced_mpcc_global_polish_retry_isfinite_number(value) || return Inf
    return Float64(value)
end

function _reduced_mpcc_global_polish_retry_float_or_neginf(value)::Float64
    _reduced_mpcc_global_polish_retry_isfinite_number(value) || return -Inf
    return Float64(value)
end

function _reduced_mpcc_global_polish_retry_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_global_polish_retry_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
