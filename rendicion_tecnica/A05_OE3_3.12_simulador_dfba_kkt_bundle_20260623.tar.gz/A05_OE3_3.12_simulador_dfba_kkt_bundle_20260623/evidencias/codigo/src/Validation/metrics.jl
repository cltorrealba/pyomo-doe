const DEFAULT_SIMULATION_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

"""
    mode_counts(result)

Count saved simulation modes from `result.metadata["mode_history"]`.
"""
function mode_counts(result::SimulationResult)::Dict{Symbol, Int}
    history = _safe_metadata_vector(result, "mode_history")
    counts = Dict{Symbol, Int}()
    history === nothing && return counts

    for mode in history
        mode_symbol = mode isa Symbol ? mode : Symbol(String(mode))
        counts[mode_symbol] = get(counts, mode_symbol, 0) + 1
    end
    return counts
end

"""
    total_sugar(result; time_index=length(result.time))

Return glucose plus fructose at a saved time point.
"""
function total_sugar(
    result::SimulationResult;
    time_index::Int = length(result.time),
)::Float64
    _validate_time_index(result, time_index)
    glucose_index = _state_index(result, "glucose")
    fructose_index = _state_index(result, "fructose")
    return Float64(result.states[glucose_index, time_index] + result.states[fructose_index, time_index])
end

"""
    time_to_sugar_depletion(result; tol=get(result.metadata, "sugar_depletion_tol", 1.0e-6))

Return the first saved time where glucose plus fructose is at or below `tol`.
Returns `nothing` if no saved point is sugar depleted.
"""
function time_to_sugar_depletion(
    result::SimulationResult;
    tol::Real = get(result.metadata, "sugar_depletion_tol", 1.0e-6),
)::Union{Nothing, Float64}
    converted_tol = Float64(tol)
    isfinite(converted_tol) && converted_tol >= 0.0 ||
        error("Sugar depletion tolerance must be finite and nonnegative, got $tol.")

    for k in eachindex(result.time)
        if total_sugar(result; time_index = k) <= converted_tol
            return result.time[k]
        end
    end
    return nothing
end

"""
    diagnostic_summary(result)

Return compact solver diagnostic maxima from simulation metadata.
"""
function diagnostic_summary(result::SimulationResult)::Dict{String, Any}
    mass_balance_residuals = _safe_metadata_vector(result, "mass_balance_residuals")
    lower_bound_violations = _safe_metadata_vector(result, "max_lower_bound_violations")
    upper_bound_violations = _safe_metadata_vector(result, "max_upper_bound_violations")
    has_diagnostics =
        _has_nonempty_metadata_vector(mass_balance_residuals) &&
        _has_nonempty_metadata_vector(lower_bound_violations) &&
        _has_nonempty_metadata_vector(upper_bound_violations)

    return Dict{String, Any}(
        "max_mass_balance_residual" => _metadata_vector_max(mass_balance_residuals),
        "max_lower_bound_violation" => _metadata_vector_max(lower_bound_violations),
        "max_upper_bound_violation" => _metadata_vector_max(upper_bound_violations),
        "has_diagnostics" => has_diagnostics,
    )
end

"""
    summarize_simulation(result)

Return a compact plotting-free trajectory summary for a `SimulationResult`.
"""
function summarize_simulation(result::SimulationResult)::Dict{String, Any}
    isempty(result.time) && error("Cannot summarize a SimulationResult with no saved time points.")
    size(result.states, 2) == length(result.time) || error(
        "SimulationResult states must be stored as n_states x n_time. " *
        "Got $(size(result.states, 2)) saved state columns for $(length(result.time)) time points.",
    )

    initial_index = firstindex(result.time)
    final_index = lastindex(result.time)
    diagnostics = diagnostic_summary(result)

    initial_glucose = _state_value(result, "glucose", initial_index)
    final_glucose = _state_value(result, "glucose", final_index)
    initial_fructose = _state_value(result, "fructose", initial_index)
    final_fructose = _state_value(result, "fructose", final_index)
    initial_total_sugar = initial_glucose + initial_fructose
    final_total_sugar = final_glucose + final_fructose
    initial_ethanol = _state_value(result, "ethanol", initial_index)
    final_ethanol = _state_value(result, "ethanol", final_index)
    ethanol_index = _state_index(result, "ethanol")

    return Dict{String, Any}(
        "initial_time" => result.time[initial_index],
        "final_time" => result.time[final_index],
        "n_saved_points" => length(result.time),
        "n_states" => size(result.states, 1),
        "n_fluxes" => result.fluxes === nothing ? 0 : size(result.fluxes, 1),
        "n_alphas" => result.alphas === nothing ? 0 : size(result.alphas, 1),
        "alpha_scope" => get(result.metadata, "alpha_scope", nothing),
        "model_scope" => get(result.metadata, "model_scope", "unknown"),
        "retcode" => get(result.metadata, "retcode", nothing),
        "termination_reason" => get(result.metadata, "termination_reason", nothing),
        "termination_time" => get(result.metadata, "termination_time", nothing),
        "algorithm" => get(result.metadata, "algorithm", nothing),
        "initial_biomass" => _state_value(result, "biomass", initial_index),
        "final_biomass" => _state_value(result, "biomass", final_index),
        "initial_nitrogen" => _state_value(result, "nitrogen", initial_index),
        "final_nitrogen" => _state_value(result, "nitrogen", final_index),
        "initial_glucose" => initial_glucose,
        "final_glucose" => final_glucose,
        "initial_fructose" => initial_fructose,
        "final_fructose" => final_fructose,
        "initial_total_sugar" => initial_total_sugar,
        "final_total_sugar" => final_total_sugar,
        "sugar_consumed" => initial_total_sugar - final_total_sugar,
        "initial_ethanol" => initial_ethanol,
        "final_ethanol" => final_ethanol,
        "ethanol_produced" => final_ethanol - initial_ethanol,
        "max_ethanol" => maximum(view(result.states, ethanol_index, :)),
        "initial_oxygen" => _state_value(result, "oxygen", initial_index),
        "final_oxygen" => _state_value(result, "oxygen", final_index),
        "initial_protein" => _state_value(result, "protein", initial_index),
        "final_protein" => _state_value(result, "protein", final_index),
        "initial_carbohydrate" => _state_value(result, "carbohydrate", initial_index),
        "final_carbohydrate" => _state_value(result, "carbohydrate", final_index),
        "time_to_sugar_depletion" => time_to_sugar_depletion(result),
        "mode_counts" => mode_counts(result),
        "min_state_value" => get(result.metadata, "min_state_value", minimum(result.states)),
        "has_negative_saved_states" => get(result.metadata, "has_negative_saved_states", any(result.states .< 0.0)),
        "max_mass_balance_residual" => diagnostics["max_mass_balance_residual"],
        "max_lower_bound_violation" => diagnostics["max_lower_bound_violation"],
        "max_upper_bound_violation" => diagnostics["max_upper_bound_violation"],
        "oxygen_derivative_policy" => get(result.metadata, "oxygen_derivative_policy", nothing),
        "carbohydrate_derivative_policy" => get(result.metadata, "carbohydrate_derivative_policy", nothing),
        "simulation_elapsed_seconds" => get(result.metadata, "simulation_elapsed_seconds", missing),
        "ode_solve_elapsed_seconds" => get(result.metadata, "ode_solve_elapsed_seconds", missing),
        "rhs_elapsed_seconds" => get(result.metadata, "rhs_elapsed_seconds", missing),
        "history_reconstruction_elapsed_seconds" =>
            get(result.metadata, "history_reconstruction_elapsed_seconds", missing),
        "rhs_call_count" => get(result.metadata, "rhs_call_count", missing),
        "rhs_lp_solve_count" => get(result.metadata, "rhs_lp_solve_count", missing),
        "flux_reconstruction_solve_count" => get(result.metadata, "flux_reconstruction_solve_count", missing),
        "total_lp_solve_count" => get(result.metadata, "total_lp_solve_count", missing),
        "reconstruct_fluxes" => get(result.metadata, "reconstruct_fluxes", missing),
        "fba_variant" => get(result.metadata, "fba_variant", missing),
        "quadratic_penalty" => get(result.metadata, "quadratic_penalty", missing),
        "l1_penalty" => get(result.metadata, "l1_penalty", missing),
        "lp_reuse" => get(result.metadata, "lp_reuse", missing),
        "lp_primal_start" => get(result.metadata, "lp_primal_start", missing),
        "lp_basis_warm_start" => get(result.metadata, "lp_basis_warm_start", missing),
        "lp_reuse_highs_solver" => get(result.metadata, "lp_reuse_highs_solver", missing),
        "lp_simplex_strategy" => get(result.metadata, "lp_simplex_strategy", missing),
        "lp_reuse_strategy" => get(result.metadata, "lp_reuse_strategy", missing),
        "lp_warm_start_strategy" => get(result.metadata, "lp_warm_start_strategy", missing),
        "allow_experimental_lp_reuse" => get(result.metadata, "allow_experimental_lp_reuse", missing),
        "experimental_lp_reuse" => get(result.metadata, "experimental_lp_reuse", missing),
        "trajectory_equivalence_checked" => get(result.metadata, "trajectory_equivalence_checked", missing),
        "trajectory_equivalence_passed" => get(result.metadata, "trajectory_equivalence_passed", missing),
        "scientific_output_equivalent" => get(result.metadata, "scientific_output_equivalent", missing),
        "lp_reuse_validity_note" => get(result.metadata, "lp_reuse_validity_note", missing),
        "lp_reuse_build_elapsed_seconds" => get(result.metadata, "lp_reuse_build_elapsed_seconds", missing),
        "lp_reuse_update_elapsed_seconds" => get(result.metadata, "lp_reuse_update_elapsed_seconds", missing),
        "lp_reuse_solve_elapsed_seconds" => get(result.metadata, "lp_reuse_solve_elapsed_seconds", missing),
        "lp_reuse_warm_start_applied_count" =>
            get(result.metadata, "lp_reuse_warm_start_applied_count", missing),
        "lp_reuse_basis_warm_start_applied_count" =>
            get(result.metadata, "lp_reuse_basis_warm_start_applied_count", missing),
        "lp_reuse_basis_warm_start_failed_count" =>
            get(result.metadata, "lp_reuse_basis_warm_start_failed_count", missing),
        "lp_reuse_basis_capture_count" => get(result.metadata, "lp_reuse_basis_capture_count", missing),
        "lp_reuse_simplex_iterations" => get(result.metadata, "lp_reuse_simplex_iterations", missing),
        "qpfba_persistent_fallback_count" =>
            get(result.metadata, "qpfba_persistent_fallback_count", missing),
        "dynamic_control_schedule_enabled" =>
            get(result.metadata, "dynamic_control_schedule_enabled", missing),
        "dynamic_control_policy" => get(result.metadata, "dynamic_control_policy", missing),
        "dynamic_control_fda_total_product_g_L" =>
            get(result.metadata, "dynamic_control_fda_total_product_g_L", missing),
        "dynamic_control_organic_total_product_g_L" =>
            get(result.metadata, "dynamic_control_organic_total_product_g_L", missing),
        "dynamic_control_penalty" => get(result.metadata, "dynamic_control_penalty", missing),
        "dynamic_control_volatilization_enabled" =>
            get(result.metadata, "dynamic_control_volatilization_enabled", missing),
    )
end

function _state_names(result::SimulationResult)::Vector{String}
    names = get(result.metadata, "state_names", nothing)
    names === nothing && return copy(DEFAULT_SIMULATION_STATE_NAMES)
    return String.(names)
end

function _state_index(result::SimulationResult, name::AbstractString)::Int
    names = _state_names(result)
    index = findfirst(==(String(name)), names)
    index === nothing && error("State name not found in SimulationResult metadata: $(String(name)).")
    index <= size(result.states, 1) || error(
        "State index $index for $(String(name)) exceeds SimulationResult state dimension $(size(result.states, 1)).",
    )
    return index
end

function _state_value(result::SimulationResult, name::AbstractString, time_index::Int)::Float64
    _validate_time_index(result, time_index)
    return Float64(result.states[_state_index(result, name), time_index])
end

function _validate_time_index(result::SimulationResult, time_index::Int)
    firstindex(result.time) <= time_index <= lastindex(result.time) || error(
        "SimulationResult time_index must be between $(firstindex(result.time)) and $(lastindex(result.time)), got $time_index.",
    )
    return nothing
end

function _safe_metadata_vector(result::SimulationResult, key::String)
    value = get(result.metadata, key, nothing)
    value isa AbstractVector || return nothing
    return value
end

function _has_nonempty_metadata_vector(value)::Bool
    return value isa AbstractVector && !isempty(value)
end

function _metadata_vector_max(value)
    _has_nonempty_metadata_vector(value) || return nothing
    return maximum(Float64.(value))
end
