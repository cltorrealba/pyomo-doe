import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_CASCADE_RETRY_HORIZON_SMOKE_TYPE =
    "reduced_dcdfba_mpcc_windowed_cascade_retry_horizon_smoke"

const REDUCED_DCDFBA_MPCC_WINDOWED_CASCADE_RETRY_HORIZON_COLUMNS = [
    "cascade_horizon_case_id",
    "case_index",
    "case_status",
    "target_horizon",
    "window_hours",
    "nfe_per_window",
    "degree",
    "source_ipopt_max_iter",
    "retry_ipopt_max_iter_values",
    "cascade_ipopt_max_iter",
    "base_attempt_traffic_light",
    "base_attempt_viable",
    "base_horizon_reached",
    "base_target_completed",
    "retry_policy_applied",
    "retry_replacement_recommended",
    "n_selected_windows",
    "n_retried_windows",
    "green_recovered_count",
    "trajectory_ready_recovered_count",
    "residual_feasible_recovered_count",
    "cascade_rebuild_applied",
    "retry_replacement_applied",
    "windowed_candidate_rebuilt",
    "cascade_replacement_window_id",
    "cascade_replacement_window_index",
    "cascade_replacement_retry_case_id",
    "cascade_replacement_retry_ipopt_max_iter",
    "n_downstream_windows_requested",
    "n_downstream_windows_resolved",
    "cascade_stopped_by_error",
    "rebuilt_attempt_traffic_light",
    "rebuilt_attempt_viable",
    "rebuilt_horizon_reached",
    "rebuilt_target_completed",
    "horizon_gain",
    "traffic_light_improved",
    "viability_recovered_by_cascade",
    "target_recovered_by_cascade",
    "nonterminal_replacement_applied",
    "recommended_next_action",
    "outputs_written",
    "smoke_is_scientific_simulation",
    "solved_trajectory_claimed",
    "first_mpcc_target",
    "full_model_kkt_deferred",
    "dfvb_kkt_deferred",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCWindowedCascadeRetryHorizonSmokeResult

Diagnostic smoke over one or more reduced MPCC target horizons using the
retry-aware attempt plus retry replacement cascade rebuild. It summarizes
whether cascade replacement improves the target candidate and whether a
non-terminal replacement forced downstream re-solves.
"""
struct ReducedDCDFBAMPCCWindowedCascadeRetryHorizonSmokeResult
    cascade_horizon_table::DataFrame
    retry_aware_results::Vector{ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult}
    cascade_results::Vector{ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult}
    metadata::Dict{String, Any}
end

"""
    smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(cascade_results; retry_aware_results=...)

Aggregate already-computed cascade retry rebuild results. This method is useful
for deterministic tests and cached diagnostics.
"""
function smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(
    cascade_results::AbstractVector{<:ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult};
    retry_aware_results::AbstractVector{<:ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult} =
        ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult[],
)::ReducedDCDFBAMPCCWindowedCascadeRetryHorizonSmokeResult
    collected_cascades = collect(cascade_results)
    isempty(collected_cascades) && throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke requires at least one cascade result."),
    )
    collected_retry_aware = collect(retry_aware_results)
    isempty(collected_retry_aware) || length(collected_retry_aware) == length(collected_cascades) ||
        throw(
            ArgumentError(
                "Reduced MPCC cascade retry horizon smoke retry_aware_results must be empty or match cascade_results length.",
            ),
        )
    rows = [
        _reduced_mpcc_cascade_retry_horizon_row(
            cascade,
            case_index;
            retry_aware = isempty(collected_retry_aware) ? nothing :
                          collected_retry_aware[case_index],
        ) for (case_index, cascade) in enumerate(collected_cascades)
    ]
    table = _reduced_mpcc_cascade_retry_horizon_table(rows)
    metadata = _reduced_mpcc_cascade_retry_horizon_metadata(
        rows,
        collected_retry_aware,
        collected_cascades;
        requested_case_count = length(rows),
        stopped_after_first_non_green = false,
    )
    return ReducedDCDFBAMPCCWindowedCascadeRetryHorizonSmokeResult(
        table,
        collected_retry_aware,
        collected_cascades,
        metadata,
    )
end

"""
    smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(model, reaction_map; kwargs...)

Run reduced MPCC retry-aware attempts over selected target horizons, apply
retry replacement cascade rebuilds, and summarize the resulting candidates.
This is a guarded diagnostic workflow: it writes no outputs, does not touch
full-model or DFVB KKT code, and does not claim a validated simulation.
"""
function smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    target_horizons = [1.0],
    t0::Real = 0.0,
    window_hours::Real = 0.5,
    nfe_per_window::Int = 2,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    source_ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    retry_ipopt_max_iter_values = [200, 300, 500],
    cascade_ipopt_max_iter::Union{Nothing, Int} = nothing,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    tau_schedule = nothing,
    retry_selection_policy::AbstractString = "iteration_limit_or_not_ready",
    retry_max_windows::Int = 2,
    replacement_acceptance_policy::AbstractString = "green_or_trajectory_ready",
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_RESIDUAL_FEASIBLE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        ),
    silent::Bool = true,
    continue_on_error::Bool = true,
    stop_after_first_non_green::Bool = false,
    case_callback = nothing,
)::ReducedDCDFBAMPCCWindowedCascadeRetryHorizonSmokeResult
    retry_iters =
        _reduced_mpcc_cascade_retry_horizon_validate_retry_iters(
            retry_ipopt_max_iter_values,
        )
    cascade_iter =
        _reduced_mpcc_cascade_retry_horizon_validate_cascade_iter(
            cascade_ipopt_max_iter,
            retry_iters,
        )
    specs = _reduced_mpcc_cascade_retry_horizon_specs(
        target_horizons,
        t0,
        window_hours,
        nfe_per_window,
        degree,
        source_ipopt_max_iter,
        retry_iters,
        cascade_iter,
    )

    rows = Dict{String, Any}[]
    retry_aware_results = ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult[]
    cascade_results = ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult[]
    stopped = false

    for spec in specs
        row = try
            retry_aware = attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
                model,
                reaction_map;
                target_horizon = spec.target_horizon,
                t0 = spec.t0,
                window_hours = spec.window_hours,
                nfe_per_window = spec.nfe_per_window,
                degree = spec.degree,
                y0 = y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = source_ipopt_max_iter,
                linear_solver = linear_solver,
                ipopt_profile = ipopt_profile,
                complementarity_mode = complementarity_mode,
                complementarity_tau = complementarity_tau,
                tau_schedule = tau_schedule,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                continuation_acceptance_policy = continuation_acceptance_policy,
                continuation_state_relative_rmse_threshold =
                    continuation_state_relative_rmse_threshold,
                viability_thresholds = viability_thresholds,
                retry_selection_policy = retry_selection_policy,
                retry_max_windows = retry_max_windows,
                retry_ipopt_max_iter_values = retry_iters,
                silent = silent,
                continue_on_error = continue_on_error,
            )
            cascade = cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
                retry_aware.base_attempt,
                retry_aware.retry_policy_diagnostic,
                model,
                reaction_map;
                acceptance_policy = replacement_acceptance_policy,
                continuation_acceptance_policy = continuation_acceptance_policy,
                continuation_state_relative_rmse_threshold =
                    continuation_state_relative_rmse_threshold,
                thresholds = viability_thresholds,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = cascade_iter,
                linear_solver = linear_solver,
                ipopt_profile = ipopt_profile,
                complementarity_mode = complementarity_mode,
                complementarity_tau = complementarity_tau,
                tau_schedule = tau_schedule,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                silent = silent,
                continue_on_error = continue_on_error,
            )
            push!(retry_aware_results, retry_aware)
            push!(cascade_results, cascade)
            _reduced_mpcc_cascade_retry_horizon_row(
                cascade,
                spec.case_index;
                spec = spec,
                retry_aware = retry_aware,
            )
        catch err
            continue_on_error || rethrow()
            _reduced_mpcc_cascade_retry_horizon_error_row(spec, err)
        end
        push!(rows, row)
        case_callback === nothing || case_callback(row, spec.case_index, length(specs))
        if stop_after_first_non_green &&
           get(row, "rebuilt_attempt_traffic_light", missing) != "green"
            stopped = true
            break
        end
    end

    table = _reduced_mpcc_cascade_retry_horizon_table(rows)
    metadata = _reduced_mpcc_cascade_retry_horizon_metadata(
        rows,
        retry_aware_results,
        cascade_results;
        requested_case_count = length(specs),
        stopped_after_first_non_green = stopped,
    )
    return ReducedDCDFBAMPCCWindowedCascadeRetryHorizonSmokeResult(
        table,
        retry_aware_results,
        cascade_results,
        metadata,
    )
end

function _reduced_mpcc_cascade_retry_horizon_specs(
    target_horizons,
    t0::Real,
    window_hours::Real,
    nfe_per_window::Int,
    degree::Int,
    source_ipopt_max_iter,
    retry_ipopt_max_iter_values::Vector{Int},
    cascade_ipopt_max_iter::Int,
)::Vector{NamedTuple}
    initial_time = Float64(t0)
    isfinite(initial_time) || throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke t0 must be finite."),
    )
    duration = Float64(window_hours)
    isfinite(duration) && duration > 0.0 || throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke window_hours must be finite and positive."),
    )
    nfe_per_window > 0 || throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke nfe_per_window must be positive."),
    )
    degree == 3 || throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke currently supports only degree == 3."),
    )
    source_ipopt_max_iter === nothing || source_ipopt_max_iter > 0 || throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke source_ipopt_max_iter must be positive or nothing."),
    )
    horizons = Float64.(collect(target_horizons))
    isempty(horizons) && throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke target_horizons must not be empty."),
    )
    all(value -> isfinite(value) && value > 0.0, horizons) || throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke target_horizons must be finite and positive."),
    )

    specs = NamedTuple[]
    for (case_index, target) in enumerate(horizons)
        _reduced_mpcc_cascade_retry_horizon_n_windows(target, duration)
        push!(
            specs,
            (
                cascade_horizon_case_id =
                    _reduced_mpcc_cascade_retry_horizon_case_id(case_index),
                case_index = case_index,
                t0 = initial_time,
                target_horizon = target,
                window_hours = duration,
                nfe_per_window = nfe_per_window,
                degree = degree,
                source_ipopt_max_iter = source_ipopt_max_iter,
                retry_ipopt_max_iter_values = copy(retry_ipopt_max_iter_values),
                cascade_ipopt_max_iter = cascade_ipopt_max_iter,
            ),
        )
    end
    return specs
end

function _reduced_mpcc_cascade_retry_horizon_row(
    cascade::ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult,
    case_index::Int;
    spec = nothing,
    retry_aware = nothing,
)::Dict{String, Any}
    metadata = cascade.metadata
    source_metadata = cascade.source_attempt.metadata
    retry_metadata =
        retry_aware === nothing ? Dict{String, Any}() : retry_aware.metadata
    base_horizon = get(source_metadata, "horizon_reached", missing)
    rebuilt_horizon = get(metadata, "rebuilt_horizon_reached", missing)
    horizon_gain = _reduced_mpcc_cascade_retry_horizon_gain(base_horizon, rebuilt_horizon)
    base_light = get(metadata, "base_attempt_traffic_light", missing)
    rebuilt_light = get(metadata, "rebuilt_attempt_traffic_light", missing)
    replacement_index = get(metadata, "cascade_replacement_window_index", missing)
    downstream_requested = get(metadata, "n_downstream_windows_requested", 0)
    row = Dict{String, Any}(
        "cascade_horizon_case_id" =>
            spec === nothing ? _reduced_mpcc_cascade_retry_horizon_case_id(case_index) :
            spec.cascade_horizon_case_id,
        "case_index" => case_index,
        "case_status" => "completed",
        "target_horizon" =>
            _reduced_mpcc_cascade_retry_horizon_spec_or_metadata(
                spec,
                metadata,
                "target_horizon",
            ),
        "window_hours" =>
            _reduced_mpcc_cascade_retry_horizon_spec_or_source(
                spec,
                source_metadata,
                "window_hours",
            ),
        "nfe_per_window" =>
            _reduced_mpcc_cascade_retry_horizon_spec_or_source(
                spec,
                source_metadata,
                "nfe_per_window",
            ),
        "degree" =>
            _reduced_mpcc_cascade_retry_horizon_spec_or_source(
                spec,
                source_metadata,
                "degree",
            ),
        "source_ipopt_max_iter" =>
            spec === nothing ? missing : spec.source_ipopt_max_iter,
        "retry_ipopt_max_iter_values" =>
            spec === nothing ? missing : join(spec.retry_ipopt_max_iter_values, ","),
        "cascade_ipopt_max_iter" =>
            spec === nothing ?
            get(metadata, "cascade_replacement_retry_ipopt_max_iter", missing) :
            spec.cascade_ipopt_max_iter,
        "base_attempt_traffic_light" => base_light,
        "base_attempt_viable" => get(metadata, "base_attempt_viable", false),
        "base_horizon_reached" => base_horizon,
        "base_target_completed" => get(source_metadata, "target_completed", missing),
        "retry_policy_applied" =>
            get(retry_metadata, "retry_policy_applied", missing),
        "retry_replacement_recommended" =>
            get(retry_metadata, "retry_replacement_recommended", missing),
        "n_selected_windows" => get(retry_metadata, "n_selected_windows", missing),
        "n_retried_windows" => get(retry_metadata, "n_retried_windows", missing),
        "green_recovered_count" =>
            get(retry_metadata, "green_recovered_count", missing),
        "trajectory_ready_recovered_count" =>
            get(retry_metadata, "trajectory_ready_recovered_count", missing),
        "residual_feasible_recovered_count" =>
            get(retry_metadata, "residual_feasible_recovered_count", missing),
        "cascade_rebuild_applied" =>
            get(metadata, "cascade_rebuild_applied", false),
        "retry_replacement_applied" =>
            get(metadata, "retry_replacement_applied", false),
        "windowed_candidate_rebuilt" =>
            get(metadata, "windowed_candidate_rebuilt", false),
        "cascade_replacement_window_id" =>
            get(metadata, "cascade_replacement_window_id", missing),
        "cascade_replacement_window_index" => replacement_index,
        "cascade_replacement_retry_case_id" =>
            get(metadata, "cascade_replacement_retry_case_id", missing),
        "cascade_replacement_retry_ipopt_max_iter" =>
            get(metadata, "cascade_replacement_retry_ipopt_max_iter", missing),
        "n_downstream_windows_requested" => downstream_requested,
        "n_downstream_windows_resolved" =>
            get(metadata, "n_downstream_windows_resolved", missing),
        "cascade_stopped_by_error" =>
            get(metadata, "cascade_stopped_by_error", false),
        "rebuilt_attempt_traffic_light" => rebuilt_light,
        "rebuilt_attempt_viable" =>
            get(metadata, "rebuilt_attempt_viable", false),
        "rebuilt_horizon_reached" => rebuilt_horizon,
        "rebuilt_target_completed" =>
            get(metadata, "rebuilt_target_completed", missing),
        "horizon_gain" => horizon_gain,
        "traffic_light_improved" =>
            get(metadata, "improved_attempt_traffic_light", false),
        "viability_recovered_by_cascade" =>
            get(metadata, "base_attempt_viable", false) !== true &&
            get(metadata, "rebuilt_attempt_viable", false) === true,
        "target_recovered_by_cascade" =>
            get(source_metadata, "target_completed", false) !== true &&
            get(metadata, "rebuilt_target_completed", false) === true,
        "nonterminal_replacement_applied" =>
            replacement_index !== missing &&
            _reduced_mpcc_cascade_retry_horizon_isfinite_number(downstream_requested) &&
            Int(downstream_requested) > 0,
        "recommended_next_action" =>
            get(metadata, "recommended_next_action", missing),
        "outputs_written" => false,
        "smoke_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "error_type" => missing,
        "error_message" => missing,
    )
    return row
end

function _reduced_mpcc_cascade_retry_horizon_error_row(spec, err)::Dict{String, Any}
    row = Dict{String, Any}(
        column => missing for column in
        REDUCED_DCDFBA_MPCC_WINDOWED_CASCADE_RETRY_HORIZON_COLUMNS
    )
    row["cascade_horizon_case_id"] = spec.cascade_horizon_case_id
    row["case_index"] = spec.case_index
    row["case_status"] = "failed"
    row["target_horizon"] = spec.target_horizon
    row["window_hours"] = spec.window_hours
    row["nfe_per_window"] = spec.nfe_per_window
    row["degree"] = spec.degree
    row["source_ipopt_max_iter"] = spec.source_ipopt_max_iter
    row["retry_ipopt_max_iter_values"] = join(spec.retry_ipopt_max_iter_values, ",")
    row["cascade_ipopt_max_iter"] = spec.cascade_ipopt_max_iter
    row["cascade_rebuild_applied"] = false
    row["retry_replacement_applied"] = false
    row["windowed_candidate_rebuilt"] = false
    row["outputs_written"] = false
    row["smoke_is_scientific_simulation"] = false
    row["solved_trajectory_claimed"] = false
    row["first_mpcc_target"] = "reduced_dfba"
    row["full_model_kkt_deferred"] = true
    row["dfvb_kkt_deferred"] = true
    row["hsl_required"] = false
    row["ma57_required"] = false
    row["indices_reacciones_used"] = false
    row["r0001_used_as_oxygen"] = false
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_cascade_retry_horizon_metadata(
    rows::Vector{Dict{String, Any}},
    retry_aware_results::Vector{ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult},
    cascade_results::Vector{ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult};
    requested_case_count::Int,
    stopped_after_first_non_green::Bool,
)::Dict{String, Any}
    best_green =
        _reduced_mpcc_cascade_retry_horizon_best_row(
            rows,
            row -> get(row, "rebuilt_attempt_traffic_light", missing) == "green",
        )
    first_non_green =
        _reduced_mpcc_cascade_retry_horizon_first_row(
            rows,
            row -> get(row, "rebuilt_attempt_traffic_light", missing) != "green",
        )
    first_nonterminal =
        _reduced_mpcc_cascade_retry_horizon_first_row(
            rows,
            row -> get(row, "nonterminal_replacement_applied", false) === true,
        )
    return Dict{String, Any}(
        "smoke_type" =>
            REDUCED_DCDFBA_MPCC_WINDOWED_CASCADE_RETRY_HORIZON_SMOKE_TYPE,
        "n_requested_cases" => requested_case_count,
        "n_cases" => length(rows),
        "n_completed_cases" =>
            count(row -> get(row, "case_status", "") == "completed", rows),
        "n_failed_cases" =>
            count(row -> get(row, "case_status", "") == "failed", rows),
        "n_retry_aware_results" => length(retry_aware_results),
        "n_cascade_results" => length(cascade_results),
        "cascade_rebuild_applied_count" =>
            count(row -> get(row, "cascade_rebuild_applied", false) === true, rows),
        "retry_replacement_applied_count" =>
            count(row -> get(row, "retry_replacement_applied", false) === true, rows),
        "nonterminal_replacement_count" =>
            count(row -> get(row, "nonterminal_replacement_applied", false) === true, rows),
        "downstream_resolve_case_count" =>
            count(
                row -> _reduced_mpcc_cascade_retry_horizon_float_or_zero(
                    get(row, "n_downstream_windows_requested", 0),
                ) > 0.0,
                rows,
            ),
        "green_rebuilt_count" =>
            count(row -> get(row, "rebuilt_attempt_traffic_light", missing) == "green", rows),
        "yellow_rebuilt_count" =>
            count(row -> get(row, "rebuilt_attempt_traffic_light", missing) == "yellow", rows),
        "red_rebuilt_count" =>
            count(row -> get(row, "rebuilt_attempt_traffic_light", missing) == "red", rows),
        "viability_recovered_count" =>
            count(row -> get(row, "viability_recovered_by_cascade", false) === true, rows),
        "target_recovered_count" =>
            count(row -> get(row, "target_recovered_by_cascade", false) === true, rows),
        "max_base_horizon_reached" =>
            _reduced_mpcc_cascade_retry_horizon_finite_max(rows, "base_horizon_reached"),
        "max_rebuilt_horizon_reached" =>
            _reduced_mpcc_cascade_retry_horizon_finite_max(rows, "rebuilt_horizon_reached"),
        "best_green_case_id" =>
            _reduced_mpcc_cascade_retry_horizon_value(
                best_green,
                "cascade_horizon_case_id",
            ),
        "best_green_target_horizon" =>
            _reduced_mpcc_cascade_retry_horizon_value(best_green, "target_horizon"),
        "best_green_rebuilt_horizon_reached" =>
            _reduced_mpcc_cascade_retry_horizon_value(
                best_green,
                "rebuilt_horizon_reached",
            ),
        "first_non_green_case_id" =>
            _reduced_mpcc_cascade_retry_horizon_value(
                first_non_green,
                "cascade_horizon_case_id",
            ),
        "first_non_green_target_horizon" =>
            _reduced_mpcc_cascade_retry_horizon_value(
                first_non_green,
                "target_horizon",
            ),
        "first_nonterminal_cascade_case_id" =>
            _reduced_mpcc_cascade_retry_horizon_value(
                first_nonterminal,
                "cascade_horizon_case_id",
            ),
        "first_nonterminal_cascade_target_horizon" =>
            _reduced_mpcc_cascade_retry_horizon_value(
                first_nonterminal,
                "target_horizon",
            ),
        "stopped_after_first_non_green" => stopped_after_first_non_green,
        "recommended_next_action" =>
            _reduced_mpcc_cascade_retry_horizon_recommended_action(
                rows,
                best_green,
                first_non_green,
                first_nonterminal,
            ),
        "outputs_written" => false,
        "smoke_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC cascade retry horizon smoke; diagnostic only and not a validated scientific simulation.",
    )
end

function _reduced_mpcc_cascade_retry_horizon_recommended_action(
    rows::Vector{Dict{String, Any}},
    best_green,
    first_non_green,
    first_nonterminal,
)::String
    isempty(rows) && return "run_cascade_retry_horizon_smoke"
    first_nonterminal === nothing &&
        return "run_nonterminal_cascade_retry_horizon_smoke"
    first_non_green !== nothing && best_green === nothing &&
        return "inspect_cascade_retry_horizon_failures"
    first_non_green !== nothing &&
        return "inspect_first_non_green_cascade_retry_horizon"
    best_green !== nothing && return "extend_cascade_retry_horizon_grid"
    return "inspect_cascade_retry_horizon_smoke"
end

function _reduced_mpcc_cascade_retry_horizon_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_cascade_retry_horizon_table_scalar(
                    get(row, column, missing),
                ) for row in rows
            ] for column in REDUCED_DCDFBA_MPCC_WINDOWED_CASCADE_RETRY_HORIZON_COLUMNS
        )...,
    )
end

function _reduced_mpcc_cascade_retry_horizon_n_windows(
    target_horizon::Float64,
    window_hours::Float64,
)::Int
    raw = target_horizon / window_hours
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || throw(
        ArgumentError(
            "Reduced MPCC cascade retry horizon smoke target_horizon $(target_horizon) " *
            "is not an integer multiple of window_hours $(window_hours).",
        ),
    )
    n_windows > 0 || throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke computed window count must be positive."),
    )
    return n_windows
end

function _reduced_mpcc_cascade_retry_horizon_validate_retry_iters(values)::Vector{Int}
    collection = Int.(collect(values))
    isempty(collection) && throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke retry_ipopt_max_iter_values must not be empty."),
    )
    all(value -> value > 0, collection) || throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke retry_ipopt_max_iter_values must be positive."),
    )
    return collection
end

function _reduced_mpcc_cascade_retry_horizon_validate_cascade_iter(value, retry_iters::Vector{Int})::Int
    selected = value === nothing ? maximum(retry_iters) : Int(value)
    selected > 0 || throw(
        ArgumentError("Reduced MPCC cascade retry horizon smoke cascade_ipopt_max_iter must be positive."),
    )
    return selected
end

function _reduced_mpcc_cascade_retry_horizon_case_id(index::Int)::String
    return "cascade_retry_horizon_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_cascade_retry_horizon_spec_or_metadata(spec, metadata, key::AbstractString)
    if spec !== nothing
        symbol = Symbol(key)
        haskey(spec, symbol) && return getfield(spec, symbol)
    end
    return get(metadata, String(key), missing)
end

function _reduced_mpcc_cascade_retry_horizon_spec_or_source(spec, source_metadata, key::AbstractString)
    if spec !== nothing
        symbol = Symbol(key)
        haskey(spec, symbol) && return getfield(spec, symbol)
    end
    return get(source_metadata, String(key), missing)
end

function _reduced_mpcc_cascade_retry_horizon_gain(base, rebuilt)
    _reduced_mpcc_cascade_retry_horizon_isfinite_number(base) || return missing
    _reduced_mpcc_cascade_retry_horizon_isfinite_number(rebuilt) || return missing
    return Float64(rebuilt) - Float64(base)
end

function _reduced_mpcc_cascade_retry_horizon_best_row(rows::Vector{Dict{String, Any}}, predicate)
    candidates = [row for row in rows if predicate(row)]
    isempty(candidates) && return nothing
    index = argmax([
        (
            _reduced_mpcc_cascade_retry_horizon_float_or_neginf(
                get(row, "rebuilt_horizon_reached", missing),
            ),
            _reduced_mpcc_cascade_retry_horizon_float_or_neginf(
                get(row, "target_horizon", missing),
            ),
        ) for row in candidates
    ])
    return candidates[index]
end

function _reduced_mpcc_cascade_retry_horizon_first_row(rows::Vector{Dict{String, Any}}, predicate)
    index = findfirst(predicate, rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_cascade_retry_horizon_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_cascade_retry_horizon_finite_max(
    rows::Vector{Dict{String, Any}},
    key::AbstractString,
)
    values = Float64[
        Float64(get(row, String(key), NaN)) for row in rows if
        _reduced_mpcc_cascade_retry_horizon_isfinite_number(
            get(row, String(key), missing),
        )
    ]
    isempty(values) && return missing
    return maximum(values)
end

function _reduced_mpcc_cascade_retry_horizon_float_or_zero(value)::Float64
    _reduced_mpcc_cascade_retry_horizon_isfinite_number(value) || return 0.0
    return Float64(value)
end

function _reduced_mpcc_cascade_retry_horizon_float_or_neginf(value)::Float64
    _reduced_mpcc_cascade_retry_horizon_isfinite_number(value) || return -Inf
    return Float64(value)
end

function _reduced_mpcc_cascade_retry_horizon_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_cascade_retry_horizon_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
