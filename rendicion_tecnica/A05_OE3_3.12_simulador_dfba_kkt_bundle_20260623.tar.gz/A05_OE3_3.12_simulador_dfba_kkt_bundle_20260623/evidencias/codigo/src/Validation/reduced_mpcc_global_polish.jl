const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_TYPE =
    "reduced_dcdfba_mpcc_global_polish_from_windowed_candidate"

const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_START_COLUMNS = [
    "block",
    "source_size",
    "target_size",
    "applied",
    "finite_value_count",
    "total_value_count",
    "max_abs_start",
]

const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_LEGACY =
    "legacy_zero_derivative"
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_GAP =
    "de_oliveira_gap"
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING =
    "de_oliveira_tracking"
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED =
    "seed"
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEQUENTIAL =
    "sequential_reference"
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_TRUST_REGION_DEFAULT_STATES = [
    "biomass",
    "glucose",
    "fructose",
    "ethanol",
    "total_sugar",
]
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_AROMA_TRACE_STATES = [
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_AMINO_ACID_TRACE_STATES = [
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
]
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_METABOLITE_TRACE_STATES = vcat(
    REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_AMINO_ACID_TRACE_STATES,
    REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_AROMA_TRACE_STATES,
)
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_SELECTION_RESIDUAL_KEYS = [
    "max_rhs_residual",
    "max_collocation_integration_residual",
    "max_continuity_residual",
    "max_initial_condition_residual",
    "max_mass_balance_residual",
    "max_stationarity_residual",
]

const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_STATES =
    REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_TRUST_REGION_DEFAULT_STATES

const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_FINAL_STATES = [
    "biomass",
    "total_sugar",
]
const REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_POST_SOLVE_FLUX_BOUND_PROJECTION_REPAIR_ENV =
    "MPCC_GLOBAL_POLISH_POST_SOLVE_FLUX_BOUND_PROJECTION_REPAIR"

"""
    ReducedDCDFBAMPCCWindowedStartValues

Monolithic start arrays assembled from a reduced MPCC windowed candidate. The
arrays are shaped like one global reduced MPCC collocation problem over the
reached windowed horizon. They are diagnostic starts only; they are not a
validated simulation.
"""
struct ReducedDCDFBAMPCCWindowedStartValues
    state_boundary::Matrix{Float64}
    state_collocation::Array{Float64, 3}
    state_derivative::Array{Float64, 3}
    flux::Array{Float64, 3}
    lower_bound_duals::Array{Float64, 3}
    upper_bound_duals::Array{Float64, 3}
    mass_balance_duals::Array{Float64, 3}
    metadata::Dict{String, Any}
end

"""
    ReducedDCDFBAMPCCGlobalPolishResult

Diagnostic result from re-solving one reached reduced MPCC windowed/cascade
candidate as a single global MPCC over the same horizon. This is a global
polish attempt, not a scientific simulation claim.
"""
struct ReducedDCDFBAMPCCGlobalPolishResult
    source_continuation::ReducedDCDFBAMPCCWindowedContinuationResult
    windowed_start_values::ReducedDCDFBAMPCCWindowedStartValues
    solve_attempt::ReducedDCDFBAMPCCSolveAttemptResult
    trajectory_candidate::Union{Nothing, ReducedDCDFBAMPCCTrajectoryCandidate}
    comparison_result::Union{Nothing, ReducedDCDFBAMPCCSequentialComparisonResult}
    accepted_candidate_diagnostics::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics}
    accepted_trajectory_candidate::Union{Nothing, ReducedDCDFBAMPCCTrajectoryCandidate}
    accepted_comparison_result::Union{Nothing, ReducedDCDFBAMPCCSequentialComparisonResult}
    start_summary_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    export_reduced_dcdfba_mpcc_windowed_start_values(starts, output_dir; overwrite=false)

Persist dense global-start arrays assembled from a windowed MPCC candidate.
These artifacts are intended for later global-polish runs without re-solving
the windowed source.
"""
function export_reduced_dcdfba_mpcc_windowed_start_values(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Reduced MPCC windowed start output_dir exists and is not a directory: $output_path")
    end
    paths = Dict{String, String}(
        "start_values" => joinpath(output_path, "windowed_start_values.jls"),
        "metadata" => joinpath(output_path, "metadata.toml"),
        "array_manifest" => joinpath(output_path, "array_manifest.csv"),
    )
    _reduced_mpcc_window_prepare_output_paths!(paths, overwrite)
    open(paths["start_values"], "w") do io
        serialize(io, starts)
    end
    open(paths["metadata"], "w") do io
        TOML.print(io, _toml_normalize(starts.metadata))
    end
    CSV.write(paths["array_manifest"], _reduced_mpcc_windowed_start_array_manifest(starts))
    return paths
end

function _reduced_mpcc_windowed_start_array_manifest(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
)::DataFrame
    return DataFrame([
        _reduced_mpcc_windowed_start_array_manifest_row(
            "state_boundary",
            starts.state_boundary,
        ),
        _reduced_mpcc_windowed_start_array_manifest_row(
            "state_collocation",
            starts.state_collocation,
        ),
        _reduced_mpcc_windowed_start_array_manifest_row(
            "state_derivative",
            starts.state_derivative,
        ),
        _reduced_mpcc_windowed_start_array_manifest_row("flux", starts.flux),
        _reduced_mpcc_windowed_start_array_manifest_row(
            "lower_bound_duals",
            starts.lower_bound_duals,
        ),
        _reduced_mpcc_windowed_start_array_manifest_row(
            "upper_bound_duals",
            starts.upper_bound_duals,
        ),
        _reduced_mpcc_windowed_start_array_manifest_row(
            "mass_balance_duals",
            starts.mass_balance_duals,
        ),
    ])
end

function _reduced_mpcc_windowed_start_array_manifest_row(
    block::AbstractString,
    values::AbstractArray{<:Real},
)::NamedTuple
    finite_count = 0
    max_abs = 0.0
    for value in values
        float_value = Float64(value)
        if isfinite(float_value)
            finite_count += 1
            max_abs = max(max_abs, abs(float_value))
        end
    end
    total_count = length(values)
    return (
        block = String(block),
        dimensions = join(size(values), "x"),
        finite_value_count = finite_count,
        total_value_count = total_count,
        all_finite = finite_count == total_count,
        max_abs_value = max_abs,
    )
end

function load_reduced_dcdfba_mpcc_windowed_start_values(
    path_or_dir::AbstractString,
)::ReducedDCDFBAMPCCWindowedStartValues
    input_path = normpath(String(path_or_dir))
    start_path =
        isdir(input_path) ? joinpath(input_path, "windowed_start_values.jls") : input_path
    isfile(start_path) || throw(
        ArgumentError("Reduced MPCC windowed start values file not found: $start_path"),
    )
    starts = open(start_path, "r") do io
        deserialize(io)
    end
    starts isa ReducedDCDFBAMPCCWindowedStartValues || throw(
        ArgumentError("Serialized reduced MPCC start artifact has unexpected type: $(typeof(starts))."),
    )
    return starts
end

function _reduced_mpcc_global_polish_start_values_path_available(
    path_or_dir::AbstractString,
)::Bool
    input_path = normpath(String(path_or_dir))
    return isfile(input_path) ||
           (isdir(input_path) && isfile(joinpath(input_path, "windowed_start_values.jls")))
end

function _reduced_mpcc_global_polish_export_pre_solve_start_values!(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    pre_solve_report::ReducedDCDFBAMPCCDiagnosticReport,
    pre_solve_metadata::Dict{String, Any},
    output_dir::AbstractString;
    overwrite::Bool = false,
    start_source_label::AbstractString = "windowed_candidate",
)::Dict{String, Any}
    output_path = normpath(String(output_dir))
    start_values_path = joinpath(output_path, "windowed_start_values.jls")
    metadata_path = joinpath(output_path, "metadata.toml")
    array_manifest_path = joinpath(output_path, "array_manifest.csv")
    merge!(starts.metadata, pre_solve_metadata)
    starts.metadata["start_type"] =
        "reduced_dcdfba_mpcc_global_polish_pre_solve_start_values"
    starts.metadata["global_polish_pre_solve_start_value_source"] =
        "pre_solve_start_values_after_initialization"
    starts.metadata["global_polish_pre_solve_start_source"] =
        String(start_source_label)
    starts.metadata["global_polish_pre_solve_start_exported"] = true
    starts.metadata["global_polish_pre_solve_start_output_dir"] = output_path
    starts.metadata["global_polish_pre_solve_start_values_path"] = start_values_path
    starts.metadata["global_polish_pre_solve_start_metadata_path"] = metadata_path
    starts.metadata["global_polish_pre_solve_start_array_manifest_path"] =
        array_manifest_path
    starts.metadata["global_polish_pre_solve_start_residuals_available"] =
        pre_solve_report.residuals_available
    starts.metadata["global_polish_pre_solve_start_residual_thresholds_satisfied"] =
        pre_solve_report.residual_thresholds_satisfied
    starts.metadata["global_polish_pre_solve_start_dominant_residual"] =
        pre_solve_report.dominant_residual
    starts.metadata["global_polish_pre_solve_start_ranked_residuals"] =
        copy(pre_solve_report.ranked_residuals)
    for (key, value) in pre_solve_report.residual_values
        starts.metadata["global_polish_pre_solve_start_$(String(key))"] =
            Float64(value)
    end
    for (key, value) in pre_solve_report.residual_thresholds
        starts.metadata["global_polish_pre_solve_start_$(String(key))_threshold"] =
            Float64(value)
    end
    for (key, value) in pre_solve_report.residual_ratios
        starts.metadata["global_polish_pre_solve_start_$(String(key))_ratio"] =
            Float64(value)
    end
    paths = export_reduced_dcdfba_mpcc_windowed_start_values(
        starts,
        output_path;
        overwrite = overwrite,
    )
    return Dict{String, Any}(
        "global_polish_pre_solve_start_export_requested" => true,
        "global_polish_pre_solve_start_exported" => true,
        "global_polish_pre_solve_start_output_dir" => output_path,
        "global_polish_pre_solve_start_values_path" => paths["start_values"],
        "global_polish_pre_solve_start_metadata_path" => paths["metadata"],
        "global_polish_pre_solve_start_array_manifest_path" =>
            paths["array_manifest"],
        "global_polish_pre_solve_start_value_source" =>
            "pre_solve_start_values_after_initialization",
        "global_polish_pre_solve_start_residuals_available" =>
            pre_solve_report.residuals_available,
        "global_polish_pre_solve_start_residual_thresholds_satisfied" =>
            pre_solve_report.residual_thresholds_satisfied,
        "global_polish_pre_solve_start_dominant_residual" =>
            pre_solve_report.dominant_residual,
    )
end

function load_reduced_dcdfba_mpcc_global_candidate_values(
    path_or_dir::AbstractString,
)::ReducedDCDFBAMPCCCandidateDiagnostics
    input_path = normpath(String(path_or_dir))
    candidate_path =
        isdir(input_path) ? joinpath(input_path, "global_candidate_values.jls") : input_path
    isfile(candidate_path) || throw(
        ArgumentError("Reduced MPCC global candidate values file not found: $candidate_path"),
    )
    candidate = open(candidate_path, "r") do io
        deserialize(io)
    end
    candidate isa ReducedDCDFBAMPCCCandidateDiagnostics || throw(
        ArgumentError("Serialized reduced MPCC global candidate has unexpected type: $(typeof(candidate))."),
    )
    return candidate
end

function _reduced_mpcc_global_polish_prefix_candidate_handoff_report(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)
    metadata = candidate.metadata
    solver_status = String(get(metadata, "candidate_solver_status", get(metadata, "solver_status", "missing")))
    primal_status = String(get(metadata, "candidate_primal_status", get(metadata, "primal_status", "missing")))
    residual_feasible = get(metadata, "candidate_residual_feasible", missing)
    trajectory_ready =
        get(metadata, "candidate_trajectory_extraction_ready", get(metadata, "trajectory_ready", missing))
    iteration_limit_residual_feasible =
        get(metadata, "candidate_iteration_limit_residual_feasible", missing)
    residual_thresholds_satisfied =
        get(metadata, "candidate_residual_thresholds_satisfied",
            get(metadata, "residual_thresholds_satisfied", missing))

    normalized_solver = uppercase(strip(solver_status))
    normalized_primal = uppercase(strip(primal_status))
    infeasible_status =
        occursin("INFEASIBLE", normalized_solver) ||
        occursin("INFEASIBLE", normalized_primal) ||
        normalized_primal in ("NO_SOLUTION", "UNKNOWN_RESULT_STATUS", "MISSING")
    residual_feasible_infeasible_status =
        infeasible_status && residual_thresholds_satisfied === true

    ready =
        (
            !infeasible_status &&
            (
                residual_feasible === true ||
                trajectory_ready === true ||
                iteration_limit_residual_feasible === true ||
                residual_thresholds_satisfied === true
            )
        ) ||
        residual_feasible_infeasible_status

    reason =
        if residual_feasible_infeasible_status
            "candidate_residual_thresholds_satisfied_infeasible_status_review"
        elseif infeasible_status
            "infeasible_solver_or_primal_status"
        elseif residual_feasible === true
            "candidate_residual_feasible"
        elseif trajectory_ready === true
            "candidate_trajectory_ready"
        elseif iteration_limit_residual_feasible === true
            "candidate_iteration_limit_residual_feasible"
        elseif residual_thresholds_satisfied === true
            "candidate_residual_thresholds_satisfied"
        else
            "candidate_not_residual_feasible"
        end

    return (
        ready = ready,
        reason = reason,
        solver_status = solver_status,
        primal_status = primal_status,
        residual_feasible = residual_feasible,
        trajectory_ready = trajectory_ready,
        iteration_limit_residual_feasible = iteration_limit_residual_feasible,
        residual_thresholds_satisfied = residual_thresholds_satisfied,
    )
end

function _reduced_mpcc_global_polish_output_candidate(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
)::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics}
    return result.accepted_candidate_diagnostics === nothing ?
           result.solve_attempt.candidate_diagnostics :
           result.accepted_candidate_diagnostics
end

function _reduced_mpcc_global_polish_output_comparison(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
)::Union{Nothing, ReducedDCDFBAMPCCSequentialComparisonResult}
    return result.accepted_comparison_result === nothing ?
           result.comparison_result :
           result.accepted_comparison_result
end

"""
    export_reduced_dcdfba_mpcc_global_polish(result, output_dir; overwrite=false)

Write diagnostic CSV/TOML artifacts for one reduced global MPCC polish attempt.
The export records solver/residual metadata and, when available, the global
candidate comparison against the sequential reference.
"""
function export_reduced_dcdfba_mpcc_global_polish(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
    candidate_values_dir::Union{Nothing, AbstractString} = nothing,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Reduced MPCC global polish output_dir exists and is not a directory: $output_path")
    end
    output_candidate = _reduced_mpcc_global_polish_output_candidate(result)
    output_comparison = _reduced_mpcc_global_polish_output_comparison(result)
    paths = Dict{String, String}(
        "metadata" => joinpath(output_path, "metadata.toml"),
        "start_summary" => joinpath(output_path, "start_summary.csv"),
        "residual_report" => joinpath(output_path, "residual_report.csv"),
        "solve_metadata" => joinpath(output_path, "solve_metadata.csv"),
    )
    nlp_block_violation_rows =
        _reduced_mpcc_global_polish_nlp_block_violation_rows(result)
    if nlp_block_violation_rows !== nothing
        paths["nlp_block_violations"] = joinpath(output_path, "nlp_block_violations.csv")
    end
    if output_comparison !== nothing
        paths["comparison_summary"] = joinpath(output_path, "comparison_summary.csv")
        paths["comparison_state_metrics"] = joinpath(output_path, "comparison_state_metrics.csv")
        paths["comparison_aligned_timeseries"] =
            joinpath(output_path, "comparison_aligned_timeseries.csv")
        if _reduced_mpcc_global_polish_has_three_way_comparison(result)
            paths["three_way_aligned_timeseries"] =
                joinpath(output_path, "three_way_aligned_timeseries.csv")
            paths["three_way_state_metrics"] =
                joinpath(output_path, "three_way_state_metrics.csv")
        end
    end
    if output_candidate !== nothing
        values_dir = candidate_values_dir === nothing ?
            joinpath(output_path, "global_candidate_values") :
            normpath(String(candidate_values_dir))
        paths["candidate_values_jls"] = joinpath(values_dir, "global_candidate_values.jls")
        paths["candidate_state_boundary_values"] =
            joinpath(values_dir, "state_boundary_values.csv")
        paths["candidate_state_collocation_values"] =
            joinpath(values_dir, "state_collocation_values.csv")
        paths["candidate_flux_values"] = joinpath(values_dir, "flux_values.csv")
        paths["candidate_bound_dual_values"] = joinpath(values_dir, "bound_dual_values.csv")
        paths["candidate_mass_balance_dual_values"] =
            joinpath(values_dir, "mass_balance_dual_values.csv")
    end
    _reduced_mpcc_window_prepare_output_paths!(paths, overwrite)

    CSV.write(paths["start_summary"], result.start_summary_table)
    CSV.write(
        paths["residual_report"],
        _reduced_mpcc_global_polish_dict_table(result.solve_attempt.residual_report),
    )
    CSV.write(
        paths["solve_metadata"],
        _reduced_mpcc_global_polish_dict_table(result.solve_attempt.metadata),
    )
    if nlp_block_violation_rows !== nothing
        CSV.write(paths["nlp_block_violations"], DataFrame(nlp_block_violation_rows))
    end
    if output_comparison !== nothing
        CSV.write(paths["comparison_summary"], output_comparison.summary_table)
        CSV.write(paths["comparison_state_metrics"], output_comparison.state_metrics_table)
        CSV.write(
            paths["comparison_aligned_timeseries"],
            output_comparison.aligned_timeseries_table,
        )
        if haskey(paths, "three_way_aligned_timeseries")
            three_way = _reduced_mpcc_global_polish_three_way_timeseries(result)
            CSV.write(paths["three_way_aligned_timeseries"], three_way)
            CSV.write(
                paths["three_way_state_metrics"],
                _reduced_mpcc_global_polish_three_way_state_metrics(three_way),
            )
        end
    end
    if output_candidate !== nothing
        _write_reduced_mpcc_global_polish_candidate_values!(
            paths,
            output_candidate,
        )
    end
    open(paths["metadata"], "w") do io
        TOML.print(io, _toml_normalize(result.metadata))
    end
    return paths
end

function write_reduced_dcdfba_mpcc_global_polish_report(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    diagnostics_dir = joinpath(output_path, "diagnostics")
    plots_dir = joinpath(output_path, "plots")
    result.metadata["outputs_written"] = true
    result.metadata["output_dir"] = output_path
    result.metadata["diagnostic_output_dir"] = diagnostics_dir
    result.metadata["plot_output_dir"] = plots_dir

    paths = Dict{String, String}()
    for (key, path) in export_reduced_dcdfba_mpcc_global_polish(
        result,
        diagnostics_dir;
        overwrite = overwrite,
        candidate_values_dir = joinpath(output_path, "global_candidate_values"),
    )
        prefix = startswith(key, "candidate_") ? "global_" : "diagnostics_"
        paths["$(prefix)$(key)"] = path
    end
    output_comparison = _reduced_mpcc_global_polish_output_comparison(result)
    if output_comparison !== nothing
        plot_result = ReducedDCDFBAMPCCWindowedContinuationResult(
            DataFrame(),
            ReducedDCDFBAMPCCSequentialComparisonResult[],
            nothing,
            nothing,
            output_comparison.state_metrics_table,
            output_comparison.aligned_timeseries_table,
            copy(result.metadata),
        )
        for (key, path) in write_reduced_dcdfba_mpcc_windowed_plots(
            plot_result,
            plots_dir;
            overwrite = overwrite,
        )
            paths["plot_$(key)"] = path
        end
        for (key, path) in write_reduced_dcdfba_mpcc_global_three_way_plots(
            result,
            plots_dir;
            overwrite = overwrite,
        )
            paths["plot_three_way_$(key)"] = path
        end
    end
    return paths
end

"""
    write_reduced_dcdfba_mpcc_global_polish_recovery(result, output_dir; ...)

Write a compact recovery bundle for a global MPCC polish result. This is meant
to run before risky CSV/plot exports so long solves leave a serialized result
that can be inspected or re-exported later.
"""
function write_reduced_dcdfba_mpcc_global_polish_recovery(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
    output_dir::AbstractString;
    fallback_root::Union{Nothing, AbstractString} = nothing,
    error = nothing,
    stacktrace = nothing,
    overwrite::Bool = true,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    primary_dir = joinpath(output_path, "recovery")
    recovery_root = fallback_root === nothing ?
        get(
            ENV,
            "MPCC_RECOVERY_OUTPUT_ROOT",
            joinpath(tempdir(), "FermentationDFBA", "mpcc_recovery"),
        ) :
        String(fallback_root)
    fallback_dir = joinpath(
        normpath(recovery_root),
        "global_polish_$(round(Int, time() * 1000))",
    )

    last_error = nothing
    for recovery_dir in (primary_dir, fallback_dir)
        try
            return _write_reduced_dcdfba_mpcc_global_polish_recovery_bundle(
                result,
                recovery_dir;
                intended_output_dir = output_path,
                error = error,
                stacktrace = stacktrace,
                overwrite = overwrite,
            )
        catch err
            last_error = err
        end
    end
    throw(last_error)
end

"""
    safe_write_reduced_dcdfba_mpcc_global_polish_report(result, output_dir; ...)

Write a recovery bundle first, then attempt the full report export. If the full
export fails, write a second recovery bundle with the export error and return
those recovery paths instead of throwing.
"""
function safe_write_reduced_dcdfba_mpcc_global_polish_report(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
    fallback_root::Union{Nothing, AbstractString} = nothing,
)::Dict{String, String}
    pre_export_recovery = write_reduced_dcdfba_mpcc_global_polish_recovery(
        result,
        output_dir;
        fallback_root = fallback_root,
        overwrite = true,
    )
    result.metadata["recovery_written"] = true
    result.metadata["pre_export_recovery_dir"] = dirname(pre_export_recovery["recovery_result_jls"])

    try
        paths = write_reduced_dcdfba_mpcc_global_polish_report(
            result,
            output_dir;
            overwrite = overwrite,
        )
        paths["recovery_result_jls"] = pre_export_recovery["recovery_result_jls"]
        paths["recovery_metadata"] = pre_export_recovery["recovery_metadata"]
        result.metadata["report_export_failed"] = false
        return paths
    catch err
        bt = catch_backtrace()
        result.metadata["outputs_written"] = false
        result.metadata["report_export_failed"] = true
        result.metadata["report_export_error_type"] = string(typeof(err))
        result.metadata["report_export_error_message"] = sprint(showerror, err)
        recovery = write_reduced_dcdfba_mpcc_global_polish_recovery(
            result,
            output_dir;
            fallback_root = fallback_root,
            error = err,
            stacktrace = bt,
            overwrite = true,
        )
        recovery["report_export_error_type"] = string(typeof(err))
        recovery["report_export_error_message"] = sprint(showerror, err)
        return recovery
    end
end

function _write_reduced_dcdfba_mpcc_global_polish_recovery_bundle(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
    recovery_dir::AbstractString;
    intended_output_dir::AbstractString,
    error,
    stacktrace,
    overwrite::Bool,
)::Dict{String, String}
    recovery_path = normpath(String(recovery_dir))
    paths = Dict{String, String}(
        "recovery_result_jls" => joinpath(recovery_path, "global_polish_result.jls"),
        "recovery_metadata" => joinpath(recovery_path, "recovery_metadata.toml"),
        "recovery_error_report" => joinpath(recovery_path, "export_error.txt"),
    )
    if result.solve_attempt.candidate_diagnostics !== nothing
        paths["recovery_candidate_diagnostics_jls"] =
            joinpath(recovery_path, "candidate_diagnostics.jls")
    end
    output_candidate = _reduced_mpcc_global_polish_output_candidate(result)
    if output_candidate !== nothing
        paths["recovery_accepted_candidate_diagnostics_jls"] =
            joinpath(recovery_path, "accepted_candidate_diagnostics.jls")
    end
    _reduced_mpcc_window_prepare_output_paths!(paths, overwrite)

    if haskey(paths, "recovery_candidate_diagnostics_jls")
        open(paths["recovery_candidate_diagnostics_jls"], "w") do io
            serialize(io, result.solve_attempt.candidate_diagnostics)
        end
    end
    if haskey(paths, "recovery_accepted_candidate_diagnostics_jls")
        open(paths["recovery_accepted_candidate_diagnostics_jls"], "w") do io
            serialize(io, output_candidate)
        end
    end
    open(paths["recovery_result_jls"], "w") do io
        serialize(io, result)
    end

    metadata = Dict{String, Any}(
        "recovery_type" => "reduced_dcdfba_mpcc_global_polish_recovery",
        "recovery_dir" => recovery_path,
        "intended_output_dir" => intended_output_dir,
        "solver_status" => get(result.metadata, "solver_status", missing),
        "primal_status" => get(result.metadata, "primal_status", missing),
        "candidate_values_available" =>
            get(result.metadata, "candidate_values_available", missing),
        "candidate_residual_feasible" =>
            get(result.metadata, "candidate_residual_feasible", missing),
        "candidate_trajectory_ready" =>
            get(result.metadata, "candidate_trajectory_ready", missing),
        "selected_candidate_source" =>
            get(result.metadata, "selected_candidate_source", missing),
        "selected_candidate_residual_feasible" =>
            get(result.metadata, "selected_candidate_residual_feasible", missing),
        "selected_candidate_trajectory_ready" =>
            get(result.metadata, "selected_candidate_trajectory_ready", missing),
        "solve_elapsed_seconds" => get(result.metadata, "solve_elapsed_seconds", missing),
        "global_horizon" => get(result.metadata, "global_horizon", missing),
    )
    if error !== nothing
        metadata["export_error_type"] = string(typeof(error))
        metadata["export_error_message"] = sprint(showerror, error)
    end
    open(paths["recovery_metadata"], "w") do io
        TOML.print(io, _toml_normalize(metadata))
    end
    open(paths["recovery_error_report"], "w") do io
        if error === nothing
            println(io, "No export error recorded. Recovery was written before full report export.")
        else
            println(io, "Export error type: ", typeof(error))
            println(io, "Export error message:")
            showerror(io, error)
            println(io)
            if stacktrace !== nothing
                println(io)
                println(io, "Stacktrace:")
                showerror(io, error, stacktrace)
                println(io)
            end
        end
    end
    return paths
end

function _reduced_mpcc_global_polish_has_three_way_comparison(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
)::Bool
    output_comparison = _reduced_mpcc_global_polish_output_comparison(result)
    output_comparison === nothing && return false
    nrow(result.source_continuation.aligned_timeseries_table) > 0 || return false
    nrow(output_comparison.aligned_timeseries_table) > 0 || return false
    return true
end

function _reduced_mpcc_global_polish_three_way_timeseries(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
)::DataFrame
    _reduced_mpcc_global_polish_has_three_way_comparison(result) || return DataFrame()
    source = result.source_continuation.aligned_timeseries_table
    global_table =
        _reduced_mpcc_global_polish_output_comparison(result).aligned_timeseries_table
    "time" in names(source) ||
        throw(ArgumentError("Source aligned timeseries is missing time column."))
    "time" in names(global_table) ||
        throw(ArgumentError("Global aligned timeseries is missing time column."))
    source_time = Float64.(source[!, "time"])
    global_time = Float64.(global_table[!, "time"])
    source_indices = Int[]
    global_indices = Int[]
    for (global_index, time_value) in enumerate(global_time)
        source_index = findfirst(
            source_value -> isapprox(source_value, time_value; atol = 1.0e-8, rtol = 1.0e-10),
            source_time,
        )
        source_index === nothing && continue
        push!(source_indices, source_index)
        push!(global_indices, global_index)
    end
    isempty(global_indices) && return DataFrame()

    table = DataFrame("time" => global_time[global_indices])
    prefixes = String[]
    for column in names(global_table)
        endswith(column, "_mpcc_candidate") || continue
        prefix = first(split(column, "_mpcc_candidate"; limit = 2))
        "$(prefix)_sequential" in names(global_table) || continue
        "$(prefix)_mpcc_candidate" in names(source) || continue
        "$(prefix)_sequential" in names(source) || continue
        push!(prefixes, prefix)
    end
    for prefix in unique(prefixes)
        sequential = Float64.(global_table[global_indices, "$(prefix)_sequential"])
        windowed = Float64.(source[source_indices, "$(prefix)_mpcc_candidate"])
        global_candidate = Float64.(global_table[global_indices, "$(prefix)_mpcc_candidate"])
        table[!, "$(prefix)_sequential"] = sequential
        table[!, "$(prefix)_windowed_seed"] = windowed
        table[!, "$(prefix)_global_candidate"] = global_candidate
        table[!, "$(prefix)_difference_seed_minus_sequential"] = windowed .- sequential
        table[!, "$(prefix)_difference_global_minus_sequential"] =
            global_candidate .- sequential
        table[!, "$(prefix)_difference_global_minus_seed"] =
            global_candidate .- windowed
    end
    return table
end

function _reduced_mpcc_global_polish_three_way_state_metrics(table::DataFrame)::DataFrame
    nrow(table) == 0 && return DataFrame()
    rows = Dict{String, Any}[]
    prefixes = String[]
    for column in names(table)
        endswith(column, "_sequential") || continue
        prefix = first(split(column, "_sequential"; limit = 2))
        "$(prefix)_windowed_seed" in names(table) || continue
        "$(prefix)_global_candidate" in names(table) || continue
        push!(prefixes, prefix)
    end
    for prefix in unique(prefixes)
        sequential = Float64.(table[!, "$(prefix)_sequential"])
        windowed = Float64.(table[!, "$(prefix)_windowed_seed"])
        global_candidate = Float64.(table[!, "$(prefix)_global_candidate"])
        seed_diff = windowed .- sequential
        global_diff = global_candidate .- sequential
        global_seed_diff = global_candidate .- windowed
        push!(
            rows,
            Dict{String, Any}(
                "state_name" => prefix,
                "initial_sequential" => sequential[begin],
                "initial_windowed_seed" => windowed[begin],
                "initial_global_candidate" => global_candidate[begin],
                "final_sequential" => sequential[end],
                "final_windowed_seed" => windowed[end],
                "final_global_candidate" => global_candidate[end],
                "final_difference_seed_minus_sequential" => seed_diff[end],
                "final_difference_global_minus_sequential" => global_diff[end],
                "final_difference_global_minus_seed" => global_seed_diff[end],
                "seed_max_abs_difference" => maximum(abs.(seed_diff)),
                "global_max_abs_difference" => maximum(abs.(global_diff)),
                "global_vs_seed_max_abs_difference" => maximum(abs.(global_seed_diff)),
                "seed_rmse" => sqrt(sum(abs2, seed_diff) / length(seed_diff)),
                "global_rmse" => sqrt(sum(abs2, global_diff) / length(global_diff)),
                "global_vs_seed_rmse" =>
                    sqrt(sum(abs2, global_seed_diff) / length(global_seed_diff)),
                "seed_relative_rmse" =>
                    _reduced_mpcc_global_polish_relative_rmse(seed_diff, sequential, windowed),
                "global_relative_rmse" => _reduced_mpcc_global_polish_relative_rmse(
                    global_diff,
                    sequential,
                    global_candidate,
                ),
                "global_vs_seed_relative_rmse" =>
                    _reduced_mpcc_global_polish_relative_rmse(
                        global_seed_diff,
                        windowed,
                        global_candidate,
                    ),
            ),
        )
    end
    return DataFrame(rows)
end

function _reduced_mpcc_global_polish_relative_rmse(diff, first_series, second_series)::Float64
    rmse = sqrt(sum(abs2, diff) / length(diff))
    denominator = max(
        maximum(abs.(Float64.(first_series))),
        maximum(abs.(Float64.(second_series))),
        eps(Float64),
    )
    return rmse / denominator
end

function _write_reduced_mpcc_global_polish_candidate_values!(
    paths::Dict{String, String},
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Nothing
    open(paths["candidate_values_jls"], "w") do io
        serialize(io, candidate)
    end
    _write_reduced_mpcc_global_polish_state_boundary_values(
        paths["candidate_state_boundary_values"],
        candidate,
    )
    _write_reduced_mpcc_global_polish_state_collocation_values(
        paths["candidate_state_collocation_values"],
        candidate,
    )
    _write_reduced_mpcc_global_polish_flux_values(paths["candidate_flux_values"], candidate)
    _write_reduced_mpcc_global_polish_bound_dual_values(
        paths["candidate_bound_dual_values"],
        candidate,
    )
    _write_reduced_mpcc_global_polish_mass_balance_dual_values(
        paths["candidate_mass_balance_dual_values"],
        candidate,
    )
    return nothing
end

function _write_reduced_mpcc_global_polish_state_boundary_values(
    path::AbstractString,
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Nothing
    state_names = _reduced_mpcc_global_polish_candidate_state_names(candidate)
    times = _reduced_mpcc_global_polish_candidate_time_vector(
        candidate,
        "candidate_boundary_times",
        size(candidate.state_boundary, 2),
    )
    open(path, "w") do io
        println(io, "time,state_index,state_name,value")
        for t in eachindex(times), state_index in axes(candidate.state_boundary, 1)
            _reduced_mpcc_global_polish_write_csv_row(
                io,
                times[t],
                state_index,
                state_names[state_index],
                candidate.state_boundary[state_index, t],
            )
        end
    end
    return nothing
end

function _write_reduced_mpcc_global_polish_state_collocation_values(
    path::AbstractString,
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Nothing
    state_names = _reduced_mpcc_global_polish_candidate_state_names(candidate)
    nfe = size(candidate.state_collocation, 2)
    degree = size(candidate.state_collocation, 3)
    times = _reduced_mpcc_global_polish_candidate_time_vector(
        candidate,
        "candidate_collocation_times",
        nfe * degree,
    )
    open(path, "w") do io
        println(io, "element,collocation,time,state_index,state_name,state_value,state_derivative")
        for e in 1:nfe, j in 1:degree
            time_index = (e - 1) * degree + j
            for state_index in axes(candidate.state_collocation, 1)
                _reduced_mpcc_global_polish_write_csv_row(
                    io,
                    e,
                    j,
                    times[time_index],
                    state_index,
                    state_names[state_index],
                    candidate.state_collocation[state_index, e, j],
                    candidate.state_derivative[state_index, e, j],
                )
            end
        end
    end
    return nothing
end

function _write_reduced_mpcc_global_polish_flux_values(
    path::AbstractString,
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Nothing
    reaction_ids = _reduced_mpcc_global_polish_candidate_reaction_ids(candidate)
    nfe = size(candidate.flux, 2)
    degree = size(candidate.flux, 3)
    times = _reduced_mpcc_global_polish_candidate_time_vector(
        candidate,
        "candidate_collocation_times",
        nfe * degree,
    )
    open(path, "w") do io
        println(io, "element,collocation,time,reaction_index,reaction_id,flux")
        for e in 1:nfe, j in 1:degree
            time_index = (e - 1) * degree + j
            for reaction_index in axes(candidate.flux, 1)
                _reduced_mpcc_global_polish_write_csv_row(
                    io,
                    e,
                    j,
                    times[time_index],
                    reaction_index,
                    reaction_ids[reaction_index],
                    candidate.flux[reaction_index, e, j],
                )
            end
        end
    end
    return nothing
end

function _write_reduced_mpcc_global_polish_bound_dual_values(
    path::AbstractString,
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Nothing
    reaction_ids = _reduced_mpcc_global_polish_candidate_reaction_ids(candidate)
    nfe = size(candidate.lower_bound_duals, 2)
    degree = size(candidate.lower_bound_duals, 3)
    times = _reduced_mpcc_global_polish_candidate_time_vector(
        candidate,
        "candidate_collocation_times",
        nfe * degree,
    )
    open(path, "w") do io
        println(io, "element,collocation,time,reaction_index,reaction_id,lower_bound_dual,upper_bound_dual")
        for e in 1:nfe, j in 1:degree
            time_index = (e - 1) * degree + j
            for reaction_index in axes(candidate.lower_bound_duals, 1)
                _reduced_mpcc_global_polish_write_csv_row(
                    io,
                    e,
                    j,
                    times[time_index],
                    reaction_index,
                    reaction_ids[reaction_index],
                    candidate.lower_bound_duals[reaction_index, e, j],
                    candidate.upper_bound_duals[reaction_index, e, j],
                )
            end
        end
    end
    return nothing
end

function _write_reduced_mpcc_global_polish_mass_balance_dual_values(
    path::AbstractString,
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Nothing
    metabolite_ids = _reduced_mpcc_global_polish_candidate_metabolite_ids(candidate)
    nfe = size(candidate.mass_balance_duals, 2)
    degree = size(candidate.mass_balance_duals, 3)
    times = _reduced_mpcc_global_polish_candidate_time_vector(
        candidate,
        "candidate_collocation_times",
        nfe * degree,
    )
    open(path, "w") do io
        println(io, "element,collocation,time,metabolite_index,metabolite_id,mass_balance_dual")
        for e in 1:nfe, j in 1:degree
            time_index = (e - 1) * degree + j
            for metabolite_index in axes(candidate.mass_balance_duals, 1)
                _reduced_mpcc_global_polish_write_csv_row(
                    io,
                    e,
                    j,
                    times[time_index],
                    metabolite_index,
                    metabolite_ids[metabolite_index],
                    candidate.mass_balance_duals[metabolite_index, e, j],
                )
            end
        end
    end
    return nothing
end

function _reduced_mpcc_global_polish_candidate_state_names(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Vector{String}
    fallback = ["state_$(i)" for i in axes(candidate.state_boundary, 1)]
    return _reduced_mpcc_global_polish_string_vector(
        get(candidate.metadata, "candidate_state_names", fallback),
        length(fallback),
        fallback,
    )
end

function _reduced_mpcc_global_polish_candidate_reaction_ids(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Vector{String}
    fallback = ["reaction_$(i)" for i in axes(candidate.flux, 1)]
    return _reduced_mpcc_global_polish_string_vector(
        get(candidate.metadata, "candidate_flux_rxn_ids", fallback),
        length(fallback),
        fallback,
    )
end

function _reduced_mpcc_global_polish_candidate_metabolite_ids(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Vector{String}
    count = size(candidate.mass_balance_duals, 1)
    return ["metabolite_$(i)" for i in 1:count]
end

function _reduced_mpcc_global_polish_string_vector(values, expected_length::Int, fallback)::Vector{String}
    collected =
        try
            String.(collect(values))
        catch
            String.(collect(fallback))
        end
    length(collected) == expected_length || return String.(collect(fallback))
    return collected
end

function _reduced_mpcc_global_polish_candidate_time_vector(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
    key::AbstractString,
    expected_length::Int,
)::Vector{Float64}
    raw = get(candidate.metadata, String(key), nothing)
    if raw !== nothing
        values =
            try
                Float64.(collect(raw))
            catch
                Float64[]
            end
        length(values) == expected_length && all(isfinite, values) && return values
    end
    return collect(0.0:(expected_length - 1.0))
end

function _reduced_mpcc_global_polish_write_csv_row(io::IO, values...)::Nothing
    println(io, join((_reduced_mpcc_global_polish_csv_cell(value) for value in values), ","))
    return nothing
end

function _reduced_mpcc_global_polish_csv_cell(value)::String
    if value === missing || value === nothing
        return ""
    end
    text = string(value)
    if occursin(",", text) || occursin("\"", text) || occursin("\n", text) || occursin("\r", text)
        return "\"" * replace(text, "\"" => "\"\"") * "\""
    end
    return text
end

function _reduced_mpcc_global_polish_push_top_stationarity_row!(
    rows::Vector{NamedTuple},
    row::NamedTuple,
    max_rows::Int,
)::Nothing
    max_rows <= 0 && return nothing
    if length(rows) < max_rows
        push!(rows, row)
        return nothing
    end
    min_index = 1
    min_value = rows[1].abs_residual
    for index in 2:length(rows)
        if rows[index].abs_residual < min_value
            min_index = index
            min_value = rows[index].abs_residual
        end
    end
    row.abs_residual > min_value && (rows[min_index] = row)
    return nothing
end

function _reduced_mpcc_global_polish_stationarity_top_residual_rows(
    problem::ReducedDCDFBAMPCCSmokeProblem,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    max_rows::Int,
)::Vector{NamedTuple}
    max_rows <= 0 && return NamedTuple[]
    state_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.state_collocation)
    flux_values = _reduced_dcdfba_start_array_or_nothing(problem.nlp.flux)
    lower_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.lower_bound_duals)
    upper_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.bound_feasibility.upper_bound_duals)
    mass_dual_values =
        _reduced_dcdfba_start_array_or_nothing(problem.stationarity.mass_balance_duals)
    any(
        value -> value === nothing,
        (state_values, flux_values, lower_dual_values, upper_dual_values, mass_dual_values),
    ) && return NamedTuple[]

    model = problem.nlp.kkt_problem.model
    nfe = problem.nlp.dimensions.nfe
    degree = problem.nlp.dimensions.collocation_degree
    collocation_times = haskey(starts.metadata, "source_collocation_times") ?
                        Float64.(starts.metadata["source_collocation_times"]) :
                        Float64[]
    rows = NamedTuple[]
    for e in 1:nfe, j in 1:degree
        mass_dual = mass_dual_values[:, e, j]
        bounds = _reduced_dcdfba_numeric_flux_bounds(problem, e, j, state_values)
        coefficients =
            _reduced_dcdfba_numeric_stationarity_coefficients(problem, e, j, state_values)
        stoichiometric_dual_term = transpose(model.S) * mass_dual
        residuals =
            coefficients .+ stoichiometric_dual_term .+
            lower_dual_values[:, e, j] .+
            upper_dual_values[:, e, j]
        time_index = (e - 1) * degree + j
        time =
            1 <= time_index <= length(collocation_times) ? collocation_times[time_index] : NaN
        for r in eachindex(residuals)
            residual = Float64(residuals[r])
            row = (
                abs_residual = abs(residual),
                residual = residual,
                reaction_index = r,
                reaction_id = r <= length(model.rxn_ids) ? model.rxn_ids[r] : string(r),
                element = e,
                collocation_index = j,
                time = time,
                objective_coefficient = Float64(coefficients[r]),
                stoichiometric_dual_term = Float64(stoichiometric_dual_term[r]),
                lower_bound_dual = Float64(lower_dual_values[r, e, j]),
                upper_bound_dual = Float64(upper_dual_values[r, e, j]),
                flux = Float64(flux_values[r, e, j]),
                lower_bound = Float64(bounds.lb[r]),
                upper_bound = Float64(bounds.ub[r]),
            )
            _reduced_mpcc_global_polish_push_top_stationarity_row!(rows, row, max_rows)
        end
    end
    sort!(rows; by = row -> row.abs_residual, rev = true)
    return rows
end

function _reduced_mpcc_global_polish_write_stationarity_top_residuals(
    path::AbstractString,
    rows::Vector{NamedTuple},
)::Nothing
    mkpath(dirname(path))
    open(path, "w") do io
        _reduced_mpcc_global_polish_write_csv_row(
            io,
            "rank",
            "abs_residual",
            "residual",
            "reaction_index",
            "reaction_id",
            "element",
            "collocation_index",
            "time",
            "objective_coefficient",
            "stoichiometric_dual_term",
            "lower_bound_dual",
            "upper_bound_dual",
            "flux",
            "lower_bound",
            "upper_bound",
        )
        for (rank, row) in enumerate(rows)
            _reduced_mpcc_global_polish_write_csv_row(
                io,
                rank,
                row.abs_residual,
                row.residual,
                row.reaction_index,
                row.reaction_id,
                row.element,
                row.collocation_index,
                row.time,
                row.objective_coefficient,
                row.stoichiometric_dual_term,
                row.lower_bound_dual,
                row.upper_bound_dual,
                row.flux,
                row.lower_bound,
                row.upper_bound,
            )
        end
    end
    return nothing
end

function _reduced_mpcc_global_polish_maybe_write_stationarity_top_residuals!(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    pre_solve_start_output_dir::Union{Nothing, AbstractString},
    max_rows::Int,
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "global_polish_stationarity_top_residuals_requested" => max_rows,
        "global_polish_stationarity_top_residuals_written" => false,
    )
    max_rows <= 0 && return metadata
    output_root =
        pre_solve_start_output_dir === nothing ||
        isempty(strip(String(pre_solve_start_output_dir))) ?
        pwd() :
        dirname(normpath(String(pre_solve_start_output_dir)))
    output_path = joinpath(output_root, "pre_solve_stationarity_top_residuals.csv")
    _reduced_mpcc_global_polish_artifact_source_trace(
        "stationarity_top_residuals_begin rows=$(max_rows) path=$(output_path)",
    )
    rows = _reduced_mpcc_global_polish_stationarity_top_residual_rows(
        problem.smoke_problem,
        starts,
        max_rows,
    )
    _reduced_mpcc_global_polish_write_stationarity_top_residuals(output_path, rows)
    metadata["global_polish_stationarity_top_residuals_written"] = true
    metadata["global_polish_stationarity_top_residuals_path"] = output_path
    metadata["global_polish_stationarity_top_residuals_row_count"] = length(rows)
    if !isempty(rows)
        first_row = first(rows)
        metadata["global_polish_stationarity_top_residuals_max_abs"] =
            first_row.abs_residual
        metadata["global_polish_stationarity_top_residuals_max_reaction_index"] =
            first_row.reaction_index
        metadata["global_polish_stationarity_top_residuals_max_reaction_id"] =
            first_row.reaction_id
        metadata["global_polish_stationarity_top_residuals_max_element"] =
            first_row.element
        metadata["global_polish_stationarity_top_residuals_max_collocation_index"] =
            first_row.collocation_index
        metadata["global_polish_stationarity_top_residuals_max_time"] = first_row.time
        println(
            "stationarity_top_residual: rank=1 abs_residual=$(first_row.abs_residual) " *
            "reaction=$(first_row.reaction_id) element=$(first_row.element) " *
            "collocation=$(first_row.collocation_index) time=$(first_row.time)",
        )
    end
    _reduced_mpcc_global_polish_artifact_source_trace(
        "stationarity_top_residuals_done rows=$(length(rows))",
    )
    return metadata
end

function _reduced_mpcc_global_polish_parse_element_indices(
    raw::AbstractString,
    nfe::Int;
    name::AbstractString,
)::Union{Nothing, Vector{Int}}
    text = lowercase(strip(String(raw)))
    isempty(text) && return nothing
    text in ("all", "*", "full") && return nothing
    indices = Int[]
    for token in split(text, r"[,;\s]+")
        isempty(token) && continue
        if startswith(token, "tail:")
            count_text = strip(token[(lastindex("tail:") + 1):end])
            count = tryparse(Int, count_text)
            count === nothing && throw(
                ArgumentError("Environment variable $name has invalid tail count: $token"),
            )
            count > 0 || throw(
                ArgumentError("Environment variable $name tail count must be positive: $token"),
            )
            append!(indices, max(1, nfe - count + 1):nfe)
        elseif occursin(":", token)
            parts = split(token, ":")
            length(parts) == 2 || throw(
                ArgumentError("Environment variable $name has invalid range: $token"),
            )
            first_index = tryparse(Int, strip(parts[1]))
            last_index = tryparse(Int, strip(parts[2]))
            (first_index === nothing || last_index === nothing) && throw(
                ArgumentError("Environment variable $name has invalid range: $token"),
            )
            first_index <= last_index || throw(
                ArgumentError("Environment variable $name range must be ascending: $token"),
            )
            append!(indices, first_index:last_index)
        else
            index = tryparse(Int, token)
            index === nothing && throw(
                ArgumentError("Environment variable $name has invalid element index: $token"),
            )
            push!(indices, index)
        end
    end
    isempty(indices) && return Int[]
    indices = sort!(unique!(indices))
    for index in indices
        1 <= index <= nfe || throw(
            ArgumentError(
                "Environment variable $name element index $index is outside 1:$nfe.",
            ),
        )
    end
    return indices
end

function _reduced_mpcc_global_polish_env_element_indices(
    name::AbstractString,
    nfe::Int,
)::Union{Nothing, Vector{Int}}
    return _reduced_mpcc_global_polish_parse_element_indices(
        get(ENV, String(name), ""),
        nfe;
        name = name,
    )
end

"""
    build_reduced_dcdfba_mpcc_windowed_start_values(continuation; require_complete=true)

Concatenate window-local reduced MPCC candidate arrays into monolithic start
arrays. Boundary states are joined without duplicating shared finite-element
boundaries; collocation, derivative, flux, and dual arrays are concatenated
along the finite-element dimension.
"""
function build_reduced_dcdfba_mpcc_windowed_start_values(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult;
    require_complete::Bool = true,
)::ReducedDCDFBAMPCCWindowedStartValues
    comparisons = continuation.window_comparisons
    isempty(comparisons) && throw(
        ArgumentError("Reduced MPCC global polish requires at least one source window comparison."),
    )
    if require_complete &&
       get(continuation.metadata, "continuation_completed", false) !== true
        throw(
            ArgumentError(
                "Reduced MPCC global polish requires a completed source continuation. " *
                "Set require_complete=false to build starts for the reached prefix only.",
            ),
        )
    end

    first_candidate = first(comparisons).trajectory_candidate.candidate_diagnostics
    n_states = size(first_candidate.state_boundary, 1)
    n_reactions = size(first_candidate.flux, 1)
    n_metabolites = size(first_candidate.mass_balance_duals, 1)
    degree = size(first_candidate.state_collocation, 3)
    degree == 3 || throw(
        ArgumentError("Reduced MPCC global polish currently supports only degree == 3."),
    )

    local_nfe_values = [
        _reduced_mpcc_global_polish_candidate_nfe(comparison) for comparison in comparisons
    ]
    total_nfe = sum(local_nfe_values)
    total_nfe > 0 || throw(
        ArgumentError("Reduced MPCC global polish source total nfe must be positive."),
    )

    state_boundary = Matrix{Float64}(undef, n_states, total_nfe + 1)
    state_collocation = Array{Float64, 3}(undef, n_states, total_nfe, degree)
    state_derivative = Array{Float64, 3}(undef, n_states, total_nfe, degree)
    flux = Array{Float64, 3}(undef, n_reactions, total_nfe, degree)
    lower_bound_duals = Array{Float64, 3}(undef, n_reactions, total_nfe, degree)
    upper_bound_duals = Array{Float64, 3}(undef, n_reactions, total_nfe, degree)
    mass_balance_duals = Array{Float64, 3}(undef, n_metabolites, total_nfe, degree)

    element_offset = 0
    next_boundary_column = 1
    previous_final_time = nothing
    max_boundary_join_mismatch = 0.0
    boundary_times = Float64[]
    collocation_times = Float64[]

    for (window_index, comparison) in enumerate(comparisons)
        candidate = comparison.trajectory_candidate.candidate_diagnostics
        local_nfe = local_nfe_values[window_index]
        _reduced_mpcc_global_polish_validate_candidate_shapes!(
            candidate,
            comparison,
            window_index,
            n_states,
            n_reactions,
            n_metabolites,
            degree,
            local_nfe,
        )

        times = Float64.(comparison.trajectory_candidate.boundary_result.time)
        if previous_final_time !== nothing
            isapprox(first(times), previous_final_time; atol = 1.0e-10, rtol = 0.0) || throw(
                ArgumentError(
                    "Reduced MPCC global polish requires continuous window boundary times. " *
                    "Got previous=$(previous_final_time) and next=$(first(times)).",
                ),
            )
            join_mismatch = maximum(
                abs.(
                    state_boundary[:, next_boundary_column - 1] .-
                    candidate.state_boundary[:, 1],
                ),
            )
            max_boundary_join_mismatch = max(max_boundary_join_mismatch, join_mismatch)
        end

        if window_index == 1
            state_boundary[:, 1:(local_nfe + 1)] .= candidate.state_boundary
            append!(boundary_times, times)
            next_boundary_column = local_nfe + 2
        else
            target_range = next_boundary_column:(next_boundary_column + local_nfe - 1)
            state_boundary[:, target_range] .= candidate.state_boundary[:, 2:end]
            append!(boundary_times, times[2:end])
            next_boundary_column += local_nfe
        end

        element_range = (element_offset + 1):(element_offset + local_nfe)
        state_collocation[:, element_range, :] .= candidate.state_collocation
        state_derivative[:, element_range, :] .= candidate.state_derivative
        flux[:, element_range, :] .= candidate.flux
        lower_bound_duals[:, element_range, :] .= candidate.lower_bound_duals
        upper_bound_duals[:, element_range, :] .= candidate.upper_bound_duals
        mass_balance_duals[:, element_range, :] .= candidate.mass_balance_duals
        append!(
            collocation_times,
            _reduced_mpcc_global_polish_candidate_collocation_times(comparison),
        )

        element_offset += local_nfe
        previous_final_time = last(times)
    end

    _reduced_mpcc_global_polish_validate_finite_arrays(
        state_boundary,
        state_collocation,
        state_derivative,
        flux,
        lower_bound_duals,
        upper_bound_duals,
        mass_balance_duals,
    )

    metadata = _reduced_mpcc_global_polish_start_metadata(
        continuation,
        comparisons,
        local_nfe_values,
        boundary_times,
        collocation_times,
        max_boundary_join_mismatch,
        n_states,
        n_reactions,
        n_metabolites,
        degree,
        total_nfe,
        require_complete,
    )
    return ReducedDCDFBAMPCCWindowedStartValues(
        state_boundary,
        state_collocation,
        state_derivative,
        flux,
        lower_bound_duals,
        upper_bound_duals,
        mass_balance_duals,
        metadata,
    )
end

"""
    apply_reduced_dcdfba_mpcc_windowed_starts!(problem, starts)

Apply monolithic windowed/cascade candidate arrays as JuMP starts to a reduced
global MPCC solve-attempt problem.
"""
function apply_reduced_dcdfba_mpcc_windowed_starts!(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
)::DataFrame
    _reduced_mpcc_global_polish_validate_target_shapes(problem, starts)
    nlp = problem.smoke_problem.nlp

    _reduced_mpcc_global_polish_set_starts!(nlp.state_boundary, starts.state_boundary)
    _reduced_mpcc_global_polish_set_starts!(nlp.state_collocation, starts.state_collocation)
    _reduced_mpcc_global_polish_set_starts!(nlp.state_derivative, starts.state_derivative)
    _reduced_mpcc_global_polish_set_starts!(nlp.flux, starts.flux)
    _reduced_mpcc_global_polish_set_starts!(
        problem.smoke_problem.bound_feasibility.lower_bound_duals,
        starts.lower_bound_duals,
    )
    _reduced_mpcc_global_polish_set_starts!(
        problem.smoke_problem.bound_feasibility.upper_bound_duals,
        starts.upper_bound_duals,
    )
    _reduced_mpcc_global_polish_set_starts!(
        problem.smoke_problem.stationarity.mass_balance_duals,
        starts.mass_balance_duals,
    )

    table = _reduced_mpcc_global_polish_start_summary_table(problem, starts)
    metadata = Dict{String, Any}(
        "windowed_global_polish_start_applied" => true,
        "windowed_global_polish_start_source" => "windowed_candidate_arrays",
        "windowed_global_polish_source_window_count" =>
            starts.metadata["source_window_count"],
        "windowed_global_polish_source_total_nfe" =>
            starts.metadata["source_total_nfe"],
        "windowed_global_polish_source_collocation_degree" =>
            starts.metadata["source_collocation_degree"],
        "windowed_global_polish_max_boundary_join_mismatch" =>
            starts.metadata["source_max_boundary_join_mismatch"],
        "windowed_global_polish_start_summary_rows" => nrow(table),
        "windowed_global_polish_start_is_scientific_simulation" => false,
    )
    merge!(problem.metadata, metadata)
    merge!(problem.smoke_problem.metadata, metadata)
    merge!(problem.smoke_problem.nlp.metadata, metadata)
    return table
end

function _reduced_mpcc_global_polish_array_abs_max(values)::Float64
    isempty(values) && return 0.0
    return Float64(maximum(abs, values))
end

function _reduced_mpcc_global_polish_sanitize_dense_dual_starts(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
)::ReducedDCDFBAMPCCWindowedStartValues
    metadata = copy(starts.metadata)
    metadata["dense_start_dual_sanitize_applied"] = true
    metadata["dense_start_dual_sanitize_policy"] =
        "zero_bound_and_mass_balance_duals_preserve_dense_state_derivative_flux_starts"
    metadata["dense_start_dual_sanitize_lower_bound_dual_abs_max_before"] =
        _reduced_mpcc_global_polish_array_abs_max(starts.lower_bound_duals)
    metadata["dense_start_dual_sanitize_upper_bound_dual_abs_max_before"] =
        _reduced_mpcc_global_polish_array_abs_max(starts.upper_bound_duals)
    metadata["dense_start_dual_sanitize_mass_balance_dual_abs_max_before"] =
        _reduced_mpcc_global_polish_array_abs_max(starts.mass_balance_duals)
    metadata["dense_start_dual_sanitize_lower_bound_dual_abs_max_after"] = 0.0
    metadata["dense_start_dual_sanitize_upper_bound_dual_abs_max_after"] = 0.0
    metadata["dense_start_dual_sanitize_mass_balance_dual_abs_max_after"] = 0.0

    return ReducedDCDFBAMPCCWindowedStartValues(
        starts.state_boundary,
        starts.state_collocation,
        starts.state_derivative,
        starts.flux,
        zeros(Float64, size(starts.lower_bound_duals)),
        zeros(Float64, size(starts.upper_bound_duals)),
        zeros(Float64, size(starts.mass_balance_duals)),
        metadata,
    )
end

function _reduced_mpcc_global_polish_objective_mode(mode::AbstractString)::String
    cleaned = lowercase(strip(String(mode)))
    aliases = Dict(
        "legacy" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_LEGACY,
        "zero_derivative" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_LEGACY,
        "legacy_zero_derivative" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_LEGACY,
        "deoliveira_gap" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_GAP,
        "de_oliveira_gap" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_GAP,
        "gap" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_GAP,
        "deoliveira_tracking" =>
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING,
        "de_oliveira_tracking" =>
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING,
        "tracking" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING,
    )
    haskey(aliases, cleaned) || throw(
        ArgumentError(
            "Reduced MPCC global polish objective_mode must be one of " *
            "legacy_zero_derivative, de_oliveira_gap, or de_oliveira_tracking. Got: $mode",
        ),
    )
    return aliases[cleaned]
end

function _reduced_mpcc_global_polish_nonnegative_weight(
    value::Real,
    label::AbstractString,
)::Float64
    numeric = Float64(value)
    isfinite(numeric) && numeric >= 0.0 ||
        throw(ArgumentError("Reduced MPCC global polish $label must be finite and nonnegative."))
    return numeric
end

function _reduced_mpcc_global_polish_objective_state_reference(
    reference::AbstractString,
)::String
    cleaned = lowercase(strip(String(reference)))
    aliases = Dict(
        "seed" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
        "windowed_seed" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
        "windowed_start" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
        "windowed" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
        "sequential" =>
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEQUENTIAL,
        "sequential_reference" =>
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEQUENTIAL,
    )
    haskey(aliases, cleaned) || throw(
        ArgumentError(
            "Reduced MPCC global polish objective_state_reference must be seed " *
            "or sequential_reference. Got: $reference",
        ),
    )
    return aliases[cleaned]
end

function _reduced_mpcc_global_polish_positive_scale(values)::Float64
    scale = maximum(abs, values)
    isfinite(scale) || return 1.0
    return max(1.0, Float64(scale))
end

function _reduced_mpcc_global_polish_state_scales(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
)::Vector{Float64}
    n_states = size(starts.state_boundary, 1)
    scales = Vector{Float64}(undef, n_states)
    for i in 1:n_states
        scales[i] = max(
            _reduced_mpcc_global_polish_positive_scale(view(starts.state_boundary, i, :)),
            _reduced_mpcc_global_polish_positive_scale(view(starts.state_collocation, i, :, :)),
        )
    end
    return scales
end

function _reduced_mpcc_global_polish_flux_scales(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
)::Vector{Float64}
    n_reactions = size(starts.flux, 1)
    scales = Vector{Float64}(undef, n_reactions)
    for r in 1:n_reactions
        scales[r] = _reduced_mpcc_global_polish_positive_scale(view(starts.flux, r, :, :))
    end
    return scales
end

function _reduced_mpcc_global_polish_state_names(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    n_states::Int,
)::Vector{String}
    fallback = length(DEFAULT_SIMULATION_STATE_NAMES) == n_states ?
        String.(DEFAULT_SIMULATION_STATE_NAMES) :
        ["state_$(i)" for i in 1:n_states]
    return _reduced_mpcc_global_polish_string_vector(
        get(starts.metadata, "source_state_names", fallback),
        n_states,
        fallback,
    )
end

function _reduced_mpcc_global_polish_state_index(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    n_states::Int,
    state_name::AbstractString,
)::Union{Nothing, Int}
    names = _reduced_mpcc_global_polish_state_names(starts, n_states)
    normalized = lowercase(strip(String(state_name)))
    return findfirst(name -> lowercase(strip(name)) == normalized, names)
end

function _reduced_mpcc_global_polish_trust_region_states(
    states::AbstractString,
)::Vector{String}
    cleaned = lowercase(strip(String(states)))
    cleaned in ("", "none", "off", "false", "disabled") && return String[]
    requested = String[]
    for token in split(cleaned, [',', ';'])
        state = lowercase(strip(token))
        isempty(state) && continue
        if state == "core"
            append!(requested, REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_TRUST_REGION_DEFAULT_STATES)
        elseif state in ("aroma", "aromas", "aroma_trace", "aroma_traces", "aromatic_traces")
            append!(requested, REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_AROMA_TRACE_STATES)
        elseif state in ("amino_acid", "amino_acids", "amino_trace", "amino_acid_traces")
            append!(requested, REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_AMINO_ACID_TRACE_STATES)
        elseif state in (
            "trace",
            "traces",
            "metabolite_trace",
            "metabolite_traces",
            "all_traces",
        )
            append!(requested, REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_METABOLITE_TRACE_STATES)
        else
            push!(requested, state)
        end
    end
    unique_requested = String[]
    for state in requested
        state in unique_requested || push!(unique_requested, state)
    end
    return unique_requested
end

function _reduced_mpcc_global_polish_trust_region_state_set(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    n_states::Int,
    requested_states::Vector{String},
)
    resolved_state_indices = Int[]
    resolved_state_names = String[]
    include_total_sugar = false
    for state in requested_states
        if state in ("total_sugar", "sugar", "total_hexose", "hexose")
            include_total_sugar = true
            "total_sugar" in resolved_state_names || push!(resolved_state_names, "total_sugar")
            continue
        end
        state_index = _reduced_mpcc_global_polish_state_index(starts, n_states, state)
        state_index === nothing && throw(
            ArgumentError(
                "Reduced MPCC global polish trust-region state '$state' is not " *
                "available in the MPCC state vector.",
            ),
        )
        state_index in resolved_state_indices || push!(resolved_state_indices, state_index)
        state in resolved_state_names || push!(resolved_state_names, state)
    end
    glucose_index = _reduced_mpcc_global_polish_state_index(starts, n_states, "glucose")
    fructose_index = _reduced_mpcc_global_polish_state_index(starts, n_states, "fructose")
    if include_total_sugar && (glucose_index === nothing || fructose_index === nothing)
        throw(
            ArgumentError(
                "Reduced MPCC global polish trust-region total_sugar requires glucose " *
                "and fructose states.",
            ),
        )
    end
    return (
        state_indices = resolved_state_indices,
        state_names = resolved_state_names,
        include_total_sugar = include_total_sugar,
        glucose_index = glucose_index,
        fructose_index = fructose_index,
    )
end

function _reduced_mpcc_global_polish_objective_state_targets(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    nlp,
    state_reference::AbstractString,
    sequential_reference,
)::Tuple{Matrix{Float64}, Array{Float64, 3}, String}
    mode = _reduced_mpcc_global_polish_objective_state_reference(state_reference)
    if mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED
        return starts.state_boundary, starts.state_collocation, mode
    end

    sequential_reference === nothing && throw(
        ArgumentError(
            "Reduced MPCC global polish objective_state_reference=sequential_reference " *
            "requires a sequential reference trajectory.",
        ),
    )
    n_states = nlp.dimensions.n_states
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree
    size(sequential_reference.states, 1) >= n_states || throw(
        ArgumentError(
            "Sequential objective reference has fewer states ($(size(sequential_reference.states, 1))) " *
            "than the global MPCC problem ($n_states).",
        ),
    )
    grid = nlp.kkt_problem.grid
    state_boundary = similar(starts.state_boundary)
    state_collocation = similar(starts.state_collocation)
    for e in 1:nfe
        left, right = element_bounds(grid, e)
        if e == 1
            state_boundary[:, 1] .=
                _reduced_dcdfba_interpolated_state(sequential_reference, left)[1:n_states]
        end
        state_boundary[:, e + 1] .=
            _reduced_dcdfba_interpolated_state(sequential_reference, right)[1:n_states]
        for j in 1:degree
            time_value = collocation_time(grid, e, j)
            state_collocation[:, e, j] .=
                _reduced_dcdfba_interpolated_state(sequential_reference, time_value)[1:n_states]
        end
    end
    return state_boundary, state_collocation, mode
end

function _reduced_mpcc_global_polish_current_start_value(variable, fallback::Real)::Float64
    value = try
        JuMP.start_value(variable)
    catch
        nothing
    end
    value === nothing && return Float64(fallback)
    value_float = Float64(value)
    return isfinite(value_float) ? value_float : Float64(fallback)
end

function _reduced_mpcc_global_polish_trust_region_penalty!(
    jump_model,
    nlp,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    target_state_boundary::Matrix{Float64},
    target_state_collocation::Array{Float64, 3},
    state_scales::Vector{Float64};
    enabled::Bool,
    states::AbstractString,
    abs_delta::Real,
    rel_delta::Real,
    weight::Real,
    metadata_prefix::AbstractString = "global_polish_trust_region",
    variable_prefix::AbstractString = "global_polish_trust_region",
    parameter_prefix::AbstractString = "trust_region",
)
    abs_band = _reduced_mpcc_global_polish_nonnegative_weight(
        abs_delta,
        "$(parameter_prefix)_abs_delta",
    )
    rel_band = _reduced_mpcc_global_polish_nonnegative_weight(
        rel_delta,
        "$(parameter_prefix)_rel_delta",
    )
    trust_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        weight,
        "$(parameter_prefix)_weight",
    )
    requested_states = _reduced_mpcc_global_polish_trust_region_states(states)
    metadata = Dict{String, Any}(
        "$(metadata_prefix)_enabled" => enabled,
        "$(metadata_prefix)_requested_states" => join(requested_states, ","),
        "$(metadata_prefix)_abs_delta" => abs_band,
        "$(metadata_prefix)_rel_delta" => rel_band,
        "$(metadata_prefix)_weight" => trust_weight,
        "$(metadata_prefix)_band_formula" =>
            "abs_delta + rel_delta * component_scale",
    )
    enabled || return 0.0, metadata
    isempty(requested_states) && throw(
        ArgumentError(
            "Reduced MPCC global polish trust region is enabled but no states were requested.",
        ),
    )
    hard_constraints = trust_weight == 0.0
    metadata["$(metadata_prefix)_mode"] =
        hard_constraints ? "hard_constraints" : "soft_slack_penalty"
    metadata["$(metadata_prefix)_slack_penalty"] = hard_constraints ?
        "disabled_hard_constraints" :
        "weight * mean((slack/component_scale)^2)"
    metadata["$(metadata_prefix)_hard_constraint_center"] =
        hard_constraints ? "current_start_value" : "not_applicable"
    hard_constraints || trust_weight > 0.0 || throw(
        ArgumentError(
            "Reduced MPCC global polish $(parameter_prefix)_weight must be positive when " *
            "the trust region is enabled.",
        ),
    )

    n_states = nlp.dimensions.n_states
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree
    resolved = _reduced_mpcc_global_polish_trust_region_state_set(
        starts,
        n_states,
        requested_states,
    )
    state_indices = resolved.state_indices
    include_total_sugar = Bool(resolved.include_total_sugar)
    n_selected_states = length(state_indices)

    penalty = 0.0
    penalty_terms = 0
    constraint_terms = 0

    if n_selected_states > 0
        trust_region_state_boundary_lower_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:n_selected_states, 1:(nfe + 1)],
                lower_bound = 0.0,
                base_name = "$(variable_prefix)_state_boundary_lower_slack",
            )
        trust_region_state_boundary_upper_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:n_selected_states, 1:(nfe + 1)],
                lower_bound = 0.0,
                base_name = "$(variable_prefix)_state_boundary_upper_slack",
            )
        trust_region_state_collocation_lower_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:n_selected_states, 1:nfe, 1:degree],
                lower_bound = 0.0,
                base_name = "$(variable_prefix)_state_collocation_lower_slack",
            )
        trust_region_state_collocation_upper_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:n_selected_states, 1:nfe, 1:degree],
                lower_bound = 0.0,
                base_name = "$(variable_prefix)_state_collocation_upper_slack",
            )
        for (p, state_index) in enumerate(state_indices)
            scale = state_scales[state_index]
            band = abs_band + rel_band * scale
            for k in 1:(nfe + 1)
                if hard_constraints
                    center_value = _reduced_mpcc_global_polish_current_start_value(
                        nlp.state_boundary[state_index, k],
                        target_state_boundary[state_index, k],
                    )
                    JuMP.set_start_value(nlp.state_boundary[state_index, k], center_value)
                    JuMP.@constraint(
                        jump_model,
                        center_value - nlp.state_boundary[state_index, k] <= band,
                    )
                    JuMP.@constraint(
                        jump_model,
                        nlp.state_boundary[state_index, k] - center_value <= band,
                    )
                else
                    start_value = _reduced_mpcc_global_polish_current_start_value(
                        nlp.state_boundary[state_index, k],
                        starts.state_boundary[state_index, k],
                    )
                    JuMP.set_start_value(
                        trust_region_state_boundary_lower_slack[p, k],
                        max(target_state_boundary[state_index, k] - start_value - band, 0.0),
                    )
                    JuMP.set_start_value(
                        trust_region_state_boundary_upper_slack[p, k],
                        max(start_value - target_state_boundary[state_index, k] - band, 0.0),
                    )
                    JuMP.@constraint(
                        jump_model,
                        target_state_boundary[state_index, k] -
                        nlp.state_boundary[state_index, k] <=
                        band + trust_region_state_boundary_lower_slack[p, k],
                    )
                    JuMP.@constraint(
                        jump_model,
                        nlp.state_boundary[state_index, k] -
                        target_state_boundary[state_index, k] <=
                        band + trust_region_state_boundary_upper_slack[p, k],
                    )
                    penalty +=
                        (trust_region_state_boundary_lower_slack[p, k] / scale)^2 +
                        (trust_region_state_boundary_upper_slack[p, k] / scale)^2
                    penalty_terms += 2
                end
                constraint_terms += 2
            end
            for e in 1:nfe, j in 1:degree
                if hard_constraints
                    center_value = _reduced_mpcc_global_polish_current_start_value(
                        nlp.state_collocation[state_index, e, j],
                        target_state_collocation[state_index, e, j],
                    )
                    JuMP.set_start_value(nlp.state_collocation[state_index, e, j], center_value)
                    JuMP.@constraint(
                        jump_model,
                        center_value - nlp.state_collocation[state_index, e, j] <= band,
                    )
                    JuMP.@constraint(
                        jump_model,
                        nlp.state_collocation[state_index, e, j] - center_value <= band,
                    )
                else
                    start_value = _reduced_mpcc_global_polish_current_start_value(
                        nlp.state_collocation[state_index, e, j],
                        starts.state_collocation[state_index, e, j],
                    )
                    JuMP.set_start_value(
                        trust_region_state_collocation_lower_slack[p, e, j],
                        max(target_state_collocation[state_index, e, j] - start_value - band, 0.0),
                    )
                    JuMP.set_start_value(
                        trust_region_state_collocation_upper_slack[p, e, j],
                        max(start_value - target_state_collocation[state_index, e, j] - band, 0.0),
                    )
                    JuMP.@constraint(
                        jump_model,
                        target_state_collocation[state_index, e, j] -
                        nlp.state_collocation[state_index, e, j] <=
                        band + trust_region_state_collocation_lower_slack[p, e, j],
                    )
                    JuMP.@constraint(
                        jump_model,
                        nlp.state_collocation[state_index, e, j] -
                        target_state_collocation[state_index, e, j] <=
                        band + trust_region_state_collocation_upper_slack[p, e, j],
                    )
                    penalty +=
                        (trust_region_state_collocation_lower_slack[p, e, j] / scale)^2 +
                        (trust_region_state_collocation_upper_slack[p, e, j] / scale)^2
                    penalty_terms += 2
                end
                constraint_terms += 2
            end
        end
    end

    if include_total_sugar
        glucose_index = Int(resolved.glucose_index)
        fructose_index = Int(resolved.fructose_index)
        total_scale = max(1.0, state_scales[glucose_index] + state_scales[fructose_index])
        total_band = abs_band + rel_band * total_scale
        trust_region_total_sugar_boundary_lower_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:(nfe + 1)],
                lower_bound = 0.0,
                base_name = "$(variable_prefix)_total_sugar_boundary_lower_slack",
            )
        trust_region_total_sugar_boundary_upper_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:(nfe + 1)],
                lower_bound = 0.0,
                base_name = "$(variable_prefix)_total_sugar_boundary_upper_slack",
            )
        trust_region_total_sugar_collocation_lower_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:nfe, 1:degree],
                lower_bound = 0.0,
                base_name = "$(variable_prefix)_total_sugar_collocation_lower_slack",
            )
        trust_region_total_sugar_collocation_upper_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:nfe, 1:degree],
                lower_bound = 0.0,
                base_name = "$(variable_prefix)_total_sugar_collocation_upper_slack",
            )
        for k in 1:(nfe + 1)
            target_total =
                target_state_boundary[glucose_index, k] +
                target_state_boundary[fructose_index, k]
            candidate_total =
                nlp.state_boundary[glucose_index, k] +
                nlp.state_boundary[fructose_index, k]
            if hard_constraints
                center_glucose = _reduced_mpcc_global_polish_current_start_value(
                    nlp.state_boundary[glucose_index, k],
                    target_state_boundary[glucose_index, k],
                )
                center_fructose = _reduced_mpcc_global_polish_current_start_value(
                    nlp.state_boundary[fructose_index, k],
                    target_state_boundary[fructose_index, k],
                )
                JuMP.set_start_value(nlp.state_boundary[glucose_index, k], center_glucose)
                JuMP.set_start_value(nlp.state_boundary[fructose_index, k], center_fructose)
                center_total = center_glucose + center_fructose
                JuMP.@constraint(jump_model, center_total - candidate_total <= total_band)
                JuMP.@constraint(jump_model, candidate_total - center_total <= total_band)
            else
                start_total =
                    _reduced_mpcc_global_polish_current_start_value(
                        nlp.state_boundary[glucose_index, k],
                        starts.state_boundary[glucose_index, k],
                    ) +
                    _reduced_mpcc_global_polish_current_start_value(
                        nlp.state_boundary[fructose_index, k],
                        starts.state_boundary[fructose_index, k],
                    )
                JuMP.set_start_value(
                    trust_region_total_sugar_boundary_lower_slack[k],
                    max(target_total - start_total - total_band, 0.0),
                )
                JuMP.set_start_value(
                    trust_region_total_sugar_boundary_upper_slack[k],
                    max(start_total - target_total - total_band, 0.0),
                )
                JuMP.@constraint(
                    jump_model,
                    target_total - candidate_total <=
                    total_band + trust_region_total_sugar_boundary_lower_slack[k],
                )
                JuMP.@constraint(
                    jump_model,
                    candidate_total - target_total <=
                    total_band + trust_region_total_sugar_boundary_upper_slack[k],
                )
                penalty +=
                    (trust_region_total_sugar_boundary_lower_slack[k] / total_scale)^2 +
                    (trust_region_total_sugar_boundary_upper_slack[k] / total_scale)^2
                penalty_terms += 2
            end
            constraint_terms += 2
        end
        for e in 1:nfe, j in 1:degree
            target_total =
                target_state_collocation[glucose_index, e, j] +
                target_state_collocation[fructose_index, e, j]
            candidate_total =
                nlp.state_collocation[glucose_index, e, j] +
                nlp.state_collocation[fructose_index, e, j]
            if hard_constraints
                center_glucose = _reduced_mpcc_global_polish_current_start_value(
                    nlp.state_collocation[glucose_index, e, j],
                    target_state_collocation[glucose_index, e, j],
                )
                center_fructose = _reduced_mpcc_global_polish_current_start_value(
                    nlp.state_collocation[fructose_index, e, j],
                    target_state_collocation[fructose_index, e, j],
                )
                JuMP.set_start_value(
                    nlp.state_collocation[glucose_index, e, j],
                    center_glucose,
                )
                JuMP.set_start_value(
                    nlp.state_collocation[fructose_index, e, j],
                    center_fructose,
                )
                center_total = center_glucose + center_fructose
                JuMP.@constraint(jump_model, center_total - candidate_total <= total_band)
                JuMP.@constraint(jump_model, candidate_total - center_total <= total_band)
            else
                start_total =
                    _reduced_mpcc_global_polish_current_start_value(
                        nlp.state_collocation[glucose_index, e, j],
                        starts.state_collocation[glucose_index, e, j],
                    ) +
                    _reduced_mpcc_global_polish_current_start_value(
                        nlp.state_collocation[fructose_index, e, j],
                        starts.state_collocation[fructose_index, e, j],
                    )
                JuMP.set_start_value(
                    trust_region_total_sugar_collocation_lower_slack[e, j],
                    max(target_total - start_total - total_band, 0.0),
                )
                JuMP.set_start_value(
                    trust_region_total_sugar_collocation_upper_slack[e, j],
                    max(start_total - target_total - total_band, 0.0),
                )
                JuMP.@constraint(
                    jump_model,
                    target_total - candidate_total <=
                    total_band + trust_region_total_sugar_collocation_lower_slack[e, j],
                )
                JuMP.@constraint(
                    jump_model,
                    candidate_total - target_total <=
                    total_band + trust_region_total_sugar_collocation_upper_slack[e, j],
                )
                penalty +=
                    (trust_region_total_sugar_collocation_lower_slack[e, j] / total_scale)^2 +
                    (trust_region_total_sugar_collocation_upper_slack[e, j] / total_scale)^2
                penalty_terms += 2
            end
            constraint_terms += 2
        end
        metadata["$(metadata_prefix)_total_sugar_scale"] = total_scale
        metadata["$(metadata_prefix)_total_sugar_band"] = total_band
    end

    constraint_terms > 0 || throw(
        ArgumentError(
            "Reduced MPCC global polish trust region did not resolve any usable state.",
        ),
    )
    metadata["$(metadata_prefix)_resolved_states"] =
        join(resolved.state_names, ",")
    metadata["$(metadata_prefix)_state_count"] = n_selected_states
    metadata["$(metadata_prefix)_includes_total_sugar"] = include_total_sugar
    metadata["$(metadata_prefix)_slack_terms"] = penalty_terms
    metadata["$(metadata_prefix)_constraint_terms"] = constraint_terms
    metadata["$(metadata_prefix)_normalization"] = "mean_over_two_sided_slacks"
    return hard_constraints ? 0.0 : trust_weight * penalty / penalty_terms, metadata
end

function _reduced_mpcc_global_polish_terminal_trust_region_penalty!(
    jump_model,
    nlp,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    target_state_boundary::Matrix{Float64},
    state_scales::Vector{Float64};
    enabled::Bool,
    states::AbstractString,
    abs_delta::Real,
    rel_delta::Real,
    weight::Real,
)
    abs_band = _reduced_mpcc_global_polish_nonnegative_weight(
        abs_delta,
        "terminal_trust_region_abs_delta",
    )
    rel_band = _reduced_mpcc_global_polish_nonnegative_weight(
        rel_delta,
        "terminal_trust_region_rel_delta",
    )
    trust_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        weight,
        "terminal_trust_region_weight",
    )
    requested_states = _reduced_mpcc_global_polish_trust_region_states(states)
    metadata = Dict{String, Any}(
        "global_polish_terminal_trust_region_enabled" => enabled,
        "global_polish_terminal_trust_region_requested_states" =>
            join(requested_states, ","),
        "global_polish_terminal_trust_region_abs_delta" => abs_band,
        "global_polish_terminal_trust_region_rel_delta" => rel_band,
        "global_polish_terminal_trust_region_weight" => trust_weight,
        "global_polish_terminal_trust_region_band_formula" =>
            "abs_delta + rel_delta * component_scale",
    )
    enabled || return 0.0, metadata
    isempty(requested_states) && throw(
        ArgumentError(
            "Reduced MPCC global polish terminal trust region is enabled but no " *
            "states were requested.",
        ),
    )
    hard_constraints = trust_weight == 0.0
    metadata["global_polish_terminal_trust_region_mode"] =
        hard_constraints ? "hard_constraints" : "soft_slack_penalty"
    metadata["global_polish_terminal_trust_region_slack_penalty"] = hard_constraints ?
        "disabled_hard_constraints" :
        "weight * mean((terminal_slack/component_scale)^2)"
    metadata["global_polish_terminal_trust_region_hard_constraint_center"] =
        hard_constraints ? "current_start_value" : "not_applicable"
    hard_constraints || trust_weight > 0.0 || throw(
        ArgumentError(
            "Reduced MPCC global polish terminal_trust_region_weight must be positive " *
            "when the terminal trust region is enabled.",
        ),
    )

    n_states = nlp.dimensions.n_states
    nfe = nlp.dimensions.nfe
    final_k = nfe + 1
    resolved = _reduced_mpcc_global_polish_trust_region_state_set(
        starts,
        n_states,
        requested_states,
    )
    state_indices = resolved.state_indices
    include_total_sugar = Bool(resolved.include_total_sugar)
    n_selected_states = length(state_indices)

    penalty = 0.0
    penalty_terms = 0
    constraint_terms = 0

    if n_selected_states > 0
        terminal_trust_region_state_lower_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:n_selected_states],
                lower_bound = 0.0,
                base_name = "global_polish_terminal_trust_region_state_lower_slack",
            )
        terminal_trust_region_state_upper_slack = hard_constraints ? nothing :
            JuMP.@variable(
                jump_model,
                [1:n_selected_states],
                lower_bound = 0.0,
                base_name = "global_polish_terminal_trust_region_state_upper_slack",
            )
        for (p, state_index) in enumerate(state_indices)
            scale = state_scales[state_index]
            band = abs_band + rel_band * scale
            target_value = target_state_boundary[state_index, final_k]
            if hard_constraints
                center_value = _reduced_mpcc_global_polish_current_start_value(
                    nlp.state_boundary[state_index, final_k],
                    target_value,
                )
                JuMP.set_start_value(nlp.state_boundary[state_index, final_k], center_value)
                JuMP.@constraint(
                    jump_model,
                    center_value - nlp.state_boundary[state_index, final_k] <= band,
                )
                JuMP.@constraint(
                    jump_model,
                    nlp.state_boundary[state_index, final_k] - center_value <= band,
                )
            else
                start_value = _reduced_mpcc_global_polish_current_start_value(
                    nlp.state_boundary[state_index, final_k],
                    starts.state_boundary[state_index, final_k],
                )
                JuMP.set_start_value(
                    terminal_trust_region_state_lower_slack[p],
                    max(target_value - start_value - band, 0.0),
                )
                JuMP.set_start_value(
                    terminal_trust_region_state_upper_slack[p],
                    max(start_value - target_value - band, 0.0),
                )
                JuMP.@constraint(
                    jump_model,
                    target_value - nlp.state_boundary[state_index, final_k] <=
                    band + terminal_trust_region_state_lower_slack[p],
                )
                JuMP.@constraint(
                    jump_model,
                    nlp.state_boundary[state_index, final_k] - target_value <=
                    band + terminal_trust_region_state_upper_slack[p],
                )
                penalty +=
                    (terminal_trust_region_state_lower_slack[p] / scale)^2 +
                    (terminal_trust_region_state_upper_slack[p] / scale)^2
                penalty_terms += 2
            end
            constraint_terms += 2
        end
    end

    if include_total_sugar
        glucose_index = Int(resolved.glucose_index)
        fructose_index = Int(resolved.fructose_index)
        total_scale = max(1.0, state_scales[glucose_index] + state_scales[fructose_index])
        total_band = abs_band + rel_band * total_scale
        target_total =
            target_state_boundary[glucose_index, final_k] +
            target_state_boundary[fructose_index, final_k]
        start_total =
            _reduced_mpcc_global_polish_current_start_value(
                nlp.state_boundary[glucose_index, final_k],
                starts.state_boundary[glucose_index, final_k],
            ) +
            _reduced_mpcc_global_polish_current_start_value(
                nlp.state_boundary[fructose_index, final_k],
                starts.state_boundary[fructose_index, final_k],
            )
        candidate_total =
            nlp.state_boundary[glucose_index, final_k] +
            nlp.state_boundary[fructose_index, final_k]
        if hard_constraints
            center_glucose = _reduced_mpcc_global_polish_current_start_value(
                nlp.state_boundary[glucose_index, final_k],
                target_state_boundary[glucose_index, final_k],
            )
            center_fructose = _reduced_mpcc_global_polish_current_start_value(
                nlp.state_boundary[fructose_index, final_k],
                target_state_boundary[fructose_index, final_k],
            )
            JuMP.set_start_value(nlp.state_boundary[glucose_index, final_k], center_glucose)
            JuMP.set_start_value(nlp.state_boundary[fructose_index, final_k], center_fructose)
            center_total = center_glucose + center_fructose
            JuMP.@constraint(jump_model, center_total - candidate_total <= total_band)
            JuMP.@constraint(jump_model, candidate_total - center_total <= total_band)
        else
            JuMP.@variable(
                jump_model,
                terminal_trust_region_total_sugar_lower_slack >= 0,
                base_name = "global_polish_terminal_trust_region_total_sugar_lower_slack",
            )
            JuMP.@variable(
                jump_model,
                terminal_trust_region_total_sugar_upper_slack >= 0,
                base_name = "global_polish_terminal_trust_region_total_sugar_upper_slack",
            )
            JuMP.set_start_value(
                terminal_trust_region_total_sugar_lower_slack,
                max(target_total - start_total - total_band, 0.0),
            )
            JuMP.set_start_value(
                terminal_trust_region_total_sugar_upper_slack,
                max(start_total - target_total - total_band, 0.0),
            )
            JuMP.@constraint(
                jump_model,
                target_total - candidate_total <=
                total_band + terminal_trust_region_total_sugar_lower_slack,
            )
            JuMP.@constraint(
                jump_model,
                candidate_total - target_total <=
                total_band + terminal_trust_region_total_sugar_upper_slack,
            )
            penalty +=
                (terminal_trust_region_total_sugar_lower_slack / total_scale)^2 +
                (terminal_trust_region_total_sugar_upper_slack / total_scale)^2
            penalty_terms += 2
        end
        constraint_terms += 2
        metadata["global_polish_terminal_trust_region_total_sugar_scale"] = total_scale
        metadata["global_polish_terminal_trust_region_total_sugar_band"] = total_band
    end

    constraint_terms > 0 || throw(
        ArgumentError(
            "Reduced MPCC global polish terminal trust region did not resolve any " *
            "usable state.",
        ),
    )
    metadata["global_polish_terminal_trust_region_resolved_states"] =
        join(resolved.state_names, ",")
    metadata["global_polish_terminal_trust_region_state_count"] = n_selected_states
    metadata["global_polish_terminal_trust_region_includes_total_sugar"] =
        include_total_sugar
    metadata["global_polish_terminal_trust_region_slack_terms"] = penalty_terms
    metadata["global_polish_terminal_trust_region_constraint_terms"] = constraint_terms
    metadata["global_polish_terminal_trust_region_normalization"] =
        "mean_over_terminal_two_sided_slacks"
    return hard_constraints ? 0.0 : trust_weight * penalty / penalty_terms, metadata
end

function _reduced_mpcc_global_polish_apply_objective!(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    starts::ReducedDCDFBAMPCCWindowedStartValues;
    sequential_reference = nothing,
    objective_mode::AbstractString,
    objective_state_reference::AbstractString,
    objective_rho::Real,
    objective_state_tracking_weight::Real,
    objective_biomass_tracking_weight::Real,
    objective_biomass_terminal_weight::Real,
    objective_sugar_tracking_weight::Real,
    objective_total_sugar_tracking_weight::Real,
    objective_total_sugar_terminal_weight::Real,
    objective_flux_tracking_weight::Real,
    objective_derivative_regularization_weight::Real,
    trust_region_enabled::Bool,
    trust_region_state_reference::AbstractString,
    trust_region_states::AbstractString,
    trust_region_abs_delta::Real,
    trust_region_rel_delta::Real,
    trust_region_weight::Real,
    trace_trust_region_enabled::Bool,
    trace_trust_region_state_reference::AbstractString,
    trace_trust_region_states::AbstractString,
    trace_trust_region_abs_delta::Real,
    trace_trust_region_rel_delta::Real,
    trace_trust_region_weight::Real,
    terminal_trust_region_enabled::Bool,
    terminal_trust_region_state_reference::AbstractString,
    terminal_trust_region_states::AbstractString,
    terminal_trust_region_abs_delta::Real,
    terminal_trust_region_rel_delta::Real,
    terminal_trust_region_weight::Real,
)::Dict{String, Any}
    mode = _reduced_mpcc_global_polish_objective_mode(objective_mode)
    state_reference_mode =
        _reduced_mpcc_global_polish_objective_state_reference(objective_state_reference)
    trust_region_reference_mode =
        _reduced_mpcc_global_polish_objective_state_reference(trust_region_state_reference)
    trace_trust_region_reference_mode =
        _reduced_mpcc_global_polish_objective_state_reference(
            trace_trust_region_state_reference,
        )
    terminal_trust_region_reference_mode =
        _reduced_mpcc_global_polish_objective_state_reference(
            terminal_trust_region_state_reference,
        )
    rho = _reduced_mpcc_global_polish_nonnegative_weight(objective_rho, "objective_rho")
    state_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        objective_state_tracking_weight,
        "objective_state_tracking_weight",
    )
    biomass_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        objective_biomass_tracking_weight,
        "objective_biomass_tracking_weight",
    )
    biomass_terminal_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        objective_biomass_terminal_weight,
        "objective_biomass_terminal_weight",
    )
    sugar_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        objective_sugar_tracking_weight,
        "objective_sugar_tracking_weight",
    )
    total_sugar_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        objective_total_sugar_tracking_weight,
        "objective_total_sugar_tracking_weight",
    )
    total_sugar_terminal_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        objective_total_sugar_terminal_weight,
        "objective_total_sugar_terminal_weight",
    )
    flux_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        objective_flux_tracking_weight,
        "objective_flux_tracking_weight",
    )
    derivative_weight = _reduced_mpcc_global_polish_nonnegative_weight(
        objective_derivative_regularization_weight,
        "objective_derivative_regularization_weight",
    )

    metadata = Dict{String, Any}(
        "global_polish_objective_mode" => mode,
        "global_polish_objective_state_reference" => state_reference_mode,
        "global_polish_objective_rho" => rho,
        "global_polish_objective_state_tracking_weight" => state_weight,
        "global_polish_objective_biomass_tracking_weight" => biomass_weight,
        "global_polish_objective_biomass_terminal_weight" => biomass_terminal_weight,
        "global_polish_objective_sugar_tracking_weight" => sugar_weight,
        "global_polish_objective_total_sugar_tracking_weight" => total_sugar_weight,
        "global_polish_objective_total_sugar_terminal_weight" =>
            total_sugar_terminal_weight,
        "global_polish_objective_flux_tracking_weight" => flux_weight,
        "global_polish_objective_derivative_regularization_weight" => derivative_weight,
        "global_polish_objective_component_normalization" => "average_by_component_count",
        "global_polish_objective_state_scaling" => "per_state_max_abs_start_or_one",
        "global_polish_objective_flux_scaling" => "per_reaction_max_abs_start_or_one",
        "global_polish_trust_region_enabled" => trust_region_enabled,
        "global_polish_trace_trust_region_enabled" => trace_trust_region_enabled,
        "global_polish_terminal_trust_region_enabled" =>
            terminal_trust_region_enabled,
    )
    if (
        trust_region_enabled ||
        trace_trust_region_enabled ||
        terminal_trust_region_enabled
    ) &&
        mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_LEGACY
        throw(
            ArgumentError(
                "Reduced MPCC global polish trust regions require a replaced objective " *
                "(de_oliveira_gap or de_oliveira_tracking), not legacy_zero_derivative.",
            ),
        )
    end
    if mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_LEGACY
        metadata["global_polish_objective_description"] =
            "legacy zero-derivative regularization from collocation scaffold"
        metadata["global_polish_objective_replaced"] = false
        return metadata
    end

    nlp = problem.smoke_problem.nlp
    jump_model = nlp.jump_model
    n_states = nlp.dimensions.n_states
    n_reactions = nlp.dimensions.n_reactions
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree
    target_state_boundary, target_state_collocation, resolved_state_reference =
        _reduced_mpcc_global_polish_objective_state_targets(
            starts,
            nlp,
            state_reference_mode,
            sequential_reference,
        )
    metadata["global_polish_objective_state_reference"] = resolved_state_reference
    trust_region_state_boundary,
    trust_region_state_collocation,
    resolved_trust_region_reference =
        _reduced_mpcc_global_polish_objective_state_targets(
            starts,
            nlp,
            trust_region_reference_mode,
            sequential_reference,
        )
    metadata["global_polish_trust_region_state_reference"] =
        resolved_trust_region_reference
    trace_trust_region_state_boundary = starts.state_boundary
    trace_trust_region_state_collocation = starts.state_collocation
    resolved_trace_trust_region_reference = "disabled"
    if trace_trust_region_enabled
        trace_state_boundary, trace_state_collocation, trace_reference =
            _reduced_mpcc_global_polish_objective_state_targets(
                starts,
                nlp,
                trace_trust_region_reference_mode,
                sequential_reference,
            )
        trace_trust_region_state_boundary = trace_state_boundary
        trace_trust_region_state_collocation = trace_state_collocation
        resolved_trace_trust_region_reference = trace_reference
    end
    metadata["global_polish_trace_trust_region_state_reference"] =
        resolved_trace_trust_region_reference
    terminal_trust_region_state_boundary = starts.state_boundary
    resolved_terminal_trust_region_reference = "disabled"
    if terminal_trust_region_enabled
        terminal_state_boundary, _, terminal_reference =
            _reduced_mpcc_global_polish_objective_state_targets(
                starts,
                nlp,
                terminal_trust_region_reference_mode,
                sequential_reference,
            )
        terminal_trust_region_state_boundary = terminal_state_boundary
        resolved_terminal_trust_region_reference = terminal_reference
    end
    metadata["global_polish_terminal_trust_region_state_reference"] =
        resolved_terminal_trust_region_reference
    state_scales = _reduced_mpcc_global_polish_state_scales(starts)
    flux_scales = _reduced_mpcc_global_polish_flux_scales(starts)
    state_tracking_terms = n_states * (nfe + 1 + nfe * degree)
    flux_tracking_terms = n_reactions * nfe * degree
    derivative_terms = n_states * nfe * degree
    complementarity_terms = 2 * n_reactions * nfe * degree
    biomass_index = _reduced_mpcc_global_polish_state_index(starts, n_states, "biomass")
    biomass_tracking_terms = nfe + 1 + nfe * degree
    glucose_index_raw =
        _reduced_mpcc_global_polish_state_index(starts, n_states, "glucose")
    fructose_index_raw =
        _reduced_mpcc_global_polish_state_index(starts, n_states, "fructose")
    sugar_tracking_requested =
        sugar_weight > 0.0 ||
        total_sugar_weight > 0.0 ||
        total_sugar_terminal_weight > 0.0
    if sugar_tracking_requested &&
        (glucose_index_raw === nothing || fructose_index_raw === nothing)
        throw(
            ArgumentError(
                "Reduced MPCC global polish sugar tracking requires glucose and " *
                "fructose states.",
            ),
        )
    end
    sugar_indices = if glucose_index_raw === nothing || fructose_index_raw === nothing
        Int[]
    else
        Int[Int(glucose_index_raw), Int(fructose_index_raw)]
    end
    sugar_tracking_terms =
        isempty(sugar_indices) ? 0 : length(sugar_indices) * (nfe + 1 + nfe * degree)
    total_sugar_tracking_terms = isempty(sugar_indices) ? 0 : nfe + 1 + nfe * degree
    total_sugar_scale = isempty(sugar_indices) ? 1.0 :
        max(1.0, state_scales[sugar_indices[1]] + state_scales[sugar_indices[2]])

    state_tracking = if mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING &&
        state_weight > 0.0
        (
            sum(
                ((nlp.state_boundary[i, k] - target_state_boundary[i, k]) / state_scales[i])^2
                for i in 1:n_states, k in 1:(nfe + 1)
            ) +
            sum(
                (
                    (
                        nlp.state_collocation[i, e, j] -
                        target_state_collocation[i, e, j]
                    ) / state_scales[i]
                )^2 for i in 1:n_states, e in 1:nfe, j in 1:degree
            )
        ) / state_tracking_terms
    else
        0.0
    end

    biomass_tracking = if mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING &&
        biomass_weight > 0.0 && biomass_index !== nothing
        i = biomass_index
        (
            sum(
                ((nlp.state_boundary[i, k] - target_state_boundary[i, k]) / state_scales[i])^2
                for k in 1:(nfe + 1)
            ) +
            sum(
                (
                    (
                        nlp.state_collocation[i, e, j] -
                        target_state_collocation[i, e, j]
                    ) / state_scales[i]
                )^2 for e in 1:nfe, j in 1:degree
            )
        ) / biomass_tracking_terms
    else
        0.0
    end

    biomass_terminal_tracking = if mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING &&
        biomass_terminal_weight > 0.0 && biomass_index !== nothing
        i = biomass_index
        ((nlp.state_boundary[i, nfe + 1] - target_state_boundary[i, nfe + 1]) / state_scales[i])^2
    else
        0.0
    end

    sugar_tracking = if mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING &&
        sugar_weight > 0.0
        (
            sum(
                ((nlp.state_boundary[i, k] - target_state_boundary[i, k]) / state_scales[i])^2
                for i in sugar_indices, k in 1:(nfe + 1)
            ) +
            sum(
                (
                    (
                        nlp.state_collocation[i, e, j] -
                        target_state_collocation[i, e, j]
                    ) / state_scales[i]
                )^2 for i in sugar_indices, e in 1:nfe, j in 1:degree
            )
        ) / sugar_tracking_terms
    else
        0.0
    end

    total_sugar_tracking = if mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING &&
        total_sugar_weight > 0.0
        g = sugar_indices[1]
        f = sugar_indices[2]
        (
            sum(
                (
                    (
                        nlp.state_boundary[g, k] +
                        nlp.state_boundary[f, k] -
                        target_state_boundary[g, k] -
                        target_state_boundary[f, k]
                    ) / total_sugar_scale
                )^2 for k in 1:(nfe + 1)
            ) +
            sum(
                (
                    (
                        nlp.state_collocation[g, e, j] +
                        nlp.state_collocation[f, e, j] -
                        target_state_collocation[g, e, j] -
                        target_state_collocation[f, e, j]
                    ) / total_sugar_scale
                )^2 for e in 1:nfe, j in 1:degree
            )
        ) / total_sugar_tracking_terms
    else
        0.0
    end

    total_sugar_terminal_tracking =
        if mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING &&
            total_sugar_terminal_weight > 0.0
            g = sugar_indices[1]
            f = sugar_indices[2]
            (
                (
                    nlp.state_boundary[g, nfe + 1] +
                    nlp.state_boundary[f, nfe + 1] -
                    target_state_boundary[g, nfe + 1] -
                    target_state_boundary[f, nfe + 1]
                ) / total_sugar_scale
            )^2
        else
            0.0
        end

    flux_tracking = if mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING &&
        flux_weight > 0.0
        sum(
            ((nlp.flux[r, e, j] - starts.flux[r, e, j]) / flux_scales[r])^2 for
            r in 1:n_reactions, e in 1:nfe, j in 1:degree
        ) / flux_tracking_terms
    else
        0.0
    end

    derivative_regularization = derivative_weight > 0.0 ?
        sum(
            (nlp.state_derivative[i, e, j] / state_scales[i])^2 for
            i in 1:n_states, e in 1:nfe, j in 1:degree
        ) / derivative_terms : 0.0

    trust_region_penalty, trust_region_metadata =
        _reduced_mpcc_global_polish_trust_region_penalty!(
            jump_model,
            nlp,
            starts,
            trust_region_state_boundary,
            trust_region_state_collocation,
            state_scales;
            enabled = trust_region_enabled,
            states = trust_region_states,
            abs_delta = trust_region_abs_delta,
            rel_delta = trust_region_rel_delta,
            weight = trust_region_weight,
        )
    merge!(metadata, trust_region_metadata)

    trace_trust_region_penalty, trace_trust_region_metadata =
        _reduced_mpcc_global_polish_trust_region_penalty!(
            jump_model,
            nlp,
            starts,
            trace_trust_region_state_boundary,
            trace_trust_region_state_collocation,
            state_scales;
            enabled = trace_trust_region_enabled,
            states = trace_trust_region_states,
            abs_delta = trace_trust_region_abs_delta,
            rel_delta = trace_trust_region_rel_delta,
            weight = trace_trust_region_weight,
            metadata_prefix = "global_polish_trace_trust_region",
            variable_prefix = "global_polish_trace_trust_region",
            parameter_prefix = "trace_trust_region",
        )
    merge!(metadata, trace_trust_region_metadata)

    terminal_trust_region_penalty, terminal_trust_region_metadata =
        _reduced_mpcc_global_polish_terminal_trust_region_penalty!(
            jump_model,
            nlp,
            starts,
            terminal_trust_region_state_boundary,
            state_scales;
            enabled = terminal_trust_region_enabled,
            states = terminal_trust_region_states,
            abs_delta = terminal_trust_region_abs_delta,
            rel_delta = terminal_trust_region_rel_delta,
            weight = terminal_trust_region_weight,
        )
    merge!(metadata, terminal_trust_region_metadata)

    bound_feasibility = problem.smoke_problem.bound_feasibility
    dynamic_bounds = bound_feasibility.dynamic_bounds
    lower_duals = bound_feasibility.lower_bound_duals
    upper_duals = bound_feasibility.upper_bound_duals
    de_oliveira_bracket = if rho > 0.0
        sum(
            (
                nlp.flux[r, e, j] -
                _reduced_dcdfba_lower_bound_expression(nlp, dynamic_bounds, r, e, j)
            ) * lower_duals[r, e, j] +
            (
                nlp.flux[r, e, j] -
                _reduced_dcdfba_upper_bound_expression(nlp, dynamic_bounds, r, e, j)
            ) * upper_duals[r, e, j] for
            r in 1:n_reactions, e in 1:nfe, j in 1:degree
        ) / complementarity_terms
    else
        0.0
    end

    # With this codebase's dual signs, the bracket is nonpositive at feasible
    # points. Thus `phi - rho * bracket` is a nonnegative gap penalty.
    JuMP.@objective(
        jump_model,
        Min,
        state_weight * state_tracking +
        biomass_weight * biomass_tracking +
        biomass_terminal_weight * biomass_terminal_tracking +
        sugar_weight * sugar_tracking +
        total_sugar_weight * total_sugar_tracking +
        total_sugar_terminal_weight * total_sugar_terminal_tracking +
        flux_weight * flux_tracking +
        derivative_weight * derivative_regularization -
        rho * de_oliveira_bracket +
        trust_region_penalty +
        trace_trust_region_penalty +
        terminal_trust_region_penalty,
    )

    metadata["global_polish_objective_replaced"] = true
    metadata["global_polish_objective_description"] =
        mode == REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_DE_OLIVEIRA_TRACKING ?
        "normalized seed-tracking Phi plus de Oliveira complementarity gap penalty" :
        "zero Phi plus de Oliveira complementarity gap penalty"
    metadata["global_polish_objective_formula"] =
        "min Phi(x,v) - rho * mean((v-lb)*alpha_L + (v-ub)*alpha_U)"
    metadata["global_polish_objective_dual_sign_convention"] =
        "alpha_L<=0, alpha_U>=0; de Oliveira bracket is nonpositive for feasible bounds"
    metadata["global_polish_objective_state_tracking_terms"] = state_tracking_terms
    metadata["global_polish_objective_flux_tracking_terms"] = flux_tracking_terms
    metadata["global_polish_objective_derivative_terms"] = derivative_terms
    metadata["global_polish_objective_complementarity_terms"] = complementarity_terms
    metadata["global_polish_objective_de_oliveira_gap_enabled"] = rho > 0.0
    metadata["global_polish_objective_biomass_state_index"] =
        biomass_index === nothing ? missing : biomass_index
    metadata["global_polish_objective_biomass_tracking_terms"] =
        biomass_index === nothing ? 0 : biomass_tracking_terms
    metadata["global_polish_objective_glucose_state_index"] =
        glucose_index_raw === nothing ? missing : glucose_index_raw
    metadata["global_polish_objective_fructose_state_index"] =
        fructose_index_raw === nothing ? missing : fructose_index_raw
    metadata["global_polish_objective_sugar_tracking_terms"] = sugar_tracking_terms
    metadata["global_polish_objective_total_sugar_tracking_terms"] =
        total_sugar_tracking_terms
    metadata["global_polish_objective_total_sugar_terminal_terms"] =
        isempty(sugar_indices) ? 0 : 1
    metadata["global_polish_objective_total_sugar_scale"] = total_sugar_scale
    metadata["global_polish_objective_state_scale_min"] = minimum(state_scales)
    metadata["global_polish_objective_state_scale_max"] = maximum(state_scales)
    metadata["global_polish_objective_flux_scale_min"] = minimum(flux_scales)
    metadata["global_polish_objective_flux_scale_max"] = maximum(flux_scales)
    return metadata
end

function _reduced_mpcc_global_polish_current_start_values(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    source_metadata::Dict{String, Any},
)::ReducedDCDFBAMPCCWindowedStartValues
    nlp = problem.smoke_problem.nlp
    grid = nlp.kkt_problem.grid
    nfe = nlp.dimensions.nfe
    degree = nlp.dimensions.collocation_degree
    boundary_times = Float64[grid.tspan[1]]
    for e in 1:nfe
        push!(boundary_times, Float64(element_bounds(grid, e)[2]))
    end
    collocation_times = Float64[
        Float64(collocation_time(grid, e, j)) for e in 1:nfe for j in 1:degree
    ]
    metadata = Dict{String, Any}(
        "start_type" => "reduced_dcdfba_mpcc_artifact_state_initialization_start_values",
        "source_window_count" => get(source_metadata, "source_window_count", missing),
        "source_completed_required" => get(source_metadata, "source_completed_required", false),
        "source_continuation_completed" =>
            get(source_metadata, "source_continuation_completed", missing),
        "source_total_nfe" => nfe,
        "source_local_nfe_values" =>
            get(source_metadata, "source_local_nfe_values", Int[]),
        "source_collocation_degree" => degree,
        "source_n_states" => nlp.dimensions.n_states,
        "source_n_reactions" => nlp.dimensions.n_reactions,
        "source_n_metabolites" => nlp.kkt_problem.dimensions.n_metabolites,
        "source_boundary_times" => boundary_times,
        "source_collocation_times" => collocation_times,
        "source_initial_time" => first(boundary_times),
        "source_final_time" => last(boundary_times),
        "source_horizon" => last(boundary_times) - first(boundary_times),
        "source_boundary_point_count" => length(boundary_times),
        "source_collocation_point_count" => length(collocation_times),
        "source_max_boundary_join_mismatch" =>
            get(source_metadata, "source_max_boundary_join_mismatch", 0.0),
        "all_source_candidates_residual_feasible" =>
            get(source_metadata, "all_source_candidates_residual_feasible", missing),
        "all_source_candidates_trajectory_ready" =>
            get(source_metadata, "all_source_candidates_trajectory_ready", missing),
        "outputs_written" => false,
        "start_values_are_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
    merge!(metadata, source_metadata)
    return ReducedDCDFBAMPCCWindowedStartValues(
        _reduced_mpcc_global_polish_variable_start_values(nlp.state_boundary),
        _reduced_mpcc_global_polish_variable_start_values(nlp.state_collocation),
        _reduced_mpcc_global_polish_variable_start_values(nlp.state_derivative),
        _reduced_mpcc_global_polish_variable_start_values(nlp.flux),
        _reduced_mpcc_global_polish_variable_start_values(
            problem.smoke_problem.bound_feasibility.lower_bound_duals,
        ),
        _reduced_mpcc_global_polish_variable_start_values(
            problem.smoke_problem.bound_feasibility.upper_bound_duals,
        ),
        _reduced_mpcc_global_polish_variable_start_values(
            problem.smoke_problem.stationarity.mass_balance_duals,
        ),
        metadata,
    )
end

function _reduced_mpcc_global_polish_variable_start_values(variables)
    values = Array{Float64}(undef, size(variables))
    for index in eachindex(variables)
        value = JuMP.start_value(variables[index])
        values[index] = value === nothing ? 0.0 : Float64(value)
    end
    return values
end

"""
    polish_reduced_dcdfba_mpcc_windowed_candidate(model, reaction_map, continuation; kwargs...)

Build a single reduced MPCC over the reached windowed horizon, initialize it
from the windowed candidate arrays, and run one guarded Ipopt/MUMPS global
polish attempt.
"""
function polish_reduced_dcdfba_mpcc_windowed_candidate(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult;
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} = 500,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    objective_mode::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_LEGACY,
    objective_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    objective_rho::Real = 1.0,
    objective_state_tracking_weight::Real = 1.0,
    objective_biomass_tracking_weight::Real = 0.0,
    objective_biomass_terminal_weight::Real = 0.0,
    objective_sugar_tracking_weight::Real = 0.0,
    objective_total_sugar_tracking_weight::Real = 0.0,
    objective_total_sugar_terminal_weight::Real = 0.0,
    objective_flux_tracking_weight::Real = 0.0,
    objective_derivative_regularization_weight::Real = 0.0,
    trust_region_enabled::Bool = false,
    trust_region_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    trust_region_states::AbstractString =
        join(REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_TRUST_REGION_DEFAULT_STATES, ","),
    trust_region_abs_delta::Real = 0.0,
    trust_region_rel_delta::Real = 0.02,
    trust_region_weight::Real = 100.0,
    trace_trust_region_enabled::Bool = false,
    trace_trust_region_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    trace_trust_region_states::AbstractString = "aromas",
    trace_trust_region_abs_delta::Real = 0.0,
    trace_trust_region_rel_delta::Real = 0.02,
    trace_trust_region_weight::Real = 100.0,
    terminal_trust_region_enabled::Bool = false,
    terminal_trust_region_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    terminal_trust_region_states::AbstractString = "total_sugar",
    terminal_trust_region_abs_delta::Real = 0.0,
    terminal_trust_region_rel_delta::Real = 0.001,
    terminal_trust_region_weight::Real = 100.0,
    biological_acceptance_enabled::Bool = false,
    biological_acceptance_states::AbstractString =
        join(
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_STATES,
            ",",
        ),
    biological_acceptance_relative_tolerance::Real = 0.01,
    biological_acceptance_absolute_tolerance::Real = 1.0e-9,
    biological_acceptance_final_states::AbstractString =
        join(
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_FINAL_STATES,
            ",",
        ),
    biological_acceptance_final_absolute_tolerance::Real = 1.0e-4,
    structural_acceptance_relative_tolerance::Real = 0.05,
    accept_post_solve_requires_trajectory_ready::Bool = false,
    require_pre_solve_ready::Bool = false,
    silent::Bool = true,
    require_complete::Bool = true,
    collocation_repair_enabled::Bool = true,
    collocation_repair_max_iterations::Int = 8,
    collocation_repair_tolerance::Real = 1.0e-7,
    pre_solve_start_output_dir::Union{Nothing, AbstractString} = nothing,
    pre_solve_start_output_overwrite::Bool = true,
)::ReducedDCDFBAMPCCGlobalPolishResult
    starts = build_reduced_dcdfba_mpcc_windowed_start_values(
        continuation;
        require_complete = require_complete,
    )
    sequential_reference = _reduced_mpcc_global_polish_sequential_reference(
        continuation,
        starts,
    )
    return _polish_reduced_dcdfba_mpcc_global_start_values(
        model,
        reaction_map,
        continuation,
        starts,
        sequential_reference;
        initialization_reference = sequential_reference,
        residual_thresholds = residual_thresholds,
        params = params,
        optimizer = optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        objective_mode = objective_mode,
        objective_state_reference = objective_state_reference,
        objective_rho = objective_rho,
        objective_state_tracking_weight = objective_state_tracking_weight,
        objective_biomass_tracking_weight = objective_biomass_tracking_weight,
        objective_biomass_terminal_weight = objective_biomass_terminal_weight,
        objective_sugar_tracking_weight = objective_sugar_tracking_weight,
        objective_total_sugar_tracking_weight = objective_total_sugar_tracking_weight,
        objective_total_sugar_terminal_weight = objective_total_sugar_terminal_weight,
        objective_flux_tracking_weight = objective_flux_tracking_weight,
        objective_derivative_regularization_weight =
            objective_derivative_regularization_weight,
        trust_region_enabled = trust_region_enabled,
        trust_region_state_reference = trust_region_state_reference,
        trust_region_states = trust_region_states,
        trust_region_abs_delta = trust_region_abs_delta,
        trust_region_rel_delta = trust_region_rel_delta,
        trust_region_weight = trust_region_weight,
        trace_trust_region_enabled = trace_trust_region_enabled,
        trace_trust_region_state_reference = trace_trust_region_state_reference,
        trace_trust_region_states = trace_trust_region_states,
        trace_trust_region_abs_delta = trace_trust_region_abs_delta,
        trace_trust_region_rel_delta = trace_trust_region_rel_delta,
        trace_trust_region_weight = trace_trust_region_weight,
        terminal_trust_region_enabled = terminal_trust_region_enabled,
        terminal_trust_region_state_reference = terminal_trust_region_state_reference,
        terminal_trust_region_states = terminal_trust_region_states,
        terminal_trust_region_abs_delta = terminal_trust_region_abs_delta,
        terminal_trust_region_rel_delta = terminal_trust_region_rel_delta,
        terminal_trust_region_weight = terminal_trust_region_weight,
        biological_acceptance_enabled = biological_acceptance_enabled,
        biological_acceptance_states = biological_acceptance_states,
        biological_acceptance_relative_tolerance =
            biological_acceptance_relative_tolerance,
        biological_acceptance_absolute_tolerance =
            biological_acceptance_absolute_tolerance,
        biological_acceptance_final_states = biological_acceptance_final_states,
        biological_acceptance_final_absolute_tolerance =
            biological_acceptance_final_absolute_tolerance,
        structural_acceptance_relative_tolerance =
            structural_acceptance_relative_tolerance,
        accept_post_solve_requires_trajectory_ready =
            accept_post_solve_requires_trajectory_ready,
        require_pre_solve_ready = require_pre_solve_ready,
        silent = silent,
        require_complete = require_complete,
        start_source_label = "windowed_candidate",
        collocation_repair_enabled = collocation_repair_enabled,
        collocation_repair_max_iterations = collocation_repair_max_iterations,
        collocation_repair_tolerance = collocation_repair_tolerance,
        pre_solve_start_output_dir = pre_solve_start_output_dir,
        pre_solve_start_output_overwrite = pre_solve_start_output_overwrite,
    )
end

function _polish_reduced_dcdfba_mpcc_global_start_values(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    source_continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    sequential_reference::SimulationResult;
    initialization_reference::SimulationResult = sequential_reference,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} = 500,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    objective_mode::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_LEGACY,
    objective_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    objective_rho::Real = 1.0,
    objective_state_tracking_weight::Real = 1.0,
    objective_biomass_tracking_weight::Real = 0.0,
    objective_biomass_terminal_weight::Real = 0.0,
    objective_sugar_tracking_weight::Real = 0.0,
    objective_total_sugar_tracking_weight::Real = 0.0,
    objective_total_sugar_terminal_weight::Real = 0.0,
    objective_flux_tracking_weight::Real = 0.0,
    objective_derivative_regularization_weight::Real = 0.0,
    trust_region_enabled::Bool = false,
    trust_region_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    trust_region_states::AbstractString =
        join(REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_TRUST_REGION_DEFAULT_STATES, ","),
    trust_region_abs_delta::Real = 0.0,
    trust_region_rel_delta::Real = 0.02,
    trust_region_weight::Real = 100.0,
    trace_trust_region_enabled::Bool = false,
    trace_trust_region_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    trace_trust_region_states::AbstractString = "aromas",
    trace_trust_region_abs_delta::Real = 0.0,
    trace_trust_region_rel_delta::Real = 0.02,
    trace_trust_region_weight::Real = 100.0,
    terminal_trust_region_enabled::Bool = false,
    terminal_trust_region_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    terminal_trust_region_states::AbstractString = "total_sugar",
    terminal_trust_region_abs_delta::Real = 0.0,
    terminal_trust_region_rel_delta::Real = 0.001,
    terminal_trust_region_weight::Real = 100.0,
    biological_acceptance_enabled::Bool = false,
    biological_acceptance_states::AbstractString =
        join(
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_STATES,
            ",",
        ),
    biological_acceptance_relative_tolerance::Real = 0.01,
    biological_acceptance_absolute_tolerance::Real = 1.0e-9,
    biological_acceptance_final_states::AbstractString =
        join(
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_FINAL_STATES,
            ",",
        ),
    biological_acceptance_final_absolute_tolerance::Real = 1.0e-4,
    structural_acceptance_relative_tolerance::Real = 0.05,
    accept_post_solve_requires_trajectory_ready::Bool = false,
    require_pre_solve_ready::Bool = false,
    silent::Bool = true,
    require_complete::Bool = true,
    start_source_label::AbstractString = "windowed_candidate",
    apply_default_start_initializers::Bool = true,
    dense_start_kkt_refresh_policy::AbstractString = "off",
    collocation_repair_enabled::Bool = true,
    collocation_repair_max_iterations::Int = 8,
    collocation_repair_tolerance::Real = 1.0e-7,
    pre_solve_start_output_dir::Union{Nothing, AbstractString} = nothing,
    pre_solve_start_output_overwrite::Bool = true,
)::ReducedDCDFBAMPCCGlobalPolishResult
    tspan = (first(sequential_reference.time), last(sequential_reference.time))
    nfe = Int(starts.metadata["source_total_nfe"])
    degree = Int(starts.metadata["source_collocation_degree"])

    _reduced_mpcc_global_polish_artifact_source_trace(
        "global_start_values_begin tspan=$(tspan) nfe=$(nfe) degree=$(degree)",
    )
    _reduced_mpcc_global_polish_artifact_source_trace("build_solve_attempt_problem_begin")
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = initialization_reference,
        tspan = tspan,
        nfe = nfe,
        degree = degree,
        params = params,
        residual_thresholds = residual_thresholds,
        optimizer = optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        apply_default_start_initializers = apply_default_start_initializers,
        silent = silent,
    )
    _reduced_mpcc_global_polish_artifact_source_trace("build_solve_attempt_problem_done")
    _reduced_mpcc_global_polish_artifact_source_trace("apply_windowed_starts_begin")
    start_summary_table = apply_reduced_dcdfba_mpcc_windowed_starts!(problem, starts)
    _reduced_mpcc_global_polish_artifact_source_trace("apply_windowed_starts_done")
    refresh_metadata = Dict{String, Any}(
        "global_polish_flux_dual_refresh_after_windowed_start" =>
            apply_default_start_initializers,
        "global_polish_flux_dual_refresh_after_prefix_overlay" =>
            get(starts.metadata, "incremental_global_prefix_candidate_applied", false) === true,
    )
    if apply_default_start_initializers
        _reduced_mpcc_global_polish_artifact_source_trace("default_start_refresh_begin")
        refresh_metadata["global_polish_flux_dual_refresh_policy"] =
            "refresh_dynamic_flux_and_stationarity_duals_from_current_state_start"
        for metadata in (
            _reduced_dcdfba_apply_dynamic_flux_lp_starts!(problem.smoke_problem),
            _reduced_dcdfba_project_dynamic_flux_starts!(problem.smoke_problem),
            _reduced_dcdfba_apply_stationarity_dual_starts!(problem.smoke_problem),
        )
            merge!(refresh_metadata, metadata)
        end
        _reduced_mpcc_global_polish_artifact_source_trace("default_start_refresh_done")
    else
        refresh_metadata["global_polish_flux_dual_refresh_policy"] =
            "not_applied_preserve_dense_global_start_flux_duals"
        refresh_metadata["global_polish_flux_dual_refresh_skipped"] = true
        refresh_metadata["global_polish_flux_dual_refresh_skip_reason"] =
            "preserve_dense_or_prefix_rhs_and_stationarity_starts"
    end
    dense_kkt_policy = lowercase(strip(String(dense_start_kkt_refresh_policy)))
    dense_kkt_element_indices = _reduced_mpcc_global_polish_env_element_indices(
        "MPCC_GLOBAL_POLISH_DENSE_START_KKT_REFRESH_ELEMENTS",
        problem.smoke_problem.nlp.dimensions.nfe,
    )
    collocation_repair_element_indices = _reduced_mpcc_global_polish_env_element_indices(
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_ELEMENTS",
        problem.smoke_problem.nlp.dimensions.nfe,
    )
    post_objective_dual_fit_element_indices =
        _reduced_mpcc_global_polish_env_element_indices(
            "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_FIXED_FLUX_DUAL_FIT_ELEMENTS",
            problem.smoke_problem.nlp.dimensions.nfe,
        )
    post_objective_kkt_refresh_element_indices =
        _reduced_mpcc_global_polish_env_element_indices(
            "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_KKT_REFRESH_ELEMENTS",
            problem.smoke_problem.nlp.dimensions.nfe,
        )
    refresh_metadata["global_polish_dense_start_kkt_refresh_elements"] =
        dense_kkt_element_indices === nothing ? "all" : copy(dense_kkt_element_indices)
    if dense_kkt_policy in ("off", "none", "disabled")
        refresh_metadata["global_polish_dense_start_kkt_refresh_applied"] = false
        refresh_metadata["global_polish_dense_start_kkt_refresh_policy"] = "off"
    elseif dense_kkt_policy in ("fixed_flux_dual_fit", "fixed_flux_stationarity_dual_fit")
        _reduced_mpcc_global_polish_artifact_source_trace("dense_fixed_flux_dual_fit_begin")
        dense_kkt_metadata =
            _reduced_dcdfba_apply_fixed_flux_stationarity_dual_fit_starts!(
                problem.smoke_problem;
                complementarity_tau = complementarity_tau,
                element_indices = dense_kkt_element_indices,
            )
        _reduced_mpcc_global_polish_artifact_source_trace("dense_fixed_flux_dual_fit_done")
        refresh_metadata["global_polish_dense_start_kkt_refresh_applied"] = true
        refresh_metadata["global_polish_dense_start_kkt_refresh_policy"] =
            "fixed_flux_stationarity_dual_fit"
        merge!(refresh_metadata, dense_kkt_metadata)
    elseif dense_kkt_policy in ("lp_flux_dual_rhs", "refresh_flux_dual_rhs", "local_lp_flux_dual_rhs")
        _reduced_mpcc_global_polish_artifact_source_trace("dense_lp_flux_dual_refresh_begin")
        refresh_metadata["global_polish_flux_dual_refresh_after_windowed_start"] =
            true
        refresh_metadata["global_polish_flux_dual_refresh_policy"] =
            "refresh_dynamic_flux_and_stationarity_duals_from_dense_state_start"
        refresh_metadata["global_polish_dense_start_kkt_refresh_applied"] = true
        refresh_metadata["global_polish_dense_start_kkt_refresh_policy"] =
            "lp_flux_dual_rhs"
        for metadata in (
            _reduced_dcdfba_apply_dynamic_flux_lp_starts!(
                problem.smoke_problem;
                element_indices = dense_kkt_element_indices,
            ),
            _reduced_dcdfba_project_dynamic_flux_starts!(
                problem.smoke_problem;
                element_indices = dense_kkt_element_indices,
            ),
            _reduced_dcdfba_apply_stationarity_dual_starts!(
                problem.smoke_problem;
                element_indices = dense_kkt_element_indices,
            ),
        )
            merge!(refresh_metadata, metadata)
        end
        _reduced_mpcc_global_polish_artifact_source_trace("dense_lp_flux_dual_refresh_done")
    else
        throw(
            ArgumentError(
                "Reduced MPCC global polish dense start KKT refresh policy must be one of off, fixed_flux_dual_fit, lp_flux_dual_rhs. Got: $(dense_start_kkt_refresh_policy)",
            ),
        )
    end
    merge!(problem.metadata, refresh_metadata)
    merge!(problem.smoke_problem.metadata, refresh_metadata)
    merge!(problem.smoke_problem.nlp.metadata, refresh_metadata)
    repair_metadata = Dict{String, Any}(
        "global_polish_collocation_repair_enabled" => collocation_repair_enabled,
        "global_polish_collocation_repair_max_iterations" =>
            collocation_repair_max_iterations,
        "global_polish_collocation_repair_tolerance" =>
            Float64(collocation_repair_tolerance),
        "global_polish_collocation_repair_elements" =>
            collocation_repair_element_indices === nothing ?
            "all" :
            copy(collocation_repair_element_indices),
    )
    if collocation_repair_enabled
        _reduced_mpcc_global_polish_artifact_source_trace("collocation_repair_begin")
        collocation_repair_metadata =
            _reduced_dcdfba_apply_collocation_consistent_state_starts!(
                problem.smoke_problem;
                max_iterations = collocation_repair_max_iterations,
                tolerance = Float64(collocation_repair_tolerance),
                element_indices = collocation_repair_element_indices,
            )
        repair_metadata["global_polish_collocation_repair_applied"] = true
        repair_metadata["global_polish_collocation_repair_policy"] =
            get(
                collocation_repair_metadata,
                "collocation_consistent_state_start_policy",
                "fixed_point_state_flux_dual_rhs_start_refresh",
            )
        merge!(repair_metadata, collocation_repair_metadata)
        _reduced_mpcc_global_polish_artifact_source_trace("collocation_repair_done")
    else
        repair_metadata["global_polish_collocation_repair_applied"] = false
        repair_metadata["global_polish_collocation_repair_policy"] = "disabled"
    end
    merge!(problem.metadata, repair_metadata)
    merge!(problem.smoke_problem.metadata, repair_metadata)
    merge!(problem.smoke_problem.nlp.metadata, repair_metadata)
    if get(starts.metadata, "incremental_global_tail_reference_reanchor_applied", false) === true
        first_tail_element = Int(starts.metadata["incremental_global_tail_reference_reanchor_first_element"])
        last_tail_element = Int(starts.metadata["incremental_global_tail_reference_reanchor_last_element"])
        tail_repair_enabled =
            _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_TAIL_START_REPAIR_ENABLED", true)
        tail_repair_max_iterations =
            _reduced_dcdfba_env_nonnegative_int("MPCC_GLOBAL_POLISH_TAIL_START_REPAIR_MAX_ITER", 20)
        tail_repair_tolerance =
            _reduced_dcdfba_env_nonnegative_float("MPCC_GLOBAL_POLISH_TAIL_START_REPAIR_TOL", 1.0e-7)
        tail_repair_metadata = Dict{String, Any}(
            "global_polish_tail_start_repair_enabled" => tail_repair_enabled,
            "global_polish_tail_start_repair_max_iterations" =>
                tail_repair_max_iterations,
            "global_polish_tail_start_repair_tolerance" => tail_repair_tolerance,
        )
        if tail_repair_enabled && tail_repair_max_iterations > 0
            _reduced_mpcc_global_polish_artifact_source_trace(
                "tail_start_repair_begin first=$(first_tail_element) last=$(last_tail_element) max_iter=$(tail_repair_max_iterations)",
            )
            merge!(
                tail_repair_metadata,
                _reduced_dcdfba_apply_collocation_consistent_state_starts!(
                    problem.smoke_problem;
                    element_indices = first_tail_element:last_tail_element,
                    max_iterations = tail_repair_max_iterations,
                    tolerance = tail_repair_tolerance,
                ),
            )
            tail_repair_metadata["global_polish_tail_start_repair_applied"] = true
            tail_repair_metadata["global_polish_tail_start_repair_policy"] =
                "reanchored_tail_only_fixed_point_state_flux_dual_rhs_refresh"
            _reduced_mpcc_global_polish_artifact_source_trace("tail_start_repair_done")
        else
            tail_repair_metadata["global_polish_tail_start_repair_applied"] = false
            tail_repair_metadata["global_polish_tail_start_repair_policy"] =
                tail_repair_enabled ? "disabled_by_zero_max_iterations" : "disabled"
            _reduced_mpcc_global_polish_artifact_source_trace(
                "tail_start_repair_skipped enabled=$(tail_repair_enabled) max_iter=$(tail_repair_max_iterations)",
            )
        end
        tail_element_range = first_tail_element:last_tail_element
        tail_flux_projection_enabled = _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_TAIL_FLUX_BOUND_PROJECTION",
            false,
        )
        tail_repair_metadata["global_polish_tail_flux_bound_projection_enabled"] =
            tail_flux_projection_enabled
        if tail_flux_projection_enabled
            _reduced_mpcc_global_polish_artifact_source_trace(
                "tail_flux_bound_projection_begin first=$(first_tail_element) last=$(last_tail_element)",
            )
            merge!(
                tail_repair_metadata,
                _reduced_dcdfba_project_dynamic_flux_starts!(
                    problem.smoke_problem;
                    element_indices = tail_element_range,
                ),
            )
            _reduced_mpcc_global_polish_artifact_source_trace("tail_flux_bound_projection_done")
        end
        tail_rhs_refresh_enabled = _reduced_dcdfba_env_bool(
            "MPCC_GLOBAL_POLISH_TAIL_RHS_DERIVATIVE_REFRESH",
            false,
        )
        tail_repair_metadata["global_polish_tail_rhs_derivative_refresh_enabled"] =
            tail_rhs_refresh_enabled
        if tail_rhs_refresh_enabled
            _reduced_mpcc_global_polish_artifact_source_trace(
                "tail_rhs_derivative_refresh_begin first=$(first_tail_element) last=$(last_tail_element)",
            )
            merge!(
                tail_repair_metadata,
                _reduced_dcdfba_apply_rhs_consistent_derivative_starts!(
                    problem.smoke_problem;
                    element_indices = tail_element_range,
                ),
            )
            _reduced_mpcc_global_polish_artifact_source_trace("tail_rhs_derivative_refresh_done")
        end
        tail_repair_metadata["global_polish_tail_start_repair_first_element"] =
            first_tail_element
        tail_repair_metadata["global_polish_tail_start_repair_last_element"] =
            last_tail_element
        merge!(problem.metadata, tail_repair_metadata)
        merge!(problem.smoke_problem.metadata, tail_repair_metadata)
        merge!(problem.smoke_problem.nlp.metadata, tail_repair_metadata)
    end
    post_repair_dual_fit_enabled =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_POST_REPAIR_FIXED_FLUX_DUAL_FIT", false)
    post_repair_dual_fit_metadata =
        if post_repair_dual_fit_enabled &&
           String(get(problem.metadata, "complementarity_mode", "exact")) ==
           REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES
            _reduced_mpcc_global_polish_artifact_source_trace(
                "post_repair_fixed_flux_dual_fit_begin",
            )
            metadata =
                _reduced_dcdfba_apply_fixed_flux_stationarity_dual_fit_starts!(
                    problem.smoke_problem;
                    complementarity_tau = complementarity_tau,
                )
            metadata["post_repair_fixed_flux_stationarity_dual_fit_applied"] = true
            _reduced_mpcc_global_polish_artifact_source_trace(
                "post_repair_fixed_flux_dual_fit_done",
            )
            metadata
        else
            Dict{String, Any}(
                "post_repair_fixed_flux_stationarity_dual_fit_applied" => false,
                "post_repair_fixed_flux_stationarity_dual_fit_enabled" =>
                    post_repair_dual_fit_enabled,
                "post_repair_fixed_flux_stationarity_dual_fit_skip_reason" =>
                    post_repair_dual_fit_enabled ? "not_scholtes_mode" : "disabled",
            )
        end
    post_repair_dual_fit_metadata[
        "post_repair_fixed_flux_stationarity_dual_fit_enabled"
    ] = post_repair_dual_fit_enabled
    merge!(problem.metadata, post_repair_dual_fit_metadata)
    merge!(problem.smoke_problem.metadata, post_repair_dual_fit_metadata)
    merge!(problem.smoke_problem.nlp.metadata, post_repair_dual_fit_metadata)
    selective_dual_fit_enabled =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_SELECTIVE_FIXED_FLUX_DUAL_FIT", false)
    selective_dual_fit_metadata =
        if selective_dual_fit_enabled &&
           String(get(problem.metadata, "complementarity_mode", "exact")) ==
           REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES
            _reduced_dcdfba_apply_selective_fixed_flux_stationarity_dual_fit_starts!(
                problem.smoke_problem;
                complementarity_tau = complementarity_tau,
            )
        else
            Dict{String, Any}(
                "selective_fixed_flux_stationarity_dual_fit_applied" => false,
                "selective_fixed_flux_stationarity_dual_fit_enabled" =>
                    selective_dual_fit_enabled,
                "selective_fixed_flux_stationarity_dual_fit_skip_reason" =>
                    selective_dual_fit_enabled ? "not_scholtes_mode" : "disabled",
            )
        end
    selective_dual_fit_metadata["selective_fixed_flux_stationarity_dual_fit_enabled"] =
        selective_dual_fit_enabled
    merge!(problem.metadata, selective_dual_fit_metadata)
    merge!(problem.smoke_problem.metadata, selective_dual_fit_metadata)
    merge!(problem.smoke_problem.nlp.metadata, selective_dual_fit_metadata)
    bound_dual_clip_enabled =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_BOUND_DUAL_COMPLEMENTARITY_CLIP", false)
    bound_dual_clip_metadata =
        if bound_dual_clip_enabled &&
           String(get(problem.metadata, "complementarity_mode", "exact")) ==
           REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES
            _reduced_dcdfba_clip_bound_dual_starts_for_complementarity!(
                problem.smoke_problem;
                complementarity_tau = complementarity_tau,
            )
        else
            Dict{String, Any}(
                "bound_dual_complementarity_clip_applied" => false,
                "bound_dual_complementarity_clip_enabled" => bound_dual_clip_enabled,
                "bound_dual_complementarity_clip_skip_reason" =>
                    bound_dual_clip_enabled ? "not_scholtes_mode" : "disabled",
            )
        end
    bound_dual_clip_metadata["bound_dual_complementarity_clip_enabled"] =
        bound_dual_clip_enabled
    merge!(problem.metadata, bound_dual_clip_metadata)
    merge!(problem.smoke_problem.metadata, bound_dual_clip_metadata)
    merge!(problem.smoke_problem.nlp.metadata, bound_dual_clip_metadata)
    _reduced_mpcc_global_polish_artifact_source_trace("apply_objective_begin")
    objective_metadata = _reduced_mpcc_global_polish_apply_objective!(
        problem,
        starts;
        sequential_reference = sequential_reference,
        objective_mode = objective_mode,
        objective_state_reference = objective_state_reference,
        objective_rho = objective_rho,
        objective_state_tracking_weight = objective_state_tracking_weight,
        objective_biomass_tracking_weight = objective_biomass_tracking_weight,
        objective_biomass_terminal_weight = objective_biomass_terminal_weight,
        objective_sugar_tracking_weight = objective_sugar_tracking_weight,
        objective_total_sugar_tracking_weight = objective_total_sugar_tracking_weight,
        objective_total_sugar_terminal_weight = objective_total_sugar_terminal_weight,
        objective_flux_tracking_weight = objective_flux_tracking_weight,
        objective_derivative_regularization_weight =
            objective_derivative_regularization_weight,
        trust_region_enabled = trust_region_enabled,
        trust_region_state_reference = trust_region_state_reference,
        trust_region_states = trust_region_states,
        trust_region_abs_delta = trust_region_abs_delta,
        trust_region_rel_delta = trust_region_rel_delta,
        trust_region_weight = trust_region_weight,
        trace_trust_region_enabled = trace_trust_region_enabled,
        trace_trust_region_state_reference = trace_trust_region_state_reference,
        trace_trust_region_states = trace_trust_region_states,
        trace_trust_region_abs_delta = trace_trust_region_abs_delta,
        trace_trust_region_rel_delta = trace_trust_region_rel_delta,
        trace_trust_region_weight = trace_trust_region_weight,
        terminal_trust_region_enabled = terminal_trust_region_enabled,
        terminal_trust_region_state_reference = terminal_trust_region_state_reference,
        terminal_trust_region_states = terminal_trust_region_states,
        terminal_trust_region_abs_delta = terminal_trust_region_abs_delta,
        terminal_trust_region_rel_delta = terminal_trust_region_rel_delta,
        terminal_trust_region_weight = terminal_trust_region_weight,
    )
    merge!(problem.metadata, objective_metadata)
    merge!(problem.smoke_problem.metadata, objective_metadata)
    merge!(problem.smoke_problem.nlp.metadata, objective_metadata)
    _reduced_mpcc_global_polish_artifact_source_trace("apply_objective_done")
    post_objective_kkt_refresh_enabled =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_POST_OBJECTIVE_KKT_REFRESH", false)
    post_objective_kkt_refresh_metadata = Dict{String, Any}(
        "post_objective_kkt_refresh_enabled" => post_objective_kkt_refresh_enabled,
        "post_objective_kkt_refresh_elements" =>
            post_objective_kkt_refresh_element_indices === nothing ?
            "all" :
            copy(post_objective_kkt_refresh_element_indices),
    )
    if post_objective_kkt_refresh_enabled
        _reduced_mpcc_global_polish_artifact_source_trace(
            "post_objective_kkt_refresh_begin",
        )
        for metadata in (
            _reduced_dcdfba_apply_dynamic_flux_lp_starts!(
                problem.smoke_problem;
                element_indices = post_objective_kkt_refresh_element_indices,
            ),
            _reduced_dcdfba_project_dynamic_flux_starts!(
                problem.smoke_problem;
                element_indices = post_objective_kkt_refresh_element_indices,
            ),
            _reduced_dcdfba_apply_stationarity_dual_starts!(
                problem.smoke_problem;
                element_indices = post_objective_kkt_refresh_element_indices,
            ),
            _reduced_dcdfba_apply_rhs_consistent_derivative_starts!(
                problem.smoke_problem;
                element_indices = post_objective_kkt_refresh_element_indices,
            ),
        )
            merge!(post_objective_kkt_refresh_metadata, metadata)
        end
        post_objective_kkt_refresh_metadata["post_objective_kkt_refresh_applied"] =
            true
        _reduced_mpcc_global_polish_artifact_source_trace(
            "post_objective_kkt_refresh_done",
        )
    else
        post_objective_kkt_refresh_metadata["post_objective_kkt_refresh_applied"] =
            false
        post_objective_kkt_refresh_metadata["post_objective_kkt_refresh_skip_reason"] =
            "disabled"
    end
    merge!(problem.metadata, post_objective_kkt_refresh_metadata)
    merge!(problem.smoke_problem.metadata, post_objective_kkt_refresh_metadata)
    merge!(problem.smoke_problem.nlp.metadata, post_objective_kkt_refresh_metadata)
    post_objective_collocation_repair_enabled = _reduced_dcdfba_env_bool(
        "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_COLLOCATION_REPAIR",
        false,
    )
    post_objective_collocation_repair_metadata = Dict{String, Any}(
        "post_objective_collocation_repair_enabled" =>
            post_objective_collocation_repair_enabled,
        "post_objective_collocation_repair_elements" =>
            post_objective_kkt_refresh_element_indices === nothing ?
            "all" :
            copy(post_objective_kkt_refresh_element_indices),
    )
    if post_objective_collocation_repair_enabled
        _reduced_mpcc_global_polish_artifact_source_trace(
            "post_objective_collocation_repair_begin",
        )
        repair_metadata =
            _reduced_dcdfba_apply_collocation_consistent_state_starts!(
                problem.smoke_problem;
                max_iterations = collocation_repair_max_iterations,
                tolerance = Float64(collocation_repair_tolerance),
                element_indices = post_objective_kkt_refresh_element_indices,
            )
        merge!(post_objective_collocation_repair_metadata, repair_metadata)
        post_objective_collocation_repair_metadata[
            "post_objective_collocation_repair_applied"
        ] = true
        _reduced_mpcc_global_polish_artifact_source_trace(
            "post_objective_collocation_repair_done",
        )
    else
        post_objective_collocation_repair_metadata[
            "post_objective_collocation_repair_applied"
        ] = false
        post_objective_collocation_repair_metadata[
            "post_objective_collocation_repair_skip_reason"
        ] = "disabled"
    end
    merge!(problem.metadata, post_objective_collocation_repair_metadata)
    merge!(problem.smoke_problem.metadata, post_objective_collocation_repair_metadata)
    merge!(problem.smoke_problem.nlp.metadata, post_objective_collocation_repair_metadata)
    post_objective_dual_fit_enabled = _reduced_dcdfba_env_bool(
        "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_FIXED_FLUX_DUAL_FIT",
        false,
    )
    post_objective_dual_fit_metadata =
        if post_objective_dual_fit_enabled &&
           String(get(problem.metadata, "complementarity_mode", "exact")) ==
           REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES
            _reduced_mpcc_global_polish_artifact_source_trace(
                "post_objective_fixed_flux_dual_fit_begin",
            )
            metadata =
                _reduced_dcdfba_apply_fixed_flux_stationarity_dual_fit_starts!(
                    problem.smoke_problem;
                    complementarity_tau = complementarity_tau,
                    element_indices = post_objective_dual_fit_element_indices,
                )
            metadata["post_objective_fixed_flux_stationarity_dual_fit_applied"] = true
            _reduced_mpcc_global_polish_artifact_source_trace(
                "post_objective_fixed_flux_dual_fit_done",
            )
            metadata
        else
            Dict{String, Any}(
                "post_objective_fixed_flux_stationarity_dual_fit_applied" => false,
                "post_objective_fixed_flux_stationarity_dual_fit_enabled" =>
                    post_objective_dual_fit_enabled,
                "post_objective_fixed_flux_stationarity_dual_fit_skip_reason" =>
                    post_objective_dual_fit_enabled ? "not_scholtes_mode" : "disabled",
            )
        end
    post_objective_dual_fit_metadata[
        "post_objective_fixed_flux_stationarity_dual_fit_enabled"
    ] = post_objective_dual_fit_enabled
    post_objective_dual_fit_metadata[
        "post_objective_fixed_flux_stationarity_dual_fit_elements"
    ] =
        post_objective_dual_fit_element_indices === nothing ?
        "all" :
        copy(post_objective_dual_fit_element_indices)
    merge!(problem.metadata, post_objective_dual_fit_metadata)
    merge!(problem.smoke_problem.metadata, post_objective_dual_fit_metadata)
    merge!(problem.smoke_problem.nlp.metadata, post_objective_dual_fit_metadata)
    rhs_refresh_requested =
        apply_default_start_initializers ||
        dense_kkt_policy in ("lp_flux_dual_rhs", "refresh_flux_dual_rhs", "local_lp_flux_dual_rhs")
    if starts.metadata["source_window_count"] > 1 && rhs_refresh_requested
        _reduced_mpcc_global_polish_artifact_source_trace("rhs_derivative_refresh_begin")
        rhs_start_metadata =
            _reduced_dcdfba_apply_rhs_consistent_derivative_starts!(problem.smoke_problem)
        rhs_start_metadata["global_polish_rhs_derivative_refresh_after_dense_start"] = true
        merge!(problem.metadata, rhs_start_metadata)
        merge!(problem.smoke_problem.metadata, rhs_start_metadata)
        merge!(problem.smoke_problem.nlp.metadata, rhs_start_metadata)
        _reduced_mpcc_global_polish_artifact_source_trace("rhs_derivative_refresh_done")
    elseif starts.metadata["source_window_count"] > 1 &&
           get(problem.metadata, "rhs_consistent_derivative_start_applied", false) !== true
        rhs_start_metadata = Dict{String, Any}(
            "rhs_consistent_derivative_start_applied" => false,
            "rhs_consistent_derivative_start_policy" =>
                "not_applied_preserve_dense_global_start_derivatives",
            "rhs_consistent_derivative_start_collocation_points" => 0,
            "rhs_consistent_derivative_start_max_adjustment" => 0.0,
            "rhs_consistent_derivative_start_max_abs_value" => 0.0,
            "rhs_consistent_derivative_start_max_rhs_residual_after" => NaN,
            "global_polish_rhs_derivative_refresh_after_dense_start" => false,
            "global_polish_rhs_derivative_refresh_skipped" => true,
            "global_polish_rhs_derivative_refresh_skip_reason" =>
                "preserve_dense_or_prefix_structural_derivative_starts",
        )
        merge!(problem.metadata, rhs_start_metadata)
        merge!(problem.smoke_problem.metadata, rhs_start_metadata)
        merge!(problem.smoke_problem.nlp.metadata, rhs_start_metadata)
    end

    _reduced_mpcc_global_polish_artifact_source_trace("pre_solve_diagnostics_begin")
    pre_solve_report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)
    _reduced_mpcc_global_polish_artifact_source_trace(
        "pre_solve_diagnostics_done thresholds_satisfied=$(pre_solve_report.residual_thresholds_satisfied) dominant=$(pre_solve_report.dominant_residual)",
    )
    stationarity_top_residual_count =
        _reduced_dcdfba_env_nonnegative_int("MPCC_GLOBAL_POLISH_STATIONARITY_TOP_RESIDUALS", 0)
    stationarity_top_residual_metadata =
        _reduced_mpcc_global_polish_maybe_write_stationarity_top_residuals!(
            problem,
            starts,
            pre_solve_start_output_dir,
            stationarity_top_residual_count,
        )
    merge!(problem.metadata, stationarity_top_residual_metadata)
    merge!(problem.smoke_problem.metadata, stationarity_top_residual_metadata)
    merge!(problem.smoke_problem.nlp.metadata, stationarity_top_residual_metadata)
    _reduced_mpcc_global_polish_artifact_source_trace("pre_solve_current_start_values_begin")
    pre_solve_starts =
        _reduced_mpcc_global_polish_current_start_values(problem, starts.metadata)
    _reduced_mpcc_global_polish_artifact_source_trace("pre_solve_current_start_values_done")
    pre_solve_start_candidate =
        _reduced_mpcc_global_polish_start_candidate_diagnostics(
            pre_solve_starts,
            pre_solve_report;
            value_source = "pre_solve_start_values_after_initialization",
        )
    pre_solve_metadata = _reduced_dcdfba_mpcc_solve_attempt_pre_solve_metadata(
        pre_solve_report,
        require_pre_solve_ready,
    )
    pre_solve_start_output_requested =
        pre_solve_start_output_dir !== nothing &&
        !isempty(strip(String(pre_solve_start_output_dir)))
    pre_solve_start_export_metadata = Dict{String, Any}(
        "global_polish_pre_solve_start_export_requested" =>
            pre_solve_start_output_requested,
        "global_polish_pre_solve_start_exported" => false,
        "global_polish_pre_solve_start_output_dir" =>
            pre_solve_start_output_requested ?
            normpath(String(pre_solve_start_output_dir)) :
            missing,
        "global_polish_pre_solve_start_value_source" =>
            "pre_solve_start_values_after_initialization",
    )
    if pre_solve_start_output_requested
        _reduced_mpcc_global_polish_artifact_source_trace("pre_solve_start_export_begin")
        merge!(
            pre_solve_start_export_metadata,
            _reduced_mpcc_global_polish_export_pre_solve_start_values!(
                pre_solve_starts,
                pre_solve_report,
                pre_solve_metadata,
                String(pre_solve_start_output_dir);
                overwrite = pre_solve_start_output_overwrite,
                start_source_label = start_source_label,
            ),
        )
        _reduced_mpcc_global_polish_artifact_source_trace("pre_solve_start_export_done")
    end
    merge!(problem.metadata, pre_solve_metadata)
    merge!(problem.metadata, pre_solve_start_export_metadata)
    merge!(problem.smoke_problem.metadata, pre_solve_metadata)
    merge!(problem.smoke_problem.metadata, pre_solve_start_export_metadata)
    merge!(problem.smoke_problem.nlp.metadata, pre_solve_metadata)
    merge!(problem.smoke_problem.nlp.metadata, pre_solve_start_export_metadata)
    if Bool(pre_solve_metadata["guarded_solve_attempt_blocked"])
        residual_summary = join(
            [
                string(
                    key,
                    "=",
                    pre_solve_report.residual_values[key],
                    " (threshold=",
                    pre_solve_report.residual_thresholds[key],
                    ", ratio=",
                    pre_solve_report.residual_ratios[key],
                    ")",
                ) for key in pre_solve_report.ranked_residuals[1:min(3, length(pre_solve_report.ranked_residuals))]
            ],
            "; ",
        )
        throw(
            ArgumentError(
                "Reduced MPCC global polish blocked by pre-solve diagnostics. " *
                "dominant_residual=$(pre_solve_report.dominant_residual); " *
                "top_residuals=$(residual_summary). " *
                "Set require_pre_solve_ready=false to run a diagnostic solver call anyway.",
            ),
        )
    end

    _reduced_mpcc_global_polish_artifact_source_trace("ipopt_optimize_begin")
    solve_elapsed_seconds = @elapsed JuMP.optimize!(problem.smoke_problem.nlp.jump_model)
    _reduced_mpcc_global_polish_artifact_source_trace(
        "ipopt_optimize_done elapsed=$(solve_elapsed_seconds)",
    )
    smoke_result = _reduced_dcdfba_mpcc_smoke_result(problem.smoke_problem, solve_elapsed_seconds)
    residual_report = _reduced_dcdfba_mpcc_solve_attempt_residual_report(
        problem.smoke_problem,
        smoke_result,
        problem.residual_thresholds,
        include_structural_rows = false,
    )
    candidate_diagnostics = _reduced_dcdfba_mpcc_candidate_diagnostics_or_nothing(
        problem,
        smoke_result,
    )
    candidate_diagnostics, post_solve_flux_bound_projection_repair_metadata =
        _reduced_mpcc_global_polish_project_candidate_flux_bounds(
            problem,
            smoke_result,
            candidate_diagnostics,
        )
    if candidate_diagnostics !== nothing &&
       get(
           post_solve_flux_bound_projection_repair_metadata,
           "post_solve_flux_bound_projection_repair_applied",
           false,
       ) === true
        _reduced_mpcc_global_polish_refresh_residual_report_from_candidate!(
            residual_report,
            problem,
            candidate_diagnostics,
        )
    end
    merge!(problem.metadata, post_solve_flux_bound_projection_repair_metadata)
    merge!(problem.smoke_problem.metadata, post_solve_flux_bound_projection_repair_metadata)
    merge!(
        problem.smoke_problem.nlp.metadata,
        post_solve_flux_bound_projection_repair_metadata,
    )
    skip_nlp_block_violation_rows = _reduced_dcdfba_mpcc_skip_nlp_block_violation_rows()
    nlp_block_violation_rows =
        skip_nlp_block_violation_rows ? Dict{String, Any}[] :
        _reduced_dcdfba_mpcc_nlp_block_violation_rows(problem.smoke_problem)
    nlp_block_violation_summary =
        skip_nlp_block_violation_rows ?
        _reduced_dcdfba_mpcc_skipped_nlp_block_violation_summary() :
        _reduced_dcdfba_mpcc_nlp_block_violation_summary(nlp_block_violation_rows)
    _reduced_dcdfba_mpcc_apply_structural_nlp_residual_gate!(
        residual_report,
        nlp_block_violation_rows,
        problem.residual_thresholds,
    )
    if skip_nlp_block_violation_rows
        residual_report["structural_nlp_residual_gate_applied"] = false
        residual_report["structural_nlp_residual_gate_skipped"] = true
        residual_report["structural_nlp_residual_gate_skip_reason"] =
            REDUCED_DCDFBA_MPCC_SKIP_NLP_BLOCK_VIOLATION_ROWS_ENV
    end
    post_solve_metadata = _reduced_dcdfba_mpcc_solve_attempt_post_solve_metadata(
        smoke_result,
        residual_report,
    )
    if candidate_diagnostics !== nothing
        _reduced_dcdfba_mpcc_apply_structural_nlp_candidate_gate!(
            candidate_diagnostics,
            smoke_result,
            nlp_block_violation_rows,
            problem.residual_thresholds,
        )
        if skip_nlp_block_violation_rows
            candidate_diagnostics.metadata["candidate_structural_nlp_residual_gate_applied"] =
                false
            candidate_diagnostics.metadata["candidate_structural_nlp_residual_gate_skipped"] =
                true
            candidate_diagnostics.metadata["candidate_structural_nlp_residual_gate_skip_reason"] =
                REDUCED_DCDFBA_MPCC_SKIP_NLP_BLOCK_VIOLATION_ROWS_ENV
        end
    end

    solve_metadata = copy(problem.metadata)
    merge!(solve_metadata, smoke_result.metadata)
    merge!(solve_metadata, residual_report)
    merge!(solve_metadata, post_solve_flux_bound_projection_repair_metadata)
    merge!(solve_metadata, post_solve_metadata)
    merge!(solve_metadata, _reduced_dcdfba_mpcc_candidate_metadata(candidate_diagnostics))
    merge!(solve_metadata, nlp_block_violation_summary)
    solve_metadata["nlp_block_violation_rows"] = nlp_block_violation_rows
    solve_metadata["problem_type"] = REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_TYPE
    solve_metadata["problem_scope"] = "guarded_reduced_global_mpcc_polish_attempt"
    solve_metadata["solver_call_performed"] = true
    solve_metadata["global_polish_start_source"] = String(start_source_label)
    solve_metadata["global_polish_is_scientific_simulation"] = false
    solve_metadata["solved_trajectory_claimed"] = false

    merge!(problem.smoke_problem.metadata, solve_metadata)
    merge!(problem.smoke_problem.nlp.metadata, solve_metadata)

    residuals_available = Bool(residual_report["residuals_available"])
    residual_thresholds_satisfied = Bool(residual_report["residual_thresholds_satisfied"])
    solve_attempt = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        problem.residual_thresholds,
        residuals_available,
        residual_thresholds_satisfied,
        residual_report,
        solve_metadata,
        candidate_diagnostics,
    )
    trajectory_candidate =
        candidate_diagnostics === nothing ? nothing :
        extract_reduced_dcdfba_mpcc_trajectory_candidate(
            candidate_diagnostics;
            require_trajectory_ready = false,
        )
    comparison_result =
        trajectory_candidate === nothing ? nothing :
        compare_reduced_dcdfba_mpcc_to_sequential(
            sequential_reference,
            trajectory_candidate,
        )
    comparison_result === nothing ||
        _reduced_mpcc_sweep_merge_solve_attempt_metadata!(comparison_result, solve_attempt)
    accepted_selection = _reduced_mpcc_global_polish_select_accepted_candidate(
        pre_solve_start_candidate,
        solve_attempt,
        trajectory_candidate,
        comparison_result,
        sequential_reference;
        biological_acceptance_enabled = biological_acceptance_enabled,
        biological_acceptance_states = biological_acceptance_states,
        biological_acceptance_relative_tolerance =
            biological_acceptance_relative_tolerance,
        biological_acceptance_absolute_tolerance =
            biological_acceptance_absolute_tolerance,
        biological_acceptance_final_states = biological_acceptance_final_states,
        biological_acceptance_final_absolute_tolerance =
            biological_acceptance_final_absolute_tolerance,
        structural_acceptance_relative_tolerance =
            structural_acceptance_relative_tolerance,
        accept_post_solve_requires_trajectory_ready =
            accept_post_solve_requires_trajectory_ready,
    )

    metadata = _reduced_mpcc_global_polish_metadata(
        source_continuation,
        starts,
        solve_attempt,
        trajectory_candidate,
        comparison_result,
        start_summary_table,
        require_complete,
    )
    merge!(metadata, accepted_selection.metadata)
    metadata["global_polish_start_source"] = String(start_source_label)
    return ReducedDCDFBAMPCCGlobalPolishResult(
        source_continuation,
        starts,
        solve_attempt,
        trajectory_candidate,
        comparison_result,
        accepted_selection.candidate,
        accepted_selection.trajectory_candidate,
        accepted_selection.comparison_result,
        start_summary_table,
        metadata,
    )
end

function polish_reduced_dcdfba_mpcc_windowed_candidate(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    cascade::ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult;
    kwargs...,
)::ReducedDCDFBAMPCCGlobalPolishResult
    result = polish_reduced_dcdfba_mpcc_windowed_candidate(
        model,
        reaction_map,
        cascade.rebuilt_continuation;
        kwargs...,
    )
    result.metadata["global_polish_source_kind"] = "retry_cascade_rebuilt_continuation"
    result.metadata["cascade_rebuild_applied"] =
        get(cascade.metadata, "cascade_rebuild_applied", false)
    result.metadata["cascade_replacement_window_index"] =
        get(cascade.metadata, "cascade_replacement_window_index", missing)
    result.metadata["cascade_rebuilt_attempt_traffic_light"] =
        get(cascade.metadata, "rebuilt_attempt_traffic_light", missing)
    return result
end

function polish_reduced_dcdfba_mpcc_windowed_artifacts(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    artifact_dir::AbstractString;
    target_horizon::Real,
    window_hours::Real,
    nfe_per_window::Int,
    degree::Int = 3,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} = 500,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    objective_mode::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_LEGACY,
    objective_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    objective_rho::Real = 1.0,
    objective_state_tracking_weight::Real = 1.0,
    objective_biomass_tracking_weight::Real = 0.0,
    objective_biomass_terminal_weight::Real = 0.0,
    objective_sugar_tracking_weight::Real = 0.0,
    objective_total_sugar_tracking_weight::Real = 0.0,
    objective_total_sugar_terminal_weight::Real = 0.0,
    objective_flux_tracking_weight::Real = 0.0,
    objective_derivative_regularization_weight::Real = 0.0,
    trust_region_enabled::Bool = false,
    trust_region_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    trust_region_states::AbstractString =
        join(REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_TRUST_REGION_DEFAULT_STATES, ","),
    trust_region_abs_delta::Real = 0.0,
    trust_region_rel_delta::Real = 0.02,
    trust_region_weight::Real = 100.0,
    trace_trust_region_enabled::Bool = false,
    trace_trust_region_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    trace_trust_region_states::AbstractString = "aromas",
    trace_trust_region_abs_delta::Real = 0.0,
    trace_trust_region_rel_delta::Real = 0.02,
    trace_trust_region_weight::Real = 100.0,
    terminal_trust_region_enabled::Bool = false,
    terminal_trust_region_state_reference::AbstractString =
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE_SEED,
    terminal_trust_region_states::AbstractString = "total_sugar",
    terminal_trust_region_abs_delta::Real = 0.0,
    terminal_trust_region_rel_delta::Real = 0.001,
    terminal_trust_region_weight::Real = 100.0,
    biological_acceptance_enabled::Bool = false,
    biological_acceptance_states::AbstractString =
        join(
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_STATES,
            ",",
        ),
    biological_acceptance_relative_tolerance::Real = 0.01,
    biological_acceptance_absolute_tolerance::Real = 1.0e-9,
    biological_acceptance_final_states::AbstractString =
        join(
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_FINAL_STATES,
            ",",
        ),
    biological_acceptance_final_absolute_tolerance::Real = 1.0e-4,
    structural_acceptance_relative_tolerance::Real = 0.05,
    accept_post_solve_requires_trajectory_ready::Bool = false,
    require_pre_solve_ready::Bool = false,
    silent::Bool = true,
    require_complete::Bool = true,
    artifact_extension_policy::AbstractString = "error",
    prefer_dense_start_artifact::Bool = false,
    dense_start_values_path::Union{Nothing, AbstractString} = nothing,
    sanitize_dense_start_duals::Bool = true,
    dense_start_kkt_refresh_policy::AbstractString = "fixed_flux_dual_fit",
    prefix_candidate_path::Union{Nothing, AbstractString} = nothing,
    allow_unsafe_prefix_candidate::Bool = false,
    apply_default_start_initializers::Union{Nothing, Bool} = nothing,
    collocation_repair_enabled::Bool = true,
    collocation_repair_max_iterations::Int = 8,
    collocation_repair_tolerance::Real = 1.0e-7,
    pre_solve_start_output_dir::Union{Nothing, AbstractString} = nothing,
    pre_solve_start_output_overwrite::Bool = true,
)::ReducedDCDFBAMPCCGlobalPolishResult
    source = _reduced_mpcc_global_polish_artifact_source(
        model,
        artifact_dir;
        target_horizon = target_horizon,
        window_hours = window_hours,
        nfe_per_window = nfe_per_window,
        degree = degree,
        require_complete = require_complete,
        artifact_extension_policy = artifact_extension_policy,
        prefer_dense_start_artifact = prefer_dense_start_artifact,
        dense_start_values_path = dense_start_values_path,
        sanitize_dense_start_duals = sanitize_dense_start_duals,
        prefix_candidate_path = prefix_candidate_path,
        allow_unsafe_prefix_candidate = allow_unsafe_prefix_candidate,
    )
    force_start_kkt_refresh =
        _reduced_dcdfba_env_bool("MPCC_GLOBAL_POLISH_START_KKT_REFRESH_FORCE", false)
    effective_dense_start_kkt_refresh_policy =
        (source.dense_start_used || force_start_kkt_refresh) ?
        dense_start_kkt_refresh_policy :
        "off"
    result = _polish_reduced_dcdfba_mpcc_global_start_values(
        model,
        reaction_map,
        source.source_continuation,
        source.starts,
        source.sequential_reference;
        initialization_reference = source.initialization_reference,
        residual_thresholds = residual_thresholds,
        params = params,
        optimizer = optimizer,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        objective_mode = objective_mode,
        objective_state_reference = objective_state_reference,
        objective_rho = objective_rho,
        objective_state_tracking_weight = objective_state_tracking_weight,
        objective_biomass_tracking_weight = objective_biomass_tracking_weight,
        objective_biomass_terminal_weight = objective_biomass_terminal_weight,
        objective_sugar_tracking_weight = objective_sugar_tracking_weight,
        objective_total_sugar_tracking_weight = objective_total_sugar_tracking_weight,
        objective_total_sugar_terminal_weight = objective_total_sugar_terminal_weight,
        objective_flux_tracking_weight = objective_flux_tracking_weight,
        objective_derivative_regularization_weight =
            objective_derivative_regularization_weight,
        trust_region_enabled = trust_region_enabled,
        trust_region_state_reference = trust_region_state_reference,
        trust_region_states = trust_region_states,
        trust_region_abs_delta = trust_region_abs_delta,
        trust_region_rel_delta = trust_region_rel_delta,
        trust_region_weight = trust_region_weight,
        trace_trust_region_enabled = trace_trust_region_enabled,
        trace_trust_region_state_reference = trace_trust_region_state_reference,
        trace_trust_region_states = trace_trust_region_states,
        trace_trust_region_abs_delta = trace_trust_region_abs_delta,
        trace_trust_region_rel_delta = trace_trust_region_rel_delta,
        trace_trust_region_weight = trace_trust_region_weight,
        terminal_trust_region_enabled = terminal_trust_region_enabled,
        terminal_trust_region_state_reference = terminal_trust_region_state_reference,
        terminal_trust_region_states = terminal_trust_region_states,
        terminal_trust_region_abs_delta = terminal_trust_region_abs_delta,
        terminal_trust_region_rel_delta = terminal_trust_region_rel_delta,
        terminal_trust_region_weight = terminal_trust_region_weight,
        biological_acceptance_enabled = biological_acceptance_enabled,
        biological_acceptance_states = biological_acceptance_states,
        biological_acceptance_relative_tolerance =
            biological_acceptance_relative_tolerance,
        biological_acceptance_absolute_tolerance =
            biological_acceptance_absolute_tolerance,
        biological_acceptance_final_states = biological_acceptance_final_states,
        biological_acceptance_final_absolute_tolerance =
            biological_acceptance_final_absolute_tolerance,
        structural_acceptance_relative_tolerance =
            structural_acceptance_relative_tolerance,
        accept_post_solve_requires_trajectory_ready =
            accept_post_solve_requires_trajectory_ready,
        require_pre_solve_ready = require_pre_solve_ready,
        silent = silent,
        require_complete = require_complete,
        start_source_label = source.start_source_label,
        apply_default_start_initializers =
            apply_default_start_initializers === nothing ?
            !source.dense_start_used :
            apply_default_start_initializers,
        dense_start_kkt_refresh_policy = effective_dense_start_kkt_refresh_policy,
        collocation_repair_enabled = collocation_repair_enabled,
        collocation_repair_max_iterations = collocation_repair_max_iterations,
        collocation_repair_tolerance = collocation_repair_tolerance,
        pre_solve_start_output_dir = pre_solve_start_output_dir,
        pre_solve_start_output_overwrite = pre_solve_start_output_overwrite,
    )
    result.metadata["global_polish_source_kind"] = "windowed_artifacts"
    result.metadata["global_polish_artifact_dir"] = normpath(String(artifact_dir))
    result.metadata["global_polish_artifact_dense_start_used"] = source.dense_start_used
    result.metadata["global_polish_artifact_state_seed_used"] = source.state_seed_used
    result.metadata["global_polish_artifact_dense_start_duals_sanitized"] =
        source.dense_start_duals_sanitized
    result.metadata["global_polish_artifact_dense_start_dual_policy"] =
        source.dense_start_dual_policy
    result.metadata["global_polish_artifact_dense_start_path"] =
        source.dense_start_path
    result.metadata["global_polish_artifact_dense_start_path_explicit"] =
        source.dense_start_path_explicit
    result.metadata["global_polish_artifact_dense_start_kkt_refresh_policy"] =
        String(effective_dense_start_kkt_refresh_policy)
    result.metadata["global_polish_artifact_start_kkt_refresh_forced"] =
        force_start_kkt_refresh
    result.metadata["global_polish_artifact_start_kkt_refresh_forced_without_dense_start"] =
        force_start_kkt_refresh && !source.dense_start_used
    result.metadata["global_polish_artifact_extension_policy"] =
        get(source.source_continuation.metadata, "artifact_extension_policy", "error")
    result.metadata["global_polish_artifact_extension_applied"] =
        get(source.source_continuation.metadata, "artifact_extension_applied", false)
    result.metadata["global_polish_artifact_extension_tail_hours"] =
        get(source.source_continuation.metadata, "artifact_extension_tail_hours", 0.0)
    result.metadata["global_polish_artifact_extension_source_final_time"] =
        get(source.source_continuation.metadata, "artifact_extension_source_final_time", missing)
    result.metadata["global_polish_artifact_extension_target_final_time"] =
        get(source.source_continuation.metadata, "artifact_extension_target_final_time", missing)
    result.metadata["global_polish_artifact_extension_reference_is_scientific"] =
        get(
            source.source_continuation.metadata,
            "artifact_extension_reference_is_scientific",
            false,
        )
    result.metadata["global_polish_incremental_prefix_candidate_used"] =
        source.prefix_candidate_used
    result.metadata["global_polish_incremental_prefix_candidate_path"] =
        source.prefix_candidate_path
    result.metadata["global_polish_incremental_prefix_candidate_handoff_ready"] =
        source.prefix_candidate_handoff_ready
    result.metadata["global_polish_incremental_prefix_candidate_handoff_reason"] =
        source.prefix_candidate_handoff_reason
    result.metadata["global_polish_incremental_prefix_candidate_unsafe_allowed"] =
        source.allow_unsafe_prefix_candidate
    return result
end

function _reduced_mpcc_global_polish_artifact_source(
    model::MetabolicModel,
    artifact_dir::AbstractString;
    target_horizon::Real,
    window_hours::Real,
    nfe_per_window::Int,
    degree::Int,
    require_complete::Bool,
    artifact_extension_policy::AbstractString,
    prefer_dense_start_artifact::Bool,
    dense_start_values_path::Union{Nothing, AbstractString},
    sanitize_dense_start_duals::Bool,
    prefix_candidate_path::Union{Nothing, AbstractString},
    allow_unsafe_prefix_candidate::Bool,
)
    _reduced_mpcc_global_polish_artifact_source_trace("start")
    artifact_path = normpath(String(artifact_dir))
    diagnostics_dir = joinpath(artifact_path, "diagnostics")
    aligned_path = joinpath(diagnostics_dir, "aligned_timeseries.csv")
    window_table_path = joinpath(diagnostics_dir, "window_table.csv")
    isfile(aligned_path) || throw(
        ArgumentError("Reduced MPCC global polish artifact aligned_timeseries.csv not found: $aligned_path"),
    )
    _reduced_mpcc_global_polish_artifact_source_trace("read_aligned_timeseries_begin")
    aligned = CSV.read(aligned_path, DataFrame)
    _reduced_mpcc_global_polish_artifact_source_trace(
        "read_aligned_timeseries_done rows=$(nrow(aligned)) cols=$(ncol(aligned))",
    )
    window_table = isfile(window_table_path) ? CSV.read(window_table_path, DataFrame) : DataFrame()
    _reduced_mpcc_global_polish_artifact_source_trace(
        "artifact_simulations_begin target_horizon=$(Float64(target_horizon)) policy=$(artifact_extension_policy)",
    )
    sequential_reference, state_seed, prefix_aligned = _reduced_mpcc_global_polish_artifact_simulations(
        aligned;
        target_horizon = target_horizon,
        extension_policy = artifact_extension_policy,
    )
    _reduced_mpcc_global_polish_artifact_source_trace(
        "artifact_simulations_done rows=$(nrow(prefix_aligned)) final_time=$(last(sequential_reference.time))",
    )
    target_nfe = _reduced_mpcc_global_polish_target_nfe(
        target_horizon,
        window_hours,
        nfe_per_window,
    )
    _reduced_mpcc_global_polish_artifact_source_trace("target_nfe=$(target_nfe)")
    default_dense_start_path =
        joinpath(artifact_path, "global_start_values", "windowed_start_values.jls")
    dense_start_path_explicit =
        dense_start_values_path !== nothing &&
        !isempty(strip(String(dense_start_values_path)))
    dense_start_path = dense_start_path_explicit ?
        normpath(String(dense_start_values_path)) :
        default_dense_start_path
    dense_start_available =
        _reduced_mpcc_global_polish_start_values_path_available(dense_start_path)
    if dense_start_path_explicit && !dense_start_available
        throw(
            ArgumentError(
                "Reduced MPCC global polish dense start values path not found: $(dense_start_path)",
            ),
        )
    end
    dense_start_used = false
    dense_start_duals_sanitized = false
    dense_start_dual_policy = "not_applicable"
    starts =
        if (prefer_dense_start_artifact || dense_start_path_explicit) && dense_start_available
            dense_start_used = true
            _reduced_mpcc_global_polish_artifact_source_trace(
                "load_dense_start_begin path=$(dense_start_path)",
            )
            _reduced_mpcc_global_polish_slice_starts(
                load_reduced_dcdfba_mpcc_windowed_start_values(dense_start_path),
                target_horizon,
            )
        else
            _reduced_mpcc_global_polish_artifact_source_trace(
                "state_seed_start_values_begin target_nfe=$(target_nfe)",
            )
            _reduced_mpcc_global_polish_state_seed_start_values(
                model,
                state_seed;
                target_nfe = target_nfe,
                degree = degree,
                window_hours = window_hours,
                nfe_per_window = nfe_per_window,
                require_complete = require_complete,
                artifact_dir = artifact_path,
            )
        end
    _reduced_mpcc_global_polish_artifact_source_trace(
        "start_values_done dense_start_used=$(dense_start_used)",
    )
    if dense_start_used
        if sanitize_dense_start_duals
            starts = _reduced_mpcc_global_polish_sanitize_dense_dual_starts(starts)
            dense_start_duals_sanitized = true
            dense_start_dual_policy =
                "zero_bound_and_mass_balance_duals_preserve_dense_state_derivative_flux_starts"
        else
            dense_start_dual_policy = "preserve_dense_bound_and_mass_balance_duals"
        end
    end
    if dense_start_used &&
       Float64(get(starts.metadata, "source_max_boundary_join_mismatch", 0.0)) > 1.0e-8
        starts = _reduced_mpcc_global_polish_overlay_continuous_state_starts(
            starts,
            sequential_reference;
            source_label = "artifact_aligned_timeseries_sequential",
        )
    end
    prefix_candidate_used = false
    normalized_prefix_candidate_path = missing
    prefix_candidate_handoff_ready = missing
    prefix_candidate_handoff_reason = missing
    if prefix_candidate_path !== nothing && !isempty(strip(String(prefix_candidate_path)))
        normalized_prefix_candidate_path = normpath(String(prefix_candidate_path))
        _reduced_mpcc_global_polish_artifact_source_trace(
            "load_prefix_candidate_begin path=$(normalized_prefix_candidate_path)",
        )
        prefix_candidate = load_reduced_dcdfba_mpcc_global_candidate_values(
            normalized_prefix_candidate_path,
        )
        _reduced_mpcc_global_polish_artifact_source_trace("load_prefix_candidate_done")
        _reduced_mpcc_global_polish_artifact_source_trace("prefix_handoff_report_begin")
        handoff_report =
            _reduced_mpcc_global_polish_prefix_candidate_handoff_report(prefix_candidate)
        _reduced_mpcc_global_polish_artifact_source_trace(
            "prefix_handoff_report_done ready=$(handoff_report.ready) reason=$(handoff_report.reason)",
        )
        prefix_candidate_handoff_ready = handoff_report.ready
        prefix_candidate_handoff_reason = handoff_report.reason
        if !handoff_report.ready && !allow_unsafe_prefix_candidate
            throw(
                ArgumentError(
                    "Reduced MPCC global prefix candidate is not safe for incremental handoff: " *
                    "source=$(normalized_prefix_candidate_path), " *
                    "reason=$(handoff_report.reason), " *
                    "solver_status=$(handoff_report.solver_status), " *
                    "primal_status=$(handoff_report.primal_status), " *
                    "candidate_residual_feasible=$(handoff_report.residual_feasible), " *
                    "candidate_trajectory_ready=$(handoff_report.trajectory_ready).",
                ),
            )
        end
        overlay_target_nfe = Int(starts.metadata["source_total_nfe"])
        _reduced_mpcc_global_polish_artifact_source_trace(
            "prefix_overlay_begin target_nfe=$(overlay_target_nfe)",
        )
        starts = _reduced_mpcc_global_polish_overlay_prefix_candidate_starts(
            starts,
            prefix_candidate;
            source_label = normalized_prefix_candidate_path,
            tail_reference = state_seed,
            tail_reference_label = "artifact_aligned_timeseries_mpcc_candidate",
        )
        _reduced_mpcc_global_polish_artifact_source_trace("prefix_overlay_done")
        starts.metadata["incremental_global_prefix_candidate_unsafe_allowed"] =
            allow_unsafe_prefix_candidate && !handoff_report.ready
        starts.metadata["incremental_global_prefix_candidate_unsafe_reason"] =
            allow_unsafe_prefix_candidate && !handoff_report.ready ? handoff_report.reason : missing
        prefix_candidate_used = true
    end
    _reduced_mpcc_global_polish_artifact_source_trace("continuation_metadata_begin")
    continuation = ReducedDCDFBAMPCCWindowedContinuationResult(
        _reduced_mpcc_global_polish_artifact_window_prefix(window_table, last(sequential_reference.time)),
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        sequential_reference,
        state_seed,
        DataFrame(),
        prefix_aligned,
        Dict{String, Any}(
            "continuation_completed" => true,
            "source_kind" => "windowed_artifacts",
            "artifact_dir" => artifact_path,
            "artifact_dense_start_path" => dense_start_path,
            "artifact_dense_start_path_explicit" => dense_start_path_explicit,
            "artifact_dense_start_used" => dense_start_used,
            "artifact_state_seed_used" => !dense_start_used,
            "artifact_dense_start_duals_sanitized" => dense_start_duals_sanitized,
            "artifact_dense_start_dual_policy" => dense_start_dual_policy,
            "artifact_prefix_candidate_used" => prefix_candidate_used,
            "artifact_prefix_candidate_path" => normalized_prefix_candidate_path,
            "artifact_prefix_candidate_handoff_ready" => prefix_candidate_handoff_ready,
            "artifact_prefix_candidate_handoff_reason" => prefix_candidate_handoff_reason,
            "artifact_prefix_candidate_unsafe_allowed" => allow_unsafe_prefix_candidate,
            "artifact_extension_policy" =>
                get(state_seed.metadata, "artifact_extension_policy", "error"),
            "artifact_extension_applied" =>
                get(state_seed.metadata, "artifact_extension_applied", false),
            "artifact_extension_source_final_time" =>
                get(state_seed.metadata, "artifact_extension_source_final_time", missing),
            "artifact_extension_target_final_time" =>
                get(state_seed.metadata, "artifact_extension_target_final_time", missing),
            "artifact_extension_tail_hours" =>
                get(state_seed.metadata, "artifact_extension_tail_hours", 0.0),
            "artifact_extension_row_count" =>
                get(state_seed.metadata, "artifact_extension_row_count", 0),
            "artifact_extension_reference_is_scientific" =>
                get(state_seed.metadata, "artifact_extension_reference_is_scientific", false),
        ),
    )
    _reduced_mpcc_global_polish_artifact_source_trace("done")
    return (
        source_continuation = continuation,
        sequential_reference = sequential_reference,
        initialization_reference = dense_start_used ? sequential_reference : state_seed,
        starts = starts,
        dense_start_used = dense_start_used,
        state_seed_used = !dense_start_used,
        dense_start_duals_sanitized = dense_start_duals_sanitized,
        dense_start_dual_policy = dense_start_dual_policy,
        dense_start_path = dense_start_path,
        dense_start_path_explicit = dense_start_path_explicit,
        prefix_candidate_used = prefix_candidate_used,
        prefix_candidate_path = normalized_prefix_candidate_path,
        prefix_candidate_handoff_ready = prefix_candidate_handoff_ready,
        prefix_candidate_handoff_reason = prefix_candidate_handoff_reason,
        allow_unsafe_prefix_candidate = allow_unsafe_prefix_candidate,
        start_source_label =
            prefix_candidate_used ? "windowed_artifact_dense_start_values_with_global_prefix" :
            dense_start_used && dense_start_duals_sanitized ? "windowed_artifact_dense_state_flux_values_sanitized_duals" :
            dense_start_used ? "windowed_artifact_dense_start_values" :
            "windowed_artifact_state_timeseries",
    )
end

function _reduced_mpcc_global_polish_artifact_source_trace(message::AbstractString)
    enabled = lowercase(strip(get(ENV, "MPCC_GLOBAL_POLISH_ARTIFACT_SOURCE_TRACE", "0")))
    enabled in ("1", "true", "yes", "on") || return nothing
    println("artifact_source_trace: $(round(time(); digits = 3)) | $(message)")
    flush(stdout)
    return nothing
end

function _reduced_mpcc_global_polish_overlay_continuous_state_starts(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    reference::SimulationResult;
    source_label::AbstractString,
)::ReducedDCDFBAMPCCWindowedStartValues
    metadata = copy(starts.metadata)
    previous_mismatch = Float64(get(metadata, "source_max_boundary_join_mismatch", 0.0))
    n_states = size(starts.state_boundary, 1)
    size(reference.states, 1) >= n_states || throw(
        ArgumentError(
            "Continuous state overlay reference has fewer states ($(size(reference.states, 1))) " *
            "than the dense start artifact ($n_states).",
        ),
    )
    target_nfe = Int(metadata["source_total_nfe"])
    degree = Int(metadata["source_collocation_degree"])
    grid = build_collocation_grid(
        (Float64(metadata["source_initial_time"]), Float64(metadata["source_final_time"]));
        nfe = target_nfe,
        degree = degree,
    )
    state_boundary = similar(starts.state_boundary)
    state_collocation = similar(starts.state_collocation)
    state_derivative = similar(starts.state_derivative)
    for e in 1:target_nfe
        left, right = element_bounds(grid, e)
        if e == 1
            state_boundary[:, 1] .=
                _reduced_dcdfba_interpolated_state(reference, left)[1:n_states]
        end
        state_boundary[:, e + 1] .=
            _reduced_dcdfba_interpolated_state(reference, right)[1:n_states]
        for j in 1:degree
            time_value = collocation_time(grid, e, j)
            state_collocation[:, e, j] .=
                _reduced_dcdfba_interpolated_state(reference, time_value)[1:n_states]
            state_derivative[:, e, j] .=
                _reduced_dcdfba_piecewise_state_slope(reference, time_value)[1:n_states]
        end
    end
    metadata["source_max_boundary_join_mismatch"] = 0.0
    metadata["dense_state_continuity_overlay_applied"] = true
    metadata["dense_state_continuity_overlay_source"] = String(source_label)
    metadata["dense_state_continuity_overlay_previous_boundary_join_mismatch"] =
        previous_mismatch
    metadata["dense_state_continuity_overlay_preserves_flux_and_dual_starts"] = true
    return ReducedDCDFBAMPCCWindowedStartValues(
        state_boundary,
        state_collocation,
        state_derivative,
        starts.flux,
        starts.lower_bound_duals,
        starts.upper_bound_duals,
        starts.mass_balance_duals,
        metadata,
    )
end

function _reduced_mpcc_global_polish_overlay_prefix_candidate_starts(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics;
    source_label::AbstractString,
    tail_reference::Union{Nothing, SimulationResult} = nothing,
    tail_reference_label::AbstractString = "tail_reference",
)::ReducedDCDFBAMPCCWindowedStartValues
    total_nfe = Int(starts.metadata["source_total_nfe"])
    candidate_nfe = size(candidate.state_collocation, 2)
    candidate_nfe > 0 || throw(
        ArgumentError("Reduced MPCC global prefix candidate must contain at least one finite element."),
    )
    prefix_nfe = min(candidate_nfe, total_nfe)
    candidate_truncated_to_target = candidate_nfe > total_nfe

    size(candidate.state_boundary, 1) == size(starts.state_boundary, 1) ||
        throw(
            ArgumentError(
                "Reduced MPCC global prefix candidate state_boundary shape " *
                "$(size(candidate.state_boundary)) is incompatible with target state count " *
                "$(size(starts.state_boundary, 1)).",
            ),
        )
    size(candidate.state_boundary, 2) >= prefix_nfe + 1 ||
        throw(ArgumentError("Reduced MPCC global prefix candidate state_boundary is shorter than the overlay prefix."))
    size(candidate.state_collocation[:, 1:prefix_nfe, :]) == size(starts.state_collocation[:, 1:prefix_nfe, :]) ||
        throw(ArgumentError("Reduced MPCC global prefix candidate state_collocation shape is incompatible."))
    size(candidate.state_derivative[:, 1:prefix_nfe, :]) == size(starts.state_derivative[:, 1:prefix_nfe, :]) ||
        throw(ArgumentError("Reduced MPCC global prefix candidate state_derivative shape is incompatible."))
    size(candidate.flux[:, 1:prefix_nfe, :]) == size(starts.flux[:, 1:prefix_nfe, :]) ||
        throw(ArgumentError("Reduced MPCC global prefix candidate flux shape is incompatible."))
    size(candidate.lower_bound_duals[:, 1:prefix_nfe, :]) == size(starts.lower_bound_duals[:, 1:prefix_nfe, :]) ||
        throw(ArgumentError("Reduced MPCC global prefix candidate lower-bound dual shape is incompatible."))
    size(candidate.upper_bound_duals[:, 1:prefix_nfe, :]) == size(starts.upper_bound_duals[:, 1:prefix_nfe, :]) ||
        throw(ArgumentError("Reduced MPCC global prefix candidate upper-bound dual shape is incompatible."))
    size(candidate.mass_balance_duals[:, 1:prefix_nfe, :]) == size(starts.mass_balance_duals[:, 1:prefix_nfe, :]) ||
        throw(ArgumentError("Reduced MPCC global prefix candidate mass-balance dual shape is incompatible."))

    candidate_state_boundary = @view candidate.state_boundary[:, 1:(prefix_nfe + 1)]
    candidate_state_collocation = @view candidate.state_collocation[:, 1:prefix_nfe, :]
    candidate_state_derivative = @view candidate.state_derivative[:, 1:prefix_nfe, :]
    candidate_flux = @view candidate.flux[:, 1:prefix_nfe, :]
    candidate_lower_bound_duals = @view candidate.lower_bound_duals[:, 1:prefix_nfe, :]
    candidate_upper_bound_duals = @view candidate.upper_bound_duals[:, 1:prefix_nfe, :]
    candidate_mass_balance_duals = @view candidate.mass_balance_duals[:, 1:prefix_nfe, :]

    _reduced_mpcc_global_polish_validate_finite_arrays(
        candidate_state_boundary,
        candidate_state_collocation,
        candidate_state_derivative,
        candidate_flux,
        candidate_lower_bound_duals,
        candidate_upper_bound_duals,
        candidate_mass_balance_duals,
    )

    state_boundary = copy(starts.state_boundary)
    state_collocation = copy(starts.state_collocation)
    state_derivative = copy(starts.state_derivative)
    flux = copy(starts.flux)
    lower_bound_duals = copy(starts.lower_bound_duals)
    upper_bound_duals = copy(starts.upper_bound_duals)
    mass_balance_duals = copy(starts.mass_balance_duals)

    old_prefix_boundary = state_boundary[:, 1:(prefix_nfe + 1)]
    prefix_boundary_delta = maximum(abs.(old_prefix_boundary .- candidate_state_boundary))
    join_boundary_delta = maximum(abs.(old_prefix_boundary[:, end] .- candidate_state_boundary[:, end]))
    tail_exists = prefix_nfe < total_nfe
    prefix_final_state = copy(candidate_state_boundary[:, end])
    tail_join_state_before_overlay =
        tail_exists ? copy(state_boundary[:, prefix_nfe + 1]) : Float64[]
    tail_join_shift =
        tail_exists ? prefix_final_state .- tail_join_state_before_overlay : Float64[]
    tail_join_shift_abs = abs.(tail_join_shift)
    tail_join_shift_max_abs = isempty(tail_join_shift_abs) ? 0.0 : maximum(tail_join_shift_abs)
    state_scales = _reduced_mpcc_global_polish_state_scales(starts)
    tail_join_shift_rel_rmse = isempty(tail_join_shift) ? 0.0 :
                               sqrt(sum((tail_join_shift ./ state_scales) .^ 2) / length(tail_join_shift))
    state_names = _reduced_mpcc_global_polish_state_names(starts, length(state_scales))
    dominant_tail_join_index = isempty(tail_join_shift_abs) ? 0 : argmax(tail_join_shift_abs)
    dominant_tail_join_state =
        dominant_tail_join_index == 0 ? "missing" : state_names[dominant_tail_join_index]
    dominant_tail_join_abs =
        dominant_tail_join_index == 0 ? 0.0 : tail_join_shift_abs[dominant_tail_join_index]

    state_boundary[:, 1:(prefix_nfe + 1)] .= candidate_state_boundary
    state_collocation[:, 1:prefix_nfe, :] .= candidate_state_collocation
    state_derivative[:, 1:prefix_nfe, :] .= candidate_state_derivative
    flux[:, 1:prefix_nfe, :] .= candidate_flux
    lower_bound_duals[:, 1:prefix_nfe, :] .= candidate_lower_bound_duals
    upper_bound_duals[:, 1:prefix_nfe, :] .= candidate_upper_bound_duals
    mass_balance_duals[:, 1:prefix_nfe, :] .= candidate_mass_balance_duals

    repair_tolerance = 100.0 * eps(Float64) * max(
        1.0,
        isempty(prefix_final_state) ? 0.0 : maximum(abs, prefix_final_state),
        isempty(tail_join_state_before_overlay) ? 0.0 :
        maximum(abs, tail_join_state_before_overlay),
    )
    tail_shift_repair_applied = tail_exists && tail_join_shift_max_abs > repair_tolerance
    tail_reference_reanchor_applied = false
    tail_flux_dual_extension_applied = false
    if tail_shift_repair_applied
        if tail_reference !== nothing
            n_states = size(state_boundary, 1)
            boundary_times = Float64.(starts.metadata["source_boundary_times"])
            tail_start_time = boundary_times[prefix_nfe + 1]
            reference_tail_start =
                _reduced_dcdfba_interpolated_state(tail_reference, tail_start_time)[1:n_states]
            for boundary_index in (prefix_nfe + 2):size(state_boundary, 2)
                reference_state = _reduced_dcdfba_interpolated_state(
                    tail_reference,
                    boundary_times[boundary_index],
                )[1:n_states]
                state_boundary[:, boundary_index] .=
                    prefix_final_state .+ (reference_state .- reference_tail_start)
            end
            grid = build_collocation_grid(
                (
                    Float64(starts.metadata["source_initial_time"]),
                    Float64(starts.metadata["source_final_time"]),
                );
                nfe = total_nfe,
                degree = Int(starts.metadata["source_collocation_degree"]),
            )
            for e in (prefix_nfe + 1):total_nfe, j in axes(state_collocation, 3)
                time_value = collocation_time(grid, e, j)
                reference_state =
                    _reduced_dcdfba_interpolated_state(tail_reference, time_value)[1:n_states]
                state_collocation[:, e, j] .=
                    prefix_final_state .+ (reference_state .- reference_tail_start)
                state_derivative[:, e, j] .=
                    _reduced_dcdfba_piecewise_state_slope(tail_reference, time_value)[1:n_states]
            end
            tail_reference_reanchor_applied = true
            for e in (prefix_nfe + 1):total_nfe
                flux[:, e, :] .= candidate.flux[:, prefix_nfe, :]
                lower_bound_duals[:, e, :] .= candidate.lower_bound_duals[:, prefix_nfe, :]
                upper_bound_duals[:, e, :] .= candidate.upper_bound_duals[:, prefix_nfe, :]
                mass_balance_duals[:, e, :] .= candidate.mass_balance_duals[:, prefix_nfe, :]
            end
            tail_flux_dual_extension_applied = true
        else
            shift = reshape(tail_join_shift, :, 1)
            if prefix_nfe + 2 <= size(state_boundary, 2)
                state_boundary[:, (prefix_nfe + 2):end] .+= shift
            end
            tail_elements = (prefix_nfe + 1):total_nfe
            for j in axes(state_collocation, 3)
                state_collocation[:, tail_elements, j] .+= shift
            end
        end
    end
    join_boundary_delta_after_repair =
        tail_exists ? maximum(abs.(state_boundary[:, prefix_nfe + 1] .- prefix_final_state)) : 0.0

    metadata = copy(starts.metadata)
    metadata["incremental_global_prefix_candidate_applied"] = true
    metadata["incremental_global_prefix_candidate_source"] = String(source_label)
    handoff_report =
        _reduced_mpcc_global_polish_prefix_candidate_handoff_report(candidate)
    metadata["incremental_global_prefix_candidate_handoff_ready"] =
        handoff_report.ready
    metadata["incremental_global_prefix_candidate_handoff_reason"] =
        handoff_report.reason
    metadata["incremental_global_prefix_candidate_overlay_policy"] =
        tail_reference_reanchor_applied ?
        "state_derivative_prefix_with_reanchored_tail_reference" :
        tail_shift_repair_applied ?
        "state_derivative_prefix_with_constant_state_offset_tail_repair" :
        "state_and_derivative_prefix_only"
    metadata["incremental_global_prefix_candidate_flux_duals_overlayed"] = true
    metadata["incremental_global_prefix_candidate_flux_duals_overlay_policy"] =
        "copy_prefix_candidate_flux_bound_duals_and_mass_balance_duals"
    metadata["incremental_global_prefix_candidate_nfe"] = prefix_nfe
    metadata["incremental_global_prefix_candidate_source_nfe"] = candidate_nfe
    metadata["incremental_global_prefix_candidate_truncated_to_target"] =
        candidate_truncated_to_target
    metadata["incremental_global_prefix_candidate_boundary_points"] = prefix_nfe + 1
    metadata["incremental_global_prefix_candidate_boundary_delta_before_overlay"] =
        prefix_boundary_delta
    metadata["incremental_global_prefix_candidate_join_boundary_delta_before_overlay"] =
        join_boundary_delta
    metadata["incremental_global_prefix_candidate_join_boundary_delta_after_repair"] =
        join_boundary_delta_after_repair
    metadata["incremental_global_prefix_tail_join_mismatch_available"] = tail_exists
    metadata["incremental_global_prefix_tail_join_mismatch_max_abs_before_repair"] =
        tail_join_shift_max_abs
    metadata["incremental_global_prefix_tail_join_mismatch_rel_rmse_before_repair"] =
        tail_join_shift_rel_rmse
    metadata["incremental_global_prefix_tail_join_mismatch_dominant_state"] =
        dominant_tail_join_state
    metadata["incremental_global_prefix_tail_join_mismatch_dominant_state_abs"] =
        dominant_tail_join_abs
    metadata["incremental_global_tail_state_shift_repair_applied"] =
        tail_shift_repair_applied
    metadata["incremental_global_tail_state_shift_repair_policy"] =
        tail_reference_reanchor_applied ?
        "reanchored_tail_reference_from_prefix_final_state" :
        tail_shift_repair_applied ?
        "constant_state_offset_tail_from_prefix_final_state" :
        "not_applied"
    metadata["incremental_global_tail_state_shift_repair_max_abs_shift"] =
        tail_join_shift_max_abs
    metadata["incremental_global_tail_state_shift_repair_rel_rmse_shift"] =
        tail_join_shift_rel_rmse
    metadata["incremental_global_tail_state_shift_repair_tail_element_count"] =
        tail_exists ? total_nfe - prefix_nfe : 0
    metadata["incremental_global_tail_reference_reanchor_applied"] =
        tail_reference_reanchor_applied
    metadata["incremental_global_tail_reference_reanchor_source"] =
        tail_reference_reanchor_applied ? String(tail_reference_label) : "not_applied"
    metadata["incremental_global_tail_reference_reanchor_first_element"] =
        tail_reference_reanchor_applied ? prefix_nfe + 1 : missing
    metadata["incremental_global_tail_reference_reanchor_last_element"] =
        tail_reference_reanchor_applied ? total_nfe : missing
    metadata["incremental_global_tail_reference_reanchor_element_count"] =
        tail_reference_reanchor_applied ? total_nfe - prefix_nfe : 0
    metadata["incremental_global_tail_reference_reanchor_preserves_tail_shape"] =
        tail_reference_reanchor_applied
    metadata["incremental_global_tail_flux_dual_extension_applied"] =
        tail_flux_dual_extension_applied
    metadata["incremental_global_tail_flux_dual_extension_policy"] =
        tail_flux_dual_extension_applied ?
        "repeat_last_prefix_candidate_flux_bound_duals_and_mass_balance_duals" :
        "not_applied"
    metadata["incremental_global_tail_flux_dual_extension_source_element"] =
        tail_flux_dual_extension_applied ? prefix_nfe : missing
    metadata["incremental_global_tail_flux_dual_extension_first_element"] =
        tail_flux_dual_extension_applied ? prefix_nfe + 1 : missing
    metadata["incremental_global_tail_flux_dual_extension_last_element"] =
        tail_flux_dual_extension_applied ? total_nfe : missing
    metadata["incremental_global_prefix_candidate_solver_status"] =
        get(candidate.metadata, "candidate_solver_status", missing)
    metadata["incremental_global_prefix_candidate_primal_status"] =
        get(candidate.metadata, "candidate_primal_status", missing)
    metadata["incremental_global_prefix_candidate_residual_feasible"] =
        get(candidate.metadata, "candidate_residual_feasible", missing)
    metadata["incremental_global_prefix_candidate_trajectory_ready"] =
        get(candidate.metadata, "candidate_trajectory_extraction_ready", missing)
    metadata["incremental_global_prefix_preserves_tail_windowed_start"] =
        tail_exists && !tail_shift_repair_applied

    return ReducedDCDFBAMPCCWindowedStartValues(
        state_boundary,
        state_collocation,
        state_derivative,
        flux,
        lower_bound_duals,
        upper_bound_duals,
        mass_balance_duals,
        metadata,
    )
end

function _reduced_mpcc_global_polish_target_nfe(
    target_horizon::Real,
    window_hours::Real,
    nfe_per_window::Int,
)::Int
    target = Float64(target_horizon)
    window = Float64(window_hours)
    raw_windows = target / window
    n_windows = round(Int, raw_windows)
    isapprox(raw_windows, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || throw(
        ArgumentError("Artifact global polish target_horizon must be an integer multiple of window_hours."),
    )
    nfe_per_window > 0 || throw(ArgumentError("nfe_per_window must be positive."))
    return n_windows * nfe_per_window
end

function _reduced_mpcc_global_polish_artifact_simulations(
    aligned::DataFrame;
    target_horizon::Real,
    extension_policy::AbstractString = "error",
)
    "time" in names(aligned) || throw(
        ArgumentError("Artifact aligned_timeseries.csv must contain a time column."),
    )
    policy = _reduced_mpcc_global_polish_artifact_extension_policy(extension_policy)
    times = Float64.(aligned[!, "time"])
    isempty(times) && throw(ArgumentError("Artifact aligned_timeseries.csv is empty."))
    initial_time = first(times)
    final_time = initial_time + Float64(target_horizon)
    tolerance = 100.0 * eps(Float64) * max(1.0, abs(initial_time), abs(final_time))
    source_final_time = last(times)
    extension_applied = final_time > source_final_time + tolerance
    prepared_aligned = extension_applied ?
        _reduced_mpcc_global_polish_extend_artifact_aligned(
            aligned,
            final_time;
            policy = policy,
        ) :
        aligned
    times = Float64.(prepared_aligned[!, "time"])
    row_indices = findall(t -> t <= final_time + tolerance, times)
    isempty(row_indices) && throw(ArgumentError("Artifact prefix contains no rows."))
    last_time = times[last(row_indices)]
    isapprox(last_time, final_time; atol = 1.0e-8, rtol = 1.0e-10) || throw(
        ArgumentError(
            "Artifact aligned_timeseries.csv does not contain the requested final time $final_time. " *
            "Last prefix time is $last_time.",
        ),
    )
    prefix = prepared_aligned[row_indices, :]
    prefix_times = Float64.(prefix[!, "time"])
    sequential_states = _reduced_mpcc_global_polish_artifact_state_matrix(prefix, "sequential")
    mpcc_states = _reduced_mpcc_global_polish_artifact_state_matrix(prefix, "mpcc_candidate")
    state_names = copy(DEFAULT_SIMULATION_STATE_NAMES)
    extension_tail_hours = max(0.0, final_time - source_final_time)
    extension_row_count = extension_applied ? nrow(prepared_aligned) - nrow(aligned) : 0
    extension_metadata = Dict{String, Any}(
        "artifact_extension_policy" => policy,
        "artifact_extension_applied" => extension_applied,
        "artifact_extension_source_final_time" => source_final_time,
        "artifact_extension_target_final_time" => final_time,
        "artifact_extension_tail_hours" => extension_tail_hours,
        "artifact_extension_row_count" => extension_row_count,
        "artifact_extension_reference_is_scientific" => false,
        "artifact_extension_reference_note" =>
            extension_applied ?
            "post-artifact tail is initialization-only and must be judged by residuals and plots" :
            "not_applied",
    )
    sequential_reference = SimulationResult(
        prefix_times,
        sequential_states;
        metadata = merge(
            Dict{String, Any}(
            "state_names" => state_names,
            "model_scope" => "reduced",
                "reference_source" =>
                    extension_applied ?
                    "artifact_aligned_timeseries_sequential_with_$(policy)_extension" :
                    "artifact_aligned_timeseries_sequential",
            "is_scientific_simulation" => false,
            ),
            extension_metadata,
        ),
    )
    state_seed = SimulationResult(
        prefix_times,
        mpcc_states;
        metadata = merge(
            Dict{String, Any}(
            "state_names" => state_names,
            "model_scope" => "reduced",
                "reference_source" =>
                    extension_applied ?
                    "artifact_aligned_timeseries_mpcc_candidate_with_$(policy)_extension" :
                    "artifact_aligned_timeseries_mpcc_candidate",
            "is_scientific_simulation" => false,
            ),
            extension_metadata,
        ),
    )
    return sequential_reference, state_seed, prefix
end

function _reduced_mpcc_global_polish_artifact_extension_policy(
    policy::AbstractString,
)::String
    normalized = lowercase(strip(String(policy)))
    normalized in ("", "strict") && return "error"
    normalized in ("error", "hold_terminal", "linear_terminal_slope") ||
        throw(
            ArgumentError(
                "MPCC artifact extension policy must be error, hold_terminal, or " *
                "linear_terminal_slope. Got: $(policy).",
            ),
        )
    return normalized
end

function _reduced_mpcc_global_polish_extend_artifact_aligned(
    aligned::DataFrame,
    final_time::Real;
    policy::AbstractString,
)::DataFrame
    extension_policy = _reduced_mpcc_global_polish_artifact_extension_policy(policy)
    extension_policy == "error" && throw(
        ArgumentError(
            "Artifact aligned_timeseries.csv does not reach requested final time " *
            "$(Float64(final_time)). Set MPCC_GLOBAL_POLISH_ARTIFACT_EXTENSION_POLICY " *
            "to hold_terminal or linear_terminal_slope for exploratory horizon extension.",
        ),
    )
    times = Float64.(aligned[!, "time"])
    length(times) >= 1 ||
        throw(ArgumentError("Artifact aligned_timeseries.csv is empty."))
    length(times) >= 2 || extension_policy == "hold_terminal" ||
        throw(
            ArgumentError(
                "linear_terminal_slope artifact extension requires at least two time rows.",
            ),
        )
    source_final_time = last(times)
    target_final_time = Float64(final_time)
    target_final_time > source_final_time ||
        return copy(aligned)
    dt = length(times) >= 2 ? source_final_time - times[end - 1] : target_final_time - source_final_time
    dt > 0.0 ||
        throw(ArgumentError("Artifact aligned_timeseries.csv must have increasing terminal times."))
    tolerance = 100.0 * eps(Float64) * max(1.0, abs(source_final_time), abs(target_final_time))
    extended = copy(aligned)
    new_time = source_final_time + dt
    while new_time <= target_final_time + tolerance
        row_values = Dict{String, Float64}("time" => min(new_time, target_final_time))
        for column in names(aligned)
            column == "time" && continue
            if endswith(column, "_difference_mpcc_minus_sequential")
                state_name = first(split(column, "_difference_mpcc_minus_sequential"; limit = 2))
                sequential_column = "$(state_name)_sequential"
                mpcc_column = "$(state_name)_mpcc_candidate"
                if haskey(row_values, sequential_column) && haskey(row_values, mpcc_column)
                    row_values[column] = row_values[mpcc_column] - row_values[sequential_column]
                else
                    row_values[column] = _reduced_mpcc_global_polish_extend_artifact_value(
                        aligned,
                        column,
                        row_values["time"],
                        source_final_time,
                        extension_policy,
                    )
                end
            else
                row_values[column] = _reduced_mpcc_global_polish_extend_artifact_value(
                    aligned,
                    column,
                    row_values["time"],
                    source_final_time,
                    extension_policy,
                )
            end
        end
        push!(extended, [row_values[column] for column in names(aligned)])
        new_time += dt
    end
    return extended
end

function _reduced_mpcc_global_polish_extend_artifact_value(
    aligned::DataFrame,
    column::AbstractString,
    time_value::Real,
    source_final_time::Real,
    policy::AbstractString,
)::Float64
    last_value = Float64(aligned[end, column])
    value = if policy == "linear_terminal_slope" && nrow(aligned) >= 2
        previous_time = Float64(aligned[end - 1, "time"])
        previous_value = Float64(aligned[end - 1, column])
        slope = (last_value - previous_value) / (Float64(source_final_time) - previous_time)
        last_value + slope * (Float64(time_value) - Float64(source_final_time))
    else
        last_value
    end
    return _reduced_mpcc_global_polish_artifact_extension_nonnegative_column(column) ?
           max(value, 0.0) :
           value
end

function _reduced_mpcc_global_polish_artifact_extension_nonnegative_column(
    column::AbstractString,
)::Bool
    suffixes = ("_sequential", "_mpcc_candidate")
    for suffix in suffixes
        endswith(column, suffix) || continue
        state_name = first(split(column, suffix; limit = 2))
        return state_name in DEFAULT_SIMULATION_STATE_NAMES || state_name == "total_sugar"
    end
    return false
end

function _reduced_mpcc_global_polish_artifact_state_matrix(
    table::DataFrame,
    suffix::AbstractString,
)::Matrix{Float64}
    states = Matrix{Float64}(undef, length(DEFAULT_SIMULATION_STATE_NAMES), nrow(table))
    for (state_index, state_name) in enumerate(DEFAULT_SIMULATION_STATE_NAMES)
        column = "$(state_name)_$(suffix)"
        column in names(table) || throw(
            ArgumentError("Artifact aligned_timeseries.csv is missing required column: $column"),
        )
        states[state_index, :] .= Float64.(table[!, column])
    end
    return states
end

function _reduced_mpcc_global_polish_artifact_window_prefix(
    table::DataFrame,
    final_time::Real,
)::DataFrame
    nrow(table) == 0 && return table
    "tfinal" in names(table) || return table
    tolerance = 100.0 * eps(Float64) * max(1.0, abs(Float64(final_time)))
    return table[Float64.(table[!, "tfinal"]) .<= Float64(final_time) + tolerance, :]
end

function _reduced_mpcc_global_polish_state_seed_start_values(
    model::MetabolicModel,
    seed::SimulationResult;
    target_nfe::Int,
    degree::Int,
    window_hours::Real,
    nfe_per_window::Int,
    require_complete::Bool,
    artifact_dir::AbstractString,
)::ReducedDCDFBAMPCCWindowedStartValues
    grid = build_collocation_grid(
        (first(seed.time), last(seed.time));
        nfe = target_nfe,
        degree = degree,
    )
    n_states = size(seed.states, 1)
    n_reactions = length(model.rxn_ids)
    n_metabolites = length(model.met_ids)
    state_boundary = Matrix{Float64}(undef, n_states, target_nfe + 1)
    for e in 1:target_nfe
        left, right = element_bounds(grid, e)
        e == 1 && (state_boundary[:, 1] .= _reduced_dcdfba_interpolated_state(seed, left))
        state_boundary[:, e + 1] .= _reduced_dcdfba_interpolated_state(seed, right)
    end
    state_collocation = Array{Float64, 3}(undef, n_states, target_nfe, degree)
    state_derivative = Array{Float64, 3}(undef, n_states, target_nfe, degree)
    for e in 1:target_nfe, j in 1:degree
        time_value = collocation_time(grid, e, j)
        state_collocation[:, e, j] .= _reduced_dcdfba_interpolated_state(seed, time_value)
        state_derivative[:, e, j] .= _reduced_dcdfba_piecewise_state_slope(seed, time_value)
    end
    flux = Array{Float64, 3}(undef, n_reactions, target_nfe, degree)
    for r in 1:n_reactions, e in 1:target_nfe, j in 1:degree
        flux[r, e, j] = clamp(0.0, model.lb[r], model.ub[r])
    end
    lower_bound_duals = zeros(Float64, n_reactions, target_nfe, degree)
    upper_bound_duals = zeros(Float64, n_reactions, target_nfe, degree)
    mass_balance_duals = zeros(Float64, n_metabolites, target_nfe, degree)
    boundary_times = Float64[grid.tspan[1]]
    for e in 1:target_nfe
        push!(boundary_times, Float64(element_bounds(grid, e)[2]))
    end
    collocation_times = Float64[
        Float64(collocation_time(grid, e, j)) for e in 1:target_nfe for j in 1:degree
    ]
    n_windows = round(Int, (last(seed.time) - first(seed.time)) / Float64(window_hours))
    local_nfe_values = fill(nfe_per_window, n_windows)
    metadata = Dict{String, Any}(
        "start_type" => "reduced_dcdfba_mpcc_windowed_artifact_state_timeseries_start_values",
        "source_window_count" => n_windows,
        "source_completed_required" => require_complete,
        "source_continuation_completed" => true,
        "source_total_nfe" => target_nfe,
        "source_local_nfe_values" => local_nfe_values,
        "source_collocation_degree" => degree,
        "source_n_states" => n_states,
        "source_n_reactions" => n_reactions,
        "source_n_metabolites" => n_metabolites,
        "source_boundary_times" => boundary_times,
        "source_collocation_times" => collocation_times,
        "source_initial_time" => first(boundary_times),
        "source_final_time" => last(boundary_times),
        "source_horizon" => last(boundary_times) - first(boundary_times),
        "source_boundary_point_count" => length(boundary_times),
        "source_collocation_point_count" => length(collocation_times),
        "source_max_boundary_join_mismatch" => 0.0,
        "all_source_candidates_residual_feasible" => missing,
        "all_source_candidates_trajectory_ready" => missing,
        "artifact_dir" => normpath(String(artifact_dir)),
        "artifact_start_source" => "aligned_timeseries_mpcc_candidate_states",
        "outputs_written" => false,
        "start_values_are_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
    return ReducedDCDFBAMPCCWindowedStartValues(
        state_boundary,
        state_collocation,
        state_derivative,
        flux,
        lower_bound_duals,
        upper_bound_duals,
        mass_balance_duals,
        metadata,
    )
end

function _reduced_mpcc_global_polish_slice_starts(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    target_horizon::Real,
)::ReducedDCDFBAMPCCWindowedStartValues
    boundary_times = Float64.(starts.metadata["source_boundary_times"])
    initial_time = first(boundary_times)
    target_final_time = initial_time + Float64(target_horizon)
    target_boundary_index = findfirst(
        t -> isapprox(t, target_final_time; atol = 1.0e-8, rtol = 1.0e-10),
        boundary_times,
    )
    target_boundary_index === nothing && throw(
        ArgumentError("Dense start artifact does not contain requested final time $target_final_time."),
    )
    target_nfe = target_boundary_index - 1
    target_nfe == Int(starts.metadata["source_total_nfe"]) && return starts
    degree = Int(starts.metadata["source_collocation_degree"])
    metadata = copy(starts.metadata)
    metadata["source_total_nfe"] = target_nfe
    metadata["source_boundary_times"] = boundary_times[1:(target_nfe + 1)]
    metadata["source_collocation_times"] =
        Float64.(starts.metadata["source_collocation_times"])[1:(target_nfe * degree)]
    metadata["source_final_time"] = target_final_time
    metadata["source_horizon"] = Float64(target_horizon)
    metadata["source_boundary_point_count"] = target_nfe + 1
    metadata["source_collocation_point_count"] = target_nfe * degree
    metadata["source_local_nfe_values"] =
        _reduced_mpcc_global_polish_prefix_local_nfe_values(
            Int.(starts.metadata["source_local_nfe_values"]),
            target_nfe,
        )
    metadata["source_window_count"] = length(metadata["source_local_nfe_values"])
    metadata["artifact_dense_start_sliced"] = true
    return ReducedDCDFBAMPCCWindowedStartValues(
        starts.state_boundary[:, 1:(target_nfe + 1)],
        starts.state_collocation[:, 1:target_nfe, :],
        starts.state_derivative[:, 1:target_nfe, :],
        starts.flux[:, 1:target_nfe, :],
        starts.lower_bound_duals[:, 1:target_nfe, :],
        starts.upper_bound_duals[:, 1:target_nfe, :],
        starts.mass_balance_duals[:, 1:target_nfe, :],
        metadata,
    )
end

function _reduced_mpcc_global_polish_prefix_local_nfe_values(
    local_nfe_values::Vector{Int},
    target_nfe::Int,
)::Vector{Int}
    remaining = target_nfe
    output = Int[]
    for value in local_nfe_values
        remaining <= 0 && break
        keep = min(value, remaining)
        push!(output, keep)
        remaining -= keep
    end
    remaining == 0 || throw(
        ArgumentError("Dense start artifact local nfe values do not cover requested prefix."),
    )
    return output
end

function _reduced_mpcc_global_polish_candidate_nfe(
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
)::Int
    return size(comparison.trajectory_candidate.candidate_diagnostics.state_collocation, 2)
end

function _reduced_mpcc_global_polish_candidate_collocation_times(
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
)::Vector{Float64}
    metadata = comparison.trajectory_candidate.candidate_diagnostics.metadata
    values = get(metadata, "candidate_collocation_times", comparison.trajectory_candidate.collocation_result.time)
    return Float64.(collect(values))
end

function _reduced_mpcc_global_polish_validate_candidate_shapes!(
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
    window_index::Int,
    n_states::Int,
    n_reactions::Int,
    n_metabolites::Int,
    degree::Int,
    local_nfe::Int,
)
    local_nfe > 0 || throw(
        ArgumentError("Reduced MPCC global polish window $window_index has nonpositive nfe."),
    )
    size(candidate.state_boundary) == (n_states, local_nfe + 1) || throw(
        ArgumentError("Reduced MPCC global polish window $window_index has incompatible state_boundary shape."),
    )
    size(candidate.state_collocation) == (n_states, local_nfe, degree) || throw(
        ArgumentError("Reduced MPCC global polish window $window_index has incompatible state_collocation shape."),
    )
    size(candidate.state_derivative) == (n_states, local_nfe, degree) || throw(
        ArgumentError("Reduced MPCC global polish window $window_index has incompatible state_derivative shape."),
    )
    size(candidate.flux) == (n_reactions, local_nfe, degree) || throw(
        ArgumentError("Reduced MPCC global polish window $window_index has incompatible flux shape."),
    )
    size(candidate.lower_bound_duals) == (n_reactions, local_nfe, degree) || throw(
        ArgumentError("Reduced MPCC global polish window $window_index has incompatible lower dual shape."),
    )
    size(candidate.upper_bound_duals) == (n_reactions, local_nfe, degree) || throw(
        ArgumentError("Reduced MPCC global polish window $window_index has incompatible upper dual shape."),
    )
    size(candidate.mass_balance_duals) == (n_metabolites, local_nfe, degree) || throw(
        ArgumentError("Reduced MPCC global polish window $window_index has incompatible mass dual shape."),
    )
    length(comparison.trajectory_candidate.boundary_result.time) == local_nfe + 1 || throw(
        ArgumentError("Reduced MPCC global polish window $window_index boundary times do not match nfe."),
    )
    length(_reduced_mpcc_global_polish_candidate_collocation_times(comparison)) ==
        local_nfe * degree || throw(
        ArgumentError("Reduced MPCC global polish window $window_index collocation times do not match nfe*degree."),
    )
    return nothing
end

function _reduced_mpcc_global_polish_validate_finite_arrays(arrays...)
    for array in arrays
        all(isfinite, array) || throw(
            ArgumentError("Reduced MPCC global polish source start arrays must be finite."),
        )
    end
    return nothing
end

function _reduced_mpcc_global_polish_start_metadata(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    comparisons::Vector{ReducedDCDFBAMPCCSequentialComparisonResult},
    local_nfe_values::Vector{Int},
    boundary_times::Vector{Float64},
    collocation_times::Vector{Float64},
    max_boundary_join_mismatch::Float64,
    n_states::Int,
    n_reactions::Int,
    n_metabolites::Int,
    degree::Int,
    total_nfe::Int,
    require_complete::Bool,
)::Dict{String, Any}
    return Dict{String, Any}(
        "start_type" => "reduced_dcdfba_mpcc_windowed_candidate_start_values",
        "source_window_count" => length(comparisons),
        "source_completed_required" => require_complete,
        "source_continuation_completed" =>
            get(continuation.metadata, "continuation_completed", missing),
        "source_total_nfe" => total_nfe,
        "source_local_nfe_values" => copy(local_nfe_values),
        "source_collocation_degree" => degree,
        "source_n_states" => n_states,
        "source_n_reactions" => n_reactions,
        "source_n_metabolites" => n_metabolites,
        "source_boundary_times" => copy(boundary_times),
        "source_collocation_times" => copy(collocation_times),
        "source_initial_time" => first(boundary_times),
        "source_final_time" => last(boundary_times),
        "source_horizon" => last(boundary_times) - first(boundary_times),
        "source_boundary_point_count" => length(boundary_times),
        "source_collocation_point_count" => length(collocation_times),
        "source_max_boundary_join_mismatch" => max_boundary_join_mismatch,
        "all_source_candidates_residual_feasible" => all(
            comparison -> get(
                comparison.trajectory_candidate.candidate_diagnostics.metadata,
                "candidate_residual_feasible",
                false,
            ) === true,
            comparisons,
        ),
        "all_source_candidates_trajectory_ready" => all(
            comparison -> get(
                comparison.trajectory_candidate.metadata,
                "trajectory_candidate_ready",
                get(
                    comparison.trajectory_candidate.candidate_diagnostics.metadata,
                    "candidate_trajectory_extraction_ready",
                    false,
                ),
            ) === true,
            comparisons,
        ),
        "outputs_written" => false,
        "start_values_are_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
end

function _reduced_mpcc_global_polish_validate_target_shapes(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
)
    nlp = problem.smoke_problem.nlp
    size(starts.state_boundary) == size(nlp.state_boundary) || throw(
        ArgumentError("Reduced MPCC global polish state_boundary starts do not match target problem shape."),
    )
    size(starts.state_collocation) == size(nlp.state_collocation) || throw(
        ArgumentError("Reduced MPCC global polish state_collocation starts do not match target problem shape."),
    )
    size(starts.state_derivative) == size(nlp.state_derivative) || throw(
        ArgumentError("Reduced MPCC global polish state_derivative starts do not match target problem shape."),
    )
    size(starts.flux) == size(nlp.flux) || throw(
        ArgumentError("Reduced MPCC global polish flux starts do not match target problem shape."),
    )
    size(starts.lower_bound_duals) ==
        size(problem.smoke_problem.bound_feasibility.lower_bound_duals) || throw(
        ArgumentError("Reduced MPCC global polish lower-bound dual starts do not match target problem shape."),
    )
    size(starts.upper_bound_duals) ==
        size(problem.smoke_problem.bound_feasibility.upper_bound_duals) || throw(
        ArgumentError("Reduced MPCC global polish upper-bound dual starts do not match target problem shape."),
    )
    size(starts.mass_balance_duals) ==
        size(problem.smoke_problem.stationarity.mass_balance_duals) || throw(
        ArgumentError("Reduced MPCC global polish mass-balance dual starts do not match target problem shape."),
    )
    return nothing
end

function _reduced_mpcc_global_polish_set_starts!(variables, values)
    size(variables) == size(values) || throw(
        ArgumentError("Reduced MPCC global polish cannot apply start values with mismatched shapes."),
    )
    for index in eachindex(values)
        JuMP.set_start_value(variables[index], Float64(values[index]))
    end
    return nothing
end

function _reduced_mpcc_global_polish_start_summary_table(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
)::DataFrame
    nlp = problem.smoke_problem.nlp
    rows = [
        _reduced_mpcc_global_polish_start_row(
            "state_boundary",
            starts.state_boundary,
            nlp.state_boundary,
        ),
        _reduced_mpcc_global_polish_start_row(
            "state_collocation",
            starts.state_collocation,
            nlp.state_collocation,
        ),
        _reduced_mpcc_global_polish_start_row(
            "state_derivative",
            starts.state_derivative,
            nlp.state_derivative,
        ),
        _reduced_mpcc_global_polish_start_row("flux", starts.flux, nlp.flux),
        _reduced_mpcc_global_polish_start_row(
            "lower_bound_duals",
            starts.lower_bound_duals,
            problem.smoke_problem.bound_feasibility.lower_bound_duals,
        ),
        _reduced_mpcc_global_polish_start_row(
            "upper_bound_duals",
            starts.upper_bound_duals,
            problem.smoke_problem.bound_feasibility.upper_bound_duals,
        ),
        _reduced_mpcc_global_polish_start_row(
            "mass_balance_duals",
            starts.mass_balance_duals,
            problem.smoke_problem.stationarity.mass_balance_duals,
        ),
    ]
    return DataFrame(
        (
            column => [
                _reduced_mpcc_global_polish_table_scalar(get(row, column, missing)) for
                row in rows
            ] for column in REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_START_COLUMNS
        )...,
    )
end

function _reduced_mpcc_global_polish_start_row(
    block::AbstractString,
    source_values,
    target_variables,
)::Dict{String, Any}
    finite_count = count(isfinite, source_values)
    total_count = length(source_values)
    return Dict{String, Any}(
        "block" => String(block),
        "source_size" => string(size(source_values)),
        "target_size" => string(size(target_variables)),
        "applied" => size(source_values) == size(target_variables),
        "finite_value_count" => finite_count,
        "total_value_count" => total_count,
        "max_abs_start" => total_count == 0 ? missing : maximum(abs.(source_values)),
    )
end

function _reduced_mpcc_global_polish_sequential_reference(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
)::SimulationResult
    reference = continuation.sequential_reference
    reference === nothing && throw(
        ArgumentError("Reduced MPCC global polish requires a sequential reference for global initialization."),
    )
    first(reference.time) == starts.metadata["source_initial_time"] || throw(
        ArgumentError("Reduced MPCC global polish sequential reference initial time does not match source starts."),
    )
    last(reference.time) == starts.metadata["source_final_time"] || throw(
        ArgumentError("Reduced MPCC global polish sequential reference final time does not match source starts."),
    )
    return reference
end

function _reduced_mpcc_global_polish_metadata(
    continuation::ReducedDCDFBAMPCCWindowedContinuationResult,
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    solve_attempt::ReducedDCDFBAMPCCSolveAttemptResult,
    trajectory_candidate,
    comparison_result,
    start_summary_table::DataFrame,
    require_complete::Bool,
)::Dict{String, Any}
    candidate_metadata =
        solve_attempt.candidate_diagnostics === nothing ?
        Dict{String, Any}() :
        solve_attempt.candidate_diagnostics.metadata
    comparison_metadata =
        comparison_result === nothing ? Dict{String, Any}() : comparison_result.metadata
    residual_feasible = get(candidate_metadata, "candidate_residual_feasible", false) === true
    trajectory_ready =
        get(candidate_metadata, "candidate_trajectory_extraction_ready", false) === true
    iteration_limit_residual_feasible =
        get(candidate_metadata, "candidate_iteration_limit_residual_feasible", false) === true
    metadata = Dict{String, Any}(
        "global_polish_type" => REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_TYPE,
        "global_polish_source_kind" => "windowed_continuation",
        "global_polish_start_source" => "windowed_candidate",
        "global_polish_source_complete_required" => require_complete,
        "global_polish_source_continuation_completed" =>
            get(continuation.metadata, "continuation_completed", missing),
        "source_window_count" => starts.metadata["source_window_count"],
        "global_nfe" => starts.metadata["source_total_nfe"],
        "global_degree" => starts.metadata["source_collocation_degree"],
        "global_horizon" => starts.metadata["source_horizon"],
        "global_tspan" =>
            (starts.metadata["source_initial_time"], starts.metadata["source_final_time"]),
        "source_max_boundary_join_mismatch" =>
            starts.metadata["source_max_boundary_join_mismatch"],
        "start_summary_rows" => nrow(start_summary_table),
        "pre_solve_guard_required" =>
            get(solve_attempt.metadata, "pre_solve_guard_required", missing),
        "pre_solve_guard_passed" =>
            get(solve_attempt.metadata, "pre_solve_guard_passed", missing),
        "pre_solve_blocked" =>
            get(solve_attempt.metadata, "guarded_solve_attempt_blocked", missing),
        "solver_status" => get(solve_attempt.metadata, "solver_status", missing),
        "primal_status" => get(solve_attempt.metadata, "primal_status", missing),
        "ipopt_profile" =>
            get(solve_attempt.metadata, "solve_attempt_ipopt_profile", missing),
        "ipopt_profile_env" =>
            get(solve_attempt.metadata, "solve_attempt_ipopt_profile_env", missing),
        "dynamic_flux_bound_mode" =>
            get(solve_attempt.metadata, "dynamic_flux_bound_mode", missing),
        "dynamic_flux_bound_policy" =>
            get(solve_attempt.metadata, "dynamic_flux_bound_policy", missing),
        "dynamic_phase_smoothing_width" =>
            get(solve_attempt.metadata, "dynamic_phase_smoothing_width", missing),
        "dynamic_phase_proxy_mode" =>
            get(solve_attempt.metadata, "dynamic_phase_proxy_mode", missing),
        "dynamic_phase_proxy_definition" =>
            get(solve_attempt.metadata, "dynamic_phase_proxy_definition", missing),
        "dynamic_turnover_threshold" =>
            get(solve_attempt.metadata, "dynamic_turnover_threshold", missing),
        "smooth_turnover_mode_embedded" =>
            get(solve_attempt.metadata, "smooth_turnover_mode_embedded", missing),
        "turnover_mode_deferred" =>
            get(solve_attempt.metadata, "turnover_mode_deferred", missing),
        "almost_locally_solved_accepted" =>
            get(solve_attempt.metadata, "post_solve_almost_locally_solved_accepted", missing),
        "acceptable_solver_status" =>
            get(solve_attempt.metadata, "post_solve_acceptable_solver_status", missing),
        "solve_elapsed_seconds" =>
            get(solve_attempt.metadata, "solve_elapsed_seconds", missing),
        "candidate_values_available" =>
            solve_attempt.candidate_diagnostics !== nothing,
        "candidate_residual_feasible" => residual_feasible,
        "candidate_trajectory_ready" => trajectory_ready,
        "candidate_iteration_limit_residual_feasible" =>
            iteration_limit_residual_feasible,
        "candidate_dominant_residual" =>
            get(candidate_metadata, "candidate_dominant_residual", missing),
        "max_rhs_residual" =>
            get(solve_attempt.residual_report, "max_rhs_residual", missing),
        "max_collocation_integration_residual" =>
            get(
                solve_attempt.residual_report,
                "max_collocation_integration_residual",
                missing,
            ),
        "max_continuity_residual" =>
            get(solve_attempt.residual_report, "max_continuity_residual", missing),
        "max_initial_condition_residual" =>
            get(
                solve_attempt.residual_report,
                "max_initial_condition_residual",
                missing,
            ),
        "max_mass_balance_residual" =>
            get(solve_attempt.residual_report, "max_mass_balance_residual", missing),
        "max_lower_bound_violation" =>
            get(solve_attempt.residual_report, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" =>
            get(solve_attempt.residual_report, "max_upper_bound_violation", missing),
        "max_stationarity_residual" =>
            get(solve_attempt.residual_report, "max_stationarity_residual", missing),
        "max_lower_complementarity_residual" =>
            get(solve_attempt.residual_report, "max_lower_complementarity_residual", missing),
        "max_upper_complementarity_residual" =>
            get(solve_attempt.residual_report, "max_upper_complementarity_residual", missing),
        "trajectory_candidate_available" => trajectory_candidate !== nothing,
        "comparison_available" => comparison_result !== nothing,
        "max_state_relative_rmse" =>
            get(comparison_metadata, "max_state_relative_rmse", missing),
        "max_state_abs_difference" =>
            get(comparison_metadata, "max_state_abs_difference", missing),
        "final_biomass_difference" =>
            comparison_result === nothing ? missing :
            _reduced_mpcc_sweep_final_difference(comparison_result, "biomass"),
        "final_total_sugar_difference" =>
            comparison_result === nothing ? missing :
            _reduced_mpcc_sweep_final_difference(comparison_result, "total_sugar"),
        "recommended_next_action" =>
            _reduced_mpcc_global_polish_recommended_action(
                residual_feasible,
                trajectory_ready,
                iteration_limit_residual_feasible,
                get(solve_attempt.metadata, "guarded_solve_attempt_blocked", false) === true;
                dominant_residual = get(
                    candidate_metadata,
                    "candidate_dominant_residual",
                    missing,
                ),
            ),
        "outputs_written" => false,
        "global_polish_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC global polish re-solves a windowed/cascade candidate as one simultaneous MPCC; diagnostic only and not a validated scientific simulation.",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "nlp_structure_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(metadata, solve_attempt.metadata, "base_flux_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, solve_attempt.metadata, "fixed_flux_")
    _merge_reduced_dcdfba_metadata_prefix!(metadata, solve_attempt.metadata, "flux_variable_")
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "global_polish_objective_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "global_polish_trust_region_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "global_polish_trace_trust_region_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "global_polish_terminal_trust_region_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "global_polish_flux_dual_refresh_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "global_polish_dense_start_kkt_refresh_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "solve_attempt_ipopt_warm_start_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "global_polish_collocation_repair_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "global_polish_pre_solve_start_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "collocation_consistent_state_start_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "selective_fixed_flux_stationarity_dual_fit_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "bound_dual_complementarity_clip_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        solve_attempt.metadata,
        "post_solve_flux_bound_projection_repair_",
    )
    _merge_reduced_dcdfba_metadata_prefix!(
        metadata,
        starts.metadata,
        "incremental_global_",
    )
    return metadata
end

function _reduced_mpcc_global_polish_start_candidate_diagnostics(
    starts::ReducedDCDFBAMPCCWindowedStartValues,
    pre_solve_report::ReducedDCDFBAMPCCDiagnosticReport;
    value_source::AbstractString = "pre_solve_start_values",
)::ReducedDCDFBAMPCCCandidateDiagnostics
    residual_values = Dict{String, Float64}(
        String(key) => Float64(value) for (key, value) in pre_solve_report.residual_values
    )
    residual_thresholds = Dict{String, Float64}(
        String(key) => Float64(value) for (key, value) in pre_solve_report.residual_thresholds
    )
    residual_ratios = Dict{String, Float64}(
        String(key) => Float64(value) for (key, value) in pre_solve_report.residual_ratios
    )
    residual_feasible =
        pre_solve_report.residuals_available &&
        pre_solve_report.residual_thresholds_satisfied
    candidate_metadata = Dict{String, Any}(
        "candidate_extraction_performed" => true,
        "candidate_value_source" => String(value_source),
        "candidate_solver_status" => "START_VALUES",
        "candidate_primal_status" =>
            residual_feasible ? "FEASIBLE_POINT" : "NEARLY_FEASIBLE_POINT",
        "candidate_residuals_available" => pre_solve_report.residuals_available,
        "candidate_residual_thresholds_satisfied" =>
            pre_solve_report.residual_thresholds_satisfied,
        "candidate_residual_feasible" => residual_feasible,
        "candidate_iteration_limit_residual_feasible" => false,
        "candidate_dominant_residual" => pre_solve_report.dominant_residual,
        "candidate_trajectory_extraction_ready" => residual_feasible,
        "trajectory_candidate_ready" => residual_feasible,
        "candidate_values_available" => true,
        "candidate_grid_nfe" => Int(starts.metadata["source_total_nfe"]),
        "candidate_collocation_degree" =>
            Int(starts.metadata["source_collocation_degree"]),
        "candidate_boundary_times" => copy(starts.metadata["source_boundary_times"]),
        "candidate_collocation_times" =>
            copy(starts.metadata["source_collocation_times"]),
        "candidate_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
    )
    merge!(candidate_metadata, pre_solve_report.metadata)
    return ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(starts.state_boundary),
        copy(starts.state_collocation),
        copy(starts.state_derivative),
        copy(starts.flux),
        copy(starts.lower_bound_duals),
        copy(starts.upper_bound_duals),
        copy(starts.mass_balance_duals),
        residual_values,
        residual_thresholds,
        residual_ratios,
        copy(pre_solve_report.ranked_residuals),
        copy(pre_solve_report.warnings),
        candidate_metadata,
    )
end

function _reduced_mpcc_global_polish_post_solve_flux_bound_projection_repair_enabled()::Bool
    return _reduced_dcdfba_env_bool(
        REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_POST_SOLVE_FLUX_BOUND_PROJECTION_REPAIR_ENV,
        false,
    )
end

function _reduced_mpcc_global_polish_project_candidate_flux_bounds(
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    smoke_result::ReducedDCDFBAMPCCSmokeResult,
    candidate::Union{Nothing, ReducedDCDFBAMPCCCandidateDiagnostics},
)
    enabled = _reduced_mpcc_global_polish_post_solve_flux_bound_projection_repair_enabled()
    metadata = Dict{String, Any}(
        "post_solve_flux_bound_projection_repair_enabled" => enabled,
        "post_solve_flux_bound_projection_repair_env" =>
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_POST_SOLVE_FLUX_BOUND_PROJECTION_REPAIR_ENV,
        "post_solve_flux_bound_projection_repair_applied" => false,
        "post_solve_flux_bound_projection_repair_adjusted_count" => 0,
        "post_solve_flux_bound_projection_repair_max_adjustment" => 0.0,
    )
    candidate === nothing && return candidate, metadata
    enabled || return candidate, metadata

    smoke_problem = problem.smoke_problem
    nfe = smoke_problem.nlp.dimensions.nfe
    degree = smoke_problem.nlp.dimensions.collocation_degree
    model = smoke_problem.nlp.kkt_problem.model
    projected_flux = copy(candidate.flux)
    adjusted_count = 0
    max_adjustment = 0.0
    max_adjustment_reaction_index = 0
    max_adjustment_reaction_id = ""
    max_adjustment_element = 0
    max_adjustment_collocation = 0
    max_adjustment_old_flux = NaN
    max_adjustment_new_flux = NaN
    max_adjustment_lower_bound = NaN
    max_adjustment_upper_bound = NaN

    for e in 1:nfe, j in 1:degree
        bounds = _reduced_dcdfba_numeric_flux_bounds(
            smoke_problem,
            e,
            j,
            candidate.state_collocation,
        )
        for r in axes(projected_flux, 1)
            old_flux = Float64(projected_flux[r, e, j])
            new_flux = clamp(old_flux, bounds.lb[r], bounds.ub[r])
            adjustment = abs(new_flux - old_flux)
            adjustment > 0.0 || continue
            adjusted_count += 1
            projected_flux[r, e, j] = new_flux
            if adjustment > max_adjustment
                max_adjustment = adjustment
                max_adjustment_reaction_index = r
                max_adjustment_reaction_id = String(model.rxn_ids[r])
                max_adjustment_element = e
                max_adjustment_collocation = j
                max_adjustment_old_flux = old_flux
                max_adjustment_new_flux = new_flux
                max_adjustment_lower_bound = bounds.lb[r]
                max_adjustment_upper_bound = bounds.ub[r]
            end
        end
    end

    merge!(
        metadata,
        Dict{String, Any}(
            "post_solve_flux_bound_projection_repair_adjusted_count" =>
                adjusted_count,
            "post_solve_flux_bound_projection_repair_max_adjustment" =>
                max_adjustment,
            "post_solve_flux_bound_projection_repair_max_adjustment_reaction_index" =>
                max_adjustment_reaction_index == 0 ? missing :
                max_adjustment_reaction_index,
            "post_solve_flux_bound_projection_repair_max_adjustment_reaction_id" =>
                isempty(max_adjustment_reaction_id) ? missing :
                max_adjustment_reaction_id,
            "post_solve_flux_bound_projection_repair_max_adjustment_element" =>
                max_adjustment_element == 0 ? missing : max_adjustment_element,
            "post_solve_flux_bound_projection_repair_max_adjustment_collocation" =>
                max_adjustment_collocation == 0 ? missing :
                max_adjustment_collocation,
            "post_solve_flux_bound_projection_repair_max_adjustment_old_flux" =>
                max_adjustment_old_flux,
            "post_solve_flux_bound_projection_repair_max_adjustment_new_flux" =>
                max_adjustment_new_flux,
            "post_solve_flux_bound_projection_repair_max_adjustment_lower_bound" =>
                max_adjustment_lower_bound,
            "post_solve_flux_bound_projection_repair_max_adjustment_upper_bound" =>
                max_adjustment_upper_bound,
        ),
    )
    adjusted_count == 0 && begin
        merge!(candidate.metadata, metadata)
        return candidate, metadata
    end

    candidate_values = (
        state_boundary = candidate.state_boundary,
        state_collocation = candidate.state_collocation,
        state_derivative = candidate.state_derivative,
        flux = projected_flux,
        lower_bound_duals = candidate.lower_bound_duals,
        upper_bound_duals = candidate.upper_bound_duals,
        mass_balance_duals = candidate.mass_balance_duals,
    )
    repaired = _reduced_dcdfba_mpcc_candidate_diagnostics_from_values(
        smoke_problem,
        smoke_result,
        problem.residual_thresholds,
        candidate_values,
        "post_solve_values_flux_bound_projection_repair",
    )
    metadata["post_solve_flux_bound_projection_repair_applied"] = true
    metadata["post_solve_flux_bound_projection_repair_previous_max_lower_bound_violation"] =
        get(candidate.residual_values, "max_lower_bound_violation", missing)
    metadata["post_solve_flux_bound_projection_repair_previous_max_upper_bound_violation"] =
        get(candidate.residual_values, "max_upper_bound_violation", missing)
    metadata["post_solve_flux_bound_projection_repair_max_lower_bound_violation_after"] =
        get(repaired.residual_values, "max_lower_bound_violation", missing)
    metadata["post_solve_flux_bound_projection_repair_max_upper_bound_violation_after"] =
        get(repaired.residual_values, "max_upper_bound_violation", missing)
    metadata["post_solve_flux_bound_projection_repair_max_mass_balance_residual_after"] =
        get(repaired.residual_values, "max_mass_balance_residual", missing)
    metadata["post_solve_flux_bound_projection_repair_max_rhs_residual_after"] =
        get(repaired.residual_values, "max_rhs_residual", missing)
    metadata["post_solve_flux_bound_projection_repair_max_lower_complementarity_residual_after"] =
        get(repaired.residual_values, "max_lower_complementarity_residual", missing)
    metadata["post_solve_flux_bound_projection_repair_max_upper_complementarity_residual_after"] =
        get(repaired.residual_values, "max_upper_complementarity_residual", missing)
    merge!(repaired.metadata, metadata)
    return repaired, metadata
end

function _reduced_mpcc_global_polish_refresh_residual_report_from_candidate!(
    residual_report::Dict{String, Any},
    problem::ReducedDCDFBAMPCCSolveAttemptProblem,
    candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
)::Dict{String, Any}
    residual_values = copy(candidate.residual_values)
    threshold_values = copy(candidate.residual_thresholds)
    ratios = _reduced_dcdfba_mpcc_residual_ratios(residual_values, threshold_values)
    within = Dict{String, Bool}(
        key => isfinite(residual_values[key]) &&
               residual_values[key] <= threshold_values[key] for
        key in keys(residual_values)
    )
    ranked_residuals = _reduced_dcdfba_mpcc_ranked_residuals(ratios)
    residuals_available = all(value -> isfinite(value), values(residual_values))
    residual_thresholds_satisfied =
        residuals_available && all(values(within))

    residual_report["residuals_available"] = residuals_available
    residual_report["residual_thresholds_satisfied"] = residual_thresholds_satisfied
    residual_report["residual_threshold_report"] = within
    residual_report["residual_ratios"] = ratios
    residual_report["ranked_residuals"] = ranked_residuals
    residual_report["dominant_residual"] =
        isempty(ranked_residuals) ? "unavailable" : first(ranked_residuals)
    for key in keys(residual_values)
        residual_report[key] = residual_values[key]
        residual_report["$(key)_threshold"] = threshold_values[key]
        residual_report["$(key)_ratio"] = ratios[key]
        residual_report["$(key)_within_threshold"] = within[key]
    end
    tau_status = _reduced_dcdfba_mpcc_complementarity_tau_status(
        problem.smoke_problem,
        get(residual_values, "max_lower_complementarity_residual", NaN),
        get(residual_values, "max_upper_complementarity_residual", NaN),
    )
    for (key, value) in pairs(tau_status)
        residual_report[String(key)] = value
    end
    return residual_report
end

function _reduced_mpcc_global_polish_selection_score(
    residual_values::AbstractDict,
    residual_thresholds::AbstractDict = Dict{String, Any}(),
)::Float64
    score = 0.0
    any_value = false
    for key in REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_SELECTION_RESIDUAL_KEYS
        haskey(residual_values, key) || continue
        value = _reduced_mpcc_global_polish_numeric_or_nan(residual_values[key])
        isfinite(value) || continue
        threshold = _reduced_mpcc_global_polish_selection_threshold(
            key,
            residual_values,
            residual_thresholds,
        )
        isfinite(threshold) && threshold > 0.0 || continue
        score = max(score, abs(value) / threshold)
        any_value = true
    end
    return any_value ? score : Inf
end

function _reduced_mpcc_global_polish_selection_threshold(
    key::AbstractString,
    residual_values::AbstractDict,
    residual_thresholds::AbstractDict,
)::Float64
    threshold_key = "$(key)_threshold"
    if haskey(residual_values, threshold_key)
        return _reduced_mpcc_global_polish_numeric_or_nan(residual_values[threshold_key])
    elseif haskey(residual_thresholds, key)
        return _reduced_mpcc_global_polish_numeric_or_nan(residual_thresholds[key])
    end
    return NaN
end

function _reduced_mpcc_global_polish_numeric_or_nan(value)::Float64
    value === missing && return NaN
    try
        return Float64(value)
    catch
        return NaN
    end
end

function _reduced_mpcc_global_polish_metric_states(states::AbstractString)::Vector{String}
    requested = _reduced_mpcc_global_polish_trust_region_states(states)
    if isempty(requested)
        return String[]
    end
    return requested
end

function _reduced_mpcc_global_polish_metric_value(
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
    state_name::AbstractString,
    metric_name::AbstractString,
)::Float64
    table = comparison.state_metrics_table
    "state_name" in names(table) || return NaN
    metric_name in names(table) || return NaN
    index = findfirst(==(String(state_name)), String.(table[!, "state_name"]))
    index === nothing && return NaN
    return _reduced_mpcc_global_polish_numeric_or_nan(table[index, metric_name])
end

function _reduced_mpcc_global_polish_comparison_max_metric(
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
    states::Vector{String},
    metric_name::AbstractString,
)::Float64
    values = Float64[]
    for state_name in states
        value = _reduced_mpcc_global_polish_metric_value(
            comparison,
            state_name,
            metric_name,
        )
        isfinite(value) && push!(values, abs(value))
    end
    return isempty(values) ? Inf : maximum(values)
end

function _reduced_mpcc_global_polish_acceptance_not_worse(
    candidate_value::Real,
    start_value::Real,
    relative_tolerance::Real,
    absolute_tolerance::Real,
)::Bool
    candidate = Float64(candidate_value)
    start = Float64(start_value)
    rel_tol = Float64(relative_tolerance)
    abs_tol = Float64(absolute_tolerance)
    isfinite(candidate) || return false
    isfinite(start) || return false
    threshold = max(start * (1.0 + rel_tol), start + abs_tol)
    return candidate <= threshold
end

function _reduced_mpcc_global_polish_biological_acceptance(
    start_comparison::Union{Nothing, ReducedDCDFBAMPCCSequentialComparisonResult},
    polish_comparison::Union{Nothing, ReducedDCDFBAMPCCSequentialComparisonResult};
    enabled::Bool,
    states::AbstractString,
    relative_tolerance::Real,
    absolute_tolerance::Real,
    final_states::AbstractString,
    final_absolute_tolerance::Real,
)::NamedTuple
    core_states = _reduced_mpcc_global_polish_metric_states(states)
    terminal_states = _reduced_mpcc_global_polish_metric_states(final_states)
    metadata = Dict{String, Any}(
        "biological_acceptance_enabled" => enabled,
        "biological_acceptance_states" => join(core_states, ","),
        "biological_acceptance_final_states" => join(terminal_states, ","),
        "biological_acceptance_relative_tolerance" => Float64(relative_tolerance),
        "biological_acceptance_absolute_tolerance" => Float64(absolute_tolerance),
        "biological_acceptance_final_absolute_tolerance" =>
            Float64(final_absolute_tolerance),
        "biological_acceptance_trace_states_excluded" =>
            join(REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_AROMA_TRACE_STATES, ","),
    )
    if !enabled
        metadata["biological_acceptance_passed"] = true
        metadata["biological_acceptance_reason"] = "disabled"
        return (passed = true, metadata = metadata)
    end
    if start_comparison === nothing || polish_comparison === nothing
        metadata["biological_acceptance_passed"] = false
        metadata["biological_acceptance_reason"] = "comparison_missing"
        return (passed = false, metadata = metadata)
    end
    isempty(core_states) && throw(
        ArgumentError(
            "Reduced MPCC global polish biological acceptance is enabled but no " *
            "core states were requested.",
        ),
    )

    start_core_relative_rmse =
        _reduced_mpcc_global_polish_comparison_max_metric(
            start_comparison,
            core_states,
            "relative_rmse",
        )
    polish_core_relative_rmse =
        _reduced_mpcc_global_polish_comparison_max_metric(
            polish_comparison,
            core_states,
            "relative_rmse",
        )
    core_not_worse = _reduced_mpcc_global_polish_acceptance_not_worse(
        polish_core_relative_rmse,
        start_core_relative_rmse,
        relative_tolerance,
        absolute_tolerance,
    )
    start_core_final_abs =
        isempty(terminal_states) ? 0.0 :
        _reduced_mpcc_global_polish_comparison_max_metric(
            start_comparison,
            terminal_states,
            "final_difference_mpcc_minus_sequential",
        )
    polish_core_final_abs =
        isempty(terminal_states) ? 0.0 :
        _reduced_mpcc_global_polish_comparison_max_metric(
            polish_comparison,
            terminal_states,
            "final_difference_mpcc_minus_sequential",
        )
    final_not_worse = _reduced_mpcc_global_polish_acceptance_not_worse(
        polish_core_final_abs,
        start_core_final_abs,
        relative_tolerance,
        final_absolute_tolerance,
    )
    passed = core_not_worse && final_not_worse
    metadata["biological_acceptance_passed"] = passed
    metadata["biological_acceptance_reason"] =
        passed ? "core_states_not_worse_than_pre_solve_start" :
        (!core_not_worse ? "core_relative_rmse_worse_than_pre_solve_start" :
         "core_final_difference_worse_than_pre_solve_start")
    metadata["biological_acceptance_start_core_relative_rmse"] =
        start_core_relative_rmse
    metadata["biological_acceptance_post_solve_core_relative_rmse"] =
        polish_core_relative_rmse
    metadata["biological_acceptance_core_relative_rmse_not_worse"] = core_not_worse
    metadata["biological_acceptance_start_core_final_abs_difference"] =
        start_core_final_abs
    metadata["biological_acceptance_post_solve_core_final_abs_difference"] =
        polish_core_final_abs
    metadata["biological_acceptance_core_final_difference_not_worse"] =
        final_not_worse
    return (passed = passed, metadata = metadata)
end

function _reduced_mpcc_global_polish_select_accepted_candidate(
    start_candidate::ReducedDCDFBAMPCCCandidateDiagnostics,
    solve_attempt::ReducedDCDFBAMPCCSolveAttemptResult,
    trajectory_candidate::Union{Nothing, ReducedDCDFBAMPCCTrajectoryCandidate},
    comparison_result::Union{Nothing, ReducedDCDFBAMPCCSequentialComparisonResult},
    sequential_reference::SimulationResult;
    biological_acceptance_enabled::Bool = false,
    biological_acceptance_states::AbstractString =
        join(
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_STATES,
            ",",
        ),
    biological_acceptance_relative_tolerance::Real = 0.01,
    biological_acceptance_absolute_tolerance::Real = 1.0e-9,
    biological_acceptance_final_states::AbstractString =
        join(
            REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_DEFAULT_FINAL_STATES,
            ",",
        ),
    biological_acceptance_final_absolute_tolerance::Real = 1.0e-4,
    structural_acceptance_relative_tolerance::Real = 0.05,
    accept_post_solve_requires_trajectory_ready::Bool = false,
)
    structural_relative_tolerance = Float64(structural_acceptance_relative_tolerance)
    if !isfinite(structural_relative_tolerance) || structural_relative_tolerance < 0.0
        throw(ArgumentError("structural_acceptance_relative_tolerance must be finite and nonnegative"))
    end
    polish_candidate = solve_attempt.candidate_diagnostics
    start_score = _reduced_mpcc_global_polish_selection_score(
        start_candidate.residual_values,
        start_candidate.residual_thresholds,
    )
    polish_score = _reduced_mpcc_global_polish_selection_score(
        solve_attempt.residual_report,
    )
    polish_residual_feasible =
        polish_candidate !== nothing &&
        get(polish_candidate.metadata, "candidate_residual_feasible", false) === true
    start_residual_feasible =
        get(start_candidate.metadata, "candidate_residual_feasible", false) === true
    score_tolerance = 1.0e-9
    polish_not_worse =
        polish_candidate !== nothing &&
        polish_score <= max(
            start_score * (1.0 + structural_relative_tolerance),
            start_score + score_tolerance,
        )
    polish_structural_absolute_feasible =
        polish_candidate !== nothing && polish_residual_feasible
    polish_trajectory_ready =
        polish_candidate !== nothing &&
        get(polish_candidate.metadata, "candidate_trajectory_extraction_ready", false) === true
    polish_structural_worse_but_absolute_feasible =
        polish_candidate !== nothing &&
        start_residual_feasible &&
        polish_structural_absolute_feasible &&
        !polish_not_worse
    structural_acceptance =
        polish_candidate !== nothing &&
        polish_structural_absolute_feasible
    start_trajectory = extract_reduced_dcdfba_mpcc_trajectory_candidate(
        start_candidate;
        require_trajectory_ready = false,
    )
    start_comparison = compare_reduced_dcdfba_mpcc_to_sequential(
        sequential_reference,
        start_trajectory,
    )
    biological_acceptance = _reduced_mpcc_global_polish_biological_acceptance(
        start_comparison,
        comparison_result;
        enabled = biological_acceptance_enabled,
        states = biological_acceptance_states,
        relative_tolerance = biological_acceptance_relative_tolerance,
        absolute_tolerance = biological_acceptance_absolute_tolerance,
        final_states = biological_acceptance_final_states,
        final_absolute_tolerance = biological_acceptance_final_absolute_tolerance,
    )
    accept_polish =
        polish_candidate !== nothing &&
        polish_residual_feasible &&
        structural_acceptance &&
        biological_acceptance.passed &&
        (!accept_post_solve_requires_trajectory_ready || polish_trajectory_ready)

    accepted_candidate = accept_polish ? polish_candidate : start_candidate
    accepted_trajectory =
        accept_polish ? trajectory_candidate : start_trajectory
    accepted_comparison =
        accept_polish ? comparison_result : start_comparison
    polish_value_source =
        polish_candidate === nothing ? "post_solve_values" :
        String(
            get(
                polish_candidate.metadata,
                "candidate_values_source",
                get(polish_candidate.metadata, "candidate_value_source", "post_solve_values"),
            ),
        )
    accepted_value_source = String(
        get(
            accepted_candidate.metadata,
            "candidate_values_source",
            get(
                accepted_candidate.metadata,
                "candidate_value_source",
                accept_polish ? polish_value_source : "pre_solve_start_values",
            ),
        ),
    )
    reason =
        if accept_polish && polish_residual_feasible && polish_not_worse
            "post_solve_candidate_residual_feasible"
        elseif accept_polish && polish_structural_worse_but_absolute_feasible
            "post_solve_candidate_residual_feasible_structural_score_worse_than_pre_solve_start"
        elseif accept_polish
            "post_solve_candidate_residual_feasible_absolute_structural_gate"
        elseif polish_candidate === nothing
            "post_solve_candidate_missing_fallback_to_pre_solve_start"
        elseif !polish_residual_feasible
            "post_solve_candidate_not_residual_feasible_fallback_to_pre_solve_start"
        elseif !structural_acceptance
            "post_solve_candidate_structural_guard_failed_fallback_to_pre_solve_start"
        elseif !biological_acceptance.passed
            "post_solve_candidate_core_biology_guard_failed_fallback_to_pre_solve_start"
        elseif accept_post_solve_requires_trajectory_ready && !polish_trajectory_ready
            "post_solve_candidate_not_trajectory_ready_fallback_to_pre_solve_start"
        else
            "post_solve_structural_residual_score_worse_than_pre_solve_start"
        end
    metadata = Dict{String, Any}(
        "candidate_selection_policy" =>
            "prefer_post_solve_when_residual_feasible_absolute_structural_gate_and_core_biology_not_worse_than_pre_solve_start",
        "candidate_selection_reason" => reason,
        "candidate_selection_accept_post_solve_requires_trajectory_ready" =>
            accept_post_solve_requires_trajectory_ready,
        "selected_candidate_source" =>
            accept_polish ? polish_value_source : "pre_solve_start_values",
        "selected_candidate_is_post_solve" => accept_polish,
        "selected_candidate_is_pre_solve_start" => !accept_polish,
        "post_solve_candidate_available" => polish_candidate !== nothing,
        "post_solve_candidate_accepted" => accept_polish,
        "post_solve_candidate_rejected" => polish_candidate !== nothing && !accept_polish,
        "post_solve_structural_residual_score" => polish_score,
        "pre_solve_start_structural_residual_score" => start_score,
        "post_solve_structural_acceptance_relative_tolerance" =>
            structural_relative_tolerance,
        "selected_candidate_structural_residual_score" =>
            accept_polish ? polish_score : start_score,
        "post_solve_candidate_structural_not_worse" => polish_not_worse,
        "post_solve_candidate_structural_relative_guard_passed" => polish_not_worse,
        "post_solve_candidate_structural_absolute_feasible" =>
            polish_structural_absolute_feasible,
        "post_solve_candidate_structural_worse_than_pre_solve_start_but_residual_feasible" =>
            polish_structural_worse_but_absolute_feasible,
        "post_solve_candidate_structural_acceptance_passed" =>
            structural_acceptance,
        "pre_solve_start_candidate_residual_feasible" => start_residual_feasible,
        "post_solve_candidate_residual_feasible" => polish_residual_feasible,
        "post_solve_candidate_trajectory_ready" => polish_trajectory_ready,
        "selected_candidate_residual_feasible" =>
            get(accepted_candidate.metadata, "candidate_residual_feasible", missing),
        "selected_candidate_trajectory_ready" => get(
            accepted_candidate.metadata,
            "candidate_trajectory_extraction_ready",
            missing,
        ),
        "selected_candidate_dominant_residual" =>
            get(accepted_candidate.metadata, "candidate_dominant_residual", missing),
        "selected_candidate_value_source" =>
            accepted_value_source,
        "global_candidate_values_source" =>
            accepted_value_source,
    )
    merge!(metadata, biological_acceptance.metadata)
    accepted_comparison === nothing || merge!(
        metadata,
        Dict{String, Any}(
            "selected_candidate_max_state_relative_rmse" =>
                get(accepted_comparison.metadata, "max_state_relative_rmse", missing),
            "selected_candidate_max_state_abs_difference" =>
                get(accepted_comparison.metadata, "max_state_abs_difference", missing),
            "selected_candidate_final_biomass_difference" =>
                _reduced_mpcc_sweep_final_difference(accepted_comparison, "biomass"),
            "selected_candidate_final_total_sugar_difference" =>
                _reduced_mpcc_sweep_final_difference(accepted_comparison, "total_sugar"),
        ),
    )
    return (
        candidate = accepted_candidate,
        trajectory_candidate = accepted_trajectory,
        comparison_result = accepted_comparison,
        metadata = metadata,
    )
end

function _reduced_mpcc_global_polish_recommended_action(
    residual_feasible::Bool,
    trajectory_ready::Bool,
    iteration_limit_residual_feasible::Bool,
    pre_solve_blocked::Bool;
    dominant_residual = missing,
)::String
    pre_solve_blocked && return "inspect_global_polish_preflight"
    trajectory_ready && residual_feasible &&
        return "review_global_polish_candidate_before_scientific_use"
    iteration_limit_residual_feasible &&
        return "increase_global_polish_iterations_or_refine_scaling"
    residual_feasible && return "improve_global_polish_solver_status"
    _reduced_mpcc_global_polish_is_structural_residual(dominant_residual) &&
        return "improve_global_structural_feasibility_before_biology"
    return "inspect_global_polish_residuals"
end

function _reduced_mpcc_global_polish_is_structural_residual(value)::Bool
    value === missing && return false
    text = String(value)
    return text in (
        "max_collocation_integration_residual",
        "max_continuity_residual",
        "max_initial_condition_residual",
    )
end

function _reduced_mpcc_global_polish_dict_table(values::Dict)::DataFrame
    rows = [
        Dict{String, Any}(
            "key" => String(key),
            "value" => _reduced_mpcc_global_polish_table_scalar(value),
        ) for (key, value) in sort(collect(values); by = item -> String(item[1]))
        if String(key) != "nlp_block_violation_rows"
    ]
    return DataFrame(rows)
end

function _reduced_mpcc_global_polish_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractVector || value isa AbstractDict || value isa Tuple
        return string(value)
    else
        return value
    end
end

function _reduced_mpcc_global_polish_nlp_block_violation_rows(
    result::ReducedDCDFBAMPCCGlobalPolishResult,
)
    rows = get(result.solve_attempt.metadata, "nlp_block_violation_rows", nothing)
    rows === nothing && return nothing
    rows isa AbstractVector || return nothing
    isempty(rows) && return nothing
    return rows
end
