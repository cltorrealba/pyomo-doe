import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOWED_SELECTIVE_REFINEMENT_TYPE =
    "reduced_dcdfba_mpcc_windowed_selective_refinement"
const REDUCED_DCDFBA_MPCC_WINDOWED_SELECTIVE_REPLACEMENT_TYPE =
    "reduced_dcdfba_mpcc_windowed_selective_replacement"

struct ReducedDCDFBAMPCCWindowedSelectiveRefinementResult
    selected_windows::DataFrame
    refined_window_table::DataFrame
    before_after_table::DataFrame
    refined_state_metrics_table::DataFrame
    refined_aligned_timeseries_table::DataFrame
    metadata::Dict{String, Any}
end

struct ReducedDCDFBAMPCCWindowedSelectiveReplacementResult
    replacement_table::DataFrame
    window_table::DataFrame
    state_metrics_table::DataFrame
    aligned_timeseries_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    run_reduced_dcdfba_mpcc_windowed_selective_refinement(...)

Rerun only selected windows from a previous windowed MPCC artifact set. Each
window is initialized from the exported sequential reference at its own `t0`,
so this is a local refinement diagnostic and not a full-horizon rerun.
"""
function run_reduced_dcdfba_mpcc_windowed_selective_refinement(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    window_table::DataFrame,
    refinement_candidates::DataFrame,
    aligned_timeseries_table::DataFrame;
    top_n::Int = 4,
    window_ids::AbstractVector{<:AbstractString} = String[],
    only_coarse_tau_fallback::Bool = true,
    minimum_priority::AbstractString = "high",
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    complementarity_tau_gate_tol::Union{Nothing, Real} =
        reduced_mpcc_complementarity_tau_gate_tol_from_env(),
    tau_schedule = [1.0e-2, 1.0e-4, 1.0e-6],
    tau_stage_max_iters = reduced_mpcc_tau_stage_max_iters_from_env(),
    tau_final_retry_max_iter = reduced_mpcc_tau_final_retry_max_iter_from_env(),
    allow_coarse_tau_fallback::Bool = false,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    continuation_acceptance_policy::AbstractString =
        REDUCED_DCDFBA_MPCC_CONTINUATION_POLICY_ITERATION_LIMIT_STATE_DRIFT,
    continuation_state_abs_difference_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_ABS_DIFFERENCE,
    continuation_state_relative_rmse_threshold::Real =
        REDUCED_DCDFBA_MPCC_CONTINUATION_DEFAULT_MAX_STATE_RELATIVE_RMSE,
    silent::Bool = true,
    continue_on_error::Bool = true,
    window_callback = nothing,
    tau_stage_callback = nothing,
)::ReducedDCDFBAMPCCWindowedSelectiveRefinementResult
    top_n > 0 || throw(ArgumentError("Selective refinement top_n must be positive."))
    selected = _reduced_mpcc_selective_refinement_select_windows(
        refinement_candidates;
        top_n = top_n,
        window_ids = window_ids,
        only_coarse_tau_fallback = only_coarse_tau_fallback,
        minimum_priority = minimum_priority,
    )
    policy = _reduced_mpcc_window_validate_continuation_policy(
        continuation_acceptance_policy,
    )
    state_threshold =
        _reduced_mpcc_window_validate_state_relative_rmse_threshold(
            continuation_state_relative_rmse_threshold,
        )
    abs_threshold =
        _reduced_mpcc_window_validate_state_abs_difference_threshold(
            continuation_state_abs_difference_threshold,
        )

    refined_rows = Dict{String, Any}[]
    before_after_rows = Dict{String, Any}[]
    refined_state_metric_rows = Dict{String, Any}[]
    refined_aligned_rows = Dict{String, Any}[]
    for (selection_index, candidate_row) in enumerate(eachrow(selected))
        original_window = _reduced_mpcc_selective_refinement_window_row(
            window_table,
            String(candidate_row["window_id"]),
        )
        spec = _reduced_mpcc_selective_refinement_spec(original_window)
        y0 = _reduced_mpcc_selective_refinement_y0(aligned_timeseries_table, spec.t0)
        refined_comparison = nothing
        refined_row = nothing
        try
            refined_comparison = _reduced_mpcc_window_run_one(
                model,
                reaction_map;
                spec = spec,
                y0 = y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = ipopt_max_iter,
                linear_solver = linear_solver,
                ipopt_profile = ipopt_profile,
                complementarity_mode = complementarity_mode,
                complementarity_tau = complementarity_tau,
                complementarity_tau_gate_tol = complementarity_tau_gate_tol,
                tau_schedule = tau_schedule,
                tau_stage_max_iters = tau_stage_max_iters,
                tau_final_retry_max_iter = tau_final_retry_max_iter,
                allow_coarse_tau_fallback = allow_coarse_tau_fallback,
                flux_dual_start_seed = nothing,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                silent = silent,
                tau_stage_callback = _reduced_mpcc_window_tau_stage_callback(
                    tau_stage_callback,
                    spec,
                    "selective_refinement",
                ),
            )
            refined_row = _reduced_mpcc_window_completed_row(
                spec.window_index,
                refined_comparison;
                continuation_acceptance_policy = policy,
                continuation_state_abs_difference_threshold = abs_threshold,
                continuation_state_relative_rmse_threshold = state_threshold,
                state_drift_blocks_continuation = false,
            )
            refined_row["window_initial_state_primary_source"] =
                "artifact_sequential_reference_at_window_start"
            refined_row["window_initial_state_propagation_policy"] =
                REDUCED_DCDFBA_MPCC_WINDOW_INITIAL_STATE_PROPAGATION_SEQUENTIAL
            refined_row["window_initial_state_retry_applied"] = false
            refined_row["window_initial_state_retry_source"] = "not_attempted"
            refined_row["next_initial_state_source"] = "not_applicable_selective_window"
            append!(
                refined_state_metric_rows,
                _reduced_mpcc_selective_refinement_state_metric_rows(
                    refined_comparison,
                    spec,
                    selection_index,
                ),
            )
            append!(
                refined_aligned_rows,
                _reduced_mpcc_selective_refinement_aligned_rows(
                    refined_comparison,
                    spec,
                    selection_index,
                ),
            )
        catch err
            continue_on_error || rethrow()
            refined_row = _reduced_mpcc_window_error_row(spec, err)
            refined_row["solver_status"] = "REFINEMENT_ERROR"
            refined_row["primal_status"] = "NO_SOLUTION"
            refined_row["solve_elapsed_seconds"] = 0.0
        end
        push!(refined_rows, refined_row)
        push!(
            before_after_rows,
            _reduced_mpcc_selective_refinement_before_after_row(
                candidate_row,
                original_window,
                refined_row,
                selection_index,
            ),
        )
        _reduced_mpcc_window_maybe_callback(
            window_callback,
            refined_row,
            selection_index,
            nrow(selected),
        )
    end

    refined_window_table = _reduced_mpcc_window_table(refined_rows)
    before_after_table = DataFrame(before_after_rows)
    refined_state_metrics_table = DataFrame(refined_state_metric_rows)
    refined_aligned_timeseries_table = DataFrame(refined_aligned_rows)
    metadata = Dict{String, Any}(
        "result_type" => REDUCED_DCDFBA_MPCC_WINDOWED_SELECTIVE_REFINEMENT_TYPE,
        "selective_refinement_is_scientific_simulation" => false,
        "full_horizon_rerun_performed" => false,
        "n_selected_windows" => nrow(selected),
        "top_n" => top_n,
        "requested_window_ids" => collect(String.(window_ids)),
        "only_coarse_tau_fallback" => only_coarse_tau_fallback,
        "minimum_priority" => String(minimum_priority),
        "ipopt_max_iter" => ipopt_max_iter === nothing ? "default" : ipopt_max_iter,
        "linear_solver" => String(linear_solver),
        "ipopt_profile" => String(ipopt_profile),
        "complementarity_mode" => String(complementarity_mode),
        "complementarity_tau" => Float64(complementarity_tau),
        "tau_schedule" => tau_schedule === nothing ? "disabled" : join(tau_schedule, ","),
        "tau_stage_max_iters" =>
            tau_stage_max_iters === nothing ? "default" : join(
                (value === nothing ? "default" : string(value) for value in tau_stage_max_iters),
                ",",
            ),
        "tau_final_retry_max_iter" =>
            tau_final_retry_max_iter === nothing ? "disabled" : string(tau_final_retry_max_iter),
        "allow_coarse_tau_fallback" => allow_coarse_tau_fallback,
        "residual_max_rhs" => residual_thresholds.max_rhs_residual,
        "residual_max_mass" => residual_thresholds.max_mass_balance_residual,
        "residual_max_lower_complementarity" =>
            residual_thresholds.max_lower_complementarity_residual,
        "residual_max_upper_complementarity" =>
            residual_thresholds.max_upper_complementarity_residual,
    )
    return ReducedDCDFBAMPCCWindowedSelectiveRefinementResult(
        selected,
        refined_window_table,
        before_after_table,
        refined_state_metrics_table,
        refined_aligned_timeseries_table,
        metadata,
    )
end

function run_reduced_dcdfba_mpcc_windowed_selective_refinement_artifacts(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    artifact_dir::AbstractString;
    refinement_dir::Union{Nothing, AbstractString} = nothing,
    kwargs...,
)::ReducedDCDFBAMPCCWindowedSelectiveRefinementResult
    diagnostics_dir = _reduced_mpcc_refinement_diagnostics_dir(artifact_dir)
    candidates_dir =
        refinement_dir === nothing ? joinpath(dirname(diagnostics_dir), "refinement_diagnostics") :
        normpath(String(refinement_dir))
    candidates_path = joinpath(candidates_dir, "window_refinement_candidates.csv")
    isfile(candidates_path) || error(
        "Selective refinement requires window_refinement_candidates.csv. " *
        "Run main_reduced_mpcc_windowed_refinement_diagnostics.jl first or set refinement_dir.",
    )
    window_table = CSV.read(joinpath(diagnostics_dir, "window_table.csv"), DataFrame)
    aligned_timeseries = CSV.read(joinpath(diagnostics_dir, "aligned_timeseries.csv"), DataFrame)
    candidates = CSV.read(candidates_path, DataFrame)
    return run_reduced_dcdfba_mpcc_windowed_selective_refinement(
        model,
        reaction_map,
        window_table,
        candidates,
        aligned_timeseries;
        kwargs...,
    )
end

function export_reduced_dcdfba_mpcc_windowed_selective_refinement(
    result::ReducedDCDFBAMPCCWindowedSelectiveRefinementResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Reduced MPCC selective-refinement output_dir exists and is not a directory: $output_path")
    end
    paths = Dict{String, String}(
        "selected_windows" => joinpath(output_path, "selected_windows.csv"),
        "refined_window_table" => joinpath(output_path, "refined_window_table.csv"),
        "before_after_table" => joinpath(output_path, "before_after_table.csv"),
        "refined_state_metrics" => joinpath(output_path, "refined_state_metrics.csv"),
        "refined_aligned_timeseries" => joinpath(output_path, "refined_aligned_timeseries.csv"),
        "metadata" => joinpath(output_path, "metadata.toml"),
    )
    _reduced_mpcc_window_prepare_output_paths!(paths, overwrite)
    CSV.write(paths["selected_windows"], result.selected_windows)
    CSV.write(paths["refined_window_table"], result.refined_window_table)
    CSV.write(paths["before_after_table"], result.before_after_table)
    CSV.write(paths["refined_state_metrics"], result.refined_state_metrics_table)
    CSV.write(paths["refined_aligned_timeseries"], result.refined_aligned_timeseries_table)
    open(paths["metadata"], "w") do io
        TOML.print(io, _toml_normalize(result.metadata))
    end
    return paths
end

"""
    apply_reduced_dcdfba_mpcc_windowed_selective_replacements(...)

Apply selected refined window trajectories to a previous coarse windowed MPCC
aligned-timeseries table. By default only refined windows that are both
residual-feasible and trajectory-ready are applied.
"""
function apply_reduced_dcdfba_mpcc_windowed_selective_replacements(
    window_table::DataFrame,
    state_metrics_table::DataFrame,
    aligned_timeseries_table::DataFrame,
    before_after_table::DataFrame,
    refined_aligned_timeseries_table::DataFrame;
    replacement_policy::AbstractString = "trajectory_ready",
    include_left_boundary::Bool = false,
)::ReducedDCDFBAMPCCWindowedSelectiveReplacementResult
    nrow(aligned_timeseries_table) > 0 ||
        throw(ArgumentError("Selective replacement requires non-empty aligned_timeseries_table."))
    nrow(before_after_table) > 0 ||
        throw(ArgumentError("Selective replacement requires non-empty before_after_table."))
    nrow(refined_aligned_timeseries_table) > 0 ||
        throw(ArgumentError("Selective replacement requires non-empty refined_aligned_timeseries_table."))

    policy = _reduced_mpcc_selective_replacement_validate_policy(replacement_policy)
    replaced = copy(aligned_timeseries_table)
    replacement_rows = Dict{String, Any}[]
    states = _reduced_mpcc_refinement_state_names(replaced)

    for row in eachrow(before_after_table)
        window_id = String(row["window_id"])
        accepted, reason = _reduced_mpcc_selective_replacement_accept(row, policy)
        refined_rows = refined_aligned_timeseries_table[
            String.(refined_aligned_timeseries_table[!, "window_id"]) .== window_id,
            :,
        ]
        updated_count = 0
        if accepted && nrow(refined_rows) > 0
            updated_count = _reduced_mpcc_selective_replacement_apply!(
                replaced,
                refined_rows,
                states;
                t0 = Float64(row["t0"]),
                include_left_boundary = include_left_boundary,
            )
            updated_count == 0 && (reason = "accepted_but_no_matching_timepoints")
        elseif accepted
            accepted = false
            reason = "missing_refined_aligned_timeseries"
        end
        push!(
            replacement_rows,
            Dict{String, Any}(
                "window_id" => window_id,
                "window_index" => Int(row["window_index"]),
                "t0" => Float64(row["t0"]),
                "tfinal" => Float64(row["tfinal"]),
                "replacement_policy" => policy,
                "replacement_applied" => accepted && updated_count > 0,
                "replacement_reason" => reason,
                "updated_timepoint_count" => updated_count,
                "original_tau" => _reduced_mpcc_refinement_number(row, "original_tau", NaN),
                "refined_tau" => _reduced_mpcc_refinement_number(row, "refined_tau", NaN),
                "original_residual_feasible" =>
                    _reduced_mpcc_refinement_bool(row["original_residual_feasible"]),
                "refined_residual_feasible" =>
                    _reduced_mpcc_refinement_bool(row["refined_residual_feasible"]),
                "original_trajectory_ready" =>
                    _reduced_mpcc_refinement_bool(row["original_trajectory_ready"]),
                "refined_trajectory_ready" =>
                    _reduced_mpcc_refinement_bool(row["refined_trajectory_ready"]),
                "original_max_state_abs_difference" =>
                    _reduced_mpcc_refinement_number(row, "original_max_state_abs_difference", NaN),
                "refined_max_state_abs_difference" =>
                    _reduced_mpcc_refinement_number(row, "refined_max_state_abs_difference", NaN),
                "original_max_state_relative_rmse" =>
                    _reduced_mpcc_refinement_number(row, "original_max_state_relative_rmse", NaN),
                "refined_max_state_relative_rmse" =>
                    _reduced_mpcc_refinement_number(row, "refined_max_state_relative_rmse", NaN),
            ),
        )
    end

    replacement_table = DataFrame(replacement_rows)
    replaced_metrics = _reduced_mpcc_selective_replacement_state_metrics(replaced)
    metadata = Dict{String, Any}(
        "result_type" => REDUCED_DCDFBA_MPCC_WINDOWED_SELECTIVE_REPLACEMENT_TYPE,
        "replacement_policy" => policy,
        "include_left_boundary" => include_left_boundary,
        "n_candidate_replacements" => nrow(before_after_table),
        "n_applied_replacements" =>
            count(_reduced_mpcc_refinement_bool, replacement_table[!, "replacement_applied"]),
        "n_updated_timepoints" => sum(Int.(replacement_table[!, "updated_timepoint_count"])),
        "source_global_max_state_abs_difference" =>
            _reduced_mpcc_window_metric_max(state_metrics_table, "max_abs_difference"),
        "source_global_max_state_relative_rmse" =>
            _reduced_mpcc_window_metric_max(state_metrics_table, "relative_rmse"),
        "replaced_global_max_state_abs_difference" =>
            _reduced_mpcc_window_metric_max(replaced_metrics, "max_abs_difference"),
        "replaced_global_max_state_relative_rmse" =>
            _reduced_mpcc_window_metric_max(replaced_metrics, "relative_rmse"),
        "outputs_written" => false,
        "windowed_replacement_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "interpretation_note" =>
            "Selective refined-window replacement applied to exported reduced MPCC diagnostics; " *
            "diagnostic only, not a full simultaneous scientific simulation.",
    )
    return ReducedDCDFBAMPCCWindowedSelectiveReplacementResult(
        replacement_table,
        copy(window_table),
        replaced_metrics,
        replaced,
        metadata,
    )
end

function apply_reduced_dcdfba_mpcc_windowed_selective_replacement_artifacts(
    artifact_dir::AbstractString,
    selective_refinement_dirs::AbstractVector{<:AbstractString};
    replacement_policy::AbstractString = "trajectory_ready",
    include_left_boundary::Bool = false,
)::ReducedDCDFBAMPCCWindowedSelectiveReplacementResult
    diagnostics_dir = _reduced_mpcc_refinement_diagnostics_dir(artifact_dir)
    window_table = CSV.read(joinpath(diagnostics_dir, "window_table.csv"), DataFrame)
    state_metrics_table = CSV.read(joinpath(diagnostics_dir, "state_metrics.csv"), DataFrame)
    aligned_timeseries_table = CSV.read(joinpath(diagnostics_dir, "aligned_timeseries.csv"), DataFrame)
    before_after, refined_aligned =
        _reduced_mpcc_selective_replacement_read_refinements(selective_refinement_dirs)
    result = apply_reduced_dcdfba_mpcc_windowed_selective_replacements(
        window_table,
        state_metrics_table,
        aligned_timeseries_table,
        before_after,
        refined_aligned;
        replacement_policy = replacement_policy,
        include_left_boundary = include_left_boundary,
    )
    result.metadata["source_artifact_dir"] = normpath(String(artifact_dir))
    result.metadata["source_diagnostics_dir"] = diagnostics_dir
    result.metadata["selective_refinement_dirs"] =
        [normpath(String(dir)) for dir in selective_refinement_dirs]
    return result
end

function export_reduced_dcdfba_mpcc_windowed_selective_replacement(
    result::ReducedDCDFBAMPCCWindowedSelectiveReplacementResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Reduced MPCC selective replacement output_dir exists and is not a directory: $output_path")
    end
    paths = Dict{String, String}(
        "replacement_table" => joinpath(output_path, "replacement_table.csv"),
        "window_table" => joinpath(output_path, "window_table.csv"),
        "state_metrics" => joinpath(output_path, "state_metrics.csv"),
        "aligned_timeseries" => joinpath(output_path, "aligned_timeseries.csv"),
        "metadata" => joinpath(output_path, "metadata.toml"),
    )
    _reduced_mpcc_window_prepare_output_paths!(paths, overwrite)
    CSV.write(paths["replacement_table"], result.replacement_table)
    CSV.write(paths["window_table"], result.window_table)
    CSV.write(paths["state_metrics"], result.state_metrics_table)
    CSV.write(paths["aligned_timeseries"], result.aligned_timeseries_table)
    open(paths["metadata"], "w") do io
        TOML.print(io, _toml_normalize(result.metadata))
    end
    return paths
end

function write_reduced_dcdfba_mpcc_windowed_selective_replacement_report(
    result::ReducedDCDFBAMPCCWindowedSelectiveReplacementResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    diagnostics_dir = joinpath(output_path, "diagnostics")
    plots_dir = joinpath(output_path, "plots")
    result.metadata["outputs_written"] = true
    result.metadata["output_dir"] = output_path
    result.metadata["diagnostic_output_dir"] = diagnostics_dir
    result.metadata["plot_output_dir"] = plots_dir

    paths = Dict{String, String}()
    for (key, path) in export_reduced_dcdfba_mpcc_windowed_selective_replacement(
        result,
        diagnostics_dir;
        overwrite = overwrite,
    )
        paths["diagnostics_$(key)"] = path
    end
    plot_result = ReducedDCDFBAMPCCWindowedContinuationResult(
        result.window_table,
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        nothing,
        nothing,
        result.state_metrics_table,
        result.aligned_timeseries_table,
        copy(result.metadata),
    )
    for (key, path) in write_reduced_dcdfba_mpcc_windowed_plots(
        plot_result,
        plots_dir;
        overwrite = overwrite,
    )
        paths["plot_$(key)"] = path
    end
    return paths
end

function _reduced_mpcc_selective_refinement_select_windows(
    refinement_candidates::DataFrame;
    top_n::Int,
    window_ids::AbstractVector{<:AbstractString},
    only_coarse_tau_fallback::Bool,
    minimum_priority::AbstractString,
)::DataFrame
    nrow(refinement_candidates) > 0 ||
        throw(ArgumentError("Selective refinement requires non-empty refinement_candidates."))
    selected = copy(refinement_candidates)
    requested_ids = Set(String.(window_ids))
    if !isempty(requested_ids)
        selected = selected[in.(String.(selected[!, "window_id"]), Ref(requested_ids)), :]
    else
        if only_coarse_tau_fallback && "coarse_tau_fallback" in names(selected)
            selected = selected[_reduced_mpcc_refinement_bool.(selected[!, "coarse_tau_fallback"]), :]
        end
        priority_rank = Dict("high" => 3, "medium" => 2, "low" => 1)
        min_rank = get(priority_rank, lowercase(String(minimum_priority)), 1)
        if "refinement_priority" in names(selected)
            selected = selected[
                [get(priority_rank, lowercase(String(value)), 0) >= min_rank for value in selected[!, "refinement_priority"]],
                :,
            ]
        end
        if "refinement_rank" in names(selected)
            sort!(selected, :refinement_rank)
        elseif "refinement_score" in names(selected)
            sort!(selected, :refinement_score, rev = true)
        end
        selected = first(selected, min(top_n, nrow(selected)))
    end
    nrow(selected) > 0 ||
        throw(ArgumentError("Selective refinement selection is empty. Relax filters or pass window_ids."))
    return selected
end

function _reduced_mpcc_selective_refinement_window_row(
    window_table::DataFrame,
    window_id::AbstractString,
)
    matches = findall(==(String(window_id)), String.(window_table[!, "window_id"]))
    length(matches) == 1 || throw(
        ArgumentError("Expected exactly one source window row for $(window_id), got $(length(matches))."),
    )
    return window_table[matches[1], :]
end

function _reduced_mpcc_selective_refinement_spec(window_row)
    t0 = Float64(window_row["t0"])
    tfinal = Float64(window_row["tfinal"])
    nfe = Int(window_row["nfe"])
    degree = Int(window_row["degree"])
    return (
        window_id = String(window_row["window_id"]),
        window_index = Int(window_row["window_index"]),
        t0 = t0,
        tfinal = tfinal,
        window_hours = tfinal - t0,
        nfe = nfe,
        degree = degree,
        boundary_dt = (tfinal - t0) / nfe,
    )
end

function _reduced_mpcc_selective_refinement_y0(
    aligned_timeseries_table::DataFrame,
    target_time::Real,
)::Vector{Float64}
    time = Float64(target_time)
    time_index = findfirst(
        saved_time -> isapprox(Float64(saved_time), time; atol = 1.0e-8, rtol = 0.0),
        aligned_timeseries_table[!, "time"],
    )
    time_index !== nothing || throw(
        ArgumentError("Could not find sequential reference time $(time) in aligned_timeseries_table."),
    )
    values = Float64[]
    for state_name in REDUCED_DFBA_STATE_NAMES
        column = "$(state_name)_sequential"
        column in names(aligned_timeseries_table) || throw(
            ArgumentError("aligned_timeseries_table is missing required column $(column)."),
        )
        push!(values, Float64(aligned_timeseries_table[time_index, column]))
    end
    return values
end

function _reduced_mpcc_selective_refinement_state_metric_rows(
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
    spec,
    selection_index::Int,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    for row in eachrow(comparison.state_metrics_table)
        push!(
            rows,
            Dict{String, Any}(
                "selection_index" => selection_index,
                "window_id" => spec.window_id,
                "window_index" => spec.window_index,
                "t0" => spec.t0,
                "tfinal" => spec.tfinal,
                "state_name" => String(row["state_name"]),
                "final_difference_mpcc_minus_sequential" =>
                    Float64(row["final_difference_mpcc_minus_sequential"]),
                "max_abs_difference" => Float64(row["max_abs_difference"]),
                "rmse" => Float64(row["rmse"]),
                "relative_rmse" => Float64(row["relative_rmse"]),
            ),
        )
    end
    return rows
end

function _reduced_mpcc_selective_refinement_aligned_rows(
    comparison::ReducedDCDFBAMPCCSequentialComparisonResult,
    spec,
    selection_index::Int,
)::Vector{Dict{String, Any}}
    table = comparison.aligned_timeseries_table
    rows = Dict{String, Any}[]
    for aligned_row in eachrow(table)
        row = Dict{String, Any}(
            "selection_index" => selection_index,
            "window_id" => spec.window_id,
            "window_index" => spec.window_index,
            "t0" => spec.t0,
            "tfinal" => spec.tfinal,
        )
        for column in names(table)
            row[column] = _reduced_mpcc_seq_table_scalar(aligned_row[column])
        end
        push!(rows, row)
    end
    return rows
end

function _reduced_mpcc_selective_replacement_validate_policy(
    replacement_policy::AbstractString,
)::String
    policy = lowercase(strip(String(replacement_policy)))
    policy in ("trajectory_ready", "residual_feasible", "all") || throw(
        ArgumentError(
            "Selective replacement policy must be one of trajectory_ready, residual_feasible, all; got $(replacement_policy).",
        ),
    )
    return policy
end

function _reduced_mpcc_selective_replacement_accept(row, policy::AbstractString)
    residual_feasible = _reduced_mpcc_refinement_bool(row["refined_residual_feasible"])
    trajectory_ready = _reduced_mpcc_refinement_bool(row["refined_trajectory_ready"])
    if policy == "trajectory_ready"
        accepted = residual_feasible && trajectory_ready
        reason = accepted ? "refined_residual_feasible_and_trajectory_ready" :
                 "refined_not_trajectory_ready"
    elseif policy == "residual_feasible"
        accepted = residual_feasible
        reason = accepted ? "refined_residual_feasible" : "refined_not_residual_feasible"
    else
        accepted = true
        reason = "policy_all"
    end
    return accepted, reason
end

function _reduced_mpcc_selective_replacement_apply!(
    aligned_timeseries_table::DataFrame,
    refined_rows::DataFrame,
    states::Vector{String};
    t0::Real,
    include_left_boundary::Bool,
)::Int
    times = Float64.(aligned_timeseries_table[!, "time"])
    refined_column_names = names(refined_rows)
    updated_count = 0
    for row in eachrow(refined_rows)
        time = Float64(row["time"])
        if !include_left_boundary && isapprox(time, Float64(t0); atol = 1.0e-8, rtol = 0.0)
            continue
        end
        target_index = findfirst(
            saved_time -> isapprox(saved_time, time; atol = 1.0e-8, rtol = 0.0),
            times,
        )
        target_index === nothing && continue
        changed = false
        for state in states
            mpcc_column = "$(state)_mpcc_candidate"
            sequential_column = "$(state)_sequential"
            difference_column = "$(state)_difference_mpcc_minus_sequential"
            mpcc_column in refined_column_names || continue
            mpcc_column in names(aligned_timeseries_table) || continue
            aligned_timeseries_table[target_index, mpcc_column] = Float64(row[mpcc_column])
            if sequential_column in names(aligned_timeseries_table) &&
               difference_column in names(aligned_timeseries_table)
                aligned_timeseries_table[target_index, difference_column] =
                    Float64(aligned_timeseries_table[target_index, mpcc_column]) -
                    Float64(aligned_timeseries_table[target_index, sequential_column])
            end
            changed = true
        end
        changed && (updated_count += 1)
    end
    return updated_count
end

function _reduced_mpcc_selective_replacement_state_metrics(
    aligned_timeseries_table::DataFrame,
)::DataFrame
    states = _reduced_mpcc_refinement_state_names(aligned_timeseries_table)
    isempty(states) && return _reduced_mpcc_window_empty_state_metrics_table()
    rows = [
        _reduced_mpcc_seq_state_metric_row(
            state,
            aligned_timeseries_table[!, "$(state)_sequential"],
            aligned_timeseries_table[!, "$(state)_mpcc_candidate"],
        ) for state in states
    ]
    return DataFrame(
        (
            column => [_reduced_mpcc_seq_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_SEQUENTIAL_STATE_METRIC_COLUMNS
        )...,
    )
end

function _reduced_mpcc_selective_replacement_read_refinements(
    selective_refinement_dirs::AbstractVector{<:AbstractString},
)::Tuple{DataFrame, DataFrame}
    !isempty(selective_refinement_dirs) ||
        throw(ArgumentError("Selective replacement requires at least one selective refinement directory."))
    before_after_tables = DataFrame[]
    aligned_tables = DataFrame[]
    for dir in selective_refinement_dirs
        output_dir = _reduced_mpcc_selective_refinement_output_dir(dir)
        before_after_path = joinpath(output_dir, "before_after_table.csv")
        aligned_path = joinpath(output_dir, "refined_aligned_timeseries.csv")
        isfile(aligned_path) || error(
            "Selective replacement requires refined_aligned_timeseries.csv in $(output_dir). " *
            "Rerun selective refinement with the current code.",
        )
        before_after = CSV.read(before_after_path, DataFrame)
        before_after[!, "selective_refinement_output_dir"] = fill(output_dir, nrow(before_after))
        aligned = CSV.read(aligned_path, DataFrame)
        aligned[!, "selective_refinement_output_dir"] = fill(output_dir, nrow(aligned))
        push!(before_after_tables, before_after)
        push!(aligned_tables, aligned)
    end
    return (
        vcat(before_after_tables...; cols = :union),
        vcat(aligned_tables...; cols = :union),
    )
end

function _reduced_mpcc_selective_refinement_output_dir(path::AbstractString)::String
    root = normpath(String(path))
    candidates = [
        root,
        joinpath(root, "artifacts"),
        joinpath(root, "selective_refinement"),
    ]
    for candidate in candidates
        if isfile(joinpath(candidate, "before_after_table.csv"))
            return normpath(candidate)
        end
    end
    error(
        "Could not find selective refinement before_after_table.csv in $(root), " *
        "$(root)/artifacts, or $(root)/selective_refinement.",
    )
end

function _reduced_mpcc_selective_refinement_before_after_row(
    candidate_row,
    original_window,
    refined_row::Dict{String, Any},
    selection_index::Int,
)::Dict{String, Any}
    original_abs =
        _reduced_mpcc_refinement_number(candidate_row, "max_window_state_abs_difference", NaN)
    original_rel =
        _reduced_mpcc_refinement_number(candidate_row, "max_window_state_relative_rmse", NaN)
    refined_abs = _reduced_mpcc_refinement_dict_number(refined_row, "max_state_abs_difference", NaN)
    refined_rel = _reduced_mpcc_refinement_dict_number(refined_row, "max_state_relative_rmse", NaN)
    original_tau =
        _reduced_mpcc_refinement_number(candidate_row, "accepted_tau", NaN)
    refined_tau =
        _reduced_mpcc_refinement_dict_number(refined_row, "tau_continuation_selected_tau", NaN)
    return Dict{String, Any}(
        "selection_index" => selection_index,
        "window_id" => String(candidate_row["window_id"]),
        "window_index" => Int(candidate_row["window_index"]),
        "t0" => Float64(candidate_row["t0"]),
        "tfinal" => Float64(candidate_row["tfinal"]),
        "original_refinement_rank" =>
            _reduced_mpcc_refinement_number(candidate_row, "refinement_rank", NaN),
        "original_refinement_score" =>
            _reduced_mpcc_refinement_number(candidate_row, "refinement_score", NaN),
        "original_solver_status" => String(original_window["solver_status"]),
        "refined_solver_status" => string(get(refined_row, "solver_status", missing)),
        "original_primal_status" => String(original_window["primal_status"]),
        "refined_primal_status" => string(get(refined_row, "primal_status", missing)),
        "original_residual_feasible" =>
            _reduced_mpcc_refinement_bool(original_window["candidate_residual_feasible"]),
        "refined_residual_feasible" =>
            _reduced_mpcc_refinement_bool(get(refined_row, "candidate_residual_feasible", false)),
        "original_trajectory_ready" =>
            _reduced_mpcc_refinement_bool(original_window["candidate_trajectory_ready"]),
        "refined_trajectory_ready" =>
            _reduced_mpcc_refinement_bool(get(refined_row, "candidate_trajectory_ready", false)),
        "original_tau" => original_tau,
        "refined_tau" => refined_tau,
        "original_coarse_tau_fallback" =>
            _reduced_mpcc_refinement_bool(candidate_row["coarse_tau_fallback"]),
        "refined_coarse_tau_fallback" => _reduced_mpcc_refinement_bool(
            get(refined_row, "tau_continuation_coarse_tau_fallback_applied", false),
        ),
        "original_max_state_abs_difference" => original_abs,
        "refined_max_state_abs_difference" => refined_abs,
        "max_state_abs_difference_delta_refined_minus_original" => refined_abs - original_abs,
        "original_max_state_relative_rmse" => original_rel,
        "refined_max_state_relative_rmse" => refined_rel,
        "max_state_relative_rmse_delta_refined_minus_original" => refined_rel - original_rel,
        "original_dominant_abs_state" => String(candidate_row["dominant_abs_state"]),
        "original_dominant_boundary_state" => String(candidate_row["dominant_boundary_state"]),
        "refined_dominant_residual" => string(get(refined_row, "dominant_residual", missing)),
        "solve_elapsed_seconds" =>
            _reduced_mpcc_refinement_dict_number(refined_row, "solve_elapsed_seconds", 0.0),
        "recommended_followup" => _reduced_mpcc_selective_refinement_followup(
            original_tau,
            refined_tau,
            refined_abs,
            original_abs,
            get(refined_row, "solver_status", "missing"),
        ),
    )
end

function _reduced_mpcc_refinement_dict_number(
    row::Dict{String, Any},
    column::AbstractString,
    default::Float64,
)::Float64
    value = get(row, String(column), default)
    value === missing && return default
    value isa Real && return Float64(value)
    parsed = tryparse(Float64, String(value))
    return parsed === nothing ? default : parsed
end

function _reduced_mpcc_selective_refinement_followup(
    original_tau::Float64,
    refined_tau::Float64,
    refined_abs::Float64,
    original_abs::Float64,
    solver_status,
)::String
    if !isfinite(refined_tau)
        return "inspect_refinement_failure"
    elseif isfinite(original_tau) && refined_tau < original_tau && refined_abs <= original_abs
        return "candidate_for_full_horizon_policy_update"
    elseif occursin("ITERATION_LIMIT", uppercase(String(solver_status)))
        return "increase_iters_or_accept_residual_feasible_candidate"
    else
        return "inspect_before_replacing_window"
    end
end
