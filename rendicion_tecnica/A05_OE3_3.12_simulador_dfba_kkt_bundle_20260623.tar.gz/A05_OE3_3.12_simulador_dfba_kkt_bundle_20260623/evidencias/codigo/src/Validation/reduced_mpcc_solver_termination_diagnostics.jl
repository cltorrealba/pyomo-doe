const REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_DIAGNOSTIC_TYPE =
    "reduced_dcdfba_mpcc_solver_termination_diagnostics"

const REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_RESIDUAL_COLUMNS = [
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
]

const REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_COLUMNS = [
    "window_id",
    "window_index",
    "phase",
    "phase_id",
    "ipopt_max_iter",
    "t0",
    "tfinal",
    "window_hours",
    "solver_status",
    "primal_status",
    "traffic_light",
    "viability_class",
    "trajectory_ready",
    "residual_feasible",
    "iteration_limit_residual_feasible",
    "residual_thresholds_satisfied",
    "residuals_pass",
    "state_drift_pass",
    "solve_elapsed_seconds",
    "max_residual_ratio",
    "dominant_residual",
    "termination_blocker",
    "likely_cause",
    "recommended_next_action",
    "blocking_reasons",
    "review_reasons",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
]

const REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_RESIDUAL_GATE_COLUMNS = [
    "window_id",
    "window_index",
    "phase",
    "phase_id",
    "residual_name",
    "value",
    "threshold",
    "ratio",
    "within_threshold",
    "is_dominant",
]

const REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_TRANSITION_COLUMNS = [
    "window_id",
    "window_index",
    "source_solver_status",
    "source_traffic_light",
    "source_trajectory_ready",
    "source_residual_feasible",
    "source_termination_blocker",
    "source_dominant_residual",
    "source_max_residual_ratio",
    "best_retry_case_id",
    "best_retry_ipopt_max_iter",
    "best_retry_solver_status",
    "best_retry_traffic_light",
    "best_retry_trajectory_ready",
    "best_retry_residual_feasible",
    "best_retry_termination_blocker",
    "best_retry_dominant_residual",
    "best_retry_max_residual_ratio",
    "recovered_trajectory_ready",
    "recovered_residual_feasible",
    "recovered_green",
    "residual_ratio_improved",
    "residual_ratio_delta",
    "recommended_next_action",
]

"""
    ReducedDCDFBAMPCCSolverTerminationDiagnosticResult

Diagnostic-only summary of reduced MPCC window solver termination. It separates
Ipopt termination/status gates from residual-gate failures and retry recovery.
It writes no outputs, changes no thresholds, and does not claim a solved
scientific trajectory.
"""
struct ReducedDCDFBAMPCCSolverTerminationDiagnosticResult
    termination_table::DataFrame
    residual_gate_table::DataFrame
    transition_table::DataFrame
    retry_aware_attempt::Union{Nothing, ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult}
    metadata::Dict{String, Any}
end

"""
    diagnose_reduced_dcdfba_mpcc_solver_termination(attempt)

Classify solver termination and residual gates for the window rows of a
reduced MPCC windowed attempt.
"""
function diagnose_reduced_dcdfba_mpcc_solver_termination(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
)::ReducedDCDFBAMPCCSolverTerminationDiagnosticResult
    thresholds = _reduced_mpcc_solver_termination_thresholds(attempt.viability_report)
    source_rows = _reduced_mpcc_solver_termination_source_rows(attempt, thresholds)
    table = _reduced_mpcc_solver_termination_table(source_rows)
    residual_table = _reduced_mpcc_solver_termination_residual_gate_table(
        source_rows,
        thresholds,
    )
    transition_table = _reduced_mpcc_solver_termination_transition_table(
        Dict{String, Any}[],
    )
    metadata = _reduced_mpcc_solver_termination_metadata(
        table,
        residual_table,
        transition_table;
        source_kind = "windowed_attempt",
        retry_aware_attempt = nothing,
    )
    return ReducedDCDFBAMPCCSolverTerminationDiagnosticResult(
        table,
        residual_table,
        transition_table,
        nothing,
        metadata,
    )
end

"""
    diagnose_reduced_dcdfba_mpcc_solver_termination(retry_policy)

Classify source-window solver termination and best-retry transitions for a
multi-window retry-policy diagnostic.
"""
function diagnose_reduced_dcdfba_mpcc_solver_termination(
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult,
)::ReducedDCDFBAMPCCSolverTerminationDiagnosticResult
    attempt = retry_policy.source_attempt
    thresholds = _reduced_mpcc_solver_termination_thresholds(attempt.viability_report)
    rows = _reduced_mpcc_solver_termination_source_rows(attempt, thresholds)
    append!(
        rows,
        _reduced_mpcc_solver_termination_best_retry_rows(retry_policy, thresholds),
    )
    table = _reduced_mpcc_solver_termination_table(rows)
    residual_table = _reduced_mpcc_solver_termination_residual_gate_table(rows, thresholds)
    transition_rows =
        _reduced_mpcc_solver_termination_transition_rows(retry_policy, table)
    transition_table =
        _reduced_mpcc_solver_termination_transition_table(transition_rows)
    metadata = _reduced_mpcc_solver_termination_metadata(
        table,
        residual_table,
        transition_table;
        source_kind = "windowed_retry_policy",
        retry_aware_attempt = nothing,
    )
    return ReducedDCDFBAMPCCSolverTerminationDiagnosticResult(
        table,
        residual_table,
        transition_table,
        nothing,
        metadata,
    )
end

"""
    diagnose_reduced_dcdfba_mpcc_solver_termination(retry_aware_attempt)

Classify source-window solver termination and best-retry transitions for a
retry-aware reduced MPCC windowed attempt.
"""
function diagnose_reduced_dcdfba_mpcc_solver_termination(
    retry_aware_attempt::ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult,
)::ReducedDCDFBAMPCCSolverTerminationDiagnosticResult
    diagnostic = diagnose_reduced_dcdfba_mpcc_solver_termination(
        retry_aware_attempt.retry_policy_diagnostic,
    )
    metadata = copy(diagnostic.metadata)
    metadata["source_kind"] = "retry_aware_windowed_attempt"
    metadata["retry_aware_attempt_traffic_light"] =
        get(retry_aware_attempt.metadata, "retry_aware_traffic_light", missing)
    metadata["retry_replacement_recommended"] =
        get(retry_aware_attempt.metadata, "retry_replacement_recommended", missing)
    metadata["retry_replacement_applied"] =
        get(retry_aware_attempt.metadata, "retry_replacement_applied", false)
    return ReducedDCDFBAMPCCSolverTerminationDiagnosticResult(
        diagnostic.termination_table,
        diagnostic.residual_gate_table,
        diagnostic.transition_table,
        retry_aware_attempt,
        metadata,
    )
end

function _reduced_mpcc_solver_termination_source_rows(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    thresholds::Dict{String, Float64},
)::Vector{Dict{String, Any}}
    table = attempt.viability_report.viability_table
    nrow(table) == 0 && return Dict{String, Any}[]
    rows = [
        row for row in eachrow(table) if
        String(get(row, "source_type", "")) == "windowed_continuation_window"
    ]
    isempty(rows) && (rows = collect(eachrow(table)))
    return [
        _reduced_mpcc_solver_termination_row(
            row,
            thresholds;
            phase = "source_window",
            attempt = attempt,
        ) for row in rows
    ]
end

function _reduced_mpcc_solver_termination_best_retry_rows(
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult,
    thresholds::Dict{String, Float64},
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    for retry in retry_policy.retry_results
        best = _reduced_mpcc_solver_termination_best_retry_row(retry)
        best === nothing && continue
        push!(
            rows,
            _reduced_mpcc_solver_termination_row(
                best,
                thresholds;
                phase = "best_retry",
                retry = retry,
            ),
        )
    end
    return rows
end

function _reduced_mpcc_solver_termination_row(
    row,
    thresholds::Dict{String, Float64};
    phase::AbstractString,
    attempt = nothing,
    retry = nothing,
)::Dict{String, Any}
    window_id = _reduced_mpcc_solver_termination_window_id(row, phase)
    window_index = _reduced_mpcc_solver_termination_window_index(row)
    phase_id = phase == "best_retry" ?
               _reduced_mpcc_solver_termination_value(row, "retry_case_id") :
               _reduced_mpcc_solver_termination_value(row, "candidate_id", window_id)
    bounds = _reduced_mpcc_solver_termination_bounds(
        attempt,
        retry,
        row,
        window_id,
        window_index,
    )
    ratios = _reduced_mpcc_solver_termination_residual_ratios(row, thresholds)
    dominant = _reduced_mpcc_solver_termination_dominant_residual(ratios)
    max_ratio = _reduced_mpcc_solver_termination_max_ratio(ratios)
    blocker = _reduced_mpcc_solver_termination_blocker(row, dominant)
    likely_cause =
        _reduced_mpcc_solver_termination_likely_cause(row, blocker, dominant)
    recommended =
        _reduced_mpcc_solver_termination_recommended_action(row, blocker, dominant)
    result = Dict{String, Any}(
        "window_id" => window_id,
        "window_index" => window_index,
        "phase" => String(phase),
        "phase_id" => phase_id,
        "ipopt_max_iter" => _reduced_mpcc_solver_termination_value(row, "ipopt_max_iter"),
        "t0" => bounds.t0,
        "tfinal" => bounds.tfinal,
        "window_hours" => bounds.window_hours,
        "solver_status" =>
            _reduced_mpcc_solver_termination_value(row, "solver_status"),
        "primal_status" =>
            _reduced_mpcc_solver_termination_value(row, "primal_status"),
        "traffic_light" =>
            _reduced_mpcc_solver_termination_value(row, "traffic_light"),
        "viability_class" =>
            _reduced_mpcc_solver_termination_value(row, "viability_class"),
        "trajectory_ready" =>
            _reduced_mpcc_solver_termination_bool(row, "trajectory_ready"),
        "residual_feasible" =>
            _reduced_mpcc_solver_termination_bool(row, "residual_feasible"),
        "iteration_limit_residual_feasible" =>
            _reduced_mpcc_solver_termination_bool(
                row,
                "iteration_limit_residual_feasible",
            ),
        "residual_thresholds_satisfied" =>
            _reduced_mpcc_solver_termination_thresholds_satisfied(row),
        "residuals_pass" =>
            _reduced_mpcc_solver_termination_bool(row, "residuals_pass"),
        "state_drift_pass" =>
            _reduced_mpcc_solver_termination_bool(row, "state_drift_pass"),
        "solve_elapsed_seconds" =>
            _reduced_mpcc_solver_termination_value(row, "solve_elapsed_seconds"),
        "max_residual_ratio" => max_ratio,
        "dominant_residual" => dominant,
        "termination_blocker" => blocker,
        "likely_cause" => likely_cause,
        "recommended_next_action" => recommended,
        "blocking_reasons" =>
            _reduced_mpcc_solver_termination_value(row, "blocking_reasons"),
        "review_reasons" =>
            _reduced_mpcc_solver_termination_value(row, "review_reasons"),
    )
    for column in REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_RESIDUAL_COLUMNS
        result[column] = _reduced_mpcc_solver_termination_value(row, column)
    end
    return result
end

function _reduced_mpcc_solver_termination_window_id(row, phase::AbstractString)
    if phase == "best_retry"
        return _reduced_mpcc_solver_termination_value(
            row,
            "source_window_id",
            missing,
        )
    end
    return _reduced_mpcc_solver_termination_value(row, "candidate_id", missing)
end

function _reduced_mpcc_solver_termination_window_index(row)
    value = _reduced_mpcc_solver_termination_value(row, "window_index", missing)
    value === missing &&
        (value = _reduced_mpcc_solver_termination_value(row, "source_window_index", missing))
    return value
end

function _reduced_mpcc_solver_termination_bounds(
    attempt,
    retry,
    row,
    window_id,
    window_index,
)
    t0 = _reduced_mpcc_solver_termination_first_present(
        _reduced_mpcc_solver_termination_value(row, "t0", missing),
        _reduced_mpcc_solver_termination_value(row, "source_window_t0", missing),
    )
    tfinal = _reduced_mpcc_solver_termination_first_present(
        _reduced_mpcc_solver_termination_value(row, "tfinal", missing),
        _reduced_mpcc_solver_termination_value(row, "source_window_tfinal", missing),
    )
    hours = _reduced_mpcc_solver_termination_first_present(
        _reduced_mpcc_solver_termination_value(row, "window_hours", missing),
        _reduced_mpcc_solver_termination_value(row, "source_window_hours", missing),
    )
    if retry !== nothing
        metadata = retry.metadata
        t0 = _reduced_mpcc_solver_termination_first_present(
            t0,
            get(metadata, "source_window_t0", missing),
        )
        tfinal = _reduced_mpcc_solver_termination_first_present(
            tfinal,
            get(metadata, "source_window_tfinal", missing),
        )
        hours = _reduced_mpcc_solver_termination_first_present(
            hours,
            get(metadata, "source_window_hours", missing),
        )
    end
    if attempt !== nothing && attempt.continuation_result.window_table isa DataFrame
        source = _reduced_mpcc_solver_termination_continuation_row(
            attempt.continuation_result.window_table,
            window_id,
            window_index,
        )
        if source !== nothing
            t0 = _reduced_mpcc_solver_termination_first_present(
                t0,
                get(source, "t0", missing),
            )
            tfinal = _reduced_mpcc_solver_termination_first_present(
                tfinal,
                get(source, "tfinal", missing),
            )
            hours = _reduced_mpcc_solver_termination_first_present(
                hours,
                get(source, "window_hours", missing),
            )
        end
    end
    return (t0 = t0, tfinal = tfinal, window_hours = hours)
end

function _reduced_mpcc_solver_termination_continuation_row(
    table::DataFrame,
    window_id,
    window_index,
)
    nrow(table) == 0 && return nothing
    if "window_id" in names(table) && window_id !== missing
        index = findfirst(==(String(window_id)), String.(table[!, "window_id"]))
        index === nothing || return table[index, :]
    end
    if "window_index" in names(table) && window_index !== missing
        index = findfirst(==(Int(window_index)), Int.(table[!, "window_index"]))
        index === nothing || return table[index, :]
    end
    return nothing
end

function _reduced_mpcc_solver_termination_best_retry_row(
    retry::ReducedDCDFBAMPCCWindowRetryDiagnosticResult,
)
    table = retry.retry_table
    nrow(table) == 0 && return nothing
    case_id = get(retry.metadata, "best_retry_case_id", missing)
    if case_id !== missing && "retry_case_id" in names(table)
        index = findfirst(==(String(case_id)), String.(table[!, "retry_case_id"]))
        index === nothing || return table[index, :]
    end
    order = sortperm([
        (
            _reduced_mpcc_solver_termination_light_order(get(row, "traffic_light", "")),
            _reduced_mpcc_solver_termination_float_or_inf(
                get(row, "max_mass_balance_ratio", missing),
            ),
            _reduced_mpcc_solver_termination_float_or_inf(
                get(row, "ipopt_max_iter", missing),
            ),
        ) for row in eachrow(table)
    ])
    isempty(order) && return nothing
    return table[first(order), :]
end

function _reduced_mpcc_solver_termination_residual_gate_table(
    rows::Vector{Dict{String, Any}},
    thresholds::Dict{String, Float64},
)::DataFrame
    gate_rows = Dict{String, Any}[]
    for row in rows
        dominant = get(row, "dominant_residual", "unavailable")
        for residual in REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_RESIDUAL_COLUMNS
            value = get(row, residual, missing)
            threshold = get(thresholds, residual, NaN)
            ratio = _reduced_mpcc_solver_termination_ratio(value, threshold)
            push!(
                gate_rows,
                Dict{String, Any}(
                    "window_id" => get(row, "window_id", missing),
                    "window_index" => get(row, "window_index", missing),
                    "phase" => get(row, "phase", missing),
                    "phase_id" => get(row, "phase_id", missing),
                    "residual_name" => residual,
                    "value" => value,
                    "threshold" => threshold,
                    "ratio" => ratio,
                    "within_threshold" =>
                        _reduced_mpcc_solver_termination_within_threshold(
                            value,
                            threshold,
                        ),
                    "is_dominant" => String(dominant) == residual,
                ),
            )
        end
    end
    return _reduced_mpcc_solver_termination_residual_gate_table_from_rows(gate_rows)
end

function _reduced_mpcc_solver_termination_transition_rows(
    retry_policy::ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult,
    termination_table::DataFrame,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    for retry in retry_policy.retry_results
        window_id = get(retry.metadata, "source_window_id", missing)
        source = _reduced_mpcc_solver_termination_table_row(
            termination_table,
            window_id,
            "source_window",
        )
        best = _reduced_mpcc_solver_termination_table_row(
            termination_table,
            window_id,
            "best_retry",
        )
        source === nothing && best === nothing && continue
        push!(
            rows,
            _reduced_mpcc_solver_termination_transition_row(
                source,
                best,
                retry,
            ),
        )
    end
    return rows
end

function _reduced_mpcc_solver_termination_transition_row(source, best, retry)
    source_ratio = _reduced_mpcc_solver_termination_table_value(
        source,
        "max_residual_ratio",
    )
    best_ratio = _reduced_mpcc_solver_termination_table_value(
        best,
        "max_residual_ratio",
    )
    delta = _reduced_mpcc_solver_termination_ratio_delta(source_ratio, best_ratio)
    recovered_trajectory =
        _reduced_mpcc_solver_termination_table_value(source, "trajectory_ready") !== true &&
        _reduced_mpcc_solver_termination_table_value(best, "trajectory_ready") === true
    recovered_residual =
        _reduced_mpcc_solver_termination_table_value(source, "residual_feasible") !== true &&
        _reduced_mpcc_solver_termination_table_value(best, "residual_feasible") === true
    recovered_green =
        String(_reduced_mpcc_solver_termination_table_value(source, "traffic_light")) != "green" &&
        String(_reduced_mpcc_solver_termination_table_value(best, "traffic_light")) == "green"
    return Dict{String, Any}(
        "window_id" =>
            _reduced_mpcc_solver_termination_first_present(
                _reduced_mpcc_solver_termination_table_value(source, "window_id"),
                _reduced_mpcc_solver_termination_table_value(best, "window_id"),
            ),
        "window_index" =>
            _reduced_mpcc_solver_termination_first_present(
                _reduced_mpcc_solver_termination_table_value(source, "window_index"),
                _reduced_mpcc_solver_termination_table_value(best, "window_index"),
            ),
        "source_solver_status" =>
            _reduced_mpcc_solver_termination_table_value(source, "solver_status"),
        "source_traffic_light" =>
            _reduced_mpcc_solver_termination_table_value(source, "traffic_light"),
        "source_trajectory_ready" =>
            _reduced_mpcc_solver_termination_table_value(source, "trajectory_ready"),
        "source_residual_feasible" =>
            _reduced_mpcc_solver_termination_table_value(source, "residual_feasible"),
        "source_termination_blocker" =>
            _reduced_mpcc_solver_termination_table_value(source, "termination_blocker"),
        "source_dominant_residual" =>
            _reduced_mpcc_solver_termination_table_value(source, "dominant_residual"),
        "source_max_residual_ratio" => source_ratio,
        "best_retry_case_id" => get(retry.metadata, "best_retry_case_id", missing),
        "best_retry_ipopt_max_iter" =>
            _reduced_mpcc_solver_termination_table_value(best, "ipopt_max_iter"),
        "best_retry_solver_status" =>
            _reduced_mpcc_solver_termination_table_value(best, "solver_status"),
        "best_retry_traffic_light" =>
            _reduced_mpcc_solver_termination_table_value(best, "traffic_light"),
        "best_retry_trajectory_ready" =>
            _reduced_mpcc_solver_termination_table_value(best, "trajectory_ready"),
        "best_retry_residual_feasible" =>
            _reduced_mpcc_solver_termination_table_value(best, "residual_feasible"),
        "best_retry_termination_blocker" =>
            _reduced_mpcc_solver_termination_table_value(best, "termination_blocker"),
        "best_retry_dominant_residual" =>
            _reduced_mpcc_solver_termination_table_value(best, "dominant_residual"),
        "best_retry_max_residual_ratio" => best_ratio,
        "recovered_trajectory_ready" => recovered_trajectory,
        "recovered_residual_feasible" => recovered_residual,
        "recovered_green" => recovered_green,
        "residual_ratio_improved" =>
            _reduced_mpcc_solver_termination_ratio_improved(source_ratio, best_ratio),
        "residual_ratio_delta" => delta,
        "recommended_next_action" =>
            _reduced_mpcc_solver_termination_transition_action(
                recovered_green,
                recovered_trajectory,
                recovered_residual,
                source,
                best,
            ),
    )
end

function _reduced_mpcc_solver_termination_metadata(
    table::DataFrame,
    residual_table::DataFrame,
    transition_table::DataFrame;
    source_kind::AbstractString,
    retry_aware_attempt,
)::Dict{String, Any}
    source_rows = [
        row for row in eachrow(table) if
        String(get(row, "phase", "")) == "source_window"
    ]
    retry_rows = [
        row for row in eachrow(table) if
        String(get(row, "phase", "")) == "best_retry"
    ]
    blocked_sources = [
        row for row in source_rows if
        get(row, "trajectory_ready", false) !== true
    ]
    dominant_blocker =
        _reduced_mpcc_solver_termination_dominant_blocker(blocked_sources)
    first_blocked =
        isempty(blocked_sources) ? nothing :
        blocked_sources[first(sortperm([
            _reduced_mpcc_solver_termination_float_or_inf(get(row, "window_index", Inf)) for
            row in blocked_sources
        ]))]
    return Dict{String, Any}(
        "diagnostic_type" =>
            REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_DIAGNOSTIC_TYPE,
        "source_kind" => String(source_kind),
        "n_windows_analyzed" => length(source_rows),
        "n_retry_rows_analyzed" => length(retry_rows),
        "n_transition_rows" => nrow(transition_table),
        "iteration_limit_count" =>
            count(row -> String(get(row, "solver_status", "")) == "ITERATION_LIMIT", source_rows),
        "iteration_limit_residual_feasible_count" =>
            count(row -> get(row, "iteration_limit_residual_feasible", false) === true, source_rows),
        "trajectory_ready_count" =>
            count(row -> get(row, "trajectory_ready", false) === true, source_rows),
        "residual_feasible_count" =>
            count(row -> get(row, "residual_feasible", false) === true, source_rows),
        "residual_threshold_failure_count" =>
            count(
                row -> String(get(row, "termination_blocker", "")) ==
                       "residual_thresholds_failed",
                source_rows,
            ),
        "dominant_termination_blocker" => dominant_blocker,
        "first_blocked_window_id" =>
            first_blocked === nothing ? missing : get(first_blocked, "window_id", missing),
        "first_blocked_window_index" =>
            first_blocked === nothing ? missing : get(first_blocked, "window_index", missing),
        "max_residual_ratio" =>
            _reduced_mpcc_solver_termination_table_max(table, "max_residual_ratio"),
        "dominant_residual" =>
            _reduced_mpcc_solver_termination_global_dominant_residual(residual_table),
        "retry_recovered_trajectory_ready_count" =>
            nrow(transition_table) == 0 ? 0 :
            count(value -> value === true, transition_table[!, "recovered_trajectory_ready"]),
        "retry_recovered_residual_feasible_count" =>
            nrow(transition_table) == 0 ? 0 :
            count(value -> value === true, transition_table[!, "recovered_residual_feasible"]),
        "retry_recovered_green_count" =>
            nrow(transition_table) == 0 ? 0 :
            count(value -> value === true, transition_table[!, "recovered_green"]),
        "recommended_next_action" =>
            _reduced_mpcc_solver_termination_metadata_action(
                source_rows,
                transition_table,
            ),
        "outputs_written" => false,
        "solver_termination_diagnostic_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "retry_aware_attempt_attached" => retry_aware_attempt !== nothing,
        "interpretation_note" =>
            "Reduced MPCC solver-termination diagnostics; diagnostic only and not a validated simulation.",
    )
end

function _reduced_mpcc_solver_termination_thresholds(
    report::ReducedDCDFBAMPCCSimulationViabilityReport,
)::Dict{String, Float64}
    thresholds = report.thresholds
    return Dict{String, Float64}(
        "max_rhs_residual" => thresholds.max_rhs_residual,
        "max_mass_balance_residual" => thresholds.max_mass_balance_residual,
        "max_lower_bound_violation" => thresholds.max_lower_bound_violation,
        "max_upper_bound_violation" => thresholds.max_upper_bound_violation,
        "max_stationarity_residual" => thresholds.max_stationarity_residual,
        "max_lower_complementarity_residual" =>
            thresholds.max_lower_complementarity_residual,
        "max_upper_complementarity_residual" =>
            thresholds.max_upper_complementarity_residual,
    )
end

function _reduced_mpcc_solver_termination_blocker(row, dominant)::String
    _reduced_mpcc_solver_termination_bool(row, "trajectory_ready") &&
        return "trajectory_ready"
    _reduced_mpcc_solver_termination_bool(row, "iteration_limit_residual_feasible") &&
        return "iteration_limit_residual_feasible_status_gate"
    residuals_pass = _reduced_mpcc_solver_termination_thresholds_satisfied(row)
    residuals_pass === false && return "residual_thresholds_failed"
    solver_status = String(_reduced_mpcc_solver_termination_value(row, "solver_status", ""))
    residual_feasible =
        _reduced_mpcc_solver_termination_bool(row, "residual_feasible")
    if solver_status == "ITERATION_LIMIT" && residual_feasible
        return "iteration_limit_residual_feasible_status_gate"
    elseif solver_status == "ITERATION_LIMIT"
        return "iteration_limit_with_residual_infeasible_candidate"
    elseif residual_feasible
        return "residual_feasible_but_not_trajectory_ready"
    elseif solver_status == "" || solver_status == "missing"
        return "failed_or_missing"
    else
        return "candidate_not_residual_feasible"
    end
end

function _reduced_mpcc_solver_termination_likely_cause(
    row,
    blocker::AbstractString,
    dominant,
)::String
    blocker == "trajectory_ready" && return "none_candidate_ready"
    blocker == "iteration_limit_residual_feasible_status_gate" &&
        return "solver_iteration_limit_status_gate"
    blocker == "residual_thresholds_failed" &&
        return "residual_threshold_exceeded:" * String(dominant)
    blocker == "iteration_limit_with_residual_infeasible_candidate" &&
        return "iteration_limit_and_residual_infeasibility"
    blocker == "residual_feasible_but_not_trajectory_ready" &&
        return "solver_status_blocks_trajectory:" *
               String(_reduced_mpcc_solver_termination_value(row, "solver_status", ""))
    blocker == "failed_or_missing" && return "failed_or_missing_candidate"
    return "inspect_solver_status_and_candidate_residuals"
end

function _reduced_mpcc_solver_termination_recommended_action(
    row,
    blocker::AbstractString,
    dominant,
)::String
    blocker == "trajectory_ready" &&
        return "review_ready_candidate_before_scientific_use"
    blocker == "iteration_limit_residual_feasible_status_gate" &&
        return "inspect_solver_termination_policy_or_scaling"
    blocker == "residual_thresholds_failed" &&
        return "repair_dominant_residual_before_solver_policy_change"
    blocker == "iteration_limit_with_residual_infeasible_candidate" &&
        return "repair_residual_feasibility_before_more_solver_budget"
    blocker == "residual_feasible_but_not_trajectory_ready" &&
        return "inspect_solver_status_gate_before_trajectory_extraction"
    blocker == "failed_or_missing" && return "inspect_failed_solver_row"
    return String(
        _reduced_mpcc_solver_termination_value(
            row,
            "next_recommended_action",
            "inspect_solver_status_and_candidate_residuals",
        ),
    )
end

function _reduced_mpcc_solver_termination_transition_action(
    recovered_green::Bool,
    recovered_trajectory::Bool,
    recovered_residual::Bool,
    source,
    best,
)::String
    recovered_green && return "review_green_retry_before_window_replacement"
    recovered_trajectory &&
        return "review_trajectory_ready_retry_before_window_replacement"
    recovered_residual && return "review_residual_feasible_retry_before_more_budget"
    source_blocker =
        String(_reduced_mpcc_solver_termination_table_value(source, "termination_blocker"))
    best_blocker =
        String(_reduced_mpcc_solver_termination_table_value(best, "termination_blocker"))
    source_blocker == "iteration_limit_residual_feasible_status_gate" &&
        best_blocker == "iteration_limit_residual_feasible_status_gate" &&
        return "inspect_solver_termination_policy_or_scaling"
    return "inspect_retry_residuals_before_more_budget"
end

function _reduced_mpcc_solver_termination_metadata_action(
    source_rows,
    transition_table::DataFrame,
)::String
    isempty(source_rows) && return "run_windowed_attempt_before_termination_diagnostics"
    all(row -> get(row, "trajectory_ready", false) === true, source_rows) &&
        return "review_ready_window_candidates_before_scientific_use"
    if any(
        row -> String(get(row, "termination_blocker", "")) == "residual_thresholds_failed",
        source_rows,
    )
        return "repair_dominant_residual_before_solver_policy_change"
    end
    if nrow(transition_table) > 0 &&
       any(value -> value === true, transition_table[!, "recovered_trajectory_ready"])
        return "review_retry_recovery_before_window_replacement"
    end
    if any(
        row -> String(get(row, "termination_blocker", "")) ==
               "iteration_limit_residual_feasible_status_gate",
        source_rows,
    )
        return "inspect_solver_termination_policy_or_scaling"
    end
    return "inspect_solver_status_and_candidate_residuals"
end

function _reduced_mpcc_solver_termination_thresholds_satisfied(row)
    if _reduced_mpcc_solver_termination_has(row, "residual_thresholds_satisfied")
        return _reduced_mpcc_solver_termination_bool(row, "residual_thresholds_satisfied")
    end
    if _reduced_mpcc_solver_termination_has(row, "residuals_pass")
        return _reduced_mpcc_solver_termination_bool(row, "residuals_pass")
    end
    return missing
end

function _reduced_mpcc_solver_termination_residual_ratios(
    row,
    thresholds::Dict{String, Float64},
)::Dict{String, Any}
    return Dict{String, Any}(
        column => _reduced_mpcc_solver_termination_ratio(
            _reduced_mpcc_solver_termination_value(row, column),
            get(thresholds, column, NaN),
        ) for column in REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_RESIDUAL_COLUMNS
    )
end

function _reduced_mpcc_solver_termination_dominant_residual(
    ratios::Dict{String, Any},
)::String
    finite = [
        (key, Float64(value)) for (key, value) in ratios if
        _reduced_mpcc_solver_termination_isfinite_number(value)
    ]
    isempty(finite) && return "unavailable"
    order = sortperm([(-value, key) for (key, value) in finite])
    return finite[first(order)][1]
end

function _reduced_mpcc_solver_termination_max_ratio(ratios::Dict{String, Any})
    finite_values = Float64[
        Float64(value) for value in Base.values(ratios) if
        _reduced_mpcc_solver_termination_isfinite_number(value)
    ]
    isempty(finite_values) && return missing
    return maximum(finite_values)
end

function _reduced_mpcc_solver_termination_ratio(value, threshold)
    _reduced_mpcc_solver_termination_isfinite_number(value) || return missing
    _reduced_mpcc_solver_termination_isfinite_number(threshold) || return missing
    threshold_value = Float64(threshold)
    if threshold_value == 0.0
        return Float64(value) == 0.0 ? 0.0 : Inf
    end
    threshold_value > 0.0 || return missing
    return abs(Float64(value)) / threshold_value
end

function _reduced_mpcc_solver_termination_within_threshold(value, threshold)
    _reduced_mpcc_solver_termination_isfinite_number(value) || return false
    _reduced_mpcc_solver_termination_isfinite_number(threshold) || return false
    return abs(Float64(value)) <= Float64(threshold)
end

function _reduced_mpcc_solver_termination_dominant_blocker(rows)::String
    isempty(rows) && return "none"
    counts = Dict{String, Int}()
    for row in rows
        key = String(get(row, "termination_blocker", "unknown"))
        counts[key] = get(counts, key, 0) + 1
    end
    ordered = sort(collect(counts); by = pair -> (-pair.second, pair.first))
    return first(ordered).first
end

function _reduced_mpcc_solver_termination_global_dominant_residual(table::DataFrame)
    nrow(table) == 0 && return "unavailable"
    finite = [
        (row["residual_name"], Float64(row["ratio"])) for row in eachrow(table) if
        _reduced_mpcc_solver_termination_isfinite_number(row["ratio"])
    ]
    isempty(finite) && return "unavailable"
    order = sortperm([(-value, String(name)) for (name, value) in finite])
    return String(finite[first(order)][1])
end

function _reduced_mpcc_solver_termination_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_solver_termination_scalar(get(row, column, missing)) for
                row in rows
            ] for column in REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_COLUMNS
        )...,
    )
end

function _reduced_mpcc_solver_termination_residual_gate_table_from_rows(
    rows::Vector{Dict{String, Any}},
)::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_solver_termination_scalar(get(row, column, missing)) for
                row in rows
            ] for column in REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_RESIDUAL_GATE_COLUMNS
        )...,
    )
end

function _reduced_mpcc_solver_termination_transition_table(
    rows::Vector{Dict{String, Any}},
)::DataFrame
    return DataFrame(
        (
            column => [
                _reduced_mpcc_solver_termination_scalar(get(row, column, missing)) for
                row in rows
            ] for column in REDUCED_DCDFBA_MPCC_SOLVER_TERMINATION_TRANSITION_COLUMNS
        )...,
    )
end

function _reduced_mpcc_solver_termination_table_row(
    table::DataFrame,
    window_id,
    phase::AbstractString,
)
    nrow(table) == 0 && return nothing
    index = findfirst(
        row -> String(get(row, "window_id", "")) == String(window_id) &&
               String(get(row, "phase", "")) == String(phase),
        eachrow(table),
    )
    return index === nothing ? nothing : table[index, :]
end

function _reduced_mpcc_solver_termination_table_value(row, column::AbstractString)
    row === nothing && return missing
    return get(row, String(column), missing)
end

function _reduced_mpcc_solver_termination_table_max(table::DataFrame, column::AbstractString)
    String(column) in names(table) || return missing
    finite_values = Float64[
        Float64(value) for value in table[!, String(column)] if
        _reduced_mpcc_solver_termination_isfinite_number(value)
    ]
    isempty(finite_values) && return missing
    return maximum(finite_values)
end

function _reduced_mpcc_solver_termination_ratio_delta(source_ratio, best_ratio)
    _reduced_mpcc_solver_termination_isfinite_number(source_ratio) || return missing
    _reduced_mpcc_solver_termination_isfinite_number(best_ratio) || return missing
    return Float64(source_ratio) - Float64(best_ratio)
end

function _reduced_mpcc_solver_termination_ratio_improved(source_ratio, best_ratio)::Bool
    _reduced_mpcc_solver_termination_isfinite_number(source_ratio) || return false
    _reduced_mpcc_solver_termination_isfinite_number(best_ratio) || return false
    return Float64(best_ratio) < Float64(source_ratio)
end

function _reduced_mpcc_solver_termination_light_order(value)::Int
    label = lowercase(String(value))
    label == "green" && return 1
    label == "yellow" && return 2
    label == "red" && return 3
    return 4
end

function _reduced_mpcc_solver_termination_value(row, column::AbstractString, default = missing)
    return get(row, String(column), default)
end

function _reduced_mpcc_solver_termination_has(row, column::AbstractString)::Bool
    key = String(column)
    try
        key in names(row) && return true
    catch
    end
    try
        haskey(row, key) && return true
    catch
    end
    try
        haskey(row, Symbol(key)) && return true
    catch
    end
    return false
end

function _reduced_mpcc_solver_termination_bool(row, column::AbstractString)::Bool
    return _reduced_mpcc_solver_termination_value(row, column, false) === true
end

function _reduced_mpcc_solver_termination_first_present(values...)
    for value in values
        (value === missing || value === nothing) && continue
        return value
    end
    return missing
end

function _reduced_mpcc_solver_termination_float_or_inf(value)
    _reduced_mpcc_solver_termination_isfinite_number(value) || return Inf
    return Float64(value)
end

function _reduced_mpcc_solver_termination_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_solver_termination_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
