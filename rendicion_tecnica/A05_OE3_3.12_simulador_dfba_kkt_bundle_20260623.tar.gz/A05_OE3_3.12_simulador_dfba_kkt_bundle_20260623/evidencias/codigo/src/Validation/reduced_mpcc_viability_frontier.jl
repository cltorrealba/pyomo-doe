import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_SIMULATION_VIABILITY_FRONTIER_TYPE =
    "reduced_dcdfba_mpcc_simulation_viability_frontier"

const REDUCED_DCDFBA_MPCC_SIMULATION_VIABILITY_FRONTIER_COLUMNS = [
    "frontier_case_id",
    "source_candidate_id",
    "frontier_index",
    "case_status",
    "horizon",
    "nfe",
    "degree",
    "boundary_dt",
    "n_collocation_points",
    "traffic_light",
    "viability_class",
    "simulation_viable",
    "trajectory_ready",
    "residual_feasible",
    "iteration_limit_residual_feasible",
    "residuals_pass",
    "state_drift_pass",
    "guardrails_pass",
    "is_last_green",
    "is_first_non_green_after_green",
    "solver_status",
    "primal_status",
    "solve_elapsed_seconds",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_state_abs_difference",
    "max_state_relative_rmse",
    "final_biomass_difference",
    "final_total_sugar_difference",
    "blocking_reasons",
    "review_reasons",
    "next_recommended_action",
    "full_dfba_cold_reference_deferred",
    "reduced_full_equivalence_claimed",
    "persistent_lp_baseline_used",
    "hsl_required",
    "ma57_required",
    "indices_reacciones_used",
    "r0001_used_as_oxygen",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCSimulationViabilityFrontierResult

Ordered diagnostic frontier over monolithic reduced MPCC solve-attempt cases.
Each case is classified by the simulation-viability semaphore. The frontier
summarizes the last green case and the first non-green case that blocks further
horizon escalation. It writes no outputs and makes no scientific simulation
claim.
"""
struct ReducedDCDFBAMPCCSimulationViabilityFrontierResult
    frontier_table::DataFrame
    sweep_results::Vector{ReducedDCDFBAMPCCSolveAttemptSweepResult}
    viability_reports::Vector{ReducedDCDFBAMPCCSimulationViabilityReport}
    metadata::Dict{String, Any}
end

"""
    sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(report)

Aggregate an existing simulation-viability report as an ordered frontier. Rows
are ordered by horizon, then finite-element count, then candidate id.
"""
function sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(
    report::ReducedDCDFBAMPCCSimulationViabilityReport,
)::ReducedDCDFBAMPCCSimulationViabilityFrontierResult
    return sweep_reduced_dcdfba_mpcc_simulation_viability_frontier([report])
end

"""
    sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(reports)

Aggregate existing simulation-viability reports into a single ordered frontier.
"""
function sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(
    reports::AbstractVector{<:ReducedDCDFBAMPCCSimulationViabilityReport},
)::ReducedDCDFBAMPCCSimulationViabilityFrontierResult
    isempty(reports) && throw(
        ArgumentError("Reduced MPCC viability frontier requires at least one viability report."),
    )
    rows = Dict{String, Any}[]
    for report in reports
        for row in eachrow(report.viability_table)
            push!(rows, _reduced_mpcc_frontier_row_from_viability(row, length(rows) + 1))
        end
    end
    _reduced_mpcc_frontier_sort_rows!(rows)
    _reduced_mpcc_frontier_reindex!(rows)
    _reduced_mpcc_frontier_mark_boundary!(rows)
    table = _reduced_mpcc_frontier_table(rows)
    metadata = _reduced_mpcc_frontier_metadata(
        rows,
        ReducedDCDFBAMPCCSolveAttemptSweepResult[],
        collect(reports);
        stopped_after_first_non_green = false,
    )
    return ReducedDCDFBAMPCCSimulationViabilityFrontierResult(
        table,
        ReducedDCDFBAMPCCSolveAttemptSweepResult[],
        collect(reports),
        metadata,
    )
end

"""
    sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(model, reaction_map; horizons, kwargs...)

Run an ordered monolithic reduced MPCC frontier sweep. For each horizon, the
finite-element count is either supplied explicitly through `nfe_values` or
derived from `boundary_dt`. Each case is run as a one-scenario solve-attempt
sweep, classified by the semaphore, and summarized as green/yellow/red.
"""
function sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(
    model::MetabolicModel,
    reaction_map::ReactionMap;
    horizons = [0.5],
    boundary_dt::Real = 0.25,
    nfe_values = nothing,
    t0::Real = 0.0,
    degree::Int = 3,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    ipopt_max_iter::Union{Nothing, Int} =
        REDUCED_DCDFBA_MPCC_SOLVE_ATTEMPT_DEFAULT_MAX_ITER,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(),
    silent::Bool = true,
    continue_on_error::Bool = true,
    stop_after_first_non_green::Bool = false,
)::ReducedDCDFBAMPCCSimulationViabilityFrontierResult
    specs = _reduced_mpcc_frontier_specs(t0, horizons, boundary_dt, nfe_values, degree)
    rows = Dict{String, Any}[]
    sweeps = ReducedDCDFBAMPCCSolveAttemptSweepResult[]
    reports = ReducedDCDFBAMPCCSimulationViabilityReport[]
    stopped = false

    for spec in specs
        try
            sweep = sweep_reduced_dcdfba_mpcc_solve_attempts(
                model,
                reaction_map;
                horizons = [spec.horizon],
                nfe_values = [spec.nfe],
                t0 = spec.t0,
                degree = spec.degree,
                y0 = y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = ipopt_max_iter,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                silent = silent,
                continue_on_error = false,
            )
            report = assess_reduced_dcdfba_mpcc_simulation_viability(
                sweep;
                thresholds = viability_thresholds,
            )
            push!(sweeps, sweep)
            push!(reports, report)
            row = _reduced_mpcc_frontier_row_from_viability(
                report.viability_table[1, :],
                spec.frontier_index,
            )
            row["frontier_case_id"] = spec.frontier_case_id
            row["frontier_index"] = spec.frontier_index
            push!(rows, row)
            if stop_after_first_non_green && row["traffic_light"] != "green"
                stopped = true
                break
            end
        catch err
            continue_on_error || rethrow()
            push!(rows, _reduced_mpcc_frontier_error_row(spec, err))
            stopped = true
            break
        end
    end

    _reduced_mpcc_frontier_mark_boundary!(rows)
    table = _reduced_mpcc_frontier_table(rows)
    metadata = _reduced_mpcc_frontier_metadata(
        rows,
        sweeps,
        reports;
        stopped_after_first_non_green = stopped,
        requested_case_count = length(specs),
        ipopt_max_iter = ipopt_max_iter,
    )
    return ReducedDCDFBAMPCCSimulationViabilityFrontierResult(
        table,
        sweeps,
        reports,
        metadata,
    )
end

function _reduced_mpcc_frontier_specs(
    t0::Real,
    horizons,
    boundary_dt::Real,
    nfe_values,
    degree::Int,
)::Vector{NamedTuple}
    initial_time = Float64(t0)
    isfinite(initial_time) || throw(
        ArgumentError("Reduced MPCC viability frontier t0 must be finite."),
    )
    degree == 3 || throw(
        ArgumentError("Reduced MPCC viability frontier currently supports only degree == 3."),
    )
    dt = Float64(boundary_dt)
    isfinite(dt) && dt > 0.0 || throw(
        ArgumentError("Reduced MPCC viability frontier boundary_dt must be finite and positive."),
    )
    horizon_values = Float64.(collect(horizons))
    isempty(horizon_values) && throw(
        ArgumentError("Reduced MPCC viability frontier horizons must not be empty."),
    )
    all(value -> isfinite(value) && value > 0.0, horizon_values) || throw(
        ArgumentError("Reduced MPCC viability frontier horizons must be finite and positive."),
    )
    issorted(horizon_values) || throw(
        ArgumentError("Reduced MPCC viability frontier horizons must be sorted in ascending order."),
    )
    nfe_collection = if nfe_values === nothing
        [_reduced_mpcc_frontier_nfe_from_dt(horizon, dt) for horizon in horizon_values]
    else
        values = Int.(collect(nfe_values))
        length(values) == length(horizon_values) || throw(
            ArgumentError(
                "Reduced MPCC viability frontier nfe_values must have the same length as horizons.",
            ),
        )
        values
    end
    all(value -> value > 0, nfe_collection) || throw(
        ArgumentError("Reduced MPCC viability frontier nfe values must be positive."),
    )

    specs = NamedTuple[]
    for (index, (horizon, nfe)) in enumerate(zip(horizon_values, nfe_collection))
        push!(
            specs,
            (
                frontier_case_id = _reduced_mpcc_frontier_case_id(index),
                frontier_index = index,
                t0 = initial_time,
                tfinal = initial_time + horizon,
                horizon = horizon,
                nfe = nfe,
                degree = degree,
                boundary_dt = horizon / nfe,
            ),
        )
    end
    return specs
end

function _reduced_mpcc_frontier_nfe_from_dt(horizon::Float64, boundary_dt::Float64)::Int
    raw = horizon / boundary_dt
    nfe = round(Int, raw)
    isapprox(raw, nfe; atol = 1.0e-10, rtol = 1.0e-10) || throw(
        ArgumentError(
            "Reduced MPCC viability frontier horizon $(horizon) is not an integer multiple " *
            "of boundary_dt $(boundary_dt). Provide explicit nfe_values for nonuniform cases.",
        ),
    )
    nfe > 0 || throw(ArgumentError("Reduced MPCC viability frontier computed nfe must be positive."))
    return nfe
end

function _reduced_mpcc_frontier_row_from_viability(row, index::Int)::Dict{String, Any}
    horizon = get(row, "horizon", missing)
    nfe = get(row, "nfe", missing)
    degree = get(row, "degree", missing)
    return Dict{String, Any}(
        "frontier_case_id" => _reduced_mpcc_frontier_case_id(index),
        "source_candidate_id" => get(row, "candidate_id", missing),
        "frontier_index" => index,
        "case_status" => get(row, "source_row_status", missing),
        "horizon" => horizon,
        "nfe" => nfe,
        "degree" => degree,
        "boundary_dt" =>
            get(row, "boundary_dt", _reduced_mpcc_frontier_boundary_dt(horizon, nfe)),
        "n_collocation_points" =>
            _reduced_mpcc_frontier_collocation_points(nfe, degree),
        "traffic_light" => get(row, "traffic_light", missing),
        "viability_class" => get(row, "viability_class", missing),
        "simulation_viable" => get(row, "simulation_viable", false),
        "trajectory_ready" => get(row, "trajectory_ready", false),
        "residual_feasible" => get(row, "residual_feasible", false),
        "iteration_limit_residual_feasible" =>
            get(row, "iteration_limit_residual_feasible", false),
        "residuals_pass" => get(row, "residuals_pass", false),
        "state_drift_pass" => get(row, "state_drift_pass", false),
        "guardrails_pass" => get(row, "guardrails_pass", false),
        "is_last_green" => false,
        "is_first_non_green_after_green" => false,
        "solver_status" => get(row, "solver_status", missing),
        "primal_status" => get(row, "primal_status", missing),
        "solve_elapsed_seconds" => get(row, "solve_elapsed_seconds", missing),
        "max_rhs_residual" => get(row, "max_rhs_residual", missing),
        "max_mass_balance_residual" => get(row, "max_mass_balance_residual", missing),
        "max_lower_bound_violation" => get(row, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" => get(row, "max_upper_bound_violation", missing),
        "max_stationarity_residual" => get(row, "max_stationarity_residual", missing),
        "max_lower_complementarity_residual" =>
            get(row, "max_lower_complementarity_residual", missing),
        "max_upper_complementarity_residual" =>
            get(row, "max_upper_complementarity_residual", missing),
        "max_state_abs_difference" => get(row, "max_state_abs_difference", missing),
        "max_state_relative_rmse" => get(row, "max_state_relative_rmse", missing),
        "final_biomass_difference" => get(row, "final_biomass_difference", missing),
        "final_total_sugar_difference" => get(row, "final_total_sugar_difference", missing),
        "blocking_reasons" => get(row, "blocking_reasons", missing),
        "review_reasons" => get(row, "review_reasons", missing),
        "next_recommended_action" => get(row, "next_recommended_action", missing),
        "full_dfba_cold_reference_deferred" =>
            get(row, "full_dfba_cold_reference_deferred", true),
        "reduced_full_equivalence_claimed" =>
            get(row, "reduced_full_equivalence_claimed", false),
        "persistent_lp_baseline_used" => get(row, "persistent_lp_baseline_used", false),
        "hsl_required" => get(row, "hsl_required", false),
        "ma57_required" => get(row, "ma57_required", false),
        "indices_reacciones_used" => get(row, "indices_reacciones_used", false),
        "r0001_used_as_oxygen" => get(row, "r0001_used_as_oxygen", false),
        "error_type" => get(row, "error_type", missing),
        "error_message" => get(row, "error_message", missing),
    )
end

function _reduced_mpcc_frontier_error_row(spec, err)::Dict{String, Any}
    row = Dict{String, Any}(
        column => missing for column in REDUCED_DCDFBA_MPCC_SIMULATION_VIABILITY_FRONTIER_COLUMNS
    )
    row["frontier_case_id"] = spec.frontier_case_id
    row["source_candidate_id"] = missing
    row["frontier_index"] = spec.frontier_index
    row["case_status"] = "failed"
    row["horizon"] = spec.horizon
    row["nfe"] = spec.nfe
    row["degree"] = spec.degree
    row["boundary_dt"] = spec.boundary_dt
    row["n_collocation_points"] = spec.nfe * spec.degree
    row["traffic_light"] = "red"
    row["viability_class"] = "failed_diagnostic_row"
    row["simulation_viable"] = false
    row["trajectory_ready"] = false
    row["residual_feasible"] = false
    row["iteration_limit_residual_feasible"] = false
    row["residuals_pass"] = false
    row["state_drift_pass"] = false
    row["guardrails_pass"] = true
    row["is_last_green"] = false
    row["is_first_non_green_after_green"] = false
    row["blocking_reasons"] = "source_row_not_completed"
    row["review_reasons"] = "inspect_failed_diagnostics_before_simulation"
    row["next_recommended_action"] = "inspect_failed_diagnostics_before_simulation"
    row["full_dfba_cold_reference_deferred"] = true
    row["reduced_full_equivalence_claimed"] = false
    row["persistent_lp_baseline_used"] = false
    row["hsl_required"] = false
    row["ma57_required"] = false
    row["indices_reacciones_used"] = false
    row["r0001_used_as_oxygen"] = false
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_frontier_mark_boundary!(rows::Vector{Dict{String, Any}})
    for row in rows
        row["is_last_green"] = false
        row["is_first_non_green_after_green"] = false
    end
    last_green_index = findlast(row -> get(row, "traffic_light", missing) == "green", rows)
    last_green_index !== nothing && (rows[last_green_index]["is_last_green"] = true)
    if last_green_index !== nothing && last_green_index < length(rows)
        for index in (last_green_index + 1):length(rows)
            if get(rows[index], "traffic_light", missing) != "green"
                rows[index]["is_first_non_green_after_green"] = true
                break
            end
        end
    elseif last_green_index === nothing && !isempty(rows)
        rows[firstindex(rows)]["is_first_non_green_after_green"] =
            get(rows[firstindex(rows)], "traffic_light", missing) != "green"
    end
    return rows
end

function _reduced_mpcc_frontier_sort_rows!(rows::Vector{Dict{String, Any}})
    sort!(
        rows;
        by = row -> (
            _reduced_mpcc_frontier_float_or_inf(get(row, "horizon", missing)),
            _reduced_mpcc_frontier_float_or_inf(get(row, "nfe", missing)),
            string(get(row, "source_candidate_id", "")),
        ),
    )
    return rows
end

function _reduced_mpcc_frontier_reindex!(rows::Vector{Dict{String, Any}})
    for (index, row) in enumerate(rows)
        row["frontier_index"] = index
        row["frontier_case_id"] = _reduced_mpcc_frontier_case_id(index)
    end
    return rows
end

function _reduced_mpcc_frontier_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_frontier_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_SIMULATION_VIABILITY_FRONTIER_COLUMNS
        )...,
    )
end

function _reduced_mpcc_frontier_metadata(
    rows::Vector{Dict{String, Any}},
    sweeps::Vector{ReducedDCDFBAMPCCSolveAttemptSweepResult},
    reports::Vector{ReducedDCDFBAMPCCSimulationViabilityReport};
    stopped_after_first_non_green::Bool,
    requested_case_count::Int = length(rows),
    ipopt_max_iter = missing,
)::Dict{String, Any}
    last_green = _reduced_mpcc_frontier_last_green_row(rows)
    first_non_green = _reduced_mpcc_frontier_first_non_green_after_green_row(rows)
    green_count = count(row -> get(row, "traffic_light", missing) == "green", rows)
    yellow_count = count(row -> get(row, "traffic_light", missing) == "yellow", rows)
    red_count = count(row -> get(row, "traffic_light", missing) == "red", rows)
    return Dict{String, Any}(
        "frontier_type" => REDUCED_DCDFBA_MPCC_SIMULATION_VIABILITY_FRONTIER_TYPE,
        "n_requested_cases" => requested_case_count,
        "n_cases" => length(rows),
        "n_completed_cases" => count(row -> get(row, "case_status", "") == "completed", rows),
        "n_failed_cases" => count(row -> get(row, "case_status", "") == "failed", rows),
        "n_sweep_results" => length(sweeps),
        "n_viability_reports" => length(reports),
        "green_count" => green_count,
        "yellow_count" => yellow_count,
        "red_count" => red_count,
        "simulation_viable_case_count" =>
            count(row -> get(row, "simulation_viable", false) === true, rows),
        "last_green_case_id" => _reduced_mpcc_frontier_value(last_green, "frontier_case_id"),
        "last_green_horizon" => _reduced_mpcc_frontier_value(last_green, "horizon"),
        "last_green_nfe" => _reduced_mpcc_frontier_value(last_green, "nfe"),
        "last_green_boundary_dt" => _reduced_mpcc_frontier_value(last_green, "boundary_dt"),
        "last_green_solver_status" => _reduced_mpcc_frontier_value(last_green, "solver_status"),
        "last_green_max_state_relative_rmse" =>
            _reduced_mpcc_frontier_value(last_green, "max_state_relative_rmse"),
        "first_non_green_case_id" =>
            _reduced_mpcc_frontier_value(first_non_green, "frontier_case_id"),
        "first_non_green_horizon" => _reduced_mpcc_frontier_value(first_non_green, "horizon"),
        "first_non_green_nfe" => _reduced_mpcc_frontier_value(first_non_green, "nfe"),
        "first_non_green_traffic_light" =>
            _reduced_mpcc_frontier_value(first_non_green, "traffic_light"),
        "first_non_green_viability_class" =>
            _reduced_mpcc_frontier_value(first_non_green, "viability_class"),
        "first_non_green_blocking_reasons" =>
            _reduced_mpcc_frontier_value(first_non_green, "blocking_reasons"),
        "frontier_reached_green" => last_green !== nothing,
        "frontier_blocked" => first_non_green !== nothing,
        "all_requested_cases_green" => !isempty(rows) && green_count == length(rows),
        "stopped_after_first_non_green" => stopped_after_first_non_green,
        "ipopt_max_iter" => ipopt_max_iter,
        "total_solve_elapsed_seconds" =>
            sum(
                Float64(get(row, "solve_elapsed_seconds", 0.0)) for row in rows if
                _reduced_mpcc_frontier_isfinite_number(get(row, "solve_elapsed_seconds", missing))
            ),
        "recommended_next_action" =>
            _reduced_mpcc_frontier_recommended_action(last_green, first_non_green, rows),
        "outputs_written" => false,
        "frontier_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Ordered reduced MPCC simulation-viability frontier; diagnostic only and not a scientific simulation claim.",
    )
end

function _reduced_mpcc_frontier_recommended_action(last_green, first_non_green, rows)::String
    isempty(rows) && return "run_short_frontier_cases"
    last_green === nothing && return "recover_short_green_candidate_before_scaling"
    first_non_green === nothing && return "extend_frontier_horizon"
    class = string(get(first_non_green, "viability_class", "unknown"))
    if class == "iteration_limit_residual_feasible_candidate" ||
       class == "residual_feasible_but_not_trajectory_ready"
        return "improve_solver_termination_at_frontier"
    elseif class == "state_drift_too_large" || class == "windowed_drift_too_large"
        return "reduce_state_drift_at_frontier"
    elseif class == "residual_thresholds_failed"
        return "repair_residual_feasibility_at_frontier"
    elseif class == "guardrail_violation"
        return "fix_scientific_guardrails_before_scaling"
    else
        return "inspect_first_non_green_frontier_case"
    end
end

function _reduced_mpcc_frontier_last_green_row(rows::Vector{Dict{String, Any}})
    index = findlast(row -> get(row, "traffic_light", missing) == "green", rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_frontier_first_non_green_after_green_row(rows::Vector{Dict{String, Any}})
    isempty(rows) && return nothing
    last_green_index = findlast(row -> get(row, "traffic_light", missing) == "green", rows)
    if last_green_index === nothing
        first_non_green = findfirst(row -> get(row, "traffic_light", missing) != "green", rows)
        return first_non_green === nothing ? nothing : rows[first_non_green]
    end
    last_green_index == length(rows) && return nothing
    for index in (last_green_index + 1):length(rows)
        get(rows[index], "traffic_light", missing) != "green" && return rows[index]
    end
    return nothing
end

function _reduced_mpcc_frontier_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_frontier_boundary_dt(horizon, nfe)
    _reduced_mpcc_frontier_isfinite_number(horizon) || return missing
    _reduced_mpcc_frontier_isfinite_number(nfe) || return missing
    Int(nfe) > 0 || return missing
    return Float64(horizon) / Int(nfe)
end

function _reduced_mpcc_frontier_collocation_points(nfe, degree)
    _reduced_mpcc_frontier_isfinite_number(nfe) || return missing
    _reduced_mpcc_frontier_isfinite_number(degree) || return missing
    return Int(nfe) * Int(degree)
end

function _reduced_mpcc_frontier_case_id(index::Int)::String
    return "frontier_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_frontier_float_or_inf(value)::Float64
    _reduced_mpcc_frontier_isfinite_number(value) || return Inf
    return Float64(value)
end

function _reduced_mpcc_frontier_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_frontier_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
