const DFVB_BASELINE_REPORT_TYPE = "matlab_dfvb_baseline_trajectory_report"
const DFVB_BASELINE_SOURCE = "matlab_dfvb_export"
const DFVB_BASELINE_ACTIVE_ALPHA_MAPPING_POLICY =
    "MATLAB active alpha trajectory columns are local active columns; compare to Julia alpha histories by active position and source alpha metadata, not by local alpha name."
const DFVB_BASELINE_ALPHA_MAPPING_NOTE =
    "Active alpha CSV columns use local active IDs alpha_1..alpha_n; Julia active alpha histories use source alpha IDs such as alpha_3. Use active_alpha_mapping for comparisons."
const DFVB_BASELINE_INTERPRETATION_NOTE =
    "This report summarizes exported MATLAB DFVB baseline trajectories. It does not run or validate the Julia DFVB ODE, does not compare Julia versus MATLAB trajectories, and does not imply biological validity of the exported exchange partition."

const DFVB_BASELINE_STATE_SUMMARY_COLUMNS = [
    "state_name",
    "initial_value",
    "final_value",
    "minimum_value",
    "maximum_value",
    "range",
    "time_of_minimum",
    "time_of_maximum",
    "finite_values",
    "has_negative_values",
]

const DFVB_BASELINE_ALPHA_SUMMARY_COLUMNS = [
    "alpha_scope",
    "local_alpha_id",
    "source_alpha_index",
    "source_alpha_id",
    "initial_value",
    "final_value",
    "minimum_value",
    "maximum_value",
    "range",
    "time_of_minimum",
    "time_of_maximum",
    "finite_values",
]

const DFVB_BASELINE_ACTIVE_ALPHA_MAPPING_COLUMNS = [
    "active_alpha_index",
    "active_alpha_id",
    "source_alpha_index",
    "source_alpha_id",
]

"""
    DFVBBaselineReport

Compact report for exported MATLAB DFVB baseline trajectories. State
trajectories are preserved on the original MATLAB time grid. Alpha trajectories
are summarized by alpha column; wide alpha timeseries are intentionally not
stored in this report type.
"""
struct DFVBBaselineReport
    state_summary::DataFrame
    state_timeseries::DataFrame
    alpha_summary::DataFrame
    active_alpha_mapping::DataFrame
    metadata::Dict{String, Any}
end

"""
    build_dfvb_baseline_report(artifacts; include_full_alpha_summary=true, include_active_alpha_summary=true)

Build a plotting-free report from MATLAB-exported DFVB state and alpha
trajectories. This does not run a Julia simulation, solve an LP, interpolate
time grids, or compare MATLAB against Julia outputs.
"""
function build_dfvb_baseline_report(
    artifacts::DFVBArtifacts;
    include_full_alpha_summary::Bool = true,
    include_active_alpha_summary::Bool = true,
)::DFVBBaselineReport
    artifacts.state_trajectories !== nothing ||
        error("DFVB baseline report requires artifacts.state_trajectories to be loaded.")

    state_timeseries = DataFrame(artifacts.state_trajectories)
    _validate_dfvb_baseline_state_table(state_timeseries)
    time = _dfvb_baseline_time_vector(state_timeseries, "state_trajectories")

    active_alpha_mapping = _dfvb_baseline_active_alpha_mapping(artifacts)
    state_summary = _dfvb_baseline_state_summary_table(state_timeseries, time)
    alpha_summary = _dfvb_baseline_alpha_summary_table(
        artifacts,
        time,
        active_alpha_mapping;
        include_full_alpha_summary = include_full_alpha_summary,
        include_active_alpha_summary = include_active_alpha_summary,
    )
    metadata = _dfvb_baseline_metadata(
        artifacts,
        state_timeseries,
        alpha_summary,
        active_alpha_mapping,
        time;
        include_full_alpha_summary = include_full_alpha_summary,
        include_active_alpha_summary = include_active_alpha_summary,
    )

    return DFVBBaselineReport(
        state_summary,
        state_timeseries,
        alpha_summary,
        active_alpha_mapping,
        metadata,
    )
end

"""
    export_dfvb_baseline_report(report, output_dir; overwrite=false)

Export MATLAB DFVB baseline report CSV/TOML files. Only known report files are
overwritten when `overwrite=true`; unrelated files are left untouched.
"""
function export_dfvb_baseline_report(
    report::DFVBBaselineReport,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("DFVB baseline report output_dir exists and is not a directory: $output_path")
    end

    paths = Dict{String, String}(
        "state_summary" => joinpath(output_path, "dfvb_baseline_state_summary.csv"),
        "state_timeseries" => joinpath(output_path, "dfvb_baseline_state_timeseries.csv"),
        "alpha_summary" => joinpath(output_path, "dfvb_baseline_alpha_summary.csv"),
        "active_alpha_mapping" => joinpath(output_path, "dfvb_baseline_active_alpha_mapping.csv"),
        "metadata" => joinpath(output_path, "dfvb_baseline_metadata.toml"),
    )
    existing_targets = [path for path in values(paths) if isfile(path)]
    if !overwrite && !isempty(existing_targets)
        error(
            "DFVB baseline report target file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end

    mkpath(output_path)
    if overwrite
        for path in values(paths)
            isfile(path) && rm(path)
        end
    end

    CSV.write(paths["state_summary"], report.state_summary)
    CSV.write(paths["state_timeseries"], report.state_timeseries)
    CSV.write(paths["alpha_summary"], report.alpha_summary)
    CSV.write(paths["active_alpha_mapping"], report.active_alpha_mapping)
    open(paths["metadata"], "w") do io
        TOML.print(io, _dfvb_baseline_toml_normalize(report.metadata))
    end
    return paths
end

function _validate_dfvb_baseline_state_table(state_table::DataFrame)
    missing_columns = setdiff(DFVB_ARTIFACT_STATE_COLUMNS, names(state_table))
    isempty(missing_columns) || error(
        "DFVB baseline state trajectories are missing expected columns: $(join(missing_columns, ", ")).",
    )
    ncol(state_table) == length(DFVB_ARTIFACT_STATE_COLUMNS) || error(
        "DFVB baseline state trajectories must contain time plus 19 state columns. " *
        "Got $(ncol(state_table)) columns.",
    )
    nrow(state_table) > 0 || error("DFVB baseline state trajectories must contain at least one row.")
    return nothing
end

function _dfvb_baseline_time_vector(table::DataFrame, label::AbstractString)::Vector{Float64}
    "time" in names(table) || error("DFVB baseline $label table is missing a time column.")
    time = _dfvb_baseline_numeric_vector(table[!, "time"], "$label.time")
    all(isfinite, time) || error("DFVB baseline $label time column must contain only finite values.")
    isempty(time) && error("DFVB baseline $label time column is empty.")
    return time
end

function _dfvb_baseline_state_summary_table(state_table::DataFrame, time::Vector{Float64})::DataFrame
    rows = [
        _dfvb_baseline_series_summary_row(
            state_name,
            _dfvb_baseline_numeric_vector(state_table[!, state_name], "state_trajectories.$state_name"),
            time,
        ) for state_name in DFVB_ARTIFACT_STATE_COLUMNS[2:end]
    ]
    return DataFrame(
        (
            column => [_dfvb_baseline_table_scalar(get(row, column, missing)) for row in rows] for
            column in DFVB_BASELINE_STATE_SUMMARY_COLUMNS
        )...,
    )
end

function _dfvb_baseline_alpha_summary_table(
    artifacts::DFVBArtifacts,
    state_time::Vector{Float64},
    active_alpha_mapping::DataFrame;
    include_full_alpha_summary::Bool,
    include_active_alpha_summary::Bool,
)::DataFrame
    rows = Vector{Dict{String, Any}}()
    if include_active_alpha_summary
        artifacts.alpha_trajectories_active !== nothing ||
            error("DFVB baseline active alpha summary requires artifacts.alpha_trajectories_active to be loaded.")
        append!(
            rows,
            _dfvb_baseline_active_alpha_summary_rows(
                artifacts.alpha_trajectories_active,
                active_alpha_mapping,
                state_time,
            ),
        )
    end
    if include_full_alpha_summary
        artifacts.alpha_trajectories !== nothing ||
            error("DFVB baseline full alpha summary requires artifacts.alpha_trajectories to be loaded.")
        append!(rows, _dfvb_baseline_full_alpha_summary_rows(artifacts.alpha_trajectories, state_time))
    end

    return DataFrame(
        (
            column => [_dfvb_baseline_table_scalar(get(row, column, missing)) for row in rows] for
            column in DFVB_BASELINE_ALPHA_SUMMARY_COLUMNS
        )...,
    )
end

function _dfvb_baseline_active_alpha_summary_rows(
    alpha_table::DataFrame,
    active_alpha_mapping::DataFrame,
    state_time::Vector{Float64},
)::Vector{Dict{String, Any}}
    alpha_time = _dfvb_baseline_time_vector(alpha_table, "alpha_trajectories_active")
    _dfvb_baseline_assert_matching_time_grid(state_time, alpha_time, "active alpha trajectories")
    local_alpha_ids = _dfvb_baseline_alpha_column_ids(alpha_table, "active alpha trajectories")
    nrow(active_alpha_mapping) == length(local_alpha_ids) || error(
        "DFVB active alpha mapping row count $(nrow(active_alpha_mapping)) does not match " *
        "active alpha trajectory column count $(length(local_alpha_ids)).",
    )

    rows = Vector{Dict{String, Any}}(undef, length(local_alpha_ids))
    for (i, local_alpha_id) in enumerate(local_alpha_ids)
        values = _dfvb_baseline_numeric_vector(alpha_table[!, local_alpha_id], "alpha_trajectories_active.$local_alpha_id")
        base_row = _dfvb_baseline_alpha_summary_row("active", local_alpha_id, values, alpha_time)
        base_row["source_alpha_index"] = Int(active_alpha_mapping[i, "source_alpha_index"])
        base_row["source_alpha_id"] = String(active_alpha_mapping[i, "source_alpha_id"])
        rows[i] = base_row
    end
    return rows
end

function _dfvb_baseline_full_alpha_summary_rows(
    alpha_table::DataFrame,
    state_time::Vector{Float64},
)::Vector{Dict{String, Any}}
    alpha_time = _dfvb_baseline_time_vector(alpha_table, "alpha_trajectories")
    _dfvb_baseline_assert_matching_time_grid(state_time, alpha_time, "full alpha trajectories")
    local_alpha_ids = _dfvb_baseline_alpha_column_ids(alpha_table, "full alpha trajectories")

    rows = Vector{Dict{String, Any}}(undef, length(local_alpha_ids))
    for (i, local_alpha_id) in enumerate(local_alpha_ids)
        values = _dfvb_baseline_numeric_vector(alpha_table[!, local_alpha_id], "alpha_trajectories.$local_alpha_id")
        base_row = _dfvb_baseline_alpha_summary_row("full", local_alpha_id, values, alpha_time)
        base_row["source_alpha_index"] = i
        base_row["source_alpha_id"] = local_alpha_id
        rows[i] = base_row
    end
    return rows
end

function _dfvb_baseline_alpha_summary_row(
    alpha_scope::AbstractString,
    local_alpha_id::AbstractString,
    values::Vector{Float64},
    time::Vector{Float64},
)::Dict{String, Any}
    row = _dfvb_baseline_series_summary_row(String(local_alpha_id), values, time)
    return Dict{String, Any}(
        "alpha_scope" => String(alpha_scope),
        "local_alpha_id" => String(local_alpha_id),
        "source_alpha_index" => missing,
        "source_alpha_id" => missing,
        "initial_value" => row["initial_value"],
        "final_value" => row["final_value"],
        "minimum_value" => row["minimum_value"],
        "maximum_value" => row["maximum_value"],
        "range" => row["range"],
        "time_of_minimum" => row["time_of_minimum"],
        "time_of_maximum" => row["time_of_maximum"],
        "finite_values" => row["finite_values"],
    )
end

function _dfvb_baseline_series_summary_row(
    label::AbstractString,
    values::Vector{Float64},
    time::Vector{Float64},
)::Dict{String, Any}
    length(values) == length(time) || error(
        "DFVB baseline series $(String(label)) length $(length(values)) does not match time length $(length(time)).",
    )
    finite_mask = isfinite.(values)
    finite_values = all(finite_mask)
    finite_indices = findall(finite_mask)
    if isempty(finite_indices)
        minimum_value = NaN
        maximum_value = NaN
        time_of_minimum = NaN
        time_of_maximum = NaN
    else
        subset = values[finite_indices]
        min_subset_index = argmin(subset)
        max_subset_index = argmax(subset)
        minimum_value = subset[min_subset_index]
        maximum_value = subset[max_subset_index]
        time_of_minimum = time[finite_indices[min_subset_index]]
        time_of_maximum = time[finite_indices[max_subset_index]]
    end

    return Dict{String, Any}(
        "state_name" => String(label),
        "initial_value" => values[begin],
        "final_value" => values[end],
        "minimum_value" => minimum_value,
        "maximum_value" => maximum_value,
        "range" => maximum_value - minimum_value,
        "time_of_minimum" => time_of_minimum,
        "time_of_maximum" => time_of_maximum,
        "finite_values" => finite_values,
        "has_negative_values" => any(value -> isfinite(value) && value < 0.0, values),
    )
end

function _dfvb_baseline_active_alpha_mapping(artifacts::DFVBArtifacts)::DataFrame
    indices = artifacts.active_alpha_indices
    metadata = artifacts.N_active_column_metadata
    for column in ("active_alpha_index", "source_alpha_index", "source_alpha_id")
        column in names(indices) || error("DFVB active_alpha_indices is missing column $column.")
    end
    for column in ("alpha_index", "source_alpha_index", "source_alpha_id")
        column in names(metadata) || error("DFVB N_active_column_metadata is missing column $column.")
    end
    nrow(indices) == nrow(metadata) || error(
        "DFVB active_alpha_indices row count $(nrow(indices)) does not match " *
        "N_active_column_metadata row count $(nrow(metadata)).",
    )

    rows = Vector{Dict{String, Any}}(undef, nrow(indices))
    metadata_alpha_indices = Int.([_dfvb_baseline_required_int(metadata[i, "alpha_index"], "N_active_column_metadata.alpha_index", i) for i in axes(metadata, 1)])
    for i in axes(indices, 1)
        active_alpha_index = _dfvb_baseline_required_int(indices[i, "active_alpha_index"], "active_alpha_indices.active_alpha_index", i)
        metadata_index = findfirst(==(active_alpha_index), metadata_alpha_indices)
        metadata_index !== nothing || error(
            "DFVB active alpha index $active_alpha_index is missing from N_active_column_metadata.alpha_index.",
        )
        source_alpha_index = _dfvb_baseline_required_int(indices[i, "source_alpha_index"], "active_alpha_indices.source_alpha_index", i)
        metadata_source_index =
            _dfvb_baseline_required_int(metadata[metadata_index, "source_alpha_index"], "N_active_column_metadata.source_alpha_index", metadata_index)
        source_alpha_id = strip(String(indices[i, "source_alpha_id"]))
        metadata_source_id = strip(String(metadata[metadata_index, "source_alpha_id"]))
        source_alpha_index == metadata_source_index || error(
            "DFVB active alpha index $active_alpha_index source index mismatch: " *
            "$source_alpha_index vs $metadata_source_index.",
        )
        source_alpha_id == metadata_source_id || error(
            "DFVB active alpha index $active_alpha_index source ID mismatch: " *
            "$source_alpha_id vs $metadata_source_id.",
        )
        rows[i] = Dict{String, Any}(
            "active_alpha_index" => active_alpha_index,
            "active_alpha_id" => "alpha_$active_alpha_index",
            "source_alpha_index" => source_alpha_index,
            "source_alpha_id" => source_alpha_id,
        )
    end

    return DataFrame(
        (
            column => [_dfvb_baseline_table_scalar(get(row, column, missing)) for row in rows] for
            column in DFVB_BASELINE_ACTIVE_ALPHA_MAPPING_COLUMNS
        )...,
    )
end

function _dfvb_baseline_metadata(
    artifacts::DFVBArtifacts,
    state_timeseries::DataFrame,
    alpha_summary::DataFrame,
    active_alpha_mapping::DataFrame,
    time::Vector{Float64};
    include_full_alpha_summary::Bool,
    include_active_alpha_summary::Bool,
)::Dict{String, Any}
    n_active_summary_rows = nrow(alpha_summary) == 0 ? 0 : count(==("active"), String.(alpha_summary[!, "alpha_scope"]))
    n_full_summary_rows = nrow(alpha_summary) == 0 ? 0 : count(==("full"), String.(alpha_summary[!, "alpha_scope"]))
    return Dict{String, Any}(
        "report_type" => DFVB_BASELINE_REPORT_TYPE,
        "source" => DFVB_BASELINE_SOURCE,
        "artifact_id" => artifacts.paths.artifact_id,
        "state_time_start" => time[begin],
        "state_time_end" => time[end],
        "n_time_points" => nrow(state_timeseries),
        "n_states" => length(DFVB_ARTIFACT_STATE_COLUMNS) - 1,
        "state_names" => copy(DFVB_ARTIFACT_STATE_COLUMNS[2:end]),
        "n_active_alphas" => nrow(active_alpha_mapping),
        "n_full_alphas" => artifacts.manifest.n_null_basis_columns,
        "active_alpha_summary_included" => include_active_alpha_summary,
        "full_alpha_summary_included" => include_full_alpha_summary,
        "n_active_alpha_summary_rows" => n_active_summary_rows,
        "n_full_alpha_summary_rows" => n_full_summary_rows,
        "active_alpha_mapping_policy" => DFVB_BASELINE_ACTIVE_ALPHA_MAPPING_POLICY,
        "full_alpha_timeseries_exported" => false,
        "active_alpha_timeseries_exported" => false,
        "r0001_used_as_oxygen" => false,
        "indices_reacciones_used" => false,
        "oxygen_reaction_id" => "r_1992",
        "oxygen_policy_note" => DFVB_ARTIFACT_OXYGEN_MAPPING_NOTE,
        "exchange_partition_note" => DFVB_ARTIFACT_EXCHANGE_PARTITION_NOTE,
        "alpha_mapping_note" => DFVB_BASELINE_ALPHA_MAPPING_NOTE,
        "interpretation_note" => DFVB_BASELINE_INTERPRETATION_NOTE,
        "julia_simulation_run" => false,
        "lp_solve_run" => false,
        "julia_vs_matlab_comparison_included" => false,
        "dfvb_vs_dfba_comparison_included" => false,
        "kkt_mpcc_collocation_implemented" => false,
    )
end

function _dfvb_baseline_alpha_column_ids(alpha_table::DataFrame, label::AbstractString)::Vector{String}
    alpha_ids = setdiff(names(alpha_table), ["time"])
    !isempty(alpha_ids) || error("DFVB baseline $label table must contain at least one alpha column.")
    return String.(alpha_ids)
end

function _dfvb_baseline_assert_matching_time_grid(
    state_time::Vector{Float64},
    alpha_time::Vector{Float64},
    label::AbstractString,
)
    length(state_time) == length(alpha_time) || error(
        "DFVB baseline $label time grid length $(length(alpha_time)) does not match state grid length $(length(state_time)).",
    )
    all(state_time .== alpha_time) || error(
        "DFVB baseline $label time grid must exactly match state trajectories; interpolation is not performed.",
    )
    return nothing
end

function _dfvb_baseline_numeric_vector(values, label::AbstractString)::Vector{Float64}
    output = Vector{Float64}(undef, length(values))
    for (i, value) in enumerate(values)
        ismissing(value) && error("Missing numeric value in DFVB baseline $label row $i.")
        parsed = value isa Real ? Float64(value) : tryparse(Float64, strip(String(value)))
        parsed === nothing && error("Non-numeric value in DFVB baseline $label row $i: $value")
        output[i] = parsed
    end
    return output
end

function _dfvb_baseline_required_int(value, label::AbstractString, row::Integer)::Int
    ismissing(value) && error("Missing integer value in DFVB baseline $label row $row.")
    if value isa Integer
        return Int(value)
    elseif value isa AbstractFloat && isinteger(value)
        return Int(value)
    end
    parsed = tryparse(Int, strip(String(value)))
    parsed === nothing && error("Non-integer value in DFVB baseline $label row $row: $value")
    return parsed
end

function _dfvb_baseline_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end

function _dfvb_baseline_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _dfvb_baseline_toml_normalize_real(value)
    elseif value isa Tuple
        return _dfvb_baseline_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _dfvb_baseline_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _dfvb_baseline_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _dfvb_baseline_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _dfvb_baseline_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _dfvb_baseline_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end
