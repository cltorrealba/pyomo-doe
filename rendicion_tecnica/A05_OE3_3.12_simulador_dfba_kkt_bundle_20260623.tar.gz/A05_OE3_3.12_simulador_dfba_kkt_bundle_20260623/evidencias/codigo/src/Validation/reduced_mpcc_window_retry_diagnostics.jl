import HiGHS
import OrdinaryDiffEq

const REDUCED_DCDFBA_MPCC_WINDOW_RETRY_DIAGNOSTIC_TYPE =
    "reduced_dcdfba_mpcc_window_retry_diagnostics"

const REDUCED_DCDFBA_MPCC_WINDOW_RETRY_COLUMNS = [
    "retry_case_id",
    "source_window_id",
    "source_window_index",
    "source_window_t0",
    "source_window_tfinal",
    "source_window_hours",
    "nfe",
    "degree",
    "ipopt_max_iter",
    "case_status",
    "solver_status",
    "primal_status",
    "solve_elapsed_seconds",
    "traffic_light",
    "viability_class",
    "residual_feasible",
    "iteration_limit_residual_feasible",
    "trajectory_ready",
    "residuals_pass",
    "state_drift_pass",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_mass_balance_ratio",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_state_relative_rmse",
    "dominant_residual",
    "blocking_reasons",
    "review_reasons",
    "improved_mass_balance_vs_source",
    "mass_balance_ratio_improvement",
    "became_residual_feasible",
    "became_green",
    "recommended_next_action",
    "error_type",
    "error_message",
]

"""
    ReducedDCDFBAMPCCWindowRetryDiagnosticResult

Retry diagnostics for one reduced MPCC window selected from a windowed
target-horizon attempt. Each retry uses the same local window initial state and
grid, but a different Ipopt iteration budget. The result is diagnostic-only:
it does not relax thresholds, write outputs, or validate a scientific
simulation.
"""
struct ReducedDCDFBAMPCCWindowRetryDiagnosticResult
    retry_table::DataFrame
    retry_sweeps::Vector{ReducedDCDFBAMPCCSolveAttemptSweepResult}
    retry_reports::Vector{ReducedDCDFBAMPCCSimulationViabilityReport}
    metadata::Dict{String, Any}
end

"""
    diagnose_reduced_dcdfba_mpcc_window_retry(attempt, reports; kwargs...)

Aggregate already-computed single-window retry viability reports. This method
is useful for deterministic tests and for summarizing cached diagnostics.
"""
function diagnose_reduced_dcdfba_mpcc_window_retry(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    reports::AbstractVector{<:ReducedDCDFBAMPCCSimulationViabilityReport};
    window_index = nothing,
    ipopt_max_iter_values,
)::ReducedDCDFBAMPCCWindowRetryDiagnosticResult
    isempty(reports) && throw(
        ArgumentError("Reduced MPCC window retry diagnostics require at least one retry report."),
    )
    max_iter_values = _reduced_mpcc_retry_validate_max_iter_values(ipopt_max_iter_values)
    length(max_iter_values) == length(reports) || throw(
        ArgumentError(
            "Reduced MPCC window retry diagnostics require one ipopt_max_iter value per retry report.",
        ),
    )
    source = _reduced_mpcc_retry_source(attempt, window_index)
    rows = Dict{String, Any}[]
    for (case_index, (report, max_iter)) in enumerate(zip(reports, max_iter_values))
        push!(
            rows,
            _reduced_mpcc_retry_row_from_report(source, report, case_index, max_iter),
        )
    end
    table = _reduced_mpcc_retry_table(rows)
    metadata = _reduced_mpcc_retry_metadata(source, rows, max_iter_values)
    return ReducedDCDFBAMPCCWindowRetryDiagnosticResult(
        table,
        ReducedDCDFBAMPCCSolveAttemptSweepResult[],
        collect(reports),
        metadata,
    )
end

"""
    diagnose_reduced_dcdfba_mpcc_window_retry(attempt, model, reaction_map; kwargs...)

Retry the first residual-infeasible/red/non-green window from a reduced MPCC
windowed target-horizon attempt with alternate `ipopt_max_iter` values. The
local window is rerun with the same initial state, tspan, `nfe`, and degree.
"""
function diagnose_reduced_dcdfba_mpcc_window_retry(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    model::MetabolicModel,
    reaction_map::ReactionMap;
    window_index = nothing,
    ipopt_max_iter_values = [200, 300, 500],
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    sequential_optimizer = HiGHS.Optimizer,
    sequential_algorithm = OrdinaryDiffEq.Tsit5(),
    sequential_ode_abstol::Real = 1.0e-8,
    sequential_ode_reltol::Real = 1.0e-8,
    sequential_lp_atol::Real = 1.0e-8,
    sequential_adaptive::Bool = true,
    sequential_dt = nothing,
    sequential_nonnegative::Bool = true,
    sequential_stop_on_sugar_depletion::Bool = true,
    sequential_reconstruct_fluxes::Bool = false,
    mpcc_optimizer = nothing,
    linear_solver::AbstractString = ipopt_linear_solver_from_env(),
    ipopt_profile::AbstractString = reduced_mpcc_ipopt_profile_name_from_env(),
    complementarity_mode::Union{Symbol, AbstractString} =
        reduced_mpcc_complementarity_mode_from_env(
            REDUCED_DCDFBA_MPCC_COMPLEMENTARITY_MODE_SCHOLTES,
        ),
    complementarity_tau::Real = reduced_mpcc_complementarity_tau_from_env(),
    tau_schedule = nothing,
    require_pre_solve_ready::Bool = true,
    residual_thresholds::ReducedDCDFBAMPCCResidualThresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(),
    viability_thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        ),
    silent::Bool = true,
    continue_on_error::Bool = true,
)::ReducedDCDFBAMPCCWindowRetryDiagnosticResult
    max_iter_values = _reduced_mpcc_retry_validate_max_iter_values(ipopt_max_iter_values)
    source = _reduced_mpcc_retry_source(attempt, window_index)
    comparison = _reduced_mpcc_retry_source_comparison(attempt, source.window_index)
    local_y0 = Float64.(comparison.sequential_result.states[:, 1])

    rows = Dict{String, Any}[]
    sweeps = ReducedDCDFBAMPCCSolveAttemptSweepResult[]
    reports = ReducedDCDFBAMPCCSimulationViabilityReport[]
    for (case_index, max_iter) in enumerate(max_iter_values)
        try
            sweep = sweep_reduced_dcdfba_mpcc_solve_attempts(
                model,
                reaction_map;
                horizons = [source.window_hours],
                nfe_values = [source.nfe],
                t0 = source.t0,
                degree = source.degree,
                y0 = local_y0,
                params = params,
                sequential_optimizer = sequential_optimizer,
                sequential_algorithm = sequential_algorithm,
                sequential_ode_abstol = sequential_ode_abstol,
                sequential_ode_reltol = sequential_ode_reltol,
                sequential_lp_atol = sequential_lp_atol,
                sequential_adaptive = sequential_adaptive,
                sequential_dt = sequential_dt,
                sequential_nonnegative = sequential_nonnegative,
                sequential_stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
                sequential_reconstruct_fluxes = sequential_reconstruct_fluxes,
                mpcc_optimizer = mpcc_optimizer,
                ipopt_max_iter = max_iter,
                linear_solver = linear_solver,
                ipopt_profile = ipopt_profile,
                complementarity_mode = complementarity_mode,
                complementarity_tau = complementarity_tau,
                tau_schedule = tau_schedule,
                require_pre_solve_ready = require_pre_solve_ready,
                residual_thresholds = residual_thresholds,
                silent = silent,
                continue_on_error = false,
            )
            report = assess_reduced_dcdfba_mpcc_simulation_viability(
                sweep;
                thresholds = viability_thresholds,
            )
            push!(sweeps, sweep)
            push!(reports, report)
            push!(
                rows,
                _reduced_mpcc_retry_row_from_report(source, report, case_index, max_iter),
            )
        catch err
            continue_on_error || rethrow()
            push!(
                rows,
                _reduced_mpcc_retry_error_row(source, case_index, max_iter, err),
            )
        end
    end
    table = _reduced_mpcc_retry_table(rows)
    metadata = _reduced_mpcc_retry_metadata(source, rows, max_iter_values)
    return ReducedDCDFBAMPCCWindowRetryDiagnosticResult(table, sweeps, reports, metadata)
end

function _reduced_mpcc_retry_source(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    requested_window_index,
)
    selected_index = _reduced_mpcc_retry_selected_window_index(attempt, requested_window_index)
    candidate_id = _reduced_mpcc_retry_window_id(selected_index)
    viability_row = _reduced_mpcc_retry_viability_row(attempt, candidate_id)
    continuation_row = _reduced_mpcc_retry_continuation_row(attempt, candidate_id)
    comparison = _reduced_mpcc_retry_source_comparison(attempt, selected_index)
    t0 = Float64(first(comparison.sequential_result.time))
    tfinal = Float64(last(comparison.sequential_result.time))
    nfe = _reduced_mpcc_retry_int_or_default(
        get(continuation_row, "nfe", get(viability_row, "nfe", missing)),
        length(comparison.sequential_result.time) - 1,
    )
    degree = _reduced_mpcc_retry_int_or_default(
        get(continuation_row, "degree", get(viability_row, "degree", missing)),
        3,
    )
    threshold = attempt.viability_report.thresholds.max_mass_balance_residual
    source_mass = get(viability_row, "max_mass_balance_residual", missing)
    return (
        window_id = candidate_id,
        window_index = selected_index,
        t0 = t0,
        tfinal = tfinal,
        window_hours = tfinal - t0,
        nfe = nfe,
        degree = degree,
        source_traffic_light = get(viability_row, "traffic_light", missing),
        source_viability_class = get(viability_row, "viability_class", missing),
        source_solver_status = get(viability_row, "solver_status", missing),
        source_residual_feasible = get(viability_row, "residual_feasible", missing),
        source_max_mass_balance_residual = source_mass,
        source_max_mass_balance_ratio =
            _reduced_mpcc_retry_ratio(source_mass, threshold),
        source_blocking_reasons = get(viability_row, "blocking_reasons", missing),
        max_mass_balance_threshold = threshold,
    )
end

function _reduced_mpcc_retry_selected_window_index(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    requested_window_index,
)::Int
    if requested_window_index !== nothing
        index = Int(requested_window_index)
        index > 0 || throw(
            ArgumentError("Reduced MPCC window retry window_index must be positive."),
        )
        return index
    end
    for key in (
        "first_not_residual_feasible_window_index",
        "first_red_window_index",
        "first_non_green_window_index",
    )
        value = get(attempt.metadata, key, missing)
        parsed = _reduced_mpcc_retry_int_or_missing(value)
        parsed === missing || return parsed
    end
    row_index = findfirst(
        row -> String(row["source_type"]) == "windowed_continuation_window" &&
               String(row["traffic_light"]) != "green",
        eachrow(attempt.viability_report.viability_table),
    )
    row_index !== nothing && return Int(attempt.viability_report.viability_table[row_index, "window_index"])
    throw(ArgumentError("Reduced MPCC window retry could not find a non-green source window."))
end

function _reduced_mpcc_retry_source_comparison(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    window_index::Int,
)::ReducedDCDFBAMPCCSequentialComparisonResult
    comparisons = attempt.continuation_result.window_comparisons
    1 <= window_index <= length(comparisons) || throw(
        ArgumentError(
            "Reduced MPCC window retry source window_index $(window_index) is outside available comparisons.",
        ),
    )
    return comparisons[window_index]
end

function _reduced_mpcc_retry_viability_row(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    candidate_id::AbstractString,
)
    index = findfirst(==(String(candidate_id)), String.(attempt.viability_report.viability_table[!, "candidate_id"]))
    index === nothing && throw(
        ArgumentError("Reduced MPCC window retry could not find viability row $(candidate_id)."),
    )
    return attempt.viability_report.viability_table[index, :]
end

function _reduced_mpcc_retry_continuation_row(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    candidate_id::AbstractString,
)
    table = attempt.continuation_result.window_table
    index = findfirst(==(String(candidate_id)), String.(table[!, "window_id"]))
    index === nothing && throw(
        ArgumentError("Reduced MPCC window retry could not find continuation row $(candidate_id)."),
    )
    return table[index, :]
end

function _reduced_mpcc_retry_row_from_report(
    source,
    report::ReducedDCDFBAMPCCSimulationViabilityReport,
    case_index::Int,
    max_iter::Int,
)::Dict{String, Any}
    nrow(report.viability_table) > 0 || throw(
        ArgumentError("Reduced MPCC window retry report has no viability rows."),
    )
    row = report.viability_table[1, :]
    mass = get(row, "max_mass_balance_residual", missing)
    mass_ratio = _reduced_mpcc_retry_ratio(mass, source.max_mass_balance_threshold)
    return Dict{String, Any}(
        "retry_case_id" => _reduced_mpcc_retry_case_id(case_index),
        "source_window_id" => source.window_id,
        "source_window_index" => source.window_index,
        "source_window_t0" => source.t0,
        "source_window_tfinal" => source.tfinal,
        "source_window_hours" => source.window_hours,
        "nfe" => source.nfe,
        "degree" => source.degree,
        "ipopt_max_iter" => max_iter,
        "case_status" => get(row, "source_row_status", missing),
        "solver_status" => get(row, "solver_status", missing),
        "primal_status" => get(row, "primal_status", missing),
        "solve_elapsed_seconds" => get(row, "solve_elapsed_seconds", missing),
        "traffic_light" => get(row, "traffic_light", missing),
        "viability_class" => get(row, "viability_class", missing),
        "residual_feasible" => get(row, "residual_feasible", false),
        "iteration_limit_residual_feasible" =>
            get(row, "iteration_limit_residual_feasible", false),
        "trajectory_ready" => get(row, "trajectory_ready", false),
        "residuals_pass" => get(row, "residuals_pass", false),
        "state_drift_pass" => get(row, "state_drift_pass", false),
        "max_rhs_residual" => get(row, "max_rhs_residual", missing),
        "max_mass_balance_residual" => mass,
        "max_mass_balance_ratio" => mass_ratio,
        "max_lower_bound_violation" => get(row, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" => get(row, "max_upper_bound_violation", missing),
        "max_stationarity_residual" => get(row, "max_stationarity_residual", missing),
        "max_lower_complementarity_residual" =>
            get(row, "max_lower_complementarity_residual", missing),
        "max_upper_complementarity_residual" =>
            get(row, "max_upper_complementarity_residual", missing),
        "max_state_relative_rmse" => get(row, "max_state_relative_rmse", missing),
        "dominant_residual" => _reduced_mpcc_retry_dominant_residual(row, source),
        "blocking_reasons" => get(row, "blocking_reasons", missing),
        "review_reasons" => get(row, "review_reasons", missing),
        "improved_mass_balance_vs_source" =>
            _reduced_mpcc_retry_improved(mass, source.source_max_mass_balance_residual),
        "mass_balance_ratio_improvement" =>
            _reduced_mpcc_retry_ratio_improvement(source.source_max_mass_balance_ratio, mass_ratio),
        "became_residual_feasible" =>
            source.source_residual_feasible !== true &&
            get(row, "residual_feasible", false) === true,
        "became_green" =>
            String(source.source_traffic_light) != "green" &&
            get(row, "traffic_light", missing) == "green",
        "recommended_next_action" => get(row, "next_recommended_action", missing),
        "error_type" => get(row, "error_type", missing),
        "error_message" => get(row, "error_message", missing),
    )
end

function _reduced_mpcc_retry_error_row(source, case_index::Int, max_iter::Int, err)
    row = Dict{String, Any}(
        column => missing for column in REDUCED_DCDFBA_MPCC_WINDOW_RETRY_COLUMNS
    )
    row["retry_case_id"] = _reduced_mpcc_retry_case_id(case_index)
    row["source_window_id"] = source.window_id
    row["source_window_index"] = source.window_index
    row["source_window_t0"] = source.t0
    row["source_window_tfinal"] = source.tfinal
    row["source_window_hours"] = source.window_hours
    row["nfe"] = source.nfe
    row["degree"] = source.degree
    row["ipopt_max_iter"] = max_iter
    row["case_status"] = "failed"
    row["traffic_light"] = "red"
    row["viability_class"] = "failed_retry_row"
    row["residual_feasible"] = false
    row["trajectory_ready"] = false
    row["residuals_pass"] = false
    row["state_drift_pass"] = false
    row["improved_mass_balance_vs_source"] = false
    row["became_residual_feasible"] = false
    row["became_green"] = false
    row["recommended_next_action"] = "inspect_failed_retry_diagnostics"
    row["error_type"] = string(typeof(err))
    row["error_message"] = sprint(showerror, err)
    return row
end

function _reduced_mpcc_retry_metadata(
    source,
    rows::Vector{Dict{String, Any}},
    max_iter_values::Vector{Int},
)::Dict{String, Any}
    best = _reduced_mpcc_retry_best_row(rows)
    first_green = _reduced_mpcc_retry_first_row(rows, row -> get(row, "traffic_light", "") == "green")
    first_residual_feasible =
        _reduced_mpcc_retry_first_row(rows, row -> get(row, "residual_feasible", false) === true)
    return Dict{String, Any}(
        "retry_diagnostic_type" => REDUCED_DCDFBA_MPCC_WINDOW_RETRY_DIAGNOSTIC_TYPE,
        "source_window_id" => source.window_id,
        "source_window_index" => source.window_index,
        "source_window_t0" => source.t0,
        "source_window_tfinal" => source.tfinal,
        "source_window_hours" => source.window_hours,
        "source_nfe" => source.nfe,
        "source_degree" => source.degree,
        "source_traffic_light" => source.source_traffic_light,
        "source_viability_class" => source.source_viability_class,
        "source_solver_status" => source.source_solver_status,
        "source_residual_feasible" => source.source_residual_feasible,
        "source_max_mass_balance_residual" => source.source_max_mass_balance_residual,
        "source_max_mass_balance_ratio" => source.source_max_mass_balance_ratio,
        "source_blocking_reasons" => source.source_blocking_reasons,
        "ipopt_max_iter_values" => copy(max_iter_values),
        "n_retry_cases" => length(rows),
        "n_completed_retry_cases" =>
            count(row -> get(row, "case_status", "") == "completed", rows),
        "n_failed_retry_cases" =>
            count(row -> get(row, "case_status", "") == "failed", rows),
        "green_retry_count" =>
            count(row -> get(row, "traffic_light", missing) == "green", rows),
        "yellow_retry_count" =>
            count(row -> get(row, "traffic_light", missing) == "yellow", rows),
        "red_retry_count" =>
            count(row -> get(row, "traffic_light", missing) == "red", rows),
        "residual_feasible_retry_count" =>
            count(row -> get(row, "residual_feasible", false) === true, rows),
        "best_retry_case_id" => _reduced_mpcc_retry_value(best, "retry_case_id"),
        "best_retry_ipopt_max_iter" => _reduced_mpcc_retry_value(best, "ipopt_max_iter"),
        "best_retry_traffic_light" => _reduced_mpcc_retry_value(best, "traffic_light"),
        "best_retry_viability_class" => _reduced_mpcc_retry_value(best, "viability_class"),
        "best_retry_max_mass_balance_residual" =>
            _reduced_mpcc_retry_value(best, "max_mass_balance_residual"),
        "best_retry_max_mass_balance_ratio" =>
            _reduced_mpcc_retry_value(best, "max_mass_balance_ratio"),
        "first_green_retry_case_id" =>
            _reduced_mpcc_retry_value(first_green, "retry_case_id"),
        "first_green_retry_ipopt_max_iter" =>
            _reduced_mpcc_retry_value(first_green, "ipopt_max_iter"),
        "first_residual_feasible_retry_case_id" =>
            _reduced_mpcc_retry_value(first_residual_feasible, "retry_case_id"),
        "first_residual_feasible_retry_ipopt_max_iter" =>
            _reduced_mpcc_retry_value(first_residual_feasible, "ipopt_max_iter"),
        "retry_recovered_residual_feasibility" => first_residual_feasible !== nothing,
        "retry_recovered_green_window" => first_green !== nothing,
        "total_retry_solve_elapsed_seconds" => sum(
            Float64(get(row, "solve_elapsed_seconds", 0.0)) for row in rows if
            _reduced_mpcc_retry_isfinite_number(get(row, "solve_elapsed_seconds", missing))
        ),
        "recommended_next_action" =>
            _reduced_mpcc_retry_recommended_action(first_green, first_residual_feasible, best),
        "outputs_written" => false,
        "retry_diagnostic_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC single-window retry diagnostics; repeats one local window with alternate Ipopt iteration budgets.",
    )
end

function _reduced_mpcc_retry_validate_max_iter_values(values)::Vector{Int}
    collection = Int.(collect(values))
    isempty(collection) && throw(
        ArgumentError("Reduced MPCC window retry ipopt_max_iter_values must not be empty."),
    )
    all(value -> value > 0, collection) || throw(
        ArgumentError("Reduced MPCC window retry ipopt_max_iter_values must be positive."),
    )
    return collection
end

function _reduced_mpcc_retry_dominant_residual(row, source)
    residuals = Dict(
        "max_rhs_residual" => _reduced_mpcc_retry_ratio(
            get(row, "max_rhs_residual", missing),
            1.0e-6,
        ),
        "max_mass_balance_residual" => _reduced_mpcc_retry_ratio(
            get(row, "max_mass_balance_residual", missing),
            source.max_mass_balance_threshold,
        ),
        "max_stationarity_residual" => _reduced_mpcc_retry_ratio(
            get(row, "max_stationarity_residual", missing),
            1.0e-5,
        ),
        "max_lower_complementarity_residual" => _reduced_mpcc_retry_ratio(
            get(row, "max_lower_complementarity_residual", missing),
            1.0e-5,
        ),
        "max_upper_complementarity_residual" => _reduced_mpcc_retry_ratio(
            get(row, "max_upper_complementarity_residual", missing),
            1.0e-5,
        ),
    )
    finite = [
        (key, value) for (key, value) in residuals if
        _reduced_mpcc_retry_isfinite_number(value)
    ]
    isempty(finite) && return missing
    order = sortperm([(-Float64(value), key) for (key, value) in finite])
    return finite[first(order)][1]
end

function _reduced_mpcc_retry_best_row(rows::Vector{Dict{String, Any}})
    candidates = [
        row for row in rows if
        _reduced_mpcc_retry_isfinite_number(get(row, "max_mass_balance_ratio", missing))
    ]
    isempty(candidates) && return nothing
    order = sortperm([
        (
            get(row, "traffic_light", missing) == "green" ? 0 :
            get(row, "residual_feasible", false) === true ? 1 : 2,
            Float64(row["max_mass_balance_ratio"]),
            Int(row["ipopt_max_iter"]),
        ) for row in candidates
    ])
    return candidates[first(order)]
end

function _reduced_mpcc_retry_recommended_action(first_green, first_residual_feasible, best)::String
    first_green !== nothing && return "resume_windowed_attempt_with_retry_policy"
    first_residual_feasible !== nothing &&
        return "increase_solver_budget_or_accept_iteration_limit_review"
    best !== nothing && return "inspect_mass_balance_scaling_and_flux_starts_before_more_retries"
    return "inspect_failed_retry_diagnostics"
end

function _reduced_mpcc_retry_first_row(rows::Vector{Dict{String, Any}}, predicate)
    index = findfirst(predicate, rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_retry_row_from_table(table::DataFrame, column::AbstractString, value)
    String(column) in names(table) || return nothing
    index = findfirst(==(value), table[!, String(column)])
    return index === nothing ? nothing : table[index, :]
end

function _reduced_mpcc_retry_ratio(value, threshold)
    _reduced_mpcc_retry_isfinite_number(value) || return missing
    _reduced_mpcc_retry_isfinite_number(threshold) || return missing
    Float64(threshold) > 0.0 || return missing
    return abs(Float64(value)) / Float64(threshold)
end

function _reduced_mpcc_retry_improved(value, source_value)::Bool
    _reduced_mpcc_retry_isfinite_number(value) || return false
    _reduced_mpcc_retry_isfinite_number(source_value) || return false
    return abs(Float64(value)) < abs(Float64(source_value))
end

function _reduced_mpcc_retry_ratio_improvement(source_ratio, retry_ratio)
    _reduced_mpcc_retry_isfinite_number(source_ratio) || return missing
    _reduced_mpcc_retry_isfinite_number(retry_ratio) || return missing
    return Float64(source_ratio) - Float64(retry_ratio)
end

function _reduced_mpcc_retry_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_retry_case_id(index::Int)::String
    return "retry_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_retry_window_id(index::Int)::String
    return "window_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_retry_int_or_default(value, default::Int)::Int
    parsed = _reduced_mpcc_retry_int_or_missing(value)
    return parsed === missing ? default : parsed
end

function _reduced_mpcc_retry_int_or_missing(value)
    value === missing && return missing
    value === nothing && return missing
    return try
        Int(value)
    catch
        missing
    end
end

function _reduced_mpcc_retry_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_retry_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_retry_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_WINDOW_RETRY_COLUMNS
        )...,
    )
end

function _reduced_mpcc_retry_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
