const REDUCED_DCDFBA_MPCC_WINDOWED_FAILURE_DIAGNOSTIC_TYPE =
    "reduced_dcdfba_mpcc_windowed_failure_diagnostics"

const REDUCED_DCDFBA_MPCC_WINDOWED_FAILURE_WINDOW_COLUMNS = [
    "candidate_id",
    "source_type",
    "window_index",
    "traffic_light",
    "viability_class",
    "failure_cause",
    "solver_status",
    "residual_feasible",
    "trajectory_ready",
    "residuals_pass",
    "state_drift_pass",
    "global_state_drift_pass",
    "window_continuation_pass",
    "blocking_reasons",
    "review_reasons",
    "max_residual_ratio",
    "dominant_residual",
    "max_mass_balance_residual",
    "max_mass_balance_ratio",
    "max_rhs_residual",
    "max_rhs_ratio",
    "max_stationarity_residual",
    "max_stationarity_ratio",
    "max_lower_complementarity_residual",
    "max_lower_complementarity_ratio",
    "max_upper_complementarity_residual",
    "max_upper_complementarity_ratio",
    "max_state_relative_rmse",
    "global_max_state_relative_rmse",
]

const REDUCED_DCDFBA_MPCC_WINDOWED_FAILURE_RESIDUAL_COLUMNS = [
    "candidate_id",
    "source_type",
    "window_index",
    "traffic_light",
    "viability_class",
    "residual_name",
    "residual_value",
    "threshold",
    "ratio",
    "within_threshold",
    "is_dominant_residual",
]

const REDUCED_DCDFBA_MPCC_WINDOWED_FAILURE_MASS_BALANCE_COLUMNS = [
    "candidate_id",
    "window_index",
    "element_index",
    "collocation_index",
    "metabolite_index",
    "metabolite_id",
    "mass_balance_residual",
    "abs_mass_balance_residual",
    "threshold",
    "ratio",
    "is_window_max",
    "is_attempt_max",
    "traffic_light",
    "viability_class",
    "solver_status",
]

"""
    ReducedDCDFBAMPCCWindowedFailureDiagnosticResult

Cause-oriented diagnostic for a reduced MPCC windowed simulation attempt. It
normalizes residual ratios against the active semaphore thresholds and, when a
model is provided, locates the largest `S*v = 0` mass-balance residuals by
window, finite element, Radau point, and metabolite. This is diagnostic-only
and does not modify or rerun the MPCC formulation.
"""
struct ReducedDCDFBAMPCCWindowedFailureDiagnosticResult
    window_summary_table::DataFrame
    residual_ratio_table::DataFrame
    mass_balance_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    diagnose_reduced_dcdfba_mpcc_windowed_failure(attempt, model; top_n_mass_balance=10)

Summarize likely failure causes for a reduced MPCC windowed target-horizon
attempt. The report highlights the first non-green, first red, and first
residual-infeasible windows, ranks residual ratios, and reports the dominant
mass-balance rows from `model.S * v`.
"""
function diagnose_reduced_dcdfba_mpcc_windowed_failure(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    model::MetabolicModel;
    top_n_mass_balance::Int = 10,
)::ReducedDCDFBAMPCCWindowedFailureDiagnosticResult
    top_n_mass_balance > 0 || throw(
        ArgumentError("Reduced MPCC windowed failure diagnostics top_n_mass_balance must be positive."),
    )
    window_rows = _reduced_mpcc_failure_window_rows(attempt)
    residual_rows = _reduced_mpcc_failure_residual_rows(attempt)
    mass_rows = _reduced_mpcc_failure_mass_balance_rows(attempt, model, top_n_mass_balance)
    metadata = _reduced_mpcc_failure_metadata(attempt, window_rows, residual_rows, mass_rows)
    return ReducedDCDFBAMPCCWindowedFailureDiagnosticResult(
        _reduced_mpcc_failure_window_table(window_rows),
        _reduced_mpcc_failure_residual_table(residual_rows),
        _reduced_mpcc_failure_mass_balance_table(mass_rows),
        metadata,
    )
end

function _reduced_mpcc_failure_window_rows(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    thresholds = _reduced_mpcc_failure_threshold_dict(attempt.viability_report.thresholds)
    for row in eachrow(attempt.viability_report.viability_table)
        residual_values = _reduced_mpcc_failure_row_residual_values(row)
        residual_ratios = Dict(
            key => _reduced_mpcc_failure_ratio(value, thresholds[key]) for
            (key, value) in residual_values
        )
        dominant_residual, max_ratio = _reduced_mpcc_failure_dominant_ratio(residual_ratios)
        push!(
            rows,
            Dict{String, Any}(
                "candidate_id" => get(row, "candidate_id", missing),
                "source_type" => get(row, "source_type", missing),
                "window_index" => get(row, "window_index", missing),
                "traffic_light" => get(row, "traffic_light", missing),
                "viability_class" => get(row, "viability_class", missing),
                "failure_cause" =>
                    _reduced_mpcc_failure_cause(row, dominant_residual, max_ratio),
                "solver_status" => get(row, "solver_status", missing),
                "residual_feasible" => get(row, "residual_feasible", missing),
                "trajectory_ready" => get(row, "trajectory_ready", missing),
                "residuals_pass" => get(row, "residuals_pass", missing),
                "state_drift_pass" => get(row, "state_drift_pass", missing),
                "global_state_drift_pass" =>
                    get(row, "global_state_drift_pass", missing),
                "window_continuation_pass" =>
                    get(row, "window_continuation_pass", missing),
                "blocking_reasons" => get(row, "blocking_reasons", missing),
                "review_reasons" => get(row, "review_reasons", missing),
                "max_residual_ratio" => max_ratio,
                "dominant_residual" => dominant_residual,
                "max_mass_balance_residual" =>
                    get(row, "max_mass_balance_residual", missing),
                "max_mass_balance_ratio" =>
                    get(residual_ratios, "max_mass_balance_residual", missing),
                "max_rhs_residual" => get(row, "max_rhs_residual", missing),
                "max_rhs_ratio" => get(residual_ratios, "max_rhs_residual", missing),
                "max_stationarity_residual" =>
                    get(row, "max_stationarity_residual", missing),
                "max_stationarity_ratio" =>
                    get(residual_ratios, "max_stationarity_residual", missing),
                "max_lower_complementarity_residual" =>
                    get(row, "max_lower_complementarity_residual", missing),
                "max_lower_complementarity_ratio" =>
                    get(residual_ratios, "max_lower_complementarity_residual", missing),
                "max_upper_complementarity_residual" =>
                    get(row, "max_upper_complementarity_residual", missing),
                "max_upper_complementarity_ratio" =>
                    get(residual_ratios, "max_upper_complementarity_residual", missing),
                "max_state_relative_rmse" =>
                    get(row, "max_state_relative_rmse", missing),
                "global_max_state_relative_rmse" =>
                    get(row, "global_max_state_relative_rmse", missing),
            ),
        )
    end
    return rows
end

function _reduced_mpcc_failure_residual_rows(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    thresholds = _reduced_mpcc_failure_threshold_dict(attempt.viability_report.thresholds)
    for row in eachrow(attempt.viability_report.viability_table)
        residual_values = _reduced_mpcc_failure_row_residual_values(row)
        residual_ratios = Dict(
            key => _reduced_mpcc_failure_ratio(value, thresholds[key]) for
            (key, value) in residual_values
        )
        dominant_residual, _ = _reduced_mpcc_failure_dominant_ratio(residual_ratios)
        for key in sort(collect(keys(residual_values)))
            value = residual_values[key]
            threshold = thresholds[key]
            ratio = residual_ratios[key]
            push!(
                rows,
                Dict{String, Any}(
                    "candidate_id" => get(row, "candidate_id", missing),
                    "source_type" => get(row, "source_type", missing),
                    "window_index" => get(row, "window_index", missing),
                    "traffic_light" => get(row, "traffic_light", missing),
                    "viability_class" => get(row, "viability_class", missing),
                    "residual_name" => key,
                    "residual_value" => value,
                    "threshold" => threshold,
                    "ratio" => ratio,
                    "within_threshold" =>
                        _reduced_mpcc_failure_isfinite_number(ratio) ? ratio <= 1.0 :
                        false,
                    "is_dominant_residual" => key == dominant_residual,
                ),
            )
        end
    end
    return rows
end

function _reduced_mpcc_failure_mass_balance_rows(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    model::MetabolicModel,
    top_n::Int,
)::Vector{Dict{String, Any}}
    rows = Dict{String, Any}[]
    threshold = attempt.viability_report.thresholds.max_mass_balance_residual
    attempt_max_key = nothing
    attempt_max_abs = -Inf
    viability_by_id = Dict(
        String(row["candidate_id"]) => row for row in eachrow(attempt.viability_report.viability_table)
    )

    for (index, comparison) in enumerate(attempt.continuation_result.window_comparisons)
        candidate_id = _reduced_mpcc_failure_window_id(index)
        viability_row = get(viability_by_id, candidate_id, nothing)
        diagnostics = comparison.trajectory_candidate.candidate_diagnostics
        flux = diagnostics.flux
        size(model.S, 2) == size(flux, 1) || throw(
            ArgumentError(
                "Reduced MPCC windowed failure diagnostics model reaction count does not match candidate flux dimension.",
            ),
        )
        size(model.S, 1) == length(model.met_ids) || throw(
            ArgumentError(
                "Reduced MPCC windowed failure diagnostics model metabolite IDs do not match S rows.",
            ),
        )
        candidate_rows = Dict{String, Any}[]
        for e in axes(flux, 2), j in axes(flux, 3)
            residual = model.S * flux[:, e, j]
            for m in eachindex(residual)
                abs_residual = abs(Float64(residual[m]))
                key = (candidate_id, e, j, m)
                if abs_residual > attempt_max_abs
                    attempt_max_abs = abs_residual
                    attempt_max_key = key
                end
                push!(
                    candidate_rows,
                    Dict{String, Any}(
                        "candidate_id" => candidate_id,
                        "window_index" => index,
                        "element_index" => e,
                        "collocation_index" => j,
                        "metabolite_index" => m,
                        "metabolite_id" => model.met_ids[m],
                        "mass_balance_residual" => Float64(residual[m]),
                        "abs_mass_balance_residual" => abs_residual,
                        "threshold" => threshold,
                        "ratio" => _reduced_mpcc_failure_ratio(abs_residual, threshold),
                        "is_window_max" => false,
                        "is_attempt_max" => false,
                        "traffic_light" =>
                            viability_row === nothing ? missing :
                            get(viability_row, "traffic_light", missing),
                        "viability_class" =>
                            viability_row === nothing ? missing :
                            get(viability_row, "viability_class", missing),
                        "solver_status" =>
                            viability_row === nothing ? missing :
                            get(viability_row, "solver_status", missing),
                    ),
                )
            end
        end
        sort!(
            candidate_rows;
            by = row -> -Float64(row["abs_mass_balance_residual"]),
        )
        !isempty(candidate_rows) && (candidate_rows[1]["is_window_max"] = true)
        append!(rows, first(candidate_rows, min(top_n, length(candidate_rows))))
    end

    for row in rows
        row["is_attempt_max"] =
            attempt_max_key !== nothing &&
            row["candidate_id"] == attempt_max_key[1] &&
            row["element_index"] == attempt_max_key[2] &&
            row["collocation_index"] == attempt_max_key[3] &&
            row["metabolite_index"] == attempt_max_key[4]
    end
    return rows
end

function _reduced_mpcc_failure_metadata(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    window_rows::Vector{Dict{String, Any}},
    residual_rows::Vector{Dict{String, Any}},
    mass_rows::Vector{Dict{String, Any}},
)::Dict{String, Any}
    first_non_green = _reduced_mpcc_failure_first_row(
        window_rows,
        row -> get(row, "source_type", "") == "windowed_continuation_window" &&
               get(row, "traffic_light", "") != "green",
    )
    first_red = _reduced_mpcc_failure_first_row(
        window_rows,
        row -> get(row, "source_type", "") == "windowed_continuation_window" &&
               get(row, "traffic_light", "") == "red",
    )
    first_not_residual_feasible = _reduced_mpcc_failure_first_row(
        window_rows,
        row -> get(row, "source_type", "") == "windowed_continuation_window" &&
               get(row, "residual_feasible", false) !== true,
    )
    dominant_residual_row = _reduced_mpcc_failure_max_ratio_row(residual_rows)
    dominant_mass_row = _reduced_mpcc_failure_max_mass_balance_row(mass_rows)
    return Dict{String, Any}(
        "diagnostic_type" => REDUCED_DCDFBA_MPCC_WINDOWED_FAILURE_DIAGNOSTIC_TYPE,
        "target_horizon" => get(attempt.metadata, "target_horizon", missing),
        "horizon_reached" => get(attempt.metadata, "horizon_reached", missing),
        "target_completed" => get(attempt.metadata, "target_completed", false),
        "attempt_traffic_light" => get(attempt.metadata, "attempt_traffic_light", missing),
        "attempt_viable" => get(attempt.metadata, "attempt_viable", false),
        "n_window_rows" => count(
            row -> get(row, "source_type", "") == "windowed_continuation_window",
            window_rows,
        ),
        "n_red_windows" => count(
            row -> get(row, "source_type", "") == "windowed_continuation_window" &&
                   get(row, "traffic_light", "") == "red",
            window_rows,
        ),
        "n_yellow_windows" => count(
            row -> get(row, "source_type", "") == "windowed_continuation_window" &&
                   get(row, "traffic_light", "") == "yellow",
            window_rows,
        ),
        "first_non_green_window_id" =>
            _reduced_mpcc_failure_row_value(first_non_green, "candidate_id"),
        "first_non_green_window_index" =>
            _reduced_mpcc_failure_row_value(first_non_green, "window_index"),
        "first_non_green_failure_cause" =>
            _reduced_mpcc_failure_row_value(first_non_green, "failure_cause"),
        "first_red_window_id" => _reduced_mpcc_failure_row_value(first_red, "candidate_id"),
        "first_red_window_index" => _reduced_mpcc_failure_row_value(first_red, "window_index"),
        "first_red_failure_cause" =>
            _reduced_mpcc_failure_row_value(first_red, "failure_cause"),
        "first_not_residual_feasible_window_id" =>
            _reduced_mpcc_failure_row_value(first_not_residual_feasible, "candidate_id"),
        "first_not_residual_feasible_window_index" =>
            _reduced_mpcc_failure_row_value(first_not_residual_feasible, "window_index"),
        "dominant_residual_candidate_id" =>
            _reduced_mpcc_failure_row_value(dominant_residual_row, "candidate_id"),
        "dominant_residual_name" =>
            _reduced_mpcc_failure_row_value(dominant_residual_row, "residual_name"),
        "dominant_residual_value" =>
            _reduced_mpcc_failure_row_value(dominant_residual_row, "residual_value"),
        "dominant_residual_threshold" =>
            _reduced_mpcc_failure_row_value(dominant_residual_row, "threshold"),
        "dominant_residual_ratio" =>
            _reduced_mpcc_failure_row_value(dominant_residual_row, "ratio"),
        "dominant_mass_balance_candidate_id" =>
            _reduced_mpcc_failure_row_value(dominant_mass_row, "candidate_id"),
        "dominant_mass_balance_window_index" =>
            _reduced_mpcc_failure_row_value(dominant_mass_row, "window_index"),
        "dominant_mass_balance_element_index" =>
            _reduced_mpcc_failure_row_value(dominant_mass_row, "element_index"),
        "dominant_mass_balance_collocation_index" =>
            _reduced_mpcc_failure_row_value(dominant_mass_row, "collocation_index"),
        "dominant_mass_balance_metabolite_id" =>
            _reduced_mpcc_failure_row_value(dominant_mass_row, "metabolite_id"),
        "dominant_mass_balance_residual" =>
            _reduced_mpcc_failure_row_value(dominant_mass_row, "mass_balance_residual"),
        "dominant_mass_balance_ratio" =>
            _reduced_mpcc_failure_row_value(dominant_mass_row, "ratio"),
        "recommended_next_action" =>
            _reduced_mpcc_failure_recommended_action(first_red, first_non_green),
        "outputs_written" => false,
        "failure_diagnostic_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "scientific_baseline" => "full_dfba_cold_deferred",
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" =>
            "Reduced MPCC windowed failure diagnostics; identifies numerical blockers and does not validate a scientific simulation.",
    )
end

function _reduced_mpcc_failure_threshold_dict(
    thresholds::ReducedDCDFBAMPCCSimulationViabilityThresholds,
)::Dict{String, Float64}
    return Dict{String, Float64}(
        "max_rhs_residual" => thresholds.max_rhs_residual,
        "max_mass_balance_residual" => thresholds.max_mass_balance_residual,
        "max_lower_bound_violation" => thresholds.max_lower_bound_violation,
        "max_upper_bound_violation" => thresholds.max_upper_bound_violation,
        "max_stationarity_residual" => thresholds.max_stationarity_residual,
        "max_lower_complementarity_residual" =>
            thresholds.max_lower_complementarity_residual,
        "max_upper_complementarity_residual" =>
            thresholds.max_upper_complementarity_residual,
    )
end

function _reduced_mpcc_failure_row_residual_values(row)::Dict{String, Any}
    return Dict{String, Any}(
        "max_rhs_residual" => get(row, "max_rhs_residual", missing),
        "max_mass_balance_residual" => get(row, "max_mass_balance_residual", missing),
        "max_lower_bound_violation" => get(row, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" => get(row, "max_upper_bound_violation", missing),
        "max_stationarity_residual" => get(row, "max_stationarity_residual", missing),
        "max_lower_complementarity_residual" =>
            get(row, "max_lower_complementarity_residual", missing),
        "max_upper_complementarity_residual" =>
            get(row, "max_upper_complementarity_residual", missing),
    )
end

function _reduced_mpcc_failure_cause(row, dominant_residual, max_ratio)::String
    blocking = String(get(row, "blocking_reasons", ""))
    traffic_light = String(get(row, "traffic_light", ""))
    viability_class = String(get(row, "viability_class", ""))
    if occursin("scientific_guardrail_violation", blocking)
        return "scientific_guardrail_violation"
    elseif occursin("source_row_not_completed", blocking)
        return "windowed_continuation_incomplete"
    elseif occursin("candidate_not_residual_feasible", blocking) ||
           occursin("residual_thresholds_failed", blocking) ||
           (_reduced_mpcc_failure_isfinite_number(max_ratio) && max_ratio > 1.0)
        return "residual_threshold_exceeded:" * String(dominant_residual)
    elseif traffic_light == "yellow" &&
           viability_class == "iteration_limit_residual_feasible_candidate"
        return "iteration_limit_residual_feasible"
    elseif occursin("candidate_not_trajectory_ready", blocking)
        return "candidate_not_trajectory_ready"
    elseif occursin("global_state_drift_too_large", blocking)
        return "global_state_drift_too_large"
    elseif occursin("state_drift_too_large", blocking)
        return "state_drift_too_large"
    elseif traffic_light == "green"
        return "none"
    else
        return "inspect_window_diagnostics"
    end
end

function _reduced_mpcc_failure_dominant_ratio(ratios::Dict)::Tuple{String, Any}
    finite = [
        (String(key), Float64(value)) for (key, value) in ratios if
        _reduced_mpcc_failure_isfinite_number(value)
    ]
    isempty(finite) && return ("unavailable", missing)
    order = sortperm([(-value, key) for (key, value) in finite])
    key, value = finite[first(order)]
    return key, value
end

function _reduced_mpcc_failure_ratio(value, threshold)
    _reduced_mpcc_failure_isfinite_number(value) || return missing
    _reduced_mpcc_failure_isfinite_number(threshold) || return missing
    Float64(threshold) > 0.0 || return missing
    return abs(Float64(value)) / Float64(threshold)
end

function _reduced_mpcc_failure_first_row(rows::Vector{Dict{String, Any}}, predicate)
    index = findfirst(predicate, rows)
    return index === nothing ? nothing : rows[index]
end

function _reduced_mpcc_failure_max_ratio_row(rows::Vector{Dict{String, Any}})
    candidates = [
        row for row in rows if _reduced_mpcc_failure_isfinite_number(get(row, "ratio", missing))
    ]
    isempty(candidates) && return nothing
    order = sortperm([(-Float64(row["ratio"]), String(row["candidate_id"])) for row in candidates])
    return candidates[first(order)]
end

function _reduced_mpcc_failure_max_mass_balance_row(rows::Vector{Dict{String, Any}})
    candidates = [
        row for row in rows if
        _reduced_mpcc_failure_isfinite_number(get(row, "abs_mass_balance_residual", missing))
    ]
    isempty(candidates) && return nothing
    order = sortperm([
        (-Float64(row["abs_mass_balance_residual"]), String(row["candidate_id"])) for
        row in candidates
    ])
    return candidates[first(order)]
end

function _reduced_mpcc_failure_recommended_action(first_red, first_non_green)::String
    row = first_red === nothing ? first_non_green : first_red
    row === nothing && return "review_green_attempt_before_scientific_use"
    cause = String(get(row, "failure_cause", "inspect_window_diagnostics"))
    if occursin("max_mass_balance_residual", cause)
        return "inspect_mass_balance_row_scaling_and_flux_starts"
    elseif occursin("residual_threshold_exceeded", cause)
        return "inspect_dominant_residual_scaling_and_starts"
    elseif cause == "iteration_limit_residual_feasible"
        return "increase_ipopt_iterations_or_improve_solver_termination"
    elseif occursin("state_drift", cause)
        return "reduce_windowed_state_drift"
    else
        return "inspect_windowed_failure_diagnostics"
    end
end

function _reduced_mpcc_failure_row_value(row, key::AbstractString)
    row === nothing && return missing
    return get(row, String(key), missing)
end

function _reduced_mpcc_failure_window_id(index::Int)::String
    return "window_" * lpad(string(index), 3, '0')
end

function _reduced_mpcc_failure_window_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_failure_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_WINDOWED_FAILURE_WINDOW_COLUMNS
        )...,
    )
end

function _reduced_mpcc_failure_residual_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_failure_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_WINDOWED_FAILURE_RESIDUAL_COLUMNS
        )...,
    )
end

function _reduced_mpcc_failure_mass_balance_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_reduced_mpcc_failure_table_scalar(get(row, column, missing)) for row in rows] for
            column in REDUCED_DCDFBA_MPCC_WINDOWED_FAILURE_MASS_BALANCE_COLUMNS
        )...,
    )
end

function _reduced_mpcc_failure_isfinite_number(value)::Bool
    value === missing && return false
    value === nothing && return false
    return try
        isfinite(Float64(value))
    catch
        false
    end
end

function _reduced_mpcc_failure_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end
