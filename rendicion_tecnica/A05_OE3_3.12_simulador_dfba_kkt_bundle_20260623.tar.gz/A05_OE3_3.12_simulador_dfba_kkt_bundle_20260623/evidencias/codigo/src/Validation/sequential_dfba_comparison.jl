import HiGHS
import OrdinaryDiffEq

const SEQUENTIAL_DFBA_COMPARISON_SUMMARY_COLUMNS = [
    "model_scope",
    "model_id",
    "retcode",
    "termination_reason",
    "initial_time",
    "final_time",
    "n_saved_points",
    "n_states",
    "n_fluxes",
    "initial_biomass",
    "final_biomass",
    "initial_glucose",
    "final_glucose",
    "initial_fructose",
    "final_fructose",
    "initial_total_sugar",
    "final_total_sugar",
    "sugar_consumed",
    "initial_ethanol",
    "final_ethanol",
    "ethanol_produced",
    "final_oxygen",
    "mode_count_growth",
    "mode_count_turnover",
    "mode_count_sugar_depleted",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "min_state_value",
    "has_negative_saved_states",
    "simulation_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
    "reconstruct_fluxes",
    "oxygen_derivative_policy",
    "carbohydrate_derivative_policy",
]

const SEQUENTIAL_DFBA_STATE_METRIC_COLUMNS = [
    "state_name",
    "initial_reduced",
    "initial_full",
    "final_reduced",
    "final_full",
    "final_difference_full_minus_reduced",
    "max_abs_difference",
    "rmse",
    "relative_rmse",
    "reduced_min",
    "reduced_max",
    "full_min",
    "full_max",
    "notes",
]

const SEQUENTIAL_DFBA_OXYGEN_NOTE =
    "oxygen remains forced zero; reduced r_1992 is absent/disabled and full r_1992 is present/closed by bounds; r_0001 is not used as oxygen"
const SEQUENTIAL_DFBA_CARBOHYDRATE_NOTE =
    "carbohydrate dy[8] remains empirical and is not driven by r_4048"
const SEQUENTIAL_DFBA_INTERPRETATION_NOTE =
    "This is a short diagnostic comparison. Full and reduced networks are not equivalent. " *
    "Differences may reflect model reduction, network size, LP degeneracy, ODE adaptivity, and active-set changes. " *
    "Fluxes are not compared by default."
const SEQUENTIAL_DFBA_RUNTIME_POLICY_NOTE =
    "Sequential full-vs-reduced comparison defaults to short smoke horizons. " *
    "Long full-model comparisons require explicit opt-in and are capped at the configured hard horizon."

"""
    SequentialDFBARuntimePolicy(; kwargs...)

Runtime guardrails for full-vs-reduced sequential DFBA comparison runs. The
default policy keeps scripts short, permits manual opt-in up to 72 hours, and
guards against accidentally dense output grids.
"""
struct SequentialDFBARuntimePolicy
    smoke_tfinal_hours::Float64
    manual_tfinal_hours::Float64
    hard_tfinal_hours::Float64
    min_saveat_hours::Float64
    max_saved_points::Int
    allow_long_full::Bool
    allow_dense_output::Bool
end

function SequentialDFBARuntimePolicy(;
    smoke_tfinal_hours::Real = 0.25,
    manual_tfinal_hours::Real = 2.0,
    hard_tfinal_hours::Real = 72.0,
    min_saveat_hours::Real = 0.25,
    max_saved_points::Integer = 289,
    allow_long_full::Bool = false,
    allow_dense_output::Bool = false,
)::SequentialDFBARuntimePolicy
    smoke_tfinal = Float64(smoke_tfinal_hours)
    manual_tfinal = Float64(manual_tfinal_hours)
    hard_tfinal = Float64(hard_tfinal_hours)
    min_saveat = Float64(min_saveat_hours)
    max_points = Int(max_saved_points)

    all(isfinite, (smoke_tfinal, manual_tfinal, hard_tfinal, min_saveat)) ||
        error("Sequential DFBA runtime policy limits must be finite.")
    smoke_tfinal >= 0.0 ||
        error("Sequential DFBA runtime policy smoke_tfinal_hours must be non-negative.")
    manual_tfinal >= smoke_tfinal ||
        error("Sequential DFBA runtime policy manual_tfinal_hours must be >= smoke_tfinal_hours.")
    hard_tfinal >= manual_tfinal ||
        error("Sequential DFBA runtime policy hard_tfinal_hours must be >= manual_tfinal_hours.")
    min_saveat > 0.0 ||
        error("Sequential DFBA runtime policy min_saveat_hours must be positive.")
    max_points >= 2 ||
        error("Sequential DFBA runtime policy max_saved_points must be at least 2.")

    return SequentialDFBARuntimePolicy(
        smoke_tfinal,
        manual_tfinal,
        hard_tfinal,
        min_saveat,
        max_points,
        allow_long_full,
        allow_dense_output,
    )
end

"""
    SequentialDFBAComparisonResult

Container for short full-vs-reduced sequential DFBA state comparison reports.
Flux comparison is intentionally excluded by default because the full and
reduced networks are different flux spaces.
"""
struct SequentialDFBAComparisonResult
    reduced_result::SimulationResult
    full_result::SimulationResult
    summary_table::DataFrame
    state_metrics_table::DataFrame
    state_timeseries_table::DataFrame
    metadata::Dict{String, Any}
end

"""
    compare_sequential_dfba_full_reduced(reduced_model, reduced_reaction_map, full_model, full_reaction_map; kwargs...)

Run matching short sequential DFBA simulations for the reduced and full models,
then compare their 19 shared fermentation state trajectories. This report is a
diagnostic state comparison only; it does not compare fluxes by default.
"""
function compare_sequential_dfba_full_reduced(
    reduced_model::MetabolicModel,
    reduced_reaction_map::ReactionMap,
    full_model::MetabolicModel,
    full_reaction_map::ReactionMap;
    tspan::Tuple{Float64, Float64} = (0.0, 0.25),
    saveat = 0.25,
    y0::AbstractVector = zenteno_state_to_vector(default_zenteno_initial_state()),
    algorithm = OrdinaryDiffEq.Tsit5(),
    reconstruct_fluxes::Bool = false,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    lp_atol::Real = 1.0e-8,
    ode_abstol::Real = 1.0e-8,
    ode_reltol::Real = 1.0e-8,
    nonnegative::Bool = true,
    stop_on_sugar_depletion::Bool = true,
    sugar_depletion_tol::Real = 1.0e-6,
    adaptive::Bool = true,
    dt = nothing,
    progress_interval_seconds::Real = 0.0,
    max_rhs_calls = nothing,
    max_walltime_seconds = nothing,
    runtime_policy::SequentialDFBARuntimePolicy = SequentialDFBARuntimePolicy(),
)::SequentialDFBAComparisonResult
    _sequential_dfba_runtime_policy_report(tspan, saveat, reconstruct_fluxes, runtime_policy)

    _validate_sequential_dfba_reaction_map(reduced_model, reduced_reaction_map, "reduced")
    _validate_sequential_dfba_reaction_map(full_model, full_reaction_map, "full")
    _assert_sequential_dfba_oxygen_not_r0001(reduced_reaction_map, "reduced")
    _assert_sequential_dfba_oxygen_not_r0001(full_reaction_map, "full")

    reduced_lb = copy(reduced_model.lb)
    reduced_ub = copy(reduced_model.ub)
    full_lb = copy(full_model.lb)
    full_ub = copy(full_model.ub)

    common_kwargs = (
        y0 = y0,
        tspan = tspan,
        optimizer = optimizer,
        silent = silent,
        lp_atol = lp_atol,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        saveat = saveat,
        algorithm = algorithm,
        adaptive = adaptive,
        dt = dt,
        nonnegative = nonnegative,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
        reconstruct_fluxes = reconstruct_fluxes,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
    )

    reduced_result = simulate_reduced_dfba(reduced_model, reduced_reaction_map; common_kwargs...)
    full_result = simulate_full_dfba(full_model, full_reaction_map; common_kwargs...)

    _assert_sequential_dfba_bounds_unchanged(reduced_model, reduced_lb, reduced_ub, "reduced")
    _assert_sequential_dfba_bounds_unchanged(full_model, full_lb, full_ub, "full")

    return _sequential_dfba_comparison_from_results(
        reduced_result,
        full_result;
        reduced_model_id = reduced_model.model_id,
        full_model_id = full_model.model_id,
        tspan = tspan,
        saveat = saveat,
        algorithm_label = _sequential_dfba_algorithm_label(algorithm),
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        lp_atol = lp_atol,
        reconstruct_fluxes = reconstruct_fluxes,
        adaptive = adaptive,
        dt = dt,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
        runtime_policy = runtime_policy,
    )
end

"""
    export_sequential_dfba_comparison(comparison, output_dir; overwrite=false)

Write CSV/TOML report artifacts for a sequential full-vs-reduced DFBA state
comparison and return paths keyed by artifact role.
"""
function export_sequential_dfba_comparison(
    comparison::SequentialDFBAComparisonResult,
    output_dir::AbstractString;
    overwrite::Bool = false,
)::Dict{String, String}
    output_path = normpath(String(output_dir))
    if ispath(output_path) && !isdir(output_path)
        error("Sequential DFBA comparison output_dir exists and is not a directory: $output_path")
    end

    paths = Dict{String, String}(
        "summary" => joinpath(output_path, "sequential_dfba_comparison_summary.csv"),
        "state_metrics" => joinpath(output_path, "sequential_dfba_state_metrics.csv"),
        "state_timeseries" => joinpath(output_path, "sequential_dfba_state_timeseries.csv"),
        "metadata" => joinpath(output_path, "sequential_dfba_comparison_metadata.toml"),
    )
    existing_targets = [path for path in values(paths) if isfile(path)]
    if !overwrite && !isempty(existing_targets)
        error(
            "Sequential DFBA comparison export target file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end

    mkpath(output_path)
    if overwrite
        for path in values(paths)
            isfile(path) && rm(path)
        end
    end
    CSV.write(paths["summary"], comparison.summary_table)
    CSV.write(paths["state_metrics"], comparison.state_metrics_table)
    CSV.write(paths["state_timeseries"], comparison.state_timeseries_table)
    open(paths["metadata"], "w") do io
        TOML.print(io, _sequential_dfba_toml_normalize(comparison.metadata))
    end
    return paths
end

function _sequential_dfba_comparison_from_results(
    reduced_result::SimulationResult,
    full_result::SimulationResult;
    reduced_model_id::AbstractString,
    full_model_id::AbstractString,
    tspan::Tuple{Float64, Float64},
    saveat,
    algorithm_label::AbstractString,
    ode_abstol::Real,
    ode_reltol::Real,
    lp_atol::Real,
    reconstruct_fluxes::Bool,
    adaptive::Bool = true,
    dt = nothing,
    progress_interval_seconds::Real = 0.0,
    max_rhs_calls = nothing,
    max_walltime_seconds = nothing,
    runtime_policy::SequentialDFBARuntimePolicy = SequentialDFBARuntimePolicy(),
)::SequentialDFBAComparisonResult
    state_names = _sequential_dfba_validate_results(reduced_result, full_result)
    summary_table = _sequential_dfba_summary_table(
        reduced_result,
        full_result;
        reduced_model_id = reduced_model_id,
        full_model_id = full_model_id,
    )
    state_metrics_table = _sequential_dfba_state_metrics_table(reduced_result, full_result, state_names)
    state_timeseries_table = _sequential_dfba_state_timeseries_table(reduced_result, full_result, state_names)
    metadata = _sequential_dfba_comparison_metadata(
        reduced_result,
        full_result,
        state_names;
        reduced_model_id = reduced_model_id,
        full_model_id = full_model_id,
        tspan = tspan,
        saveat = saveat,
        algorithm_label = algorithm_label,
        ode_abstol = ode_abstol,
        ode_reltol = ode_reltol,
        lp_atol = lp_atol,
        reconstruct_fluxes = reconstruct_fluxes,
        adaptive = adaptive,
        dt = dt,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
        runtime_policy = runtime_policy,
    )

    return SequentialDFBAComparisonResult(
        reduced_result,
        full_result,
        summary_table,
        state_metrics_table,
        state_timeseries_table,
        metadata,
    )
end

function _sequential_dfba_validate_results(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
)::Vector{String}
    reduced_result.time == full_result.time || error(
        "Sequential DFBA comparison requires identical saved time vectors. " *
        "Got reduced=$(reduced_result.time) and full=$(full_result.time).",
    )
    n_time = length(reduced_result.time)
    size(reduced_result.states, 1) == 19 || error(
        "Sequential DFBA comparison expects reduced states to have 19 rows, got $(size(reduced_result.states, 1)).",
    )
    size(full_result.states, 1) == 19 || error(
        "Sequential DFBA comparison expects full states to have 19 rows, got $(size(full_result.states, 1)).",
    )
    size(reduced_result.states, 2) == n_time || error(
        "Reduced state column count $(size(reduced_result.states, 2)) does not match saved times $n_time.",
    )
    size(full_result.states, 2) == n_time || error(
        "Full state column count $(size(full_result.states, 2)) does not match saved times $n_time.",
    )

    reduced_names = _state_names(reduced_result)
    full_names = _state_names(full_result)
    reduced_names == full_names || error(
        "Sequential DFBA comparison requires matching state names. " *
        "Got reduced=$(reduced_names) and full=$(full_names).",
    )
    length(reduced_names) == 19 || error(
        "Sequential DFBA comparison expects 19 state names, got $(length(reduced_names)).",
    )
    return reduced_names
end

function _sequential_dfba_summary_table(
    reduced_result::SimulationResult,
    full_result::SimulationResult;
    reduced_model_id::AbstractString,
    full_model_id::AbstractString,
)::DataFrame
    rows = [
        _sequential_dfba_summary_row(reduced_result, reduced_model_id),
        _sequential_dfba_summary_row(full_result, full_model_id),
    ]
    return DataFrame(
        (
            column => [_sequential_dfba_table_scalar(get(row, column, missing)) for row in rows] for
            column in SEQUENTIAL_DFBA_COMPARISON_SUMMARY_COLUMNS
        )...,
    )
end

function _sequential_dfba_summary_row(result::SimulationResult, model_id::AbstractString)::Dict{String, Any}
    summary = summarize_simulation(result)
    counts = get(summary, "mode_counts", Dict{Symbol, Int}())
    return Dict{String, Any}(
        "model_scope" => get(summary, "model_scope", "unknown"),
        "model_id" => String(model_id),
        "retcode" => get(summary, "retcode", nothing),
        "termination_reason" => get(summary, "termination_reason", nothing),
        "initial_time" => get(summary, "initial_time", nothing),
        "final_time" => get(summary, "final_time", nothing),
        "n_saved_points" => get(summary, "n_saved_points", nothing),
        "n_states" => get(summary, "n_states", nothing),
        "n_fluxes" => get(summary, "n_fluxes", nothing),
        "initial_biomass" => get(summary, "initial_biomass", nothing),
        "final_biomass" => get(summary, "final_biomass", nothing),
        "initial_glucose" => get(summary, "initial_glucose", nothing),
        "final_glucose" => get(summary, "final_glucose", nothing),
        "initial_fructose" => get(summary, "initial_fructose", nothing),
        "final_fructose" => get(summary, "final_fructose", nothing),
        "initial_total_sugar" => get(summary, "initial_total_sugar", nothing),
        "final_total_sugar" => get(summary, "final_total_sugar", nothing),
        "sugar_consumed" => get(summary, "sugar_consumed", nothing),
        "initial_ethanol" => get(summary, "initial_ethanol", nothing),
        "final_ethanol" => get(summary, "final_ethanol", nothing),
        "ethanol_produced" => get(summary, "ethanol_produced", nothing),
        "final_oxygen" => get(summary, "final_oxygen", nothing),
        "mode_count_growth" => _summary_mode_count(counts, :growth),
        "mode_count_turnover" => _summary_mode_count(counts, :turnover),
        "mode_count_sugar_depleted" => _summary_mode_count(counts, :sugar_depleted),
        "max_mass_balance_residual" => get(summary, "max_mass_balance_residual", nothing),
        "max_lower_bound_violation" => get(summary, "max_lower_bound_violation", nothing),
        "max_upper_bound_violation" => get(summary, "max_upper_bound_violation", nothing),
        "min_state_value" => get(summary, "min_state_value", nothing),
        "has_negative_saved_states" => get(summary, "has_negative_saved_states", nothing),
        "simulation_elapsed_seconds" => get(summary, "simulation_elapsed_seconds", missing),
        "rhs_call_count" => get(summary, "rhs_call_count", missing),
        "total_lp_solve_count" => get(summary, "total_lp_solve_count", missing),
        "reconstruct_fluxes" => get(summary, "reconstruct_fluxes", missing),
        "oxygen_derivative_policy" => get(summary, "oxygen_derivative_policy", nothing),
        "carbohydrate_derivative_policy" => get(summary, "carbohydrate_derivative_policy", nothing),
    )
end

function _sequential_dfba_state_metrics_table(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
    state_names::Vector{String},
)::DataFrame
    rows = [
        _sequential_dfba_state_metric_row(
            state_name,
            view(reduced_result.states, i, :),
            view(full_result.states, i, :),
        ) for (i, state_name) in enumerate(state_names)
    ]
    return DataFrame(
        (
            column => [_sequential_dfba_table_scalar(get(row, column, missing)) for row in rows] for
            column in SEQUENTIAL_DFBA_STATE_METRIC_COLUMNS
        )...,
    )
end

function _sequential_dfba_state_metric_row(
    state_name::AbstractString,
    reduced_values,
    full_values,
)::Dict{String, Any}
    reduced = Float64.(collect(reduced_values))
    full = Float64.(collect(full_values))
    difference = full .- reduced
    rmse = sqrt(sum(abs2, difference) / length(difference))
    denominator = max(maximum(abs.(full)), maximum(abs.(reduced)), eps(Float64))
    relative_rmse = rmse / denominator

    return Dict{String, Any}(
        "state_name" => String(state_name),
        "initial_reduced" => reduced[begin],
        "initial_full" => full[begin],
        "final_reduced" => reduced[end],
        "final_full" => full[end],
        "final_difference_full_minus_reduced" => difference[end],
        "max_abs_difference" => maximum(abs.(difference)),
        "rmse" => rmse,
        "relative_rmse" => relative_rmse,
        "reduced_min" => minimum(reduced),
        "reduced_max" => maximum(reduced),
        "full_min" => minimum(full),
        "full_max" => maximum(full),
        "notes" => _sequential_dfba_state_note(state_name),
    )
end

function _sequential_dfba_state_timeseries_table(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
    state_names::Vector{String},
)::DataFrame
    table = DataFrame("time" => copy(reduced_result.time))
    for (i, state_name) in enumerate(state_names)
        reduced_values = collect(view(reduced_result.states, i, :))
        full_values = collect(view(full_result.states, i, :))
        prefix = lowercase(String(state_name))
        table[!, "$(prefix)_reduced"] = reduced_values
        table[!, "$(prefix)_full"] = full_values
        table[!, "$(prefix)_difference_full_minus_reduced"] = full_values .- reduced_values
    end
    return table
end

function _sequential_dfba_comparison_metadata(
    reduced_result::SimulationResult,
    full_result::SimulationResult,
    state_names::Vector{String};
    reduced_model_id::AbstractString,
    full_model_id::AbstractString,
    tspan::Tuple{Float64, Float64},
    saveat,
    algorithm_label::AbstractString,
    ode_abstol::Real,
    ode_reltol::Real,
    lp_atol::Real,
    reconstruct_fluxes::Bool,
    adaptive::Bool,
    dt,
    progress_interval_seconds::Real,
    max_rhs_calls,
    max_walltime_seconds,
    runtime_policy::SequentialDFBARuntimePolicy,
)::Dict{String, Any}
    runtime_report = _sequential_dfba_runtime_policy_report(tspan, saveat, reconstruct_fluxes, runtime_policy)
    return Dict{String, Any}(
        "comparison_type" => "sequential_dfba_full_vs_reduced",
        "tspan" => tspan,
        "saveat" => saveat,
        "algorithm_label" => String(algorithm_label),
        "ode_abstol" => Float64(ode_abstol),
        "ode_reltol" => Float64(ode_reltol),
        "lp_atol" => Float64(lp_atol),
        "reconstruct_fluxes" => reconstruct_fluxes,
        "adaptive" => adaptive,
        "dt" => dt,
        "progress_interval_seconds" => Float64(progress_interval_seconds),
        "max_rhs_calls" => max_rhs_calls,
        "max_walltime_seconds" => max_walltime_seconds,
        "state_names" => copy(state_names),
        "n_states" => length(state_names),
        "n_saved_points" => length(reduced_result.time),
        "requested_duration_hours" => runtime_report.requested_duration_hours,
        "estimated_saved_points" => runtime_report.estimated_saved_points,
        "runtime_policy_label" => runtime_report.runtime_policy_label,
        "runtime_policy_smoke_tfinal_hours" => runtime_policy.smoke_tfinal_hours,
        "runtime_policy_manual_tfinal_hours" => runtime_policy.manual_tfinal_hours,
        "runtime_policy_hard_tfinal_hours" => runtime_policy.hard_tfinal_hours,
        "runtime_policy_min_saveat_hours" => runtime_policy.min_saveat_hours,
        "runtime_policy_max_saved_points" => runtime_policy.max_saved_points,
        "runtime_policy_allow_long_full" => runtime_policy.allow_long_full,
        "runtime_policy_allow_dense_output" => runtime_policy.allow_dense_output,
        "runtime_policy_long_full_run_requested" => runtime_report.long_full_run_requested,
        "runtime_policy_dense_output_requested" => runtime_report.dense_output_requested,
        "runtime_policy_flux_reconstruction_long_run_requested" =>
            runtime_report.flux_reconstruction_long_run_requested,
        "runtime_policy_note" => runtime_report.runtime_policy_note,
        "reduced_model_scope" => get(reduced_result.metadata, "model_scope", "unknown"),
        "full_model_scope" => get(full_result.metadata, "model_scope", "unknown"),
        "reduced_model_id" => String(reduced_model_id),
        "full_model_id" => String(full_model_id),
        "oxygen_mapping_note" => SEQUENTIAL_DFBA_OXYGEN_NOTE,
        "carbohydrate_mapping_note" => SEQUENTIAL_DFBA_CARBOHYDRATE_NOTE,
        "flux_comparison_included" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "interpretation_note" => SEQUENTIAL_DFBA_INTERPRETATION_NOTE,
    )
end

function _sequential_dfba_runtime_policy_report(
    tspan::Tuple{Float64, Float64},
    saveat,
    reconstruct_fluxes::Bool,
    runtime_policy::SequentialDFBARuntimePolicy,
)
    initial_time, final_time = tspan
    isfinite(initial_time) && isfinite(final_time) ||
        error("Sequential DFBA comparison tspan values must be finite.")
    final_time > initial_time ||
        error("Sequential DFBA comparison tspan must have final time greater than initial time.")
    saveat isa Real ||
        error("Sequential DFBA comparison runtime policy requires scalar numeric saveat.")
    saveat_hours = Float64(saveat)
    isfinite(saveat_hours) && saveat_hours > 0.0 ||
        error("Sequential DFBA comparison saveat must be finite and positive.")

    duration_hours = final_time - initial_time
    tolerance = 100.0 * eps(Float64)
    estimated_saved_points = Int(floor(duration_hours / saveat_hours + tolerance)) + 1
    long_full_run_requested = duration_hours > runtime_policy.manual_tfinal_hours + tolerance
    dense_output_requested =
        saveat_hours < runtime_policy.min_saveat_hours - tolerance ||
        estimated_saved_points > runtime_policy.max_saved_points
    flux_reconstruction_long_run_requested = reconstruct_fluxes && long_full_run_requested

    if duration_hours > runtime_policy.hard_tfinal_hours + tolerance
        error(
            "Sequential DFBA comparison requested duration $(duration_hours) h exceeds " *
            "hard_tfinal_hours=$(runtime_policy.hard_tfinal_hours). The supported cap is 72 h by default.",
        )
    end
    if long_full_run_requested && !runtime_policy.allow_long_full
        error(
            "Sequential DFBA comparison requested duration $(duration_hours) h exceeds " *
            "manual_tfinal_hours=$(runtime_policy.manual_tfinal_hours). Set runtime_policy.allow_long_full=true " *
            "or DFBA_SEQ_COMPARE_ALLOW_LONG_FULL=true for explicit long-run opt-in.",
        )
    end
    if saveat_hours < runtime_policy.min_saveat_hours - tolerance && !runtime_policy.allow_dense_output
        error(
            "Sequential DFBA comparison saveat=$(saveat_hours) h is below " *
            "min_saveat_hours=$(runtime_policy.min_saveat_hours). Set runtime_policy.allow_dense_output=true " *
            "or DFBA_SEQ_COMPARE_ALLOW_DENSE_OUTPUT=true for dense output.",
        )
    end
    if estimated_saved_points > runtime_policy.max_saved_points && !runtime_policy.allow_dense_output
        error(
            "Sequential DFBA comparison estimated_saved_points=$(estimated_saved_points) exceeds " *
            "max_saved_points=$(runtime_policy.max_saved_points). Increase saveat or enable dense output explicitly.",
        )
    end

    runtime_policy_label = long_full_run_requested ? "long_opt_in" : "default_short"
    return (
        requested_duration_hours = duration_hours,
        estimated_saved_points = estimated_saved_points,
        runtime_policy_label = runtime_policy_label,
        long_full_run_requested = long_full_run_requested,
        dense_output_requested = dense_output_requested,
        flux_reconstruction_long_run_requested = flux_reconstruction_long_run_requested,
        runtime_policy_note = SEQUENTIAL_DFBA_RUNTIME_POLICY_NOTE,
    )
end

function _validate_sequential_dfba_reaction_map(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    model_scope::AbstractString,
)
    report = validate_reaction_map(model, reaction_map)
    report.ok || error(
        "Sequential DFBA comparison $(String(model_scope)) reaction map validation failed. " *
        "Missing reactions: $(report.missing_required_reactions)",
    )
    return report
end

function _assert_sequential_dfba_oxygen_not_r0001(reaction_map::ReactionMap, model_scope::AbstractString)
    oxygen_id = get(reaction_map.core, "oxygen_exchange", "")
    disabled_oxygen_id = get(reaction_map.disabled_reactions, "oxygen_exchange", "")
    if strip(oxygen_id) == "r_0001" || strip(disabled_oxygen_id) == "r_0001"
        error("Sequential DFBA comparison $(String(model_scope)) oxygen_exchange must not map to r_0001.")
    end
    return nothing
end

function _assert_sequential_dfba_bounds_unchanged(
    model::MetabolicModel,
    original_lb::Vector{Float64},
    original_ub::Vector{Float64},
    model_scope::AbstractString,
)
    model.lb == original_lb || error("Sequential DFBA comparison mutated $(String(model_scope)) lower bounds.")
    model.ub == original_ub || error("Sequential DFBA comparison mutated $(String(model_scope)) upper bounds.")
    return nothing
end

function _sequential_dfba_state_note(state_name::AbstractString)::String
    name = String(state_name)
    if name == "oxygen"
        return SEQUENTIAL_DFBA_OXYGEN_NOTE
    elseif name == "carbohydrate"
        return SEQUENTIAL_DFBA_CARBOHYDRATE_NOTE
    end
    return "compared on shared 19-state trajectory order"
end

function _sequential_dfba_algorithm_label(algorithm)::String
    algorithm === nothing && return "default"
    return String(nameof(typeof(algorithm)))
end

function _sequential_dfba_table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end

function _sequential_dfba_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _sequential_dfba_toml_normalize_real(value)
    elseif value isa Tuple
        return _sequential_dfba_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _sequential_dfba_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _sequential_dfba_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _sequential_dfba_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _sequential_dfba_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _sequential_dfba_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end
