import HiGHS
import JuMP
import MathOptInterface as MOI

const DFVB_STATIC_LP_BIOLOGICAL_INTERPRETATION_NOTE =
    "Static DFVB LP smoke only: this solves a mathematical alpha-space reconstruction problem and does not validate dynamic DFVB physiology."
const DFVB_DYNAMIC_LP_BIOLOGICAL_INTERPRETATION_NOTE =
    "Dynamic DFVB LP smoke only: this applies state-dependent dFBA bounds and weighted objectives to an alpha-space reconstruction problem; it does not compute DFVB RHS derivatives or validate dynamic DFVB physiology."
const DFVB_DEFAULT_OBJECTIVE_RXN_ID = "r_2111"

"""
    StaticDFVBResult

Result container for a static DFVB alpha-space LP solve.
"""
struct StaticDFVBResult
    status::MOI.TerminationStatusCode
    primal_status::MOI.ResultStatusCode
    dual_status::MOI.ResultStatusCode
    objective_value::Float64
    objective_rxn_id::Union{Nothing, String}
    objective_reaction_index::Union{Nothing, Int}
    alpha::Vector{Float64}
    alpha_ids::Vector{String}
    fluxes::Vector{Float64}
    use_active_alpha::Bool
    mass_balance_residual::Float64
    max_lower_bound_violation::Float64
    max_upper_bound_violation::Float64
    metadata::Dict{String, Any}
end

"""
    validate_dfvb_reaction_order(model, artifacts; throw_on_error=true)

Validate that the metabolic model reaction order exactly matches the DFVB
artifact reaction order. The DFVB static LP never reorders reactions silently.
"""
function validate_dfvb_reaction_order(
    model::MetabolicModel,
    artifacts::DFVBArtifacts;
    throw_on_error::Bool = true,
)
    errors = String[]
    artifact_rxn_ids = String.(artifacts.reaction_order[!, "reaction_id"])

    if length(model.rxn_ids) != length(artifact_rxn_ids)
        push!(
            errors,
            "DFVB reaction order length mismatch: model has $(length(model.rxn_ids)) reactions, artifacts have $(length(artifact_rxn_ids)).",
        )
    else
        first_mismatch = findfirst(i -> model.rxn_ids[i] != artifact_rxn_ids[i], eachindex(model.rxn_ids))
        if first_mismatch !== nothing
            push!(
                errors,
                "DFVB reaction order mismatch at index $first_mismatch: model has $(model.rxn_ids[first_mismatch]), artifacts have $(artifact_rxn_ids[first_mismatch]).",
            )
        end
    end

    if throw_on_error && !isempty(errors)
        error(join(errors, " "))
    end

    return (ok = isempty(errors), errors = errors)
end

"""
    reconstruct_dfvb_fluxes(artifacts, alpha; use_active_alpha=true)

Reconstruct reaction fluxes from DFVB alpha variables as `v = N * alpha`.
"""
function reconstruct_dfvb_fluxes(
    artifacts::DFVBArtifacts,
    alpha::AbstractVector;
    use_active_alpha::Bool = true,
)::Vector{Float64}
    N = _dfvb_basis_matrix(artifacts, use_active_alpha)
    length(alpha) == size(N, 2) || error(
        "DFVB alpha length $(length(alpha)) does not match $(size(N, 2)) columns for alpha scope $(_dfvb_alpha_scope(use_active_alpha)).",
    )
    return Vector{Float64}(N * Float64.(alpha))
end

"""
    build_dfvb_problem(model, artifacts; objective_rxn_id="r_2111", objective_weights=nothing, use_active_alpha=true, optimizer=HiGHS.Optimizer, silent=true)

Build a static DFVB LP in alpha variables. The reconstructed flux expression is
`v = N * alpha`; model reaction bounds are enforced on `v`. No `S * v == 0`
constraints are added because `N` is assumed to be the null-space basis.
"""
function build_dfvb_problem(
    model::MetabolicModel,
    artifacts::DFVBArtifacts;
    objective_rxn_id = missing,
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}} = nothing,
    use_active_alpha::Bool = true,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
)
    validate_dfvb_reaction_order(model, artifacts; throw_on_error = true)
    objective = _dfvb_normalize_objective(
        model;
        objective_rxn_id = objective_rxn_id,
        objective_weights = objective_weights,
    )

    N = _dfvb_basis_matrix(artifacts, use_active_alpha)
    alpha_bounds = _dfvb_alpha_bounds_table(artifacts, use_active_alpha)
    alpha_ids = _dfvb_alpha_ids(artifacts, use_active_alpha)
    n_reactions = length(model.rxn_ids)
    n_alpha = size(N, 2)

    size(N, 1) == n_reactions || error(
        "DFVB basis row count $(size(N, 1)) does not match model reaction count $n_reactions.",
    )
    nrow(alpha_bounds) == n_alpha || error(
        "DFVB alpha bounds row count $(nrow(alpha_bounds)) does not match alpha column count $n_alpha for alpha scope $(_dfvb_alpha_scope(use_active_alpha)).",
    )
    length(alpha_ids) == n_alpha || error(
        "DFVB alpha id count $(length(alpha_ids)) does not match alpha column count $n_alpha for alpha scope $(_dfvb_alpha_scope(use_active_alpha)).",
    )

    lower_bounds, upper_bounds = _dfvb_alpha_bound_vectors(alpha_bounds)

    jump_model = JuMP.Model(optimizer)
    silent && JuMP.set_silent(jump_model)

    JuMP.@variable(jump_model, alpha[1:n_alpha])
    for j in 1:n_alpha
        JuMP.set_lower_bound(alpha[j], lower_bounds[j])
        JuMP.set_upper_bound(alpha[j], upper_bounds[j])
    end

    row_indices, column_indices, values = findnz(N)
    flux_expressions = [JuMP.AffExpr(0.0) for _ in 1:n_reactions]
    for k in eachindex(values)
        JuMP.add_to_expression!(
            flux_expressions[row_indices[k]],
            values[k],
            alpha[column_indices[k]],
        )
    end

    JuMP.@constraint(jump_model, lower_bound[i = 1:n_reactions], flux_expressions[i] >= model.lb[i])
    JuMP.@constraint(jump_model, upper_bound[i = 1:n_reactions], flux_expressions[i] <= model.ub[i])

    objective_expression = JuMP.AffExpr(0.0)
    for (rxn_id, weight) in objective.objective_weights
        JuMP.add_to_expression!(
            objective_expression,
            weight,
            flux_expressions[reaction_index(model, rxn_id)],
        )
    end
    JuMP.@objective(jump_model, Max, objective_expression)

    metadata = _dfvb_static_metadata(
        model,
        artifacts;
        objective_rxn_id = objective.objective_rxn_id,
        objective_reaction_index = objective.objective_index,
        objective_weights = objective.objective_weights,
        objective_type = objective.objective_type,
        objective_description = objective.objective_description,
        use_active_alpha = use_active_alpha,
        n_alpha = n_alpha,
        solver_label = "not_solved",
    )

    return (
        jump_model = jump_model,
        alpha = alpha,
        alpha_ids = alpha_ids,
        flux_expressions = flux_expressions,
        objective_rxn_id = objective.objective_rxn_id,
        objective_reaction_index = objective.objective_index,
        objective_weights = objective.objective_weights,
        objective_type = objective.objective_type,
        objective_description = objective.objective_description,
        use_active_alpha = use_active_alpha,
        alpha_scope = _dfvb_alpha_scope(use_active_alpha),
        N = N,
        metadata = metadata,
    )
end

"""
    solve_static_dfvb(model, artifacts; objective_rxn_id="r_2111", objective_weights=nothing, use_active_alpha=true, optimizer=HiGHS.Optimizer, silent=true, atol=1e-8)

Solve a static DFVB alpha-space LP and reconstruct reaction fluxes.
"""
function solve_static_dfvb(
    model::MetabolicModel,
    artifacts::DFVBArtifacts;
    objective_rxn_id = missing,
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}} = nothing,
    use_active_alpha::Bool = true,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1.0e-8,
)::StaticDFVBResult
    tolerance = Float64(atol)
    isfinite(tolerance) && tolerance > 0.0 || error("DFVB static LP atol must be finite and positive, got $atol.")

    problem = build_dfvb_problem(
        model,
        artifacts;
        objective_rxn_id = objective_rxn_id,
        objective_weights = objective_weights,
        use_active_alpha = use_active_alpha,
        optimizer = optimizer,
        silent = silent,
    )

    JuMP.optimize!(problem.jump_model)

    status = JuMP.termination_status(problem.jump_model)
    primal_status = JuMP.primal_status(problem.jump_model)
    dual_status = JuMP.dual_status(problem.jump_model)
    has_primal = primal_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT)

    alpha_values = has_primal ? Float64.(JuMP.value.(problem.alpha)) : Float64[]
    fluxes = has_primal ?
        reconstruct_dfvb_fluxes(artifacts, alpha_values; use_active_alpha = use_active_alpha) :
        Float64[]
    objective_value = has_primal ? Float64(JuMP.objective_value(problem.jump_model)) : NaN
    mass_balance_residual = has_primal ? check_mass_balance(model, fluxes; atol = tolerance) : Inf
    bound_report = has_primal ? check_bound_violations(model, fluxes; atol = tolerance) : (
        max_lower_violation = Inf,
        max_upper_violation = Inf,
        n_lower_violations = length(model.rxn_ids),
        n_upper_violations = length(model.rxn_ids),
    )

    solver_label = _solver_name(problem.jump_model)
    metadata = _dfvb_static_metadata(
        model,
        artifacts;
        objective_rxn_id = problem.objective_rxn_id,
        objective_reaction_index = problem.objective_reaction_index,
        objective_weights = problem.objective_weights,
        objective_type = problem.objective_type,
        objective_description = problem.objective_description,
        use_active_alpha = use_active_alpha,
        n_alpha = size(problem.N, 2),
        solver_label = solver_label,
    )
    metadata["primal_status"] = primal_status
    metadata["dual_status"] = dual_status
    metadata["n_lower_bound_violations"] = bound_report.n_lower_violations
    metadata["n_upper_bound_violations"] = bound_report.n_upper_violations
    metadata["objective_flux"] =
        has_primal && problem.objective_reaction_index !== nothing ? fluxes[problem.objective_reaction_index] : missing
    metadata["biomass_flux_r_2111"] = has_primal && has_reaction(model, "r_2111") ? fluxes[reaction_index(model, "r_2111")] : missing
    metadata["atp_maintenance_flux_r_4046"] =
        has_primal && has_reaction(model, "r_4046") ? fluxes[reaction_index(model, "r_4046")] : missing
    metadata["protein_flux_r_4047"] = has_primal && has_reaction(model, "r_4047") ? fluxes[reaction_index(model, "r_4047")] : missing
    metadata["r_0001_flux"] = has_primal && has_reaction(model, "r_0001") ? fluxes[reaction_index(model, "r_0001")] : missing
    metadata["r_1992_flux"] = has_primal && has_reaction(model, "r_1992") ? fluxes[reaction_index(model, "r_1992")] : missing

    return StaticDFVBResult(
        status,
        primal_status,
        dual_status,
        objective_value,
        problem.objective_rxn_id,
        problem.objective_reaction_index,
        alpha_values,
        copy(problem.alpha_ids),
        fluxes,
        use_active_alpha,
        mass_balance_residual,
        bound_report.max_lower_violation,
        bound_report.max_upper_violation,
        metadata,
    )
end

"""
    solve_dynamic_dfvb_lp(model, reaction_map, artifacts, y; params=default_zenteno_parameters(), use_active_alpha=true, optimizer=HiGHS.Optimizer, silent=true, atol=1e-8)

Solve one dynamic-bound DFVB LP smoke problem. This applies Zenteno dynamic
bounds and weighted objectives to the model, solves the alpha-space DFVB LP,
and reconstructs fluxes. It does not compute DFVB RHS derivatives or integrate
an ODE system.
"""
function solve_dynamic_dfvb_lp(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    artifacts::DFVBArtifacts,
    y::AbstractVector;
    params::ZentenoKineticParameters = default_zenteno_parameters(),
    use_active_alpha::Bool = true,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1.0e-8,
)::StaticDFVBResult
    _assert_dfvb_oxygen_not_r0001(reaction_map)

    state = zenteno_state_from_vector(y)
    bounds = zenteno_dynamic_bounds(model, reaction_map, state, params)
    dynamic_model = apply_dynamic_bounds(model, bounds)
    result = solve_static_dfvb(
        dynamic_model,
        artifacts;
        objective_weights = bounds.objective_weights,
        use_active_alpha = use_active_alpha,
        optimizer = optimizer,
        silent = silent,
        atol = atol,
    )

    _annotate_dynamic_dfvb_result!(result, bounds)
    return result
end

function _dfvb_normalize_objective(
    model::MetabolicModel;
    objective_rxn_id,
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}},
)
    resolved_objective_rxn_id = if objective_rxn_id === missing
        objective_weights === nothing ? DFVB_DEFAULT_OBJECTIVE_RXN_ID : nothing
    else
        objective_rxn_id
    end

    return _normalize_fba_objective(
        model;
        objective_rxn_id = resolved_objective_rxn_id,
        objective_weights = objective_weights,
    )
end

function _annotate_dynamic_dfvb_result!(
    result::StaticDFVBResult,
    bounds::ZentenoDynamicBounds,
)::StaticDFVBResult
    metadata = result.metadata
    metadata["problem_type"] = "dynamic_dfvb_lp"
    metadata["use_dynamic_bounds"] = true
    metadata["dynamic_mode"] = String(bounds.mode)
    metadata["dynamic_lb_update_count"] = length(bounds.lb_updates)
    metadata["dynamic_ub_update_count"] = length(bounds.ub_updates)
    metadata["dynamic_objective_term_count"] = length(bounds.objective_weights)
    metadata["dynamic_lb_update_reaction_ids"] = sort(collect(keys(bounds.lb_updates)))
    metadata["dynamic_ub_update_reaction_ids"] = sort(collect(keys(bounds.ub_updates)))
    metadata["dynamic_objective_reaction_ids"] = sort(collect(keys(bounds.objective_weights)))
    metadata["dynamic_bounds_metadata"] = copy(bounds.metadata)
    metadata["objective_type"] = "weighted"
    metadata["objective_value_is_not_biomass_flux"] = true
    metadata["carbohydrate_derivative_policy"] = "empirical_not_r_4048"
    metadata["biological_interpretation_note"] = DFVB_DYNAMIC_LP_BIOLOGICAL_INTERPRETATION_NOTE
    metadata["dfvb_rhs_implemented"] = false
    metadata["kkt_mpcc_collocation_implemented"] = false
    metadata["indices_reacciones_used"] = false
    metadata["r0001_used_as_oxygen"] = false
    metadata["oxygen_reaction_id"] = "r_1992"
    return result
end

function _dfvb_basis_matrix(artifacts::DFVBArtifacts, use_active_alpha::Bool)::SparseMatrixCSC{Float64, Int}
    return use_active_alpha ? artifacts.N_active : artifacts.N
end

function _dfvb_alpha_bounds_table(artifacts::DFVBArtifacts, use_active_alpha::Bool)::DataFrame
    return use_active_alpha ? artifacts.alpha_bounds_active : artifacts.alpha_bounds
end

function _dfvb_alpha_metadata_table(artifacts::DFVBArtifacts, use_active_alpha::Bool)::DataFrame
    return use_active_alpha ? artifacts.N_active_column_metadata : artifacts.N_column_metadata
end

function _dfvb_alpha_scope(use_active_alpha::Bool)::String
    return use_active_alpha ? "active" : "full"
end

function _dfvb_alpha_bound_vectors(alpha_bounds::DataFrame)::Tuple{Vector{Float64}, Vector{Float64}}
    lower_column = _dfvb_find_column_name(alpha_bounds, ("lower_bound", "lb", "alphalb", "alpha_lb"), "lower alpha bound")
    upper_column = _dfvb_find_column_name(alpha_bounds, ("upper_bound", "ub", "alphaub", "alpha_ub"), "upper alpha bound")

    lower_bounds = [_dfvb_problem_required_float(alpha_bounds[i, lower_column], lower_column, i) for i in axes(alpha_bounds, 1)]
    upper_bounds = [_dfvb_problem_required_float(alpha_bounds[i, upper_column], upper_column, i) for i in axes(alpha_bounds, 1)]
    for i in eachindex(lower_bounds)
        lower_bounds[i] <= upper_bounds[i] || error(
            "DFVB alpha bounds row $i has lower bound $(lower_bounds[i]) greater than upper bound $(upper_bounds[i]).",
        )
    end
    return lower_bounds, upper_bounds
end

function _dfvb_alpha_ids(artifacts::DFVBArtifacts, use_active_alpha::Bool)::Vector{String}
    metadata = _dfvb_alpha_metadata_table(artifacts, use_active_alpha)
    if "source_alpha_id" in names(metadata)
        ids = String.(metadata[!, "source_alpha_id"])
    elseif "alpha_id" in names(metadata)
        ids = String.(metadata[!, "alpha_id"])
    else
        bounds = _dfvb_alpha_bounds_table(artifacts, use_active_alpha)
        bounds_names = names(bounds)
        if "source_alpha_id" in bounds_names
            ids = String.(bounds[!, "source_alpha_id"])
        elseif "alpha_id" in bounds_names
            ids = String.(bounds[!, "alpha_id"])
        elseif "source_alpha_index" in bounds_names
            ids = ["alpha_$(Int(value))" for value in bounds[!, "source_alpha_index"]]
        elseif "alpha_index" in bounds_names
            ids = ["alpha_$(Int(value))" for value in bounds[!, "alpha_index"]]
        else
            ids = ["alpha_$i" for i in 1:size(_dfvb_basis_matrix(artifacts, use_active_alpha), 2)]
        end
    end

    return ids
end

function _dfvb_find_column_name(table::DataFrame, candidates, label::AbstractString)::String
    table_names = names(table)
    for candidate in candidates
        candidate_string = String(candidate)
        candidate_string in table_names && return candidate_string
    end
    error(
        "DFVB alpha bounds table is missing a required $label column. Expected one of: $(join(String.(candidates), ", ")). Found: $(join(table_names, ", ")).",
    )
end

function _dfvb_problem_required_float(value, column::AbstractString, row::Integer)::Float64
    ismissing(value) && error("Missing numeric value in DFVB alpha bounds column $column row $row.")
    parsed = value isa Real ? Float64(value) : tryparse(Float64, strip(String(value)))
    parsed === nothing && error("Non-numeric value in DFVB alpha bounds column $column row $row: $value")
    isfinite(parsed) || error("Non-finite numeric value in DFVB alpha bounds column $column row $row: $value")
    return parsed
end

function _assert_dfvb_oxygen_not_r0001(reaction_map::ReactionMap)
    oxygen_id = get(reaction_map.core, "oxygen_exchange", "")
    disabled_oxygen_id = get(reaction_map.disabled_reactions, "oxygen_exchange", "")
    if strip(oxygen_id) == "r_0001" || strip(disabled_oxygen_id) == "r_0001"
        error("Dynamic DFVB LP oxygen_exchange must not map to r_0001.")
    end
    return nothing
end

function _dfvb_static_metadata(
    model::MetabolicModel,
    artifacts::DFVBArtifacts;
    objective_rxn_id::Union{Nothing, AbstractString},
    objective_reaction_index::Union{Nothing, Int},
    objective_weights::Dict{String, Float64},
    objective_type::AbstractString,
    objective_description::AbstractString,
    use_active_alpha::Bool,
    n_alpha::Int,
    solver_label::AbstractString,
)::Dict{String, Any}
    return Dict{String, Any}(
        "problem_type" => "static_dfvb_lp",
        "model_scope" => "matlab_full_dfvb_export",
        "model_id" => model.model_id,
        "artifact_id" => artifacts.paths.artifact_id,
        "use_active_alpha" => use_active_alpha,
        "n_reactions" => length(model.rxn_ids),
        "n_alpha" => n_alpha,
        "objective_type" => String(objective_type),
        "objective_rxn_id" => objective_rxn_id === nothing ? nothing : String(objective_rxn_id),
        "objective_reaction_index" => objective_reaction_index,
        "objective_weights" => copy(objective_weights),
        "n_objective_terms" => length(objective_weights),
        "objective_description" => String(objective_description),
        "objective_value_is_not_biomass_flux" => String(objective_type) == "weighted",
        "solver_label" => String(solver_label),
        "alpha_scope" => _dfvb_alpha_scope(use_active_alpha),
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
        "oxygen_reaction_id" => "r_1992",
        "oxygen_mapping_note" => DFVB_ARTIFACT_OXYGEN_MAPPING_NOTE,
        "exchange_partition_note" => DFVB_ARTIFACT_EXCHANGE_PARTITION_NOTE,
        "biological_interpretation_note" => DFVB_STATIC_LP_BIOLOGICAL_INTERPRETATION_NOTE,
        "dfvb_rhs_implemented" => false,
        "kkt_mpcc_collocation_implemented" => false,
    )
end
