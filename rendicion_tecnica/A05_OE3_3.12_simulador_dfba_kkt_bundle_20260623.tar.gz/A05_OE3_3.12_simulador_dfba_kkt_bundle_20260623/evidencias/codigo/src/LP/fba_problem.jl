import HiGHS
import JuMP
import MathOptInterface as MOI

"""
    FBAResult

Result container for a static flux balance analysis solve.
"""
struct FBAResult
    status::MOI.TerminationStatusCode
    objective_value::Float64
    fluxes::Vector{Float64}
    objective_rxn_id::Union{Nothing, String}
    objective_index::Union{Nothing, Int}
    objective_weights::Dict{String, Float64}
    objective_description::String
    mass_balance_residual::Float64
    max_lower_bound_violation::Float64
    max_upper_bound_violation::Float64
    metadata::Dict{String, Any}
end

"""
    build_fba_problem(model; objective_rxn_id=nothing, objective_weights=nothing, sense=:max, optimizer=HiGHS.Optimizer, silent=true, optimizer_attributes=Dict())

Build a static FBA linear program for the supplied metabolic model.
"""
function build_fba_problem(
    model::MetabolicModel;
    objective_rxn_id::Union{Nothing, AbstractString} = nothing,
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}} = nothing,
    sense::Symbol = :max,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    optimizer_attributes::AbstractDict = Dict{String, Any}(),
)
    sense in (:max, :min) || error("Unsupported FBA objective sense: $sense. Use :max or :min.")

    n_mets, n_rxns = size(model.S)
    validate_reduced_model_dimensions(model; throw_on_error = true)
    objective = _normalize_fba_objective(
        model;
        objective_rxn_id = objective_rxn_id,
        objective_weights = objective_weights,
    )

    jump_model = JuMP.Model(optimizer)
    for (name, value) in optimizer_attributes
        JuMP.set_optimizer_attribute(jump_model, String(name), value)
    end
    silent && JuMP.set_silent(jump_model)

    JuMP.@variable(jump_model, v[1:n_rxns])
    for i in 1:n_rxns
        JuMP.set_lower_bound(v[i], model.lb[i])
        JuMP.set_upper_bound(v[i], model.ub[i])
    end

    row_indices, column_indices, values = findnz(model.S)
    mass_balance_expressions = [JuMP.AffExpr(0.0) for _ in 1:n_mets]
    for k in eachindex(values)
        JuMP.add_to_expression!(
            mass_balance_expressions[row_indices[k]],
            values[k],
            v[column_indices[k]],
        )
    end
    JuMP.@constraint(jump_model, steady_state[i = 1:n_mets], mass_balance_expressions[i] == 0.0)

    objective_expression = JuMP.AffExpr(0.0)
    for (rxn_id, weight) in objective.objective_weights
        JuMP.add_to_expression!(
            objective_expression,
            weight,
            v[reaction_index(model, rxn_id)],
        )
    end

    if sense == :max
        JuMP.@objective(jump_model, Max, objective_expression)
    else
        JuMP.@objective(jump_model, Min, objective_expression)
    end

    return (
        jump_model = jump_model,
        fluxes = v,
        objective_rxn_id = objective.objective_rxn_id,
        objective_index = objective.objective_index,
        objective_weights = objective.objective_weights,
        objective_description = objective.objective_description,
        objective_type = objective.objective_type,
        sense = sense,
    )
end

"""
    solve_fba(model; objective_rxn_id=nothing, objective_weights=nothing, sense=:max, optimizer=HiGHS.Optimizer, silent=true, atol=1e-8, optimizer_attributes=Dict())

Solve a static FBA problem and return an `FBAResult`.
"""
function solve_fba(
    model::MetabolicModel;
    objective_rxn_id::Union{Nothing, AbstractString} = nothing,
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}} = nothing,
    sense::Symbol = :max,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1e-8,
    optimizer_attributes::AbstractDict = Dict{String, Any}(),
)
    problem = build_fba_problem(
        model;
        objective_rxn_id = objective_rxn_id,
        objective_weights = objective_weights,
        sense = sense,
        optimizer = optimizer,
        silent = silent,
        optimizer_attributes = optimizer_attributes,
    )
    jump_model = problem.jump_model
    JuMP.optimize!(jump_model)

    status = JuMP.termination_status(jump_model)
    primal_status = JuMP.primal_status(jump_model)
    dual_status = JuMP.dual_status(jump_model)
    has_primal = primal_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT)

    fluxes = has_primal ? Float64.(JuMP.value.(problem.fluxes)) : Float64[]
    objective_value = has_primal ? Float64(JuMP.objective_value(jump_model)) : NaN
    mass_balance_residual = has_primal ? check_mass_balance(model, fluxes; atol = atol) : Inf
    bound_report = has_primal ? check_bound_violations(model, fluxes; atol = atol) : (
        max_lower_violation = Inf,
        max_upper_violation = Inf,
        n_lower_violations = length(model.rxn_ids),
        n_upper_violations = length(model.rxn_ids),
    )

    metadata = Dict{String, Any}(
        "sense" => problem.sense,
        "primal_status" => primal_status,
        "dual_status" => dual_status,
        "solver_name" => _solver_name(jump_model),
        "solver_reported_solve_time_seconds" => _moi_model_attribute_or_missing(jump_model, MOI.SolveTimeSec()),
        "simplex_iterations" => _moi_model_attribute_or_missing(jump_model, MOI.SimplexIterations()),
        "raw_status_string" => _moi_model_attribute_or_missing(jump_model, MOI.RawStatusString()),
        "objective_type" => problem.objective_type,
        "n_objective_terms" => length(problem.objective_weights),
        "optimizer_attributes" => Dict(String(k) => v for (k, v) in optimizer_attributes),
    )

    return FBAResult(
        status,
        objective_value,
        fluxes,
        problem.objective_rxn_id,
        problem.objective_index,
        copy(problem.objective_weights),
        problem.objective_description,
        mass_balance_residual,
        bound_report.max_lower_violation,
        bound_report.max_upper_violation,
        metadata,
    )
end

"""
    build_qp_regularized_fba_problem(model; objective_rxn_id=nothing, objective_weights=nothing, quadratic_penalty, optimizer=HiGHS.Optimizer, silent=true)

Build a convex QP that maximizes the primary FBA objective with a quadratic
flux penalty, represented as `min -c'v + quadratic_penalty * sum(v.^2)`.
"""
function build_qp_regularized_fba_problem(
    model::MetabolicModel;
    objective_rxn_id::Union{Nothing, AbstractString} = nothing,
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}} = nothing,
    quadratic_penalty::Real,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
)
    penalty = _validate_qp_regularized_fba_penalty(quadratic_penalty)
    n_mets, n_rxns = size(model.S)
    validate_reduced_model_dimensions(model; throw_on_error = true)
    objective = _normalize_fba_objective(
        model;
        objective_rxn_id = objective_rxn_id,
        objective_weights = objective_weights,
    )

    jump_model = JuMP.Model(_qp_regularized_fba_optimizer(optimizer))
    silent && JuMP.set_silent(jump_model)

    JuMP.@variable(jump_model, v[1:n_rxns])
    for i in 1:n_rxns
        JuMP.set_lower_bound(v[i], model.lb[i])
        JuMP.set_upper_bound(v[i], model.ub[i])
    end

    row_indices, column_indices, values = findnz(model.S)
    mass_balance_expressions = [JuMP.AffExpr(0.0) for _ in 1:n_mets]
    for k in eachindex(values)
        JuMP.add_to_expression!(
            mass_balance_expressions[row_indices[k]],
            values[k],
            v[column_indices[k]],
        )
    end
    JuMP.@constraint(jump_model, steady_state[i = 1:n_mets], mass_balance_expressions[i] == 0.0)

    objective_expression = _fba_objective_expression(model, v, objective.objective_weights)
    JuMP.@objective(jump_model, Min, -objective_expression + penalty * sum(v[i]^2 for i in 1:n_rxns))

    return (
        jump_model = jump_model,
        fluxes = v,
        objective_rxn_id = objective.objective_rxn_id,
        objective_index = objective.objective_index,
        objective_weights = objective.objective_weights,
        objective_description = objective.objective_description,
        objective_type = objective.objective_type,
        fba_variant = "qpfba",
        quadratic_penalty = penalty,
        sense = :min,
    )
end

"""
    solve_qp_regularized_fba(model; objective_rxn_id=nothing, objective_weights=nothing, quadratic_penalty, optimizer=HiGHS.Optimizer, silent=true, atol=1e-8)

Solve a QP-regularized FBA problem. `FBAResult.objective_value` reports the
unregularized primary objective; regularized values are stored in metadata.
"""
function solve_qp_regularized_fba(
    model::MetabolicModel;
    objective_rxn_id::Union{Nothing, AbstractString} = nothing,
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}} = nothing,
    quadratic_penalty::Real,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1e-8,
)
    problem = build_qp_regularized_fba_problem(
        model;
        objective_rxn_id = objective_rxn_id,
        objective_weights = objective_weights,
        quadratic_penalty = quadratic_penalty,
        optimizer = optimizer,
        silent = silent,
    )
    JuMP.optimize!(problem.jump_model)
    return _qp_regularized_fba_result_from_problem(model, problem; atol = atol, model_reuse = false)
end

"""
    build_l1_regularized_fba_problem(model; objective_rxn_id=nothing, objective_weights=nothing, l1_penalty, optimizer=HiGHS.Optimizer, silent=true)

Build a linear pFBA-like problem that maximizes the primary FBA objective with
an L1 flux penalty, represented as `min -c'v + l1_penalty * sum(abs(v))`.
"""
function build_l1_regularized_fba_problem(
    model::MetabolicModel;
    objective_rxn_id::Union{Nothing, AbstractString} = nothing,
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}} = nothing,
    l1_penalty::Real,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
)
    penalty = _validate_l1_regularized_fba_penalty(l1_penalty)
    n_mets, n_rxns = size(model.S)
    validate_reduced_model_dimensions(model; throw_on_error = true)
    objective = _normalize_fba_objective(
        model;
        objective_rxn_id = objective_rxn_id,
        objective_weights = objective_weights,
    )

    jump_model = JuMP.Model(optimizer)
    silent && JuMP.set_silent(jump_model)

    JuMP.@variable(jump_model, v[1:n_rxns])
    JuMP.@variable(jump_model, z[1:n_rxns] >= 0.0)
    for i in 1:n_rxns
        JuMP.set_lower_bound(v[i], model.lb[i])
        JuMP.set_upper_bound(v[i], model.ub[i])
        JuMP.@constraint(jump_model, z[i] >= v[i])
        JuMP.@constraint(jump_model, z[i] >= -v[i])
    end

    row_indices, column_indices, values = findnz(model.S)
    mass_balance_expressions = [JuMP.AffExpr(0.0) for _ in 1:n_mets]
    for k in eachindex(values)
        JuMP.add_to_expression!(
            mass_balance_expressions[row_indices[k]],
            values[k],
            v[column_indices[k]],
        )
    end
    JuMP.@constraint(jump_model, steady_state[i = 1:n_mets], mass_balance_expressions[i] == 0.0)

    objective_expression = _fba_objective_expression(model, v, objective.objective_weights)
    JuMP.@objective(jump_model, Min, -objective_expression + penalty * sum(z[i] for i in 1:n_rxns))

    return (
        jump_model = jump_model,
        fluxes = v,
        absolute_fluxes = z,
        objective_rxn_id = objective.objective_rxn_id,
        objective_index = objective.objective_index,
        objective_weights = objective.objective_weights,
        objective_description = objective.objective_description,
        objective_type = objective.objective_type,
        fba_variant = "l1pfba",
        l1_penalty = penalty,
        sense = :min,
    )
end

"""
    solve_l1_regularized_fba(model; objective_rxn_id=nothing, objective_weights=nothing, l1_penalty, optimizer=HiGHS.Optimizer, silent=true, atol=1e-8)

Solve an L1-regularized pFBA-like LP. `FBAResult.objective_value` reports the
unregularized primary objective; regularized values are stored in metadata.
"""
function solve_l1_regularized_fba(
    model::MetabolicModel;
    objective_rxn_id::Union{Nothing, AbstractString} = nothing,
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}} = nothing,
    l1_penalty::Real,
    optimizer = HiGHS.Optimizer,
    silent::Bool = true,
    atol::Real = 1e-8,
)
    problem = build_l1_regularized_fba_problem(
        model;
        objective_rxn_id = objective_rxn_id,
        objective_weights = objective_weights,
        l1_penalty = l1_penalty,
        optimizer = optimizer,
        silent = silent,
    )
    JuMP.optimize!(problem.jump_model)
    return _l1_regularized_fba_result_from_problem(model, problem; atol = atol, model_reuse = false)
end

function _moi_model_attribute_or_missing(jump_model::JuMP.Model, attr)
    return try
        MOI.get(JuMP.backend(jump_model), attr)
    catch
        missing
    end
end

function _qp_regularized_fba_optimizer(optimizer)
    optimizer == HiGHS.Optimizer || return optimizer
    return JuMP.optimizer_with_attributes(
        optimizer,
        "solver" => "ipm",
        "run_crossover" => "off",
        "ipm_optimality_tolerance" => 1.0e-6,
    )
end

function _qp_regularized_fba_result_from_problem(
    model::MetabolicModel,
    problem;
    atol::Real,
    model_reuse::Bool,
    extra_metadata::Dict{String, Any} = Dict{String, Any}(),
)
    jump_model = problem.jump_model
    status = JuMP.termination_status(jump_model)
    primal_status = JuMP.primal_status(jump_model)
    dual_status = JuMP.dual_status(jump_model)
    has_primal = primal_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT)

    fluxes = has_primal ? Float64.(JuMP.value.(problem.fluxes)) : Float64[]
    primary_objective_value = has_primal ?
        _fba_primary_objective_value(model, problem.objective_weights, fluxes) :
        NaN
    penalty_value = has_primal ? problem.quadratic_penalty * sum(abs2, fluxes) : NaN
    regularized_objective_value = has_primal ? primary_objective_value - penalty_value : NaN
    solver_min_objective_value = has_primal ? Float64(JuMP.objective_value(jump_model)) : NaN
    mass_balance_residual = has_primal ? check_mass_balance(model, fluxes; atol = atol) : Inf
    bound_report = has_primal ? check_bound_violations(model, fluxes; atol = atol) : (
        max_lower_violation = Inf,
        max_upper_violation = Inf,
        n_lower_violations = length(model.rxn_ids),
        n_upper_violations = length(model.rxn_ids),
    )

    metadata = Dict{String, Any}(
        "sense" => :min,
        "primary_sense" => :max,
        "primal_status" => primal_status,
        "dual_status" => dual_status,
        "solver_name" => _solver_name(jump_model),
        "solver_reported_solve_time_seconds" => _moi_model_attribute_or_missing(jump_model, MOI.SolveTimeSec()),
        "simplex_iterations" => _moi_model_attribute_or_missing(jump_model, MOI.SimplexIterations()),
        "raw_status_string" => _moi_model_attribute_or_missing(jump_model, MOI.RawStatusString()),
        "objective_type" => "$(problem.objective_type)_qpfba",
        "primary_objective_type" => problem.objective_type,
        "n_objective_terms" => length(problem.objective_weights),
        "fba_variant" => "qpfba",
        "quadratic_penalty" => problem.quadratic_penalty,
        "primary_objective_value" => primary_objective_value,
        "quadratic_penalty_value" => penalty_value,
        "regularized_objective_value" => regularized_objective_value,
        "solver_min_objective_value" => solver_min_objective_value,
        "model_reuse" => model_reuse,
        "qpfba_near_optimal_acceptance_policy" =>
            "DFBA RHS may accept qpfba OTHER_ERROR only when primal and dual are feasible and residual/bound violations are <= 1.0e-4.",
    )
    merge!(metadata, extra_metadata)

    return FBAResult(
        status,
        primary_objective_value,
        fluxes,
        problem.objective_rxn_id,
        problem.objective_index,
        copy(problem.objective_weights),
        "$(problem.objective_description):qpfba",
        mass_balance_residual,
        bound_report.max_lower_violation,
        bound_report.max_upper_violation,
        metadata,
    )
end

function _l1_regularized_fba_result_from_problem(
    model::MetabolicModel,
    problem;
    atol::Real,
    model_reuse::Bool,
    extra_metadata::Dict{String, Any} = Dict{String, Any}(),
)
    jump_model = problem.jump_model
    status = JuMP.termination_status(jump_model)
    primal_status = JuMP.primal_status(jump_model)
    dual_status = JuMP.dual_status(jump_model)
    has_primal = primal_status in (MOI.FEASIBLE_POINT, MOI.NEARLY_FEASIBLE_POINT)

    fluxes = has_primal ? Float64.(JuMP.value.(problem.fluxes)) : Float64[]
    absolute_fluxes = has_primal ? Float64.(JuMP.value.(problem.absolute_fluxes)) : Float64[]
    primary_objective_value = has_primal ?
        _fba_primary_objective_value(model, problem.objective_weights, fluxes) :
        NaN
    l1_penalty_value = has_primal ? problem.l1_penalty * sum(absolute_fluxes) : NaN
    regularized_objective_value = has_primal ? primary_objective_value - l1_penalty_value : NaN
    solver_min_objective_value = has_primal ? Float64(JuMP.objective_value(jump_model)) : NaN
    mass_balance_residual = has_primal ? check_mass_balance(model, fluxes; atol = atol) : Inf
    bound_report = has_primal ? check_bound_violations(model, fluxes; atol = atol) : (
        max_lower_violation = Inf,
        max_upper_violation = Inf,
        n_lower_violations = length(model.rxn_ids),
        n_upper_violations = length(model.rxn_ids),
    )

    metadata = Dict{String, Any}(
        "sense" => :min,
        "primary_sense" => :max,
        "primal_status" => primal_status,
        "dual_status" => dual_status,
        "solver_name" => _solver_name(jump_model),
        "solver_reported_solve_time_seconds" => _moi_model_attribute_or_missing(jump_model, MOI.SolveTimeSec()),
        "simplex_iterations" => _moi_model_attribute_or_missing(jump_model, MOI.SimplexIterations()),
        "raw_status_string" => _moi_model_attribute_or_missing(jump_model, MOI.RawStatusString()),
        "objective_type" => "$(problem.objective_type)_l1pfba",
        "primary_objective_type" => problem.objective_type,
        "n_objective_terms" => length(problem.objective_weights),
        "fba_variant" => "l1pfba",
        "l1_penalty" => problem.l1_penalty,
        "primary_objective_value" => primary_objective_value,
        "l1_norm_value" => has_primal ? sum(absolute_fluxes) : NaN,
        "l1_penalty_value" => l1_penalty_value,
        "regularized_objective_value" => regularized_objective_value,
        "solver_min_objective_value" => solver_min_objective_value,
        "model_reuse" => model_reuse,
    )
    merge!(metadata, extra_metadata)

    return FBAResult(
        status,
        primary_objective_value,
        fluxes,
        problem.objective_rxn_id,
        problem.objective_index,
        copy(problem.objective_weights),
        "$(problem.objective_description):l1pfba",
        mass_balance_residual,
        bound_report.max_lower_violation,
        bound_report.max_upper_violation,
        metadata,
    )
end

function _fba_objective_expression(
    model::MetabolicModel,
    flux_variables,
    objective_weights::Dict{String, Float64},
)
    objective_expression = JuMP.AffExpr(0.0)
    for (rxn_id, weight) in objective_weights
        JuMP.add_to_expression!(
            objective_expression,
            weight,
            flux_variables[reaction_index(model, rxn_id)],
        )
    end
    return objective_expression
end

function _fba_primary_objective_value(
    model::MetabolicModel,
    objective_weights::Dict{String, Float64},
    fluxes::AbstractVector{<:Real},
)::Float64
    return sum(
        weight * Float64(fluxes[reaction_index(model, rxn_id)]) for
        (rxn_id, weight) in objective_weights
    )
end

function _validate_qp_regularized_fba_penalty(quadratic_penalty::Real)::Float64
    penalty = Float64(quadratic_penalty)
    isfinite(penalty) && penalty > 0.0 ||
        error("QP-regularized FBA quadratic_penalty must be finite and positive, got $quadratic_penalty.")
    return penalty
end

function _validate_l1_regularized_fba_penalty(l1_penalty::Real)::Float64
    penalty = Float64(l1_penalty)
    isfinite(penalty) && penalty > 0.0 ||
        error("L1-regularized FBA l1_penalty must be finite and positive, got $l1_penalty.")
    return penalty
end

function _normalize_fba_objective(
    model::MetabolicModel;
    objective_rxn_id::Union{Nothing, AbstractString},
    objective_weights::Union{Nothing, AbstractDict{<:AbstractString, <:Real}},
)
    if objective_rxn_id !== nothing && objective_weights !== nothing
        error("Provide either objective_rxn_id or objective_weights, not both.")
    elseif objective_weights !== nothing
        return _normalize_weighted_fba_objective(model, objective_weights)
    elseif objective_rxn_id !== nothing
        return _normalize_single_fba_objective(model, objective_rxn_id)
    else
        error("An FBA objective is required. Provide objective_rxn_id or objective_weights.")
    end
end

function _normalize_single_fba_objective(model::MetabolicModel, objective_rxn_id::AbstractString)
    rxn_id = strip(String(objective_rxn_id))
    isempty(rxn_id) && error("Objective reaction ID must not be empty.")
    objective_index = _objective_reaction_index(model, rxn_id)

    return (
        objective_type = "single",
        objective_rxn_id = rxn_id,
        objective_index = objective_index,
        objective_weights = Dict{String, Float64}(rxn_id => 1.0),
        objective_description = "single:$rxn_id",
    )
end

function _normalize_weighted_fba_objective(
    model::MetabolicModel,
    objective_weights::AbstractDict{<:AbstractString, <:Real},
)
    isempty(objective_weights) && error("Objective weights must not be empty.")

    normalized_weights = Dict{String, Float64}()
    for (rxn_id_raw, weight_raw) in objective_weights
        rxn_id = strip(String(rxn_id_raw))
        isempty(rxn_id) && error("Objective reaction ID must not be empty.")
        _objective_reaction_index(model, rxn_id)

        weight = Float64(weight_raw)
        isfinite(weight) || error("Objective weight for reaction $rxn_id must be finite, got $weight.")
        haskey(normalized_weights, rxn_id) && error(
            "Duplicate objective reaction ID after normalization: $rxn_id",
        )

        normalized_weights[rxn_id] = weight
    end

    return (
        objective_type = "weighted",
        objective_rxn_id = nothing,
        objective_index = nothing,
        objective_weights = normalized_weights,
        objective_description = "weighted",
    )
end

function _objective_reaction_index(model::MetabolicModel, rxn_id::AbstractString)::Int
    has_reaction(model, rxn_id) || error("Objective reaction ID not found in model $(model.model_id): $rxn_id")
    return reaction_index(model, rxn_id)
end

function _solver_name(jump_model)
    return try
        JuMP.solver_name(jump_model)
    catch
        "unknown"
    end
end
