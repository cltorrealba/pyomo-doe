# Gurobi-vs-HiGHS Benchmark

This guide documents an opt-in runtime comparison between the default `HiGHS`
backend and an optional local `Gurobi` backend for the sequential reduced DFBA
workflow. It uses the existing plotting-free benchmark script and does not
change model equations, RHS equations, kinetic equations, dynamic bounds, or ODE
integration logic.

## Requirements

HiGHS works by default and is the only required LP solver in this repository.
Gurobi is optional and requires:

- a valid Gurobi installation and license,
- `Gurobi.jl` available in the active Julia environment or through
  `DFBA_GUROBI_PACKAGE_PATH`,
- explicit selection with `DFBA_BENCH_SOLVER_BACKENDS=HiGHS,Gurobi`.

`Gurobi.jl` is not a required dependency and must not be added to
`Project.toml` for normal MVP execution. Do not commit local `Project.toml` or
`Manifest.toml` changes from Gurobi experiments. Do not hardcode local Gurobi
paths in repository files.

## Run the Comparison

From the repository root, configure the optional local package path and run the
benchmark:

```powershell
$env:DFBA_GUROBI_PACKAGE_PATH = "<path-to-Gurobi.jl-checkout>"
$env:DFBA_BENCH_SOLVER_BACKENDS = "HiGHS,Gurobi"
$env:DFBA_BENCH_ALGORITHM = "Tsit5"
$env:DFBA_BENCH_RECONSTRUCT = "both"
$env:DFBA_BENCH_TFINAL_HOURS = "2.0"
$env:DFBA_BENCH_SAVEAT_HOURS = "1.0"
julia --project scripts/main_benchmark.jl
```

`DFBA_BENCH_ALGORITHM=Tsit5` uses the same explicit ODE algorithm for every
selected backend. `Tsit5` is an explicit non-stiff Runge-Kutta method; it is
recommended here for local Gurobi comparisons because local tests show that the
`Gurobi` + `Rodas5P` benchmark path can hang or take too long in the current
LP-in-the-loop implementation. This is a workflow guard, not a claim that
`Tsit5` is universally better.

`Rodas5P` remains the current default in the public
`simulate_reduced_dfba(...)` API and in HiGHS-only benchmarks. The manual
simulation and export scripts use `Tsit5` by default through `DFBA_ALGORITHM`,
which is separate from the benchmark-only `DFBA_BENCH_ALGORITHM` variable. The
benchmark script fails fast when `DFBA_BENCH_SOLVER_BACKENDS` includes `Gurobi`
and the selected algorithm is `Rodas5P`, unless the user deliberately sets:

```powershell
$env:DFBA_BENCH_ALLOW_GUROBI_RODAS5P = "1"
```

Use that override only for manual local experiments where a long or stuck run
is acceptable.

If Gurobi fails to load, run the HiGHS-only benchmark instead:

```powershell
$env:DFBA_BENCH_SOLVER_BACKENDS = "HiGHS"
julia --project scripts/main_benchmark.jl
```

For a shorter smoke comparison:

```powershell
$env:DFBA_BENCH_TFINAL_HOURS = "0.5"
$env:DFBA_BENCH_ALGORITHM = "Tsit5"
$env:DFBA_BENCH_RECONSTRUCT = "false"
julia --project scripts/main_benchmark.jl
```

For a longer runtime-oriented comparison:

```powershell
$env:DFBA_BENCH_TFINAL_HOURS = "24.0"
$env:DFBA_BENCH_SAVEAT_HOURS = "1.0"
$env:DFBA_BENCH_ALGORITHM = "Tsit5"
$env:DFBA_BENCH_RECONSTRUCT = "false"
julia --project scripts/main_benchmark.jl
```

The longer example avoids saved-state flux reconstruction. It still solves one
LP inside every RHS evaluation.

## Output Files

The default output directory is ignored by Git:

```text
results/benchmarks/reduced_dfba_latest/benchmark_summary.csv
results/benchmarks/reduced_dfba_latest/benchmark_metadata.toml
```

Do not commit generated benchmark outputs unless intentionally preparing a
separate report outside this MVP code path.

When both backends and both reconstruction modes are enabled, expected scenario
IDs are:

```text
highs_reconstruct_true
highs_reconstruct_false
gurobi_reconstruct_true
gurobi_reconstruct_false
```

## Columns to Compare

Start with these columns in `benchmark_summary.csv`:

```text
solver_label
algorithm_label
ode_abstol
ode_reltol
lp_atol
reconstruct_fluxes
retcode
termination_reason
simulation_elapsed_seconds
ode_solve_elapsed_seconds
rhs_elapsed_seconds
history_reconstruction_elapsed_seconds
rhs_call_count
rhs_lp_solve_count
flux_reconstruction_solve_count
total_lp_solve_count
max_mass_balance_residual
max_lower_bound_violation
max_upper_bound_violation
final_biomass
final_total_sugar
final_ethanol
```

Compare only rows with `retcode == "Success"`. Check that final states are
close between solvers before interpreting runtime differences. If ODE behavior
is similar, `rhs_call_count` and `rhs_lp_solve_count` should also be similar
across solver backends.

Runtime comparisons should compare rows with the same:

```text
algorithm_label
ode_abstol
ode_reltol
lp_atol
reconstruct_fluxes
```

The benchmark also records these values in `benchmark_metadata.toml`.

Runtime can vary due to Julia compilation, Gurobi startup, license checks, and
machine load. `reconstruct_fluxes=false` avoids saved-state flux reconstruction,
but it does not reduce LP solves inside the RHS. This benchmark does not
implement warm-starts or JuMP model reuse.

If a Gurobi run appears stuck with the default `Rodas5P` algorithm, first try a
short `Tsit5` run. A stalled `Rodas5P` comparison usually means the ODE solver
is taking many finite-difference Jacobian or rejected-step RHS evaluations; it
does not necessarily mean individual Gurobi LP solves are slow.

## Limitations

- LP-in-the-loop remains the main bottleneck.
- Gurobi may or may not improve runtime because the MVP rebuilds a JuMP model
  for repeated LP solves.
- ODE algorithm choice affects `rhs_call_count`, so compare solver backends only
  when they use the same `DFBA_BENCH_ALGORITHM`, `DFBA_BENCH_ODE_ABSTOL`,
  `DFBA_BENCH_ODE_RELTOL`, and `DFBA_BENCH_LP_ATOL` values.
- This is not a formal publication benchmark.
- No plotting is generated.
