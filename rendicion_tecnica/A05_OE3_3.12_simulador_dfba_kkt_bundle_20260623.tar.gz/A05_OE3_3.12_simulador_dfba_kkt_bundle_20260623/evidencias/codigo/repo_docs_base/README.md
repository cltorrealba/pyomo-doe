# FermentationDFBA

Julia MVP for anaerobic Sauvignon Blanc fermentation simulations using reduced metabolic model exports from MATLAB.

## Objective

This repository will support dynamic flux balance analysis workflows for wine fermentation, starting from the already exported reduced yeast metabolic model. The long-term targets are:

1. Sequential reduced DFBA.
2. Sequential reduced DFVB after MATLAB-exported DFVB artifacts are loaded and validated.
3. Full versus reduced and consolidated sequential simulation comparison.
4. Simultaneous KKT/MPCC direct-collocation formulations.

## MVP Scope

The initial MVP initializes the Julia project structure, data contracts, configuration templates, reduced-model CSV loading, reaction-map validation, and smoke tests.

The current MVP also includes static reduced- and full-model FBA smoke solves using JuMP and HiGHS, a full-vs-reduced static FBA comparison report with CSV/TOML outputs and dependency-free SVG plots, Zenteno-style dynamic bounds, weighted dynamic FBA objectives, single-step sequential reduced and full DFBA RHS evaluations, a first sequential reduced DFBA ODE simulation path, an opt-in reduced DFBA persistent LP/primal-start/basis-warm-start RHS path, a guarded short full sequential DFBA ODE smoke path with the same experimental persistence controls, a full-vs-reduced sequential DFBA state comparison report with explicit runtime guardrails up to 72 hours, a MATLAB DFVB artifact loader/validator, a static DFVB alpha-space LP smoke solve with flux reconstruction, a dynamic-bound weighted DFVB LP smoke solve, a one-step sequential DFVB RHS smoke with alpha carry-through, a short sequential DFVB ODE smoke path with alpha trajectory export, a MATLAB DFVB baseline trajectory report, a Julia-vs-MATLAB DFVB state trajectory comparison report, a consolidated state-only sequential DFBA/DFVB comparison report, plotting-free simulation export, basic SVG trajectory plotting utilities, plotting-free benchmarks including reduced RHS warm-start diagnostics and a full-vs-reduced DFBA persistence benchmark, direct-collocation grid primitives, a reduced KKT-DFBA structural scaffold, an Ipopt/MUMPS reduced toy NLP smoke, a reduced DC-dFBA collocation NLP scaffold, a reduced collocation RHS residual scaffold, reduced FBA primal feasibility rows, reduced FBA bound-feasibility rows with bound-dual variables, reduced FBA KKT stationarity rows, reduced FBA MPCC complementarity rows, a guarded reduced MPCC solver-entry smoke, smooth growth-mode dynamic bound/objective handling for the reduced MPCC scaffold, sequential reduced DFBA initialization starts for the collocation NLP, a guarded reduced dynamic MPCC solve-attempt wrapper with residual thresholds, reduced MPCC infeasibility/scaling diagnostics, dynamic local-FBA flux starts, dynamic-bound projection, RHS-consistent derivative starts for reduced MPCC starts, local LP KKT-consistent stationarity dual starts, collocation/continuity-consistent state starts for reduced MPCC solve-attempts, a reduced MPCC pre-solve scaling plan with blocking-vs-review readiness classification, guarded reduced MPCC solve-attempt preflight/post-solve diagnostics, reduced MPCC candidate extraction diagnostics, guarded reduced MPCC trajectory-candidate extraction, reduced MPCC-vs-sequential state comparison diagnostics, short-horizon reduced MPCC solve-attempt sweep diagnostics, a script-level reduced MPCC horizon/nfe sweep runner, reduced MPCC Ipopt iteration-sensitivity diagnostics, reduced MPCC mesh-refinement sensitivity diagnostics, reduced MPCC windowed-continuation diagnostics with explicit continuation-acceptance policies, reduced MPCC simulation-viability semaphore diagnostics, reduced MPCC simulation-viability frontier diagnostics, a reduced MPCC windowed target-horizon attempt driver with an opt-in 72-hour profile, reduced MPCC windowed failure-cause diagnostics with mass-balance row localization, reduced MPCC single-window retry diagnostics, reduced MPCC windowed mass-balance tolerance-sensitivity diagnostics, reduced MPCC windowed state-drift diagnostics, reduced MPCC multi-window retry-policy diagnostics, reduced MPCC retry-aware windowed attempt diagnostics, reduced MPCC solver-termination diagnostics, reduced MPCC iteration-limit candidate review, reduced MPCC windowed policy/horizon sweep diagnostics, and optional script-level solver backend hooks. It does not implement unguarded long full sequential DFBA production runs, long production DFVB simulation, a solved reduced MPCC trajectory, flux/alpha multimodel comparison, MATLAB model reduction, plotting package dependencies, hard Gurobi dependency, or production DFBA NLP formulations.

## Why Reduced Model First

The MATLAB reduction workflow already exported a reduced model. That reduced export is the operational input contract for the Julia MVP. Reimplementing MATLAB reduction in Julia is out of scope for this first phase and would delay testing the simulation pipeline that will actually consume the reduced model.

## Exported Artifacts

The current reduced-model data contract points to:

- `Antecedentes/Files_Cristobal/Reduced_model/S.csv`
- `Antecedentes/Files_Cristobal/Reduced_model/lb.csv`
- `Antecedentes/Files_Cristobal/Reduced_model/ub.csv`
- `Antecedentes/Files_Cristobal/Reduced_model/rxn_list.csv`
- `Antecedentes/Files_Cristobal/Reduced_model/mets_list.csv`
- `Antecedentes/Files_Cristobal/Reduced_model/Indices_reacciones.csv`

Expected file details:

- `S.csv` contains the reduced stoichiometric matrix. Its headers are generic (`S1`, `S2`, ...), so reaction IDs must come from `rxn_list.csv`.
- `lb.csv` contains the reduced lower bounds in column `lb`.
- `ub.csv` contains the reduced upper bounds in column `ub`.
- `rxn_list.csv` contains reduced reaction IDs.
- `mets_list.csv` contains reduced metabolite IDs.
- `Indices_reacciones.csv` records MATLAB-exported reaction role indices. It is not used for Julia reaction mapping yet because its exported indices do not align directly with `rxn_list.csv` positions. Current mapping is by `rxn_id`.

The current full-model data contract points to:

- `Antecedentes/modelo_original/S_matrix.csv`
- `Antecedentes/modelo_original/lb_vector.csv`
- `Antecedentes/modelo_original/ub_vector.csv`

Expected full-model file details:

- `S_matrix.csv` contains `2806` metabolites by `4131` reactions.
- The first column of `S_matrix.csv` must be `metabolite_id`; metabolite IDs come from that column.
- Full-model reaction IDs come from the remaining `S_matrix.csv` headers.
- `lb_vector.csv` and `ub_vector.csv` contain one bound per reaction column.

## Known Limitations

- MATLAB-exported DFVB artifacts are available under `Antecedentes/Files_Cristobal/DFVB_artifacts/`, and static plus dynamic-bound alpha-space DFVB LP smokes are available. A one-step sequential DFVB RHS smoke, a short sequential DFVB ODE smoke, a MATLAB DFVB baseline trajectory report, a state-only Julia-vs-MATLAB DFVB trajectory comparison report, and a consolidated state-only reduced DFBA/full DFBA/Julia DFVB/MATLAB DFVB comparison report are available, but long production DFVB simulation and flux/alpha multimodel comparison are not implemented yet.
- The exported DFVB exchange partition marks only `r_0001` as exchange; this is a loader warning and must not be used as oxygen mapping.
- Oxygen exchange `r_1992` is absent from the reduced model and is explicitly disabled in the reduced reaction map.
- Oxygen exchange `r_1992` is present in the full model and is anaerobically closed by bounds (`lb = 0.0`, `ub = 0.0`). Do not use `r_0001` as oxygen.
- The carbohydrate pseudoreaction is `r_4048` and is present in the reduced model.
- Static LP/FBA, full static FBA baseline loading, full-vs-reduced static FBA comparison reporting, single-step sequential reduced and full DFBA RHS evaluations, a first sequential reduced DFBA ODE simulation path, opt-in reduced and full DFBA persistent LP/primal-start/basis-warm-start ODE diagnostics, a guarded short full sequential DFBA ODE smoke path, full-vs-reduced sequential DFBA state comparison reporting with runtime guardrails up to 72 hours, DFVB artifact loading/validation, static DFVB LP reconstruction smoke, dynamic-bound weighted DFVB LP smoke, one-step sequential DFVB RHS smoke, short sequential DFVB ODE smoke with alpha trajectory storage/export, MATLAB DFVB baseline trajectory reporting, state-only Julia-vs-MATLAB DFVB trajectory comparison reporting, consolidated state-only sequential DFBA/DFVB comparison reporting, plotting-free export, basic SVG trajectory plotting utilities, plotting-free benchmarks including reduced RHS warm-start diagnostics and full-vs-reduced DFBA persistence evaluation, direct-collocation grid primitives, a reduced KKT-DFBA structural scaffold, an Ipopt/MUMPS reduced toy NLP smoke, a reduced DC-dFBA collocation NLP scaffold, a reduced collocation RHS residual scaffold, reduced FBA primal feasibility rows, reduced FBA bound-feasibility rows with bound-dual variables, reduced FBA KKT stationarity rows, reduced FBA MPCC complementarity rows, a guarded reduced MPCC solver-entry smoke, smooth growth-mode dynamic bound/objective handling for the reduced MPCC scaffold, sequential reduced DFBA initialization starts for the collocation NLP, a guarded reduced dynamic MPCC solve-attempt wrapper with residual thresholds, reduced MPCC infeasibility/scaling diagnostics, dynamic local-FBA flux starts, dynamic-bound projection, RHS-consistent derivative starts for reduced MPCC starts, local LP KKT-consistent stationarity dual starts, collocation/continuity-consistent state starts for reduced MPCC solve-attempts, a reduced MPCC pre-solve scaling plan with blocking-vs-review readiness classification, guarded reduced MPCC solve-attempt preflight/post-solve diagnostics, reduced MPCC candidate extraction diagnostics, guarded reduced MPCC trajectory-candidate extraction, reduced MPCC-vs-sequential state comparison diagnostics, short-horizon reduced MPCC solve-attempt sweep diagnostics, a script-level reduced MPCC horizon/nfe sweep runner, reduced MPCC Ipopt iteration-sensitivity diagnostics, reduced MPCC mesh-refinement sensitivity diagnostics, reduced MPCC windowed-continuation diagnostics with explicit continuation-acceptance policies, reduced MPCC simulation-viability semaphore diagnostics, reduced MPCC simulation-viability frontier diagnostics, a reduced MPCC windowed target-horizon attempt driver, reduced MPCC windowed failure-cause diagnostics, reduced MPCC single-window retry diagnostics, reduced MPCC windowed mass-balance tolerance-sensitivity diagnostics, reduced MPCC windowed state-drift diagnostics, reduced MPCC multi-window retry-policy diagnostics, reduced MPCC retry-aware windowed attempt diagnostics, reduced MPCC solver-termination diagnostics, reduced MPCC iteration-limit candidate review, and reduced MPCC windowed policy/horizon sweep diagnostics are implemented. No unguarded long full sequential DFBA production run, long production DFVB simulation, flux/alpha multimodel trajectory comparison, solved reduced MPCC trajectory, plotting package dependency, default-enabled warm-start integration, or default simulator model-reuse implementation exists yet.
- HiGHS is the default and required LP optimizer. Ipopt is a required NLP dependency for the small solver smoke and future simultaneous work. Gurobi is available only as an optional user-provided script backend when `Gurobi.jl` and a valid license are configured locally.

## Static FBA Smoke Solve

The static FBA smoke solve loads the exported reduced model, validates the reduced reaction map, and maximizes the biomass reaction `r_2111`. It uses:

- JuMP for the LP model.
- HiGHS as the open LP optimizer.
- MathOptInterface for solver status reporting.

The formulation uses the exported bounds from `lb.csv` and `ub.csv`, enforces `S * v == 0`, and maps biological roles through reaction IDs from `rxn_list.csv`. Oxygen exchange `r_1992` remains disabled because it is absent from the reduced model. The carbohydrate pseudoreaction is mapped to `r_4048`.

Run it from the repository root:

```bash
julia --project scripts/main_static_fba_reduced.jl
```

## Full Model Loading and Static FBA Smoke

The full model loader uses `config/full_model_paths.example.toml` and reads
reaction IDs directly from the `S_matrix.csv` headers. It does not require
`rxn_list.csv`, `mets_list.csv`, or `Indices_reacciones.csv`.

The full reaction map in `config/reaction_map_full.example.toml` keeps
`oxygen_exchange = "r_1992"` active because `r_1992` is present in the full
model. The anaerobic condition is represented by the model bounds:
`r_1992` has `lb = 0.0` and `ub = 0.0`. The reaction `r_0001` may exist in the
full model, but it is not used as oxygen. The carbohydrate reaction remains
`r_4048`; sequential RHS workflows still keep `dy[8]` empirical rather than
using the `r_4048` flux.

Run the full model load report from the repository root:

```bash
julia --project scripts/main_load_full_model.jl
```

Run the full static FBA smoke solve:

```bash
julia --project scripts/main_static_fba_full.jl
```

The full static FBA smoke maximizes `r_2111` with HiGHS and provides a baseline
for full-vs-reduced comparison. A full single-step sequential DFBA RHS smoke and
a guarded short full sequential ODE smoke path are available. MATLAB-exported
DFVB artifacts are loadable, and static plus dynamic-bound DFVB alpha-space LP
smokes plus a one-step sequential DFVB RHS smoke are available.

## Full-vs-reduced Static FBA Comparison

The full-vs-reduced static FBA comparison report solves the reduced and full
static FBA baselines with the same biomass objective `r_2111`, then compares a
small reaction-ID keyed flux panel:

- `r_2111`: biomass
- `r_1714`: glucose
- `r_1709`: fructose
- `r_1761`: ethanol
- `r_1992`: oxygen
- `r_4046`: ATP maintenance
- `r_4047`: protein
- `r_4048`: carbohydrate

Run it from the repository root:

```bash
julia --project scripts/main_compare_static_fba_full_reduced.jl
```

The report writes CSV/TOML artifacts and dependency-free SVG plots to:

```text
results/static_fba_comparison/latest/static_fba_comparison_summary.csv
results/static_fba_comparison/latest/static_fba_selected_fluxes.csv
results/static_fba_comparison/latest/static_fba_comparison_metadata.toml
results/static_fba_comparison/latest/static_fba_objective_comparison.svg
results/static_fba_comparison/latest/static_fba_selected_fluxes.svg
results/static_fba_comparison/latest/static_fba_diagnostics.svg
```

The comparison is a diagnostic baseline, not a biological equivalence proof.
Fluxes are compared by reaction ID, static FBA can be degenerate, and the full
and reduced networks are not equivalent flux spaces. Non-objective flux
differences may reflect either network differences or alternative optima.

Oxygen and carbohydrate policies are preserved. Reduced `r_1992` is absent and
disabled, full `r_1992` is present but anaerobically closed by bounds, and
`r_0001` is never used as oxygen. The static `r_4048` flux is reported in the
comparison table, but the dynamic carbohydrate state derivative remains the
empirical MATLAB RHS expression and is not driven by `r_4048`.

## Optional Solver Backends

HiGHS is the default LP solver backend. `Ipopt.jl` is also a direct dependency
for the reduced toy NLP smoke and future simultaneous NLP work, using the
bundled/default MUMPS linear solver path. HSL/MA57 is not required. The
simulation, export, and benchmark scripts can opt into Gurobi only when the
user has installed and configured `Gurobi.jl` locally and has a valid Gurobi
license.

`Gurobi.jl` is not listed as a required dependency. Do not commit local
`Project.toml` or `Manifest.toml` changes caused by adding Gurobi unless the
dependency policy is intentionally being changed. If Gurobi is unavailable, the
scripts fail with a clear error only when Gurobi is requested; default HiGHS
runs do not import or require Gurobi. Do not hardcode local absolute Gurobi
paths in repository files.

Simulation and export backend selection:

```text
DFBA_SOLVER_BACKEND=HiGHS
DFBA_SOLVER_BACKEND=Gurobi
```

Optional local Gurobi package path:

```text
DFBA_GUROBI_PACKAGE_PATH=<path-to-Gurobi.jl-checkout>
```

Benchmark backend selection:

```text
DFBA_BENCH_SOLVER_BACKENDS=HiGHS
DFBA_BENCH_SOLVER_BACKENDS=HiGHS,Gurobi
```

Option 1: Gurobi is already available in the active Julia environment:

```powershell
$env:DFBA_SOLVER_BACKEND = "Gurobi"
julia --project scripts/main_simulate_reduced_dfba.jl
```

Option 2: Gurobi is available as a local `Gurobi.jl` checkout:

```powershell
$env:DFBA_SOLVER_BACKEND = "Gurobi"
$env:DFBA_GUROBI_PACKAGE_PATH = "<path-to-Gurobi.jl-checkout>"
julia --project scripts/main_simulate_reduced_dfba.jl
```

Benchmark comparison with a local `Gurobi.jl` checkout:

```powershell
$env:DFBA_BENCH_SOLVER_BACKENDS = "HiGHS,Gurobi"
$env:DFBA_BENCH_ALGORITHM = "Tsit5"
$env:DFBA_GUROBI_PACKAGE_PATH = "<path-to-Gurobi.jl-checkout>"
julia --project scripts/main_benchmark.jl
```

When `DFBA_GUROBI_PACKAGE_PATH` is used, scripts copy that checkout into a
temporary directory, activate a temporary Julia environment, run
`Pkg.build("Gurobi")` on the temporary copy if needed, import `Gurobi`, and then
restore the previous active project. This avoids modifying the repository
environment and avoids writing build files into the original local checkout.

Benchmark outputs include `solver_label`, `algorithm_label`, `ode_abstol`,
`ode_reltol`, and `lp_atol` columns. The export script writes the selected
`solver_label` and script-level `algorithm_label` to `summary.csv`, and writes
the selected solver label plus `script_algorithm_label` to `metadata.toml`.

## Direct Collocation Grid Primitives

The simultaneous scaffold now includes pure numerical direct-collocation grid
primitives for future reduced DFBA MPCC work. The supported scheme is
Radau-right degree 3 on the normalized local interval `[0, 1]`:

```julia
scheme = radau_collocation_scheme()
grid = build_collocation_grid((0.0, 1.0); nfe = 2)
```

`RadauCollocationScheme.integration_matrix` is the integration/collocation
matrix corresponding to the De Oliveira antecedent `colmat`; it maps
collocation derivatives to state increments over a finite element. The
`differentiation_matrix` is separate and differentiates polynomial values on
the augmented support nodes `[0.0; nodes]` at the Radau nodes. The quadrature
`weights` match `integration_matrix[end, :]`, and the finite-element grid is
uniform for now.

The grid primitive itself does not add HSL, KKT constraints, MPCC
complementarity, sequential initialization, or DFBA RHS residual constraints.
The first future MPCC target remains reduced DFBA. Full-model and DFVB KKT
formulations remain deferred.

## Reduced KKT-DFBA Scaffold

The simultaneous layer also includes a reduced KKT-DFBA structural scaffold:

```julia
grid = build_collocation_grid((0.0, 1.0); nfe = 2)
scaffold = build_kkt_dfba_problem(model, reaction_map, grid)
```

`KKTDFBAProblem` records the reduced model, reaction map, finite-element grid,
dimension counts, expected KKT/MPCC relation counts, and reaction-role policy
metadata. It is a contract for later implementation work, not a solver model.
The scaffold records future components such as `S*v = 0`, bound feasibility,
stationarity, complementarity pairs, ODE residual rows, continuity rows, and
initial-condition rows, but it does not construct JuMP variables or
constraints.

Guardrails are explicit: only `model_scope = "reduced"` is accepted, `r_1992`
must be absent and disabled as oxygen, `r_0001` is never oxygen,
`Indices_reacciones.csv` is not used, `dy[6]` remains forced zero, and
carbohydrate `dy[8]` remains empirical rather than driven by `r_4048`. No
Ipopt, HSL, NLP solve, KKT equations, MPCC complementarity constraints,
sequential initialization, full-model KKT, or DFVB KKT are added by this
scaffold.

## Ipopt/MUMPS Reduced Toy NLP Smoke

The simultaneous layer includes a minimal Ipopt smoke for the future reduced
NLP path:

```julia
result = solve_reduced_toy_nlp_smoke()
```

The smoke builds a two-variable JuMP model with `Ipopt.Optimizer` configured
through `ipopt_mumps_optimizer()`, which sets `linear_solver = "mumps"`. The
known solution is `x = 1.0`, `y = 0.5`, with zero objective and near-zero
linear and bilinear constraint residuals. This verifies that the required
Ipopt/MUMPS path is available in the project without assuming HSL/MA57.

This is only a solver integration smoke. It does not load reduced or full
metabolic models, construct DFBA KKT equations, build MPCC complementarity,
add direct-collocation dynamic constraints, perform sequential initialization,
or touch DFVB KKT. The first real MPCC target remains reduced DFBA; full-model
and DFVB KKT formulations remain deferred.

## Reduced DC-dFBA Collocation NLP Scaffold

The first reduced direct-collocation JuMP scaffold is available through:

```julia
nlp = build_reduced_dcdfba_collocation_nlp(model, reaction_map; tspan = (0.0, 0.25), nfe = 1)
rhs = add_reduced_dcdfba_rhs_residuals!(nlp)
primal = add_reduced_dcdfba_primal_feasibility!(nlp)
bound = add_reduced_dcdfba_bound_feasibility!(nlp)
stationarity = add_reduced_dcdfba_stationarity!(nlp, bound)
complementarity = add_reduced_dcdfba_complementarity!(nlp, stationarity)
```

This builds a `KKTDFBAProblem`, then creates a JuMP model with Ipopt/MUMPS,
boundary state variables, collocation state variables, state-derivative
variables, and reduced flux variables at each collocation point. Flux variables
use the exported reduced-model base bounds. The scaffold adds the Radau
integration constraints, finite-element continuity constraints, and initial
condition constraints for the 19-state fermentation vector. The objective is a
zero-derivative regularization term only.

`add_reduced_dcdfba_rhs_residuals!(nlp)` adds the first smooth growth-mode RHS
residual scaffold. It links `state_derivative` to the collocation states and
selected reduced flux variables for biomass, nitrogen, glucose, fructose,
ethanol, protein, carbohydrate, amino acids, and aromas. Oxygen remains forced
to `dy[6] = 0.0` because `r_1992` is absent from the reduced model.
Carbohydrate remains empirical: `dy[8]` uses biomass flux and carbohydrate
death, not `r_4048`. Reaction mapping is still by `rxn_id`; `Indices_reacciones.csv`
is not used.

`add_reduced_dcdfba_primal_feasibility!(nlp)` adds the reduced FBA primal
feasibility rows `S*v = 0` at every collocation point. These constraints use
the reduced stoichiometric matrix and the reduced flux variables already
present in the scaffold. For the default `nfe = 1`, `degree = 3` smoke shape,
this creates `1079 * 3` mass-balance rows.

`add_reduced_dcdfba_bound_feasibility!(nlp)` adds explicit reduced FBA
bound-feasibility rows at every collocation point. The lower-bound form is
`lb - v <= 0` with nonpositive lower-bound dual variables, and the upper-bound
form is `v - ub <= 0` with nonnegative upper-bound dual variables, matching
the De Oliveira-style sign convention used by the antecedent. For the default
`nfe = 1`, `degree = 3` smoke shape, this creates `2 * 1488 * 3` bound rows
and `2 * 1488 * 3` bound-dual variables. These rows duplicate the exported
flux variable bounds intentionally so the future KKT stationarity block has
explicit algebraic feasibility rows.

`add_reduced_dcdfba_stationarity!(nlp, bound)` adds mass-balance dual
variables and the reduced FBA KKT stationarity rows
`c + S'lambda + alpha_L + alpha_U = 0` at every collocation point. The vector
`c` is zero by default and follows a minimization convention; future
maximization objectives should pass negated objective weights when dynamic
objective handling is introduced. For the default `nfe = 1`, `degree = 3`
smoke shape, this creates `1079 * 3` free mass-balance dual variables and
`1488 * 3` stationarity rows.

`add_reduced_dcdfba_complementarity!(nlp, stationarity)` adds the quadratic
MPCC complementarity products `(v - lb) * alpha_L = 0` and
`(v - ub) * alpha_U = 0` at every collocation point. For the default
`nfe = 1`, `degree = 3` smoke shape, this creates `2 * 1488 * 3`
complementarity rows. This completes the fixed-bound reduced FBA KKT algebraic
scaffold, but it still does not solve the MPCC.

Smooth growth-mode dynamic bound handling is available as an opt-in scaffold:

```julia
dynamic_bounds = build_reduced_dcdfba_dynamic_bounds(nlp)
bound = add_reduced_dcdfba_bound_feasibility!(nlp; dynamic_bounds = dynamic_bounds)
stationarity = add_reduced_dcdfba_stationarity!(
    nlp,
    bound;
    objective_coefficients = dynamic_bounds.objective_coefficients,
)
complementarity = add_reduced_dcdfba_complementarity!(nlp, stationarity)
```

`build_reduced_dcdfba_dynamic_bounds(nlp)` builds state-dependent Zenteno
growth-mode lower/upper bound expressions over the collocation states and a
minimization-form objective coefficient vector. The bound expressions are
consumed by the bound-feasibility and complementarity rows so the existing
bound-dual variables remain attached to the active dynamic-or-base bounds.
This currently covers smooth growth mode only: glucose/fructose uptake lower
bounds, ethanol upper bound, nitrogen-source lower bounds, amino-acid lower
bounds, aroma lower bounds, and the growth objective coefficients. Turnover
mode, non-smooth `max` handling, and production solve policy remain deferred.
Oxygen `r_1992` is still absent in the reduced model, `r_0001` is not used as
oxygen, and carbohydrate `r_4048` still has no dynamic bound update.

Sequential reduced DFBA trajectories can now be used as solver starts for the
collocation NLP:

```julia
init = initialize_reduced_dcdfba_from_simulation!(nlp, simulation)
```

The initializer consumes an existing `SimulationResult`; it does not run an
ODE, solve an LP, call Ipopt, or create output files. It linearly interpolates
saved sequential states to finite-element boundaries and Radau collocation
times, uses piecewise-linear saved-state slopes as `state_derivative` starts,
and applies sequential flux starts only for reaction IDs present in
`simulation.metadata["flux_rxn_ids"]`. Missing flux reactions preserve their
existing starts, so the guarded smoke can still seed the full reduced flux
vector from static FBA and overwrite only reported sequential fluxes:

```julia
problem = build_reduced_dcdfba_mpcc_smoke_problem(
    model,
    reaction_map;
    sequential_initialization = simulation,
)
```

Flux starts from the sequential result are clamped to the exported reduced
base bounds before being passed to JuMP. This is an initialization heuristic,
not a proof of scientific equivalence and not a solved simultaneous
trajectory.

This is still a scaffold, not a scientific simultaneous DFBA solver. It does
not produce a solved simultaneous trajectory. Dynamic bounds are opt-in,
growth-mode structural rows only; the default path remains fixed-bound. The
current RHS scaffold is fixed to smooth growth mode and intentionally avoids
non-smooth `max` operators used by the sequential RHS.
The first real MPCC target remains reduced DFBA. Full-model and DFVB KKT
formulations remain deferred.

For guarded solver-entry checks, use:

```julia
problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map)
result = solve_reduced_dcdfba_mpcc_smoke(model, reaction_map)
```

The smoke initializes flux starts from a static reduced FBA solve and builds
the fixed-bound reduced FBA MPCC scaffold by default. Use
`use_dynamic_bounds = true` to build the same smoke with smooth growth-mode
dynamic bounds and objective coefficients wired into the KKT rows. By default,
`solve_reduced_dcdfba_mpcc_smoke` uses `ipopt_max_iter = 0`, so it verifies
Ipopt/MUMPS model entry and diagnostics without attempting a production solve.
With this guard, Ipopt may report `ITERATION_LIMIT` and an infeasible primal
status before taking restoration or feasibility iterations; that is a solver
entry diagnostic, not a failed scientific simulation.
This result is explicitly not a scientific simultaneous DFBA simulation. The
default test suite validates the smoke structurally; set
`FERMENTATIONDFBA_TEST_REDUCED_MPCC_SOLVE=1` to run the guarded Ipopt call
locally.

The public Ipopt constructor is now `ipopt_optimizer(; linear_solver=...)`.
Supported values are `mumps`, `spral`, `pardiso`, `ma57`, `ma86`, and `ma97`;
`ipopt_mumps_optimizer` remains as a compatibility alias. The local default is
still `mumps`, `spral` is the open local production candidate, and `pardiso` is
opt-in because it requires an externally configured Ipopt/PARDISO setup rather
than a required project dependency. Use `MPCC_IPOPT_LINEAR_SOLVER=spral` or pass
`linear_solver = "spral"` to the reduced MPCC solve/window APIs.
Ipopt's native warm-start mode is opt-in via
`MPCC_IPOPT_WARM_START_INIT_POINT=1`. This only enables Ipopt's
`warm_start_init_point=yes`; it does not by itself provide Ipopt constraint or
bound multiplier starts. The reduced MPCC still reports those pieces separately.

For the first guarded dynamic MPCC solve attempt, use:

```julia
thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
attempt = solve_reduced_dcdfba_mpcc_solve_attempt(
    model,
    reaction_map;
    sequential_initialization = simulation,
    residual_thresholds = thresholds,
    ipopt_max_iter = 100,
)
```

This wrapper always builds the reduced problem with RHS residuals, smooth
growth-mode dynamic bounds and objective coefficients, and sequential
initialization starts. Before calling Ipopt, it runs the same pre-solve
diagnostics used by `diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)` and
requires both residual readiness and scaling readiness by default. Solve
attempts use Scholtes-relaxed complementarity by default:
`-((v - lb) * alpha_L) <= tau` and `-((v - ub) * alpha_U) <= tau`, with
`tau = 1e-4` unless overridden by `MPCC_COMPLEMENTARITY_TAU` or
`complementarity_tau`. The diagnostic tau gate accepts Ipopt-scale numerical
roundoff using `max(1e-8, 1e-4 * tau)` by default; override it with
`MPCC_COMPLEMENTARITY_TAU_GATE_TOL` or `complementarity_tau_gate_tol = 0.0` for
strict comparison. Exact quadratic equalities remain available with
`complementarity_mode = :exact` for regression and comparison tests. The result
records finite residual diagnostics for RHS, mass balance, bound violations,
stationarity, complementarity products, and tau-gate violation, then compares
the real products with the configured diagnostic thresholds. The residual
report also stores residual ratios, ranked residual labels, the dominant
residual, pre-solve guard metadata, and post-solve trajectory-candidate
metadata. A true `trajectory_extraction_ready` flag is only a numerical gate; it
is still not a scientific simulation claim. If Ipopt returns `ITERATION_LIMIT`
with a feasible or nearly feasible primal point and residuals below the
diagnostic thresholds, the metadata labels it as
`post_solve_iteration_limit_residual_feasible_candidate`; this is useful for
convergence review but is still not trajectory-extraction ready until the solver
termination status also allows a candidate. The default thresholds are:

- `max_rhs_residual <= 1e-6`
- `max_mass_balance_residual <= 1e-6`
- `max_lower_bound_violation <= 1e-6`
- `max_upper_bound_violation <= 1e-6`
- `max_stationarity_residual <= 1e-5`
- `max_lower_complementarity_residual <= 1e-5`
- `max_upper_complementarity_residual <= 1e-5`

These are numerical diagnostics only, not scientific acceptance criteria and
not proof of reduced/full equivalence. The default test suite validates this
path structurally; set `FERMENTATIONDFBA_TEST_REDUCED_MPCC_DYNAMIC_SOLVE=1`
to run the guarded dynamic solve attempt locally.

For homotopy over the Scholtes relaxation, use
`solve_reduced_dcdfba_mpcc_tau_continuation(...)`. The default schedule is
`[1e-2, 1e-4, 1e-6]` and can be overridden with
`MPCC_TAU_SCHEDULE=1e-2,1e-4,1e-6` or `tau_schedule = [...]`. Each stage
rebuilds the same reduced MPCC window, warm-starts states, fluxes, bound duals,
and mass-balance duals from the previous finite candidate. Intermediate stages
advance when a warm-startable candidate passes post-solve residual availability,
primal-status, and Scholtes `tau` gates; final completion requires both the
residual-feasible complementarity products and the final `tau` gate. After the
first guarded stage, tighter warm-started stages run as diagnostic solver calls
because the previous candidate is expected to violate the next, smaller `tau` at
initialization. Stage metadata includes `tau`, solver status, solve time,
residual-feasible flag, advance/blocking reason, and
`max_complementarity_tau_violation`, plus the effective
`complementarity_tau_gate_tolerance`.

For scaling diagnostics, tau continuation returns the lowest-`tau`
residual-feasible stage rather than forcing a failed polish stage to replace a
usable candidate. A failed tighter stage is recorded as
`tau_continuation_polish_failed=true`, with both
`tau_continuation_selected_tau` and `tau_continuation_attempted_final_tau`
reported. Per-stage Ipopt iteration budgets can be set with
`MPCC_TAU_STAGE_MAX_ITERS=500,800,300` or `tau_stage_max_iters = [...]`; use
`default` in a slot to fall back to the solve attempt `ipopt_max_iter`.

After a guarded solve attempt, `extract_reduced_dcdfba_mpcc_candidate(result)`
returns a `ReducedDCDFBAMPCCCandidateDiagnostics` object when JuMP result values
are available. It stores post-solve arrays for state boundaries, collocation
states, derivatives, fluxes, bound duals, and mass-balance duals, plus residual
ratios, bound-activity counts, dual-sign checks, and dynamic collocation/RHS
residual summaries. This is a candidate diagnostic only:
`candidate_is_scientific_simulation = false`, `solved_trajectory_claimed = false`,
and `candidate_trajectory_extraction_ready` remains tied to the guarded solver
status and residual gates.

`extract_reduced_dcdfba_mpcc_trajectory_candidate(result)` converts those
candidate values into a `ReducedDCDFBAMPCCTrajectoryCandidate` with two
state-only `SimulationResult` views: finite-element boundary states and Radau
collocation states. Full reduced flux values remain in
`candidate_diagnostics.flux` rather than in `SimulationResult.fluxes` because
the reduced reaction list contains `r_0001`, and the generic simulation export
guard forbids treating `r_0001` as a normal exported flux ID. This trajectory
candidate is still diagnostic-only:
`trajectory_candidate_is_scientific_simulation = false`,
`trajectory_candidate_is_validated_simulation = false`, and
`trajectory_candidate_solved_trajectory_claimed = false`.

`compare_reduced_dcdfba_mpcc_to_sequential(...)` compares those boundary-state
values against reduced sequential DFBA on the same finite-element boundary
times. The report returns summary, state-metric, and aligned-timeseries tables
for the 19 fermentation states plus derived `total_sugar`. It is state-only:
full reduced flux arrays remain in `candidate_diagnostics.flux`, flux
comparison is deferred, and `full_dfba_cold` remains the later scientific
baseline.

`sweep_reduced_dcdfba_mpcc_solve_attempts(...)` aggregates short reduced MPCC
solve-attempt scenarios across small `(horizon, nfe)` grids. Each completed
scenario calls the reduced MPCC-vs-sequential comparison path and records an
in-memory `scenario_table` with solver status, primal status, solve time,
residual gates, dominant residual, recommended next action, state mismatch
metrics, and scientific guardrail flags. The sweep writes no files, introduces
no new solver options, uses no HSL/MA57, does not run the full model, and does
not claim a solved MPCC trajectory. It is intended to identify which short
reduced scenarios are worth a closer convergence review before attempting
longer horizons.

Run the reduced MPCC horizon/nfe sweep script from the repository root:

```bash
julia --project scripts/main_sweep_reduced_mpcc_solve_attempts.jl
```

The default `MPCC_SWEEP_PROFILE=smoke` evaluates only `(horizon=0.25, nfe=1)`.
For the first systematic escalation grid, run:

```bash
MPCC_SWEEP_PROFILE=escalation julia --project scripts/main_sweep_reduced_mpcc_solve_attempts.jl
```

Custom grids can be supplied with comma-separated values:

```bash
MPCC_SWEEP_PROFILE=custom MPCC_SWEEP_HORIZONS_HOURS=0.25,0.5 MPCC_SWEEP_NFE_VALUES=1,2 julia --project scripts/main_sweep_reduced_mpcc_solve_attempts.jl
```

If the requested grid exceeds `MPCC_SWEEP_MAX_SCENARIOS`, the script stops
unless `MPCC_SWEEP_ALLOW_LARGE_GRID=1` is set deliberately. The script prints a
compact scenario table only; it does not export generated CSV/TOML files.

`sweep_reduced_dcdfba_mpcc_ipopt_iterations(...)` reruns the same reduced
MPCC horizon/nfe sweep across selected Ipopt `max_iter` values. It preserves
the same formulation, starts, MUMPS linear solver, residual gates, and
scientific guardrails while reporting whether extra iterations convert
`ITERATION_LIMIT` cases into trajectory-ready `LOCALLY_SOLVED` candidates. The
result is an in-memory sensitivity table; it does not add HSL/MA57, does not
change tolerances, and does not write generated outputs.

Run the default small iteration sensitivity script from the repository root:

```bash
julia --project scripts/main_sweep_reduced_mpcc_ipopt_iterations.jl
```

The default `MPCC_ITER_PROFILE=smoke` evaluates `(horizon=0.25, nfe=1)` with
`max_iter = 100,200`. A focused local diagnostic can be requested with:

```bash
MPCC_ITER_PROFILE=focused julia --project scripts/main_sweep_reduced_mpcc_ipopt_iterations.jl
```

Custom iteration grids can be supplied with comma-separated values:

```bash
MPCC_ITER_PROFILE=custom MPCC_ITER_HORIZONS_HOURS=1.0 MPCC_ITER_NFE_VALUES=2 MPCC_ITER_MAX_ITER_VALUES=100,500,1000 julia --project scripts/main_sweep_reduced_mpcc_ipopt_iterations.jl
```

If `length(horizons) * length(nfe_values) * length(max_iter_values)` exceeds
`MPCC_ITER_MAX_SOLVES`, the script stops unless
`MPCC_ITER_ALLOW_LARGE_GRID=1` is set deliberately.

`sweep_reduced_dcdfba_mpcc_mesh_refinement(...)` reruns the reduced MPCC
solve-attempt sweep across finite-element counts for fixed horizons. It marks
whether a finer mesh first achieves `trajectory_ready` and whether the state
relative RMSE improves compared with the next coarser `nfe`. This preserves the
same formulation, starts, Ipopt/MUMPS profile, and reduced-model scope; it does
not add HSL/MA57, does not run the full model, and does not write generated
outputs.

Run the default mesh refinement script from the repository root:

```bash
julia --project scripts/main_sweep_reduced_mpcc_mesh_refinement.jl
```

The default `MPCC_MESH_PROFILE=smoke` evaluates `horizon=0.5` with `nfe=1,2`.
A focused local diagnostic can be requested with:

```bash
MPCC_MESH_PROFILE=focused julia --project scripts/main_sweep_reduced_mpcc_mesh_refinement.jl
```

Custom mesh grids can be supplied with comma-separated values:

```bash
MPCC_MESH_PROFILE=custom MPCC_MESH_HORIZONS_HOURS=1.0 MPCC_MESH_NFE_VALUES=2,4 julia --project scripts/main_sweep_reduced_mpcc_mesh_refinement.jl
```

If the requested grid exceeds `MPCC_MESH_MAX_SCENARIOS`, the script stops
unless `MPCC_MESH_ALLOW_LARGE_GRID=1` is set deliberately.

`run_reduced_dcdfba_mpcc_windowed_continuation(...)` chains short reduced MPCC
solve attempts in uniform time windows. Each window is initialized from a local
reduced sequential DFBA run, and a window can pass its final MPCC boundary
candidate state to the next window only when the configured continuation policy
accepts that candidate. The default policy is `residual_feasible`, which
preserves the existing diagnostic behavior. The stricter `trajectory_ready`
policy accepts only solver-ready candidates. The controlled diagnostic policy
`iteration_limit_residual_feasible_state_drift` accepts `trajectory_ready`
candidates and residual-feasible `ITERATION_LIMIT` candidates only when the
state-drift gate passes. The drift gate is evaluated per state: each state must
pass either `MPCC_WINDOW_STATE_ABS_DIFF_THRESHOLD` or
`MPCC_WINDOW_STATE_REL_RMSE_THRESHOLD`, avoiding false rejects when the maximum
absolute and maximum relative drift come from different state scales. Each
window row records `continuation_acceptance_policy`,
`continuation_acceptance_reason`, `continuation_state_drift_gate_pass`,
`continuation_state_drift_gate_mode`, and `iteration_limit_policy_accepted`.
The resulting boundary candidate is
concatenated and compared against a reduced sequential DFBA reference over the
reached horizon. This is a diagnostic continuation workflow for testing whether
short solved or residual-feasible windows can be stitched before attempting
longer monolithic horizons; it is not a solved scientific simultaneous DFBA
simulation and does not replace `full_dfba_cold` as the scientific sequential
baseline.

Accepted windows now also propagate the previous candidate's final
collocation-point fluxes and explicit KKT dual variables into the next window
as Ipopt start values. States still come from the local sequential reduced DFBA
initialization and the accepted MPCC final boundary state. The propagated
flux/dual seed is applied after the pre-solve guard, projected to the next
window's dynamic flux bounds, sign-clipped for bound-dual variables, and
recorded with `cross_window_flux_dual_start_*` metadata. Disable this diagnostic
warm start with `MPCC_WINDOW_PROPAGATE_FLUX_DUAL_STARTS=0` when comparing
against the older state-only continuation path.

Run the default windowed continuation diagnostic from the repository root:

```bash
julia --project scripts/main_reduced_mpcc_windowed_continuation.jl
```

The default `MPCC_WINDOW_PROFILE=smoke` evaluates two 0.25-hour windows with
`nfe=1` per window. A focused local diagnostic can be requested with:

```bash
MPCC_WINDOW_PROFILE=focused julia --project scripts/main_reduced_mpcc_windowed_continuation.jl
```

Custom runs can be supplied with scalar environment variables:

```bash
MPCC_WINDOW_PROFILE=custom MPCC_WINDOW_HOURS=0.5 MPCC_WINDOW_COUNT=4 MPCC_WINDOW_NFE=1 julia --project scripts/main_reduced_mpcc_windowed_continuation.jl
```

The continuation policy can also be selected from the script:

```bash
MPCC_WINDOW_PROFILE=focused MPCC_WINDOW_CONTINUATION_POLICY=iteration_limit_residual_feasible_state_drift MPCC_WINDOW_STATE_ABS_DIFF_THRESHOLD=1e-4 MPCC_WINDOW_STATE_REL_RMSE_THRESHOLD=0.02 julia --project scripts/main_reduced_mpcc_windowed_continuation.jl
```

The recommended reduced-MPCC production-shaped local profile is `2h4nfe`: two
hour windows, `nfe = 4`, Radau degree 3, boundary spacing `0.5 h`,
Scholtes complementarity, tau continuation, and `SPRAL` unless
`MPCC_IPOPT_LINEAR_SOLVER` is set explicitly. For a one-window smoke:

```powershell
$env:MPCC_WINDOW_PROFILE="2h4nfe"; julia --project scripts/main_reduced_mpcc_windowed_continuation.jl
```

The same entrypoint exposes the diagnostic residual gates used for longer
2h/4nfe continuation attempts:

- `MPCC_RESIDUAL_MAX_RHS`
- `MPCC_RESIDUAL_MAX_MASS`
- `MPCC_RESIDUAL_MAX_BOUND`, or `MPCC_RESIDUAL_MAX_LOWER_BOUND` and
  `MPCC_RESIDUAL_MAX_UPPER_BOUND`
- `MPCC_RESIDUAL_MAX_STATIONARITY`
- `MPCC_RESIDUAL_MAX_COMPLEMENTARITY`, or
  `MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY` and
  `MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY`

The current local diagnostic candidate for 24-32h should keep Ipopt native
warm-start disabled and cross-window KKT flux/dual starts disabled; the useful
continuation knob is instead stage-level tau iteration caps:

```powershell
$env:MPCC_WINDOW_PROFILE="custom"
$env:MPCC_WINDOW_HOURS="2.0"
$env:MPCC_WINDOW_NFE="4"
$env:MPCC_WINDOW_ALLOW_LONG="1"
$env:MPCC_WINDOW_USE_TAU_CONTINUATION="1"
$env:MPCC_TAU_SCHEDULE="1e-2,1e-4,1e-6"
$env:MPCC_TAU_STAGE_MAX_ITERS="500,800,300"
$env:MPCC_IPOPT_LINEAR_SOLVER="mumps"
$env:MPCC_IPOPT_WARM_START_INIT_POINT="0"
$env:MPCC_WINDOW_PROPAGATE_FLUX_DUAL_STARTS="0"
$env:MPCC_RESIDUAL_MAX_MASS="5e-6"
$env:MPCC_RESIDUAL_MAX_COMPLEMENTARITY="2e-6"
```

For a 24-hour diagnostic run, set `MPCC_WINDOW_COUNT=12` and
`MPCC_WINDOW_MAX_WINDOWS=12`; for 32 hours use `16` for both values.
These are continuation diagnostics only: passing these gates does not claim a
scientific solved trajectory.

For a 72-hour diagnostic attempt with the same grid:

```powershell
$env:MPCC_WINDOWED_ATTEMPT_PROFILE="2h4nfe"; $env:MPCC_WINDOWED_ATTEMPT_ALLOW_LONG="1"; julia --project scripts/main_reduced_mpcc_windowed_72h_attempt.jl
```

For the 72-hour runner wrapper:

```powershell
$env:MPCC_WINDOWED_72H_RUNNER_PROFILE="2h4nfe"; $env:MPCC_WINDOWED_72H_RUNNER_ALLOW_LONG="1"; julia --project scripts/main_reduced_mpcc_windowed_72h_simulation.jl
```

If `MPCC_WINDOW_COUNT` exceeds `MPCC_WINDOW_MAX_WINDOWS`, the script stops
unless `MPCC_WINDOW_ALLOW_LONG=1` is set deliberately. The script writes no
CSV/TOML/SVG outputs, uses the configured Ipopt linear solver, does not require
HSL/MA57 unless an HSL backend is explicitly selected, does not run the full
model, and does not touch DFVB KKT.

`assess_reduced_dcdfba_mpcc_simulation_viability(...)` applies an explicit
traffic-light gate to reduced MPCC diagnostic outputs. It accepts short
solve-attempt sweeps, Ipopt iteration-sensitivity reports, mesh-refinement
reports, and windowed-continuation reports, then returns a
`ReducedDCDFBAMPCCSimulationViabilityReport` with one normalized
`viability_table`. Green rows are diagnostic `simulation_viable_candidate`
rows; yellow rows are residual-feasible but still blocked by solver-status or
sensitivity review; red rows fail a required residual, drift, continuation, or
scientific guardrail gate.

The default numerical gate requires:

- `candidate_trajectory_ready = true`
- all residual diagnostics within the existing reduced MPCC thresholds
- `max_state_abs_difference <= 1e-4`
- `max_state_relative_rmse <= 2e-2`
- for windowed continuation, matching global drift thresholds over the reached
  horizon
- full-model, DFVB, HSL/MA57, warm-start baseline, and reaction-mapping
  guardrails preserved

Run the default semaphore script from the repository root:

```bash
julia --project scripts/main_reduced_mpcc_simulation_viability.jl
```

The default source is `MPCC_VIABILITY_SOURCE=windowed`, using two 0.25-hour
windows with `nfe=1`. Other diagnostic sources can be selected without writing
outputs:

```bash
MPCC_VIABILITY_SOURCE=sweep MPCC_VIABILITY_HORIZON_HOURS=0.5 MPCC_VIABILITY_NFE=2 julia --project scripts/main_reduced_mpcc_simulation_viability.jl
MPCC_VIABILITY_SOURCE=mesh MPCC_VIABILITY_HORIZON_HOURS=0.5 MPCC_VIABILITY_MESH_NFE_VALUES=1,2 julia --project scripts/main_reduced_mpcc_simulation_viability.jl
```

This semaphore is a decision aid only. A green diagnostic candidate is not a
scientific validation, does not prove reduced/full equivalence, and does not
replace the later `full_dfba_cold` reference.

`sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(...)` runs an ordered
monolithic reduced MPCC escalation sweep and applies the semaphore to each
case. The default policy derives `nfe` from a fixed boundary spacing
`boundary_dt = 0.25 h`, so `horizon = 0.5` maps to `nfe = 2`,
`horizon = 0.75` maps to `nfe = 3`, and so on. The frontier report marks:

- the last green `simulation_viable_candidate`;
- the first non-green case after the last green;
- the first blocking class, such as solver termination, state drift, residual
  failure, or guardrail failure;
- total solve time across frontier cases;
- a compact recommended next action.

Run the default frontier smoke from the repository root:

```bash
julia --project scripts/main_reduced_mpcc_viability_frontier.jl
```

The default `MPCC_FRONTIER_PROFILE=smoke` evaluates only `horizon=0.5` with
the derived `nfe=2`. A focused frontier can be requested with:

```bash
MPCC_FRONTIER_PROFILE=focused julia --project scripts/main_reduced_mpcc_viability_frontier.jl
```

Custom frontiers can be supplied with comma-separated horizons and, when
needed, explicit finite-element counts:

```bash
MPCC_FRONTIER_PROFILE=custom MPCC_FRONTIER_HORIZONS_HOURS=0.5,0.75,1.0 MPCC_FRONTIER_BOUNDARY_DT_HOURS=0.25 julia --project scripts/main_reduced_mpcc_viability_frontier.jl
MPCC_FRONTIER_PROFILE=custom MPCC_FRONTIER_HORIZONS_HOURS=0.5,1.0 MPCC_FRONTIER_NFE_VALUES=2,4 julia --project scripts/main_reduced_mpcc_viability_frontier.jl
```

The frontier is diagnostic only. It writes no CSV/TOML/SVG outputs, uses the
same reduced MPCC formulation and Ipopt/MUMPS path, does not add HSL/MA57, does
not run the full model, and does not touch DFVB KKT.

`attempt_reduced_dcdfba_mpcc_windowed_simulation(...)` wraps the existing
windowed-continuation diagnostic as a target-horizon attempt. It computes the
required number of uniform windows from `target_horizon / window_hours`, runs
the reduced MPCC continuation, applies the simulation-viability semaphore, and
returns a `ReducedDCDFBAMPCCWindowedSimulationAttemptResult` with:

- the original `ReducedDCDFBAMPCCWindowedContinuationResult`;
- the associated `ReducedDCDFBAMPCCSimulationViabilityReport`;
- an `attempt_table` containing global and per-window traffic lights;
- metadata for `target_completed`, `horizon_reached`, `horizon_gap`,
  `attempt_traffic_light`, first non-green/red/residual-infeasible window, and
  total solve time.

The default API target is 72 hours, but the script defaults to a short smoke
profile so accidental long runs are avoided:

```bash
julia --project scripts/main_reduced_mpcc_windowed_72h_attempt.jl
```

The smoke profile evaluates a 0.5-hour target using one 0.5-hour window with
two finite elements, matching the current short green candidate. A small pilot
uses a 2-hour target with 0.5-hour windows and two finite elements per window:

```bash
MPCC_WINDOWED_ATTEMPT_PROFILE=pilot julia --project scripts/main_reduced_mpcc_windowed_72h_attempt.jl
```

The opt-in 72-hour profile uses 144 windows of 0.5 hours, with `nfe=2` per
window, and prints progress by default:

```bash
MPCC_WINDOWED_ATTEMPT_PROFILE=72h julia --project scripts/main_reduced_mpcc_windowed_72h_attempt.jl
```

Custom target-horizon attempts can be supplied with scalar environment
variables. If the derived window count exceeds
`MPCC_WINDOWED_ATTEMPT_MAX_WINDOWS`, the script stops unless
`MPCC_WINDOWED_ATTEMPT_ALLOW_LONG=1` is set deliberately:

```bash
MPCC_WINDOWED_ATTEMPT_PROFILE=custom MPCC_WINDOWED_ATTEMPT_TARGET_HOURS=4.0 MPCC_WINDOWED_ATTEMPT_WINDOW_HOURS=0.5 MPCC_WINDOWED_ATTEMPT_NFE=2 julia --project scripts/main_reduced_mpcc_windowed_72h_attempt.jl
```

This is still a reduced-model diagnostic. It writes no CSV/TOML/SVG outputs,
does not use the full model as an MPCC base, does not touch DFVB KKT, does not
add HSL/MA57, and does not mark the result as a solved scientific simulation.

`run_reduced_dcdfba_mpcc_windowed_72h_simulation(...)` is the guarded runner
for the current practical 72-hour reduced MPCC path. It reuses the same
windowed target-horizon attempt, exposes the concatenated boundary candidate
and reduced sequential reference in memory, and records a compact
`runner_table`. The runner deliberately does not launch a monolithic global
polish over the full horizon because the observed 8-hour monolithic path is
limited by MUMPS linear-algebra scale. It also does not apply window retries,
retry replacements, or cascade rebuilds by default.

Run the short smoke from the repository root. The smoke uses one 0.25-hour
window with one finite element so the entrypoint remains cheap:

```bash
julia --project scripts/main_reduced_mpcc_windowed_72h_simulation.jl
```

Run the explicit 72-hour windowed runner when you want the long diagnostic:

```bash
MPCC_WINDOWED_72H_RUNNER_PROFILE=72h julia --project scripts/main_reduced_mpcc_windowed_72h_simulation.jl
```

The script accepts `MPCC_WINDOWED_72H_RUNNER_TARGET_HOURS`,
`MPCC_WINDOWED_72H_RUNNER_WINDOW_HOURS`, `MPCC_WINDOWED_72H_RUNNER_NFE`,
`MPCC_WINDOWED_72H_RUNNER_IPOPT_MAX_ITER`, and
`MPCC_REDUCED_MPCC_IPOPT_PROFILE`. It prints progress for the 72-hour profile,
writes no files, keeps the first MPCC target reduced DFBA, keeps
`full_dfba_cold` deferred as the scientific baseline, and records
`global_monolithic_mpcc_solve_attempted = false`.

`sweep_reduced_dcdfba_mpcc_windowed_policy_horizons(...)` runs or aggregates a
diagnostic grid of reduced MPCC windowed attempts over target horizons, window
durations, finite elements per window, continuation policies, and
state-relative-RMSE gates. It returns a
`ReducedDCDFBAMPCCWindowedPolicyHorizonSweepResult` with a
`policy_horizon_table`, the underlying attempt results, and metadata for the
best green case, maximum reached horizon, first non-green policy/horizon case,
policy counts, scale-readiness counts, primary blocker counts, and recommended
next action. Each row includes `scale_readiness`, `primary_blocker`,
`scale_recommended_next_action`, `is_scale_candidate`, `is_72h_ready_candidate`,
and `next_target_horizon_hint`, so a focused sweep can identify whether the
next move is horizon extension, solver retry, residual repair, or drift
reduction. This sweep is intended to choose a defensible policy/grid before a
long 72-hour attempt; it does not validate a scientific trajectory.

Run the default smoke from the repository root:

```bash
julia --project scripts/main_reduced_mpcc_windowed_policy_horizon_sweep.jl
```

The focused profile compares `residual_feasible` against
`iteration_limit_residual_feasible_state_drift` over 0.5- and 1-hour targets:

```bash
MPCC_WINDOWED_POLICY_SWEEP_PROFILE=focused julia --project scripts/main_reduced_mpcc_windowed_policy_horizon_sweep.jl
```

The opt-in 72-hour profile evaluates progressively longer targets up to 72
hours using 0.5-hour windows and the drift-gated iteration-limit policy:

```bash
MPCC_WINDOWED_POLICY_SWEEP_PROFILE=72h MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LONG=1 julia --project scripts/main_reduced_mpcc_windowed_policy_horizon_sweep.jl
```

The `2h4nfe` profile evaluates progressive targets
`2,4,8,16,32,72 h` using `window_hours = 2.0`, `nfe = 4`,
Radau degree 3, boundary spacing `0.5 h`, Scholtes tau continuation, and
`linear_solver in (mumps, spral)` by default:

```powershell
$env:MPCC_WINDOWED_POLICY_SWEEP_PROFILE="2h4nfe"; $env:MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LONG="1"; $env:MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LARGE="1"; julia --project scripts/main_reduced_mpcc_windowed_policy_horizon_sweep.jl
```

Custom sweeps can be supplied with comma-separated values:

```bash
MPCC_WINDOWED_POLICY_SWEEP_PROFILE=custom MPCC_WINDOWED_POLICY_SWEEP_TARGET_HOURS=0.5,1.0,2.0 MPCC_WINDOWED_POLICY_SWEEP_WINDOW_HOURS=0.5 MPCC_WINDOWED_POLICY_SWEEP_NFE=2 MPCC_WINDOWED_POLICY_SWEEP_CONTINUATION_POLICIES=residual_feasible,trajectory_ready MPCC_WINDOWED_POLICY_SWEEP_STATE_REL_RMSE_THRESHOLDS=0.02 julia --project scripts/main_reduced_mpcc_windowed_policy_horizon_sweep.jl
```

If the grid exceeds `MPCC_WINDOWED_POLICY_SWEEP_MAX_CASES`, or the largest
case exceeds `MPCC_WINDOWED_POLICY_SWEEP_MAX_WINDOWS`, the script stops unless
`MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LARGE=1` or
`MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LONG=1` is set deliberately. The script
writes no outputs, keeps the reduced MPCC target, reports solver status,
dominant residual, maximum complementarity products, tau-gate violation, first
blocking window, elapsed time, and the recommended next action. PARDISO is not
included in the default sensitivity grid; use `MPCC_IPOPT_LINEAR_SOLVER=pardiso`
or a custom linear-solver list only after configuring it locally. The sweep does
not run the full model and does not touch DFVB KKT.

Minimum review criteria for any reduced MPCC candidate remain: mass balance,
stationarity, bound feasibility, complementarity products, active tau violation,
drift versus the reduced sequential reference, solver status, and primal status.

`diagnose_reduced_dcdfba_mpcc_windowed_failure(attempt, model)` adds a
cause-oriented diagnostic layer for failed or yellow target-horizon attempts.
It consumes a `ReducedDCDFBAMPCCWindowedSimulationAttemptResult` and the
reduced `MetabolicModel`, then returns a
`ReducedDCDFBAMPCCWindowedFailureDiagnosticResult` with:

- a `window_summary_table` classifying each global/window row by likely cause;
- a `residual_ratio_table` with residual values, thresholds, and ratios;
- a `mass_balance_table` locating the largest `S*v = 0` residuals by window,
  finite element, Radau point, and metabolite ID;
- metadata for first non-green, first red, first residual-infeasible window,
  dominant residual, dominant mass-balance metabolite, and recommended action.

The 72-hour attempt script runs this failure diagnostic automatically after the
attempt and prints the dominant residual and top mass-balance rows. It does not
write outputs, relax thresholds, add solver dependencies, or reinterpret a red
attempt as a valid simulation.

`diagnose_reduced_dcdfba_mpcc_window_retry(attempt, model, reaction_map)`
reruns one selected reduced MPCC window with alternate Ipopt iteration budgets.
By default it selects the first residual-infeasible window, then the first red
window, then the first non-green window. The local retry keeps the same initial
state, `tspan`, finite-element count, degree, thresholds, reduced model, and
Ipopt/MUMPS solver path; only `ipopt_max_iter` is changed. It returns a
`ReducedDCDFBAMPCCWindowRetryDiagnosticResult` with a `retry_table`, retry
sweep/report objects, and metadata for the best retry, residual-feasibility
recovery, green-window recovery, elapsed retry solve time, and recommended next
action.

The 72-hour attempt script can run this diagnostic after a failed/yellow
attempt when explicitly enabled:

```bash
MPCC_WINDOWED_ATTEMPT_PROFILE=72h MPCC_WINDOWED_ATTEMPT_RETRY_ON_FAILURE=1 MPCC_WINDOWED_ATTEMPT_RETRY_MAX_ITERS=200,300,500 julia --project scripts/main_reduced_mpcc_windowed_72h_attempt.jl
```

This retry layer is still diagnostic-only. It writes no outputs, does not relax
residual thresholds, does not add HSL/MA57, does not change the KKT/MPCC
formulation, and does not claim a solved 72-hour scientific trajectory.

`sweep_reduced_dcdfba_mpcc_windowed_tolerances(model, reaction_map; ...)`
runs a diagnostic sensitivity sweep over the reduced MPCC windowed-attempt
mass-balance gate. The current sweep varies only
`max_mass_balance_residual`, keeping the same reduced model, initial state,
window size, finite-element grid, Ipopt/MUMPS path, and scientific guardrails.
It returns a `ReducedDCDFBAMPCCWindowedToleranceSensitivityResult` with a
`sensitivity_table`, the underlying attempt results, and metadata for the best
threshold case, the first threshold that extends the reached horizon, and the
first threshold that recovers the target horizon.

Run the default short smoke from the repository root:

```bash
julia --project scripts/main_reduced_mpcc_windowed_tolerance_sensitivity.jl
```

The opt-in 72-hour diagnostic profile tests the default mass-balance gate
against relaxed diagnostic gates:

```bash
MPCC_WINDOWED_TOL_PROFILE=72h julia --project scripts/main_reduced_mpcc_windowed_tolerance_sensitivity.jl
```

Custom target horizons and threshold lists are available:

```bash
MPCC_WINDOWED_TOL_PROFILE=custom MPCC_WINDOWED_TOL_TARGET_HOURS=8.0 MPCC_WINDOWED_TOL_WINDOW_HOURS=0.5 MPCC_WINDOWED_TOL_NFE=2 MPCC_WINDOWED_TOL_MAX_WINDOWS=16 MPCC_WINDOWED_TOL_MASS_THRESHOLDS=1e-6,5e-6 julia --project scripts/main_reduced_mpcc_windowed_tolerance_sensitivity.jl
```

This sensitivity layer is diagnostic-only. A relaxed threshold can show whether
the previous `window_014` stop was a strict numerical gate, but it does not by
itself validate the trajectory scientifically, prove reduced/full equivalence,
or change the default threshold policy.

`diagnose_reduced_dcdfba_mpcc_windowed_drift(...)` adds a state-drift layer on
top of a reduced MPCC windowed target-horizon attempt. It keeps the same
reduced model, window grid, Ipopt/MUMPS path, residual thresholds, and
scientific guardrails, then reports where the MPCC boundary candidate diverges
from reduced sequential DFBA after mass-balance gating has been inspected. It
uses the same per-state absolute-or-relative drift gate as windowed
continuation, while still reporting the raw maximum absolute and relative
drifts separately. A large global relative drift can therefore be diagnostic
rather than blocking if it belongs to a trace state with tiny absolute error.
The script-level `2h4nfe` profile enables tau continuation by default and uses
`MPCC_WINDOWED_DRIFT_STATE_ABS_DIFF_THRESHOLD` plus
`MPCC_WINDOWED_DRIFT_STATE_REL_RMSE_THRESHOLD` for the scale-aware gate. It
returns a `ReducedDCDFBAMPCCWindowedDriftDiagnosticResult` with:

- a `window_drift_table` ranking each window by absolute and relative state
  mismatch, dominant state, solver status, trajectory-readiness flag, and
  viability class;
- a `state_drift_table` with per-window and global state rankings, including
  focus-state flags for biomass, nitrogen, glucose, fructose, total sugar,
  ethanol, protein, and carbohydrate;
- a `timepoint_drift_table` locating the largest pointwise state differences;
- metadata for first state-drift window, first non-trajectory-ready window,
  dominant global drift state, dominant time point, drift pattern, and
  recommended next action.

Run the default short smoke from the repository root:

```bash
julia --project scripts/main_reduced_mpcc_windowed_drift_diagnostics.jl
```

The focused 8-hour diagnostic uses the relaxed mass-balance gate that recovered
the target horizon in the tolerance-sensitivity check:

```bash
MPCC_WINDOWED_DRIFT_PROFILE=8h julia --project scripts/main_reduced_mpcc_windowed_drift_diagnostics.jl
```

For the production-shaped local window profile:

```powershell
$env:MPCC_WINDOWED_DRIFT_PROFILE="2h4nfe"; $env:MPCC_IPOPT_LINEAR_SOLVER="mumps"; $env:MPCC_TAU_SCHEDULE="1e-2,1e-4,1e-6"; julia --project scripts/main_reduced_mpcc_windowed_drift_diagnostics.jl
```

The opt-in 72-hour profile uses 144 windows of 0.5 hours and remains a manual
diagnostic:

```bash
MPCC_WINDOWED_DRIFT_PROFILE=72h julia --project scripts/main_reduced_mpcc_windowed_drift_diagnostics.jl
```

This drift layer writes no outputs, does not relax default thresholds, does not
add solver dependencies, does not touch full-model or DFVB KKT code, and does
not claim a solved scientific trajectory.

`diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(...)` applies the existing
single-window retry diagnostic to several selected windows from one reduced
MPCC target-horizon attempt. The default selection policy targets windows with
`ITERATION_LIMIT` or `trajectory_ready=false`, preserving the source attempt's
residual gates, reduced-model scope, Ipopt/MUMPS path, and scientific
guardrails. It returns a
`ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult` with:

- a `retry_policy_table` summarizing each selected source window, the best
  retry budget, whether `green` or `trajectory_ready` was recovered, and the
  remaining recommended action;
- the underlying `ReducedDCDFBAMPCCWindowRetryDiagnosticResult` objects;
- metadata for selected window indices, recovery counts, first unrecovered
  window, and retry-policy recommendation.

Run the default smoke from the repository root:

```bash
julia --project scripts/main_reduced_mpcc_windowed_retry_policy_diagnostics.jl
```

The focused profile reruns up to two selected 0.5-hour windows with alternate
Ipopt iteration budgets:

```bash
MPCC_WINDOWED_RETRY_PROFILE=focused julia --project scripts/main_reduced_mpcc_windowed_retry_policy_diagnostics.jl
```

The 8-hour diagnostic profile is intended to test whether the `ITERATION_LIMIT`
windows seen after the relaxed mass-balance gate can be recovered by a local
retry policy:

```bash
MPCC_WINDOWED_RETRY_PROFILE=8h julia --project scripts/main_reduced_mpcc_windowed_retry_policy_diagnostics.jl
```

This retry-policy layer is still diagnostic-only. It writes no outputs, does
not change default thresholds, does not add HSL/MA57, does not switch away from
the reduced MPCC target, and does not claim a solved scientific trajectory.

`attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(...)` combines a
target-horizon reduced MPCC windowed attempt with the multi-window retry-policy
diagnostic. It returns a
`ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult` containing the base attempt,
the retry-policy diagnostic, a one-row `summary_table`, and metadata for the
retry-aware classification. This block does not replace failed/yellow windows
inside the concatenated trajectory; it only decides whether retry replacement
looks promising enough to justify a later rebuild step.

Run the default smoke:

```bash
julia --project scripts/main_reduced_mpcc_windowed_retry_aware_attempt.jl
```

A focused local run uses short windows and alternate retry iteration budgets:

```bash
MPCC_WINDOWED_RETRY_AWARE_PROFILE=focused julia --project scripts/main_reduced_mpcc_windowed_retry_aware_attempt.jl
```

The 8-hour profile is intended to check whether local retries make enough
progress to justify applying replacements and rebuilding the windowed
candidate:

```bash
MPCC_WINDOWED_RETRY_AWARE_PROFILE=8h julia --project scripts/main_reduced_mpcc_windowed_retry_aware_attempt.jl
```

The retry-aware attempt is still diagnostic-only. It does not rebuild the
trajectory, does not mark the result as simulation-viable unless the base
attempt was already viable, does not relax thresholds, does not add HSL/MA57,
and does not touch full-model or DFVB KKT code.

`apply_reduced_dcdfba_mpcc_window_retry_replacements(...)` is the first
corrective layer after retry-aware diagnostics. It consumes the existing
reduced MPCC windowed attempt and the retry-policy diagnostic, selects accepted
retry comparisons, replaces the corresponding window comparison, rebuilds the
in-memory windowed continuation, and reassesses the attempt. By default it only
applies terminal-window replacements (`terminal_only=true`), because replacing
an interior window requires re-solving downstream windows from the new boundary
state and is deferred to a later cascade-rebuild block.

Acceptance is controlled by `acceptance_policy`, with
`green_or_trajectory_ready` as the default. This allows a retry that is either
`green` or both residual-feasible and `trajectory_ready` to be applied. The
replacement result records a `replacement_table`, rebuilt attempt metadata,
`retry_replacement_applied`, and `windowed_candidate_rebuilt`. It still writes
no outputs, does not run new solver calls, does not validate a scientific
simulation, does not add HSL/MA57, and remains restricted to the reduced DFBA
MPCC target. Full-model and DFVB KKT remain deferred.

The retry-aware script keeps replacement disabled by default. To opt in for a
real 1-hour terminal-window smoke:

```bash
MPCC_WINDOWED_RETRY_AWARE_PROFILE=custom \
MPCC_WINDOWED_RETRY_AWARE_TARGET_HOURS=1.0 \
MPCC_WINDOWED_RETRY_AWARE_WINDOW_HOURS=0.5 \
MPCC_WINDOWED_RETRY_AWARE_NFE=2 \
MPCC_WINDOWED_RETRY_AWARE_MAX_WINDOWS=2 \
MPCC_WINDOWED_RETRY_AWARE_MAX_RETRY_WINDOWS=2 \
MPCC_WINDOWED_RETRY_AWARE_MAX_ITERS=200,300,500 \
MPCC_WINDOWED_RETRY_AWARE_APPLY_REPLACEMENTS=1 \
MPCC_WINDOWED_RETRY_AWARE_REPLACEMENT_POLICY=green_or_trajectory_ready \
julia --project scripts/main_reduced_mpcc_windowed_retry_aware_attempt.jl
```

`cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(...)` extends
the replacement layer for non-terminal windows. It applies the earliest
accepted retry replacement, then re-solves downstream reduced MPCC windows from
the replacement's final boundary state. Only one retry replacement is applied
per cascade rebuild, because later retry diagnostics were computed from the
pre-cascade state chain and cannot be assumed valid after an upstream state
change. The result records a `replacement_table`, a `cascade_table`, the
replacement window, downstream window counts, rebuilt attempt traffic light,
and the same scientific guardrails as the simpler replacement layer.

The retry-aware script can opt into cascade rebuilds:

```bash
MPCC_WINDOWED_RETRY_AWARE_PROFILE=custom \
MPCC_WINDOWED_RETRY_AWARE_TARGET_HOURS=1.0 \
MPCC_WINDOWED_RETRY_AWARE_WINDOW_HOURS=0.5 \
MPCC_WINDOWED_RETRY_AWARE_NFE=2 \
MPCC_WINDOWED_RETRY_AWARE_MAX_WINDOWS=2 \
MPCC_WINDOWED_RETRY_AWARE_MAX_RETRY_WINDOWS=2 \
MPCC_WINDOWED_RETRY_AWARE_MAX_ITERS=200,300,500 \
MPCC_WINDOWED_RETRY_AWARE_APPLY_REPLACEMENTS=1 \
MPCC_WINDOWED_RETRY_AWARE_CASCADE_REBUILD=1 \
MPCC_WINDOWED_RETRY_AWARE_REPLACEMENT_POLICY=green_or_trajectory_ready \
julia --project scripts/main_reduced_mpcc_windowed_retry_aware_attempt.jl
```

This cascade is still reduced-model diagnostic infrastructure. It may run
additional downstream reduced MPCC solves, but it writes no outputs, does not
add HSL/MA57, does not touch full-model or DFVB KKT code, and does not claim a
validated scientific simulation.

`smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(...)` runs the retry-aware
attempt plus cascade rebuild over selected target horizons and summarizes the
outcome in a `ReducedDCDFBAMPCCWindowedCascadeRetryHorizonSmokeResult`. Its
`cascade_horizon_table` reports the base and rebuilt traffic lights, the
replacement window, retry iteration budget, downstream windows requested and
resolved, whether the replacement was non-terminal, and whether viability was
recovered by the cascade. The smoke is meant to answer whether retry cascade
logic is ready to scale from 1 h toward longer reduced MPCC windows.

Run the default 1-hour smoke:

```bash
julia --project scripts/main_reduced_mpcc_cascade_retry_horizon_smoke.jl
```

Run a focused 1 h / 1.5 h smoke to force a non-terminal cascade when the first
accepted retry is upstream of the final window:

```bash
MPCC_CASCADE_RETRY_HORIZON_PROFILE=focused julia --project scripts/main_reduced_mpcc_cascade_retry_horizon_smoke.jl
```

Custom smoke profiles can target one horizon without writing outputs:

```bash
MPCC_CASCADE_RETRY_HORIZON_PROFILE=custom \
MPCC_CASCADE_RETRY_HORIZON_TARGET_HOURS=1.5 \
MPCC_CASCADE_RETRY_HORIZON_WINDOW_HOURS=0.5 \
MPCC_CASCADE_RETRY_HORIZON_NFE=2 \
MPCC_CASCADE_RETRY_HORIZON_MAX_CASES=1 \
MPCC_CASCADE_RETRY_HORIZON_MAX_WINDOWS=3 \
MPCC_CASCADE_RETRY_HORIZON_MAX_RETRY_WINDOWS=1 \
MPCC_CASCADE_RETRY_HORIZON_MAX_ITERS=200,300,500 \
MPCC_CASCADE_RETRY_HORIZON_CASCADE_MAX_ITER=500 \
julia --project scripts/main_reduced_mpcc_cascade_retry_horizon_smoke.jl
```

This horizon smoke may run additional reduced MPCC solves, but it does not
write result files, does not add solver dependencies, keeps HSL/MA57 optional
and absent, and keeps full-model and DFVB KKT out of scope.

`polish_reduced_dcdfba_mpcc_windowed_candidate(...)` takes a reached reduced
windowed or cascade-rebuilt MPCC candidate, concatenates its boundary,
collocation, derivative, flux, and KKT-dual arrays into monolithic start
values, and re-solves the same reached horizon as one global reduced MPCC. This
is the first bridge from windowed continuation diagnostics back to the
simultaneous method: the cascade remains only a source of initial values, while
the polish attempt is a single direct-collocation MPCC over the whole reached
horizon.

Run the default 0.5-hour global polish smoke:

```bash
julia --project scripts/main_reduced_mpcc_global_polish_smoke.jl
```

Run a focused 1-hour source/cascade plus global-polish attempt:

```bash
MPCC_GLOBAL_POLISH_PROFILE=focused julia --project scripts/main_reduced_mpcc_global_polish_smoke.jl
```

The smoke prints the source window count, global `nfe`, pre-solve gate,
solver status, residual gates, state mismatch against the reduced sequential
reference, and a `start_summary_table` showing which monolithic start blocks
were applied. It writes no outputs, does not add HSL/MA57, keeps full-model and
DFVB KKT deferred, and does not claim a solved scientific trajectory.

`sweep_reduced_dcdfba_mpcc_global_polish_horizons(...)` repeats that global
polish over a guarded horizon grid. For each requested horizon, the windowed or
cascade path is used only to generate start values; the reported case is then a
single simultaneous reduced MPCC solve over the full reached horizon. The sweep
prints green/yellow/red counts, the best green horizon, the first non-green
case after the frontier, total solver time, and a compact
`global_polish_table`. It writes no outputs and remains diagnostic-only.

Run the default 0.5-hour global-polish horizon smoke:

```bash
julia --project scripts/main_reduced_mpcc_global_polish_horizon_sweep.jl
```

Run a focused 0.5 h / 1.0 h sweep:

```bash
MPCC_GLOBAL_POLISH_SWEEP_PROFILE=focused julia --project scripts/main_reduced_mpcc_global_polish_horizon_sweep.jl
```

Run the planned grid toward 4 h:

```bash
MPCC_GLOBAL_POLISH_SWEEP_PROFILE=grid julia --project scripts/main_reduced_mpcc_global_polish_horizon_sweep.jl
```

The `72h` profile is guarded by `MPCC_GLOBAL_POLISH_SWEEP_ALLOW_LONG=1` because
it can request up to 144 reduced MPCC windows before the monolithic polish
attempt. HSL/MA57, full-model KKT, DFVB KKT, generated outputs, and scientific
trajectory claims remain out of scope for this runner.

`retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(...)` is a selective
recovery layer for horizon-sweep cases that are residual-feasible but stop with
`ITERATION_LIMIT`. It does not rerun already-green cases and does not rebuild
the whole sweep. Instead, it reuses the base case source continuation as the
global MPCC start and retries only the selected reduced simultaneous polish
with a larger Ipopt iteration budget.

Run the default 1.5-hour retry smoke:

```bash
julia --project scripts/main_reduced_mpcc_global_polish_retry.jl
```

Run the focused retry for the observed 1.5 h / 3.0 h iteration-limit cases:

```bash
MPCC_GLOBAL_POLISH_RETRY_PROFILE=focused julia --project scripts/main_reduced_mpcc_global_polish_retry.jl
```

The retry report prints the base horizon table, the retry table, recovered and
unrecovered case counts, retry solver time, and the recommended next action.
It remains reduced-only, writes no outputs, keeps HSL/MA57 optional and absent,
and does not claim a validated scientific simulation.

`diagnose_reduced_dcdfba_mpcc_solver_termination(...)` consumes a reduced MPCC
windowed attempt, retry-policy diagnostic, or retry-aware attempt and separates
solver-status blocking from residual-gate blocking. It returns a
`ReducedDCDFBAMPCCSolverTerminationDiagnosticResult` with:

- a `termination_table` classifying each source window and best retry row by
  `termination_blocker`, `likely_cause`, dominant residual, and residual ratio;
- a `residual_gate_table` with one row per residual family and threshold ratio;
- a `transition_table` comparing source windows against their best retry rows;
- metadata for `ITERATION_LIMIT` counts, residual-threshold failures, first
  blocked window, retry recovery counts, and the next diagnostic action.

Run the default smoke:

```bash
julia --project scripts/main_reduced_mpcc_solver_termination_diagnostics.jl
```

The focused profile asks whether local retries are changing the failure mode or
only repeating a residual-feasible `ITERATION_LIMIT` status gate:

```bash
MPCC_SOLVER_TERM_PROFILE=focused julia --project scripts/main_reduced_mpcc_solver_termination_diagnostics.jl
```

This layer is diagnostic-only. It writes no outputs, applies no retry
replacement, does not relax thresholds, does not add HSL/MA57, does not touch
full-model or DFVB KKT code, and does not claim a solved scientific trajectory.

`review_reduced_dcdfba_mpcc_iteration_limit_candidates(...)` adds a controlled
review gate for reduced MPCC windows that are residual-feasible but stopped at
`ITERATION_LIMIT`. It can consume a windowed attempt, retry-aware attempt, or a
solver-termination diagnostic that carries a retry-aware attempt. It returns a
`ReducedDCDFBAMPCCIterationLimitCandidateReviewResult` with:

- an `iteration_limit_candidate_review_table` classifying selected and rejected
  windows, including `diagnostic_extraction_allowed`,
  `scientific_acceptance_allowed`, residual ratios, and state-drift flags;
- an in-memory vector of selected `ReducedDCDFBAMPCCTrajectoryCandidate`
  objects for diagnostic inspection only;
- metadata for selected candidate counts, state-drift review needs, retry
  replacement status, and the next action.

Run the default smoke:

```bash
julia --project scripts/main_reduced_mpcc_iteration_limit_candidate_review.jl
```

The focused profile is useful after solver-termination diagnostics identify
residual-feasible `ITERATION_LIMIT` windows:

```bash
MPCC_ITER_LIMIT_REVIEW_PROFILE=focused julia --project scripts/main_reduced_mpcc_iteration_limit_candidate_review.jl
```

This review gate is still diagnostic-only. It does not accept `ITERATION_LIMIT`
as solved, does not rebuild the windowed candidate, does not apply retry
replacements, does not write outputs, and does not claim a scientific
simulation.

For pre-solve infeasibility and scaling diagnostics, build the same guarded
problem and inspect its start values without calling Ipopt:

```julia
problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
    model,
    reaction_map;
    sequential_initialization = simulation,
)
report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)
```

`report` stores residual values, thresholds, residual-to-threshold ratios,
ranked residual names, the dominant residual category, simple start-value
scaling summaries, and warning labels. The same function also accepts a
`ReducedDCDFBAMPCCSolveAttemptResult` to rank post-solve residual diagnostics.
This diagnostic layer does not add KKT rows, complementarity constraints,
Ipopt options, HSL/MA57, or any new solver call.

When dynamic bounds are enabled, the reduced MPCC builder now solves a local
weighted FBA LP at each collocation point using the interpolated state for that
point. These LPs produce complete flux starts satisfying `S*v = 0` and the
numeric dynamic-or-base bounds for each Radau point. The weighted LP objective
uses the local Zenteno objective weights and is not interpreted as biomass
flux. After those LP starts are assigned, a final projection step clamps any
remaining numerical bound drift and records before/after lower and upper bound
start violations in metadata. This start-value repair does not change bound
constraints, RHS constraints, stationarity, complementarity equations, Ipopt
options, or HSL/MA57 usage.

When RHS residual rows are included, the builder also updates
`state_derivative` starts to the reduced DFBA RHS evaluated at the local
collocation state and flux starts. This makes the initial `ydot - f(y,v)`
diagnostic residual small before the guarded Ipopt call. The derivative start
policy preserves the reduced-model scientific conventions: `dy[6] = 0.0` for
oxygen and carbohydrate `dy[8]` remains the empirical RHS term rather than a
direct `r_4048` flux term. These are start values only, not additional
constraints and not a solved trajectory.

When dynamic objective coefficients are present, the reduced MPCC builder now
also solves an equivalent local minimization LP at each collocation point using
the same stationarity coefficient vector `c`. The resulting primal fluxes and
HiGHS LP duals are transformed into the MPCC convention
`c + S'lambda + alpha_L + alpha_U = 0`, with nonpositive lower-bound dual starts
and nonnegative upper-bound dual starts. This makes the pre-solve KKT
stationarity and complementarity start diagnostics small for the local LP
subproblem while still avoiding any Ipopt solve, HSL/MA57 option, KKT change, or
claim of a solved simultaneous DFBA trajectory.

For guarded reduced dynamic solve-attempt problems, the builder additionally
runs a fixed-point start repair for the state variables. Each iteration sets
`state_collocation` and the next `state_boundary` values from the current
Radau integration and continuity equations, then refreshes local dynamic-FBA
flux starts, dynamic-bound projection, stationarity dual starts, and
RHS-consistent derivative starts. This is only an initialization repair: it
does not add collocation equations, does not alter KKT or complementarity
constraints, does not call Ipopt, and does not claim a solved trajectory. The
metadata records initial/final collocation, continuity, and RHS start residuals
plus convergence status.

For pre-solve scaling diagnostics, build a block-level scaling plan:

```julia
problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
    model,
    reaction_map;
    sequential_initialization = simulation,
)
plan = build_reduced_dcdfba_mpcc_scaling_plan(problem)
```

`ReducedDCDFBAMPCCScalingPlan` reports recommended scale factors for variable
blocks (`state_boundary`, `state_collocation`, `state_derivative`, `flux`,
`mass_balance_dual`, `lower_bound_dual`, `upper_bound_dual`) and constraint
families (`collocation_integration`, `continuity`, `initial_condition`, `rhs`,
`mass_balance`, bound rows, `stationarity`, and complementarity rows). The plan
is diagnostic only: it does not mutate the JuMP model, does not call Ipopt, and
does not apply Ipopt user scaling. The current reduced smoke identifies large
positive scale spreads in flux and collocation-state starts because the vectors
contain both very small and order-one-or-larger values. Those labels are treated
as review warnings, not blocking warnings, once block scale factors bring
`scaled_abs_max` near one and the collocation, continuity, RHS, KKT, and
complementarity start residuals are within their diagnostic gates. The
solve-attempt builder now drives the collocation and continuity start residuals
near machine precision before the scaling plan is inspected, but this remains a
numerical start diagnostic rather than evidence of a solved or scientifically
validated MPCC trajectory.

## Reduced Zenteno Kinetic Bound Calculations

The reduced MVP now includes the Zenteno-style kinetic-rate and dynamic-bound layer used before sequential DFBA integration. This layer computes kinetic rates and reaction-ID keyed lower-bound, upper-bound, and objective-weight updates for one fermentation state. It does not solve an ODE, run a sequential simulation, or implement DFVB.

Dynamic mapping uses reaction IDs from the reduced reaction map. `Indices_reacciones.csv` is not used for dynamic mapping. Oxygen exchange `r_1992` is skipped because it is absent from the reduced model and remains disabled. Carbohydrate exchange `r_4048` is required and present in the reduced model, but it does not receive a kinetic bound update yet because the MATLAB RHS does not apply a carbohydrate reaction flux bound.

Run the kinetic-bound smoke report from the repository root:

```bash
julia --project scripts/main_kinetic_bounds_reduced.jl
```

## Single-Step Reduced DFBA RHS

The sequential reduced DFBA layer now exposes `compute_dfba_rhs(...)` for one
right-hand-side evaluation of the 19-state fermentation vector. It computes
Zenteno dynamic bounds, uses `ZentenoDynamicBounds.objective_weights` for the
weighted FBA solve, and returns a `DFBARHSResult` with the derivative vector,
state, bounds, FBA result, selected reaction fluxes, mode, and diagnostics.

Oxygen derivative handling follows the reduced-model contract: `dy[6]` is
forced to `0.0` because oxygen exchange `r_1992` is absent. The carbohydrate
derivative follows the empirical MATLAB RHS formula and does not use the
carbohydrate pseudoreaction flux `r_4048`, even though `r_4048` is present and
required in the reduced model.

Run the single-step RHS report from the repository root:

```bash
julia --project scripts/main_sequential_reduced.jl
```

## Full Sequential DFBA RHS Smoke

The full sequential DFBA RHS smoke loads the full model and
`config/reaction_map_full.example.toml`, applies the same Zenteno dynamic-bound
layer, solves one weighted FBA problem, and returns one 19-state derivative
vector through `compute_dfba_rhs(...)`. This is a single RHS smoke evaluation
only; use `simulate_full_dfba(...)` for the guarded short full ODE smoke path.

Run it from the repository root:

```bash
julia --project scripts/main_sequential_full.jl
```

The full RHS uses the full reaction map by reaction ID. Full oxygen handling is
scope-aware: `r_1992` is present in the full model and must be closed by bounds
for the anaerobic setup, `dy[6]` remains forced to `0.0`, and `r_0001` is never
used as oxygen. If `r_1992` is present but not closed, the RHS metadata reports
`oxygen_derivative_policy = "forced_zero_present_r_1992_not_closed_by_bounds"`
instead of silently treating the setup as the expected anaerobic case.

The reduced RHS policy is unchanged: reduced `r_1992` is absent and disabled,
`dy[6] = 0.0`, and the metadata reports
`oxygen_derivative_policy = "forced_zero_absent_r_1992"`.

Carbohydrate handling is also unchanged. `r_4048` may be present and reported
as a flux, but the dynamic carbohydrate derivative `dy[8]` remains the empirical
MATLAB RHS expression and is not driven by the `r_4048` flux.

Long full sequential ODE simulation remains future work because full
LP-in-the-loop integration may be slow. DFVB artifact loading, one-step DFVB RHS
smoke evaluation, and a short DFVB ODE smoke path are available, but long
production DFVB simulation remains future work.

## Full Sequential DFBA Short Simulation

The full sequential DFBA short simulation path exposes `simulate_full_dfba(...)`
for a guarded full-model ODE smoke run. It delegates to the same sequential
LP-in-the-loop RHS as the reduced simulator, stores
`metadata["model_scope"] == "full"`, and keeps the default run deliberately
short.

Run it from the repository root:

```bash
julia --project scripts/main_simulate_full_dfba.jl
```

Default full-smoke settings:

- `tspan = (0.0, 0.25)`
- `saveat = 0.25`
- `reconstruct_fluxes = false`
- `algorithm = Tsit5()`
- `model_scope = "full"`

Environment variables:

- `DFBA_FULL_TFINAL_HOURS`: final time in hours, default `0.25`.
- `DFBA_FULL_SAVEAT_HOURS`: saved trajectory spacing, default `0.25`.
- `DFBA_FULL_RECONSTRUCT_FLUXES`: saved-state flux reconstruction, default
  `false`.

Full oxygen handling remains scope-aware during simulation. `r_1992` is present
in the full model and closed by bounds, `dy[6]` remains forced to `0.0`, and no
`r_0001` fallback is used. This metadata is reported correctly even when
`reconstruct_fluxes = false`. When full flux reconstruction is explicitly
enabled, `r_1992` may appear in the flux history and should remain approximately
zero.

Carbohydrate handling is unchanged. `r_4048` may be present and may be reported
as a flux when reconstruction is enabled, but `dy[8]` remains the empirical
MATLAB RHS expression and is not driven by the `r_4048` flux.

Full LP-in-the-loop simulation is expensive. Long full simulations are manual
profiling runs and are not default tests or default scripts. DFVB artifacts can
be loaded and validated, and static, dynamic, and one-step RHS DFVB smokes are
available. A short DFVB ODE smoke path is available separately through
`simulate_dfvb(...)`.

## Full-vs-Reduced Sequential DFBA Comparison

The full-vs-reduced sequential DFBA comparison report runs matching short
reduced and full sequential DFBA simulations and compares only the shared
19-state trajectories by default. It does not compare fluxes because the full
and reduced networks are different flux spaces and LP degeneracy can make
non-objective flux differences difficult to interpret.

Run it from the repository root:

```bash
julia --project scripts/main_compare_sequential_dfba_full_reduced.jl
```

Default settings:

- `tspan = (0.0, 0.25)`
- `saveat = 0.25`
- `reconstruct_fluxes = false`
- `algorithm = Tsit5()`

Environment variables:

- `DFBA_SEQ_COMPARE_TFINAL_HOURS`: final time in hours, default `0.25`.
- `DFBA_SEQ_COMPARE_SAVEAT_HOURS`: saved trajectory spacing, default `0.25`.
- `DFBA_SEQ_COMPARE_RECONSTRUCT_FLUXES`: saved-state flux reconstruction for
  each simulation, default `false`; fluxes are still not compared by this
  report.
- `DFBA_SEQ_COMPARE_ALLOW_LONG_FULL`: explicit opt-in for comparison horizons
  above `2.0` hours and up to `72.0` hours, default `false`.
- `DFBA_SEQ_COMPARE_ALLOW_DENSE_OUTPUT`: explicit opt-in for `saveat` below
  `0.25` hours or more than `289` estimated saved points, default `false`.
- `DFBA_SEQ_COMPARE_ADAPTIVE`: ODE adaptivity toggle. If unset, short runs use
  `true`; long opt-in runs use `false` for a fixed-step diagnostic path.
- `DFBA_SEQ_COMPARE_DT_HOURS`: fixed-step `dt` in hours. If unset and
  `DFBA_SEQ_COMPARE_ADAPTIVE=false`, `dt` defaults to `saveat`.
- `DFBA_SEQ_COMPARE_PROGRESS_SECONDS`: progress print interval in seconds.
  Long opt-in runs default to `30.0`; short runs default to `0.0`.
- `DFBA_SEQ_COMPARE_MAX_RHS_CALLS`: optional hard cap on RHS/LP evaluations per
  simulation.
- `DFBA_SEQ_COMPARE_MAX_WALLTIME_SECONDS`: optional wall-clock cap per
  simulation.

Runtime guardrails:

- Default script runs stay at `0.25` hours.
- Horizons above `2.0` hours fail unless
  `DFBA_SEQ_COMPARE_ALLOW_LONG_FULL=true`.
- The hard comparison cap is `72.0` hours.
- A 72-hour comparison should normally keep `reconstruct_fluxes=false`, use
  `saveat = 1.0` hour, and use the fixed-step diagnostic mode
  (`DFBA_SEQ_COMPARE_ADAPTIVE=false`) for first profiling.

Example PowerShell command for an explicit 72-hour diagnostic comparison:

```powershell
$env:DFBA_SEQ_COMPARE_TFINAL_HOURS = "72.0"
$env:DFBA_SEQ_COMPARE_SAVEAT_HOURS = "1.0"
$env:DFBA_SEQ_COMPARE_RECONSTRUCT_FLUXES = "false"
$env:DFBA_SEQ_COMPARE_ALLOW_LONG_FULL = "true"
$env:DFBA_SEQ_COMPARE_ADAPTIVE = "false"
$env:DFBA_SEQ_COMPARE_DT_HOURS = "1.0"
$env:DFBA_SEQ_COMPARE_PROGRESS_SECONDS = "30.0"
julia --project scripts/main_compare_sequential_dfba_full_reduced.jl
```

The report writes CSV/TOML artifacts and dependency-free SVG plots to:

```text
results/sequential_dfba_comparison/latest/sequential_dfba_comparison_summary.csv
results/sequential_dfba_comparison/latest/sequential_dfba_state_metrics.csv
results/sequential_dfba_comparison/latest/sequential_dfba_state_timeseries.csv
results/sequential_dfba_comparison/latest/sequential_dfba_comparison_metadata.toml
results/sequential_dfba_comparison/latest/sequential_dfba_core_states.svg
results/sequential_dfba_comparison/latest/sequential_dfba_state_rmse.svg
results/sequential_dfba_comparison/latest/sequential_dfba_runtime_counters.svg
```

The comparison is a diagnostic report, not a biological equivalence proof.
Differences may reflect model reduction, network size, LP degeneracy, ODE
adaptivity, and active-set changes. Long full-vs-reduced comparisons remain
manual opt-in profiling runs.

Oxygen and carbohydrate policies are preserved. Reduced `r_1992` is absent and
disabled, full `r_1992` is present and closed by bounds, and no `r_0001`
fallback is used. The carbohydrate state derivative `dy[8]` remains empirical
and is not driven by `r_4048`.

## DFVB MATLAB Artifact Loader

MATLAB-exported DFVB artifacts can be loaded and structurally validated without
constructing or solving a DFVB optimization problem. The artifact bundle lives
at:

```text
Antecedentes/Files_Cristobal/DFVB_artifacts/
```

The path contract is configured by:

```text
config/dfvb_artifact_paths.example.toml
```

Run the loader smoke report from the repository root:

```bash
julia --project scripts/main_load_dfvb_artifacts.jl
```

The loader reads:

- sparse null-space matrix `N` from `dfvb_N_sparse_triplets.csv`;
- active-alpha null-space subset from
  `dfvb_N_active_alpha_sparse_triplets.csv`;
- alpha metadata, active alpha indices, and alpha bounds;
- alpha and active-alpha trajectories;
- DFVB state trajectories;
- exchange/internal reaction partitions;
- inactive reaction tables;
- reaction ordering and MATLAB DFVB-derived reduced reaction ordering;
- `dfvb_artifact_manifest.json`.

The observed MATLAB manifest reports `4131` reactions, `2806` metabolites,
`1538` null-space columns, `490` active-alpha columns, and `2094` DFVB time
points. Indices in these files remain MATLAB 1-based; Julia preserves them as
metadata while loading sparse matrices with Julia's 1-based sparse indexing.

Scientific cautions are explicit validation warnings. The exported
`dfvb_exchange_partition.csv` marks only `r_0001` as exchange. This is not
permission to use `r_0001` as oxygen. The dFBA oxygen policy remains unchanged:
do not map oxygen to `r_0001`; `r_1992` remains the fermentation oxygen
reaction identifier used by the full/reduced dFBA policies. In the DFVB export,
`r_1992` and `r_4048` are marked internal, and that status must be reviewed
before biological interpretation.

The file `dfvb_reduced_dfba_reaction_order.csv` is a MATLAB DFVB-derived
reduced scope with `1514` rows. It is distinct from the current Julia reduced
model, which has `1488` reactions, until a separate validation block aligns
those scopes.

This loader does not itself run `dfvb_rhs!`, sequential DFVB simulation,
Julia-vs-MATLAB comparison, KKT/MPCC, direct collocation, Gurobi dependencies,
or plotting dependencies.

## Static DFVB LP Smoke

The static DFVB smoke builds and solves a JuMP/HiGHS LP in alpha variables
using the MATLAB-exported null-space basis. By default it uses the active-alpha
subset:

```text
N_active: 4131 x 490
```

Run it from the repository root:

```bash
julia --project scripts/main_static_dfvb.jl
```

The LP uses `alpha` variables with bounds from
`dfvb_alpha_bounds_active.csv`, reconstructs reaction fluxes as
`v = N_active * alpha`, enforces the full-model reaction bounds on the
reconstructed `v`, and maximizes the reconstructed biomass flux `r_2111`.
It does not add explicit `S * v == 0` constraints because `N_active` is treated
as the exported null-space basis. After the solve, the smoke validates:

- `S * v` mass-balance residual;
- lower- and upper-bound violations;
- selected reconstructed fluxes for `r_2111`, `r_1714`, `r_1709`, `r_1761`,
  `r_0001`, `r_1992`, `r_4046`, `r_4047`, and `r_4048`;
- reaction-order equality between the full model and
  `dfvb_reaction_order.csv`.

This is a mathematical reconstruction smoke only. It is not a DFVB RHS, not a
dynamic simulation, and not biological validation of the exported exchange
partition. The static DFVB metadata records `indices_reacciones_used = false`
and `r0001_used_as_oxygen = false`.

Critical partition warning: `dfvb_exchange_partition.csv` marks only `r_0001`
as exchange. `r_0001` is not oxygen. The dFBA oxygen policy remains unchanged:
oxygen remains identified as `r_1992`. In the DFVB artifacts, `r_1992` is
internal and must be interpreted carefully before any biological DFVB claims.

## Dynamic DFVB LP Smoke

The dynamic DFVB LP smoke applies state-dependent Zenteno bounds and weighted
objectives to the same alpha-space DFVB LP. It still reconstructs fluxes as
`v = N_active * alpha`, enforces full-model reaction bounds on reconstructed
flux expressions, and uses HiGHS by default.

Run it from the repository root:

```bash
julia --project scripts/main_dynamic_dfvb_lp.jl
```

This is not `dfvb_rhs!`, not `compute_dfvb_rhs(...)`, and not an ODE
simulation. It solves one growth-mode LP from
`default_zenteno_initial_state()` and one turnover-mode LP from a nitrogen-free
state. Growth mode uses a weighted objective over biomass `r_2111` and amino
acid terms. Turnover mode uses ATP maintenance `r_4046` and protein exchange
`r_4047` objective terms.

The weighted objective value is not biomass flux. The smoke reports the solved
`r_2111` flux separately from the weighted objective value, together with
`r_4046`, `r_4047`, `r_1714`, `r_1709`, `r_1761`, and `r_1992`. Oxygen remains
identified as `r_1992`, `r_0001` is not oxygen, and `r_1992` should remain
approximately zero under anaerobic closure. The carbohydrate derivative policy
is unchanged for future RHS work: `dy[8]` remains empirical and is not driven
by reconstructed `r_4048`.

The dynamic DFVB metadata records `problem_type = "dynamic_dfvb_lp"`,
`use_dynamic_bounds = true`, `objective_type = "weighted"`,
`indices_reacciones_used = false`, `r0001_used_as_oxygen = false`, and
`carbohydrate_derivative_policy = "empirical_not_r_4048"`.

## Sequential DFVB RHS Smoke

The sequential DFVB RHS smoke exposes `compute_dfvb_rhs(...)` for one
right-hand-side evaluation of the 19-state fermentation vector using the
dynamic DFVB alpha-space LP. It applies the same Zenteno dynamic bounds and
weighted objectives as `solve_dynamic_dfvb_lp(...)`, reconstructs fluxes as
`v = N_active * alpha` by default, and returns a `DFVBRHSResult` containing
the derivative vector, state, bounds, `StaticDFVBResult`, reconstructed fluxes,
active-alpha solution, alpha IDs, mode, and diagnostics.

Run it from the repository root:

```bash
julia --project scripts/main_sequential_dfvb.jl
```

This is one RHS evaluation only. It is not a DFVB ODE simulation, not
`simulate_dfvb(...)`, and not KKT/MPCC or direct collocation. The active
`N_active` basis remains the default, so the reported alpha dimension is `490`.
The weighted objective value is not biomass flux; the biomass derivative uses
the reconstructed `r_2111` flux. Oxygen policy is unchanged: `dy[6] = 0.0`,
oxygen remains identified as `r_1992`, and `r_0001` is not oxygen even though
the exported DFVB exchange partition marks `r_0001` as exchange. Carbohydrate
handling is also unchanged: reconstructed `r_4048` may be reported as a flux,
but `dy[8]` remains the empirical MATLAB RHS expression and is not driven by
`r_4048`.

MATLAB-exported alpha and state trajectories are loadable artifacts, but this
RHS smoke does not integrate or compare those trajectories. Use
`simulate_dfvb(...)` or `scripts/main_simulate_dfvb.jl` for the separate short
DFVB ODE smoke path.

Current DFVB roadmap status:

- DFVB artifact loader: complete.
- Static DFVB LP: complete.
- Dynamic DFVB LP: complete.
- Sequential DFVB RHS smoke: complete.
- Sequential DFVB short ODE simulation: complete.
- MATLAB DFVB baseline trajectory report: complete.
- Julia-vs-MATLAB DFVB trajectory comparison: complete.
- Consolidated sequential DFBA/DFVB state comparison: complete.
- Direct-collocation grid primitives: complete.
- Reduced KKT-DFBA structural scaffold: complete.
- Ipopt/MUMPS reduced toy NLP smoke: complete.
- Reduced DC-dFBA collocation NLP scaffold: complete.
- Reduced collocation RHS residual scaffold: complete.
- Reduced FBA primal feasibility rows: complete.
- Reduced FBA bound-feasibility rows with bound-dual variables: complete.
- Reduced FBA KKT stationarity rows: complete.
- Reduced FBA MPCC complementarity rows: complete.
- Guarded reduced MPCC solver-entry smoke: complete.
- Smooth growth-mode dynamic bound/objective handling for reduced MPCC: complete.
- Sequential reduced DFBA initialization starts for reduced MPCC: complete.
- Guarded reduced dynamic MPCC solve-attempt wrapper: complete.
- Reduced MPCC infeasibility/scaling diagnostics: complete.
- Dynamic local-FBA flux starts for reduced MPCC: complete.
- Dynamic-bound projection of reduced MPCC flux starts: complete.
- RHS-consistent derivative starts for reduced MPCC: complete.
- Collocation/continuity-consistent state starts for reduced MPCC: complete.
- Reduced MPCC scaling readiness classification: complete.
- Guarded reduced MPCC solve-attempt diagnostics: complete.
- Guarded reduced MPCC solve-attempt convergence profile: complete.
- Reduced MPCC candidate extraction diagnostics: complete.
- Guarded reduced MPCC trajectory-candidate extraction: complete.
- Reduced MPCC-vs-sequential state comparison diagnostics: complete.
- Short-horizon reduced MPCC solve-attempt sweep diagnostics: complete.
- Script-level reduced MPCC horizon/nfe sweep runner: complete.
- Reduced MPCC Ipopt iteration-sensitivity diagnostics: complete.
- Reduced MPCC mesh-refinement sensitivity diagnostics: complete.
- Reduced MPCC windowed-continuation diagnostics with acceptance policies: complete.
- Reduced MPCC simulation-viability semaphore diagnostics: complete.
- Reduced MPCC simulation-viability frontier diagnostics: complete.
- Reduced MPCC windowed target-horizon/72 h attempt driver: complete.
- Reduced MPCC 72 h windowed simulation runner: complete.
- Reduced MPCC windowed failure-cause diagnostics: complete.
- Reduced MPCC single-window retry diagnostics: complete.
- Reduced MPCC windowed mass-balance tolerance sensitivity: complete.
- Reduced MPCC windowed state-drift diagnostics: complete.
- Reduced MPCC multi-window retry-policy diagnostics: complete.
- Reduced MPCC retry-aware windowed attempt diagnostics: complete.
- Reduced MPCC retry replacement cascade rebuild diagnostics: complete.
- Reduced MPCC cascade retry horizon smoke diagnostics: complete.
- Reduced MPCC global polish from windowed/cascade starts: complete.
- Reduced MPCC global polish horizon sweep diagnostics: complete.
- Reduced MPCC global polish iteration-limit retry diagnostics: complete.
- Reduced MPCC solver-termination diagnostics: complete.
- Reduced MPCC iteration-limit candidate review: complete.
- Reduced MPCC windowed policy/horizon sweep diagnostics: complete.
- Solved KKT/MPCC dynamic trajectory: pending.

## Sequential DFVB Short Simulation

The sequential DFVB short simulation path exposes `simulate_dfvb(...)` for a
guarded full-model DFVB ODE smoke run. It uses `dfvb_rhs!` for LP-in-the-loop
RHS calls and reconstructs saved-state alpha trajectories by default. This is a
short smoke path only, not a long production DFVB simulator. Use
`scripts/main_compare_dfvb_matlab_baseline.jl` for the separate state-only
diagnostic comparison against exported MATLAB DFVB trajectories.

Run it from the repository root:

```bash
julia --project scripts/main_simulate_dfvb.jl
```

Default settings:

- `tspan = (0.0, 0.25)`
- `saveat = 0.25`
- `algorithm = Tsit5()`
- `use_active_alpha = true`
- `reconstruct_alphas = true`
- `reconstruct_fluxes = false`

Environment variables:

- `DFVB_TFINAL_HOURS`: final time in hours, default `0.25`.
- `DFVB_SAVEAT_HOURS`: saved trajectory spacing, default `0.25`.
- `DFVB_RECONSTRUCT_FLUXES`: saved-state flux reconstruction, default `false`.
- `DFVB_RECONSTRUCT_ALPHAS`: saved-state alpha reconstruction, default `true`.

`SimulationResult.alphas` stores alpha trajectories as `n_alpha x n_time`.
With the default active-alpha basis, `n_alpha = 490`.
`metadata["alpha_ids"]` defines the row ordering, `metadata["alpha_scope"]`
is `"active"`, and `metadata["alpha_source"]` is
`"reconstructed_saved_states"` when alpha reconstruction is enabled. The script
prints only by default; it does not write files or plots. Programmatic exports
through `export_simulation_result(...)` write `alphas.csv` when
`result.alphas !== nothing`.

Scientific policies are unchanged. The weighted objective value is not biomass
flux, `dy[1]` uses reconstructed `r_2111`, `dy[6] = 0.0`, `dy[8]` remains the
empirical MATLAB RHS expression rather than `r_4048`, oxygen remains `r_1992`,
and `r_0001` is not oxygen even though the exported DFVB exchange partition
marks `r_0001` as exchange. This path does not implement KKT/MPCC, direct
collocation, or full-vs-reduced-vs-DFVB comparison.

## MATLAB DFVB Baseline Trajectory Report

The MATLAB DFVB baseline trajectory report summarizes exported MATLAB DFVB
state and alpha trajectories without running a Julia simulation or solving an
LP. It is a reporting block for the artifact baseline, not a Julia-vs-MATLAB
DFVB comparison and not a biological equivalence claim.

Run it from the repository root:

```bash
julia --project scripts/main_dfvb_baseline_report.jl
```

The report writes CSV/TOML files and dependency-free SVG plots to:

```text
results/dfvb_baseline/latest
```

Output files:

```text
dfvb_baseline_state_summary.csv
dfvb_baseline_state_timeseries.csv
dfvb_baseline_alpha_summary.csv
dfvb_baseline_active_alpha_mapping.csv
dfvb_baseline_metadata.toml
dfvb_baseline_core_states.svg
dfvb_baseline_state_ranges.svg
dfvb_baseline_alpha_ranges.svg
```

`dfvb_baseline_state_timeseries.csv` preserves the original MATLAB time grid
and the 19 exported state columns. Alpha output is compact by default:
`dfvb_baseline_alpha_summary.csv` summarizes active and full alpha ranges, but
neither the full alpha timeseries nor the active alpha timeseries is exported
again. The active alpha trajectory file uses local active IDs such as
`alpha_1`, while Julia-generated active alpha histories use source alpha IDs
such as `alpha_3`. Use `dfvb_baseline_active_alpha_mapping.csv` to map
`active_alpha_index` and `active_alpha_id` to `source_alpha_index` and
`source_alpha_id`; do not compare local active alpha names directly.

The report metadata records `report_type =
"matlab_dfvb_baseline_trajectory_report"`, `source = "matlab_dfvb_export"`,
`full_alpha_timeseries_exported = false`,
`active_alpha_timeseries_exported = false`, `julia_simulation_run = false`,
and `lp_solve_run = false`. Oxygen and exchange cautions are preserved:
`r_0001` is not oxygen, oxygen remains `r_1992`, and the exported DFVB exchange
partition should not be interpreted as biological validation.

## Julia-vs-MATLAB DFVB Trajectory Comparison

The Julia-vs-MATLAB DFVB trajectory comparison runs the short Julia
`simulate_dfvb(...)` path and compares its saved state trajectory against the
exported MATLAB DFVB baseline state trajectory. The comparison is state-only by
default: alpha trajectories and flux trajectories are excluded from the report.
It is a diagnostic comparison for implementation work, not a biological
equivalence claim.

Run it from the repository root:

```bash
julia --project scripts/main_compare_dfvb_matlab_baseline.jl
```

The report writes CSV/TOML files and dependency-free SVG plots to:

```text
results/dfvb_matlab_comparison/latest
```

Output files:

```text
dfvb_matlab_comparison_summary.csv
dfvb_matlab_state_metrics.csv
dfvb_matlab_aligned_timeseries.csv
dfvb_matlab_comparison_metadata.toml
dfvb_matlab_core_states.svg
dfvb_matlab_state_rmse.svg
dfvb_matlab_runtime_counters.svg
```

The default alignment policy is
`alignment_policy = "linear_interpolation_to_julia_times"`. MATLAB baseline
states are linearly interpolated to Julia saved times, and the comparison does
not extrapolate outside the MATLAB baseline time range. Unsupported alignment
policies fail explicitly.

Environment variables:

- `DFVB_MATLAB_COMPARE_TFINAL_HOURS`: final Julia simulation time in hours,
  default `0.25`.
- `DFVB_MATLAB_COMPARE_SAVEAT_HOURS`: Julia saved trajectory spacing, default
  `0.25`.
- `DFVB_MATLAB_COMPARE_ALIGNMENT`: alignment policy, default
  `linear_interpolation_to_julia_times`.

Scientific policies are unchanged. Alpha comparison is excluded by default,
flux comparison is excluded by default, `r_0001` is not oxygen, oxygen remains
`r_1992`, and the empirical carbohydrate state derivative is not interpreted as
the `r_4048` flux. Long Julia DFVB simulations remain out of scope for this
report.

## Consolidated Sequential DFBA/DFVB Comparison

The consolidated sequential comparison report runs one short shared time grid
for four sources:

- reduced DFBA;
- full DFBA;
- Julia DFVB;
- MATLAB DFVB baseline trajectory.

The report is state-only by default. It compares the shared 19 fermentation
state variables, excludes flux comparison, and excludes alpha comparison. The
MATLAB DFVB baseline states are linearly interpolated to the common Julia
reference grid with `alignment_policy =
"linear_interpolation_to_reference_times"`; extrapolation is not performed.

Run it from the repository root:

```bash
julia --project scripts/main_compare_sequential_model_comparison.jl
```

The report writes CSV/TOML files and dependency-free SVG plots to:

```text
results/sequential_model_comparison/latest
```

Output files:

```text
sequential_model_comparison_summary.csv
sequential_model_state_metrics.csv
sequential_model_aligned_timeseries.csv
sequential_model_comparison_metadata.toml
sequential_model_core_states.svg
sequential_model_state_rmse.svg
sequential_model_runtime_counters.svg
```

Environment variables:

- `SEQ_MODEL_COMPARE_TFINAL_HOURS`: final shared simulation time in hours,
  default `0.25`.
- `SEQ_MODEL_COMPARE_SAVEAT_HOURS`: saved trajectory spacing, default `0.25`.
- `SEQ_MODEL_COMPARE_ALIGNMENT`: alignment policy, default
  `linear_interpolation_to_reference_times`.

This is a diagnostic multimodel state trajectory comparison, not proof of
biological equivalence. The sources differ in network size, reduction,
null-space basis, LP degeneracy, solver behavior, and artifact provenance.
Fluxes and alphas remain excluded by default because cross-model flux and alpha
semantics are not safely aligned. `r_0001` is not oxygen; oxygen remains
`r_1992`. The reduced model lacks `r_1992` and the full model has `r_1992`
closed by bounds, while the DFVB policy still records `r_1992` as the oxygen
reaction ID. The carbohydrate derivative `dy[8]` remains empirical and is not
driven by `r_4048`. The default horizon is intentionally short.

## Sequential Reduced DFBA Simulation

The sequential reduced DFBA simulator uses `OrdinaryDiffEq.jl` for ODE
integration. The preferred public API is `simulate_reduced_dfba(...)`;
`simulate_ode(...)` is kept as an alias for compatibility. This is still a
sequential LP-in-the-loop simulator: every RHS call solves a JuMP/HiGHS LP
through `dfba_rhs!` and `compute_dfba_rhs(...)`.

The default algorithm in the public `simulate_reduced_dfba(...)` API remains
`Rodas5P` from `OrdinaryDiffEq.jl` with finite-difference Jacobians, because
the RHS solves LPs and is not compatible with ForwardDiff dual numbers. The
manual simulation and export scripts select `Tsit5` by default at script level
for current reduced-dFBA workflow runs; `Tsit5` is an explicit non-stiff
Runge-Kutta method. This script default is configurable with
`DFBA_ALGORITHM=Rodas5P` or `DFBA_ALGORITHM=Tsit5`. The result is a
`SimulationResult` with states stored as `n_states x n_time`, selected fluxes
stored as `n_fluxes x n_time`, and metadata containing mode history, LP
diagnostics, solver retcode, policy flags, and selected reaction IDs.
Reduced simulations store `metadata["model_scope"] == "reduced"`; full short
simulations store `metadata["model_scope"] == "full"`.

By default, `simulate_reduced_dfba(...; reconstruct_fluxes = true)`
reconstructs selected fluxes and LP diagnostics at saved time points after the
ODE solve. This requires additional LP solves. For faster smoke or profiling
runs, `simulate_reduced_dfba(...; reconstruct_fluxes = false)` skips this
post-solve reconstruction, returns `fluxes = nothing`, keeps
`metadata["flux_rxn_ids"] == String[]`, and leaves saved-state diagnostic
history vectors empty instead of inventing flux values.

Runtime diagnostics are stored in `SimulationResult.metadata`, including
`simulation_elapsed_seconds`, `ode_solve_elapsed_seconds`,
`rhs_elapsed_seconds`, `history_reconstruction_elapsed_seconds`,
`rhs_call_count`, `rhs_lp_solve_count`, `flux_reconstruction_solve_count`,
`total_lp_solve_count`, `reconstruct_fluxes`, `lp_reuse`,
`lp_primal_start`, `lp_basis_warm_start`, `lp_simplex_strategy`,
`allow_experimental_lp_reuse`, `experimental_lp_reuse`,
`trajectory_equivalence_checked`, `trajectory_equivalence_passed`,
`scientific_output_equivalent`, `lp_reuse_validity_note`,
`lp_reuse_build_elapsed_seconds`, `lp_reuse_update_elapsed_seconds`,
`lp_reuse_solve_elapsed_seconds`, `lp_reuse_warm_start_applied_count`,
`lp_reuse_basis_warm_start_applied_count`, `lp_reuse_basis_capture_count`,
and `lp_reuse_simplex_iterations`.
These counters document the current LP-in-the-loop cost profile and feed the
plotting-free benchmark script. The default path still rebuilds one LP per RHS
evaluation and is the scientific simulation reference path. For reduced DFBA
only, a persistent JuMP/HiGHS LP remains available for isolated RHS diagnostics
and controlled ODE experiments, but `simulate_reduced_dfba(...; lp_reuse = true)`
is blocked unless `allow_experimental_lp_reuse = true` is supplied.
Long-horizon adaptive trajectories have shown material differences from the
cold rebuild path because degenerate LP optima can be selected differently.
Previous primal values can be supplied with `lp_primal_start = true`, and
HiGHS simplex basis reuse is available with `lp_basis_warm_start = true`;
these modes are benchmark diagnostics, not validated scientific simulation
defaults. When basis warm start is enabled and no strategy is specified, the
simulator uses `lp_simplex_strategy = "primal"`.

This sequential reduced DFBA workflow does not implement DFVB RHS, KKT/MPCC, or direct collocation. Oxygen
remains forced to zero because `r_1992` is absent from the reduced model, and no
oxygen fallback to `r_0001` is used. The carbohydrate derivative remains the
empirical MATLAB RHS expression and does not use the `r_4048` flux, even though
`r_4048` is present and included in reconstructed flux histories.

Negative-state and sugar-depletion handling are MVP policies. Initial states are
validated as nonnegative by default, saved states are checked after integration,
and sugar depletion is handled by initial-time termination or saved-time
truncation. A more robust nonnegative-domain/event policy is deferred.

Run the reduced DFBA simulation smoke report from the repository root:

```bash
julia --project scripts/main_simulate_reduced_dfba.jl
```

The simulation smoke script uses a short 2 h horizon by default so it finishes
quickly. It uses `Tsit5` by default and passes the selected algorithm and
tolerances explicitly to `simulate_reduced_dfba(...)`. Set
`DFBA_TFINAL_HOURS`, `DFBA_SAVEAT_HOURS`, `DFBA_RECONSTRUCT_FLUXES=false`,
`DFBA_LP_REUSE=true`, `DFBA_LP_PRIMAL_START=true`,
`DFBA_LP_BASIS_WARM_START=true`, `DFBA_LP_REUSE_HIGHS_SOLVER=simplex`,
`DFBA_LP_SIMPLEX_STRATEGY=primal`,
`DFBA_ALLOW_EXPERIMENTAL_LP_REUSE=true`, `DFBA_ALGORITHM=Rodas5P`, or
`DFBA_SOLVER_BACKEND=Gurobi` for manual longer, lighter, experimental
reduced-LP-reuse, alternative-algorithm, or optional Gurobi-backed runs.
`DFBA_LP_REUSE` is HiGHS-only at script level and requires
`DFBA_ALLOW_EXPERIMENTAL_LP_REUSE=true` for ODE simulation. `DFBA_ODE_ABSTOL`,
`DFBA_ODE_RELTOL`, and `DFBA_LP_ATOL` default to `1.0e-8`.

## Trajectory Summary Metrics

Plotting-free summary metrics are available for `SimulationResult` objects.
They support CSV reports and the plotting-free benchmark script.

- `summarize_simulation(result)` returns a compact `Dict{String, Any}` with
  final states, sugar consumed, ethanol produced, mode counts, solver
  diagnostics, termination metadata, and oxygen/carbohydrate policy strings.
- `mode_counts(result)` counts entries in `result.metadata["mode_history"]`.
- `total_sugar(result)` returns glucose plus fructose at a saved time point.
- `time_to_sugar_depletion(result)` scans saved states and returns the first
  saved time where total sugar is below the depletion tolerance, or `nothing`.
- `diagnostic_summary(result)` returns compact LP diagnostic maxima from
  metadata.

Basic SVG trajectory plotting utilities are available for interpretation; they
do not add plotting package dependencies.

## Simulation Result Export

Simulation results can be exported as plotting-free CSV/TOML report artifacts
with:

```julia
export_simulation_result(result, output_dir; overwrite = false)
```

The export writes:

- `summary.csv`: one-row scalar trajectory summary, including `model_scope`.
- `states.csv`: saved state trajectories with one row per time point.
- `fluxes.csv`: selected flux history when `result.fluxes !== nothing`.
- `alphas.csv`: alpha history when `result.alphas !== nothing`.
- `diagnostics.csv`: mode, RHS status, and LP diagnostic history.
- `metadata.toml`: normalized simulation metadata.

`summary.csv` includes `n_alphas` and `alpha_scope`; `metadata.toml` preserves
alpha metadata such as `alpha_scope`, `alpha_ids`, `alpha_source`, and
`n_alphas` when present. `summary.csv` and `metadata.toml` include the runtime diagnostics listed above.
The `elapsed_seconds` summary column is the externally supplied script/export
wall-clock time, while `simulation_elapsed_seconds` is measured inside
the simulation wrapper. When `overwrite = true`, known stale export files
from prior runs are removed before writing the new report; unrelated files in
the output directory are left untouched.

Generated result folders are expected under `results/`, which is ignored by
Git. The export does not generate plots, keeps HiGHS as the default solver, and
uses `DFBA_SOLVER_BACKEND` only for explicit optional backend selection. Oxygen
and carbohydrate policies are preserved:
oxygen remains forced to zero because `r_1992` is absent, and the carbohydrate
state derivative remains the empirical MATLAB RHS expression rather than using
the `r_4048` flux.

Run the reduced DFBA export report from the repository root:

```bash
julia --project scripts/main_export_reduced_dfba.jl
```

The export script uses the same script-level controls as the smoke simulation:
`DFBA_TFINAL_HOURS`, `DFBA_SAVEAT_HOURS`, `DFBA_RECONSTRUCT_FLUXES`,
`DFBA_LP_REUSE`, `DFBA_LP_PRIMAL_START`, `DFBA_LP_BASIS_WARM_START`,
`DFBA_LP_REUSE_HIGHS_SOLVER`, `DFBA_LP_SIMPLEX_STRATEGY`,
`DFBA_ALLOW_EXPERIMENTAL_LP_REUSE`, `DFBA_ALGORITHM`, `DFBA_ODE_ABSTOL`,
`DFBA_ODE_RELTOL`, `DFBA_LP_ATOL`, and `DFBA_SOLVER_BACKEND`.
It also supports `DFBA_OUTPUT_DIR` and
`DFBA_EXPORT_OVERWRITE`; the defaults are `results/reduced_dfba_latest` and
`true`. For example, a 72 h HiGHS export suitable for SVG plots is:

```powershell
$env:DFBA_SOLVER_BACKEND = "HiGHS"
$env:DFBA_ALGORITHM = "Tsit5"
$env:DFBA_TFINAL_HOURS = "72.0"
$env:DFBA_SAVEAT_HOURS = "1.0"
$env:DFBA_RECONSTRUCT_FLUXES = "true"
$env:DFBA_OUTPUT_DIR = "results/reduced_dfba_highs_72h"
julia --project scripts/main_export_reduced_dfba.jl
```

Then generate SVG plots from that export:

```powershell
$env:DFBA_PLOT_EXPORT_DIR = "results/reduced_dfba_highs_72h"
julia --project scripts/main_plot_reduced_dfba_export.jl
```

## Basic SVG Trajectory Plots

Basic trajectory plots can be generated as standalone SVG files from a
`SimulationResult` or from exported CSV reports. These utilities use only the
existing CSV/DataFrames stack and Base SVG writing; no plotting package
dependency is added.

Programmatic use:

```julia
paths = write_default_trajectory_plots(result, "results/reduced_dfba_latest/plots"; overwrite = true)
```

From an exported report directory containing `states.csv` and optionally
`diagnostics.csv`:

```julia
paths = write_exported_trajectory_plots("results/reduced_dfba_latest"; overwrite = true)
```

The default plot set writes:

- `biomass_ethanol.svg`
- `sugars.svg`
- `nitrogen_reserves.svg`
- `aroma_products.svg`
- `mode_timeline.svg` when diagnostics include mode history

Run the manual plotting script from the repository root:

```bash
julia --project scripts/main_plot_reduced_dfba_export.jl
```

Environment variables:

- `DFBA_PLOT_EXPORT_DIR`: export directory, default `results/reduced_dfba_latest`.
- `DFBA_PLOT_OUTPUT_DIR`: output directory, default `<export_dir>/plots`.
- `DFBA_PLOT_OVERWRITE`: overwrite existing SVG files, default `true`.

Generated plot folders are expected under `results/` or `plots/`, both ignored
by Git.

## Plotting-Free Benchmark

The reduced DFBA benchmark script runs short sequential reduced DFBA scenarios
and writes CSV/TOML benchmark artifacts without plotting. By default it uses:

- `tspan = (0.0, 2.0)`
- `saveat = 1.0`
- `reconstruct_fluxes = true` and `reconstruct_fluxes = false`
- `HiGHS` as the default optimizer backend

Run it from the repository root:

```bash
julia --project scripts/main_benchmark.jl
```

The default output directory is:

```text
results/benchmarks/reduced_dfba_latest
```

The benchmark writes:

- `benchmark_summary.csv`: one row per scenario with trajectory summaries,
  runtime diagnostics, algorithm/tolerance settings, RHS call counts, and LP
  solve counts.
- `benchmark_metadata.toml`: benchmark settings, scenario IDs, selected solver
  backends, selected algorithm, tolerances, actual solver labels, and notes.

Environment variable overrides use Base parsing only:

- `DFBA_BENCH_TFINAL_HOURS`: final simulation time in hours, default `2.0`.
- `DFBA_BENCH_SAVEAT_HOURS`: saved trajectory spacing in hours, default `1.0`.
- `DFBA_BENCH_OUTPUT_DIR`: output directory, default
  `results/benchmarks/reduced_dfba_latest`.
- `DFBA_BENCH_RECONSTRUCT`: scenario selector, one of `both`, `true`, or
  `false`; default `both`.
- `DFBA_BENCH_SOLVER_BACKENDS`: comma-separated backend selector, for example
  `HiGHS` or `HiGHS,Gurobi`; default `HiGHS`.
- `DFBA_BENCH_ALGORITHM`: ODE algorithm selector for all benchmark scenarios,
  one of `Rodas5P`, `default`, or `Tsit5`; default `Rodas5P`.
- `DFBA_BENCH_ODE_ABSTOL`: ODE absolute tolerance, default `1.0e-8`.
- `DFBA_BENCH_ODE_RELTOL`: ODE relative tolerance, default `1.0e-8`.
- `DFBA_BENCH_LP_ATOL`: LP diagnostic tolerance passed to the RHS layer,
  default `1.0e-8`.
- `DFBA_BENCH_ALLOW_GUROBI_RODAS5P`: set to `1` only for deliberate local
  experiments with the guarded `Gurobi` + `Rodas5P` benchmark path. Local
  Gurobi comparisons should normally use `DFBA_BENCH_ALGORITHM=Tsit5`.
- `DFBA_GUROBI_PACKAGE_PATH`: optional local `Gurobi.jl` checkout used only
  when a Gurobi backend is requested and `Gurobi` is not already importable.

No plots are generated. Gurobi execution is opt-in, and HiGHS remains the
default solver. Runtime comparisons should use rows with the same
`algorithm_label`, `ode_abstol`, `ode_reltol`, `lp_atol`, and
`reconstruct_fluxes`.

## Reduced DFBA LP Reuse and Primal-Start Benchmark

The reduced DFBA warm-start benchmark isolates the RHS LP layer from the ODE
integrator. It compares three HiGHS scenarios on a deterministic reduced
fermentation state grid:

- `cold_rebuild`: current reference path, rebuilding one JuMP/HiGHS LP per RHS
  evaluation;
- `persistent_no_start`: one persistent JuMP/HiGHS LP with dynamic
  bounds/objective updates;
- `persistent_primal_start`: the same persistent LP plus previous flux values
  passed as `VariablePrimalStart`.

Run it from the repository root:

```bash
julia --project scripts/main_benchmark_reduced_dfba_warm_start.jl
```

The default output directory is:

```text
results/benchmarks/reduced_dfba_warm_start_latest
```

The benchmark writes:

```text
reduced_dfba_warm_start_benchmark_summary.csv
reduced_dfba_warm_start_benchmark_solves.csv
reduced_dfba_warm_start_benchmark_metadata.toml
```

Environment variables:

- `DFBA_WARM_BENCH_N_EVALUATIONS`: number of RHS LP evaluations, default `8`.
- `DFBA_WARM_BENCH_LP_ATOL`: LP diagnostic tolerance, default `1.0e-8`.
- `DFBA_WARM_BENCH_HIGHS_SOLVER`: HiGHS solver option, default `simplex`.
- `DFBA_WARM_BENCH_SIMPLEX_STRATEGY`: HiGHS simplex strategy for non-basis
  persistent scenarios, default `default`. The basis warm-start scenario uses
  `primal` when this is left as `default`.
- `DFBA_WARM_BENCH_OUTPUT_DIR`: output directory, default
  `results/benchmarks/reduced_dfba_warm_start_latest`.

This benchmark is diagnostic and reports isolated RHS LP behavior only. It does
not validate ODE trajectory equivalence and does not enable LP reuse, primal
starts, or basis starts by default. The benchmark metadata includes
`rhs_equivalence_checked`, `trajectory_equivalence_checked`,
`trajectory_equivalence_passed`, `experimental_lp_reuse`, and
`scientific_output_equivalent` so downstream reports do not overclaim
scientific equivalence from RHS timing speedups. Because LP optima can be
degenerate, compare objective, RHS, bound violations, simplex iterations, and
elapsed times together rather than assuming previous primal values or previous
bases always improve solve time. Scientific simulations should use the default
cold rebuild path unless explicitly opting into
`allow_experimental_lp_reuse = true` for controlled diagnostics. Persistent LP
reuse remains opt-in for ODE simulation and is benchmarked for full and reduced
DFBA in the full-vs-reduced persistence benchmark. It has not been extended to
DFVB. HiGHS remains the only required solver and no Gurobi dependency is added.

## Full-vs-Reduced DFBA Persistence Benchmark

The full-vs-reduced persistence benchmark compares Julia DFBA simulations using
the full stoichiometric matrix as the model baseline. MATLAB/DFVB artifacts are
treated as generators of the reduced representation, specifically the reduction
matrix and alpha information, not as trajectory baselines. The benchmark runs
three ODE scenarios:

- `full_dfba_cold`: full `S` DFBA with one rebuilt JuMP/HiGHS LP per RHS
  evaluation; this is the performance reference scenario.
- `full_dfba_persistent`: full `S` DFBA with guarded persistent LP reuse and
  optional primal/basis initialization.
- `reduced_dfba_persistent`: reduced `S` DFBA with the same guarded persistent
  LP reuse and initialization settings.

Run the short smoke profile from the repository root:

```bash
julia --project scripts/main_benchmark_dfba_persistence.jl
```

Run the explicit 72 h profile when validating long-horizon performance:

```bash
julia --project scripts/main_benchmark_dfba_persistence_72h.jl
```

Run the matching 72 h QP-regularized pFBA-like profile:

```bash
julia --project scripts/main_benchmark_dfba_qpfba_persistence_72h.jl
```

Run the matching 72 h L1-regularized pFBA-like LP profile:

```bash
julia --project scripts/main_benchmark_dfba_l1pfba_persistence_72h.jl
```

The default short-profile output directory is:

```text
results/benchmarks/dfba_persistence_latest
```

The default 72 h output directory is:

```text
results/benchmarks/dfba_persistence_72h_latest
```

The default 72 h QP-regularized output directory is:

```text
results/benchmarks/dfba_qpfba_persistence_72h_latest
```

The default 72 h L1-regularized output directory is:

```text
results/benchmarks/dfba_l1pfba_persistence_72h_latest
```

The benchmark writes:

```text
dfba_persistence_benchmark_summary.csv
dfba_persistence_benchmark_aligned_timeseries.csv
dfba_persistence_benchmark_metadata.toml
dfba_persistence_core_states.svg
dfba_persistence_state_differences.svg
dfba_persistence_runtime_counters.svg
dfba_persistence_final_states.svg
```

Environment variables:

- `DFBA_PERSISTENCE_BENCH_PROFILE`: benchmark profile, default `short`.
  Use `72h` for the long-horizon profile.
- `DFBA_PERSISTENCE_BENCH_TFINAL_HOURS`: final simulation time, default `0.25`
  for `short` and `72.0` for `72h`.
- `DFBA_PERSISTENCE_BENCH_SAVEAT_HOURS`: saved-time interval, default `0.25`
  for `short` and `1.0` for `72h`.
- `DFBA_PERSISTENCE_BENCH_ALGORITHM`: ODE algorithm, default `Tsit5`.
- `DFBA_PERSISTENCE_BENCH_ADAPTIVE`: adaptive ODE stepping, default `true`
  for `short` and `false` for `72h`.
- `DFBA_PERSISTENCE_BENCH_DT_HOURS`: fixed ODE step size when
  `DFBA_PERSISTENCE_BENCH_ADAPTIVE=false`; the 72 h wrapper defaults to `1.0`.
- `DFBA_PERSISTENCE_BENCH_FBA_VARIANT`: FBA formulation, default `fba`.
  Use `qpfba` for the QP-regularized variant
  `min -c'v + quadratic_penalty * sum(v.^2)`, or `l1pfba` for the
  LP L1-regularized variant `min -c'v + l1_penalty * sum(abs(v))`.
- `DFBA_PERSISTENCE_BENCH_QUADRATIC_PENALTY`: positive QP penalty for
  `qpfba`, default `1.0e-5` in the QP-regularized 72 h wrapper.
- `DFBA_PERSISTENCE_BENCH_L1_PENALTY`: positive L1 penalty for `l1pfba`,
  default `1.0e-6` in the L1-regularized 72 h wrapper.
- `DFBA_PERSISTENCE_BENCH_RECONSTRUCT_FLUXES`: reconstruct saved fluxes,
  default `false`.
- `DFBA_PERSISTENCE_BENCH_PRIMAL_START`: use previous fluxes as primal starts
  in persistent scenarios, default `true`.
- `DFBA_PERSISTENCE_BENCH_BASIS_WARM_START`: use HiGHS basis starts in
  persistent scenarios, default `false`.
- `DFBA_PERSISTENCE_BENCH_HIGHS_SOLVER`: HiGHS solver option, default
  `simplex`.
- `DFBA_PERSISTENCE_BENCH_SIMPLEX_STRATEGY`: HiGHS simplex strategy, default
  `default`.
- `DFBA_PERSISTENCE_BENCH_LP_ATOL`, `DFBA_PERSISTENCE_BENCH_ODE_ABSTOL`, and
  `DFBA_PERSISTENCE_BENCH_ODE_RELTOL`: numerical tolerances, default `1.0e-8`.
- `DFBA_PERSISTENCE_BENCH_TRAJECTORY_MATCH_ATOL`: short-horizon state matching
  threshold for reporting, default `1.0e-5`.
- `DFBA_PERSISTENCE_BENCH_FULL_PERSISTENT_MAX_ABS_STATE_TOL`,
  `DFBA_PERSISTENCE_BENCH_FULL_PERSISTENT_STATE_RMSE_TOL`, and
  `DFBA_PERSISTENCE_BENCH_FULL_PERSISTENT_FINAL_STATE_TOL`: required acceptance
  tolerances for `full_dfba_persistent` versus `full_dfba_cold`.
- `DFBA_PERSISTENCE_BENCH_REDUCED_MAX_ABS_STATE_TOL`,
  `DFBA_PERSISTENCE_BENCH_REDUCED_STATE_RMSE_TOL`, and
  `DFBA_PERSISTENCE_BENCH_REDUCED_FINAL_STATE_TOL`: reporting tolerances for
  `reduced_dfba_persistent` versus `full_dfba_cold`; this comparison is a
  reduced-model similarity diagnostic, not an equivalence requirement.
- `DFBA_PERSISTENCE_BENCH_PROGRESS_INTERVAL_SECONDS`: simulation progress
  interval, default `0.0` for `short` and `60.0` for `72h`.
- `DFBA_PERSISTENCE_BENCH_MAX_RHS_CALLS` and
  `DFBA_PERSISTENCE_BENCH_MAX_WALLTIME_SECONDS`: optional runtime guards for
  long manual runs.
- `DFBA_PERSISTENCE_BENCH_OUTPUT_DIR`: output directory, default
  `results/benchmarks/dfba_persistence_latest` for `short` and
  `results/benchmarks/dfba_persistence_72h_latest` for `72h`.

The summary table includes `comparison_role`, state-difference metrics,
scenario-specific tolerances, `acceptance_required`, and
`acceptance_passed_vs_full_cold`. The full persistent scenario is the
equivalence candidate for the Julia full-`S` baseline. The reduced persistent
scenario is a similarity/performance candidate against the full-`S` baseline.
The SVG files plot dynamic trajectories for core states, state-difference
metrics, runtime counters, and final-state comparisons.

This benchmark is intended to prepare sequential full/reduced references for
future direct-collocation KKT/MPCC work. It does not build an MPCC, does not
require Ipopt/HSL, and does not add Gurobi. Persistent ODE scenarios still use
`allow_experimental_lp_reuse = true` internally and should be interpreted as
candidate baselines until representative trajectory equivalence has been
accepted.

The `qpfba` profile is an experimental QP-regularized tie-breaker for
degenerate FBA optima. It changes the optimization objective relative to the LP
FBA baseline, so its outputs should be compared as a separate formulation, not
as proof that LP persistence is trajectory-equivalent. HiGHS is still the only
required solver; the benchmark forces HiGHS `solver=ipm`,
`run_crossover=off`, and `ipm_optimality_tolerance=1.0e-6`, and basis
warm-starts are not enabled for the QP profile.
For this diagnostic profile only, QP RHS solves with HiGHS `OTHER_ERROR` are
allowed to continue when primal and dual are feasible and mass/bound violations
are at most `1.0e-4`; the original solver status remains recorded in RHS
status metadata.
If a persistent QP solve violates that policy, the RHS is recomputed with a
cold QP solve and counted in `qpfba_persistent_fallback_count`.

The `l1pfba` profile is an experimental LP pFBA-like tie-breaker. It keeps the
problem linear by adding nonnegative absolute-flux variables and minimizing
`-c'v + l1_penalty * sum(abs(v))`. Because this still changes the optimization
objective relative to the LP FBA baseline, its trajectories should be compared
as a separate formulation. It can use the same persistent LP reuse and primal
start settings as the regular LP path, and it does not add solver dependencies.

### Optional Gurobi-vs-HiGHS Benchmark

A plotting-free benchmark can compare the default HiGHS backend against an
optional local Gurobi backend. See
`docs/GUROBI_VS_HIGHS_BENCHMARK.md`.

Gurobi remains opt-in and is not included in `Project.toml`.

## Setup

Install Julia, then instantiate the environment from the repository root:

```bash
julia --project -e 'using Pkg; Pkg.instantiate()'
```

## Tests

Run the smoke tests:

```bash
julia --project -e 'using Pkg; Pkg.test()'
```

Default tests do not require Gurobi and must pass with HiGHS only. Gurobi is
not a dependency, is not required for CI, and is tested only when explicitly
requested with a locally configured `Gurobi.jl` checkout and a valid Gurobi
license. The optional helper smoke resolves the backend and solves a tiny
bounded JuMP LP; it does not run a full dFBA simulation or benchmark.

```powershell
$env:FERMENTATIONDFBA_TEST_GUROBI = "1"
$env:DFBA_GUROBI_PACKAGE_PATH = "<path-to-Gurobi.jl-checkout>"
julia --project -e 'using Pkg; Pkg.test()'
```

Benchmark script execution from the test suite is also opt-in. The default test
suite checks the benchmark contract structurally without running the benchmark.
Set the benchmark flag only for a local execution smoke with HiGHS and a
temporary output directory.

```powershell
$env:FERMENTATIONDFBA_TEST_BENCHMARK = "1"
julia --project -e 'using Pkg; Pkg.test()'
```

Do not commit `Project.toml` or `Manifest.toml` changes from local Gurobi
experiments. Full Gurobi-backed dFBA simulations and backend benchmarks may be
slower than the tiny helper smoke test and should be treated as manual profiling
runs.

Run the synthetic sanity check:

```bash
julia --project scripts/main_sanity_check.jl
```

Run the reduced export loader:

```bash
julia --project scripts/main_load_reduced_model.jl
```

Run the static reduced FBA smoke solve:

```bash
julia --project scripts/main_static_fba_reduced.jl
```

Run the full model export loader:

```bash
julia --project scripts/main_load_full_model.jl
```

Run the static full FBA smoke solve:

```bash
julia --project scripts/main_static_fba_full.jl
```

Run the full-vs-reduced static FBA comparison report:

```bash
julia --project scripts/main_compare_static_fba_full_reduced.jl
```

Run the full-vs-reduced short sequential DFBA comparison report:

```bash
julia --project scripts/main_compare_sequential_dfba_full_reduced.jl
```

Run the DFVB MATLAB artifact loader smoke:

```bash
julia --project scripts/main_load_dfvb_artifacts.jl
```

Run the MATLAB DFVB baseline trajectory report:

```bash
julia --project scripts/main_dfvb_baseline_report.jl
```

Run the Julia-vs-MATLAB DFVB trajectory comparison report:

```bash
julia --project scripts/main_compare_dfvb_matlab_baseline.jl
```

Run the consolidated sequential DFBA/DFVB comparison report:

```bash
julia --project scripts/main_compare_sequential_model_comparison.jl
```

Run the static DFVB LP reconstruction smoke:

```bash
julia --project scripts/main_static_dfvb.jl
```

Run the dynamic-bound weighted DFVB LP smoke:

```bash
julia --project scripts/main_dynamic_dfvb_lp.jl
```

Run the one-step sequential DFVB RHS smoke:

```bash
julia --project scripts/main_sequential_dfvb.jl
```

Run the short sequential DFVB ODE smoke simulation:

```bash
julia --project scripts/main_simulate_dfvb.jl
```

Run the reduced Zenteno kinetic-bound calculation:

```bash
julia --project scripts/main_kinetic_bounds_reduced.jl
```

Run the single-step reduced DFBA RHS evaluation:

```bash
julia --project scripts/main_sequential_reduced.jl
```

Run the single-step full DFBA RHS smoke evaluation:

```bash
julia --project scripts/main_sequential_full.jl
```

Run the sequential reduced DFBA ODE simulation:

```bash
julia --project scripts/main_simulate_reduced_dfba.jl
```

Run the short full sequential DFBA ODE smoke simulation:

```bash
julia --project scripts/main_simulate_full_dfba.jl
```

Run the reduced DFBA simulation export report:

```bash
julia --project scripts/main_export_reduced_dfba.jl
```

Run the basic SVG trajectory plot export from the latest reduced DFBA report:

```bash
julia --project scripts/main_plot_reduced_dfba_export.jl
```

Run the plotting-free reduced DFBA benchmark:

```bash
julia --project scripts/main_benchmark.jl
```

Run the reduced DFBA LP reuse, primal-start, and basis-warm-start benchmark:

```bash
julia --project scripts/main_benchmark_reduced_dfba_warm_start.jl
```

Run the full-vs-reduced DFBA persistence benchmark:

```bash
julia --project scripts/main_benchmark_dfba_persistence.jl
```

## Planned Next Commits

1. Review full-vs-reduced DFBA persistence benchmark outputs on representative horizons and decide accepted baseline tolerances.
2. Refine nonnegative-domain, sugar-depletion event handling, and trajectory comparison thresholds if they affect full/reduced agreement.
3. Improve guarded reduced MPCC solve convergence after reviewing first-solve mass-balance and complementarity residuals.
4. Extract a solved-trajectory candidate only after the guarded solve reports a suitable solver status and tolerable residuals.
5. Broaden multimodel diagnostics only after state-only semantics are reviewed; flux and alpha comparisons remain excluded by default.
6. Consider DFVB LP model-reuse or warm-start performance work only after DFBA persistence baselines and MPCC scaffolding are stable.
