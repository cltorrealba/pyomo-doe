# Dynamic-Control MPCC Branch Comparison

## Trajectory And Residuals

| case | sugar g/L | d sugar | isoamyl g/L | d isoamyl | T delta C | FDA delta | ORG delta | colloc | lower comp | top residual | top comp |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| warm_fda | 185.077462349 | 0 | 0.000226492453321 | 0 | 0.000235013329238 | 0.000762126284687 | 3.30109458786e-08 | 5.44815048163e-05 | 4.79963363278e-05 | valine @ 96.0 h | r_1654 @ 35.0 h |
| coolwarm_fda | 171.232894203 | -13.8445681459 | 0.000208376695794 | -1.8115757527e-05 | 2.93523242512e-05 | 0.000368709581697 | 3.53047160052e-08 | 0.000221069078149 | 0.000273454950396 | protein @ 96.0 h | r_1654 @ 66.0 h |

## Objective Components

| case | objective | base | dynamic | productivity | prod share | sugar excess | sugar share | aroma deficit | aroma share | nutrient | thermal | smooth |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| warm_fda | 74.8004303686 | 0 | 74.8004095448 | 75.0231054076 | 1.00297720112 | 0 | 0 | 0 | 0 | 0.00301524318591 | 0.000381269873009 | 0.000400077557249 |
| coolwarm_fda | 70.0371086124 | 0 | 70.037097738 | 70.2446356603 | 1.00296325703 | 0 | 0 | 0 | 0 | 0.00200737489773 | 0.000250001059931 | 0.000342858919321 |

## Slack Consistency

| case | sugar required | sugar slack | sugar violation | aroma required | aroma slack | aroma violation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| warm_fda | 180.077462349 | NaN |  | 0 | NaN |  |
| coolwarm_fda | 166.232894203 | NaN |  | 0 | NaN |  |

## Hotspots

- warm_fda residual #1: continuity valine at 96.0 h magnitude 5.44815114285e-05
- warm_fda residual #2: collocation_integration valine at 96.0 h magnitude 5.44815048163e-05
- warm_fda residual #3: continuity leucine at 96.0 h magnitude 5.44204516566e-05
- warm_fda residual #4: collocation_integration leucine at 96.0 h magnitude 5.44204384593e-05
- warm_fda residual #5: continuity phenylalanine at 96.0 h magnitude 5.43862684195e-05
- warm_fda residual #6: collocation_integration phenylalanine at 96.0 h magnitude 5.43862444386e-05
- warm_fda residual #7: continuity tyrosine at 96.0 h magnitude 5.43650876454e-05
- warm_fda residual #8: collocation_integration tyrosine at 96.0 h magnitude 5.43650656334e-05
- warm_fda residual #9: continuity methionine at 96.0 h magnitude 5.43106025804e-05
- warm_fda residual #10: collocation_integration methionine at 96.0 h magnitude 5.43105596034e-05
- warm_fda complementarity #1: lower_complementarity r_1654 at 35.0 h magnitude 4.79963363278e-05
- warm_fda complementarity #2: lower_complementarity r_1654 at 23.0 h magnitude 4.78286728736e-05
- warm_fda complementarity #3: lower_complementarity r_1654 at 23.155051025721683 h magnitude 4.71504950194e-05
- warm_fda complementarity #4: lower_complementarity r_1654 at 24.0 h magnitude 4.68251485221e-05
- warm_fda complementarity #5: lower_complementarity r_1654 at 41.0 h magnitude 4.62769839625e-05
- warm_fda complementarity #6: lower_complementarity r_1654 at 23.644948974278318 h magnitude 4.61271777678e-05
- warm_fda complementarity #7: lower_complementarity r_1654 at 41.15505102572168 h magnitude 4.60773134328e-05
- warm_fda complementarity #8: lower_complementarity r_1654 at 24.155051025721683 h magnitude 4.59571376802e-05
- warm_fda complementarity #9: lower_complementarity r_1654 at 41.644948974278314 h magnitude 4.56193892661e-05
- warm_fda complementarity #10: lower_complementarity r_1654 at 35.644948974278314 h magnitude 4.52247467633e-05

Detailed rows are in the sibling CSV files.
