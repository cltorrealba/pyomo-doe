# Dynamic-Control Staged Multistart Summary

Run count: 1
Residual-feasible count: 1
Trajectory-ready count: 0

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | cross_window_flux_dual_start_applied | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | final_selective_dual_fit_applied | selective_dual_fit_accepted | selective_dual_fit_budget_fraction | selective_dual_fit_effective_budget_tau | selective_dual_fit_element_count | selective_dual_fit_max_lower_complementarity_after | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s24_warmrepair_budget0p2_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair4 | 746099 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 189.95 | 0.000182122 | 7.75473e-08 | 0.000124133 | 0.001 | r_1654 | 20.155051025721683 | false | false | true | 0.2 | 0.0002 | 0 | 5.588807371518657e-6 | false | 0.0176912 | 5.86684e-09 | 6.15409e-09 |
