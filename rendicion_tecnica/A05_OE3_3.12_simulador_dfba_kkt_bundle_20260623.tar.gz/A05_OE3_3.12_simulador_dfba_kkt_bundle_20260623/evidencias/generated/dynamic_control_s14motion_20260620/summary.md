# Dynamic-Control Staged Multistart Summary

Run count: 3
Residual-feasible count: 3
Trajectory-ready count: 0

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | cross_window_flux_dual_start_applied | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s14_direct_temp_motion_h72_tau1em3_iter8_repair2 | 745632 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 175.045 | 0.000199591 | 1.56399e-05 | 7.58821e-05 | 0.001 | r_1654 | 54.15505102572168 | false | false | 0.684656 | 1.36584e-09 | 1.60473e-09 |
| s14_slack_temp_motion_h72_tau1em3_iter8_repair2 | 745633 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 173.641 | 0.000339401 | 1.08865e-07 | 2.08922e-05 | 0.001 | r_1654 | 26.0 | false | false | 0.00293791 | 3.886e-09 | 2.69597e-09 |
| s14_slack_nutrient_motion_h72_tau1em3_iter8_repair2 | 745672 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 179.7 | 0.00024067 | 0.000138849 | 0.000120849 | 0.001 | r_1654 | 44.644948974278314 | false | false | 3.16476e-05 | 0.00140898 | -3.52343e-05 |
