# Dynamic-control objective leverage diagnostic

- effective terminal reward coefficient: 1000.0 objective/(g/L target)
- representative temperature full-trust target gain needed: 1.9966517857142857e-05 g/L target
- representative fda full-trust target gain needed: 3e-05 g/L target
- representative organic full-trust target gain needed: 2.4e-05 g/L target
- Target alias is active: isoamyl_acetate is optimized through isoamyl_alcohol.
- All FDA starts are at their lower bound, so added FDA must overcome a bound-active nutrient penalty.
- Rejected post-solve control movement is tiny: max temperature 0.000540266 C and organic sum 6.56786e-05 g/L.

Detailed diagnostics are in the sibling CSV.
