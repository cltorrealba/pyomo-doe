# Dynamic-Control Staged Multistart Summary

Run count: 4
Residual-feasible count: 3
Trajectory-ready count: 1

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s6_mesh_flat22_prod20_reg0p05_tau20_h72 | 744183 | ITERATION_LIMIT | true | false | false | false | false | true | true | 175 | 0.000317781 | 1.28531e-07 | 0.000452691 | 20.0 | r_1902 | 11.155051025721683 | false | false | 0.00637665 | 2.25084e-09 | 2.95739e-09 |
| s7_tau_flat22_postsolve_seed_prod20_reg0p05_tau1em3_h72 | 744111 | ITERATION_LIMIT | true | false |  |  | false | true | true | 175.047 | 0.000199622 | 7.58287e-08 | 0.00099333 | 0.001 | r_1654 | 28.644948974278318 | false | false | 0.0270778 | 1.32256e-09 | 2.11631e-09 |
| s7_debug_flat22_fullseed_tau1em3_iter8_h72 | 744314 | ALMOST_LOCALLY_SOLVED | true | true | true | true | true | true | true | 175 | 0.00031782 | 1.28531e-07 | 0.000452691 | 0.001 | r_1902 | 11.155051025721683 | false | false | 7.55715e-10 | 6.38006e-09 | 6.92758e-10 |
| s8_debug_flat22_fullseed_tau5em4_iter8_h72 | 744348 |  |  |  |  |  | true | true | false |  |  |  |  |  |  |  |  |  |  |  |  |
