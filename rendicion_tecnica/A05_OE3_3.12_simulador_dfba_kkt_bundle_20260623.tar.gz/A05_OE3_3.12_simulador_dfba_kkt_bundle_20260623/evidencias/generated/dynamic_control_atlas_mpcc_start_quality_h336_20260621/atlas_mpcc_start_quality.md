# Atlas vs MPCC Start Quality

| case | h | nfe | atlas sugar | MPCC sugar | delta | colloc | top residual | schedule |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| h336 | 336 | 168 | 19.8442334219 | 115.49396287 | 95.6497294485 | 0.222687939658 | glucose @ 64.0 h | T 22-22 C; FDA 1 g/L |

Rows with `horizon_match=false` are horizon-ladder diagnostics; their terminal sugar is not directly comparable to the 336 h atlas terminal sugar.
