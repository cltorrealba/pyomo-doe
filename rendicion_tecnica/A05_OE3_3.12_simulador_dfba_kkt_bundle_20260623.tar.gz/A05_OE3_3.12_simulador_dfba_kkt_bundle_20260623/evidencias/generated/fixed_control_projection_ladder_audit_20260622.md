# Fixed-control projection ladder audit

This report is generated from existing `reduced_mpcc_fixed_control_policy_solve_attempt.csv` artifacts.

| selection | solve_horizon_h | case_id | selected_candidate_source | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | max_residual | dominant_metric | top_state_name | top_element_index | top_time_h |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| best_residual_feasible | 48 | s18_gentle_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2 | pre_solve_start_values | ITERATION_LIMIT | true | false | 1.125305531939201e-05 | max_lower_complementarity_residual | protein | 48 | 48.0 |
| best_trajectory_ready | 48 |  |  |  |  |  |  |  |  |  |  |
| best_residual_feasible | 96 | h96_s33_seed_explicit_postsolve_try_iter40 | pre_solve_start_values | ALMOST_LOCALLY_SOLVED | true | false | 3.169717494422291e-05 | max_lower_complementarity_residual | protein | 87 | 87.0 |
| best_trajectory_ready | 96 |  |  |  |  |  |  |  |  |  |  |
| best_residual_feasible | 168 | h168_serious_flat22none_fullmove_posttail74_84_iter13 | pre_solve_start_values | ALMOST_LOCALLY_SOLVED | true | false | 2.097674001313283e-05 | max_collocation_integration_residual | protein | 84 | 168.0 |
| best_trajectory_ready | 168 | h168_direct_fda_posttail74_84_iter40 | post_solve_values | ALMOST_LOCALLY_SOLVED | true | true | 0.0004846478141325501 | max_lower_complementarity_residual | valine | 67 | 134.0 |
