# Atlas vs MPCC Start Quality

| case | h | nfe | atlas sugar | MPCC sugar | delta | colloc | top residual | schedule |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| h144_matched | 144 | 72 | 19.8442334219 | 167.918791757 |  | 0.117786083727 | glucose @ 144.0 h | T 22-22 C; FDA 1 g/L |
| h144_finalrhs0 | 144 | 72 | 19.8442334219 | 167.918791757 |  | 0.117786083727 | glucose @ 144.0 h | T 22-22 C; FDA 1 g/L |
| h168_matched | 168 | 84 | 19.8442334219 | 150.051196026 |  | 0.441318249151 | glucose @ 42.0 h | T 22-22 C; FDA 1 g/L |
| h168_nfe168_posttail | 168 | 168 | 19.8442334219 | 93.2491986233 |  | 0.0284514446582 | glucose @ 84.0 h | T 22-22 C; FDA 1 g/L |
| h336 | 336 | 168 | 19.8442334219 | 115.49396287 | 95.6497294485 | 0.222687939658 | glucose @ 64.0 h | T 22-22 C; FDA 1 g/L |

Rows with `horizon_match=false` are horizon-ladder diagnostics; their terminal sugar is not directly comparable to the 336 h atlas terminal sugar.
