# Dynamic-Control MPCC Branch Comparison

## Trajectory And Residuals

| case | sugar g/L | d sugar | isoamyl g/L | d isoamyl | T delta C | FDA delta | ORG delta | colloc | lower comp | top residual | top comp |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| h72_direct_T_w1 | 175.314063114 | 0 | 0.000199685355792 | 0 | 0.0092286803654 | 0 | 0 | 8.77225257937e-05 | 1.85494723011e-05 | glucose @ 32.0 h | r_1654 @ 20.310102051443366 h |
| h72_direct_T_w1000 | 175.314078555 | 1.54408708966e-05 | 0.0001996205676 | -6.4788191644e-08 | 0.00554144641593 | 0 | 0 | 8.83790940357e-05 | 1.72619030787e-05 | glucose @ 32.0 h | r_1654 @ 20.310102051443366 h |
| h168_serious_flat22 | 159.398135428 | -15.9159276862 | 0.000245708293056 | 4.6022937264e-05 | 1.3491185058e-08 | 4.26657562825e-08 | 3.24033712408e-08 | 2.09767400131e-05 | 1.99219295677e-05 | protein @ 168.0 h | r_1913 @ 97.28989794855663 h |

## Objective Components

| case | objective | base | dynamic | sugar excess | sugar share | aroma deficit | aroma share | nutrient | thermal | smooth |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| h72_direct_T_w1 | -0.400622399053 | 0 | -0.400622394119 | 0 | -0 | 0 | -0 | 0 | 0 | 0 |
| h72_direct_T_w1000 | -400.371610904 | 0 | -400.371608238 | 0 | -0 | 0 | -0 | 0 | 0 | 0 |
| h168_serious_flat22 | 329.958406495 | 0 | 329.958406495 | 0 | 0 | 0 | 0 | 1.50138255047e-08 | 0.00199999999362 | 3.40110864778e-20 |

## Slack Consistency

| case | sugar required | sugar slack | sugar violation | aroma required | aroma slack | aroma violation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| h72_direct_T_w1 | 170.314063114 | NaN |  | 0.000300314644208 | NaN |  |
| h72_direct_T_w1000 | 170.314078555 | NaN |  | 0.0003003794324 | NaN |  |
| h168_serious_flat22 | 154.398135428 | NaN |  | 0 | NaN |  |

## Hotspots

- h72_direct_T_w1 residual #1: collocation_integration glucose at 32.0 h magnitude 8.77225257909e-05
- h72_direct_T_w1 residual #2: continuity glucose at 32.0 h magnitude 8.77225257909e-05
- h72_direct_T_w1 residual #3: collocation_integration glucose at 34.0 h magnitude 8.75807904777e-05
- h72_direct_T_w1 residual #4: continuity glucose at 34.0 h magnitude 8.75807904777e-05
- h72_direct_T_w1 residual #5: collocation_integration glucose at 36.0 h magnitude 8.73654170732e-05
- h72_direct_T_w1 residual #6: continuity glucose at 36.0 h magnitude 8.73654170732e-05
- h72_direct_T_w1 residual #7: continuity glucose at 38.0 h magnitude 8.69845798661e-05
- h72_direct_T_w1 residual #8: collocation_integration glucose at 38.0 h magnitude 8.69845798519e-05
- h72_direct_T_w1 complementarity #1: lower_complementarity r_1654 at 20.310102051443366 h magnitude 1.85494723011e-05
- h72_direct_T_w1 complementarity #2: lower_complementarity r_1654 at 24.0 h magnitude 1.5734970832e-05
- h72_direct_T_w1 complementarity #3: lower_complementarity r_1654 at 24.310102051443366 h magnitude 1.56835204992e-05
- h72_direct_T_w1 complementarity #4: lower_complementarity r_1654 at 22.310102051443366 h magnitude 1.56023670177e-05
- h72_direct_T_w1 complementarity #5: lower_complementarity r_1654 at 25.289897948556636 h magnitude 1.55446570899e-05
- h72_direct_T_w1 complementarity #6: lower_complementarity r_1654 at 17.289897948556636 h magnitude 1.55373553628e-05
- h72_direct_T_w1 complementarity #7: lower_complementarity r_1654 at 26.0 h magnitude 1.54638258332e-05
- h72_direct_T_w1 complementarity #8: lower_complementarity r_1654 at 26.310102051443366 h magnitude 1.51721257891e-05
- h72_direct_T_w1000 residual #1: collocation_integration glucose at 32.0 h magnitude 8.83790940378e-05
- h72_direct_T_w1000 residual #2: continuity glucose at 32.0 h magnitude 8.83790940378e-05
- h72_direct_T_w1000 residual #3: collocation_integration glucose at 34.0 h magnitude 8.82362978842e-05
- h72_direct_T_w1000 residual #4: continuity glucose at 34.0 h magnitude 8.82362978842e-05

Detailed rows are in the sibling CSV files.
