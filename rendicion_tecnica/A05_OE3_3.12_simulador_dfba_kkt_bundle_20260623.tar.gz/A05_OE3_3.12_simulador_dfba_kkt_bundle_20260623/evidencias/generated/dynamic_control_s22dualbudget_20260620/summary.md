# Dynamic-Control Staged Multistart Summary

Run count: 2
Residual-feasible count: 2
Trajectory-ready count: 0

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | cross_window_flux_dual_start_applied | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | final_selective_dual_fit_applied | selective_dual_fit_accepted | selective_dual_fit_budget_fraction | selective_dual_fit_effective_budget_tau | selective_dual_fit_element_count | selective_dual_fit_max_lower_complementarity_after | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s22_dualfit_budget0p2_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2 | 746011 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 190.567 | 0.000177544 | 2.67507e-05 | 0.000404278 | 0.001 | r_3682 | 20.0 | false | true | true | 0.2 | 0.0002 | 31 | 0.0003999999999999589 | false | 4.92717e-06 | 9.395e-11 | 4.09958e-08 |
| s22_dualfit_budget0p1_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2 | 746012 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 190.567 | 0.000177544 | 2.67282e-05 | 0.000957352 | 0.001 | r_1654 | 48.0 | false | false | false | 0.1 | 0.0001 | 31 | 0.00011719633815187343 | false | 0.00822188 | -2.31569e-05 | 3.5512e-10 |
