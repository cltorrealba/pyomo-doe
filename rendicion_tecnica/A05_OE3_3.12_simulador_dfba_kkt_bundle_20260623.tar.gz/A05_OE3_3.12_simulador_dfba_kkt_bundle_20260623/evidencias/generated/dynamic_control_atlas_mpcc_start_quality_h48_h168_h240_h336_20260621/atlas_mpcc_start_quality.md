# Atlas vs MPCC Start Quality

| case | h | nfe | atlas sugar | MPCC sugar | delta | colloc | top residual | schedule |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| h48_matched | 48 | 24 | 19.8442334219 | 201.167449141 |  | 0.00465404408221 | protein @ 24.0 h | T 22-22 C; FDA 1 g/L |
| h168_sched336 | 168 | 84 | 19.8442334219 | 150.051196026 |  | 0.441318249151 | glucose @ 42.0 h | T 22-22 C; FDA 1 g/L |
| h240_sched336 | 240 | 120 | 19.8442334219 | 134.410304974 |  | 0.441318249151 | glucose @ 42.0 h | T 22-22 C; FDA 1 g/L |
| h336 | 336 | 168 | 19.8442334219 | 115.49396287 | 95.6497294485 | 0.222687939658 | glucose @ 64.0 h | T 22-22 C; FDA 1 g/L |

Rows with `horizon_match=false` are horizon-ladder diagnostics; their terminal sugar is not directly comparable to the 336 h atlas terminal sugar.
