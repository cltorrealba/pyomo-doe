# Dynamic-Control MPCC Branch Comparison

## Trajectory And Residuals

| case | sugar g/L | d sugar | isoamyl g/L | d isoamyl | T delta C | FDA delta | ORG delta | colloc | lower comp | top residual | top comp |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| balance | 91.6405532012 | 0 | 0.000399517090968 | 0 | 0.00308554341179 | 3.28304749978e-08 | -2.93201598018e-05 | 0.0437208129867 | 0.00194002371539 | protein @ 168.0 h | r_1914 @ 36.644948974278314 h |
| aroma3 | 91.640096701 | -0.000456500212607 | 0.00039973319917 | 2.16108202325e-07 | 0.00496586884863 | 2.68998738802e-08 | -3.32259217515e-05 | 0.0436324343444 | 0.00194605854614 | protein @ 168.0 h | r_1914 @ 36.644948974278314 h |
| cost3 | 91.6402761106 | -0.00027709056873 | 0.000399694935157 | 1.77844188668e-07 | 0.00383114179535 | 2.42187741878e-08 | -6.91085499653e-05 | 0.0436410596952 | 0.00193752012334 | protein @ 168.0 h | r_1914 @ 36.644948974278314 h |

## Objective Components

| case | objective | base | dynamic | sugar excess | sugar share | aroma deficit | aroma share | nutrient | thermal | smooth |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| balance | 3187.28419991 | 0 | 3187.28419992 | 3182.93562654 | 0.998635649316 | 3.21794626379 | 0.00100962012232 | 0.909024346979 | 0.1601030937 | 0.0614996733662 |
| aroma3 | 3181.52338283 | 0 | 3181.52338284 | 3170.78065915 | 0.996623402565 | 9.61205686506 | 0.00302121207623 | 0.909015456768 | 0.160174834104 | 0.0614765388658 |
| cost3 | 3177.91050719 | 0 | 3177.91050723 | 3171.3431585 | 0.997933438113 | 3.20660680156 | 0.00100902992525 | 2.72680169774 | 0.480252561036 | 0.153687674848 |

## Hotspots

- balance residual #1: continuity protein at 168.0 h magnitude 0.0437208129867
- balance residual #2: collocation_integration protein at 168.0 h magnitude 0.0437208129867
- balance residual #3: continuity protein at 167.0 h magnitude 0.0424598162567
- balance residual #4: collocation_integration protein at 167.0 h magnitude 0.0424598162558
- balance residual #5: continuity protein at 166.0 h magnitude 0.0412271685128
- balance residual #6: collocation_integration protein at 166.0 h magnitude 0.0412271685112
- balance residual #7: continuity protein at 165.0 h magnitude 0.0400223573988
- balance residual #8: collocation_integration protein at 165.0 h magnitude 0.0400223573966
- balance residual #9: continuity protein at 164.0 h magnitude 0.0388448872323
- balance residual #10: collocation_integration protein at 164.0 h magnitude 0.0388448872294
- balance complementarity #1: lower_complementarity r_1914 at 36.644948974278314 h magnitude 0.00194002371539
- balance complementarity #2: lower_complementarity r_1914 at 36.15505102572168 h magnitude 0.00193996940775
- balance complementarity #3: lower_complementarity r_1914 at 36.0 h magnitude 0.00191279877948
- balance complementarity #4: lower_complementarity r_1914 at 37.0 h magnitude 0.00181890456075
- balance complementarity #5: lower_complementarity r_1914 at 35.644948974278314 h magnitude 0.00180933145279
- balance complementarity #6: lower_complementarity r_1914 at 45.644948974278314 h magnitude 0.00180422588365
- balance complementarity #7: lower_complementarity r_1914 at 46.644948974278314 h magnitude 0.00180128346213
- balance complementarity #8: lower_complementarity r_1914 at 46.15505102572168 h magnitude 0.00179994271002
- balance complementarity #9: lower_complementarity r_1914 at 50.15505102572168 h magnitude 0.00177895806605
- balance complementarity #10: lower_complementarity r_1914 at 50.644948974278314 h magnitude 0.00177894822454

Detailed rows are in the sibling CSV files.
