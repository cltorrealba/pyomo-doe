# Dynamic-Control MPCC Branch Comparison

| case | sugar g/L | d sugar | isoamyl g/L | d isoamyl | colloc | lower comp | top residual | top comp |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| unseeded | 194.624792219 | 0 | 0.000676676439348 | 0 | 0.00764905978334 | 2.74888075558e-05 | glucose @ 28.0 h | r_0203 @ 22.644948974278318 h |
| seed_org_slot1_nfe72 | 158.866923073 | -35.7578691463 | 0.00131844230475 | 0.000641765865405 | 0.0185174276861 | 0.00108811250896 | ethanol @ 31.0 h | r_2091 @ 30.0 h |
| seed_org_slot1_nfe144 | 194.765693993 | 0.140901773644 | 0.000581270775208 | -9.54056641395e-05 | 0.000182265994745 | 0.000476686671423 | protein @ 25.0 h | r_1862 @ 16.322474487139157 h |

## Hotspots

- unseeded residual #1: collocation_integration glucose at 28.0 h magnitude 0.00764905978335
- unseeded residual #2: continuity glucose at 28.0 h magnitude 0.00764905978335
- unseeded residual #3: collocation_integration glucose at 72.0 h magnitude 0.00761610031292
- unseeded residual #4: continuity glucose at 72.0 h magnitude 0.00761610031292
- unseeded residual #5: collocation_integration fructose at 28.0 h magnitude 0.00714397372346
- unseeded residual #6: continuity fructose at 28.0 h magnitude 0.00714397372346
- unseeded residual #7: collocation_integration glucose at 27.0 h magnitude 0.00630333651876
- unseeded residual #8: continuity glucose at 27.0 h magnitude 0.00630333651876
- unseeded residual #9: collocation_integration fructose at 27.0 h magnitude 0.00598945167485
- unseeded residual #10: continuity fructose at 27.0 h magnitude 0.00598945167485
- unseeded residual #11: collocation_integration protein at 72.0 h magnitude 0.00535324615618
- unseeded residual #12: continuity protein at 72.0 h magnitude 0.00535324615618
- unseeded complementarity #1: lower_complementarity r_0203 at 22.644948974278318 h magnitude 2.74888075558e-05
- unseeded complementarity #2: lower_complementarity r_0203 at 37.15505102572168 h magnitude 2.62543614681e-05
- unseeded complementarity #3: lower_complementarity r_0203 at 37.644948974278314 h magnitude 2.55053686829e-05
- unseeded complementarity #4: lower_complementarity r_0203 at 38.0 h magnitude 2.49824369632e-05
- unseeded complementarity #5: lower_complementarity r_0203 at 38.15505102572168 h magnitude 2.47591459045e-05
- unseeded complementarity #6: lower_complementarity r_0203 at 38.644948974278314 h magnitude 2.40733000036e-05
- unseeded complementarity #7: lower_complementarity r_0203 at 39.0 h magnitude 2.35943160716e-05
- unseeded complementarity #8: lower_complementarity r_0203 at 39.15505102572168 h magnitude 2.33897615008e-05

Detailed rows are in the sibling CSV files.
