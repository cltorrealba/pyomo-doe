# Dynamic-Control Staged Multistart Summary

Run count: 2
Residual-feasible count: 2
Trajectory-ready count: 0

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | cross_window_flux_dual_start_applied | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s18_gentle_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2 | 745808 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 190.567 | 0.000177544 | 2.67282e-05 | 0.000999921 | 0.001 | r_1654 | 48.0 | false | false | 0.00885252 | 1.65581e-05 | 3.26331e-10 |
| s18_gentle_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2 | 745807 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 189.95 | 0.00018212 | 3.32599e-07 | 1.12531e-05 | 0.001 | r_1654 | 20.155051025721683 | false | false | 0.0318435 | 3.43223e-09 | 3.79517e-09 |
