# Dynamic-Control MPCC Branch Comparison

| case | sugar g/L | d sugar | isoamyl g/L | d isoamyl | colloc | lower comp | top residual | top comp |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| seed_org_slot1 | 158.866923073 | 0 | 0.00131844230475 | 0 | 0.0185174276861 | 0.00108811250896 | ethanol @ 31.0 h | r_2091 @ 30.0 h |
| seed_org_slot1_repair29_44_flux2 | 163.001046694 | 4.13412362032 | 0.000374016930415 | -0.000944425374338 | 0.0867775520609 | 4.21864129498e-07 | glucose @ 44.15505102572168 h | r_1588 @ 9.155051025721683 h |
| seed_org_slot1_posttail_compflux | 158.866924654 | 1.58039946996e-06 | 0.00131851185005 | 6.95452960974e-08 | 0.0185174276218 | 0.00108811512771 | ethanol @ 31.0 h | r_2091 @ 30.0 h |

## Hotspots

- seed_org_slot1 residual #1: collocation_integration ethanol at 31.0 h magnitude 0.0185174276861
- seed_org_slot1 residual #2: continuity ethanol at 31.0 h magnitude 0.0185174276861
- seed_org_slot1 residual #3: continuity ethanol at 32.0 h magnitude 0.0182708409123
- seed_org_slot1 residual #4: collocation_integration ethanol at 32.0 h magnitude 0.0182708409123
- seed_org_slot1 residual #5: collocation_integration ethanol at 33.0 h magnitude 0.0180222960687
- seed_org_slot1 residual #6: continuity ethanol at 33.0 h magnitude 0.0180222960687
- seed_org_slot1 residual #7: collocation_integration ethanol at 34.0 h magnitude 0.0177728341203
- seed_org_slot1 residual #8: continuity ethanol at 34.0 h magnitude 0.0177728341203
- seed_org_slot1 residual #9: collocation_integration ethanol at 35.0 h magnitude 0.017523331348
- seed_org_slot1 residual #10: continuity ethanol at 35.0 h magnitude 0.017523331348
- seed_org_slot1 residual #11: collocation_integration ethanol at 36.0 h magnitude 0.017274532362
- seed_org_slot1 residual #12: continuity ethanol at 36.0 h magnitude 0.017274532362
- seed_org_slot1 complementarity #1: lower_complementarity r_2091 at 30.0 h magnitude 0.00108811250896
- seed_org_slot1 complementarity #2: lower_complementarity r_2091 at 31.0 h magnitude 0.00107065302176
- seed_org_slot1 complementarity #3: lower_complementarity r_1914 at 35.15505102572168 h magnitude 0.00106604783129
- seed_org_slot1 complementarity #4: lower_complementarity r_2091 at 30.155051025721683 h magnitude 0.00106239818734
- seed_org_slot1 complementarity #5: lower_complementarity r_1914 at 35.0 h magnitude 0.00106125634254
- seed_org_slot1 complementarity #6: lower_complementarity r_2091 at 32.0 h magnitude 0.0010532835368
- seed_org_slot1 complementarity #7: lower_complementarity r_2091 at 31.155051025721683 h magnitude 0.0010470565484
- seed_org_slot1 complementarity #8: lower_complementarity r_1914 at 36.0 h magnitude 0.00103982745854

Detailed rows are in the sibling CSV files.
