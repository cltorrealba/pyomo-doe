# h96 Fixed-Control Projection Follow-Up, 2026-06-22

Purpose: test whether the best h96 residual-feasible fixed-control seed can be
converted toward strict post-solve trajectory readiness without broad
optimization or control liberation.

## Inputs

- Starting h96 seed:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s33_funnel_warmtemp_h96_nfe96_tau1em3_iter12_reg0p02_repair2_20260621_005036/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- Matching control profile: explicit warm-temperature controls, temperature
  indices `1,3,5,7`, offsets `1=1.0,3=1.0,5=0.5,7=0.25`.
- Solver profile for post-solve attempt: MA86, limited-memory Hessian,
  `feasibility_handoff`, h96/nfe96, 8 CPU, `OPENBLAS_NUM_THREADS=1`.

## Runs

| job | run root | outcome |
| --- | --- | --- |
| `747310` | `/home/cltorrealba/mpcc_runs/fixed_control_projection_h96_s33_locked_postsolve_20260622_002541` | Failed before Ipopt: locked flat22 bounds were incompatible with seed temperature `23.0 C` versus target `[22.0, 22.0]`. |
| `747311` | `/home/cltorrealba/mpcc_runs/fixed_control_projection_h96_s33_explicit_postsolve_20260622_004140` | Ipopt reached `ALMOST_LOCALLY_SOLVED` with `inf_pr=1.3991e-5`, but post-solve was rejected as `not_residual_feasible`; selected candidate fell back to pre-solve start. |
| `747315` | `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_active_band_20260622_010555/rank1_71_89` | Active-band projection `71:89` accepted damping `0.02`; protein collocation/continuity improved from `1.4457e-5` to `1.4025e-5`; lower complementarity remained `3.1730e-5`. |
| `747316` | `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_active_band_20260622_011943/rank1_71_89` | Repeated active-band projection with selective dual fit enabled and budget fraction `0.01`; primal improved to `1.3607e-5`; selective dual fit was not applied/accepted; lower complementarity remained `3.1730e-5`. |

## Current Best h96 Evidence

- Best max-residual h96 row remains
  `h96_s33_seed_explicit_postsolve_try_iter40`:
  - `selected_candidate_source=pre_solve_start_values`
  - `solver_status=ALMOST_LOCALLY_SOLVED`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - `max_lower_complementarity_residual=3.169717494422291e-5`
  - `max_collocation_integration_residual=1.3991011653301244e-5`
  - `max_continuity_residual=1.3991011656687424e-5`

## Interpretation

- Control-state handoff is validated when the dynamic-control bounds match the
  seed controls.
- The fixed-control active-band projection is monotone for the protein primal
  defect, but the improvement rate is small and still above the strict
  `1e-6` collocation/continuity post-solve threshold.
- The dominant complementarity defect is a separate tail issue near elements
  95-96 for reactions including `r_1903`, `r_1913`, `r_1897`, and `r_1914`.
- Tight selective dual fit did not resolve the tail complementarity defect.
- Next methodological step: homotopy/regularization on top of the validated
  fixed-control seed, rather than more same-grid microprojection.
