# Dynamic-Control Staged Multistart Summary

Run count: 3
Residual-feasible count: 3
Trajectory-ready count: 2

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | cross_window_flux_dual_start_applied | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s15_micro_direct_nutrient_h24_nfe24_tau1em3_iter3_repair1 | 745708 | ALMOST_LOCALLY_SOLVED | true | true | false | false | false | false | true | true | 207.557 | 0.000108833 | 2.55267e-05 | 5.84141e-06 | 0.001 | r_1902 | 11.155051025721683 | false | false | 4.76948e-05 | 9.94317e-05 | -1.38292e-05 |
| s15_micro_direct_temp_h24_nfe24_tau1em3_iter3_repair1 | 745707 | ALMOST_LOCALLY_SOLVED | true | true | false | false | false | false | true | true | 207.679 | 0.000107064 | 1.97192e-05 | 9.80695e-06 | 0.001 | r_1902 | 13.155051025721683 | false | false | 0.00135609 | 6.11733e-11 | 0 |
| s15_micro_slack_temp_h24_nfe24_tau1em3_iter3_repair1 | 745729 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 207.552 | 0.000115391 | 1.08633e-06 | 1.37329e-05 | 0.001 | r_1654 | 23.644948974278318 | false | false | 0.0116083 | 6.15031e-11 | 0 |
