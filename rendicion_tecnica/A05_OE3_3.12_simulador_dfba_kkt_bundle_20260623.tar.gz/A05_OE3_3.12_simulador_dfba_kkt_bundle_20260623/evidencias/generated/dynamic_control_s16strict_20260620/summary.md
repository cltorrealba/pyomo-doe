# Dynamic-Control Staged Multistart Summary

Run count: 2
Residual-feasible count: 2
Trajectory-ready count: 0

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | cross_window_flux_dual_start_applied | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s16_strict_direct_nutrient_h24_nfe24_tau1em3_iter20_repair1 | 745741 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 207.557 | 0.000108217 | 2.55241e-05 | 5.69764e-06 | 0.001 | r_1902 | 11.155051025721683 | false | false | 0.00500925 | 0.000805471 | -0.000253889 |
| s16_strict_direct_temp_h24_nfe24_tau1em3_iter20_repair1 | 745740 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 207.679 | 0.000107052 | 1.97112e-05 | 0.000751444 | 0.001 | r_1902 | 11.155051025721683 | false | false | 0.0905038 | 4.09396e-10 | 0 |
