# Dynamic-control objective leverage diagnostic

- terminal reward coefficient: 1.0 objective/(g/L target)
- representative temperature full-trust target gain needed: 0.019966517857142856 g/L target
- representative fda full-trust target gain needed: 0.030000000000000002 g/L target
- representative organic full-trust target gain needed: 0.024 g/L target
- White-wine aroma blend target is active over available reduced aroma states.
- All FDA starts are at their lower bound, so added FDA must overcome a bound-active nutrient penalty.
- Accepted post-solve control movement is tiny: max temperature 0.00102844 C and organic sum 0.00011604 g/L.

Detailed diagnostics are in the sibling CSV.
