# Dynamic-Control Staged Multistart Summary

Run count: 2
Residual-feasible count: 2
Trajectory-ready count: 0

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | cross_window_flux_dual_start_applied | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | final_selective_dual_fit_applied | selective_dual_fit_accepted | selective_dual_fit_budget_fraction | selective_dual_fit_effective_budget_tau | selective_dual_fit_element_count | selective_dual_fit_max_lower_complementarity_after | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s25_extend_warmtemp_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2 | 746154 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 174.426 | 0.000203989 | 1.64771e-06 | 8.51674e-06 | 0.001 | r_1654 | 22.155051025721683 | false | false | true | 0.2 | 0.0002 | 0 | 8.613247814280009e-6 | false | 0.0211927 | 3.88994e-10 | 1.67304e-09 |
| s25_extend_mixedsplit_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2 | 746196 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 174.707 | 0.000210203 | 2.62689e-06 | 0.000411064 | 0.001 | r_3515 | 20.644948974278318 | false | true | true | 0.2 | 0.0002 | 52 | 0.00039999999999994017 | false | 3.41168e-06 | 1.08423e-07 | -5.08504e-08 |
