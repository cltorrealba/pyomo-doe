# Dynamic-Control Staged Multistart Summary

Run count: 2
Residual-feasible count: 2
Trajectory-ready count: 0

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | cross_window_flux_dual_start_applied | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s17_seedrelax_coolwarm_h48_nfe48_tau1em3_iter30_reg0p02_repair1 | 745768 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 190.658 | 0.000175288 | 0.00026504 | 4.81407e-06 | 0.001 | r_1902 | 11.0 | false | false | 0.076395 | 0.000590466 | 3.51508e-10 |
| s17_seedrelax_warmtemp_h48_nfe48_tau1em3_iter30_reg0p02_repair1 | 745767 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 188.641 | 0.000187784 | 0.000753672 | 0.000999903 | 0.001 | r_1914 | 28.0 | false | false | 0.0552569 | 1.3111e-09 | 3.70509e-10 |
