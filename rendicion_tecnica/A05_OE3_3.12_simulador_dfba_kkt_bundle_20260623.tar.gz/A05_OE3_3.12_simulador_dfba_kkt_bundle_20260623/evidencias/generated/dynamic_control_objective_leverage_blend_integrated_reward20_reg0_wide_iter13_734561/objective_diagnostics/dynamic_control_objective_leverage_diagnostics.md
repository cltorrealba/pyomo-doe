# Dynamic-control objective leverage diagnostic

- effective terminal reward coefficient: 10.0 objective/(g/L target)
- representative temperature full-trust target gain needed: -1.4285714285714288e-06 g/L target
- representative fda full-trust target gain needed: 0.0004 g/L target
- representative organic full-trust target gain needed: 0.0002 g/L target
- Integrated gross aroma-production reward is active with effective weight 10.0.
- White-wine aroma blend target is active over available reduced aroma states.
- All FDA starts are at their lower bound, so added FDA must overcome a bound-active nutrient penalty.
- Accepted post-solve control movement is tiny: max temperature 0.00102844 C and organic sum 0.00011604 g/L.

Detailed diagnostics are in the sibling CSV.
