# Dynamic-Control MPCC Branch Comparison

## Trajectory And Residuals

| case | sugar g/L | d sugar | isoamyl g/L | d isoamyl | T delta C | FDA delta | ORG delta | colloc | lower comp | top residual | top comp |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| narrow_balance | 91.6405532012 | 0 | 0.000399517090968 | 0 | 0.00308554341179 | 3.28304749978e-08 | -2.93201598018e-05 | 0.0437208129867 | 0.00194002371539 | protein @ 168.0 h | r_1914 @ 36.644948974278314 h |
| narrow_aroma3 | 91.640096701 | -0.000456500212607 | 0.00039973319917 | 2.16108202325e-07 | 0.00496586884863 | 2.68998738802e-08 | -3.32259217515e-05 | 0.0436324343444 | 0.00194605854614 | protein @ 168.0 h | r_1914 @ 36.644948974278314 h |
| narrow_cost3 | 91.6402761106 | -0.00027709056873 | 0.000399694935157 | 1.77844188668e-07 | 0.00383114179535 | 2.42187741878e-08 | -6.91085499653e-05 | 0.0436410596952 | 0.00193752012334 | protein @ 168.0 h | r_1914 @ 36.644948974278314 h |
| wide_balance | 91.6398914545 | -0.000661746749458 | 0.000489256624053 | 8.97395330846e-05 | 0.00618550827929 | 6.09259732695e-08 | -5.98569147666e-05 | 0.0435302687576 | 0.0019303502886 | protein @ 168.0 h | r_1914 @ 36.644948974278314 h |
| wide_sugaronly | 91.6382964513 | -0.00225674990621 | 0.000494109617976 | 9.45925270085e-05 | 0.0136743161666 | 3.13599377444e-05 | -0.000111182169499 | 0.0428921116771 | 0.00191545698386 | protein @ 168.0 h | r_1914 @ 36.0 h |
| wide_aromaonly | 91.6401667165 | -0.000386484753633 | 0.000401533707858 | 2.01661688998e-06 | 0.00861856979829 | 5.53769973158e-08 | -5.47358143808e-05 | 0.0435339617542 | 0.00195174844622 | protein @ 168.0 h | r_1914 @ 36.644948974278314 h |

## Objective Components

| case | objective | base | dynamic | sugar excess | sugar share | aroma deficit | aroma share | nutrient | thermal | smooth |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| narrow_balance | 3187.28419991 | 0 | 3187.28419992 | 3182.93562654 | 0.998635649316 | 3.21794626379 | 0.00100962012232 | 0.909024346979 | 0.1601030937 | 0.0614996733662 |
| narrow_aroma3 | 3181.52338283 | 0 | 3181.52338284 | 3170.78065915 | 0.996623402565 | 9.61205686506 | 0.00302121207623 | 0.909015456768 | 0.160174834104 | 0.0614765388658 |
| narrow_cost3 | 3177.91050719 | 0 | 3177.91050723 | 3171.3431585 | 0.997933438113 | 3.20660680156 | 0.00100902992525 | 2.72680169774 | 0.480252561036 | 0.153687674848 |
| wide_balance | 3160.08731272 | 0 | 3160.08731273 | 3158.95669741 | 0.99964222023 | 1.66805329849e-10 | 5.2785038305e-14 | 0.908955009116 | 0.16020189969 | 0.0614584036553 |
| wide_sugaronly | 3060.3450663 | 0 | 3060.3450663 | 3060.3450663 | 1 | 0 | 0 | 0 | 0 | 0 |
| wide_aromaonly | 30.7810579227 | 0 | 30.7810579227 | 0 | 0 | 30.7810579227 | 1 | 0 | 0 | 0 |

## Slack Consistency

| case | sugar required | sugar slack | sugar violation | aroma required | aroma slack | aroma violation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| narrow_balance | 86.6405532012 | 89.2039184473 | 0 | 0.000100482909032 | 8.96931750998e-05 | 1.07897339323e-05 |
| narrow_aroma3 | 86.640096701 | 89.0334299455 | 0 | 0.00010026680083 | 8.94988680797e-05 | 1.076793275e-05 |
| narrow_cost3 | 86.6402761106 | 89.0413269007 | 0 | 0.000100305064843 | 8.95350043496e-05 | 1.07700604937e-05 |
| wide_balance | 86.6398914545 | 88.8672703729 | 0 | 1.07433759474e-05 | 6.45765688639e-10 | 1.07427301817e-05 |
| wide_sugaronly | 86.6382964513 | 87.4692098155 | 0 | 5.89038202351e-06 | NaN |  |
| wide_aromaonly | 86.6401667165 | NaN |  | 9.8466292142e-05 | 8.77226565984e-05 | 1.07436355437e-05 |

## Hotspots

- narrow_balance residual #1: continuity protein at 168.0 h magnitude 0.0437208129867
- narrow_balance residual #2: collocation_integration protein at 168.0 h magnitude 0.0437208129867
- narrow_balance residual #3: continuity protein at 167.0 h magnitude 0.0424598162567
- narrow_balance residual #4: collocation_integration protein at 167.0 h magnitude 0.0424598162558
- narrow_balance residual #5: continuity protein at 166.0 h magnitude 0.0412271685128
- narrow_balance residual #6: collocation_integration protein at 166.0 h magnitude 0.0412271685112
- narrow_balance residual #7: continuity protein at 165.0 h magnitude 0.0400223573988
- narrow_balance residual #8: collocation_integration protein at 165.0 h magnitude 0.0400223573966
- narrow_balance residual #9: continuity protein at 164.0 h magnitude 0.0388448872323
- narrow_balance residual #10: collocation_integration protein at 164.0 h magnitude 0.0388448872294
- narrow_balance complementarity #1: lower_complementarity r_1914 at 36.644948974278314 h magnitude 0.00194002371539
- narrow_balance complementarity #2: lower_complementarity r_1914 at 36.15505102572168 h magnitude 0.00193996940775
- narrow_balance complementarity #3: lower_complementarity r_1914 at 36.0 h magnitude 0.00191279877948
- narrow_balance complementarity #4: lower_complementarity r_1914 at 37.0 h magnitude 0.00181890456075
- narrow_balance complementarity #5: lower_complementarity r_1914 at 35.644948974278314 h magnitude 0.00180933145279
- narrow_balance complementarity #6: lower_complementarity r_1914 at 45.644948974278314 h magnitude 0.00180422588365
- narrow_balance complementarity #7: lower_complementarity r_1914 at 46.644948974278314 h magnitude 0.00180128346213
- narrow_balance complementarity #8: lower_complementarity r_1914 at 46.15505102572168 h magnitude 0.00179994271002
- narrow_balance complementarity #9: lower_complementarity r_1914 at 50.15505102572168 h magnitude 0.00177895806605
- narrow_balance complementarity #10: lower_complementarity r_1914 at 50.644948974278314 h magnitude 0.00177894822454

Detailed rows are in the sibling CSV files.
