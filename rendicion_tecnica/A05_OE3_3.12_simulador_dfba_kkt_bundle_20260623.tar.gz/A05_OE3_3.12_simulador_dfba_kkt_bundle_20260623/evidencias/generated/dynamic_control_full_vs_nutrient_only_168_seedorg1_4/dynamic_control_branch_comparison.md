# Dynamic-Control MPCC Branch Comparison

| case | sugar g/L | d sugar | isoamyl g/L | d isoamyl | colloc | lower comp | top residual | top comp |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| full168 | 90.2980562147 | 0 | 0.00042413985657 | 0 | 0.0500742192196 | 0.00165695082939 | protein @ 168.0 h | r_1914 @ 52.644948974278314 h |
| nutrient_only168 | 90.2980562147 | -2.11315409615e-11 | 0.000424139815073 | -4.14963842368e-11 | 0.0500742192196 | 0.00165695082934 | protein @ 168.0 h | r_1914 @ 52.644948974278314 h |

## Hotspots

- full168 residual #1: collocation_integration protein at 168.0 h magnitude 0.0500742192196
- full168 residual #2: continuity protein at 168.0 h magnitude 0.0500742192196
- full168 residual #3: collocation_integration protein at 167.0 h magnitude 0.048586240386
- full168 residual #4: continuity protein at 167.0 h magnitude 0.048586240386
- full168 residual #5: collocation_integration protein at 166.0 h magnitude 0.0471463160265
- full168 residual #6: continuity protein at 166.0 h magnitude 0.0471463160265
- full168 residual #7: collocation_integration protein at 165.0 h magnitude 0.0457404062103
- full168 residual #8: continuity protein at 165.0 h magnitude 0.0457404062103
- full168 residual #9: collocation_integration protein at 164.0 h magnitude 0.0443676774065
- full168 residual #10: continuity protein at 164.0 h magnitude 0.0443676774065
- full168 residual #11: continuity protein at 163.0 h magnitude 0.0430273445172
- full168 residual #12: collocation_integration protein at 163.0 h magnitude 0.0430273445172
- full168 complementarity #1: lower_complementarity r_1914 at 52.644948974278314 h magnitude 0.00165695082939
- full168 complementarity #2: lower_complementarity r_1914 at 52.15505102572168 h magnitude 0.00165217506434
- full168 complementarity #3: lower_complementarity r_1914 at 53.0 h magnitude 0.00164908603599
- full168 complementarity #4: lower_complementarity r_1914 at 53.15505102572168 h magnitude 0.00164570412641
- full168 complementarity #5: lower_complementarity r_1914 at 52.0 h magnitude 0.00164475003614
- full168 complementarity #6: lower_complementarity r_1914 at 53.644948974278314 h magnitude 0.00163592692312
- full168 complementarity #7: lower_complementarity r_1914 at 54.0 h magnitude 0.00162870397366
- full168 complementarity #8: lower_complementarity r_1914 at 51.644948974278314 h magnitude 0.00162707345576

Detailed rows are in the sibling CSV files.
