# Dynamic-Control Staged Multistart Summary

Run count: 2
Residual-feasible count: 2
Trajectory-ready count: 0

| case_id | job_id | solver_status | selected_candidate_residual_feasible | selected_candidate_trajectory_ready | full_candidate_start_seed_applied | full_candidate_start_seed_dynamic_controls_applied | candidate_diagnostics_start_jls_loaded | cross_window_flux_dual_start_applied | mpcc_solve_started | mpcc_solve_returned | terminal_total_sugar_g_L | terminal_isoamyl_alcohol_g_L | max_collocation_residual | max_lower_complementarity_residual | complementarity_tau | top_complementarity_reaction_id | top_complementarity_time_h | final_complementarity_flux_projection_applied | final_selective_dual_fit_applied | selective_dual_fit_accepted | selective_dual_fit_element_count | selective_dual_fit_max_lower_complementarity_after | bound_dual_complementarity_clip_applied | temperature_max_abs_delta_vs_start_C | fda_sum_delta_vs_start_g_L | organic_sum_delta_vs_start_g_L |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| s20_dualfit_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2 | 745915 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 190.567 | 0.000177544 | 2.67507e-05 | 0.000582511 | 0.001 | r_2433 | 33.15505102572168 | false | true | true | 31 | 0.0005833333636983282 | false | 6.01853e-06 | 1.40898e-07 | 0 |
| s20_dualfit_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2 | 745914 | ITERATION_LIMIT | true | false | false | false | false | false | true | true | 189.95 | 0.00018212 | 3.32593e-07 | 2.39557e-05 | 0.001 | r_1654 | 20.155051025721683 | false | false | true | 0 | 5.562794094589434e-6 | false | 0.0318504 | 3.50941e-09 | 3.6023e-09 |
