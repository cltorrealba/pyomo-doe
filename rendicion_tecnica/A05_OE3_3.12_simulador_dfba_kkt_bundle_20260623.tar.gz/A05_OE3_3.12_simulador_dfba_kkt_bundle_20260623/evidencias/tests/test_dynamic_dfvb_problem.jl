using DataFrames
import MathOptInterface as DynamicDFVBMOI
using SparseArrays

const DYNAMIC_DFVB_REAL_CACHE = Ref{Any}(nothing)
const DYNAMIC_DFVB_FULL_MODEL_CACHE = Ref{Any}(nothing)
const DYNAMIC_DFVB_FULL_REACTION_MAP_CACHE = Ref{Any}(nothing)

function _synthetic_dynamic_dfvb_artifacts()
    paths = DFVBArtifactPaths(
        "synthetic_dynamic_dfvb",
        "manifest",
        "reaction_order",
        "reduced_dfba_reaction_order",
        "exchange_partition",
        "exchange_partition_active_alpha",
        "n_sparse_triplets",
        "n_column_metadata",
        "n_active_alpha_sparse_triplets",
        "n_active_alpha_column_metadata",
        "active_alpha_indices",
        "alpha_bounds",
        "alpha_bounds_active",
        "alpha_trajectories",
        "alpha_trajectories_active",
        "state_trajectories",
        "inactive_reactions",
        "inactive_reactions_active_alpha",
    )
    manifest = DFVBArtifactManifest(3, 1, 2, 1, 2, 1, true, 2, Dict{String, Any}())
    reaction_order = DataFrame(
        reaction_index = [1, 2, 3],
        reaction_id = ["r_1", "r_2", "r_3"],
        is_exchange = [true, false, false],
        is_internal = [false, true, true],
        exchange_position = [1, 0, 0],
        internal_position = [0, 1, 2],
        is_active_exchange = [true, false, false],
        is_active_internal = [false, true, true],
        is_inactive_exchange = [false, false, false],
        is_inactive_internal = [false, false, false],
        model_scope = ["synthetic", "synthetic", "synthetic"],
    )
    partition = DataFrame(
        model_scope = ["synthetic", "synthetic", "synthetic"],
        partition = ["exchange", "internal", "internal"],
        partition_position = [1, 1, 2],
        reaction_index = [1, 2, 3],
        reaction_id = ["r_1", "r_2", "r_3"],
        is_active = [true, true, true],
        is_inactive_forced_zero = [false, false, false],
    )
    alpha_metadata = DataFrame(
        alpha_index = [1, 2],
        source_alpha_index = [1, 2],
        source_alpha_id = ["alpha_1", "alpha_2"],
        is_active = [true, true],
        model_scope = ["synthetic", "synthetic"],
    )
    alpha_bounds = DataFrame(
        alpha_index = [1, 2],
        source_alpha_index = [1, 2],
        source_alpha_id = ["alpha_1", "alpha_2"],
        lower_bound = [0.0, 0.0],
        upper_bound = [10.0, 5.0],
        model_scope = ["synthetic", "synthetic"],
    )
    active_alpha_indices = DataFrame(
        active_alpha_index = [1, 2],
        source_alpha_index = [1, 2],
        source_alpha_id = ["alpha_1", "alpha_2"],
    )
    N = sparse([1, 2, 3], [1, 1, 2], [1.0, 1.0, 1.0], 3, 2)
    empty_inactive = DataFrame(model_scope = String[], partition = String[], reaction_id = String[])

    return DFVBArtifacts(
        paths,
        manifest,
        reaction_order,
        DataFrame(reduced_reaction_index = Int[], original_reaction_index = Int[], reaction_id = String[]),
        partition,
        partition,
        N,
        alpha_metadata,
        N,
        alpha_metadata,
        active_alpha_indices,
        alpha_bounds,
        alpha_bounds,
        nothing,
        nothing,
        nothing,
        empty_inactive,
        empty_inactive,
        Dict{String, Any}(
            "indices_reacciones_used" => false,
            "r0001_used_as_oxygen" => false,
        ),
    )
end

function _dynamic_dfvb_real_artifacts()
    if DYNAMIC_DFVB_REAL_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        DYNAMIC_DFVB_REAL_CACHE[] = load_dfvb_artifacts(
            joinpath(project_root, "config", "dfvb_artifact_paths.example.toml");
            load_alpha_trajectories = false,
            load_active_alpha_trajectories = false,
            load_state_trajectories = false,
        )
    end
    return DYNAMIC_DFVB_REAL_CACHE[]
end

function _dynamic_dfvb_full_model()
    if DYNAMIC_DFVB_FULL_MODEL_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        DYNAMIC_DFVB_FULL_MODEL_CACHE[] = load_full_model(joinpath(project_root, "config", "full_model_paths.example.toml"))
    end
    return DYNAMIC_DFVB_FULL_MODEL_CACHE[]
end

function _dynamic_dfvb_full_reaction_map()
    if DYNAMIC_DFVB_FULL_REACTION_MAP_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        DYNAMIC_DFVB_FULL_REACTION_MAP_CACHE[] = load_reaction_map(joinpath(project_root, "config", "reaction_map_full.example.toml"))
    end
    return DYNAMIC_DFVB_FULL_REACTION_MAP_CACHE[]
end

function _dynamic_dfvb_weighted_objective(model::MetabolicModel, result::StaticDFVBResult)
    weights = result.metadata["objective_weights"]
    return sum(weight * result.fluxes[reaction_index(model, rxn_id)] for (rxn_id, weight) in weights)
end

function _dynamic_dfvb_turnover_state()
    return ZentenoState(
        0.5,
        0.0,
        110.0,
        110.0,
        0.0,
        0.0,
        0.23,
        0.185,
        zeros(5),
        zeros(6),
    )
end

@testset "Synthetic weighted DFVB LP objective" begin
    model = MetabolicModel(
        sparse([1.0 -1.0 0.0]),
        [0.0, 0.0, 0.0],
        [10.0, 10.0, 5.0],
        ["r_1", "r_2", "r_3"],
        ["m_1"];
        model_id = "synthetic_dynamic_dfvb_model",
    )
    artifacts = _synthetic_dynamic_dfvb_artifacts()
    result = solve_static_dfvb(
        model,
        artifacts;
        objective_weights = Dict("r_2" => 2.0, "r_3" => 1.0),
        use_active_alpha = true,
    )

    @test result.status == DynamicDFVBMOI.OPTIMAL
    @test result.objective_rxn_id === nothing
    @test result.objective_reaction_index === nothing
    @test result.alpha ≈ [10.0, 5.0] atol = 1.0e-8
    @test result.fluxes ≈ [10.0, 10.0, 5.0] atol = 1.0e-8
    @test result.objective_value ≈ 25.0 atol = 1.0e-8
    @test result.objective_value ≈ _dynamic_dfvb_weighted_objective(model, result) atol = 1.0e-8
    @test result.metadata["objective_type"] == "weighted"
    @test result.metadata["objective_description"] == "weighted"
    @test result.metadata["n_objective_terms"] == 2
    @test result.metadata["objective_value_is_not_biomass_flux"] == true
end

@testset "Real growth-mode dynamic DFVB LP smoke" begin
    model = _dynamic_dfvb_full_model()
    reaction_map = _dynamic_dfvb_full_reaction_map()
    artifacts = _dynamic_dfvb_real_artifacts()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)
    state = default_zenteno_initial_state()
    bounds = zenteno_dynamic_bounds(model, reaction_map, state)

    @test bounds.mode == :growth
    @test bounds.objective_weights["r_2111"] == 1.0
    for rxn_id in ("r_1903", "r_1897", "r_1914", "r_1902", "r_1913")
        @test bounds.objective_weights[rxn_id] == -1.0
    end

    result = solve_dynamic_dfvb_lp(
        model,
        reaction_map,
        artifacts,
        zenteno_state_to_vector(state);
        use_active_alpha = true,
    )
    biomass_flux = result.fluxes[reaction_index(model, "r_2111")]
    oxygen_flux = result.fluxes[reaction_index(model, "r_1992")]

    @test result.status == DynamicDFVBMOI.OPTIMAL
    @test result.metadata["problem_type"] == "dynamic_dfvb_lp"
    @test result.metadata["dynamic_mode"] == "growth"
    @test result.metadata["objective_type"] == "weighted"
    @test result.metadata["n_objective_terms"] > 1
    @test result.metadata["dynamic_objective_term_count"] == length(bounds.objective_weights)
    @test result.metadata["objective_weights"] == bounds.objective_weights
    @test result.metadata["objective_value_is_not_biomass_flux"] == true
    @test result.objective_value ≈ _dynamic_dfvb_weighted_objective(model, result) rtol = 1.0e-7 atol = 1.0e-8
    @test biomass_flux > 0.0
    @test !isapprox(result.objective_value, biomass_flux; rtol = 1.0e-8, atol = 1.0e-8)
    @test oxygen_flux ≈ 0.0 atol = 1.0e-7
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test result.metadata["indices_reacciones_used"] == false
    @test result.mass_balance_residual <= 1.0e-6
    @test result.max_lower_bound_violation <= 1.0e-6
    @test result.max_upper_bound_violation <= 1.0e-6
    @test model.lb == original_lb
    @test model.ub == original_ub
end

@testset "Real turnover-mode dynamic DFVB LP smoke" begin
    model = _dynamic_dfvb_full_model()
    reaction_map = _dynamic_dfvb_full_reaction_map()
    artifacts = _dynamic_dfvb_real_artifacts()
    state = _dynamic_dfvb_turnover_state()
    bounds = zenteno_dynamic_bounds(model, reaction_map, state)

    @test bounds.mode == :turnover
    @test bounds.objective_weights["r_4046"] == 1.0
    @test bounds.objective_weights["r_4047"] == 1.0

    result = solve_dynamic_dfvb_lp(
        model,
        reaction_map,
        artifacts,
        zenteno_state_to_vector(state);
        use_active_alpha = true,
    )
    flux(rxn_id) = result.fluxes[reaction_index(model, rxn_id)]

    @test result.status == DynamicDFVBMOI.OPTIMAL
    @test result.metadata["dynamic_mode"] == "turnover"
    @test result.metadata["objective_type"] == "weighted"
    @test result.metadata["objective_weights"]["r_4046"] == 1.0
    @test result.metadata["objective_weights"]["r_4047"] == 1.0
    @test flux("r_2111") ≈ 0.0 atol = 1.0e-8
    @test result.objective_value ≈ _dynamic_dfvb_weighted_objective(model, result) rtol = 1.0e-7 atol = 1.0e-8
    @test result.objective_value ≈ flux("r_4046") + flux("r_4047") rtol = 1.0e-7 atol = 1.0e-8
    @test flux("r_1992") ≈ 0.0 atol = 1.0e-7
    @test result.mass_balance_residual <= 1.0e-6
    @test result.max_lower_bound_violation <= 1.0e-6
    @test result.max_upper_bound_violation <= 1.0e-6
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test result.metadata["indices_reacciones_used"] == false
end

@testset "Dynamic DFVB bound metadata compatibility" begin
    model = _dynamic_dfvb_full_model()
    reaction_map = _dynamic_dfvb_full_reaction_map()
    artifacts = _dynamic_dfvb_real_artifacts()
    result = solve_dynamic_dfvb_lp(
        model,
        reaction_map,
        artifacts,
        zenteno_state_to_vector(default_zenteno_initial_state());
        use_active_alpha = true,
    )

    @test result.metadata["use_dynamic_bounds"] == true
    @test result.metadata["dynamic_lb_update_count"] > 0
    @test result.metadata["dynamic_ub_update_count"] > 0
    @test result.metadata["dynamic_objective_term_count"] > 0
    @test "r_1714" in result.metadata["dynamic_lb_update_reaction_ids"]
    @test "r_1709" in result.metadata["dynamic_lb_update_reaction_ids"]
    @test "r_1761" in result.metadata["dynamic_ub_update_reaction_ids"]
    @test "r_2111" in result.metadata["dynamic_objective_reaction_ids"]
    @test result.metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test result.metadata["dfvb_rhs_implemented"] == false
    @test result.metadata["kkt_mpcc_collocation_implemented"] == false
end
