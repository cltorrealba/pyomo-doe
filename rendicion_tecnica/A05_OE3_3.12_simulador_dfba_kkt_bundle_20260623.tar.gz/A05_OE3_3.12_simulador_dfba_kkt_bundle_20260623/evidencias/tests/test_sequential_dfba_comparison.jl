import CSV
import TOML
using DataFrames

const SEQ_DFBA_TEST_SUMMARY_COLUMNS = [
    "model_scope",
    "model_id",
    "retcode",
    "termination_reason",
    "initial_time",
    "final_time",
    "n_saved_points",
    "n_states",
    "n_fluxes",
    "initial_biomass",
    "final_biomass",
    "initial_glucose",
    "final_glucose",
    "initial_fructose",
    "final_fructose",
    "initial_total_sugar",
    "final_total_sugar",
    "sugar_consumed",
    "initial_ethanol",
    "final_ethanol",
    "ethanol_produced",
    "final_oxygen",
    "mode_count_growth",
    "mode_count_turnover",
    "mode_count_sugar_depleted",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "min_state_value",
    "has_negative_saved_states",
    "simulation_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
    "reconstruct_fluxes",
    "oxygen_derivative_policy",
    "carbohydrate_derivative_policy",
]

const SEQ_DFBA_TEST_STATE_METRIC_COLUMNS = [
    "state_name",
    "initial_reduced",
    "initial_full",
    "final_reduced",
    "final_full",
    "final_difference_full_minus_reduced",
    "max_abs_difference",
    "rmse",
    "relative_rmse",
    "reduced_min",
    "reduced_max",
    "full_min",
    "full_max",
    "notes",
]

const SEQ_DFBA_TEST_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

const SEQ_DFBA_REAL_COMPARISON_CACHE = Ref{Any}(nothing)

function _synthetic_sequential_dfba_result(model_scope::AbstractString, states::Matrix{Float64})
    return SimulationResult(
        [0.0, 0.25, 0.5],
        states;
        fluxes = nothing,
        metadata = Dict{String, Any}(
            "model_scope" => String(model_scope),
            "state_names" => copy(SEQ_DFBA_TEST_STATE_NAMES),
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "termination_time" => 0.5,
            "algorithm" => "SyntheticAlgorithm",
            "mode_history" => Symbol[],
            "mass_balance_residuals" => Float64[],
            "max_lower_bound_violations" => Float64[],
            "max_upper_bound_violations" => Float64[],
            "min_state_value" => minimum(states),
            "has_negative_saved_states" => any(states .< 0.0),
            "oxygen_derivative_policy" => String(model_scope) == "full" ?
                "forced_zero_present_r_1992_closed_by_bounds" :
                "forced_zero_absent_r_1992",
            "carbohydrate_derivative_policy" => "empirical_not_r_4048",
            "simulation_elapsed_seconds" => String(model_scope) == "full" ? 2.0 : 1.0,
            "rhs_call_count" => String(model_scope) == "full" ? 20 : 8,
            "total_lp_solve_count" => String(model_scope) == "full" ? 20 : 8,
            "reconstruct_fluxes" => false,
            "sugar_depletion_tol" => 1.0e-6,
        ),
    )
end

function _synthetic_sequential_dfba_comparison()
    reduced_states = zeros(19, 3)
    full_states = zeros(19, 3)
    reduced_states[1, :] .= [1.0, 2.0, 3.0]
    full_states[1, :] .= [1.0, 2.5, 4.0]
    reduced_states[2, :] .= [0.1, 0.08, 0.06]
    full_states[2, :] .= [0.1, 0.07, 0.05]
    reduced_states[3, :] .= [10.0, 8.0, 6.0]
    full_states[3, :] .= [10.0, 7.5, 5.0]
    reduced_states[4, :] .= [9.0, 7.0, 5.0]
    full_states[4, :] .= [9.0, 6.8, 4.5]
    reduced_states[5, :] .= [0.0, 1.0, 2.0]
    full_states[5, :] .= [0.0, 1.2, 2.5]
    reduced_states[6, :] .= 0.0
    full_states[6, :] .= 0.0
    reduced_states[7, :] .= [0.2, 0.21, 0.22]
    full_states[7, :] .= [0.2, 0.215, 0.23]
    reduced_states[8, :] .= [0.1, 0.12, 0.13]
    full_states[8, :] .= [0.1, 0.13, 0.15]
    reduced_states[9:19, :] .= 0.01
    full_states[9:19, :] .= 0.012

    reduced = _synthetic_sequential_dfba_result("reduced", reduced_states)
    full = _synthetic_sequential_dfba_result("full", full_states)
    return FermentationDFBA._sequential_dfba_comparison_from_results(
        reduced,
        full;
        reduced_model_id = "synthetic_reduced_seq_dfba",
        full_model_id = "synthetic_full_seq_dfba",
        tspan = (0.0, 0.5),
        saveat = 0.25,
        algorithm_label = "SyntheticAlgorithm",
        ode_abstol = 1.0e-8,
        ode_reltol = 1.0e-8,
        lp_atol = 1.0e-8,
        reconstruct_fluxes = false,
    )
end

function _real_sequential_dfba_comparison()
    if SEQ_DFBA_REAL_COMPARISON_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        reduced_model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        full_model = load_full_model(joinpath(project_root, "config", "full_model_paths.example.toml"))
        reduced_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        full_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_full.example.toml"))
        SEQ_DFBA_REAL_COMPARISON_CACHE[] = compare_sequential_dfba_full_reduced(
            reduced_model,
            reduced_map,
            full_model,
            full_map;
            tspan = (0.0, 0.25),
            saveat = 0.25,
            reconstruct_fluxes = false,
        )
    end
    return SEQ_DFBA_REAL_COMPARISON_CACHE[]
end

function _seq_dfba_test_state_row(table::DataFrame, state_name::AbstractString)
    row_index = findfirst(==(String(state_name)), String.(table[!, "state_name"]))
    row_index === nothing && error("Missing state metrics row $(String(state_name)).")
    return table[row_index, :]
end

@testset "Synthetic sequential DFBA comparison tables" begin
    comparison = _synthetic_sequential_dfba_comparison()

    @test comparison isa SequentialDFBAComparisonResult
    @test names(comparison.summary_table) == SEQ_DFBA_TEST_SUMMARY_COLUMNS
    @test names(comparison.state_metrics_table) == SEQ_DFBA_TEST_STATE_METRIC_COLUMNS
    @test nrow(comparison.summary_table) == 2
    @test nrow(comparison.state_metrics_table) == 19
    @test nrow(comparison.state_timeseries_table) == 3
    @test "biomass_reduced" in names(comparison.state_timeseries_table)
    @test "biomass_full" in names(comparison.state_timeseries_table)
    @test "biomass_difference_full_minus_reduced" in names(comparison.state_timeseries_table)

    biomass = _seq_dfba_test_state_row(comparison.state_metrics_table, "biomass")
    expected_rmse = sqrt((0.0^2 + 0.5^2 + 1.0^2) / 3)
    @test isapprox(biomass["final_difference_full_minus_reduced"], 1.0; atol = 1.0e-12)
    @test isapprox(biomass["max_abs_difference"], 1.0; atol = 1.0e-12)
    @test isapprox(biomass["rmse"], expected_rmse; atol = 1.0e-12)
    @test isapprox(biomass["relative_rmse"], expected_rmse / 4.0; atol = 1.0e-12)

    oxygen = _seq_dfba_test_state_row(comparison.state_metrics_table, "oxygen")
    @test oxygen["rmse"] == 0.0
    @test oxygen["relative_rmse"] == 0.0
    @test occursin("r_1992", oxygen["notes"])

    carbohydrate = _seq_dfba_test_state_row(comparison.state_metrics_table, "carbohydrate")
    @test occursin("not driven by r_4048", carbohydrate["notes"])

    @test comparison.metadata["comparison_type"] == "sequential_dfba_full_vs_reduced"
    @test comparison.metadata["flux_comparison_included"] == false
    @test comparison.metadata["indices_reacciones_used"] == false
    @test comparison.metadata["r0001_used_as_oxygen"] == false
    @test comparison.metadata["runtime_policy_label"] == "default_short"
    @test comparison.metadata["runtime_policy_hard_tfinal_hours"] == 72.0
    @test comparison.metadata["runtime_policy_allow_long_full"] == false
    @test comparison.metadata["runtime_policy_allow_dense_output"] == false
    @test comparison.metadata["runtime_policy_long_full_run_requested"] == false
    @test comparison.metadata["estimated_saved_points"] == 3
end

@testset "Sequential DFBA comparison runtime guardrails" begin
    policy = SequentialDFBARuntimePolicy()
    short_report = FermentationDFBA._sequential_dfba_runtime_policy_report(
        (0.0, 0.25),
        0.25,
        false,
        policy,
    )
    @test short_report.runtime_policy_label == "default_short"
    @test short_report.requested_duration_hours == 0.25
    @test short_report.estimated_saved_points == 2
    @test short_report.long_full_run_requested == false

    @test_throws ErrorException FermentationDFBA._sequential_dfba_runtime_policy_report(
        (0.0, 72.0),
        1.0,
        false,
        policy,
    )
    @test_throws ErrorException FermentationDFBA._sequential_dfba_runtime_policy_report(
        (0.0, 72.25),
        1.0,
        false,
        SequentialDFBARuntimePolicy(allow_long_full = true),
    )

    long_policy = SequentialDFBARuntimePolicy(allow_long_full = true)
    long_report = FermentationDFBA._sequential_dfba_runtime_policy_report(
        (0.0, 72.0),
        1.0,
        false,
        long_policy,
    )
    @test long_report.runtime_policy_label == "long_opt_in"
    @test long_report.requested_duration_hours == 72.0
    @test long_report.estimated_saved_points == 73
    @test long_report.long_full_run_requested == true
    @test long_report.dense_output_requested == false

    @test_throws ErrorException FermentationDFBA._sequential_dfba_runtime_policy_report(
        (0.0, 72.0),
        0.1,
        false,
        long_policy,
    )

    dense_policy = SequentialDFBARuntimePolicy(allow_long_full = true, allow_dense_output = true)
    dense_report = FermentationDFBA._sequential_dfba_runtime_policy_report(
        (0.0, 72.0),
        0.1,
        true,
        dense_policy,
    )
    @test dense_report.long_full_run_requested == true
    @test dense_report.dense_output_requested == true
    @test dense_report.flux_reconstruction_long_run_requested == true
    @test dense_report.estimated_saved_points > dense_policy.max_saved_points

    @test_throws ErrorException SequentialDFBARuntimePolicy(manual_tfinal_hours = 0.1)
    @test_throws ErrorException SequentialDFBARuntimePolicy(hard_tfinal_hours = 1.0)
    @test_throws ErrorException SequentialDFBARuntimePolicy(min_saveat_hours = 0.0)
end

@testset "Real full-vs-reduced sequential DFBA comparison smoke" begin
    comparison = _real_sequential_dfba_comparison()

    @test comparison isa SequentialDFBAComparisonResult
    @test comparison.reduced_result.metadata["retcode"] == "Success"
    @test comparison.full_result.metadata["retcode"] == "Success"
    @test comparison.reduced_result.metadata["model_scope"] == "reduced"
    @test comparison.full_result.metadata["model_scope"] == "full"
    @test comparison.reduced_result.time == comparison.full_result.time
    @test nrow(comparison.state_metrics_table) == 19

    for column in (
        "biomass_reduced",
        "biomass_full",
        "biomass_difference_full_minus_reduced",
        "glucose_reduced",
        "fructose_full",
        "ethanol_difference_full_minus_reduced",
        "oxygen_reduced",
        "oxygen_full",
    )
        @test column in names(comparison.state_timeseries_table)
    end

    @test all(isapprox(value, 0.0; atol = 1.0e-9) for value in comparison.reduced_result.states[6, :])
    @test all(isapprox(value, 0.0; atol = 1.0e-9) for value in comparison.full_result.states[6, :])
    @test comparison.metadata["flux_comparison_included"] == false
    @test comparison.metadata["indices_reacciones_used"] == false
    @test comparison.metadata["r0001_used_as_oxygen"] == false
    @test occursin("r_1992", comparison.metadata["oxygen_mapping_note"])
    @test occursin("r_4048", comparison.metadata["carbohydrate_mapping_note"])
    @test comparison.metadata["reconstruct_fluxes"] == false
    @test comparison.metadata["runtime_policy_label"] == "default_short"
    @test comparison.metadata["runtime_policy_hard_tfinal_hours"] == 72.0
    @test comparison.metadata["runtime_policy_long_full_run_requested"] == false
end

@testset "Sequential DFBA comparison export" begin
    comparison = _synthetic_sequential_dfba_comparison()

    mktempdir() do dir
        paths = export_sequential_dfba_comparison(comparison, dir)

        @test isfile(paths["summary"])
        @test isfile(paths["state_metrics"])
        @test isfile(paths["state_timeseries"])
        @test isfile(paths["metadata"])

        summary = DataFrame(CSV.File(paths["summary"]))
        state_metrics = DataFrame(CSV.File(paths["state_metrics"]))
        state_timeseries = DataFrame(CSV.File(paths["state_timeseries"]))
        metadata = TOML.parsefile(paths["metadata"])

        @test names(summary) == SEQ_DFBA_TEST_SUMMARY_COLUMNS
        @test names(state_metrics) == SEQ_DFBA_TEST_STATE_METRIC_COLUMNS
        @test "time" in names(state_timeseries)
        @test "ethanol_difference_full_minus_reduced" in names(state_timeseries)
        @test metadata["comparison_type"] == "sequential_dfba_full_vs_reduced"
        @test metadata["flux_comparison_included"] == false
        @test metadata["reconstruct_fluxes"] == false
        @test metadata["runtime_policy_hard_tfinal_hours"] == 72.0
        @test metadata["runtime_policy_allow_long_full"] == false
        @test metadata["runtime_policy_long_full_run_requested"] == false
    end
end

@testset "Sequential DFBA comparison SVG plots" begin
    comparison = _synthetic_sequential_dfba_comparison()

    mktempdir() do dir
        paths = write_sequential_dfba_comparison_plots(comparison, dir)

        for key in ("core_states", "state_rmse", "runtime_counters")
            @test haskey(paths, key)
            @test isfile(paths[key])
            @test occursin("<svg", read(paths[key], String))
        end
        @test occursin("biomass", read(paths["core_states"], String))
        @test occursin("relative RMSE", read(paths["state_rmse"], String))
        @test occursin("total_lp_solve_count", read(paths["runtime_counters"], String))
    end
end

@testset "Sequential DFBA comparison overwrite behavior" begin
    comparison = _synthetic_sequential_dfba_comparison()

    mktempdir() do dir
        export_sequential_dfba_comparison(comparison, dir)
        @test_throws ErrorException export_sequential_dfba_comparison(comparison, dir)
        export_paths = export_sequential_dfba_comparison(comparison, dir; overwrite = true)
        @test isfile(export_paths["summary"])

        plot_dir = joinpath(dir, "plots")
        write_sequential_dfba_comparison_plots(comparison, plot_dir)
        @test_throws ErrorException write_sequential_dfba_comparison_plots(comparison, plot_dir)
        plot_paths = write_sequential_dfba_comparison_plots(comparison, plot_dir; overwrite = true)
        @test isfile(plot_paths["core_states"])
    end
end
