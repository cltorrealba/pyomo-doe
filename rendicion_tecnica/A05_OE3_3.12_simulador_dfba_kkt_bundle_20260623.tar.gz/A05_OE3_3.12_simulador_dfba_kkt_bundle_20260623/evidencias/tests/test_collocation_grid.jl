@testset "Radau degree-3 collocation scheme" begin
    scheme = radau_collocation_scheme()

    @test scheme isa RadauCollocationScheme
    @test scheme.degree == 3
    @test length(scheme.nodes) == 3
    @test length(scheme.weights) == 3
    @test size(scheme.integration_matrix) == (3, 3)
    @test size(scheme.differentiation_matrix) == (3, 4)
    @test scheme.support_nodes == [0.0; scheme.nodes]
    @test all(isfinite, scheme.nodes)
    @test all(node -> 0.0 <= node <= 1.0, scheme.nodes)
    @test isapprox(scheme.nodes[end], 1.0; atol = 10 * eps(Float64), rtol = 0.0)
    @test isapprox(sum(scheme.weights), 1.0; atol = 100 * eps(Float64), rtol = 0.0)
    @test isapprox(scheme.continuity_weights, scheme.weights; atol = 100 * eps(Float64), rtol = 0.0)
    @test isapprox(
        scheme.integration_matrix[end, :],
        scheme.weights;
        atol = 100 * eps(Float64),
        rtol = 0.0,
    )
end

@testset "Radau degree-3 antecedent coefficients" begin
    scheme = radau_collocation_scheme(3)
    expected_nodes = [
        (4.0 - sqrt(6.0)) / 10.0,
        (4.0 + sqrt(6.0)) / 10.0,
        1.0,
    ]
    expected_weights = [
        (16.0 - sqrt(6.0)) / 36.0,
        (16.0 + sqrt(6.0)) / 36.0,
        1.0 / 9.0,
    ]
    expected_colmat = [
        0.19681547722366 -0.06553542585020 0.02377097434822
        0.39442431473909 0.29207341166523 -0.04154875212600
        0.37640306270047 0.51248582618842 0.11111111111111
    ]

    @test isapprox(scheme.nodes, expected_nodes; atol = 10 * eps(Float64), rtol = 0.0)
    @test isapprox(scheme.weights, expected_weights; atol = 10 * eps(Float64), rtol = 0.0)
    @test isapprox(scheme.integration_matrix, expected_colmat; atol = 1.0e-10, rtol = 0.0)
end

@testset "Radau degree-3 quadrature exactness" begin
    scheme = radau_collocation_scheme()

    for power in 0:4
        quadrature_value = sum(
            scheme.weights[index] * scheme.nodes[index]^power for
            index in eachindex(scheme.nodes)
        )
        @test isapprox(quadrature_value, 1.0 / (power + 1); atol = 1.0e-14, rtol = 0.0)
    end
end

@testset "Radau integration matrix polynomial identities" begin
    scheme = radau_collocation_scheme()

    for power in 0:3
        initial_value = power == 0 ? 1.0 : 0.0
        for node_index in eachindex(scheme.nodes)
            node = scheme.nodes[node_index]
            polynomial_increment = node^power - initial_value
            derivative_integral = sum(
                scheme.integration_matrix[node_index, basis_index] *
                (power == 0 ? 0.0 : power * scheme.nodes[basis_index]^(power - 1)) for
                basis_index in eachindex(scheme.nodes)
            )
            @test isapprox(polynomial_increment, derivative_integral; atol = 1.0e-14, rtol = 0.0)
        end
    end
end

@testset "Radau differentiation matrix polynomial identities" begin
    scheme = radau_collocation_scheme()

    for power in 0:3
        support_values = scheme.support_nodes .^ power
        for node_index in eachindex(scheme.nodes)
            expected_derivative = power == 0 ? 0.0 : power * scheme.nodes[node_index]^(power - 1)
            computed_derivative = sum(
                scheme.differentiation_matrix[node_index, support_index] *
                support_values[support_index] for support_index in eachindex(scheme.support_nodes)
            )
            @test isapprox(expected_derivative, computed_derivative; atol = 1.0e-13, rtol = 0.0)
        end
    end
end

@testset "Uniform finite-element collocation grid" begin
    grid = build_finite_element_grid((0.0, 2.0); nfe = 4, degree = 3)

    @test grid isa FiniteElementGrid
    @test grid.tspan == (0.0, 2.0)
    @test grid.nfe == 4
    @test length(grid.element_bounds) == 4
    @test grid.element_bounds[begin] == (0.0, 0.5)
    @test grid.element_bounds[end] == (1.5, 2.0)
    @test size(grid.collocation_times) == (4, 3)

    for element_index in 1:(grid.nfe - 1)
        @test grid.element_bounds[element_index][2] == grid.element_bounds[element_index + 1][1]
    end
    @test sum(element_length(grid, element_index) for element_index in 1:grid.nfe) == 2.0

    for element_index in 1:grid.nfe
        left, right = element_bounds(grid, element_index)
        element_width = right - left
        for collocation_index in 1:grid.scheme.degree
            expected_time = left + grid.scheme.nodes[collocation_index] * element_width
            @test isapprox(
                grid.collocation_times[element_index, collocation_index],
                expected_time;
                atol = 10 * eps(Float64),
                rtol = 0.0,
            )
            @test collocation_time(grid, element_index, collocation_index) ==
                grid.collocation_times[element_index, collocation_index]
        end
    end

    alias_grid = build_collocation_grid((0.0, 2.0); nfe = 4)
    @test alias_grid.collocation_times == grid.collocation_times
end

@testset "Collocation grid input validation" begin
    @test_throws ArgumentError radau_collocation_scheme(2)
    @test_throws ArgumentError radau_collocation_scheme(4)
    @test_throws ArgumentError build_finite_element_grid((1.0, 1.0); nfe = 1)
    @test_throws ArgumentError build_finite_element_grid((1.0, 0.0); nfe = 1)
    @test_throws ArgumentError build_finite_element_grid((0.0, 1.0); nfe = 0)
    @test_throws ArgumentError build_finite_element_grid((0.0, Inf); nfe = 1)
    @test_throws ArgumentError build_finite_element_grid((NaN, 1.0); nfe = 1)

    grid = build_finite_element_grid((0.0, 1.0); nfe = 2)
    @test_throws ArgumentError collocation_time(grid, 0, 1)
    @test_throws ArgumentError collocation_time(grid, 3, 1)
    @test_throws ArgumentError collocation_time(grid, 1, 0)
    @test_throws ArgumentError collocation_time(grid, 1, 4)
    @test_throws ArgumentError element_bounds(grid, 0)
    @test_throws ArgumentError element_length(grid, 3)
end
