import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_mpcc_candidate_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_mpcc_candidate_test_simulation()
    time = [0.0, 0.25]
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    states = hcat(initial_state, initial_state)
    fluxes = reshape([0.02, 0.02], 1, 2)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

function _reduced_dcdfba_mpcc_candidate_test_problem()
    model, reaction_map = _reduced_dcdfba_mpcc_candidate_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_candidate_test_simulation()
    return build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
end

function _reduced_dcdfba_mpcc_candidate_test_start_values(problem)
    smoke = problem.smoke_problem
    return (
        state_boundary = Float64.(JuMP.start_value.(smoke.nlp.state_boundary)),
        state_collocation = Float64.(JuMP.start_value.(smoke.nlp.state_collocation)),
        state_derivative = Float64.(JuMP.start_value.(smoke.nlp.state_derivative)),
        flux = Float64.(JuMP.start_value.(smoke.nlp.flux)),
        lower_bound_duals = Float64.(JuMP.start_value.(smoke.bound_feasibility.lower_bound_duals)),
        upper_bound_duals = Float64.(JuMP.start_value.(smoke.bound_feasibility.upper_bound_duals)),
        mass_balance_duals = Float64.(JuMP.start_value.(smoke.stationarity.mass_balance_duals)),
    )
end

function _reduced_dcdfba_mpcc_candidate_test_smoke_result(
    status::MOI.TerminationStatusCode,
    primal_status::MOI.ResultStatusCode,
)
    return ReducedDCDFBAMPCCSmokeResult(
        status,
        primal_status,
        NaN,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        "Ipopt",
        0.0,
        Dict{String, Any}(),
    )
end

@testset "Reduced DC-dFBA MPCC candidate diagnostics from values" begin
    problem = _reduced_dcdfba_mpcc_candidate_test_problem()
    values = _reduced_dcdfba_mpcc_candidate_test_start_values(problem)
    smoke_result = _reduced_dcdfba_mpcc_candidate_test_smoke_result(
        MOI.ITERATION_LIMIT,
        MOI.NEARLY_FEASIBLE_POINT,
    )

    candidate = FermentationDFBA._reduced_dcdfba_mpcc_candidate_diagnostics_from_values(
        problem.smoke_problem,
        smoke_result,
        problem.residual_thresholds,
        values,
        "unit_test_start_values",
    )

    @test candidate isa ReducedDCDFBAMPCCCandidateDiagnostics
    @test size(candidate.state_boundary) == size(problem.smoke_problem.nlp.state_boundary)
    @test size(candidate.state_collocation) == size(problem.smoke_problem.nlp.state_collocation)
    @test size(candidate.state_derivative) == size(problem.smoke_problem.nlp.state_derivative)
    @test size(candidate.flux) == size(problem.smoke_problem.nlp.flux)
    @test size(candidate.lower_bound_duals) == size(problem.smoke_problem.bound_feasibility.lower_bound_duals)
    @test size(candidate.upper_bound_duals) == size(problem.smoke_problem.bound_feasibility.upper_bound_duals)
    @test size(candidate.mass_balance_duals) == size(problem.smoke_problem.stationarity.mass_balance_duals)

    @test candidate.metadata["candidate_extraction_performed"] == true
    @test candidate.metadata["candidate_values_available"] == true
    @test candidate.metadata["candidate_values_source"] == "unit_test_start_values"
    @test candidate.metadata["candidate_is_scientific_simulation"] == false
    @test candidate.metadata["candidate_is_validated_trajectory"] == false
    @test candidate.metadata["solved_trajectory_claimed"] == false
    @test candidate.metadata["model_scope"] == "reduced"
    @test candidate.metadata["first_mpcc_target"] == "reduced_dfba"
    @test candidate.metadata["full_model_kkt_deferred"] == true
    @test candidate.metadata["dfvb_kkt_deferred"] == true
    @test candidate.metadata["hsl_required"] == false
    @test candidate.metadata["ma57_required"] == false
    @test candidate.metadata["indices_reacciones_used"] == false
    @test candidate.metadata["r0001_used_as_oxygen"] == false

    @test candidate.metadata["candidate_residuals_available"] == true
    @test candidate.metadata["candidate_residual_thresholds_satisfied"] == true
    @test candidate.metadata["candidate_residual_feasible"] == true
    @test candidate.metadata["candidate_status_allows_trajectory_candidate"] == false
    @test candidate.metadata["candidate_primal_status_allows_residual_candidate"] == true
    @test candidate.metadata["candidate_trajectory_extraction_ready"] == false
    @test candidate.metadata["candidate_iteration_limit_residual_feasible"] == true
    @test "candidate_iteration_limit_residual_feasible" in candidate.warnings
    @test "candidate_solver_status_blocks_trajectory_extraction" in candidate.warnings

    @test isfinite(candidate.residual_values["max_rhs_residual"])
    @test candidate.residual_values["max_rhs_residual"] <= candidate.residual_thresholds["max_rhs_residual"]
    @test candidate.residual_values["max_mass_balance_residual"] <=
          candidate.residual_thresholds["max_mass_balance_residual"]
    @test candidate.metadata["candidate_flux_bound_check_performed"] == true
    @test candidate.metadata["candidate_flux_lower_bound_violation_count"] == 0
    @test candidate.metadata["candidate_flux_upper_bound_violation_count"] == 0
    @test candidate.metadata["candidate_lower_bound_dual_positive_count"] == 0
    @test candidate.metadata["candidate_upper_bound_dual_negative_count"] == 0
    @test candidate.metadata["candidate_state_collocation_nonfinite_count"] == 0
    @test candidate.metadata["candidate_flux_nonfinite_count"] == 0
    @test candidate.metadata["candidate_max_collocation_integration_residual"] <= 1.0e-6
    @test candidate.metadata["candidate_max_continuity_residual"] <= 1.0e-6
    @test candidate.metadata["candidate_max_initial_condition_residual"] <= 1.0e-8

    bounds = FermentationDFBA._reduced_dcdfba_numeric_flux_bounds(
        problem.smoke_problem,
        1,
        1,
        values.state_collocation,
    )
    upper_violation_reaction_index = findfirst(isfinite, bounds.ub)
    @test upper_violation_reaction_index !== nothing
    violating_flux = copy(values.flux)
    violating_flux[upper_violation_reaction_index, 1, 1] =
        Float64(bounds.ub[upper_violation_reaction_index]) + 0.25
    violating_derivatives = copy(values.state_derivative)
    rhs_state_index = size(violating_derivatives, 1)
    violating_derivatives[rhs_state_index, 1, 1] += 10.0
    violating_values = (
        state_boundary = copy(values.state_boundary),
        state_collocation = copy(values.state_collocation),
        state_derivative = violating_derivatives,
        flux = violating_flux,
        lower_bound_duals = copy(values.lower_bound_duals),
        upper_bound_duals = copy(values.upper_bound_duals),
        mass_balance_duals = copy(values.mass_balance_duals),
    )
    violating_candidate =
        FermentationDFBA._reduced_dcdfba_mpcc_candidate_diagnostics_from_values(
            problem.smoke_problem,
            smoke_result,
            problem.residual_thresholds,
            violating_values,
            "unit_test_violating_values",
        )
    bound_rows = reduced_dcdfba_mpcc_bound_violation_location_rows(
        problem.smoke_problem,
        violating_candidate;
        top_n = 3,
    )
    @test !isempty(bound_rows)
    @test bound_rows[1]["residual_type"] == "upper_bound_violation"
    @test bound_rows[1]["reaction_index"] == upper_violation_reaction_index
    @test isapprox(bound_rows[1]["violation"], 0.25; atol = 1.0e-10)

    rhs_rows = reduced_dcdfba_mpcc_rhs_residual_location_rows(
        problem.smoke_problem,
        violating_candidate;
        top_n = 3,
    )
    @test !isempty(rhs_rows)
    @test rhs_rows[1]["residual_type"] == "rhs"
    @test rhs_rows[1]["state_index"] == rhs_state_index
    @test rhs_rows[1]["abs_residual"] >= 9.0
end

@testset "Reduced DC-dFBA MPCC candidate extraction guardrails" begin
    problem = _reduced_dcdfba_mpcc_candidate_test_problem()
    smoke_result = _reduced_dcdfba_mpcc_candidate_test_smoke_result(
        MOI.OPTIMIZE_NOT_CALLED,
        MOI.NO_SOLUTION,
    )

    @test_throws ArgumentError extract_reduced_dcdfba_mpcc_candidate(problem, smoke_result)

    values = _reduced_dcdfba_mpcc_candidate_test_start_values(problem)
    candidate = FermentationDFBA._reduced_dcdfba_mpcc_candidate_diagnostics_from_values(
        problem.smoke_problem,
        smoke_result,
        problem.residual_thresholds,
        values,
        "unit_test_start_values",
    )
    residual_report = Dict{String, Any}(
        "residuals_available" => candidate.metadata["candidate_residuals_available"],
        "residual_thresholds_satisfied" =>
            candidate.metadata["candidate_residual_thresholds_satisfied"],
        "max_rhs_residual" => candidate.residual_values["max_rhs_residual"],
    )
    wrapped = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        problem.residual_thresholds,
        true,
        true,
        residual_report,
        copy(candidate.metadata),
        candidate,
    )
    @test extract_reduced_dcdfba_mpcc_candidate(wrapped) === candidate

    missing_candidate = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        problem.residual_thresholds,
        false,
        false,
        Dict{String, Any}(),
        Dict{String, Any}(),
        nothing,
    )
    @test_throws ArgumentError extract_reduced_dcdfba_mpcc_candidate(missing_candidate)
end

@testset "Reduced DC-dFBA MPCC candidate diagnostics opt-in solve" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_DYNAMIC_SOLVE", "0") == "1"
        model, reaction_map = _reduced_dcdfba_mpcc_candidate_test_model_and_map()
        simulation = _reduced_dcdfba_mpcc_candidate_test_simulation()
        result = solve_reduced_dcdfba_mpcc_solve_attempt(
            model,
            reaction_map;
            sequential_initialization = simulation,
        )

        @test result.candidate_diagnostics !== nothing
        candidate = extract_reduced_dcdfba_mpcc_candidate(result)
        @test candidate.metadata["candidate_values_source"] == "post_solve_values"
        @test candidate.metadata["candidate_is_scientific_simulation"] == false
        @test candidate.metadata["candidate_residuals_available"] == true
        @test candidate.metadata["candidate_trajectory_extraction_ready"] ==
              result.metadata["trajectory_extraction_ready"]
        @test result.metadata["candidate_extraction_performed"] == true
        @test result.metadata["candidate_values_available"] == true
    else
        @info "Skipping reduced MPCC candidate post-solve extraction; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_DYNAMIC_SOLVE=1 to run it."
        @test true
    end
end
