using DataFrames
import MathOptInterface as MOI

function _reduced_mpcc_global_polish_horizon_test_continuation(target_horizon::Float64)
    window_hours = 0.5
    n_windows = round(Int, target_horizon / window_hours)
    @assert isapprox(target_horizon / window_hours, n_windows; atol = 1.0e-12)
    initial = _reduced_mpcc_window_test_initial_state()
    comparisons = ReducedDCDFBAMPCCSequentialComparisonResult[]
    state = initial
    for window_index in 1:n_windows
        t0 = (window_index - 1) * window_hours
        tfinal = window_index * window_hours
        comparison, final_state = _reduced_mpcc_window_test_comparison(
            t0 = t0,
            tfinal = tfinal,
            initial_state = state,
            biomass_offset = 0.0,
            trajectory_ready = true,
            solver_status = "LOCALLY_SOLVED",
        )
        push!(comparisons, comparison)
        state = final_state
    end
    return run_reduced_dcdfba_mpcc_windowed_continuation(comparisons)
end

function _reduced_mpcc_global_polish_horizon_threshold_dict(thresholds)
    return Dict{String, Float64}(
        "max_rhs_residual" => thresholds.max_rhs_residual,
        "max_mass_balance_residual" => thresholds.max_mass_balance_residual,
        "max_lower_bound_violation" => thresholds.max_lower_bound_violation,
        "max_upper_bound_violation" => thresholds.max_upper_bound_violation,
        "max_stationarity_residual" => thresholds.max_stationarity_residual,
        "max_lower_complementarity_residual" =>
            thresholds.max_lower_complementarity_residual,
        "max_upper_complementarity_residual" =>
            thresholds.max_upper_complementarity_residual,
    )
end

function _reduced_mpcc_global_polish_horizon_test_result(;
    target_horizon::Float64,
    trajectory_ready::Bool,
    residual_feasible::Bool = true,
    iteration_limit_residual_feasible::Bool = !trajectory_ready,
    solve_elapsed_seconds::Float64 = target_horizon * 10.0,
    max_state_relative_rmse::Float64 = trajectory_ready ? 0.0 : 2.0e-2,
)
    continuation = _reduced_mpcc_global_polish_horizon_test_continuation(target_horizon)
    starts = build_reduced_dcdfba_mpcc_windowed_start_values(continuation)
    thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
    threshold_values = _reduced_mpcc_global_polish_horizon_threshold_dict(thresholds)
    residuals = Dict{String, Float64}(
        "max_rhs_residual" => residual_feasible ? 1.0e-12 : 1.0,
        "max_mass_balance_residual" => residual_feasible ? 5.0e-7 : 1.0,
        "max_lower_bound_violation" => 0.0,
        "max_upper_bound_violation" => 0.0,
        "max_stationarity_residual" => residual_feasible ? 1.0e-8 : 1.0,
        "max_lower_complementarity_residual" => residual_feasible ? 5.0e-7 : 1.0,
        "max_upper_complementarity_residual" => residual_feasible ? 5.0e-7 : 1.0,
    )
    ratios = Dict(
        key => value / max(threshold_values[key], eps()) for
        (key, value) in residuals
    )
    solver_status = trajectory_ready ? "LOCALLY_SOLVED" : "ITERATION_LIMIT"
    primal_status = trajectory_ready ? "FEASIBLE_POINT" : "NEARLY_FEASIBLE_POINT"
    candidate_metadata = Dict{String, Any}(
        "candidate_solver_status" => solver_status,
        "candidate_primal_status" => primal_status,
        "candidate_residual_thresholds_satisfied" => residual_feasible,
        "candidate_residual_feasible" => residual_feasible,
        "candidate_iteration_limit_residual_feasible" =>
            iteration_limit_residual_feasible,
        "candidate_dominant_residual" => "max_mass_balance_residual",
        "candidate_trajectory_extraction_ready" => trajectory_ready,
        "trajectory_candidate_ready" => trajectory_ready,
        "candidate_values_available" => true,
        "candidate_grid_nfe" => Int(starts.metadata["source_total_nfe"]),
        "candidate_collocation_degree" => Int(starts.metadata["source_collocation_degree"]),
    )
    candidate = ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(starts.state_boundary),
        copy(starts.state_collocation),
        copy(starts.state_derivative),
        copy(starts.flux),
        copy(starts.lower_bound_duals),
        copy(starts.upper_bound_duals),
        copy(starts.mass_balance_duals),
        residuals,
        threshold_values,
        ratios,
        collect(keys(residuals)),
        String[],
        candidate_metadata,
    )
    smoke_result = ReducedDCDFBAMPCCSmokeResult(
        trajectory_ready ? MOI.LOCALLY_SOLVED : MOI.ITERATION_LIMIT,
        trajectory_ready ? MOI.FEASIBLE_POINT : MOI.NEARLY_FEASIBLE_POINT,
        NaN,
        residuals["max_mass_balance_residual"],
        residuals["max_lower_bound_violation"],
        residuals["max_upper_bound_violation"],
        residuals["max_stationarity_residual"],
        residuals["max_lower_complementarity_residual"],
        residuals["max_upper_complementarity_residual"],
        "Ipopt",
        solve_elapsed_seconds,
        Dict{String, Any}(),
    )
    residual_report = Dict{String, Any}(
        "residuals_available" => true,
        "residual_thresholds_satisfied" => residual_feasible,
        "max_rhs_residual" => residuals["max_rhs_residual"],
        "max_mass_balance_residual" => residuals["max_mass_balance_residual"],
        "max_lower_bound_violation" => residuals["max_lower_bound_violation"],
        "max_upper_bound_violation" => residuals["max_upper_bound_violation"],
        "max_stationarity_residual" => residuals["max_stationarity_residual"],
        "max_lower_complementarity_residual" =>
            residuals["max_lower_complementarity_residual"],
        "max_upper_complementarity_residual" =>
            residuals["max_upper_complementarity_residual"],
    )
    solve_metadata = merge(
        Dict{String, Any}(
            "solver_status" => solver_status,
            "primal_status" => primal_status,
            "solve_elapsed_seconds" => solve_elapsed_seconds,
            "pre_solve_guard_required" => false,
            "pre_solve_guard_passed" => true,
            "guarded_solve_attempt_blocked" => false,
            "nlp_structure_audit_built" => true,
            "nlp_structure_total_variables" => 100,
            "nlp_structure_equality_constraints" => 92,
            "nlp_structure_inequality_constraints" => 8,
            "nlp_structure_fixed_variable_count" => 2,
            "nlp_structure_nearly_fixed_variable_count" => 1,
            "nlp_structure_effective_variable_count" => 98,
            "nlp_structure_dof_balance" => 6,
            "nlp_structure_too_few_degrees_of_freedom_risk" => false,
            "nlp_structure_fixed_variable_treatment_hint" => "positive_dof_margin",
        ),
        candidate_metadata,
    )
    solve_attempt = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        thresholds,
        true,
        residual_feasible,
        residual_report,
        solve_metadata,
        candidate,
    )
    start_summary_table = DataFrame(
        "block" => ["state_boundary"],
        "source_size" => [string(size(starts.state_boundary))],
        "target_size" => [string(size(starts.state_boundary))],
        "applied" => [true],
        "finite_value_count" => [length(starts.state_boundary)],
        "total_value_count" => [length(starts.state_boundary)],
        "max_abs_start" => [maximum(abs.(starts.state_boundary))],
    )
    metadata = FermentationDFBA._reduced_mpcc_global_polish_metadata(
        continuation,
        starts,
        solve_attempt,
        nothing,
        nothing,
        start_summary_table,
        true,
    )
    metadata["global_polish_source_kind"] = "cascade"
    metadata["target_horizon"] = target_horizon
    metadata["max_state_relative_rmse"] = max_state_relative_rmse
    metadata["final_total_sugar_difference"] = trajectory_ready ? 0.0 : 0.05
    metadata["cascade_rebuild_applied"] = true
    metadata["cascade_replacement_window_index"] = trajectory_ready ? missing : 1
    metadata["cascade_rebuilt_attempt_traffic_light"] =
        trajectory_ready ? "green" : "yellow"

    return ReducedDCDFBAMPCCGlobalPolishResult(
        continuation,
        starts,
        solve_attempt,
        nothing,
        nothing,
        candidate,
        nothing,
        nothing,
        start_summary_table,
        metadata,
    )
end

@testset "Reduced MPCC global polish horizon sweep aggregation" begin
    green = _reduced_mpcc_global_polish_horizon_test_result(
        target_horizon = 0.5,
        trajectory_ready = true,
    )
    yellow = _reduced_mpcc_global_polish_horizon_test_result(
        target_horizon = 1.0,
        trajectory_ready = false,
    )

    sweep = sweep_reduced_dcdfba_mpcc_global_polish_horizons([green, yellow])
    table = sweep.global_polish_table
    metadata = sweep.metadata

    @test sweep isa ReducedDCDFBAMPCCGlobalPolishHorizonSweepResult
    @test nrow(table) == 2
    @test table[1, "global_polish_case_id"] == "global_polish_horizon_001"
    @test table[2, "global_polish_case_id"] == "global_polish_horizon_002"
    @test table[1, "global_polish_traffic_light"] == "green"
    @test table[2, "global_polish_traffic_light"] == "yellow"
    @test table[1, "is_last_green"] == true
    @test table[2, "is_first_non_green_after_green"] == true
    @test table[1, "global_target_completed"] == true
    @test table[2, "global_target_completed"] == true
    @test table[1, "outputs_written"] == false
    @test table[1, "hsl_required"] == false
    @test table[1, "ma57_required"] == false
    @test table[1, "indices_reacciones_used"] == false
    @test table[1, "r0001_used_as_oxygen"] == false
    @test table[1, "nlp_structure_total_variables"] == 100
    @test table[1, "nlp_structure_effective_variable_count"] == 98
    @test table[1, "nlp_structure_dof_balance"] == 6
    @test table[1, "nlp_structure_too_few_degrees_of_freedom_risk"] == false

    @test metadata["sweep_type"] ==
          "reduced_dcdfba_mpcc_global_polish_horizon_sweep"
    @test metadata["n_requested_cases"] == 2
    @test metadata["green_count"] == 1
    @test metadata["yellow_count"] == 1
    @test metadata["red_count"] == 0
    @test metadata["global_polish_viable_count"] == 1
    @test metadata["target_completed_count"] == 2
    @test metadata["nlp_structure_dof_risk_count"] == 0
    @test metadata["nlp_structure_min_dof_balance"] == 6.0
    @test metadata["best_green_case_id"] == "global_polish_horizon_001"
    @test metadata["best_green_target_horizon"] == 0.5
    @test metadata["first_non_green_case_id"] == "global_polish_horizon_002"
    @test metadata["first_non_green_target_horizon"] == 1.0
    @test metadata["recommended_next_action"] ==
          "increase_global_polish_iterations_or_refine_scaling"
    @test metadata["outputs_written"] == false
    @test metadata["sweep_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["dfvb_kkt_deferred"] == true
end

@testset "Reduced MPCC global polish horizon sweep all-green frontier" begin
    first_green = _reduced_mpcc_global_polish_horizon_test_result(
        target_horizon = 0.5,
        trajectory_ready = true,
    )
    second_green = _reduced_mpcc_global_polish_horizon_test_result(
        target_horizon = 1.0,
        trajectory_ready = true,
        max_state_relative_rmse = 1.0e-3,
    )

    sweep = sweep_reduced_dcdfba_mpcc_global_polish_horizons([
        first_green,
        second_green,
    ])
    @test sweep.metadata["all_requested_cases_green"] == true
    @test sweep.metadata["best_green_case_id"] == "global_polish_horizon_002"
    @test sweep.metadata["best_green_target_horizon"] == 1.0
    @test sweep.metadata["first_non_green_case_id"] === missing
    @test sweep.metadata["recommended_next_action"] == "extend_global_polish_horizon_grid"
end

@testset "Reduced MPCC global polish horizon sweep validation" begin
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_global_polish_horizons(
        ReducedDCDFBAMPCCGlobalPolishResult[],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_horizon_specs(
        Float64[],
        "cascade",
        0.0,
        0.5,
        2,
        3,
        100,
        [200],
        300,
        300,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_horizon_specs(
        [0.5],
        "bad_source",
        0.0,
        0.5,
        2,
        3,
        100,
        [200],
        300,
        300,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_horizon_specs(
        [0.5],
        "cascade",
        Inf,
        0.5,
        2,
        3,
        100,
        [200],
        300,
        300,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_horizon_specs(
        [0.5],
        "cascade",
        0.0,
        0.0,
        2,
        3,
        100,
        [200],
        300,
        300,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_horizon_specs(
        [0.5],
        "cascade",
        0.0,
        0.5,
        0,
        3,
        100,
        [200],
        300,
        300,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_horizon_specs(
        [0.5],
        "cascade",
        0.0,
        0.5,
        2,
        2,
        100,
        [200],
        300,
        300,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_horizon_specs(
        [0.75],
        "cascade",
        0.0,
        0.5,
        2,
        3,
        100,
        [200],
        300,
        300,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_horizon_validate_retry_iters(
        Int[],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_horizon_validate_retry_iters(
        [200, 0],
    )
end
