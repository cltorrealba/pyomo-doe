using DataFrames

function _reduced_mpcc_policy_horizon_test_attempt(;
    target_horizon::Float64,
    horizon_reached::Float64,
    attempt_traffic_light::String,
    global_viability_class::String,
    continuation_acceptance_policy::String,
    continuation_state_relative_rmse_threshold::Float64 = 2.0e-2,
    window_hours::Float64 = 0.5,
    nfe_per_window::Int = 2,
    n_completed_windows::Int = round(Int, horizon_reached / window_hours),
    window_green_count::Int = n_completed_windows,
    window_yellow_count::Int = 0,
    window_red_count::Int = attempt_traffic_light == "red" ? 1 : 0,
    continuation_policy_rejected_window_count::Int = 0,
    iteration_limit_policy_accepted_window_count::Int = 0,
    state_drift_gate_pass_window_count::Int = n_completed_windows,
    first_non_green_window_id = missing,
    first_non_green_window_index = missing,
    first_non_green_window_class = missing,
    first_red_window_id = missing,
    first_red_window_index = missing,
    first_red_window_class = missing,
    first_not_residual_feasible_window_id = missing,
    first_not_residual_feasible_window_index = missing,
    first_not_residual_feasible_window_class = missing,
    solver_status::String = "LOCALLY_SOLVED",
    max_mass_balance_residual::Float64 = 5.0e-7,
    global_state_relative_rmse::Float64 = 0.01,
)
    n_requested_windows = round(Int, target_horizon / window_hours)
    target_completed = isapprox(horizon_reached, target_horizon; atol = 1.0e-10)
    residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
    viability_thresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        )
    continuation = ReducedDCDFBAMPCCWindowedContinuationResult(
        DataFrame(),
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        nothing,
        nothing,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}(
            "n_requested_windows" => n_requested_windows,
            "n_completed_windows" => n_completed_windows,
            "continuation_completed" => target_completed,
        ),
    )
    viability_report = ReducedDCDFBAMPCCSimulationViabilityReport(
        "windowed_continuation",
        DataFrame(),
        viability_thresholds,
        Dict{String, Any}("overall_traffic_light" => attempt_traffic_light),
    )
    blocking =
        attempt_traffic_light == "green" ? "" :
        global_viability_class == "windowed_drift_too_large" ?
        "global_state_drift_too_large" :
        "candidate_not_trajectory_ready"
    attempt_table = DataFrame(
        "candidate_id" => ["windowed_global"],
        "source_type" => ["windowed_continuation_global"],
        "traffic_light" => [attempt_traffic_light],
        "viability_class" => [global_viability_class],
        "solver_status" => [solver_status],
        "max_rhs_residual" => [1.0e-10],
        "max_mass_balance_residual" => [max_mass_balance_residual],
        "max_lower_bound_violation" => [1.0e-9],
        "max_upper_bound_violation" => [1.0e-9],
        "max_stationarity_residual" => [1.0e-8],
        "max_lower_complementarity_residual" => [5.0e-7],
        "max_upper_complementarity_residual" => [5.0e-7],
        "max_lower_complementarity_product" => [5.0e-7],
        "max_upper_complementarity_product" => [5.0e-7],
        "max_complementarity_tau_violation" => [0.0],
        "complementarity_tau_gate_pass" => [true],
        "max_state_relative_rmse" => [global_state_relative_rmse],
        "blocking_reasons" => [blocking],
        "review_reasons" => ["full_dfba_cold_reference_deferred"],
    )
    metadata = Dict{String, Any}(
        "target_horizon" => target_horizon,
        "horizon_reached" => horizon_reached,
        "horizon_gap" => max(target_horizon - horizon_reached, 0.0),
        "target_completion_fraction" => horizon_reached / target_horizon,
        "target_completed" => target_completed,
        "attempt_traffic_light" => attempt_traffic_light,
        "attempt_viable" => attempt_traffic_light == "green",
        "window_hours" => window_hours,
        "nfe_per_window" => nfe_per_window,
        "degree" => 3,
        "linear_solver" => "mumps",
        "ipopt_profile" => "acceptable",
        "complementarity_mode" => "scholtes",
        "complementarity_tau" => 1.0e-4,
        "tau_schedule" => [1.0e-2, 1.0e-4, 1.0e-6],
        "tau_continuation_stage_count" => 3,
        "continuation_acceptance_policy" => continuation_acceptance_policy,
        "continuation_state_relative_rmse_threshold" =>
            continuation_state_relative_rmse_threshold,
        "continuation_state_drift_gate_enabled" =>
            continuation_acceptance_policy ==
            "iteration_limit_residual_feasible_state_drift",
        "n_requested_windows" => n_requested_windows,
        "n_completed_windows" => n_completed_windows,
        "n_failed_windows" => max(n_requested_windows - n_completed_windows, 0),
        "global_traffic_light" => attempt_traffic_light,
        "global_viability_class" => global_viability_class,
        "window_green_count" => window_green_count,
        "window_yellow_count" => window_yellow_count,
        "window_red_count" => window_red_count,
        "continuation_policy_rejected_window_count" =>
            continuation_policy_rejected_window_count,
        "iteration_limit_policy_accepted_window_count" =>
            iteration_limit_policy_accepted_window_count,
        "state_drift_gate_pass_window_count" => state_drift_gate_pass_window_count,
        "first_non_green_window_id" => first_non_green_window_id,
        "first_non_green_window_index" => first_non_green_window_index,
        "first_non_green_window_class" => first_non_green_window_class,
        "first_red_window_id" => first_red_window_id,
        "first_red_window_index" => first_red_window_index,
        "first_red_window_class" => first_red_window_class,
        "first_not_residual_feasible_window_id" => first_not_residual_feasible_window_id,
        "first_not_residual_feasible_window_index" =>
            first_not_residual_feasible_window_index,
        "first_not_residual_feasible_window_class" =>
            first_not_residual_feasible_window_class,
        "global_max_state_relative_rmse" => global_state_relative_rmse,
        "total_solve_elapsed_seconds" => 20.0 * max(n_completed_windows, 1),
        "recommended_next_action" =>
            attempt_traffic_light == "green" ?
            "review_windowed_target_candidate_before_scientific_use" :
            "improve_solver_termination_or_retry_frontier_windows",
        "outputs_written" => false,
        "solved_trajectory_claimed" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
    return ReducedDCDFBAMPCCWindowedSimulationAttemptResult(
        continuation,
        viability_report,
        attempt_table,
        metadata,
    )
end

@testset "Reduced MPCC windowed policy horizon sweep aggregation" begin
    attempts = [
        _reduced_mpcc_policy_horizon_test_attempt(
            target_horizon = 0.5,
            horizon_reached = 0.5,
            attempt_traffic_light = "green",
            global_viability_class = "simulation_viable_candidate",
            continuation_acceptance_policy = "residual_feasible",
            global_state_relative_rmse = 0.010,
        ),
        _reduced_mpcc_policy_horizon_test_attempt(
            target_horizon = 1.0,
            horizon_reached = 1.0,
            attempt_traffic_light = "green",
            global_viability_class = "simulation_viable_candidate",
            continuation_acceptance_policy =
                "iteration_limit_residual_feasible_state_drift",
            iteration_limit_policy_accepted_window_count = 1,
            global_state_relative_rmse = 0.012,
        ),
        _reduced_mpcc_policy_horizon_test_attempt(
            target_horizon = 2.0,
            horizon_reached = 1.5,
            attempt_traffic_light = "red",
            global_viability_class = "windowed_drift_too_large",
            continuation_acceptance_policy =
                "iteration_limit_residual_feasible_state_drift",
            continuation_policy_rejected_window_count = 1,
            first_non_green_window_id = "window_004",
            first_non_green_window_index = 4,
            first_non_green_window_class = "windowed_drift_too_large",
            first_red_window_id = "window_004",
            first_red_window_index = 4,
            first_red_window_class = "windowed_drift_too_large",
            global_state_relative_rmse = 0.035,
        ),
    ]

    sweep = sweep_reduced_dcdfba_mpcc_windowed_policy_horizons(attempts)
    table = sweep.policy_horizon_table
    metadata = sweep.metadata

    @test sweep isa ReducedDCDFBAMPCCWindowedPolicyHorizonSweepResult
    @test size(table, 1) == 3
    @test table[!, "policy_case_id"] == [
        "window_policy_horizon_001",
        "window_policy_horizon_002",
        "window_policy_horizon_003",
    ]
    @test table[2, "attempt_traffic_light"] == "green"
    @test table[2, "is_last_green"] == true
    @test table[3, "is_first_non_green_after_green"] == true
    @test table[3, "continuation_policy_rejected_window_count"] == 1
    @test table[2, "iteration_limit_policy_accepted_window_count"] == 1
    @test table[1, "linear_solver"] == "mumps"
    @test table[1, "ipopt_profile"] == "acceptable"
    @test table[1, "complementarity_mode"] == "scholtes"
    @test table[1, "complementarity_tau"] == 1.0e-4
    @test table[1, "tau_continuation_stage_count"] == 3
    @test table[1, "max_complementarity_tau_violation"] == 0.0
    @test table[1, "complementarity_tau_gate_pass"] == true
    @test table[1, "scale_readiness"] == "scale_candidate"
    @test table[1, "primary_blocker"] == "none"
    @test table[1, "scale_recommended_next_action"] ==
          "extend_windowed_policy_horizon_grid"
    @test table[1, "is_scale_candidate"] == true
    @test table[1, "is_72h_ready_candidate"] == false
    @test table[1, "next_target_horizon_hint"] == 1.0
    @test table[3, "scale_readiness"] == "blocked"
    @test table[3, "primary_blocker"] == "state_drift"
    @test table[3, "scale_recommended_next_action"] ==
          "reduce_windowed_state_drift_before_72h"
    @test table[3, "is_scale_candidate"] == false
    @test table[3, "next_target_horizon_hint"] === missing
    @test all(==(false), table[!, "outputs_written"])
    @test all(==(false), table[!, "sweep_is_scientific_simulation"])
    @test all(==(false), table[!, "solved_trajectory_claimed"])
    @test all(==("reduced_dfba"), table[!, "first_mpcc_target"])
    @test all(==(true), table[!, "full_model_kkt_deferred"])
    @test all(==(true), table[!, "dfvb_kkt_deferred"])
    @test all(==(false), table[!, "hsl_required"])
    @test all(==(false), table[!, "ma57_required"])
    @test all(==(false), table[!, "indices_reacciones_used"])
    @test all(==(false), table[!, "r0001_used_as_oxygen"])

    @test metadata["sweep_type"] ==
          "reduced_dcdfba_mpcc_windowed_policy_horizon_sweep"
    @test metadata["n_requested_cases"] == 3
    @test metadata["n_completed_cases"] == 3
    @test metadata["n_failed_cases"] == 0
    @test metadata["green_count"] == 2
    @test metadata["red_count"] == 1
    @test metadata["target_completed_count"] == 2
    @test metadata["scale_candidate_count"] == 2
    @test metadata["review_before_scaling_count"] == 0
    @test metadata["blocked_case_count"] == 1
    @test metadata["scale_readiness_counts"]["scale_candidate"] == 2
    @test metadata["scale_readiness_counts"]["blocked"] == 1
    @test metadata["primary_blocker_counts"]["none"] == 2
    @test metadata["primary_blocker_counts"]["state_drift"] == 1
    @test metadata["best_green_case_id"] == "window_policy_horizon_002"
    @test metadata["best_green_target_horizon"] == 1.0
    @test metadata["best_green_policy"] ==
          "iteration_limit_residual_feasible_state_drift"
    @test metadata["best_scale_candidate_case_id"] == "window_policy_horizon_002"
    @test metadata["best_scale_candidate_next_target_horizon_hint"] == 2.0
    @test metadata["best_scale_candidate_recommended_next_action"] ==
          "extend_windowed_policy_horizon_grid"
    @test metadata["max_horizon_reached"] == 1.5
    @test metadata["first_non_green_case_id"] == "window_policy_horizon_003"
    @test metadata["first_non_green_viability_class"] == "windowed_drift_too_large"
    @test metadata["first_blocked_case_id"] == "window_policy_horizon_003"
    @test metadata["first_blocked_primary_blocker"] == "state_drift"
    @test metadata["first_blocked_scale_recommended_next_action"] ==
          "reduce_windowed_state_drift_before_72h"
    @test metadata["sweep_reached_green"] == true
    @test metadata["sweep_blocked"] == true
    @test metadata["outputs_written"] == false
    @test metadata["sweep_is_scientific_simulation"] == false
    @test metadata["scientific_baseline"] == "full_dfba_cold_deferred"
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["recommended_next_action"] == "reduce_windowed_state_drift_before_72h"
end

@testset "Reduced MPCC windowed policy horizon sweep validation" begin
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_windowed_policy_horizons(
        ReducedDCDFBAMPCCWindowedSimulationAttemptResult[],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_windowed_policy_horizon_specs(
        0.0,
        [0.5],
        [0.5],
        [2],
        ["residual_feasible"],
        [0.02],
        2,
        100,
        ["mumps"],
        [1.0e-4],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_windowed_policy_horizon_specs(
        0.0,
        [0.75],
        [0.5],
        [2],
        ["residual_feasible"],
        [0.02],
        3,
        100,
        ["mumps"],
        [1.0e-4],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_windowed_policy_horizon_specs(
        0.0,
        [0.5],
        [0.5],
        [0],
        ["residual_feasible"],
        [0.02],
        3,
        100,
        ["mumps"],
        [1.0e-4],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_windowed_policy_horizon_specs(
        0.0,
        [0.5],
        [0.5],
        [2],
        ["invalid"],
        [0.02],
        3,
        100,
        ["mumps"],
        [1.0e-4],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_windowed_policy_horizon_specs(
        0.0,
        [0.5],
        [0.5],
        [2],
        ["residual_feasible"],
        [-0.02],
        3,
        100,
        ["mumps"],
        [1.0e-4],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_windowed_policy_horizon_specs(
        0.0,
        [0.5],
        [0.5],
        [2],
        ["residual_feasible"],
        [0.02],
        3,
        100,
        ["bad_solver"],
        [1.0e-4],
    )

    yellow = Dict{String, Any}(
        "case_status" => "completed",
        "target_horizon" => 1.0,
        "window_hours" => 0.5,
        "target_completed" => true,
        "attempt_traffic_light" => "yellow",
        "global_viability_class" => "iteration_limit_residual_feasible_candidate",
        "blocking_reasons" => "candidate_not_trajectory_ready",
        "review_reasons" => "iteration_limit_residual_feasible",
        "solver_status" => "ITERATION_LIMIT",
        "continuation_policy_rejected_window_count" => 0,
    )
    FermentationDFBA._reduced_mpcc_windowed_policy_horizon_annotate_scale_readiness!(
        yellow,
    )
    @test yellow["scale_readiness"] == "review_before_scaling"
    @test yellow["primary_blocker"] == "solver_termination"
    @test yellow["scale_recommended_next_action"] ==
          "retry_or_improve_solver_termination_before_scaling"
    @test yellow["is_scale_candidate"] == false

    residual = copy(yellow)
    residual["attempt_traffic_light"] = "red"
    residual["global_viability_class"] = "residual_thresholds_failed"
    residual["blocking_reasons"] = "residual_thresholds_failed"
    FermentationDFBA._reduced_mpcc_windowed_policy_horizon_annotate_scale_readiness!(
        residual,
    )
    @test residual["scale_readiness"] == "blocked"
    @test residual["primary_blocker"] == "residual_feasibility"
end
