@testset "Reaction map validation" begin
    model = MetabolicModel(
        [1.0 0.0 0.0 0.0; 0.0 1.0 -1.0 0.0],
        [0.0, -100.0, 0.0, 0.0],
        [100.0, 100.0, 100.0, 100.0],
        ["r_2111", "r_1714", "r_1709", "r_4048"],
        ["met_a", "met_b"];
        model_id = "toy",
    )

    reaction_map = ReactionMap(
        core = Dict(
            "biomass_growth" => "r_2111",
            "glucose_exchange" => "r_1714",
            "fructose_exchange" => "r_1709",
            "oxygen_exchange" => "r_1992",
            "carbohydrate_exchange" => "r_4048",
        ),
        disabled_reactions = Dict(
            "oxygen_exchange" => "r_1992",
        ),
    )

    report = validate_reaction_map(model, reaction_map)

    @test report.ok
    @test report.found_required_reactions["biomass_growth"] == "r_2111"
    @test report.found_required_reactions["glucose_exchange"] == "r_1714"
    @test report.found_required_reactions["fructose_exchange"] == "r_1709"
    @test report.found_required_reactions["carbohydrate_exchange"] == "r_4048"
    @test report.disabled_reactions["oxygen_exchange"] == "r_1992"
    @test !haskey(report.disabled_reactions, "carbohydrate_exchange")
    @test isempty(report.missing_required_reactions)
    @test isempty(report.unknown_reaction_ids)

    broken_map = ReactionMap(core = Dict("unknown_active_role" => "r_missing"))
    broken_report = validate_reaction_map(model, broken_map)
    @test !broken_report.ok
    @test broken_report.missing_required_reactions["unknown_active_role"] == "r_missing"
    @test broken_report.unknown_reaction_ids["unknown_active_role"] == "r_missing"
end
