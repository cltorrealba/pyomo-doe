import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_collocation_state_starts_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_collocation_state_starts_test_simulation()
    time = [0.0, 0.25]
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    states = hcat(initial_state, initial_state)
    fluxes = reshape([0.02, 0.02], 1, 2)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

@testset "Reduced DC-dFBA collocation-consistent state starts metadata" begin
    model, reaction_map = _reduced_dcdfba_collocation_state_starts_test_model_and_map()
    simulation = _reduced_dcdfba_collocation_state_starts_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    metadata = problem.metadata

    @test metadata["collocation_consistent_state_start_applied"] == true
    @test metadata["collocation_consistent_state_start_policy"] ==
          "monotone_damped_fixed_point_state_flux_dual_rhs_start_refresh"
    @test metadata["collocation_consistent_state_start_iterations"] >= 1
    @test metadata["collocation_consistent_state_start_iterations"] <=
          metadata["collocation_consistent_state_start_max_iterations"]
    @test metadata["collocation_consistent_state_start_tolerance"] == 1.0e-10
    @test metadata["collocation_consistent_state_start_converged"] == true
    @test metadata["collocation_consistent_state_start_initial_collocation_residual"] > 1.0e-4
    @test metadata["collocation_consistent_state_start_initial_continuity_residual"] > 1.0e-4
    @test metadata["collocation_consistent_state_start_initial_rhs_residual"] <= 1.0e-12
    @test metadata["collocation_consistent_state_start_final_collocation_residual"] <= 1.0e-9
    @test metadata["collocation_consistent_state_start_final_continuity_residual"] <= 1.0e-9
    @test metadata["collocation_consistent_state_start_final_rhs_residual"] <= 1.0e-12
    @test metadata["collocation_consistent_state_start_initial_max_residual"] > 1.0e-4
    @test metadata["collocation_consistent_state_start_final_max_residual"] <= 1.0e-9
    @test metadata["collocation_consistent_state_start_score_policy"] ==
          "collocation_state"
    @test metadata["collocation_consistent_state_start_initial_score"] ≈
          metadata["collocation_consistent_state_start_initial_max_residual"]
    @test metadata["collocation_consistent_state_start_final_score"] ≈
          metadata["collocation_consistent_state_start_final_max_residual"]
    @test metadata["collocation_consistent_state_start_best_score"] <=
          metadata["collocation_consistent_state_start_final_score"]
    @test haskey(metadata, "collocation_consistent_state_start_last_residual_improvement")
    @test haskey(metadata, "collocation_consistent_state_start_last_score_improvement")
    @test metadata["collocation_consistent_state_start_trace_enabled"] == false
    @test metadata["collocation_consistent_state_start_restore_best_enabled"] == true
    @test metadata["collocation_consistent_state_start_monotone_enabled"] == true
    @test metadata["collocation_consistent_state_start_trace_every"] == 1
    @test metadata["collocation_consistent_state_start_damping_factors"] ==
          [1.0, 0.5, 0.25, 0.1, 0.05, 0.01]
    @test metadata["collocation_consistent_state_start_monotone_acceptance_tolerance"] ==
          0.0
    @test metadata["collocation_consistent_state_start_trial_count"] >=
          metadata["collocation_consistent_state_start_iterations"]
    @test metadata["collocation_consistent_state_start_rejected_trial_count"] >= 0
    @test metadata["collocation_consistent_state_start_last_accepted_damping_factor"] !==
          missing
    @test metadata["collocation_consistent_state_start_min_accepted_damping_factor"] !==
          missing
    @test metadata["collocation_consistent_state_start_stopped_by_monotone_guard"] == false
    @test metadata["collocation_consistent_state_start_best_iteration"] >= 0
    @test metadata["collocation_consistent_state_start_best_iteration"] <=
          metadata["collocation_consistent_state_start_iterations"]
    @test metadata["collocation_consistent_state_start_best_max_residual"] <=
          metadata["collocation_consistent_state_start_final_max_residual"]
    @test metadata["collocation_consistent_state_start_restored_best_iteration"] in
          (true, false)
    @test metadata["collocation_consistent_state_start_restore_best_improvement"] >= 0.0
    @test metadata["collocation_consistent_state_start_stagnation_tolerance"] == 0.0
    @test metadata["collocation_consistent_state_start_stagnation_iterations"] == 0
    @test metadata["collocation_consistent_state_start_stagnation_counter"] == 0
    @test metadata["collocation_consistent_state_start_stopped_by_stagnation"] == false
    @test metadata["collocation_consistent_state_start_last_dynamic_flux_lp_attempt_count"] == 3
    @test metadata["collocation_consistent_state_start_last_dynamic_flux_lp_total_solve_elapsed_seconds"] >=
          0.0
    @test metadata["collocation_consistent_state_start_last_dynamic_flux_lp_max_solve_elapsed_seconds"] >=
          0.0
    @test metadata["collocation_consistent_state_start_max_state_collocation_adjustment"] > 0.0
    @test metadata["collocation_consistent_state_start_max_state_boundary_adjustment"] > 0.0
    @test metadata["collocation_consistent_state_start_dynamic_flux_refreshed"] == true
    @test metadata["collocation_consistent_state_start_stationarity_duals_refreshed"] == true
    @test metadata["collocation_consistent_state_start_rhs_derivatives_refreshed"] == true
    @test metadata["collocation_consistent_state_start_is_scientific_simulation"] == false
    @test problem.smoke_problem.metadata["collocation_consistent_state_start_applied"] == true
    @test problem.smoke_problem.nlp.metadata["collocation_consistent_state_start_applied"] == true
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA collocation repair candidate-threshold score policy" begin
    model, reaction_map = _reduced_dcdfba_collocation_state_starts_test_model_and_map()
    simulation = _reduced_dcdfba_collocation_state_starts_test_simulation()
    problem = withenv(
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SCORE" => "candidate_threshold_ratio",
    ) do
        build_reduced_dcdfba_mpcc_solve_attempt_problem(
            model,
            reaction_map;
            sequential_initialization = simulation,
            ipopt_max_iter = 0,
        )
    end
    metadata = problem.metadata

    @test metadata["collocation_consistent_state_start_applied"] == true
    @test metadata["collocation_consistent_state_start_score_policy"] ==
          "candidate_threshold_ratio"
    @test isfinite(metadata["collocation_consistent_state_start_initial_score"])
    @test isfinite(metadata["collocation_consistent_state_start_final_score"])
    @test isfinite(metadata["collocation_consistent_state_start_best_score"])
    @test metadata["collocation_consistent_state_start_best_score"] <=
          metadata["collocation_consistent_state_start_final_score"]
    @test haskey(metadata, "collocation_consistent_state_start_last_score_improvement")
end

@testset "Reduced DC-dFBA collocation-consistent state starts scaling diagnostics" begin
    model, reaction_map = _reduced_dcdfba_collocation_state_starts_test_model_and_map()
    simulation = _reduced_dcdfba_collocation_state_starts_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    plan = build_reduced_dcdfba_mpcc_scaling_plan(problem)
    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)

    @test plan.constraint_blocks["collocation_integration"].abs_max <= 1.0e-9
    @test plan.constraint_blocks["continuity"].abs_max <= 1.0e-9
    @test report.scaling_summary["collocation_consistent_state_start_converged"] == 1.0
    @test report.scaling_summary["collocation_consistent_state_start_final_collocation_residual"] <=
          1.0e-9
    @test report.scaling_summary["collocation_consistent_state_start_final_continuity_residual"] <=
          1.0e-9
    @test report.scaling_summary["collocation_consistent_state_start_final_rhs_residual"] <=
          1.0e-12
    @test report.scaling_summary["collocation_consistent_state_start_final_max_residual"] <=
          1.0e-9
    @test report.scaling_summary["collocation_consistent_state_start_stopped_by_stagnation"] ==
          0.0
    @test report.scaling_summary["collocation_consistent_state_start_restore_best_enabled"] ==
          1.0
    @test report.scaling_summary["collocation_consistent_state_start_monotone_enabled"] ==
          1.0
    @test report.scaling_summary["collocation_consistent_state_start_trial_count"] >=
          report.scaling_summary["collocation_consistent_state_start_iterations"]
    @test report.scaling_summary["collocation_consistent_state_start_stopped_by_monotone_guard"] ==
          0.0
    @test report.scaling_summary["collocation_consistent_state_start_restored_best_iteration"] in
          (0.0, 1.0)
    @test report.scaling_summary["collocation_consistent_state_start_last_dynamic_flux_lp_attempt_count"] ==
          3.0
    @test !("collocation_integration_start_residual_large" in plan.warnings)
    @test !("continuity_start_residual_large" in plan.warnings)
    @test !("collocation_consistent_state_start_not_converged" in report.warnings)
    @test !("collocation_consistent_state_start_collocation_residual_large" in report.warnings)
    @test !("collocation_consistent_state_start_continuity_residual_large" in report.warnings)
    @test !("collocation_consistent_state_start_rhs_residual_large" in report.warnings)
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end
