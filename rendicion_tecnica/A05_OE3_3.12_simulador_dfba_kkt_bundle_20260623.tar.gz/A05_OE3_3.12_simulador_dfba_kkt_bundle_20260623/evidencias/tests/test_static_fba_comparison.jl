import CSV
import TOML
import MathOptInterface as MOI
using DataFrames

const STATIC_FBA_TEST_SUMMARY_COLUMNS = [
    "model_scope",
    "model_id",
    "n_metabolites",
    "n_reactions",
    "objective_rxn_id",
    "solver_status",
    "objective_value",
    "mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "oxygen_policy",
    "carbohydrate_policy",
]

const STATIC_FBA_TEST_SELECTED_FLUX_COLUMNS = [
    "reaction_id",
    "role",
    "present_reduced",
    "present_full",
    "reduced_flux",
    "full_flux",
    "absolute_difference",
    "relative_difference",
    "reduced_lb",
    "reduced_ub",
    "full_lb",
    "full_ub",
    "notes",
]

const STATIC_FBA_REAL_COMPARISON_CACHE = Ref{Any}(nothing)

function _synthetic_static_fba_comparison()
    reduced_model = MetabolicModel(
        reshape([1.0, -1.0], 1, 2),
        [10.0, 0.0],
        [10.0, 100.0],
        ["r_1714", "r_2111"],
        ["m_pool"];
        model_id = "synthetic_reduced_static_fba",
    )
    full_model = MetabolicModel(
        reshape([1.0, -1.0, 0.0], 1, 3),
        [10.0, 0.0, 0.0],
        [10.0, 100.0, 0.0],
        ["r_1714", "r_2111", "r_1992"],
        ["m_pool"];
        model_id = "synthetic_full_static_fba",
    )
    reduced_map = ReactionMap(
        core = Dict(
            "biomass_growth" => "r_2111",
            "glucose_exchange" => "r_1714",
            "oxygen_exchange" => "r_1992",
        ),
        disabled_reactions = Dict("oxygen_exchange" => "r_1992"),
        disabled_reaction_reasons = Dict("oxygen_exchange" => "Synthetic reduced model omits oxygen."),
    )
    full_map = ReactionMap(
        core = Dict(
            "biomass_growth" => "r_2111",
            "glucose_exchange" => "r_1714",
            "oxygen_exchange" => "r_1992",
        ),
    )

    return compare_static_fba_full_reduced(
        reduced_model,
        reduced_map,
        full_model,
        full_map;
        selected_reaction_ids = ["r_2111", "r_1714", "r_1992"],
    )
end

function _real_static_fba_comparison()
    if STATIC_FBA_REAL_COMPARISON_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        reduced_model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        full_model = load_full_model(joinpath(project_root, "config", "full_model_paths.example.toml"))
        reduced_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        full_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_full.example.toml"))
        STATIC_FBA_REAL_COMPARISON_CACHE[] = compare_static_fba_full_reduced(
            reduced_model,
            reduced_map,
            full_model,
            full_map;
            atol = 1.0e-6,
        )
    end
    return STATIC_FBA_REAL_COMPARISON_CACHE[]
end

function _static_fba_test_row(table::DataFrame, reaction_id::AbstractString)
    row_index = findfirst(==(String(reaction_id)), String.(table[!, "reaction_id"]))
    row_index === nothing && error("Missing test reaction row: $(String(reaction_id))")
    return table[row_index, :]
end

@testset "Synthetic static FBA comparison" begin
    comparison = _synthetic_static_fba_comparison()

    @test comparison isa StaticFBAComparisonResult
    @test comparison.reduced_result.status == MOI.OPTIMAL
    @test comparison.full_result.status == MOI.OPTIMAL
    @test nrow(comparison.summary_table) == 2
    @test names(comparison.summary_table) == STATIC_FBA_TEST_SUMMARY_COLUMNS
    @test names(comparison.selected_flux_table) == STATIC_FBA_TEST_SELECTED_FLUX_COLUMNS
    @test comparison.selected_reaction_ids == ["r_2111", "r_1714", "r_1992"]

    oxygen_row = _static_fba_test_row(comparison.selected_flux_table, "r_1992")
    @test oxygen_row.present_reduced == false
    @test oxygen_row.present_full == true
    @test ismissing(oxygen_row.reduced_flux)
    @test isapprox(oxygen_row.full_flux, 0.0; atol = 1.0e-12)
    @test occursin("reduced r_1992 absent/disabled", oxygen_row.notes)

    @test comparison.metadata["comparison_type"] == "static_fba_full_vs_reduced"
    @test comparison.metadata["indices_reacciones_used"] == false
    @test comparison.metadata["r0001_used_as_oxygen"] == false
end

@testset "Real full-vs-reduced static FBA comparison smoke" begin
    comparison = _real_static_fba_comparison()

    @test comparison.reduced_result.status == MOI.OPTIMAL
    @test comparison.full_result.status == MOI.OPTIMAL
    @test isapprox(comparison.reduced_result.objective_value, 0.0998071127791641; rtol = 1.0e-5, atol = 1.0e-7)
    @test isapprox(comparison.full_result.objective_value, 0.07866618384648842; rtol = 1.0e-5, atol = 1.0e-7)

    oxygen_row = _static_fba_test_row(comparison.selected_flux_table, "r_1992")
    @test oxygen_row.present_reduced == false
    @test oxygen_row.present_full == true
    @test ismissing(oxygen_row.reduced_flux)
    @test isapprox(oxygen_row.full_flux, 0.0; atol = 1.0e-8)
    @test isapprox(oxygen_row.full_lb, 0.0; atol = 0.0, rtol = 0.0)
    @test isapprox(oxygen_row.full_ub, 0.0; atol = 0.0, rtol = 0.0)

    @test comparison.metadata["indices_reacciones_used"] == false
    @test comparison.metadata["r0001_used_as_oxygen"] == false
    @test occursin("r_0001 is not used as oxygen", comparison.metadata["oxygen_mapping_note"])
end

@testset "Static FBA comparison export" begin
    comparison = _synthetic_static_fba_comparison()

    mktempdir() do dir
        paths = export_static_fba_comparison(comparison, dir)

        @test isfile(paths["summary"])
        @test isfile(paths["selected_fluxes"])
        @test isfile(paths["metadata"])

        summary = DataFrame(CSV.File(paths["summary"]))
        selected_fluxes = DataFrame(CSV.File(paths["selected_fluxes"]))
        metadata = TOML.parsefile(paths["metadata"])

        @test names(summary) == STATIC_FBA_TEST_SUMMARY_COLUMNS
        @test names(selected_fluxes) == STATIC_FBA_TEST_SELECTED_FLUX_COLUMNS
        @test nrow(summary) == 2
        @test nrow(selected_fluxes) == 3
        @test metadata["comparison_type"] == "static_fba_full_vs_reduced"
        @test metadata["indices_reacciones_used"] == false
        @test metadata["r0001_used_as_oxygen"] == false
    end
end

@testset "Static FBA comparison SVG plots" begin
    comparison = _synthetic_static_fba_comparison()

    mktempdir() do dir
        paths = write_static_fba_comparison_plots(comparison, dir)

        for key in ("objective", "selected_fluxes", "diagnostics")
            @test haskey(paths, key)
            @test isfile(paths[key])
            contents = read(paths[key], String)
            @test occursin("<svg", contents)
        end
        @test occursin("reduced", read(paths["objective"], String))
        @test occursin("full", read(paths["objective"], String))
        @test occursin("r_1992", read(paths["selected_fluxes"], String))
    end
end

@testset "Static FBA comparison overwrite behavior" begin
    comparison = _synthetic_static_fba_comparison()

    mktempdir() do dir
        export_static_fba_comparison(comparison, dir)
        @test_throws ErrorException export_static_fba_comparison(comparison, dir)
        paths = export_static_fba_comparison(comparison, dir; overwrite = true)
        @test isfile(paths["summary"])
        @test isfile(paths["selected_fluxes"])
        @test isfile(paths["metadata"])
    end
end
