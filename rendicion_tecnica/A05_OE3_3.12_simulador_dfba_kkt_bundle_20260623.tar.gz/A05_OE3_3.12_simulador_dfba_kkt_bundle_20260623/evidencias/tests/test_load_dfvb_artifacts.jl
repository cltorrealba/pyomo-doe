using CSV
using DataFrames
using SparseArrays

const DFVB_REAL_ARTIFACT_CACHE = Ref{Any}(nothing)
const TEST_DFVB_STATE_COLUMNS = [
    "time",
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _write_dfvb_test_manifest(path::AbstractString; n_reactions = 3, n_alphas = 2, n_active = 1, n_time = 2)
    write(
        path,
        """
        {
          "created_by": "synthetic",
          "n_reactions": $n_reactions,
          "n_metabolites": 2,
          "n_null_basis_columns": $n_alphas,
          "n_exchange_reactions": 1,
          "n_internal_reactions": $(n_reactions - 1),
          "n_dfvb_time_points": $n_time,
          "has_active_alpha_subset": true,
          "n_active_alpha_columns": $n_active,
          "notes": ["synthetic fixture"]
        }
        """,
    )
end

function _write_dfvb_synthetic_artifacts(dir::AbstractString)
    mkpath(dir)
    _write_dfvb_test_manifest(joinpath(dir, "dfvb_artifact_manifest.json"))

    CSV.write(
        joinpath(dir, "dfvb_reaction_order.csv"),
        DataFrame(
            reaction_index = [1, 2, 3],
            reaction_id = ["r_0001", "r_1992", "r_4048"],
            is_exchange = [true, false, false],
            is_internal = [false, true, true],
            exchange_position = [1, 0, 0],
            internal_position = [0, 1, 2],
            is_active_exchange = [false, false, false],
            is_active_internal = [false, true, true],
            is_inactive_exchange = [false, false, false],
            is_inactive_internal = [false, false, false],
            model_scope = ["synthetic", "synthetic", "synthetic"],
        ),
    )
    CSV.write(
        joinpath(dir, "dfvb_reduced_dfba_reaction_order.csv"),
        DataFrame(reduced_reaction_index = [1, 2], original_reaction_index = [2, 3], reaction_id = ["r_1992", "r_4048"]),
    )
    partition = DataFrame(
        model_scope = ["synthetic", "synthetic", "synthetic"],
        partition = ["exchange", "internal", "internal"],
        partition_position = [1, 1, 2],
        reaction_index = [1, 2, 3],
        reaction_id = ["r_0001", "r_1992", "r_4048"],
        is_active = [false, true, true],
        is_inactive_forced_zero = [false, false, false],
    )
    CSV.write(joinpath(dir, "dfvb_exchange_partition.csv"), partition)
    CSV.write(joinpath(dir, "dfvb_exchange_partition_active_alpha.csv"), partition)

    CSV.write(
        joinpath(dir, "dfvb_N_sparse_triplets.csv"),
        DataFrame(row_index = [1, 2, 3], column_index = [1, 1, 2], value = [1.0, -2.0, 3.5]),
    )
    CSV.write(
        joinpath(dir, "dfvb_N_active_alpha_sparse_triplets.csv"),
        DataFrame(row_index = [2, 3], column_index = [1, 1], value = [-2.0, 3.5]),
    )
    CSV.write(
        joinpath(dir, "dfvb_N_column_metadata.csv"),
        DataFrame(
            alpha_index = [1, 2],
            source_alpha_index = [1, 2],
            source_alpha_id = ["alpha_1", "alpha_2"],
            is_active = [true, true],
            model_scope = ["synthetic", "synthetic"],
        ),
    )
    CSV.write(
        joinpath(dir, "dfvb_N_active_alpha_column_metadata.csv"),
        DataFrame(
            alpha_index = [1],
            source_alpha_index = [2],
            source_alpha_id = ["alpha_2"],
            is_active = [true],
            model_scope = ["synthetic_active"],
        ),
    )
    CSV.write(
        joinpath(dir, "dfvb_active_alpha_indices.csv"),
        DataFrame(active_alpha_index = [1], source_alpha_index = [2], source_alpha_id = ["alpha_2"]),
    )
    CSV.write(
        joinpath(dir, "dfvb_alpha_bounds.csv"),
        DataFrame(
            alpha_index = [1, 2],
            source_alpha_index = [1, 2],
            source_alpha_id = ["alpha_1", "alpha_2"],
            lower_bound = [-1.0e6, -1.0e6],
            upper_bound = [1.0e6, 1.0e6],
            model_scope = ["synthetic", "synthetic"],
        ),
    )
    CSV.write(
        joinpath(dir, "dfvb_alpha_bounds_active.csv"),
        DataFrame(
            alpha_index = [1],
            source_alpha_index = [2],
            source_alpha_id = ["alpha_2"],
            lower_bound = [-1.0e6],
            upper_bound = [1.0e6],
            model_scope = ["synthetic_active"],
        ),
    )
    CSV.write(joinpath(dir, "dfvb_alpha_trajectories.csv"), DataFrame(time = [0.0, 1.0], alpha_1 = [0.0, 0.2], alpha_2 = [1.0, 1.2]))
    CSV.write(joinpath(dir, "dfvb_alpha_trajectories_active.csv"), DataFrame(time = [0.0, 1.0], alpha_1 = [1.0, 1.2]))
    CSV.write(
        joinpath(dir, "dfvb_state_trajectories.csv"),
        DataFrame((column => fill(0.0, 2) for column in TEST_DFVB_STATE_COLUMNS)...),
    )
    CSV.write(joinpath(dir, "dfvb_inactive_reactions.csv"), DataFrame(model_scope = String[], partition = String[], reaction_id = String[]))
    CSV.write(joinpath(dir, "dfvb_inactive_reactions_active_alpha.csv"), DataFrame(model_scope = String[], partition = String[], reaction_id = String[]))
end

function _write_dfvb_synthetic_config(path::AbstractString, artifact_dir::AbstractString)
    write(
        path,
        """
        artifact_id = "synthetic_dfvb"
        base_dir = "$(replace(artifact_dir, "\\" => "\\\\"))"
        manifest = "dfvb_artifact_manifest.json"
        reaction_order = "dfvb_reaction_order.csv"
        reduced_dfba_reaction_order = "dfvb_reduced_dfba_reaction_order.csv"
        exchange_partition = "dfvb_exchange_partition.csv"
        exchange_partition_active_alpha = "dfvb_exchange_partition_active_alpha.csv"
        n_sparse_triplets = "dfvb_N_sparse_triplets.csv"
        n_column_metadata = "dfvb_N_column_metadata.csv"
        n_active_alpha_sparse_triplets = "dfvb_N_active_alpha_sparse_triplets.csv"
        n_active_alpha_column_metadata = "dfvb_N_active_alpha_column_metadata.csv"
        active_alpha_indices = "dfvb_active_alpha_indices.csv"
        alpha_bounds = "dfvb_alpha_bounds.csv"
        alpha_bounds_active = "dfvb_alpha_bounds_active.csv"
        alpha_trajectories = "dfvb_alpha_trajectories.csv"
        alpha_trajectories_active = "dfvb_alpha_trajectories_active.csv"
        state_trajectories = "dfvb_state_trajectories.csv"
        inactive_reactions = "dfvb_inactive_reactions.csv"
        inactive_reactions_active_alpha = "dfvb_inactive_reactions_active_alpha.csv"
        """,
    )
end

function _real_dfvb_artifacts()
    if DFVB_REAL_ARTIFACT_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        config_path = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")
        DFVB_REAL_ARTIFACT_CACHE[] = load_dfvb_artifacts(config_path)
    end
    return DFVB_REAL_ARTIFACT_CACHE[]
end

function _reaction_row(table::DataFrame, reaction_id::AbstractString)
    index = findfirst(==(String(reaction_id)), String.(table[!, "reaction_id"]))
    index === nothing && error("Missing reaction $(String(reaction_id))")
    return table[index, :]
end

@testset "DFVB flat manifest parser" begin
    mktempdir() do dir
        manifest_path = joinpath(dir, "manifest.json")
        _write_dfvb_test_manifest(manifest_path; n_reactions = 5, n_alphas = 3, n_active = 2, n_time = 4)
        manifest = load_dfvb_artifact_manifest(manifest_path)

        @test manifest.n_reactions == 5
        @test manifest.n_metabolites == 2
        @test manifest.n_null_basis_columns == 3
        @test manifest.n_active_alpha_columns == 2
        @test manifest.n_dfvb_time_points == 4
        @test manifest.has_active_alpha_subset == true
        @test haskey(manifest.raw, "notes")
    end
end

@testset "Synthetic DFVB artifact loader" begin
    mktempdir() do dir
        artifact_dir = joinpath(dir, "artifacts")
        config_path = joinpath(dir, "dfvb_artifact_paths.toml")
        _write_dfvb_synthetic_artifacts(artifact_dir)
        _write_dfvb_synthetic_config(config_path, artifact_dir)

        paths = load_dfvb_artifact_paths(config_path)
        @test validate_dfvb_artifact_files(paths).ok

        artifacts = load_dfvb_artifacts(paths)
        report = validate_dfvb_artifacts(artifacts)

        @test artifacts.paths.artifact_id == "synthetic_dfvb"
        @test size(artifacts.N) == (3, 2)
        @test nnz(artifacts.N) == 3
        @test artifacts.N[1, 1] == 1.0
        @test artifacts.N[2, 1] == -2.0
        @test artifacts.N[3, 2] == 3.5
        @test size(artifacts.N_active) == (3, 1)
        @test nnz(artifacts.N_active) == 2
        @test nrow(artifacts.alpha_trajectories) == 2
        @test nrow(artifacts.alpha_trajectories_active) == 2
        @test nrow(artifacts.state_trajectories) == 2
        @test report.ok
        @test isempty(report.errors)
        @test artifacts.metadata["r0001_used_as_oxygen"] == false
        @test artifacts.metadata["indices_reacciones_used"] == false
        @test any(warning -> occursin("r_0001", warning), report.warnings)
    end
end

@testset "Real DFVB artifact dimensions" begin
    artifacts = _real_dfvb_artifacts()
    report = validate_dfvb_artifacts(artifacts)

    @test artifacts.manifest.n_reactions == 4131
    @test artifacts.manifest.n_metabolites == 2806
    @test artifacts.manifest.n_null_basis_columns == 1538
    @test artifacts.manifest.n_exchange_reactions == 1
    @test artifacts.manifest.n_internal_reactions == 4130
    @test artifacts.manifest.n_dfvb_time_points == 2094
    @test artifacts.manifest.has_active_alpha_subset == true
    @test artifacts.manifest.n_active_alpha_columns == 490
    @test size(artifacts.N) == (4131, 1538)
    @test size(artifacts.N_active) == (4131, 490)
    @test nnz(artifacts.N) == 98263
    @test nnz(artifacts.N_active) == 17023
    @test nrow(artifacts.alpha_trajectories) == 2094
    @test nrow(artifacts.alpha_trajectories_active) == 2094
    @test nrow(artifacts.state_trajectories) == 2094
    @test nrow(artifacts.reaction_order) == 4131
    @test nrow(artifacts.exchange_partition) == 4131
    @test report.ok
    @test isempty(report.errors)
    @test any(warning -> occursin("r_0001", warning), report.warnings)
    @test any(warning -> occursin("r_1992", warning), report.warnings)
    @test artifacts.metadata["r0001_used_as_oxygen"] == false
    @test artifacts.metadata["indices_reacciones_used"] == false
end

@testset "Real DFVB critical reaction statuses" begin
    artifacts = _real_dfvb_artifacts()

    r0001 = _reaction_row(artifacts.reaction_order, "r_0001")
    r1992 = _reaction_row(artifacts.reaction_order, "r_1992")
    r2111 = _reaction_row(artifacts.reaction_order, "r_2111")
    r4048 = _reaction_row(artifacts.reaction_order, "r_4048")

    @test Bool(r0001["is_exchange"])
    @test !Bool(r0001["is_internal"])
    @test Bool(r1992["is_internal"])
    @test !Bool(r1992["is_exchange"])
    @test Bool(r2111["is_internal"])
    @test !Bool(r2111["is_exchange"])
    @test Bool(r4048["is_internal"])
    @test !Bool(r4048["is_exchange"])

    report = validate_dfvb_artifacts(artifacts)
    critical = report.summary["critical_reactions"]
    @test critical["r_0001"]["partition"] == "exchange"
    @test critical["r_1992"]["partition"] == "internal"
    @test critical["r_2111"]["partition"] == "internal"
    @test critical["r_4048"]["partition"] == "internal"
    @test report.summary["r0001_used_as_oxygen"] == false
    @test report.summary["indices_reacciones_used"] == false
end
