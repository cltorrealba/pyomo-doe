using DataFrames

function _reduced_mpcc_frontier_test_viability_report(; all_green::Bool = false)
    lights = all_green ? ["green", "green", "green"] : ["green", "yellow", "red"]
    classes = all_green ?
              fill("simulation_viable_candidate", 3) :
              [
                  "simulation_viable_candidate",
                  "iteration_limit_residual_feasible_candidate",
                  "state_drift_too_large",
              ]
    table = DataFrame(
        "candidate_id" => ["candidate_001", "candidate_002", "candidate_003"],
        "source_type" => fill("solve_attempt_sweep", 3),
        "source_row_status" => fill("completed", 3),
        "traffic_light" => lights,
        "viability_class" => classes,
        "simulation_viable" => lights .== "green",
        "trajectory_ready" => [true, false, all_green],
        "residual_feasible" => fill(true, 3),
        "iteration_limit_residual_feasible" => [false, !all_green, false],
        "residual_thresholds_satisfied" => fill(true, 3),
        "residuals_pass" => fill(true, 3),
        "state_drift_pass" => [true, true, all_green],
        "global_state_drift_pass" => fill(true, 3),
        "guardrails_pass" => fill(true, 3),
        "window_continuation_pass" => fill(true, 3),
        "failed_source_row" => fill(false, 3),
        "blocking_reasons" => all_green ? fill("", 3) :
                              ["", "candidate_not_trajectory_ready", "state_drift_too_large"],
        "review_reasons" => all_green ? fill("full_dfba_cold_reference_deferred", 3) :
                            [
                                "full_dfba_cold_reference_deferred",
                                "iteration_limit_residual_feasible;full_dfba_cold_reference_deferred",
                                "full_dfba_cold_reference_deferred",
                            ],
        "horizon" => [0.5, 0.75, 1.0],
        "nfe" => [2, 3, 4],
        "degree" => fill(3, 3),
        "ipopt_max_iter" => fill(100, 3),
        "window_index" => fill(missing, 3),
        "window_hours" => fill(missing, 3),
        "boundary_dt" => fill(0.25, 3),
        "solver_status" => all_green ?
                           fill("LOCALLY_SOLVED", 3) :
                           ["LOCALLY_SOLVED", "ITERATION_LIMIT", "LOCALLY_SOLVED"],
        "primal_status" => fill("FEASIBLE_POINT", 3),
        "solve_elapsed_seconds" => [7.0, 20.0, 45.0],
        "max_rhs_residual" => fill(1.0e-12, 3),
        "max_mass_balance_residual" => fill(5.0e-7, 3),
        "max_lower_bound_violation" => zeros(3),
        "max_upper_bound_violation" => zeros(3),
        "max_stationarity_residual" => fill(1.0e-8, 3),
        "max_lower_complementarity_residual" => fill(5.0e-7, 3),
        "max_upper_complementarity_residual" => fill(4.0e-7, 3),
        "max_state_abs_difference" => all_green ? [7.0e-6, 8.0e-6, 9.0e-6] :
                                      [7.0e-6, 8.0e-6, 2.0e-1],
        "max_state_relative_rmse" => all_green ? [1.0e-2, 1.1e-2, 1.2e-2] :
                                     [1.0e-2, 1.1e-2, 3.0e-1],
        "global_max_state_abs_difference" => fill(missing, 3),
        "global_max_state_relative_rmse" => fill(missing, 3),
        "final_biomass_difference" => [1.0e-6, 2.0e-6, 3.0e-6],
        "final_total_sugar_difference" => [-1.0e-6, -2.0e-6, -3.0e-6],
        "next_recommended_action" => all_green ?
                                     fill("extract_candidate_trajectory", 3) :
                                     [
                                         "extract_candidate_trajectory",
                                         "review_iteration_limit_residual_feasible_candidate",
                                         "extract_candidate_trajectory",
                                     ],
        "full_dfba_cold_reference_deferred" => fill(true, 3),
        "reduced_full_equivalence_claimed" => fill(false, 3),
        "persistent_lp_baseline_used" => fill(false, 3),
        "hsl_required" => fill(false, 3),
        "ma57_required" => fill(false, 3),
        "indices_reacciones_used" => fill(false, 3),
        "r0001_used_as_oxygen" => fill(false, 3),
        "error_type" => fill(missing, 3),
        "error_message" => fill(missing, 3),
    )
    return ReducedDCDFBAMPCCSimulationViabilityReport(
        "solve_attempt_sweep",
        table,
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(),
        Dict{String, Any}(
            "viability_type" => "synthetic",
            "outputs_written" => false,
            "viability_report_is_scientific_simulation" => false,
            "solved_trajectory_claimed" => false,
        ),
    )
end

@testset "Reduced MPCC simulation viability frontier aggregation" begin
    report = _reduced_mpcc_frontier_test_viability_report()
    frontier = sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(report)
    table = frontier.frontier_table
    metadata = frontier.metadata

    @test frontier isa ReducedDCDFBAMPCCSimulationViabilityFrontierResult
    @test frontier.viability_reports == [report]
    @test isempty(frontier.sweep_results)
    @test size(table, 1) == 3
    @test table[1, "frontier_case_id"] == "frontier_001"
    @test table[1, "source_candidate_id"] == "candidate_001"
    @test table[1, "traffic_light"] == "green"
    @test table[1, "is_last_green"] == true
    @test table[2, "traffic_light"] == "yellow"
    @test table[2, "is_first_non_green_after_green"] == true
    @test table[2, "viability_class"] == "iteration_limit_residual_feasible_candidate"
    @test table[3, "traffic_light"] == "red"
    @test table[3, "is_first_non_green_after_green"] == false
    @test table[3, "n_collocation_points"] == 12
    @test table[1, "full_dfba_cold_reference_deferred"] == true
    @test table[1, "reduced_full_equivalence_claimed"] == false
    @test table[1, "persistent_lp_baseline_used"] == false
    @test table[1, "hsl_required"] == false
    @test table[1, "ma57_required"] == false
    @test table[1, "indices_reacciones_used"] == false
    @test table[1, "r0001_used_as_oxygen"] == false

    @test metadata["frontier_type"] == "reduced_dcdfba_mpcc_simulation_viability_frontier"
    @test metadata["n_cases"] == 3
    @test metadata["green_count"] == 1
    @test metadata["yellow_count"] == 1
    @test metadata["red_count"] == 1
    @test metadata["simulation_viable_case_count"] == 1
    @test metadata["last_green_case_id"] == "frontier_001"
    @test metadata["last_green_horizon"] == 0.5
    @test metadata["last_green_nfe"] == 2
    @test metadata["first_non_green_case_id"] == "frontier_002"
    @test metadata["first_non_green_horizon"] == 0.75
    @test metadata["first_non_green_viability_class"] ==
          "iteration_limit_residual_feasible_candidate"
    @test metadata["frontier_reached_green"] == true
    @test metadata["frontier_blocked"] == true
    @test metadata["all_requested_cases_green"] == false
    @test metadata["recommended_next_action"] == "improve_solver_termination_at_frontier"
    @test isapprox(metadata["total_solve_elapsed_seconds"], 72.0; atol = 1.0e-12)
    @test metadata["outputs_written"] == false
    @test metadata["frontier_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
end

@testset "Reduced MPCC simulation viability frontier all green" begin
    frontier = sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(
        _reduced_mpcc_frontier_test_viability_report(all_green = true),
    )

    @test all(==("green"), String.(frontier.frontier_table[!, "traffic_light"]))
    @test frontier.frontier_table[3, "is_last_green"] == true
    @test all(==(false), frontier.frontier_table[!, "is_first_non_green_after_green"])
    @test frontier.metadata["frontier_reached_green"] == true
    @test frontier.metadata["frontier_blocked"] == false
    @test frontier.metadata["all_requested_cases_green"] == true
    @test frontier.metadata["recommended_next_action"] == "extend_frontier_horizon"
end

@testset "Reduced MPCC simulation viability frontier validation" begin
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(
        ReducedDCDFBAMPCCSimulationViabilityReport[],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_frontier_specs(
        0.0,
        Float64[],
        0.25,
        nothing,
        3,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_frontier_specs(
        0.0,
        [0.75, 0.5],
        0.25,
        nothing,
        3,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_frontier_specs(
        0.0,
        [0.5],
        0.0,
        nothing,
        3,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_frontier_specs(
        0.0,
        [0.6],
        0.25,
        nothing,
        3,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_frontier_specs(
        0.0,
        [0.5, 1.0],
        0.25,
        [2],
        3,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_frontier_specs(
        0.0,
        [0.5],
        0.25,
        nothing,
        2,
    )
end

@testset "Reduced MPCC simulation viability frontier opt-in real run" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_FRONTIER", "0") == "1"
        project_root = normpath(joinpath(@__DIR__, ".."))
        model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        frontier = sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(
            model,
            reaction_map;
            horizons = [0.5],
            boundary_dt = 0.25,
            degree = 3,
        )

        @test frontier isa ReducedDCDFBAMPCCSimulationViabilityFrontierResult
        @test size(frontier.frontier_table, 1) == 1
        @test frontier.metadata["outputs_written"] == false
        @test frontier.metadata["frontier_is_scientific_simulation"] == false
        @test frontier.metadata["full_dfba_cold_reference_deferred"] == true
    else
        @info "Skipping reduced MPCC viability frontier real run; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_FRONTIER=1 to run it."
        @test true
    end
end
