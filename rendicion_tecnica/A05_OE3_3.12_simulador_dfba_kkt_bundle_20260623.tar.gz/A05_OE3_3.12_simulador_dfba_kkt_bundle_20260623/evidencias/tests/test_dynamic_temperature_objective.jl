@testset "Dynamic temperature objective schedule helpers" begin
    @test dynamic_temperature_control_value_count(horizon_h = 24.0, control_interval_h = 12.0) == 2
    @test dynamic_temperature_control_value_count(horizon_h = 168.0, control_interval_h = 12.0) == 14

    @test expand_temperature_decision_values(
        [20.0, 22.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
    ) == [20.0, 22.0]
    @test expand_temperature_decision_values(
        [22.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
        fixed_initial_temperature_C = 20.0,
    ) == [20.0, 22.0]

    @test_throws ArgumentError expand_temperature_decision_values(
        [20.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
    )

    schedule = temperature_control_schedule_from_values(
        [20.0, 22.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
        temperature_transition_width_h = 1.0,
    )
    @test schedule.temperature_transition_times_h == [12.0]
    @test schedule.temperature_values_C == [20.0, 22.0]
    @test isempty(schedule.fda_events)
    @test isempty(schedule.organic_events)
end

@testset "Dynamic temperature objective terms" begin
    schedule = temperature_control_schedule_from_values(
        [20.0, 22.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
    )
    weights = DynamicTemperatureObjectiveWeights(
        final_total_sugar_weight = 1.0,
        ethanol_reward_weight = 0.5,
        temperature_smoothness_weight = 0.25,
        temperature_move_weight = 0.1,
        reference_temperature_C = 20.0,
        negative_state_tolerance = 1.0e-9,
        incomplete_horizon_penalty_weight = 2.0,
        failure_penalty = 1000.0,
    )
    summary = Dict{String, Any}(
        "retcode" => "Success",
        "termination_reason" => "completed_tspan",
        "final_time" => 24.0,
        "final_total_sugar" => 50.0,
        "ethanol_produced" => 10.0,
        "min_state_value" => -1.0e-12,
    )

    terms = dynamic_temperature_objective_terms(summary, schedule; weights = weights, horizon_h = 24.0)
    @test terms["terminal_sugar"] == 50.0
    @test terms["ethanol_reward"] == -5.0
    @test terms["temperature_smoothness"] == 1.0
    @test terms["temperature_move"] == 0.4
    @test terms["negative_state_penalty"] == 0.0
    @test terms["incomplete_horizon_penalty"] == 0.0
    @test terms["failure_penalty"] == 0.0
    @test isapprox(dynamic_temperature_objective_value(terms), 46.4; atol = 1.0e-12)

    failed_summary = merge(
        summary,
        Dict{String, Any}(
            "retcode" => "Failure",
            "termination_reason" => "solver_error",
            "final_time" => 10.0,
            "min_state_value" => -2.0e-9,
        ),
    )
    failed_terms = dynamic_temperature_objective_terms(
        failed_summary,
        schedule;
        weights = weights,
        horizon_h = 24.0,
    )
    @test failed_terms["failure_penalty"] == 1000.0
    @test failed_terms["incomplete_horizon_penalty"] == 2.0 * 14.0^2
    @test failed_terms["negative_state_penalty"] > 0.0
end

@testset "Dynamic temperature objective terms from SimulationResult" begin
    states = zeros(19, 2)
    states[1, :] .= [0.5, 1.0]
    states[3, :] .= [110.0, 45.0]
    states[4, :] .= [110.0, 55.0]
    states[5, :] .= [0.0, 20.0]
    result = SimulationResult(
        [0.0, 24.0],
        states;
        metadata = Dict{String, Any}(
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "termination_time" => 24.0,
            "min_state_value" => 0.0,
            "has_negative_saved_states" => false,
        ),
    )
    schedule = temperature_control_schedule_from_values(
        [20.0, 20.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
    )
    terms = dynamic_temperature_objective_terms(result, schedule; horizon_h = 24.0)
    @test terms["terminal_sugar"] == 100.0
    @test terms["failure_penalty"] == 0.0
    @test terms["incomplete_horizon_penalty"] == 0.0
end

@testset "Dynamic temperature objective validation" begin
    @test_throws ArgumentError DynamicTemperatureObjectiveWeights(final_total_sugar_weight = -1.0)
    @test_throws ArgumentError DynamicTemperatureObjectiveWeights(reference_temperature_C = Inf)
    @test_throws ArgumentError temperature_control_schedule_from_values(
        [14.0, 20.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
    )
end
