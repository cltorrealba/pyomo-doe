using FermentationDFBA
using Test

import MathOptInterface as MOI

function _selection_policy_candidate(; trajectory_ready::Bool, source::String)
    state_boundary = zeros(19, 2)
    state_boundary[1, :] .= [0.5, 0.6]
    state_boundary[2, :] .= [0.1, 0.09]
    state_boundary[3, :] .= [75.0, 74.5]
    state_boundary[4, :] .= [75.0, 74.7]
    state_boundary[5, :] .= [0.0, 0.2]
    state_collocation = repeat(state_boundary[:, 2:2], 1, 1, 3)
    state_derivative = zeros(19, 1, 3)
    flux = zeros(2, 1, 3)
    lower_duals = zeros(2, 1, 3)
    upper_duals = zeros(2, 1, 3)
    mass_duals = zeros(1, 1, 3)
    residual_values = Dict{String, Float64}(
        "max_rhs_residual" => 1.0e-10,
        "max_collocation_integration_residual" => 2.0e-7,
        "max_continuity_residual" => 2.0e-7,
        "max_initial_condition_residual" => 0.0,
        "max_mass_balance_residual" => 3.0e-7,
        "max_stationarity_residual" => 1.0e-10,
        "max_lower_complementarity_residual" => 1.0e-7,
        "max_upper_complementarity_residual" => 0.0,
    )
    residual_thresholds = Dict{String, Float64}(
        "max_rhs_residual" => 1.0e-6,
        "max_collocation_integration_residual" => 1.0e-6,
        "max_continuity_residual" => 1.0e-6,
        "max_initial_condition_residual" => 1.0e-6,
        "max_mass_balance_residual" => 5.0e-6,
        "max_stationarity_residual" => 1.0e-5,
        "max_lower_complementarity_residual" => 1.0e-5,
        "max_upper_complementarity_residual" => 1.0e-5,
    )
    residual_ratios = Dict(
        key => value / residual_thresholds[key] for (key, value) in residual_values
    )
    metadata = Dict{String, Any}(
        "candidate_values_source" => source,
        "candidate_value_source" => source,
        "candidate_solver_status" => trajectory_ready ? "START_VALUES" : "ITERATION_LIMIT",
        "candidate_primal_status" => "FEASIBLE_POINT",
        "candidate_residual_feasible" => true,
        "candidate_residual_thresholds_satisfied" => true,
        "candidate_iteration_limit_residual_feasible" => !trajectory_ready,
        "candidate_trajectory_extraction_ready" => trajectory_ready,
        "trajectory_candidate_ready" => trajectory_ready,
        "candidate_dominant_residual" => "max_mass_balance_residual",
        "candidate_boundary_times" => [0.0, 1.0],
        "candidate_collocation_times" => [0.25, 0.5, 0.75],
        "candidate_grid_nfe" => 1,
        "candidate_collocation_degree" => 3,
        "candidate_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
    )
    return ReducedDCDFBAMPCCCandidateDiagnostics(
        state_boundary,
        state_collocation,
        state_derivative,
        flux,
        lower_duals,
        upper_duals,
        mass_duals,
        residual_values,
        residual_thresholds,
        residual_ratios,
        collect(keys(residual_values)),
        String[],
        metadata,
    )
end

function _selection_policy_trajectory(candidate)
    state_names = [
        "biomass",
        "nitrogen",
        "glucose",
        "fructose",
        "ethanol",
        "oxygen",
        "protein",
        "carbohydrate",
        "phenylalanine",
        "leucine",
        "valine",
        "methionine",
        "tyrosine",
        "phenylethanol",
        "isoamyl_alcohol",
        "isobutanol",
        "methionol",
        "tyrosol",
        "ethyl_acetate",
    ]
    boundary = SimulationResult(
        [0.0, 1.0],
        candidate.state_boundary;
        metadata = Dict{String, Any}(
            "model_scope" => "reduced",
            "state_names" => state_names,
            "retcode" => candidate.metadata["candidate_solver_status"],
            "termination_reason" => "selection_policy_test",
            "is_scientific_simulation" => false,
        ),
    )
    collocation = SimulationResult(
        [0.25, 0.5, 0.75],
        reshape(candidate.state_collocation, 19, 3);
        metadata = copy(boundary.metadata),
    )
    return ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary,
        collocation,
        candidate,
        copy(candidate.metadata),
    )
end

@testset "Global polish selection can require post-solve trajectory readiness" begin
    sequential = SimulationResult(
        [0.0, 1.0],
        _selection_policy_candidate(
            trajectory_ready = true,
            source = "sequential_reference",
        ).state_boundary;
        metadata = Dict{String, Any}(
            "model_scope" => "reduced",
            "state_names" => _selection_policy_trajectory(
                _selection_policy_candidate(
                    trajectory_ready = true,
                    source = "pre_solve_start_values",
                ),
            ).boundary_result.metadata["state_names"],
            "retcode" => "Success",
            "termination_reason" => "selection_policy_test_reference",
        ),
    )
    start_candidate = _selection_policy_candidate(
        trajectory_ready = true,
        source = "pre_solve_start_values",
    )
    polish_candidate = _selection_policy_candidate(
        trajectory_ready = false,
        source = "post_solve_values",
    )
    polish_trajectory = _selection_policy_trajectory(polish_candidate)
    polish_comparison =
        compare_reduced_dcdfba_mpcc_to_sequential(sequential, polish_trajectory)
    residual_report = Dict{String, Any}(
        "residuals_available" => true,
        "residual_thresholds_satisfied" => true,
    )
    merge!(residual_report, polish_candidate.residual_values)
    solve_attempt = ReducedDCDFBAMPCCSolveAttemptResult(
        ReducedDCDFBAMPCCSmokeResult(
            MOI.ITERATION_LIMIT,
            MOI.FEASIBLE_POINT,
            NaN,
            3.0e-7,
            0.0,
            0.0,
            1.0e-10,
            1.0e-7,
            0.0,
            "Ipopt",
            0.0,
            Dict{String, Any}(),
        ),
        default_reduced_dcdfba_mpcc_residual_thresholds(),
        true,
        true,
        residual_report,
        Dict{String, Any}(
            "solver_status" => "ITERATION_LIMIT",
            "primal_status" => "FEASIBLE_POINT",
        ),
        polish_candidate,
    )

    selected = FermentationDFBA._reduced_mpcc_global_polish_select_accepted_candidate(
        start_candidate,
        solve_attempt,
        polish_trajectory,
        polish_comparison,
        sequential;
        biological_acceptance_enabled = true,
        accept_post_solve_requires_trajectory_ready = true,
    )

    @test selected.candidate === start_candidate
    @test selected.metadata["post_solve_candidate_residual_feasible"] == true
    @test selected.metadata["post_solve_candidate_trajectory_ready"] == false
    @test selected.metadata["selected_candidate_residual_feasible"] == true
    @test selected.metadata["selected_candidate_trajectory_ready"] == true
    @test selected.metadata["candidate_selection_reason"] ==
          "post_solve_candidate_not_trajectory_ready_fallback_to_pre_solve_start"
end
