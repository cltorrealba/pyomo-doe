import MathOptInterface as MOI

const REDUCED_MPCC_SWEEP_TEST_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _reduced_mpcc_sweep_test_states(times::AbstractVector)
    n_time = length(times)
    states = zeros(19, n_time)
    final_time = last(times)
    for (k, time) in enumerate(times)
        theta = final_time == 0.0 ? 0.0 : time / final_time
        states[1, k] = 1.0 + 0.2 * theta
        states[2, k] = 0.1 - 0.02 * theta
        states[3, k] = 10.0 - theta
        states[4, k] = 8.0 - 0.5 * theta
        states[5, k] = 0.4 * theta
        states[6, k] = 0.0
        states[7, k] = 0.2 + 0.01 * theta
        states[8, k] = 0.1 + 0.01 * theta
        states[9:19, k] .= 0.01
    end
    return states
end

function _reduced_mpcc_sweep_test_comparison(;
    horizon::Float64,
    nfe::Int,
    biomass_offset::Float64,
    residual_scale::Float64,
    solve_elapsed_seconds::Float64,
)
    times = collect(range(0.0, horizon; length = nfe + 1))
    sequential_states = _reduced_mpcc_sweep_test_states(times)
    candidate_states = copy(sequential_states)
    sugar_offset_scale = biomass_offset / 0.01
    for (k, time) in enumerate(times)
        theta = horizon == 0.0 ? 0.0 : time / horizon
        candidate_states[1, k] += biomass_offset * theta
        candidate_states[3, k] -= 0.2 * sugar_offset_scale * theta
        candidate_states[4, k] -= 0.1 * sugar_offset_scale * theta
        candidate_states[5, k] += 0.03 * theta
    end

    sequential = SimulationResult(
        times,
        sequential_states;
        metadata = Dict{String, Any}(
            "model_id" => "synthetic_reduced_sequential",
            "model_scope" => "reduced",
            "state_names" => copy(REDUCED_MPCC_SWEEP_TEST_STATE_NAMES),
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "mode_history" => Symbol[],
            "mass_balance_residuals" => Float64[],
            "max_lower_bound_violations" => Float64[],
            "max_upper_bound_violations" => Float64[],
            "min_state_value" => minimum(sequential_states),
            "has_negative_saved_states" => false,
            "reconstruct_fluxes" => false,
        ),
    )
    boundary = SimulationResult(
        times,
        candidate_states;
        metadata = Dict{String, Any}(
            "model_id" => "synthetic_reduced_mpcc",
            "model_scope" => "reduced",
            "state_names" => copy(REDUCED_MPCC_SWEEP_TEST_STATE_NAMES),
            "retcode" => "ITERATION_LIMIT",
            "termination_reason" => "mpcc_candidate_diagnostic_only_solver_status_blocks_trajectory",
            "is_scientific_simulation" => false,
            "min_state_value" => minimum(candidate_states),
        ),
    )
    collocation = SimulationResult(
        collect(range(0.0, horizon; length = nfe * 3)),
        repeat(candidate_states[:, end:end], 1, nfe * 3);
        metadata = copy(boundary.metadata),
    )
    residuals = Dict{String, Float64}(
        "max_rhs_residual" => 1.0e-12 * residual_scale,
        "max_mass_balance_residual" => 1.0e-7 * residual_scale,
        "max_lower_bound_violation" => 0.0,
        "max_upper_bound_violation" => 0.0,
        "max_stationarity_residual" => 1.0e-8 * residual_scale,
        "max_lower_complementarity_residual" => 1.0e-7 * residual_scale,
        "max_upper_complementarity_residual" => 1.0e-7 * residual_scale,
    )
    candidate_metadata = Dict{String, Any}(
        "candidate_solver_status" => "ITERATION_LIMIT",
        "candidate_primal_status" => "FEASIBLE_POINT",
        "candidate_residual_thresholds_satisfied" => true,
        "candidate_residual_feasible" => true,
        "candidate_iteration_limit_residual_feasible" => true,
        "candidate_warning_count" => 2,
        "candidate_dominant_residual" => "max_mass_balance_residual",
        "trajectory_candidate_ready" => false,
        "trajectory_candidate_is_scientific_simulation" => false,
        "trajectory_candidate_is_validated_simulation" => false,
        "trajectory_candidate_solved_trajectory_claimed" => false,
        "post_solve_next_recommended_action" =>
            "review_iteration_limit_residual_feasible_candidate",
        "solve_elapsed_seconds" => solve_elapsed_seconds,
        "candidate_grid_nfe" => nfe,
        "candidate_collocation_degree" => 3,
        "candidate_grid_tspan" => (0.0, horizon),
    )
    diagnostics = ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(candidate_states),
        zeros(19, nfe, 3),
        zeros(19, nfe, 3),
        zeros(2, nfe, 3),
        zeros(2, nfe, 3),
        zeros(2, nfe, 3),
        zeros(1, nfe, 3),
        residuals,
        Dict{String, Float64}(),
        Dict{String, Float64}(),
        String[],
        ["candidate_solver_status_blocks_trajectory_extraction"],
        copy(candidate_metadata),
    )
    trajectory = ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary,
        collocation,
        diagnostics,
        copy(candidate_metadata),
    )
    return compare_reduced_dcdfba_mpcc_to_sequential(sequential, trajectory)
end

@testset "Reduced MPCC solve-attempt metadata merge keeps cross-window seed diagnostics" begin
    comparison = _reduced_mpcc_sweep_test_comparison(
        horizon = 0.25,
        nfe = 1,
        biomass_offset = 0.0,
        residual_scale = 1.0,
        solve_elapsed_seconds = 1.0,
    )
    solve_metadata = Dict{String, Any}(
        "cross_window_flux_dual_start_applied" => true,
        "cross_window_flux_dual_start_policy" =>
            "previous_window_final_collocation_flux_duals_constant_over_target_window",
        "cross_window_flux_dual_start_source" => "previous_window_candidate",
        "cross_window_flux_dual_start_source_stage_index" => 3,
        "cross_window_flux_dual_start_source_tau" => 1.0e-6,
        "cross_window_flux_dual_start_source_solver_status" => "LOCALLY_SOLVED",
        "cross_window_flux_dual_start_source_residual_feasible" => true,
        "cross_window_flux_dual_start_max_flux_projection_adjustment" => 2.0e-5,
        "cross_window_flux_dual_start_max_lower_dual_sign_clipping" => 3.0e-6,
        "cross_window_flux_dual_start_max_upper_dual_sign_clipping" => 4.0e-6,
        "cross_window_flux_dual_start_rhs_derivatives_refreshed" => true,
    )
    smoke = ReducedDCDFBAMPCCSmokeResult(
        MOI.LOCALLY_SOLVED,
        MOI.FEASIBLE_POINT,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        "Ipopt",
        0.0,
        Dict{String, Any}(),
    )
    solve_attempt = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke,
        default_reduced_dcdfba_mpcc_residual_thresholds(),
        true,
        true,
        Dict{String, Any}(),
        solve_metadata,
        comparison.trajectory_candidate.candidate_diagnostics,
    )

    FermentationDFBA._reduced_mpcc_sweep_merge_solve_attempt_metadata!(
        comparison,
        solve_attempt,
    )

    @test comparison.metadata["cross_window_flux_dual_start_applied"] == true
    @test comparison.metadata["cross_window_flux_dual_start_source_tau"] == 1.0e-6
    @test comparison.metadata["cross_window_flux_dual_start_max_flux_projection_adjustment"] ==
          2.0e-5
    @test comparison.trajectory_candidate.metadata["cross_window_flux_dual_start_applied"] ==
          true
    @test comparison.trajectory_candidate.candidate_diagnostics.metadata["cross_window_flux_dual_start_source_stage_index"] ==
          3
end

@testset "Reduced MPCC solve-attempt sweep synthetic summary" begin
    comparisons = [
        _reduced_mpcc_sweep_test_comparison(
            horizon = 0.25,
            nfe = 1,
            biomass_offset = 0.01,
            residual_scale = 1.0,
            solve_elapsed_seconds = 1.5,
        ),
        _reduced_mpcc_sweep_test_comparison(
            horizon = 0.5,
            nfe = 2,
            biomass_offset = 0.04,
            residual_scale = 2.0,
            solve_elapsed_seconds = 3.0,
        ),
    ]

    sweep = sweep_reduced_dcdfba_mpcc_solve_attempts(comparisons)
    table = sweep.scenario_table
    metadata = sweep.metadata

    @test sweep isa ReducedDCDFBAMPCCSolveAttemptSweepResult
    @test sweep.comparison_results == comparisons
    @test size(table, 1) == 2
    @test table[1, "scenario_id"] == "scenario_001"
    @test table[2, "scenario_id"] == "scenario_002"
    @test table[1, "scenario_status"] == "completed"
    @test table[1, "horizon"] == 0.25
    @test table[2, "nfe"] == 2
    @test table[2, "n_collocation_points"] == 6
    @test table[1, "solver_status"] == "ITERATION_LIMIT"
    @test table[1, "primal_status"] == "FEASIBLE_POINT"
    @test table[1, "candidate_residual_feasible"] == true
    @test table[1, "candidate_iteration_limit_residual_feasible"] == true
    @test table[1, "candidate_trajectory_ready"] == false
    @test table[1, "candidate_is_scientific_simulation"] == false
    @test table[1, "residual_thresholds_satisfied"] == true
    @test table[1, "next_recommended_action"] ==
          "review_iteration_limit_residual_feasible_candidate"
    @test table[2, "max_mass_balance_residual"] == 2.0e-7
    @test isapprox(table[1, "final_biomass_difference"], 0.01; atol = 1.0e-12)
    @test isapprox(table[1, "final_total_sugar_difference"], -0.3; atol = 1.0e-12)
    @test table[1, "full_dfba_cold_reference_deferred"] == true
    @test table[1, "reduced_full_equivalence_claimed"] == false
    @test table[1, "persistent_lp_baseline_used"] == false
    @test table[1, "indices_reacciones_used"] == false
    @test table[1, "r0001_used_as_oxygen"] == false

    @test metadata["sweep_type"] ==
          "reduced_dcdfba_mpcc_solve_attempt_short_horizon_sweep"
    @test metadata["n_scenarios"] == 2
    @test metadata["n_completed_scenarios"] == 2
    @test metadata["n_failed_scenarios"] == 0
    @test metadata["residual_feasible_scenario_count"] == 2
    @test metadata["iteration_limit_residual_feasible_scenario_count"] == 2
    @test metadata["trajectory_ready_scenario_count"] == 0
    @test metadata["best_state_match_scenario_id"] == "scenario_001"
    @test metadata["outputs_written"] == false
    @test metadata["sweep_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["scientific_baseline"] == "full_dfba_cold_deferred"
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
end

@testset "Reduced MPCC solve-attempt sweep validation" begin
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_solve_attempts(
        ReducedDCDFBAMPCCSequentialComparisonResult[],
    )
end

@testset "Reduced MPCC solve-attempt sweep opt-in real run" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_SWEEP", "0") == "1"
        project_root = normpath(joinpath(@__DIR__, ".."))
        model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        sweep = sweep_reduced_dcdfba_mpcc_solve_attempts(
            model,
            reaction_map;
            horizons = [0.25],
            nfe_values = [1],
            degree = 3,
        )

        @test sweep isa ReducedDCDFBAMPCCSolveAttemptSweepResult
        @test size(sweep.scenario_table, 1) == 1
        @test sweep.metadata["n_completed_scenarios"] == 1
        @test sweep.scenario_table[1, "candidate_is_scientific_simulation"] == false
        @test sweep.scenario_table[1, "full_dfba_cold_reference_deferred"] == true
    else
        @info "Skipping reduced MPCC solve-attempt sweep real run; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_SWEEP=1 to run it."
        @test true
    end
end
