import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_mpcc_trajectory_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_mpcc_trajectory_test_simulation()
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    return SimulationResult(
        [0.0, 0.25],
        hcat(initial_state, initial_state);
        fluxes = reshape([0.02, 0.02], 1, 2),
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

function _reduced_dcdfba_mpcc_trajectory_test_problem()
    model, reaction_map = _reduced_dcdfba_mpcc_trajectory_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_trajectory_test_simulation()
    return build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
end

function _reduced_dcdfba_mpcc_trajectory_test_values(problem)
    smoke = problem.smoke_problem
    return (
        state_boundary = Float64.(JuMP.start_value.(smoke.nlp.state_boundary)),
        state_collocation = Float64.(JuMP.start_value.(smoke.nlp.state_collocation)),
        state_derivative = Float64.(JuMP.start_value.(smoke.nlp.state_derivative)),
        flux = Float64.(JuMP.start_value.(smoke.nlp.flux)),
        lower_bound_duals = Float64.(JuMP.start_value.(smoke.bound_feasibility.lower_bound_duals)),
        upper_bound_duals = Float64.(JuMP.start_value.(smoke.bound_feasibility.upper_bound_duals)),
        mass_balance_duals = Float64.(JuMP.start_value.(smoke.stationarity.mass_balance_duals)),
    )
end

function _reduced_dcdfba_mpcc_trajectory_test_candidate(
    status::MOI.TerminationStatusCode,
    primal_status::MOI.ResultStatusCode,
)
    problem = _reduced_dcdfba_mpcc_trajectory_test_problem()
    smoke_result = ReducedDCDFBAMPCCSmokeResult(
        status,
        primal_status,
        NaN,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        "Ipopt",
        0.0,
        Dict{String, Any}(),
    )
    candidate = FermentationDFBA._reduced_dcdfba_mpcc_candidate_diagnostics_from_values(
        problem.smoke_problem,
        smoke_result,
        problem.residual_thresholds,
        _reduced_dcdfba_mpcc_trajectory_test_values(problem),
        "unit_test_start_values",
    )
    return problem, candidate, smoke_result
end

@testset "Reduced DC-dFBA MPCC guarded trajectory candidate extraction" begin
    problem, candidate, smoke_result = _reduced_dcdfba_mpcc_trajectory_test_candidate(
        MOI.ITERATION_LIMIT,
        MOI.NEARLY_FEASIBLE_POINT,
    )
    trajectory = extract_reduced_dcdfba_mpcc_trajectory_candidate(candidate)

    @test trajectory isa ReducedDCDFBAMPCCTrajectoryCandidate
    @test trajectory.candidate_diagnostics === candidate
    @test trajectory.boundary_result isa SimulationResult
    @test trajectory.collocation_result isa SimulationResult
    @test trajectory.boundary_result.fluxes === nothing
    @test trajectory.collocation_result.fluxes === nothing
    @test trajectory.boundary_result.alphas === nothing
    @test trajectory.collocation_result.alphas === nothing

    grid = problem.smoke_problem.nlp.kkt_problem.grid
    @test trajectory.boundary_result.time == [0.0, 0.25]
    @test trajectory.collocation_result.time == vec(grid.collocation_times[1, :])
    @test trajectory.boundary_result.states == candidate.state_boundary
    for j in 1:grid.scheme.degree
        @test trajectory.collocation_result.states[:, j] == candidate.state_collocation[:, 1, j]
    end

    metadata = trajectory.metadata
    @test metadata["problem_type"] == "reduced_dcdfba_mpcc_trajectory_candidate"
    @test metadata["trajectory_candidate_extraction_performed"] == true
    @test metadata["trajectory_candidate_ready"] == false
    @test metadata["trajectory_candidate_extracted_despite_not_ready"] == true
    @test metadata["trajectory_candidate_is_scientific_simulation"] == false
    @test metadata["trajectory_candidate_is_validated_simulation"] == false
    @test metadata["trajectory_candidate_solved_trajectory_claimed"] == false
    @test metadata["trajectory_candidate_boundary_result_has_fluxes"] == false
    @test metadata["trajectory_candidate_collocation_result_has_fluxes"] == false
    @test metadata["trajectory_candidate_flux_storage"] == "candidate_diagnostics.flux"
    @test metadata["trajectory_candidate_full_flux_vector_available"] == true
    @test metadata["trajectory_candidate_flux_export_deferred"] == true
    @test metadata["model_scope"] == "reduced"
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["candidate_contains_r0001_flux"] == true
    @test metadata["candidate_contains_r1992_flux"] == false
    @test length(metadata["mpcc_candidate_flux_rxn_ids"]) == 1488

    @test trajectory.boundary_result.metadata["trajectory_candidate_result_kind"] ==
          "finite_element_boundary_states"
    @test trajectory.collocation_result.metadata["trajectory_candidate_result_kind"] ==
          "radau_collocation_states"
    @test trajectory.boundary_result.metadata["is_scientific_simulation"] == false
    @test trajectory.collocation_result.metadata["is_scientific_simulation"] == false
    @test trajectory.boundary_result.metadata["state_names"] == metadata["state_names"]
    @test trajectory.collocation_result.metadata["state_names"] == metadata["state_names"]

    @test size(simulation_states_table(trajectory.boundary_result), 1) == 2
    @test size(simulation_states_table(trajectory.collocation_result), 1) == 3
    @test simulation_fluxes_table(trajectory.boundary_result) === nothing
    @test simulation_fluxes_table(trajectory.collocation_result) === nothing
    @test summarize_simulation(trajectory.boundary_result)["model_scope"] == "reduced"
    @test_throws ArgumentError extract_reduced_dcdfba_mpcc_trajectory_candidate(
        candidate;
        require_trajectory_ready = true,
    )

    wrapped = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        problem.residual_thresholds,
        true,
        true,
        Dict{String, Any}("max_rhs_residual" => candidate.residual_values["max_rhs_residual"]),
        copy(candidate.metadata),
        candidate,
    )
    @test extract_reduced_dcdfba_mpcc_trajectory_candidate(wrapped).candidate_diagnostics === candidate
end

@testset "Reduced DC-dFBA MPCC trajectory-ready candidate extraction" begin
    _, candidate, _ = _reduced_dcdfba_mpcc_trajectory_test_candidate(
        MOI.LOCALLY_SOLVED,
        MOI.FEASIBLE_POINT,
    )
    trajectory = extract_reduced_dcdfba_mpcc_trajectory_candidate(
        candidate;
        require_trajectory_ready = true,
    )

    @test trajectory.metadata["trajectory_candidate_ready"] == true
    @test trajectory.metadata["trajectory_candidate_extracted_despite_not_ready"] == false
    @test trajectory.metadata["termination_reason"] == "mpcc_candidate_trajectory_ready"
    @test trajectory.boundary_result.metadata["trajectory_candidate_ready"] == true
    @test trajectory.collocation_result.metadata["trajectory_candidate_ready"] == true
    @test trajectory.metadata["trajectory_candidate_is_scientific_simulation"] == false
    @test trajectory.metadata["solved_trajectory_claimed"] == false
end

@testset "Reduced DC-dFBA MPCC trajectory candidate opt-in solve" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_DYNAMIC_SOLVE", "0") == "1"
        model, reaction_map = _reduced_dcdfba_mpcc_trajectory_test_model_and_map()
        simulation = _reduced_dcdfba_mpcc_trajectory_test_simulation()
        result = solve_reduced_dcdfba_mpcc_solve_attempt(
            model,
            reaction_map;
            sequential_initialization = simulation,
        )
        trajectory = extract_reduced_dcdfba_mpcc_trajectory_candidate(result)

        @test trajectory.boundary_result.metadata["trajectory_candidate_is_scientific_simulation"] == false
        @test trajectory.metadata["trajectory_candidate_ready"] ==
              result.metadata["candidate_trajectory_extraction_ready"]
        @test trajectory.metadata["candidate_residual_feasible"] ==
              result.metadata["candidate_residual_feasible"]
        @test length(trajectory.boundary_result.time) == result.candidate_diagnostics.metadata["candidate_grid_nfe"] + 1
    else
        @info "Skipping reduced MPCC trajectory candidate opt-in solve; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_DYNAMIC_SOLVE=1 to run it."
        @test true
    end
end
