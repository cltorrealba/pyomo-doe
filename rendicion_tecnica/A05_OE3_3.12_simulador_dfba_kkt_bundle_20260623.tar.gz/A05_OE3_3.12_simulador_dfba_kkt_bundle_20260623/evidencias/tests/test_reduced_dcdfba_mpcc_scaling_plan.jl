import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_mpcc_scaling_plan_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_mpcc_scaling_plan_test_simulation()
    time = [0.0, 0.25]
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    states = hcat(initial_state, initial_state)
    fluxes = reshape([0.02, 0.02], 1, 2)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

function _reduced_dcdfba_mpcc_scaling_plan_test_problem()
    model, reaction_map = _reduced_dcdfba_mpcc_scaling_plan_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_scaling_plan_test_simulation()
    return build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
end

@testset "Reduced DC-dFBA MPCC scaling plan contract" begin
    problem = _reduced_dcdfba_mpcc_scaling_plan_test_problem()
    plan = build_reduced_dcdfba_mpcc_scaling_plan(problem)

    @test plan isa ReducedDCDFBAMPCCScalingPlan
    @test all(block -> block isa ReducedDCDFBAMPCCScaleBlock, values(plan.variable_blocks))
    @test all(block -> block isa ReducedDCDFBAMPCCScaleBlock, values(plan.constraint_blocks))
    @test sort(collect(keys(plan.variable_blocks))) == sort([
        "flux",
        "lower_bound_dual",
        "mass_balance_dual",
        "state_boundary",
        "state_collocation",
        "state_derivative",
        "upper_bound_dual",
    ])
    @test sort(collect(keys(plan.constraint_blocks))) == sort([
        "collocation_integration",
        "continuity",
        "initial_condition",
        "lower_bound",
        "lower_complementarity",
        "mass_balance",
        "rhs",
        "stationarity",
        "upper_bound",
        "upper_complementarity",
    ])
    @test all(isfinite, values(plan.variable_scale_factors))
    @test all(isfinite, values(plan.constraint_scale_factors))
    @test all(value -> value > 0.0, values(plan.variable_scale_factors))
    @test all(value -> value > 0.0, values(plan.constraint_scale_factors))
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA MPCC scaling plan magnitudes" begin
    problem = _reduced_dcdfba_mpcc_scaling_plan_test_problem()
    plan = build_reduced_dcdfba_mpcc_scaling_plan(problem)

    flux_block = plan.variable_blocks["flux"]
    state_block = plan.variable_blocks["state_collocation"]
    derivative_block = plan.variable_blocks["state_derivative"]
    mass_dual_block = plan.variable_blocks["mass_balance_dual"]

    @test flux_block.abs_max == 1000.0
    @test flux_block.positive_scale_spread > 1.0e6
    @test isapprox(flux_block.recommended_scale, 1.0e-3; atol = 0.0, rtol = 1.0e-12)
    @test isapprox(flux_block.scaled_abs_max, 1.0; atol = 0.0, rtol = 1.0e-12)
    @test state_block.recommended_scale > 0.0
    @test state_block.scaled_abs_max <= 1.0 + 1.0e-12
    @test derivative_block.recommended_scale > 1.0
    @test mass_dual_block.recommended_scale > 0.0
    @test mass_dual_block.scaled_abs_max <= 1.0 + 1.0e-12

    @test plan.constraint_blocks["collocation_integration"].abs_max <= 1.0e-9
    @test plan.constraint_blocks["continuity"].abs_max <= 1.0e-9
    @test plan.constraint_blocks["initial_condition"].abs_max == 0.0
    @test plan.constraint_blocks["rhs"].abs_max <= 1.0e-12
    @test plan.constraint_blocks["mass_balance"].abs_max <= 1.0e-8
    @test plan.constraint_blocks["stationarity"].abs_max <= 1.0e-10
    @test plan.constraint_blocks["lower_complementarity"].abs_max <= 1.0e-12
    @test plan.constraint_blocks["upper_complementarity"].abs_max <= 1.0e-12
end

@testset "Reduced DC-dFBA MPCC scaling plan metadata and warnings" begin
    problem = _reduced_dcdfba_mpcc_scaling_plan_test_problem()
    plan = build_reduced_dcdfba_mpcc_scaling_plan(problem)
    metadata = plan.metadata

    @test metadata["problem_type"] == "reduced_dcdfba_mpcc_scaling_plan"
    @test metadata["problem_scope"] == "pre_solve_reduced_mpcc_scaling_diagnostics"
    @test metadata["scaling_plan_built"] == true
    @test metadata["scaling_plan_mutates_model"] == false
    @test metadata["scaling_plan_calls_solver"] == false
    @test metadata["solver_call_performed"] == false
    @test metadata["ipopt_user_scaling_applied"] == false
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["scaling_variable_block_count"] == 7
    @test metadata["scaling_constraint_block_count"] == 10
    @test metadata["scaling_warning_count"] == length(plan.warnings)
    @test metadata["scaling_blocking_warning_count"] == 0
    @test metadata["scaling_review_warning_count"] == length(plan.warnings)
    @test isempty(metadata["scaling_blocking_warnings"])
    @test sort(metadata["scaling_review_warnings"]) == sort(plan.warnings)
    @test metadata["scaling_positive_scale_spread_warning_policy"] ==
          "review_only_after_block_scale_factors"
    @test metadata["scaling_flux_variable_positive_scale_spread"] > 1.0e6
    @test metadata["scaling_collocation_integration_abs_max"] <= 1.0e-9
    @test metadata["scaling_continuity_abs_max"] <= 1.0e-9
    @test metadata["scaling_initial_condition_abs_max"] == 0.0
    @test metadata["scaling_plan_ready_for_guarded_solve_attempt"] == true
    @test metadata["scaling_plan_is_scientific_simulation"] == false

    @test "scaling_plan_flux_variable_positive_scale_spread_large" in plan.warnings
    @test "scaling_plan_state_collocation_positive_scale_spread_large" in plan.warnings
    @test !("collocation_integration_start_residual_large" in plan.warnings)
    @test !("continuity_start_residual_large" in plan.warnings)
end

@testset "Reduced DC-dFBA MPCC diagnostics include scaling plan summary" begin
    problem = _reduced_dcdfba_mpcc_scaling_plan_test_problem()
    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)

    @test report.residual_thresholds_satisfied == true
    @test report.scaling_summary["scaling_plan_variable_block_count"] == 7.0
    @test report.scaling_summary["scaling_plan_constraint_block_count"] == 10.0
    @test report.scaling_summary["scaling_plan_blocking_warning_count"] == 0.0
    @test report.scaling_summary["scaling_plan_review_warning_count"] ==
          report.scaling_summary["scaling_plan_warning_count"]
    @test report.scaling_summary["scaling_plan_ready_for_guarded_solve_attempt"] == 1.0
    @test report.scaling_summary["scaling_plan_flux_variable_recommended_scale"] == 1.0e-3
    @test report.scaling_summary["scaling_plan_flux_variable_scaled_abs_max"] <= 1.0 + 1.0e-12
    @test report.scaling_summary["scaling_plan_flux_variable_positive_scale_spread"] > 1.0e6
    @test report.scaling_summary["scaling_plan_state_collocation_scaled_abs_max"] <= 1.0 + 1.0e-12
    @test report.scaling_summary["scaling_plan_state_derivative_scaled_abs_max"] <= 1.0 + 1.0e-12
    @test report.scaling_summary["scaling_plan_mass_balance_dual_scaled_abs_max"] <= 1.0 + 1.0e-12
    @test report.scaling_summary["scaling_plan_collocation_integration_abs_max"] <= 1.0e-9
    @test report.scaling_summary["scaling_plan_continuity_abs_max"] <= 1.0e-9
    @test report.scaling_summary["scaling_plan_rhs_abs_max"] <= 1.0e-12
    @test report.scaling_summary["scaling_plan_mass_balance_abs_max"] <= 1.0e-8
    @test report.scaling_summary["scaling_plan_stationarity_abs_max"] <= 1.0e-10
    @test report.scaling_summary["scaling_plan_max_variable_scaled_abs_max"] <= 1.0 + 1.0e-12
    @test report.scaling_summary["scaling_plan_max_constraint_scaled_abs_max"] <= 1.0 + 1.0e-12
    @test report.metadata["scaling_plan_ready_for_guarded_solve_attempt"] == true
    @test report.metadata["scaling_blocking_warning_count"] == 0
    @test report.metadata["scaling_positive_scale_spread_warning_policy"] ==
          "review_only_after_block_scale_factors"
    @test "scaling_plan_flux_variable_positive_scale_spread_large" in report.warnings
    @test !("collocation_integration_start_residual_large" in report.warnings)
    @test !("continuity_start_residual_large" in report.warnings)
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA MPCC scaling plan validation" begin
    problem = _reduced_dcdfba_mpcc_scaling_plan_test_problem()
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_scaling_plan(
        problem;
        target_abs_max = 0.0,
    )
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_scaling_plan(
        problem;
        min_scale = 0.0,
    )
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_scaling_plan(
        problem;
        min_scale = 10.0,
        max_scale = 1.0,
    )
end
