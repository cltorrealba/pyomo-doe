using DataFrames

function _reduced_mpcc_viability_test_sweep()
    table = DataFrame(
        "scenario_id" => ["scenario_green", "scenario_yellow", "scenario_red"],
        "scenario_status" => ["completed", "completed", "completed"],
        "t0" => [0.0, 0.0, 0.0],
        "tfinal" => [0.5, 1.0, 0.5],
        "horizon" => [0.5, 1.0, 0.5],
        "nfe" => [2, 2, 1],
        "degree" => fill(3, 3),
        "boundary_dt" => [0.25, 0.5, 0.5],
        "n_boundary_points" => [3, 3, 2],
        "n_collocation_points" => [6, 6, 3],
        "solver_status" => ["LOCALLY_SOLVED", "ITERATION_LIMIT", "LOCALLY_SOLVED"],
        "primal_status" => fill("FEASIBLE_POINT", 3),
        "solve_elapsed_seconds" => [8.0, 30.0, 9.0],
        "candidate_residual_feasible" => [true, true, true],
        "candidate_iteration_limit_residual_feasible" => [false, true, false],
        "candidate_trajectory_ready" => [true, false, true],
        "candidate_is_scientific_simulation" => fill(false, 3),
        "residual_thresholds_satisfied" => fill(true, 3),
        "dominant_residual" => fill("max_mass_balance_residual", 3),
        "next_recommended_action" => [
            "extract_candidate_trajectory",
            "review_iteration_limit_residual_feasible_candidate",
            "extract_candidate_trajectory",
        ],
        "candidate_warning_count" => [0, 1, 0],
        "max_rhs_residual" => [1.0e-12, 2.0e-12, 1.0e-12],
        "max_mass_balance_residual" => [4.0e-7, 7.0e-7, 4.0e-7],
        "max_lower_bound_violation" => zeros(3),
        "max_upper_bound_violation" => zeros(3),
        "max_stationarity_residual" => [1.0e-8, 2.0e-8, 1.0e-8],
        "max_lower_complementarity_residual" => [5.0e-7, 7.0e-7, 5.0e-7],
        "max_upper_complementarity_residual" => [4.0e-7, 8.0e-7, 4.0e-7],
        "max_state_abs_difference" => [8.0e-6, 5.0e-6, 2.0e-1],
        "max_state_rmse" => [7.0e-6, 4.0e-6, 1.0e-1],
        "max_state_relative_rmse" => [1.0e-2, 1.0e-4, 3.0e-1],
        "final_biomass_difference" => [1.0e-6, 1.0e-7, 2.0e-1],
        "final_glucose_difference" => [-1.0e-6, -1.0e-7, -1.0e-1],
        "final_fructose_difference" => [-1.0e-6, -1.0e-7, -1.0e-1],
        "final_ethanol_difference" => [1.0e-6, 1.0e-7, 1.0e-1],
        "final_total_sugar_difference" => [-2.0e-6, -2.0e-7, -2.0e-1],
        "min_candidate_state_value" => zeros(3),
        "full_dfba_cold_reference_deferred" => fill(true, 3),
        "reduced_full_equivalence_claimed" => fill(false, 3),
        "persistent_lp_baseline_used" => fill(false, 3),
        "indices_reacciones_used" => fill(false, 3),
        "r0001_used_as_oxygen" => fill(false, 3),
        "error_type" => fill(missing, 3),
        "error_message" => fill(missing, 3),
    )
    return ReducedDCDFBAMPCCSolveAttemptSweepResult(
        table,
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        Dict{String, Any}(
            "sweep_type" => "synthetic",
            "outputs_written" => false,
            "sweep_is_scientific_simulation" => false,
            "solved_trajectory_claimed" => false,
        ),
    )
end

function _reduced_mpcc_viability_window_table()
    return DataFrame(
        "window_id" => ["window_001", "window_002"],
        "window_index" => [1, 2],
        "window_status" => ["completed", "completed"],
        "t0" => [0.0, 0.25],
        "tfinal" => [0.25, 0.5],
        "window_hours" => [0.25, 0.25],
        "nfe" => [1, 1],
        "degree" => [3, 3],
        "boundary_dt" => [0.25, 0.25],
        "n_boundary_points" => [2, 2],
        "n_collocation_points" => [3, 3],
        "solver_status" => ["ITERATION_LIMIT", "ITERATION_LIMIT"],
        "primal_status" => ["FEASIBLE_POINT", "FEASIBLE_POINT"],
        "solve_elapsed_seconds" => [20.0, 11.0],
        "candidate_residual_feasible" => [true, true],
        "candidate_iteration_limit_residual_feasible" => [true, true],
        "candidate_trajectory_ready" => [false, false],
        "candidate_allows_continuation" => [true, true],
        "candidate_is_scientific_simulation" => [false, false],
        "residual_thresholds_satisfied" => [true, true],
        "dominant_residual" => ["max_mass_balance_residual", "max_mass_balance_residual"],
        "next_recommended_action" => [
            "review_iteration_limit_residual_feasible_candidate",
            "review_iteration_limit_residual_feasible_candidate",
        ],
        "candidate_warning_count" => [1, 1],
        "max_rhs_residual" => [1.0e-12, 1.0e-12],
        "max_mass_balance_residual" => [4.0e-7, 5.0e-7],
        "max_lower_bound_violation" => [0.0, 0.0],
        "max_upper_bound_violation" => [0.0, 0.0],
        "max_stationarity_residual" => [1.0e-8, 1.0e-8],
        "max_lower_complementarity_residual" => [5.0e-7, 5.0e-7],
        "max_upper_complementarity_residual" => [4.0e-7, 4.0e-7],
        "max_state_abs_difference" => [1.0e-6, 8.0e-2],
        "max_state_rmse" => [8.0e-7, 4.0e-2],
        "max_state_relative_rmse" => [1.0e-4, 3.0e-1],
        "final_biomass_difference" => [1.0e-7, -1.0e-2],
        "final_total_sugar_difference" => [1.0e-7, 8.0e-2],
        "initial_state_source" => ["provided_y0", "previous_candidate_final_boundary_state"],
        "next_initial_state_source" =>
            ["candidate_final_boundary_state", "candidate_final_boundary_state"],
        "full_dfba_cold_reference_deferred" => [true, true],
        "reduced_full_equivalence_claimed" => [false, false],
        "persistent_lp_baseline_used" => [false, false],
        "hsl_required" => [false, false],
        "ma57_required" => [false, false],
        "indices_reacciones_used" => [false, false],
        "r0001_used_as_oxygen" => [false, false],
        "error_type" => [missing, missing],
        "error_message" => [missing, missing],
    )
end

function _reduced_mpcc_viability_window_result()
    table = _reduced_mpcc_viability_window_table()
    metadata = Dict{String, Any}(
        "windowed_continuation_type" => "synthetic_windowed",
        "n_requested_windows" => 2,
        "n_completed_windows" => 2,
        "n_failed_windows" => 0,
        "solver_status_counts" => Dict("ITERATION_LIMIT" => 2),
        "window_hours" => 0.25,
        "nfe_per_window" => 1,
        "degree" => 3,
        "boundary_dt" => 0.25,
        "total_horizon_reached" => 0.5,
        "continuation_completed" => true,
        "all_completed_windows_residual_feasible" => true,
        "all_completed_windows_allow_continuation" => true,
        "all_completed_windows_trajectory_ready" => false,
        "iteration_limit_residual_feasible_window_count" => 2,
        "global_max_state_abs_difference" => 8.0e-2,
        "global_max_state_relative_rmse" => 3.0e-1,
        "global_final_biomass_difference" => -1.0e-2,
        "global_final_total_sugar_difference" => 8.0e-2,
        "outputs_written" => false,
        "windowed_continuation_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
        "full_dfba_cold_reference_deferred" => true,
        "reduced_full_equivalence_claimed" => false,
        "persistent_lp_baseline_used" => false,
        "first_mpcc_target" => "reduced_dfba",
        "full_model_kkt_deferred" => true,
        "dfvb_kkt_deferred" => true,
        "hsl_required" => false,
        "ma57_required" => false,
        "indices_reacciones_used" => false,
        "r0001_used_as_oxygen" => false,
    )
    return ReducedDCDFBAMPCCWindowedContinuationResult(
        table,
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        nothing,
        nothing,
        DataFrame(),
        DataFrame(),
        metadata,
    )
end

@testset "Reduced MPCC simulation viability thresholds" begin
    thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds()
    @test thresholds isa ReducedDCDFBAMPCCSimulationViabilityThresholds
    @test thresholds.max_rhs_residual == 1.0e-6
    @test thresholds.max_stationarity_residual == 1.0e-5
    @test thresholds.max_state_abs_difference == 1.0e-4
    @test thresholds.max_state_relative_rmse == 2.0e-2

    @test_throws ArgumentError default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
        max_state_abs_difference = -1.0,
    )
end

@testset "Reduced MPCC simulation viability solve sweep semaphore" begin
    report = assess_reduced_dcdfba_mpcc_simulation_viability(_reduced_mpcc_viability_test_sweep())
    table = report.viability_table
    metadata = report.metadata

    @test report isa ReducedDCDFBAMPCCSimulationViabilityReport
    @test report.source_type == "solve_attempt_sweep"
    @test size(table, 1) == 3
    @test table[1, "candidate_id"] == "scenario_green"
    @test table[1, "traffic_light"] == "green"
    @test table[1, "viability_class"] == "simulation_viable_candidate"
    @test table[1, "simulation_viable"] == true
    @test table[2, "traffic_light"] == "yellow"
    @test table[2, "viability_class"] == "iteration_limit_residual_feasible_candidate"
    @test occursin("candidate_not_trajectory_ready", table[2, "blocking_reasons"])
    @test table[3, "traffic_light"] == "red"
    @test table[3, "viability_class"] == "state_drift_too_large"
    @test occursin("state_drift_too_large", table[3, "blocking_reasons"])

    @test metadata["viability_type"] == "reduced_dcdfba_mpcc_simulation_viability_gate"
    @test metadata["source_type"] == "solve_attempt_sweep"
    @test metadata["green_count"] == 1
    @test metadata["yellow_count"] == 1
    @test metadata["red_count"] == 1
    @test metadata["simulation_viable_candidate_count"] == 1
    @test metadata["overall_traffic_light"] == "green"
    @test metadata["overall_simulation_viable"] == true
    @test metadata["best_candidate_id"] == "scenario_green"
    @test metadata["recommended_next_action"] == "review_green_candidate_before_scientific_use"
    @test metadata["outputs_written"] == false
    @test metadata["viability_report_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
end

@testset "Reduced MPCC simulation viability windowed drift semaphore" begin
    report = assess_reduced_dcdfba_mpcc_simulation_viability(
        _reduced_mpcc_viability_window_result(),
    )
    table = report.viability_table
    metadata = report.metadata

    @test report.source_type == "windowed_continuation"
    @test size(table, 1) == 3
    @test table[1, "candidate_id"] == "windowed_global"
    @test table[1, "traffic_light"] == "red"
    @test table[1, "viability_class"] == "windowed_drift_too_large"
    @test table[1, "window_continuation_pass"] == true
    @test table[1, "residual_feasible"] == true
    @test table[1, "trajectory_ready"] == false
    @test occursin("global_state_drift_too_large", table[1, "blocking_reasons"])
    @test table[2, "traffic_light"] == "yellow"
    @test table[3, "traffic_light"] == "red"
    @test table[3, "viability_class"] == "state_drift_too_large"

    @test metadata["green_count"] == 0
    @test metadata["hard_red_count"] == 2
    @test metadata["overall_traffic_light"] == "red"
    @test metadata["overall_simulation_viable"] == false
    @test metadata["recommended_next_action"] ==
          "reduce_windowed_candidate_drift_before_simulation"
    @test metadata["full_dfba_cold_reference_deferred"] == true
    @test metadata["reduced_full_equivalence_claimed"] == false
    @test metadata["persistent_lp_baseline_used"] == false
end

@testset "Reduced MPCC simulation viability source coverage" begin
    sweep = _reduced_mpcc_viability_test_sweep()
    mesh = sweep_reduced_dcdfba_mpcc_mesh_refinement(
        ReducedDCDFBAMPCCSolveAttemptSweepResult(
            sweep.scenario_table[1:2, :],
            ReducedDCDFBAMPCCSequentialComparisonResult[],
            sweep.metadata,
        ),
    )
    ipopt = sweep_reduced_dcdfba_mpcc_ipopt_iterations(
        [sweep, sweep];
        ipopt_max_iter_values = [100, 200],
    )

    mesh_report = assess_reduced_dcdfba_mpcc_simulation_viability(mesh)
    ipopt_report = assess_reduced_dcdfba_mpcc_simulation_viability(ipopt)

    @test mesh_report.source_type == "mesh_refinement_sensitivity"
    @test size(mesh_report.viability_table, 1) == 2
    @test ipopt_report.source_type == "ipopt_iteration_sensitivity"
    @test size(ipopt_report.viability_table, 1) == 6
end
