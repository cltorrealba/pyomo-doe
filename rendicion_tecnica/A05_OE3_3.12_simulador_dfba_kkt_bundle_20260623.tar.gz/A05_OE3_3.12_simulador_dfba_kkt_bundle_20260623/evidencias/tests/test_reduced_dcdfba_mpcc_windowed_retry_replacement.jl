using DataFrames

function _reduced_mpcc_retry_replacement_attempt()
    initial = _reduced_mpcc_window_test_initial_state()
    first, first_final = _reduced_mpcc_window_test_comparison(
        t0 = 0.0,
        tfinal = 0.5,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, _ = _reduced_mpcc_window_test_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = first_final,
        biomass_offset = 0.02,
        trajectory_ready = false,
        solver_status = "ITERATION_LIMIT",
    )
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first, second])
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 1.0,
    )
    return attempt, first_final
end

function _reduced_mpcc_retry_replacement_comparison(;
    t0::Float64,
    tfinal::Float64,
    initial_state::AbstractVector,
    trajectory_ready::Bool,
    solver_status::String,
    biomass_offset::Float64 = 0.0,
)
    comparison, _ = _reduced_mpcc_window_test_comparison(
        t0 = t0,
        tfinal = tfinal,
        initial_state = initial_state,
        biomass_offset = biomass_offset,
        trajectory_ready = trajectory_ready,
        solver_status = solver_status,
    )
    return comparison
end

function _reduced_mpcc_retry_replacement_retry_result(
    replacement::ReducedDCDFBAMPCCSequentialComparisonResult;
    window_index::Int,
    traffic_light::String,
    residual_feasible::Bool,
    trajectory_ready::Bool,
    ipopt_max_iter::Int = 300,
)
    source_id = "window_" * lpad(string(window_index), 3, '0')
    viability_class = traffic_light == "green" ? "simulation_viable_candidate" :
                      residual_feasible ? "iteration_limit_residual_feasible_candidate" :
                      "residual_thresholds_failed"
    retry_table = DataFrame(
        "retry_case_id" => ["retry_001"],
        "source_window_id" => [source_id],
        "source_window_index" => [window_index],
        "ipopt_max_iter" => [ipopt_max_iter],
        "case_status" => ["completed"],
        "solver_status" => [trajectory_ready ? "LOCALLY_SOLVED" : "ITERATION_LIMIT"],
        "traffic_light" => [traffic_light],
        "viability_class" => [viability_class],
        "residual_feasible" => [residual_feasible],
        "trajectory_ready" => [trajectory_ready],
        "max_mass_balance_residual" => [traffic_light == "green" ? 4.0e-7 : 2.0e-6],
        "max_mass_balance_ratio" => [traffic_light == "green" ? 0.4 : 2.0],
        "max_state_relative_rmse" => [traffic_light == "green" ? 1.0e-5 : 2.0e-5],
    )
    metadata = Dict{String, Any}(
        "retry_diagnostic_type" => "reduced_dcdfba_mpcc_window_retry_diagnostics",
        "source_window_id" => source_id,
        "source_window_index" => window_index,
        "source_window_t0" => (window_index - 1) * 0.5,
        "source_window_tfinal" => window_index * 0.5,
        "source_window_hours" => 0.5,
        "source_solver_status" => "ITERATION_LIMIT",
        "source_traffic_light" => "yellow",
        "source_viability_class" => "iteration_limit_residual_feasible_candidate",
        "source_residual_feasible" => true,
        "source_max_mass_balance_residual" => 2.0e-6,
        "source_max_mass_balance_ratio" => 2.0,
        "source_blocking_reasons" => "candidate_not_trajectory_ready",
        "n_retry_cases" => 1,
        "green_retry_count" => traffic_light == "green" ? 1 : 0,
        "yellow_retry_count" => traffic_light == "yellow" ? 1 : 0,
        "red_retry_count" => traffic_light == "red" ? 1 : 0,
        "residual_feasible_retry_count" => residual_feasible ? 1 : 0,
        "best_retry_case_id" => "retry_001",
        "best_retry_ipopt_max_iter" => ipopt_max_iter,
        "best_retry_traffic_light" => traffic_light,
        "best_retry_viability_class" => viability_class,
        "best_retry_max_mass_balance_residual" =>
            traffic_light == "green" ? 4.0e-7 : 2.0e-6,
        "best_retry_max_mass_balance_ratio" => traffic_light == "green" ? 0.4 : 2.0,
        "retry_recovered_residual_feasibility" => residual_feasible,
        "retry_recovered_green_window" => traffic_light == "green",
    )
    return ReducedDCDFBAMPCCWindowRetryDiagnosticResult(
        retry_table,
        [sweep_reduced_dcdfba_mpcc_solve_attempts([replacement])],
        ReducedDCDFBAMPCCSimulationViabilityReport[],
        metadata,
    )
end

function _reduced_mpcc_retry_replacement_policy(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
    retry::ReducedDCDFBAMPCCWindowRetryDiagnosticResult,
)
    return diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        attempt,
        [retry];
        window_indices = [Int(retry.metadata["source_window_index"])],
        max_retry_windows = 1,
        ipopt_max_iter_values = [Int(retry.metadata["best_retry_ipopt_max_iter"])],
    )
end

@testset "Reduced MPCC window retry replacement applies terminal retries" begin
    attempt, second_initial = _reduced_mpcc_retry_replacement_attempt()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = second_initial,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 2,
        traffic_light = "green",
        residual_feasible = true,
        trajectory_ready = true,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)

    result = apply_reduced_dcdfba_mpcc_window_retry_replacements(attempt, policy)

    @test result isa ReducedDCDFBAMPCCWindowedRetryReplacementResult
    @test result.source_attempt === attempt
    @test result.retry_policy_diagnostic === policy
    @test result.rebuilt_continuation.window_comparisons[2] === replacement
    @test result.replacement_table[1, "replacement_applied"] == true
    @test result.replacement_table[1, "replacement_reason"] == "accepted_retry_replacement"
    @test result.metadata["replacement_type"] ==
          "reduced_dcdfba_mpcc_windowed_retry_replacement"
    @test result.metadata["n_replacements_applied"] == 1
    @test result.metadata["applied_window_indices"] == [2]
    @test result.metadata["retry_replacement_applied"] == true
    @test result.metadata["windowed_candidate_rebuilt"] == true
    @test result.metadata["outputs_written"] == false
    @test result.metadata["replacement_is_scientific_simulation"] == false
    @test result.metadata["solved_trajectory_claimed"] == false
    @test result.metadata["first_mpcc_target"] == "reduced_dfba"
    @test result.metadata["hsl_required"] == false
    @test result.metadata["ma57_required"] == false
    @test result.metadata["indices_reacciones_used"] == false
    @test result.metadata["r0001_used_as_oxygen"] == false
end

@testset "Reduced MPCC window retry replacement accepts trajectory-ready retries" begin
    attempt, second_initial = _reduced_mpcc_retry_replacement_attempt()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = second_initial,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 2,
        traffic_light = "yellow",
        residual_feasible = true,
        trajectory_ready = true,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)

    relaxed = apply_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        policy;
        acceptance_policy = "green_or_trajectory_ready",
    )
    strict = apply_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        policy;
        acceptance_policy = "green",
    )

    @test relaxed.replacement_table[1, "replacement_applied"] == true
    @test relaxed.metadata["n_replacements_applied"] == 1
    @test strict.replacement_table[1, "replacement_applied"] == false
    @test strict.replacement_table[1, "replacement_reason"] ==
          "retry_not_accepted_by_policy"
    @test strict.metadata["windowed_candidate_rebuilt"] == false
end

@testset "Reduced MPCC window retry replacement defers nonterminal windows" begin
    attempt, _ = _reduced_mpcc_retry_replacement_attempt()
    first_initial = _reduced_mpcc_window_test_initial_state()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.0,
        tfinal = 0.5,
        initial_state = first_initial,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 1,
        traffic_light = "green",
        residual_feasible = true,
        trajectory_ready = true,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)

    result = apply_reduced_dcdfba_mpcc_window_retry_replacements(attempt, policy)

    @test result.rebuilt_attempt === attempt
    @test result.replacement_table[1, "replacement_applied"] == false
    @test result.replacement_table[1, "replacement_reason"] ==
          "nonterminal_replacement_deferred"
    @test result.metadata["n_replacements_applied"] == 0
    @test result.metadata["windowed_candidate_rebuilt"] == false
    @test result.metadata["recommended_next_action"] ==
          "implement_retry_replacement_cascade_rebuild_for_nonterminal_windows"
end

@testset "Reduced MPCC window retry replacement rejects non-improving retries" begin
    attempt, second_initial = _reduced_mpcc_retry_replacement_attempt()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = second_initial,
        trajectory_ready = false,
        solver_status = "ITERATION_LIMIT",
        biomass_offset = 0.03,
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 2,
        traffic_light = "yellow",
        residual_feasible = true,
        trajectory_ready = false,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)

    result = apply_reduced_dcdfba_mpcc_window_retry_replacements(attempt, policy)

    @test result.rebuilt_attempt === attempt
    @test result.replacement_table[1, "replacement_applied"] == false
    @test result.replacement_table[1, "replacement_reason"] ==
          "retry_not_accepted_by_policy"
    @test result.metadata["retry_replacement_applied"] == false
    @test result.metadata["windowed_candidate_rebuilt"] == false
end

@testset "Reduced MPCC window retry replacement validation" begin
    attempt, second_initial = _reduced_mpcc_retry_replacement_attempt()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = second_initial,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 2,
        traffic_light = "green",
        residual_feasible = true,
        trajectory_ready = true,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)
    other_attempt, _ = _reduced_mpcc_retry_replacement_attempt()

    @test_throws ArgumentError apply_reduced_dcdfba_mpcc_window_retry_replacements(
        other_attempt,
        policy,
    )
    @test_throws ArgumentError apply_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        policy;
        acceptance_policy = "invalid",
    )
end
