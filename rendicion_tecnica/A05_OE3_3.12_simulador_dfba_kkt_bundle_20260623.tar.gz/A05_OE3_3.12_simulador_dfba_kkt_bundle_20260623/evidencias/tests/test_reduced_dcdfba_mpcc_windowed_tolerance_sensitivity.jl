using DataFrames

function _reduced_mpcc_tol_test_attempt(;
    threshold::Float64,
    target_horizon::Float64,
    horizon_reached::Float64,
    target_completed::Bool,
    attempt_traffic_light::String,
    global_traffic_light::String,
    global_viability_class::String,
    n_requested_windows::Int,
    n_completed_windows::Int,
    window_green_count::Int,
    window_yellow_count::Int,
    window_red_count::Int,
    first_red_window_id = missing,
    first_red_window_index = missing,
    first_red_window_class = missing,
    first_not_residual_feasible_window_id = missing,
    first_not_residual_feasible_window_index = missing,
    first_not_residual_feasible_window_class = missing,
    max_mass_balance_residual::Float64,
    global_state_relative_rmse::Float64,
)
    residual_thresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(max_mass_balance_residual = threshold)
    viability_thresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        )
    continuation = ReducedDCDFBAMPCCWindowedContinuationResult(
        DataFrame(),
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        nothing,
        nothing,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}(
            "n_requested_windows" => n_requested_windows,
            "n_completed_windows" => n_completed_windows,
            "continuation_completed" => target_completed,
        ),
    )
    viability_report = ReducedDCDFBAMPCCSimulationViabilityReport(
        "windowed_continuation",
        DataFrame(),
        viability_thresholds,
        Dict{String, Any}("overall_traffic_light" => global_traffic_light),
    )
    attempt_table = DataFrame(
        "candidate_id" => ["windowed_global"],
        "source_type" => ["windowed_continuation_global"],
        "ipopt_max_iter" => [100],
        "traffic_light" => [global_traffic_light],
        "viability_class" => [global_viability_class],
        "max_rhs_residual" => [1.0e-10],
        "max_mass_balance_residual" => [max_mass_balance_residual],
        "max_lower_bound_violation" => [1.0e-9],
        "max_upper_bound_violation" => [1.0e-9],
        "max_stationarity_residual" => [1.0e-8],
        "max_lower_complementarity_residual" => [5.0e-7],
        "max_upper_complementarity_residual" => [5.0e-7],
        "blocking_reasons" =>
            [attempt_traffic_light == "green" ? "" : "residual_thresholds_failed"],
        "review_reasons" => ["full_dfba_cold_reference_deferred"],
    )
    metadata = Dict{String, Any}(
        "target_horizon" => target_horizon,
        "horizon_reached" => horizon_reached,
        "horizon_gap" => max(target_horizon - horizon_reached, 0.0),
        "target_completion_fraction" => horizon_reached / target_horizon,
        "target_completed" => target_completed,
        "attempt_traffic_light" => attempt_traffic_light,
        "attempt_viable" => attempt_traffic_light == "green",
        "window_hours" => 0.5,
        "nfe_per_window" => 2,
        "degree" => 3,
        "n_requested_windows" => n_requested_windows,
        "n_completed_windows" => n_completed_windows,
        "n_failed_windows" => 0,
        "global_traffic_light" => global_traffic_light,
        "global_viability_class" => global_viability_class,
        "window_green_count" => window_green_count,
        "window_yellow_count" => window_yellow_count,
        "window_red_count" => window_red_count,
        "first_non_green_window_id" =>
            attempt_traffic_light == "green" ? missing : "window_014",
        "first_non_green_window_index" =>
            attempt_traffic_light == "green" ? missing : 14,
        "first_non_green_window_class" =>
            attempt_traffic_light == "green" ? missing : global_viability_class,
        "first_red_window_id" => first_red_window_id,
        "first_red_window_index" => first_red_window_index,
        "first_red_window_class" => first_red_window_class,
        "first_not_residual_feasible_window_id" => first_not_residual_feasible_window_id,
        "first_not_residual_feasible_window_index" =>
            first_not_residual_feasible_window_index,
        "first_not_residual_feasible_window_class" =>
            first_not_residual_feasible_window_class,
        "global_max_state_relative_rmse" => global_state_relative_rmse,
        "total_solve_elapsed_seconds" => 30.0 * n_completed_windows,
        "recommended_next_action" =>
            attempt_traffic_light == "green" ?
            "review_windowed_target_candidate_before_scientific_use" :
            "extend_or_repair_windowed_continuation_to_target",
    )
    return ReducedDCDFBAMPCCWindowedSimulationAttemptResult(
        continuation,
        viability_report,
        attempt_table,
        metadata,
    )
end

@testset "Reduced MPCC windowed tolerance sensitivity aggregation" begin
    attempts = [
        _reduced_mpcc_tol_test_attempt(
            threshold = 1.0e-6,
            target_horizon = 72.0,
            horizon_reached = 7.0,
            target_completed = false,
            attempt_traffic_light = "red",
            global_traffic_light = "red",
            global_viability_class = "failed_diagnostic_row",
            n_requested_windows = 144,
            n_completed_windows = 14,
            window_green_count = 6,
            window_yellow_count = 7,
            window_red_count = 1,
            first_red_window_id = "window_014",
            first_red_window_index = 14,
            first_red_window_class = "residual_thresholds_failed",
            first_not_residual_feasible_window_id = "window_014",
            first_not_residual_feasible_window_index = 14,
            first_not_residual_feasible_window_class = "residual_thresholds_failed",
            max_mass_balance_residual = 2.0e-6,
            global_state_relative_rmse = 0.007,
        ),
        _reduced_mpcc_tol_test_attempt(
            threshold = 5.0e-6,
            target_horizon = 72.0,
            horizon_reached = 8.0,
            target_completed = false,
            attempt_traffic_light = "red",
            global_traffic_light = "red",
            global_viability_class = "windowed_drift_too_large",
            n_requested_windows = 144,
            n_completed_windows = 16,
            window_green_count = 8,
            window_yellow_count = 8,
            window_red_count = 0,
            max_mass_balance_residual = 3.0e-6,
            global_state_relative_rmse = 0.03,
        ),
        _reduced_mpcc_tol_test_attempt(
            threshold = 1.0e-5,
            target_horizon = 72.0,
            horizon_reached = 72.0,
            target_completed = true,
            attempt_traffic_light = "green",
            global_traffic_light = "green",
            global_viability_class = "simulation_viable_candidate",
            n_requested_windows = 144,
            n_completed_windows = 144,
            window_green_count = 144,
            window_yellow_count = 0,
            window_red_count = 0,
            max_mass_balance_residual = 4.0e-6,
            global_state_relative_rmse = 0.01,
        ),
    ]

    sensitivity = sweep_reduced_dcdfba_mpcc_windowed_tolerances(
        attempts;
        max_mass_balance_residual_values = [1.0e-6, 5.0e-6, 1.0e-5],
    )
    table = sensitivity.sensitivity_table
    metadata = sensitivity.metadata

    @test sensitivity isa ReducedDCDFBAMPCCWindowedToleranceSensitivityResult
    @test sensitivity.attempt_results == attempts
    @test size(table, 1) == 3
    @test table[1, "tolerance_case_id"] == "tolerance_001"
    @test table[1, "max_mass_balance_ratio"] == 2.0
    @test table[2, "horizon_gain_vs_strictest"] == 1.0
    @test table[2, "horizon_gain_vs_previous"] == 1.0
    @test table[2, "max_mass_balance_ratio"] == 0.6
    @test table[3, "target_completed"] == true
    @test table[3, "attempt_traffic_light"] == "green"
    @test table[3, "horizon_gain_vs_strictest"] == 65.0

    @test metadata["sensitivity_type"] ==
          "reduced_dcdfba_mpcc_windowed_tolerance_sensitivity"
    @test metadata["varied_threshold"] == "max_mass_balance_residual"
    @test metadata["strictest_horizon_reached"] == 7.0
    @test metadata["best_tolerance_case_id"] == "tolerance_003"
    @test metadata["best_max_mass_balance_residual_threshold"] == 1.0e-5
    @test metadata["best_horizon_reached"] == 72.0
    @test metadata["first_horizon_extension_case_id"] == "tolerance_002"
    @test metadata["first_horizon_extension_threshold"] == 5.0e-6
    @test metadata["first_target_completed_case_id"] == "tolerance_003"
    @test metadata["target_recovered_by_relaxation"] == true
    @test metadata["horizon_extended_by_relaxation"] == true
    @test metadata["recommended_next_action"] ==
          "review_relaxed_tolerance_candidate_before_scientific_use"
    @test metadata["outputs_written"] == false
    @test metadata["sensitivity_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
end

@testset "Reduced MPCC windowed tolerance sensitivity validation" begin
    attempt = _reduced_mpcc_tol_test_attempt(
        threshold = 1.0e-6,
        target_horizon = 72.0,
        horizon_reached = 7.0,
        target_completed = false,
        attempt_traffic_light = "red",
        global_traffic_light = "red",
        global_viability_class = "failed_diagnostic_row",
        n_requested_windows = 144,
        n_completed_windows = 14,
        window_green_count = 6,
        window_yellow_count = 7,
        window_red_count = 1,
        max_mass_balance_residual = 2.0e-6,
        global_state_relative_rmse = 0.007,
    )

    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_windowed_tolerances(
        ReducedDCDFBAMPCCWindowedSimulationAttemptResult[];
        max_mass_balance_residual_values = [1.0e-6],
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_windowed_tolerances(
        [attempt];
        max_mass_balance_residual_values = Float64[],
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_windowed_tolerances(
        [attempt];
        max_mass_balance_residual_values = [1.0e-6, 5.0e-6],
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_windowed_tolerances(
        [attempt];
        max_mass_balance_residual_values = [5.0e-6, 1.0e-6],
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_windowed_tolerances(
        [attempt];
        max_mass_balance_residual_values = [1.0e-6, 1.0e-6],
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_windowed_tolerances(
        [attempt];
        max_mass_balance_residual_values = [-1.0e-6],
    )
end
