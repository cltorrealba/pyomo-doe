import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_bound_feasibility_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

@testset "Reduced DC-dFBA bound feasibility scaffold contract" begin
    model, reaction_map = _reduced_dcdfba_bound_feasibility_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    variable_count_before = JuMP.num_variables(nlp.jump_model)
    bound = add_reduced_dcdfba_bound_feasibility!(nlp)

    @test bound isa ReducedDCDFBABoundFeasibilityScaffold
    @test bound.nlp === nlp
    @test bound.layout isa ReducedDCDFBABoundFeasibilityLayout
    @test size(bound.lower_bound_duals) == (1488, 1, 3)
    @test size(bound.upper_bound_duals) == (1488, 1, 3)
    @test size(bound.lower_bound_constraints) == (1488, 1, 3)
    @test size(bound.upper_bound_constraints) == (1488, 1, 3)
    @test all(variable -> variable isa JuMP.VariableRef, bound.lower_bound_duals)
    @test all(variable -> variable isa JuMP.VariableRef, bound.upper_bound_duals)
    @test all(constraint -> constraint isa JuMP.ConstraintRef, bound.lower_bound_constraints)
    @test all(constraint -> constraint isa JuMP.ConstraintRef, bound.upper_bound_constraints)
    @test JuMP.num_variables(nlp.jump_model) == variable_count_before + 2 * 1488 * 3
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED

    layout = bound.layout
    @test layout.n_reactions == size(model.S, 2) == 1488
    @test layout.nfe == 1
    @test layout.collocation_degree == 3
    @test layout.n_collocation_points == 3
    @test layout.n_lower_bound_constraints == 1488 * 3
    @test layout.n_upper_bound_constraints == 1488 * 3
    @test layout.n_lower_bound_dual_variables == 1488 * 3
    @test layout.n_upper_bound_dual_variables == 1488 * 3
    @test layout.n_total_bound_feasibility_constraints == 2 * 1488 * 3
    @test layout.n_total_bound_dual_variables == 2 * 1488 * 3
    @test length(bound.lower_bound_constraints) + length(bound.upper_bound_constraints) ==
          layout.n_total_bound_feasibility_constraints
end

@testset "Reduced DC-dFBA bound feasibility dual variables" begin
    model, reaction_map = _reduced_dcdfba_bound_feasibility_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    bound = add_reduced_dcdfba_bound_feasibility!(nlp)
    reaction_sample = [
        reaction_index(model, "r_2111"),
        reaction_index(model, "r_1714"),
        reaction_index(model, "r_1709"),
        reaction_index(model, "r_1761"),
        reaction_index(model, "r_4048"),
    ]

    for reaction_index_value in reaction_sample
        lower_dual = bound.lower_bound_duals[reaction_index_value, 1, 1]
        upper_dual = bound.upper_bound_duals[reaction_index_value, 1, 1]

        @test !JuMP.has_lower_bound(lower_dual)
        @test JuMP.has_upper_bound(lower_dual)
        @test JuMP.upper_bound(lower_dual) == 0.0
        @test JuMP.start_value(lower_dual) == 0.0

        @test JuMP.has_lower_bound(upper_dual)
        @test JuMP.lower_bound(upper_dual) == 0.0
        @test !JuMP.has_upper_bound(upper_dual)
        @test JuMP.start_value(upper_dual) == 0.0

        @test JuMP.lower_bound(nlp.flux[reaction_index_value, 1, 1]) == model.lb[reaction_index_value]
        @test JuMP.upper_bound(nlp.flux[reaction_index_value, 1, 1]) == model.ub[reaction_index_value]

        lower_constraint = bound.lower_bound_constraints[reaction_index_value, 1, 1]
        upper_constraint = bound.upper_bound_constraints[reaction_index_value, 1, 1]
        @test JuMP.normalized_coefficient(lower_constraint, nlp.flux[reaction_index_value, 1, 1]) == -1.0
        @test JuMP.normalized_rhs(lower_constraint) == -model.lb[reaction_index_value]
        @test JuMP.normalized_coefficient(upper_constraint, nlp.flux[reaction_index_value, 1, 1]) == 1.0
        @test JuMP.normalized_rhs(upper_constraint) == model.ub[reaction_index_value]
    end
end

@testset "Reduced DC-dFBA bound feasibility metadata guardrails" begin
    model, reaction_map = _reduced_dcdfba_bound_feasibility_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    @test nlp.metadata["bound_feasibility_constraints_built"] == false

    bound = add_reduced_dcdfba_bound_feasibility!(nlp)
    metadata = bound.metadata

    @test metadata["bound_feasibility_constraints_built"] == true
    @test metadata["reduced_fba_bound_feasibility_built"] == true
    @test metadata["bound_feasibility_component"] == "lb <= v <= ub at each collocation point"
    @test metadata["lower_bound_feasibility_form"] == "lb - v <= 0"
    @test metadata["upper_bound_feasibility_form"] == "v - ub <= 0"
    @test metadata["lower_bound_dual_variables_built"] == true
    @test metadata["upper_bound_dual_variables_built"] == true
    @test metadata["lower_bound_dual_sign"] == "nonpositive"
    @test metadata["upper_bound_dual_sign"] == "nonnegative"
    @test metadata["bound_feasibility_lower_constraints"] == 1488 * 3
    @test metadata["bound_feasibility_upper_constraints"] == 1488 * 3
    @test metadata["bound_feasibility_total_constraints"] == 2 * 1488 * 3
    @test metadata["bound_feasibility_total_dual_variables"] == 2 * 1488 * 3
    @test metadata["stationarity_constraints_built"] == false
    @test metadata["kkt_constraints_built"] == false
    @test metadata["mpcc_complementarity_built"] == false
    @test metadata["lower_bound_complementarity_built"] == false
    @test metadata["upper_bound_complementarity_built"] == false
    @test metadata["dynamic_flux_bounds_applied"] == false
    @test metadata["solver_call_performed"] == false
    @test metadata["sequential_initialization_built"] == false
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false

    @test nlp.metadata["bound_feasibility_constraints_built"] == true
    @test nlp.metadata["reduced_fba_bound_feasibility_built"] == true
    @test nlp.metadata["stationarity_constraints_built"] == false
    @test nlp.metadata["kkt_constraints_built"] == false
    @test nlp.metadata["mpcc_complementarity_built"] == false
end

@testset "Reduced DC-dFBA bound feasibility after primal feasibility and RHS" begin
    model, reaction_map = _reduced_dcdfba_bound_feasibility_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    rhs = add_reduced_dcdfba_rhs_residuals!(nlp)
    primal = add_reduced_dcdfba_primal_feasibility!(nlp)
    bound = add_reduced_dcdfba_bound_feasibility!(nlp)

    @test rhs.layout.total_rhs_residual_constraints == 19 * 3
    @test primal.layout.total_primal_feasibility_constraints == 1079 * 3
    @test bound.layout.n_total_bound_feasibility_constraints == 2 * 1488 * 3
    @test nlp.metadata["ode_rhs_constraints_built"] == true
    @test nlp.metadata["rhs_residual_scaffold_built"] == true
    @test nlp.metadata["mass_balance_constraints_built"] == true
    @test nlp.metadata["reduced_fba_primal_feasibility_built"] == true
    @test nlp.metadata["bound_feasibility_constraints_built"] == true
    @test nlp.metadata["reduced_fba_bound_feasibility_built"] == true
    @test nlp.metadata["stationarity_constraints_built"] == false
    @test nlp.metadata["kkt_constraints_built"] == false
    @test nlp.metadata["mpcc_complementarity_built"] == false
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA bound feasibility validation" begin
    model, reaction_map = _reduced_dcdfba_bound_feasibility_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )

    bound = add_reduced_dcdfba_bound_feasibility!(nlp)
    @test bound.layout.n_total_bound_feasibility_constraints == 2 * 1488 * 3
    @test_throws ArgumentError add_reduced_dcdfba_bound_feasibility!(nlp)
end
