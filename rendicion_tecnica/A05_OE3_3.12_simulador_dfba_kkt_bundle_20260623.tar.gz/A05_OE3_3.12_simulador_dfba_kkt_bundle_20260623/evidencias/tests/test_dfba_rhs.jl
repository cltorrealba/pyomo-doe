import HiGHS
import JuMP
import MathOptInterface as MOI

const DFBA_RHS_RTOL = 1.0e-7
const DFBA_RHS_ATOL = 1.0e-9

function _zenteno_state_vector(state::ZentenoState)
    return [
        state.biomass,
        state.nitrogen,
        state.glucose,
        state.fructose,
        state.ethanol,
        state.oxygen,
        state.protein,
        state.carbohydrate,
        state.amino_acids...,
        state.aromas...,
    ]
end

function _load_reduced_dfba_inputs()
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    reaction_report = validate_reaction_map(model, reaction_map)
    @test reaction_report.ok

    return model, reaction_map
end

function _all_isapprox(actual, expected; rtol = DFBA_RHS_RTOL, atol = DFBA_RHS_ATOL)
    return length(actual) == length(expected) &&
        all(isapprox(actual[i], expected[i]; rtol = rtol, atol = atol) for i in eachindex(expected))
end

function _infeasible_dfba_rhs_model(params::ZentenoKineticParameters)
    amino_acid_ids = ["r_1903", "r_1897", "r_1914", "r_1902", "r_1913"]
    aroma_ids = ["r_1589", "r_1862", "r_1866", "r_4668", "r_4677", "r_1765"]
    core_ids = ["r_2111", "r_1714", "r_1709", "r_1761", "r_4046", "r_4047", "r_4048"]
    rxn_ids = sort(collect(Set(vcat(core_ids, params.nitrogen_source_ids, amino_acid_ids, aroma_ids))))
    blocked_aroma_index = findfirst(==("r_1862"), rxn_ids)

    S = zeros(1, length(rxn_ids))
    S[1, blocked_aroma_index] = 1.0
    return MetabolicModel(
        S,
        fill(-1000.0, length(rxn_ids)),
        fill(1000.0, length(rxn_ids)),
        rxn_ids,
        ["blocked_aroma_metabolite"];
        model_id = "infeasible_dfba_rhs",
    )
end

function _turnover_dfba_rhs_state()
    return ZentenoState(
        0.5,
        0.0,
        110.0,
        110.0,
        0.0,
        0.0,
        0.23,
        0.185,
        zeros(5),
        zeros(6),
    )
end

function _rhs_relevant_reaction_ids(reaction_map::ReactionMap, params::ZentenoKineticParameters)
    ids = String[]
    for group in (
        values(reaction_map.core),
        params.nitrogen_source_ids,
        values(reaction_map.amino_acids),
        values(reaction_map.aromas),
    )
        for rxn_id in group
            cleaned_id = String(rxn_id)
            cleaned_id in ids || push!(ids, cleaned_id)
        end
    end
    return ids
end

function _expected_dynamic_indices(model::MetabolicModel, bounds::ZentenoDynamicBounds)
    return Set(
        reaction_index(model, rxn_id) for
        rxn_id in union(collect(keys(bounds.lb_updates)), collect(keys(bounds.ub_updates)))
    )
end

function _persistent_reduced_dfba_rhs(context::DFBAContext, u::AbstractVector)
    rhs_result, timings = FermentationDFBA._compute_reusable_reduced_dfba_rhs!(
        context.lp_cache,
        u;
        params = context.params,
        lp_atol = context.atol,
        primal_start = context.lp_primal_start,
        basis_warm_start = context.lp_basis_warm_start,
    )
    return rhs_result, timings
end

function _assert_persistent_rhs_matches_cold(
    model::MetabolicModel,
    reaction_map::ReactionMap,
    context::DFBAContext,
    u::AbstractVector;
    rtol = 1.0e-6,
    atol = 1.0e-8,
)
    cold = compute_dfba_rhs(
        model,
        reaction_map,
        u;
        params = context.params,
        atol = context.atol,
        fba_variant = context.fba_variant,
        quadratic_penalty = context.quadratic_penalty,
        l1_penalty = context.l1_penalty,
    )
    persistent, timings = _persistent_reduced_dfba_rhs(context, u)

    @test persistent.fba.status == cold.fba.status
    @test persistent.mode == cold.mode
    @test _all_isapprox(persistent.dy, cold.dy; rtol = rtol, atol = atol)
    @test persistent.bounds.objective_weights == cold.bounds.objective_weights
    @test persistent.fba.metadata["objective_type"] == cold.fba.metadata["objective_type"]
    @test context.lp_cache.current_dynamic_indices == _expected_dynamic_indices(model, persistent.bounds)
    @test timings.warm_start_applied == context.lp_primal_start
    @test get(persistent.fba.metadata, "lp_reuse_validity_scope", nothing) == "rhs_diagnostic_only"
    @test get(persistent.fba.metadata, "scientific_output_equivalent", nothing) == false

    for rxn_id in _rhs_relevant_reaction_ids(reaction_map, context.params)
        if haskey(cold.fluxes_by_rxn, rxn_id) && haskey(persistent.fluxes_by_rxn, rxn_id)
            @test isapprox(
                persistent.fluxes_by_rxn[rxn_id],
                cold.fluxes_by_rxn[rxn_id];
                rtol = rtol,
                atol = atol,
            )
        end
    end

    @test persistent.metadata["oxygen_derivative_policy"] == cold.metadata["oxygen_derivative_policy"]
    @test persistent.metadata["r0001_used_as_oxygen"] == false
    @test persistent.metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    return persistent
end

@testset "DFBAContext construction" begin
    model, reaction_map = _load_reduced_dfba_inputs()

    context = DFBAContext(model, reaction_map)

    @test context.model === model
    @test context.reaction_map === reaction_map
    @test context.params isa ZentenoKineticParameters
    @test context.dynamic_control_schedule === nothing
    @test context.silent == true
    @test context.atol == 1.0e-8
    @test context.nonoptimal_policy == :error
    @test context.lp_reuse == false
    @test context.lp_primal_start == false
    @test context.lp_basis_warm_start == false
    @test context.lp_simplex_strategy == "default"
    @test context.fba_variant == "fba"
    @test context.quadratic_penalty == 0.0
    @test context.l1_penalty == 0.0
    @test context.lp_cache === nothing
    @test context.lp_reuse_build_elapsed_seconds == 0.0
    @test context.lp_reuse_update_elapsed_seconds[] == 0.0
    @test context.lp_reuse_solve_elapsed_seconds[] == 0.0
    @test context.lp_reuse_warm_start_applied_count[] == 0
    @test context.lp_reuse_basis_warm_start_applied_count[] == 0
    @test context.lp_reuse_basis_warm_start_failed_count[] == 0
    @test context.lp_reuse_basis_capture_count[] == 0
    @test context.lp_reuse_simplex_iterations[] == 0

    schedule = reference_dynamic_control_schedule()
    dynamic_context = DFBAContext(model, reaction_map; dynamic_control_schedule = schedule)
    @test dynamic_context.dynamic_control_schedule === schedule

    @test_throws ErrorException DFBAContext(model, reaction_map; atol = 0.0)
    @test_throws ErrorException DFBAContext(model, reaction_map; atol = -1.0e-8)
    @test_throws ErrorException DFBAContext(model, reaction_map; nonoptimal_policy = :return_zero)
    @test_throws ErrorException DFBAContext(model, reaction_map; lp_primal_start = true)
    @test_throws ErrorException DFBAContext(model, reaction_map; lp_basis_warm_start = true)
    @test_throws ErrorException DFBAContext(model, reaction_map; fba_variant = "bad_variant")
    @test_throws ErrorException DFBAContext(model, reaction_map; dynamic_control_schedule = "bad_schedule")
    @test_throws ErrorException DFBAContext(model, reaction_map; fba_variant = "qpfba", quadratic_penalty = 0.0)
    @test_throws ErrorException DFBAContext(model, reaction_map; fba_variant = "l1pfba", l1_penalty = 0.0)
    @test_throws ErrorException DFBAContext(
        model,
        reaction_map;
        lp_reuse = true,
        lp_basis_warm_start = true,
        fba_variant = "qpfba",
        quadratic_penalty = 1.0e-8,
    )
end

@testset "Sequential reduced DFBA RHS wrapper growth mode" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    state = default_zenteno_initial_state()
    u = _zenteno_state_vector(state)
    original_u = copy(u)
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    context = DFBAContext(model, reaction_map)
    rhs_result = compute_dfba_rhs(model, reaction_map, u)
    du = similar(u)
    returned = dfba_rhs!(du, u, context, 0.0)

    @test returned === nothing
    @test length(du) == 19
    @test _all_isapprox(du, rhs_result.dy)
    @test u == original_u
    @test model.lb == original_lb
    @test model.ub == original_ub
    @test du[6] == 0.0

    biomass_flux = rhs_result.fluxes_by_rxn["r_2111"]
    expected_carbohydrate =
        max(0.0, biomass_flux) * state.biomass * context.params.CARB_CONTENT_0 -
        state.carbohydrate * context.params.K_DEATH
    @test isapprox(du[8], expected_carbohydrate; rtol = DFBA_RHS_RTOL, atol = DFBA_RHS_ATOL)
    @test has_reaction(model, "r_4048")
    @test haskey(rhs_result.fluxes_by_rxn, "r_4048")
end

@testset "Sequential reduced DFBA RHS dynamic control schedule" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    state = default_zenteno_initial_state()
    u = _zenteno_state_vector(state)
    u[14:19] .= 1.0
    schedule = DynamicControlSchedule(
        temperature_transition_times_h = [12.0],
        temperature_values_C = [20.0, 22.0],
        fda_events = [SmoothDoseEvent(12.0, 0.1, 1.0)],
        organic_events = [SmoothDoseEvent(12.0, 0.1, 1.0)],
        organic_composition = OrganicNutrientComposition(
            nitrogen_fraction_gN_per_g = 0.10,
            amino_acid_nitrogen_fractions = fill(0.2, 5),
        ),
        volatilization_model = VaporLiquidVolatilizationModel(
            aroma_partition_coefficients = ones(6),
            gas_exchange_rate_h_inv = 0.1,
        ),
    )
    params = default_zenteno_parameters()
    effective_params = dynamic_zenteno_parameters(schedule, 12.0; base_params = params)
    reference = compute_dfba_rhs(model, reaction_map, u; params = effective_params)
    expected_du = copy(reference.dy)
    apply_dynamic_control_rhs_rates!(expected_du, u, schedule, 12.0; params = effective_params)

    context = DFBAContext(model, reaction_map; params = params, dynamic_control_schedule = schedule)
    du = similar(u)
    returned = dfba_rhs!(du, u, context, 12.0)

    @test returned === nothing
    @test context.dynamic_control_schedule === schedule
    @test isapprox(effective_params.temperature_K, 294.15; atol = 1.0e-12)
    @test _all_isapprox(du, expected_du; rtol = 1.0e-6, atol = 1.0e-8)
    @test du[2] > reference.dy[2]
    @test all(du[9:13] .> reference.dy[9:13])
    @test all(du[14:19] .< reference.dy[14:19])
end

@testset "Sequential reduced DFBA RHS QP-regularized FBA" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    u = _zenteno_state_vector(default_zenteno_initial_state())
    qpfba_optimizer = JuMP.optimizer_with_attributes(
        HiGHS.Optimizer,
        "solver" => "ipm",
        "run_crossover" => "off",
        "ipm_optimality_tolerance" => 1.0e-6,
    )
    cold = compute_dfba_rhs(
        model,
        reaction_map,
        u;
        optimizer = qpfba_optimizer,
        fba_variant = "qpfba",
        quadratic_penalty = 1.0e-5,
    )
    context = DFBAContext(
        model,
        reaction_map;
        optimizer = qpfba_optimizer,
        lp_reuse = true,
        lp_reuse_highs_solver = "default",
        fba_variant = "qpfba",
        quadratic_penalty = 1.0e-5,
    )
    persistent, timings = _persistent_reduced_dfba_rhs(context, u)

    @test cold.fba.status == MOI.OPTIMAL
    @test persistent.fba.status == MOI.OPTIMAL
    @test cold.fba.metadata["fba_variant"] == "qpfba"
    @test persistent.fba.metadata["fba_variant"] == "qpfba"
    @test cold.fba.metadata["quadratic_penalty"] == 1.0e-5
    @test persistent.fba.metadata["quadratic_penalty"] == 1.0e-5
    @test _all_isapprox(persistent.dy, cold.dy; rtol = 1.0e-6, atol = 1.0e-8)
    @test timings.warm_start_applied == false
    @test context.lp_cache.fba_variant == "qpfba"
    @test context.lp_cache.quadratic_penalty == 1.0e-5
end

@testset "Sequential reduced DFBA RHS L1-regularized FBA" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    u = _zenteno_state_vector(default_zenteno_initial_state())
    cold = compute_dfba_rhs(
        model,
        reaction_map,
        u;
        fba_variant = "l1pfba",
        l1_penalty = 1.0e-6,
    )
    context = DFBAContext(
        model,
        reaction_map;
        lp_reuse = true,
        lp_primal_start = true,
        fba_variant = "l1pfba",
        l1_penalty = 1.0e-6,
    )
    persistent, timings = _persistent_reduced_dfba_rhs(context, u)

    @test cold.fba.status == MOI.OPTIMAL
    @test persistent.fba.status == MOI.OPTIMAL
    @test cold.fba.metadata["fba_variant"] == "l1pfba"
    @test persistent.fba.metadata["fba_variant"] == "l1pfba"
    @test cold.fba.metadata["l1_penalty"] == 1.0e-6
    @test persistent.fba.metadata["l1_penalty"] == 1.0e-6
    @test _all_isapprox(persistent.dy, cold.dy; rtol = 1.0e-6, atol = 1.0e-8)
    @test timings.warm_start_applied == false
    @test context.lp_cache.fba_variant == "l1pfba"
    @test context.lp_cache.l1_penalty == 1.0e-6
    @test context.lp_cache.absolute_flux_variables !== nothing
end

@testset "Sequential reduced DFBA RHS persistent LP reuse" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    u = _zenteno_state_vector(default_zenteno_initial_state())
    reference = compute_dfba_rhs(model, reaction_map, u)

    context = DFBAContext(model, reaction_map; lp_reuse = true)
    du = similar(u)
    returned = dfba_rhs!(du, u, context, 0.0)

    @test returned === nothing
    @test context.lp_reuse == true
    @test context.lp_primal_start == false
    @test context.lp_basis_warm_start == false
    @test context.lp_cache !== nothing
    @test context.lp_reuse_build_elapsed_seconds >= 0.0
    @test context.lp_reuse_update_elapsed_seconds[] >= 0.0
    @test context.lp_reuse_solve_elapsed_seconds[] >= 0.0
    @test context.lp_reuse_warm_start_applied_count[] == 0
    @test context.lp_reuse_basis_warm_start_applied_count[] == 0
    @test context.lp_reuse_basis_capture_count[] == 0
    @test context.lp_reuse_simplex_iterations[] >= 0
    @test _all_isapprox(du, reference.dy; rtol = 1.0e-6, atol = 1.0e-8)
end

@testset "Sequential reduced DFBA RHS persistent LP matches cold mode switching" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)
    context = DFBAContext(model, reaction_map; lp_reuse = true)

    growth_u = _zenteno_state_vector(default_zenteno_initial_state())
    turnover_u = _zenteno_state_vector(_turnover_dfba_rhs_state())

    growth_1 = _assert_persistent_rhs_matches_cold(model, reaction_map, context, growth_u)
    turnover = _assert_persistent_rhs_matches_cold(model, reaction_map, context, turnover_u)
    growth_2 = _assert_persistent_rhs_matches_cold(model, reaction_map, context, growth_u)

    @test growth_1.mode == :growth
    @test turnover.mode == :turnover
    @test growth_2.mode == :growth
    @test haskey(growth_1.bounds.objective_weights, "r_2111")
    @test turnover.bounds.objective_weights["r_4046"] == 1.0
    @test turnover.bounds.objective_weights["r_4047"] == 1.0
    @test haskey(growth_2.bounds.objective_weights, "r_2111")
    @test !haskey(growth_2.bounds.objective_weights, "r_4046")
    @test !haskey(growth_2.bounds.objective_weights, "r_4047")
    @test haskey(growth_2.bounds.lb_updates, "r_1714")
    @test haskey(growth_2.bounds.lb_updates, "r_1709")
    @test haskey(growth_2.bounds.ub_updates, "r_1761")
    @test all(rxn_id -> haskey(growth_2.bounds.lb_updates, rxn_id), context.params.nitrogen_source_ids)
    @test all(rxn_id -> haskey(growth_2.bounds.lb_updates, rxn_id), values(reaction_map.amino_acids))
    @test all(rxn_id -> haskey(growth_2.bounds.lb_updates, rxn_id), values(reaction_map.aromas))
    @test model.lb == original_lb
    @test model.ub == original_ub
end

@testset "Sequential reduced DFBA RHS persistent LP primal starts" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    u = _zenteno_state_vector(default_zenteno_initial_state())
    context = DFBAContext(model, reaction_map; lp_reuse = true, lp_primal_start = true)
    du = similar(u)

    dfba_rhs!(du, u, context, 0.0)
    dfba_rhs!(du, u, context, 0.1)

    @test context.lp_reuse == true
    @test context.lp_primal_start == true
    @test context.lp_basis_warm_start == false
    @test context.lp_reuse_warm_start_applied_count[] == 1
    @test context.lp_reuse_update_elapsed_seconds[] >= 0.0
    @test context.lp_reuse_solve_elapsed_seconds[] >= 0.0
    @test context.lp_reuse_simplex_iterations[] >= 0
    @test all(isfinite, du)
end

@testset "Sequential reduced DFBA RHS persistent LP basis warm starts" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    u = _zenteno_state_vector(default_zenteno_initial_state())
    context = DFBAContext(model, reaction_map; lp_reuse = true, lp_basis_warm_start = true)
    du = similar(u)

    dfba_rhs!(du, u, context, 0.0)
    dfba_rhs!(du, u, context, 0.1)

    @test context.lp_reuse == true
    @test context.lp_primal_start == false
    @test context.lp_basis_warm_start == true
    @test context.lp_simplex_strategy == "primal"
    @test context.lp_reuse_warm_start_applied_count[] == 0
    @test context.lp_reuse_basis_warm_start_applied_count[] == 1
    @test context.lp_reuse_basis_warm_start_failed_count[] == 0
    @test context.lp_reuse_basis_capture_count[] == 2
    @test context.lp_reuse_update_elapsed_seconds[] >= 0.0
    @test context.lp_reuse_solve_elapsed_seconds[] >= 0.0
    @test context.lp_reuse_simplex_iterations[] >= 0
    @test all(isfinite, du)
end

@testset "Sequential reduced DFBA RHS wrapper turnover mode" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    turnover_state = ZentenoState(
        0.5,
        0.0,
        110.0,
        110.0,
        0.0,
        0.0,
        0.23,
        0.185,
        zeros(5),
        zeros(6),
    )
    u_turnover = _zenteno_state_vector(turnover_state)
    context = DFBAContext(model, reaction_map)
    rhs_result = compute_dfba_rhs(model, reaction_map, u_turnover)
    du = similar(u_turnover)

    dfba_rhs!(du, u_turnover, context, 0.0)

    @test _all_isapprox(du, rhs_result.dy)
    @test du[1] == 0.0
    @test du[2] == 0.0
    @test du[6] == 0.0
    @test all(iszero, du[9:13])
end

@testset "Sequential reduced DFBA RHS wrapper propagates FBA errors" begin
    params = default_zenteno_parameters()
    reaction_map = default_reduced_reaction_map()
    infeasible_model = _infeasible_dfba_rhs_model(params)
    bad_context = DFBAContext(infeasible_model, reaction_map; params = params)
    u = _zenteno_state_vector(default_zenteno_initial_state())
    du = similar(u)

    err = try
        dfba_rhs!(du, u, bad_context, 0.0)
        nothing
    catch err
        err
    end

    @test err isa ErrorException
    @test occursin("Sequential DFBA RHS FBA solve did not terminate as optimal", sprint(showerror, err))
end

@testset "Sequential reduced DFBA RHS persistent LP propagates FBA errors" begin
    params = default_zenteno_parameters()
    reaction_map = default_reduced_reaction_map()
    infeasible_model = _infeasible_dfba_rhs_model(params)
    context = DFBAContext(infeasible_model, reaction_map; params = params, lp_reuse = true)
    u = _zenteno_state_vector(default_zenteno_initial_state())
    du = similar(u)

    err = try
        dfba_rhs!(du, u, context, 0.0)
        nothing
    catch err
        err
    end

    @test err isa ErrorException
    @test occursin("Sequential DFBA RHS FBA solve did not terminate as optimal", sprint(showerror, err))
    @test context.lp_cache.previous_fluxes === nothing
    @test context.lp_cache.previous_basis_colstatus === nothing
    @test context.lp_cache.previous_basis_rowstatus === nothing
end

@testset "Sequential reduced DFBA RHS wrapper dimensions" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    context = DFBAContext(model, reaction_map)
    u = _zenteno_state_vector(default_zenteno_initial_state())

    @test_throws ErrorException dfba_rhs!(zeros(18), u, context, 0.0)
    @test_throws ErrorException dfba_rhs!(zeros(19), u[1:18], context, 0.0)
end

@testset "Sequential reduced DFBA RHS growth mode" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    state = default_zenteno_initial_state()
    params = default_zenteno_parameters()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    result = compute_dfba_rhs(model, reaction_map, _zenteno_state_vector(state); params = params)

    expected_dy = [
        0.037441775920210765,
        -0.001179940120932177,
        -0.23601087168770463,
        -0.0991232310348679,
        0.1341498878391702,
        0.0,
        0.046614992843507716,
        0.012928457090477982,
        -0.07996,
        -0.07996,
        -0.07996,
        -0.07996,
        -0.07996,
        0.00906515661286332,
        2.361005001715821e-6,
        0.004742576626845715,
        2.8441874206716166e-6,
        0.01044118465094247,
        2.6779391233967487e-5,
    ]

    @test result isa DFBARHSResult
    @test length(result.dy) == 19
    @test _all_isapprox(result.dy, expected_dy)
    @test result.mode == :growth
    @test result.fba.status == MOI.OPTIMAL
    @test model.lb == original_lb
    @test model.ub == original_ub

    @test result.dy[6] == 0.0
    @test result.metadata["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test result.metadata["oxygen_exchange_reaction_id"] == "r_1992"
    @test result.metadata["oxygen_exchange_present"] == false
    @test ismissing(result.metadata["oxygen_exchange_closed"])
    @test result.metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test result.metadata["indices_reacciones_used"] == false
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test !haskey(result.fluxes_by_rxn, "r_1992")
    @test !haskey(result.fluxes_by_rxn, "r_0001")

    biomass_flux = result.fluxes_by_rxn["r_2111"]
    weighted_objective_growth = result.fba.objective_value * state.biomass
    @test isapprox(result.dy[1], biomass_flux * state.biomass; rtol = DFBA_RHS_RTOL, atol = DFBA_RHS_ATOL)
    @test !isapprox(result.dy[1], weighted_objective_growth; rtol = DFBA_RHS_RTOL, atol = DFBA_RHS_ATOL)

    nitrogen_fluxes = [result.fluxes_by_rxn[rxn_id] for rxn_id in params.nitrogen_source_ids]
    expected_nitrogen =
        sum(nitrogen_fluxes .* params.nitrogen_atom_counts .* params.MW_N .* state.biomass)
    @test isapprox(result.dy[2], expected_nitrogen; rtol = DFBA_RHS_RTOL, atol = DFBA_RHS_ATOL)

    expected_carbohydrate =
        max(0.0, biomass_flux) * state.biomass * params.CARB_CONTENT_0 -
        state.carbohydrate * params.K_DEATH
    @test isapprox(result.dy[8], expected_carbohydrate; rtol = DFBA_RHS_RTOL, atol = DFBA_RHS_ATOL)
    @test has_reaction(model, "r_4048")
    @test haskey(result.fluxes_by_rxn, "r_4048")

    @test result.dy[3] < 0.0
    @test result.dy[4] < 0.0
    @test result.dy[5] > 0.0
    @test all(value -> value < 0.0, result.dy[9:13])
    @test all(value -> value >= 0.0, result.dy[14:19])
    @test result.metadata["objective_type"] == "weighted"
    @test result.metadata["n_objective_terms"] == length(result.bounds.objective_weights)
    @test result.metadata["mass_balance_residual"] == result.fba.mass_balance_residual
    @test result.metadata["max_lower_bound_violation"] == result.fba.max_lower_bound_violation
    @test result.metadata["max_upper_bound_violation"] == result.fba.max_upper_bound_violation
end

@testset "Sequential reduced DFBA RHS turnover mode" begin
    model, reaction_map = _load_reduced_dfba_inputs()
    params = default_zenteno_parameters()
    turnover_state = ZentenoState(
        0.5,
        0.0,
        110.0,
        110.0,
        0.0,
        0.0,
        0.23,
        0.185,
        zeros(5),
        zeros(6),
    )
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    result = compute_dfba_rhs(model, reaction_map, _zenteno_state_vector(turnover_state); params = params)

    expected_turnover_dy = [
        0.0,
        0.0,
        -0.20781177187731117,
        -0.07092413122447448,
        0.1341498878391702,
        0.0,
        -0.00805,
        -0.000925,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.3395774243980447e-7,
        0.0,
        1.6137235019492724e-7,
        0.0,
        2.6779391233967487e-5,
    ]

    @test result isa DFBARHSResult
    @test length(result.dy) == 19
    @test _all_isapprox(result.dy, expected_turnover_dy)
    @test result.mode == :turnover
    @test result.fba.status == MOI.OPTIMAL
    @test model.lb == original_lb
    @test model.ub == original_ub

    @test result.dy[1] == 0.0
    @test result.dy[2] == 0.0
    @test result.dy[6] == 0.0
    @test all(iszero, result.dy[9:13])
    @test isapprox(result.fluxes_by_rxn["r_2111"], 0.0; atol = DFBA_RHS_ATOL)
    @test result.bounds.objective_weights["r_4046"] == 1.0
    @test result.bounds.objective_weights["r_4047"] == 1.0
    @test has_reaction(model, "r_4048")
    @test haskey(result.fluxes_by_rxn, "r_4048")

    expected_carbohydrate =
        max(0.0, result.fluxes_by_rxn["r_2111"]) *
        turnover_state.biomass *
        params.CARB_CONTENT_0 -
        turnover_state.carbohydrate * params.K_DEATH
    @test isapprox(result.dy[8], expected_carbohydrate; rtol = DFBA_RHS_RTOL, atol = DFBA_RHS_ATOL)
    @test result.metadata["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test result.metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
end

@testset "Sequential reduced DFBA RHS rejects non-optimal FBA solves" begin
    params = default_zenteno_parameters()
    reaction_map = default_reduced_reaction_map()
    infeasible_model = _infeasible_dfba_rhs_model(params)

    state = default_zenteno_initial_state()
    err = try
        compute_dfba_rhs(infeasible_model, reaction_map, _zenteno_state_vector(state); params = params)
        nothing
    catch err
        err
    end

    @test err isa ErrorException
    @test occursin("Sequential DFBA RHS FBA solve did not terminate as optimal", sprint(showerror, err))
end
