@testset "Dynamic control reference schedule" begin
    schedule = reference_dynamic_control_schedule(horizon_h = 168.0, control_interval_h = 12.0)

    @test length(schedule.temperature_transition_times_h) == 13
    @test length(schedule.temperature_values_C) == 14
    @test schedule.temperature_transition_times_h[1] == 12.0
    @test schedule.temperature_transition_times_h[end] == 156.0
    @test all(schedule.temperature_values_C .== 20.0)
    @test isempty(schedule.fda_events)
    @test isempty(schedule.organic_events)
    @test schedule.fda_total_limit_g_L == FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L
    @test schedule.fda_nitrogen_fraction_gN_per_g == FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G
    @test occursin("FDA solution", schedule.metadata["fda_reference"])
    @test schedule.organic_composition.metadata["product"] == "SpringFerm Xtrem"

    @test dynamic_temperature_celsius(schedule, 0.0) == 20.0
    @test dynamic_temperature_celsius(schedule, 84.0) == 20.0
    @test dynamic_temperature_celsius(schedule, 168.0) == 20.0
    @test isapprox(dynamic_temperature_kelvin(schedule, 84.0), 293.15; atol = 1.0e-12)

    values = dynamic_control_values(schedule, 24.0)
    @test values.fda_product_cumulative_g_L == 0.0
    @test values.fda_product_rate_g_L_h == 0.0
    @test values.organic_product_cumulative_g_L == 0.0
    @test values.organic_product_rate_g_L_h == 0.0
    samples = sample_dynamic_control_schedule(schedule; start_h = 0.0, stop_h = 1.0, dt_h = 0.5)
    @test length(samples) == 3
    @test [sample.time_h for sample in samples] == [0.0, 0.5, 1.0]
    @test dynamic_control_penalty(schedule) == 0.0
end

@testset "Dynamic nutrient product composition defaults" begin
    @test isapprox(fda_solution_nitrogen_fraction_gN_per_g(), 0.02; atol = 1.0e-15)
    @test isapprox(fda_solution_oiv_equivalent_limit_g_L(), 3.0; atol = 1.0e-15)

    springferm = springferm_xtrem_organic_composition()
    @test springferm.metadata["product"] == "SpringFerm Xtrem"
    @test springferm.metadata["nitrogen_basis"] == "yan_equivalent"
    @test springferm.nitrogen_fraction_gN_per_g ==
          SPRINGFERM_XTREM_YAN_EQUIVALENT_FRACTION_GN_PER_G
    @test isapprox(sum(springferm.amino_acid_nitrogen_fractions), 1.0; atol = 1.0e-12)
    @test springferm.amino_acid_nitrogen_fractions[4] == 0.0
    @test springferm.amino_acid_nitrogen_fractions[5] == 0.0

    real_yan = springferm_xtrem_organic_composition(nitrogen_basis = :real_yan)
    @test isapprox(
        real_yan.nitrogen_fraction_gN_per_g,
        0.9431 * 0.0415;
        atol = 1.0e-12,
    )
end

@testset "Dynamic control decision spec" begin
    schedule = reference_dynamic_control_schedule(
        horizon_h = 36.0,
        control_interval_h = 12.0,
        temperature_values_C = [20.0, 21.0, 22.0],
        fda_doses_g_L = [0.10, 0.0],
        organic_doses_g_L = [0.20, 0.10],
        addition_transition_width_h = 0.5,
    )
    spec = dynamic_control_decision_spec(
        schedule;
        temperature_free_indices = [2],
        addition_free_indices = [1],
        temperature_trust_region_C = 0.5,
        fda_trust_region_g_L = 0.25,
        organic_trust_region_g_L = 0.05,
    )

    @test spec isa DynamicControlDecisionSpec
    @test spec.horizon_h == 36.0
    @test spec.control_interval_h == 12.0
    @test spec.temperature_start_C == [20.0, 21.0, 22.0]
    @test spec.temperature_free == [false, true, false]
    @test spec.temperature_lower_C == [20.0, 20.5, 22.0]
    @test spec.temperature_upper_C == [20.0, 21.5, 22.0]
    @test spec.fda_start_g_L == [0.10, 0.0]
    @test spec.fda_free == [true, false]
    @test spec.fda_lower_g_L == [0.0, 0.0]
    @test spec.fda_upper_g_L == [0.35, 0.0]
    @test spec.organic_start_g_L == [0.20, 0.10]
    @test spec.organic_free == [true, false]
    @test spec.organic_lower_g_L ≈ [0.15, 0.10]
    @test spec.organic_upper_g_L ≈ [0.25, 0.10]

    table = dynamic_control_decision_table(spec)
    @test size(table, 1) == 7
    @test names(table) == [
        "variable_name",
        "family",
        "slot_index",
        "time_h",
        "start_value",
        "lower_bound",
        "upper_bound",
        "free",
        "trust_region",
        "unit",
    ]
    @test table[table.variable_name .== "temperature_C[2]", :free] == [true]
    @test table[table.variable_name .== "organic_g_L[2]", :free] == [false]

    moved = dynamic_control_schedule_from_decision_spec(
        spec;
        temperature_values_C = [20.0, 21.4, 22.0],
        fda_doses_g_L = [0.20, 0.0],
        organic_doses_g_L = [0.16, 0.10],
    )
    @test moved.temperature_values_C == [20.0, 21.4, 22.0]
    @test length(moved.fda_events) == 1
    @test moved.fda_events[1].total_product_g_L == 0.20
    @test length(moved.organic_events) == 2
    @test moved.organic_events[1].total_product_g_L == 0.16

    @test_throws ArgumentError dynamic_control_schedule_from_decision_spec(
        spec;
        temperature_values_C = [20.0, 22.0, 22.0],
    )
    @test_throws ArgumentError dynamic_control_decision_spec(
        schedule;
        temperature_free_indices = [4],
    )
end

@testset "Dynamic temperature smoothing" begin
    schedule = DynamicControlSchedule(
        temperature_transition_times_h = [12.0],
        temperature_values_C = [15.0, 25.0],
        temperature_transition_width_h = 1.0,
    )

    @test dynamic_temperature_celsius(schedule, -100.0) == 15.0
    @test dynamic_temperature_celsius(schedule, 100.0) == 25.0
    @test isapprox(dynamic_temperature_celsius(schedule, 12.0), 20.0; atol = 1.0e-12)
    @test dynamic_temperature_celsius(schedule, 8.0) < dynamic_temperature_celsius(schedule, 12.0)
    @test dynamic_temperature_celsius(schedule, 12.0) < dynamic_temperature_celsius(schedule, 16.0)

    base_params = default_zenteno_parameters(MU0 = 0.2)
    warmed = zenteno_parameters_with_temperature(base_params, 298.15)
    @test warmed.MU0 == 0.2
    @test isapprox(warmed.temperature_K, 298.15; atol = 1.0e-12)

    dynamic_params = dynamic_zenteno_parameters(schedule, 12.0; base_params = base_params)
    @test dynamic_params.MU0 == 0.2
    @test isapprox(dynamic_params.temperature_K, 293.15; atol = 1.0e-12)
end

@testset "Smooth pump dose events" begin
    event = SmoothDoseEvent(12.0, 0.3, 1.0)

    @test smooth_dose_cumulative_g_L(event, -100.0) == 0.0
    @test isapprox(smooth_dose_cumulative_g_L(event, 12.0), 0.15; atol = 1.0e-12)
    @test smooth_dose_cumulative_g_L(event, 100.0) == 0.3
    @test isapprox(smooth_dose_rate_g_L_h(event, 12.0), 0.075; atol = 1.0e-12)
end

@testset "Dynamic nutrient additions" begin
    fda_solution_nitrogen_fraction = FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G
    amino_acid_fractions = [0.4, 0.3, 0.2, 0.1, 0.0]
    organic_composition = OrganicNutrientComposition(
        nitrogen_fraction_gN_per_g = 0.10,
        amino_acid_nitrogen_fractions = amino_acid_fractions,
        auxiliary_fractions = Dict("lipid_equivalent" => 0.05),
        metadata = Dict("source" => "unit_test_placeholder"),
    )
    schedule = DynamicControlSchedule(
        fda_events = [SmoothDoseEvent(12.0, 0.3, 1.0)],
        organic_events = [SmoothDoseEvent(24.0, 0.2, 1.0)],
        organic_composition = organic_composition,
    )

    values = dynamic_control_values(schedule, 100.0)
    @test isapprox(values.fda_product_cumulative_g_L, 0.3; atol = 1.0e-12)
    @test isapprox(
        values.fda_nitrogen_cumulative_gN_L,
        0.3 * fda_solution_nitrogen_fraction;
        atol = 1.0e-12,
    )
    @test isapprox(values.organic_product_cumulative_g_L, 0.2; atol = 1.0e-12)
    @test isapprox(values.organic_nitrogen_cumulative_gN_L, 0.02; atol = 1.0e-12)

    params = default_zenteno_parameters()
    delta = dynamic_nutrient_addition_delta(schedule, -100.0, 100.0; params = params)
    @test isapprox(
        delta.free_nitrogen_delta_gN_L,
        0.3 * fda_solution_nitrogen_fraction;
        atol = 1.0e-12,
    )
    @test isapprox(delta.organic_nitrogen_delta_gN_L, 0.02; atol = 1.0e-12)
    @test delta.amino_acid_nitrogen_delta_gN_L ≈ 0.02 .* amino_acid_fractions
    @test delta.amino_acid_state_delta ≈ (0.02 .* amino_acid_fractions) ./ params.MW_N

    updated = apply_dynamic_nutrient_addition(zeros(19), schedule, -100.0, 100.0; params = params)
    @test isapprox(updated[2], 0.3 * fda_solution_nitrogen_fraction; atol = 1.0e-12)
    @test updated[9:13] ≈ (0.02 .* amino_acid_fractions) ./ params.MW_N
    @test all(updated[[1, 3, 4, 5, 6, 7, 8, 14, 15, 16, 17, 18, 19]] .== 0.0)

    @test isapprox(dynamic_control_penalty(schedule), 0.5; atol = 1.0e-12)
end

@testset "Dynamic control RHS rates" begin
    amino_acid_fractions = [0.4, 0.3, 0.2, 0.1, 0.0]
    schedule = DynamicControlSchedule(
        fda_events = [SmoothDoseEvent(12.0, 0.3, 1.0)],
        organic_events = [SmoothDoseEvent(12.0, 0.2, 1.0)],
        organic_composition = OrganicNutrientComposition(
            nitrogen_fraction_gN_per_g = 0.10,
            amino_acid_nitrogen_fractions = amino_acid_fractions,
        ),
        volatilization_model = VaporLiquidVolatilizationModel(
            aroma_partition_coefficients = ones(6),
            gas_exchange_rate_h_inv = 0.1,
        ),
    )
    params = default_zenteno_parameters()
    y = zeros(19)
    y[14:19] .= 1.0
    rates = dynamic_control_rhs_rates(schedule, 12.0, y; params = params)

    @test isapprox(
        rates.free_nitrogen_rate_gN_L_h,
        0.3 * 0.25 * FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G;
        atol = 1.0e-12,
    )
    @test isapprox(rates.organic_nitrogen_rate_gN_L_h, 0.2 * 0.25 * 0.10; atol = 1.0e-12)
    @test rates.amino_acid_nitrogen_rates_gN_L_h ≈ 0.2 * 0.25 * 0.10 .* amino_acid_fractions
    @test rates.amino_acid_state_rates_per_h ≈
        (0.2 * 0.25 * 0.10 .* amino_acid_fractions) ./ params.MW_N
    @test rates.aroma_loss_rates_g_L_h ≈ fill(0.1, 6)

    du = zeros(19)
    returned_rates = apply_dynamic_control_rhs_rates!(du, y, schedule, 12.0; params = params)
    @test returned_rates == rates
    @test isapprox(du[2], rates.free_nitrogen_rate_gN_L_h; atol = 1.0e-12)
    @test du[9:13] ≈ rates.amino_acid_state_rates_per_h
    @test du[14:19] ≈ -rates.aroma_loss_rates_g_L_h
end

@testset "Dynamic control optional penalties and volatilization hook" begin
    schedule = DynamicControlSchedule(
        temperature_transition_times_h = [12.0],
        temperature_values_C = [15.0, 25.0],
        fda_events = [SmoothDoseEvent(12.0, 0.1, 1.0)],
        organic_events = [SmoothDoseEvent(24.0, 0.2, 1.0)],
    )

    @test isapprox(dynamic_control_penalty(schedule), 0.3; atol = 1.0e-12)
    @test isapprox(
        dynamic_control_penalty(schedule; temperature_smoothness_weight = 0.01),
        1.3;
        atol = 1.0e-12,
    )

    @test volatilization_aroma_loss_rates(NoVolatilizationModel(), ones(6)) == zeros(6)

    volatilization = VaporLiquidVolatilizationModel(
        aroma_partition_coefficients = [1.0, 2.0, 0.0, 4.0, 5.0, 6.0],
        gas_exchange_rate_h_inv = 0.1,
    )
    rates = volatilization_aroma_loss_rates(volatilization, [-1.0, 2.0, 3.0, 4.0, 0.0, 6.0])
    @test rates ≈ [0.0, 0.4, 0.0, 1.6, 0.0, 3.6]

    first_pass = white_wine_first_pass_volatilization_model(
        gas_exchange_rate_h_inv = 0.1,
        temperature_reference_C = 20.0,
        temperature_q10 = 2.0,
        sugar_stripping_multiplier_per_g_L_h = 0.5,
    )
    cool_rates = volatilization_aroma_loss_rates(
        first_pass,
        ones(6);
        temperature_C = 20.0,
        sugar_consumption_rate_g_L_h = 0.0,
    )
    warm_active_rates = volatilization_aroma_loss_rates(
        first_pass,
        ones(6);
        temperature_C = 30.0,
        sugar_consumption_rate_g_L_h = 2.0,
    )
    @test all(warm_active_rates .> cool_rates)
end

@testset "Dynamic control validation" begin
    @test_throws ArgumentError SmoothDoseEvent(12.0, -0.1, 1.0)
    @test_throws ArgumentError SmoothDoseEvent(12.0, 0.1, 0.0)
    @test_throws ArgumentError OrganicNutrientComposition(
        amino_acid_nitrogen_fractions = [0.2, 0.2, 0.2, 0.2, 0.3],
    )
    @test_throws ArgumentError DynamicControlSchedule(
        temperature_transition_times_h = [12.0, 6.0],
        temperature_values_C = [20.0, 21.0, 22.0],
    )
    @test_throws ArgumentError DynamicControlSchedule(temperature_values_C = [14.0])
    @test_throws ArgumentError DynamicControlSchedule(
        fda_events = [SmoothDoseEvent(12.0, FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L + 0.01, 1.0)],
    )
    @test_throws ArgumentError sample_dynamic_control_schedule(DynamicControlSchedule(); dt_h = 0.0)
    @test_throws ArgumentError dynamic_control_rhs_rates(DynamicControlSchedule(), 0.0, zeros(18))
    @test_throws ArgumentError apply_dynamic_control_rhs_rates!(zeros(18), zeros(19), DynamicControlSchedule(), 0.0)
    @test_throws ArgumentError dynamic_nutrient_addition_delta(DynamicControlSchedule(), 2.0, 1.0)
    @test_throws ArgumentError zenteno_parameters_with_temperature(default_zenteno_parameters(), 0.0)
end
