import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_dynamic_flux_start_projection_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_dynamic_flux_start_projection_test_simulation()
    time = [0.0, 0.25]
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    states = hcat(initial_state, initial_state)
    fluxes = reshape([0.02, 0.02], 1, 2)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

@testset "Reduced DC-dFBA dynamic flux-start projection metadata" begin
    model, reaction_map = _reduced_dcdfba_dynamic_flux_start_projection_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map; use_dynamic_bounds = true)
    metadata = problem.metadata

    @test metadata["dynamic_flux_start_projection_applied"] == true
    @test metadata["dynamic_flux_start_projection_policy"] ==
          "clamp_flux_start_values_to_numeric_dynamic_or_base_bounds"
    @test metadata["dynamic_flux_start_projection_checked_points"] == 1488 * 3
    @test metadata["dynamic_flux_start_projection_changed_count"] >= 0
    @test metadata["dynamic_flux_start_projection_changed_count"] <=
          metadata["dynamic_flux_start_projection_checked_points"]
    @test metadata["dynamic_flux_start_projection_changed_fraction"] >= 0.0
    @test metadata["dynamic_flux_start_projection_max_adjustment"] >= 0.0
    @test metadata["dynamic_flux_start_projection_max_lower_bound_violation_before"] >= 0.0
    @test metadata["dynamic_flux_start_projection_max_upper_bound_violation_before"] >= 0.0
    @test metadata["dynamic_flux_start_projection_max_lower_bound_violation_after"] <= 1.0e-12
    @test metadata["dynamic_flux_start_projection_max_upper_bound_violation_after"] <= 1.0e-12
    @test problem.nlp.metadata["dynamic_flux_start_projection_applied"] == true
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA dynamic flux-start projection skipped without dynamic bounds" begin
    model, reaction_map = _reduced_dcdfba_dynamic_flux_start_projection_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map)
    metadata = problem.metadata

    @test metadata["dynamic_flux_start_projection_applied"] == false
    @test metadata["dynamic_flux_start_projection_policy"] == "not_applied_no_dynamic_bounds"
    @test metadata["dynamic_flux_start_projection_checked_points"] == 0
    @test metadata["dynamic_flux_start_projection_changed_count"] == 0
    @test metadata["dynamic_flux_start_projection_max_adjustment"] == 0.0
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA solve-attempt diagnostics after dynamic flux-start projection" begin
    model, reaction_map = _reduced_dcdfba_dynamic_flux_start_projection_test_model_and_map()
    simulation = _reduced_dcdfba_dynamic_flux_start_projection_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)

    @test problem.metadata["dynamic_flux_start_projection_applied"] == true
    @test problem.metadata["dynamic_flux_start_projection_changed_count"] >= 0
    @test report.metadata["dynamic_flux_start_projection_applied"] == true
    @test report.scaling_summary["dynamic_flux_start_projection_changed_count"] >= 0.0
    @test report.scaling_summary["dynamic_flux_start_projection_max_adjustment"] >= 0.0
    @test report.residual_values["max_lower_bound_violation"] <= 1.0e-10
    @test report.residual_values["max_upper_bound_violation"] <= 1.0e-10
    @test !("max_lower_bound_violation_above_threshold" in report.warnings)
    @test !("max_upper_bound_violation_above_threshold" in report.warnings)
    @test report.metadata["solver_call_performed"] == false
    @test report.metadata["solve_attempt_is_scientific_simulation"] == false
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end
