@testset "Full model data contract" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")

    paths = load_full_model_paths(paths_config)
    @test paths.model_id == "full_yeast_model"
    @test validate_model_files(paths).ok

    model = load_full_model(paths)

    @test model.model_id == "full_yeast_model"
    @test size(model.S) == (2806, 4131)
    @test length(model.rxn_ids) == 4131
    @test length(model.met_ids) == 2806
    @test length(model.lb) == 4131
    @test length(model.ub) == 4131
    @test validate_full_model_dimensions(model).ok
    @test all(model.lb .<= model.ub)

    for rxn_id in ("r_2111", "r_1714", "r_1709", "r_1761", "r_1992", "r_4046", "r_4047", "r_4048")
        @test has_reaction(model, rxn_id)
    end

    oxygen_index = reaction_index(model, "r_1992")
    @test isapprox(model.lb[oxygen_index], 0.0; atol = 0.0, rtol = 0.0)
    @test isapprox(model.ub[oxygen_index], 0.0; atol = 0.0, rtol = 0.0)
    @test has_reaction(model, "r_4048")
    @test has_reaction(model, "r_0001")

    reaction_map = load_reaction_map(reaction_map_config)
    report = validate_reaction_map(model, reaction_map)

    @test report.ok
    @test isempty(report.disabled_reactions)
    @test reaction_map.core["oxygen_exchange"] == "r_1992"
    @test reaction_map.core["oxygen_exchange"] != "r_0001"
    @test report.found_required_reactions["oxygen_exchange"] == "r_1992"
    @test report.found_required_reactions["carbohydrate_exchange"] == "r_4048"
end
