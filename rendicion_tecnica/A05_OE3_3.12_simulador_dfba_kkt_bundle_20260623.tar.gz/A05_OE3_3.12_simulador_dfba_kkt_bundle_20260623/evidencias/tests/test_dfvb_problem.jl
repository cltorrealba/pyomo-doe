using DataFrames
using MathOptInterface
using SparseArrays

const MOI = MathOptInterface
const STATIC_DFVB_REAL_CACHE = Ref{Any}(nothing)
const STATIC_DFVB_FULL_MODEL_CACHE = Ref{Any}(nothing)

function _synthetic_static_dfvb_artifacts()
    paths = DFVBArtifactPaths(
        "synthetic_static_dfvb",
        "manifest",
        "reaction_order",
        "reduced_dfba_reaction_order",
        "exchange_partition",
        "exchange_partition_active_alpha",
        "n_sparse_triplets",
        "n_column_metadata",
        "n_active_alpha_sparse_triplets",
        "n_active_alpha_column_metadata",
        "active_alpha_indices",
        "alpha_bounds",
        "alpha_bounds_active",
        "alpha_trajectories",
        "alpha_trajectories_active",
        "state_trajectories",
        "inactive_reactions",
        "inactive_reactions_active_alpha",
    )
    manifest = DFVBArtifactManifest(2, 1, 1, 1, 1, 1, true, 1, Dict{String, Any}())
    reaction_order = DataFrame(
        reaction_index = [1, 2],
        reaction_id = ["r_1", "r_2"],
        is_exchange = [true, false],
        is_internal = [false, true],
        exchange_position = [1, 0],
        internal_position = [0, 1],
        is_active_exchange = [true, false],
        is_active_internal = [false, true],
        is_inactive_exchange = [false, false],
        is_inactive_internal = [false, false],
        model_scope = ["synthetic", "synthetic"],
    )
    partition = DataFrame(
        model_scope = ["synthetic", "synthetic"],
        partition = ["exchange", "internal"],
        partition_position = [1, 1],
        reaction_index = [1, 2],
        reaction_id = ["r_1", "r_2"],
        is_active = [true, true],
        is_inactive_forced_zero = [false, false],
    )
    alpha_metadata = DataFrame(
        alpha_index = [1],
        source_alpha_index = [1],
        source_alpha_id = ["alpha_1"],
        is_active = [true],
        model_scope = ["synthetic"],
    )
    alpha_bounds = DataFrame(
        alpha_index = [1],
        source_alpha_index = [1],
        source_alpha_id = ["alpha_1"],
        lower_bound = [0.0],
        upper_bound = [10.0],
        model_scope = ["synthetic"],
    )
    active_alpha_indices = DataFrame(active_alpha_index = [1], source_alpha_index = [1], source_alpha_id = ["alpha_1"])
    N = sparse([1, 2], [1, 1], [1.0, 1.0], 2, 1)
    empty_inactive = DataFrame(model_scope = String[], partition = String[], reaction_id = String[])

    return DFVBArtifacts(
        paths,
        manifest,
        reaction_order,
        DataFrame(reduced_reaction_index = Int[], original_reaction_index = Int[], reaction_id = String[]),
        partition,
        partition,
        N,
        alpha_metadata,
        N,
        alpha_metadata,
        active_alpha_indices,
        alpha_bounds,
        alpha_bounds,
        nothing,
        nothing,
        nothing,
        empty_inactive,
        empty_inactive,
        Dict{String, Any}(
            "indices_reacciones_used" => false,
            "r0001_used_as_oxygen" => false,
        ),
    )
end

function _static_dfvb_real_artifacts()
    if STATIC_DFVB_REAL_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        config_path = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")
        STATIC_DFVB_REAL_CACHE[] = load_dfvb_artifacts(
            config_path;
            load_alpha_trajectories = false,
            load_active_alpha_trajectories = false,
            load_state_trajectories = false,
        )
    end
    return STATIC_DFVB_REAL_CACHE[]
end

function _static_dfvb_full_model()
    if STATIC_DFVB_FULL_MODEL_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        STATIC_DFVB_FULL_MODEL_CACHE[] = load_full_model(joinpath(project_root, "config", "full_model_paths.example.toml"))
    end
    return STATIC_DFVB_FULL_MODEL_CACHE[]
end

@testset "Synthetic static DFVB LP" begin
    model = MetabolicModel(
        sparse([1.0 -1.0]),
        [0.0, 0.0],
        [10.0, 10.0],
        ["r_1", "r_2"],
        ["m_1"];
        model_id = "synthetic_static_dfvb_model",
    )
    artifacts = _synthetic_static_dfvb_artifacts()

    result = solve_static_dfvb(model, artifacts; objective_rxn_id = "r_2", use_active_alpha = true)

    @test result.status == MOI.OPTIMAL
    @test result.primal_status == MOI.FEASIBLE_POINT
    @test result.objective_value ≈ 10.0 atol = 1.0e-8
    @test result.alpha ≈ [10.0] atol = 1.0e-8
    @test result.fluxes ≈ [10.0, 10.0] atol = 1.0e-8
    @test result.mass_balance_residual <= 1.0e-8
    @test result.max_lower_bound_violation <= 1.0e-8
    @test result.max_upper_bound_violation <= 1.0e-8
    @test result.metadata["problem_type"] == "static_dfvb_lp"
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test result.metadata["indices_reacciones_used"] == false
end

@testset "Real active-alpha static DFVB smoke" begin
    model = _static_dfvb_full_model()
    artifacts = _static_dfvb_real_artifacts()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    result = solve_static_dfvb(model, artifacts; objective_rxn_id = "r_2111", use_active_alpha = true, atol = 1.0e-8)
    objective_flux = result.fluxes[reaction_index(model, "r_2111")]
    oxygen_flux = result.fluxes[reaction_index(model, "r_1992")]

    @test result.status == MOI.OPTIMAL
    @test result.primal_status == MOI.FEASIBLE_POINT
    @test result.objective_value > 0.0
    @test result.objective_value ≈ 0.0786661838464292 rtol = 1.0e-5 atol = 1.0e-7
    @test objective_flux ≈ result.objective_value rtol = 1.0e-8 atol = 1.0e-8
    @test oxygen_flux ≈ 0.0 atol = 1.0e-7
    @test result.mass_balance_residual <= 1.0e-6
    @test result.max_lower_bound_violation <= 1.0e-6
    @test result.max_upper_bound_violation <= 1.0e-6
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test result.metadata["indices_reacciones_used"] == false
    @test result.metadata["use_active_alpha"] == true
    @test result.metadata["oxygen_reaction_id"] == "r_1992"
    @test result.metadata["r_1992_flux"] ≈ 0.0 atol = 1.0e-7
    @test model.lb == original_lb
    @test model.ub == original_ub
end

@testset "DFVB flux reconstruction helper" begin
    model = _static_dfvb_full_model()
    artifacts = _static_dfvb_real_artifacts()
    result = solve_static_dfvb(model, artifacts; objective_rxn_id = "r_2111", use_active_alpha = true)

    reconstructed = reconstruct_dfvb_fluxes(artifacts, result.alpha; use_active_alpha = true)
    @test reconstructed ≈ result.fluxes rtol = 1.0e-10 atol = 1.0e-10
end

@testset "DFVB reaction order mismatch" begin
    model = MetabolicModel(
        sparse([1.0 -1.0]),
        [0.0, 0.0],
        [10.0, 10.0],
        ["r_2", "r_1"],
        ["m_1"];
        model_id = "synthetic_static_dfvb_reordered_model",
    )
    artifacts = _synthetic_static_dfvb_artifacts()

    @test_throws ErrorException build_dfvb_problem(model, artifacts; objective_rxn_id = "r_2")
    report = validate_dfvb_reaction_order(model, artifacts; throw_on_error = false)
    @test !report.ok
    @test occursin("DFVB reaction order mismatch at index 1", report.errors[1])
end
