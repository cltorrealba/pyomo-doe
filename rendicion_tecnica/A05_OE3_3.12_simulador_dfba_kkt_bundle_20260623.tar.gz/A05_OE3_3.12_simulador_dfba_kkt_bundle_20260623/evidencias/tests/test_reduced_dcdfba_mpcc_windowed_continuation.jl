using CSV
using DataFrames

import MathOptInterface as MOI

const REDUCED_MPCC_WINDOW_TEST_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _reduced_mpcc_window_test_initial_state()
    y = zeros(19)
    y[1] = 1.0
    y[2] = 0.1
    y[3] = 10.0
    y[4] = 8.0
    y[5] = 0.0
    y[6] = 0.0
    y[7] = 0.2
    y[8] = 0.1
    y[9:19] .= 0.01
    return y
end

function _reduced_mpcc_window_test_sequential_states(initial_state::AbstractVector)
    states = repeat(Float64.(initial_state), 1, 2)
    states[1, 2] += 0.1
    states[2, 2] -= 0.01
    states[3, 2] -= 0.5
    states[4, 2] -= 0.25
    states[5, 2] += 0.2
    states[6, 2] = 0.0
    states[7, 2] += 0.01
    states[8, 2] += 0.005
    return states
end

function _reduced_mpcc_window_test_comparison(;
    t0::Float64,
    tfinal::Float64,
    initial_state::AbstractVector,
    biomass_offset::Float64,
    trajectory_ready::Bool,
    solver_status::String,
)
    times = [t0, tfinal]
    sequential_states = _reduced_mpcc_window_test_sequential_states(initial_state)
    candidate_states = copy(sequential_states)
    candidate_states[1, 2] += biomass_offset
    candidate_states[3, 2] -= 0.1 * biomass_offset
    candidate_states[4, 2] -= 0.05 * biomass_offset
    candidate_states[5, 2] += 0.02 * biomass_offset

    sequential = SimulationResult(
        times,
        sequential_states;
        metadata = Dict{String, Any}(
            "model_id" => "synthetic_reduced_sequential_window",
            "model_scope" => "reduced",
            "state_names" => copy(REDUCED_MPCC_WINDOW_TEST_STATE_NAMES),
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "mode_history" => Symbol[],
            "mass_balance_residuals" => Float64[],
            "max_lower_bound_violations" => Float64[],
            "max_upper_bound_violations" => Float64[],
            "min_state_value" => minimum(sequential_states),
            "has_negative_saved_states" => false,
            "reconstruct_fluxes" => false,
        ),
    )
    boundary_metadata = Dict{String, Any}(
        "model_id" => "synthetic_reduced_mpcc_window",
        "model_scope" => "reduced",
        "state_names" => copy(REDUCED_MPCC_WINDOW_TEST_STATE_NAMES),
        "retcode" => solver_status,
        "termination_reason" => "windowed_mpcc_candidate_diagnostic_only",
        "is_scientific_simulation" => false,
        "min_state_value" => minimum(candidate_states),
    )
    boundary = SimulationResult(times, candidate_states; metadata = boundary_metadata)

    collocation_times = collect(range(t0, tfinal; length = 3))
    collocation_states = repeat(candidate_states[:, 2:2], 1, 3)
    collocation = SimulationResult(
        collocation_times,
        collocation_states;
        metadata = copy(boundary_metadata),
    )

    residuals = Dict{String, Float64}(
        "max_rhs_residual" => 1.0e-12,
        "max_mass_balance_residual" => 5.0e-7,
        "max_lower_bound_violation" => 0.0,
        "max_upper_bound_violation" => 0.0,
        "max_stationarity_residual" => 1.0e-8,
        "max_lower_complementarity_residual" => 5.0e-7,
        "max_upper_complementarity_residual" => 5.0e-7,
    )
    candidate_metadata = Dict{String, Any}(
        "candidate_solver_status" => solver_status,
        "candidate_primal_status" => "FEASIBLE_POINT",
        "candidate_residual_thresholds_satisfied" => true,
        "candidate_residual_feasible" => true,
        "candidate_iteration_limit_residual_feasible" => solver_status == "ITERATION_LIMIT",
        "candidate_warning_count" => solver_status == "ITERATION_LIMIT" ? 1 : 0,
        "candidate_dominant_residual" => "max_mass_balance_residual",
        "candidate_trajectory_extraction_ready" => trajectory_ready,
        "trajectory_candidate_ready" => trajectory_ready,
        "trajectory_candidate_is_scientific_simulation" => false,
        "trajectory_candidate_is_validated_simulation" => false,
        "trajectory_candidate_solved_trajectory_claimed" => false,
        "post_solve_next_recommended_action" =>
            trajectory_ready ? "extract_candidate_trajectory" :
            "review_iteration_limit_residual_feasible_candidate",
        "solve_elapsed_seconds" => trajectory_ready ? 2.0 : 3.0,
        "candidate_grid_nfe" => 1,
        "candidate_collocation_degree" => 3,
        "candidate_grid_tspan" => (t0, tfinal),
        "candidate_boundary_times" => copy(times),
        "candidate_collocation_times" => copy(collocation_times),
        "candidate_state_names" => copy(REDUCED_MPCC_WINDOW_TEST_STATE_NAMES),
    )
    diagnostics = ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(candidate_states),
        reshape(copy(collocation_states), 19, 1, 3),
        zeros(19, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(1, 1, 3),
        residuals,
        Dict{String, Float64}(),
        Dict{String, Float64}(),
        String[],
        trajectory_ready ? String[] : ["candidate_solver_status_blocks_trajectory_extraction"],
        copy(candidate_metadata),
    )
    trajectory_metadata = copy(candidate_metadata)
    trajectory_metadata["model_scope"] = "reduced"
    trajectory = ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary,
        collocation,
        diagnostics,
        trajectory_metadata,
    )
    comparison = compare_reduced_dcdfba_mpcc_to_sequential(sequential, trajectory)
    return comparison, copy(candidate_states[:, end])
end

@testset "Reduced MPCC windowed continuation no-candidate diagnostics" begin
    thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
    metadata = Dict{String, Any}(
        "linear_solver" => "mumps",
        "solve_attempt_ipopt_profile" => "acceptable",
        "complementarity_mode" => "scholtes",
        "complementarity_tau" => 1.0e-2,
        "tau_schedule" => [1.0e-2, 1.0e-4, 1.0e-6],
        "tau_stage_max_iters" => [500, 800, 300],
        "tau_continuation_selected_stage_index" => 1,
        "tau_continuation_selected_tau" => 1.0e-2,
        "tau_continuation_selected_reason" => "no_residual_feasible_stage_using_last_attempt",
        "tau_continuation_attempted_final_tau" => 1.0e-2,
        "tau_continuation_stage_count" => 1,
        "tau_continuation_completed" => false,
        "tau_continuation_blocking_stage" => 1,
        "tau_continuation_blocking_reason" => "pre_solve_guard_blocked",
        "tau_continuation_stage_advance_count" => 0,
        "solver_call_performed" => false,
        "pre_solve_guard_required" => true,
        "pre_solve_guard_passed" => false,
        "pre_solve_guard_failure_component" => "scaling_plan_not_ready",
        "pre_solve_residual_thresholds_satisfied" => true,
        "pre_solve_scaling_plan_ready_for_guarded_solve_attempt" => false,
        "pre_solve_scaling_blocking_warning_count" => 0,
        "pre_solve_scaling_review_warning_count" => 1,
        "pre_solve_warning_count" => 1,
        "pre_solve_first_warning" => "scaling_plan_not_ready_for_guarded_solve_attempt",
        "guarded_solve_attempt_blocked" => true,
        "solver_status" => "OPTIMIZE_NOT_CALLED",
        "primal_status" => "NO_SOLUTION",
        "solve_elapsed_seconds" => 0.0,
        "candidate_residual_feasible" => false,
        "candidate_iteration_limit_residual_feasible" => false,
        "candidate_trajectory_ready" => false,
        "residual_thresholds_satisfied" => false,
        "dominant_residual" => "max_mass_balance_residual",
        "max_rhs_residual" => 1.0e-8,
        "max_mass_balance_residual" => 1.2e-3,
        "max_lower_bound_violation" => 0.0,
        "max_upper_bound_violation" => 0.0,
        "max_stationarity_residual" => 3.0e-5,
        "max_lower_complementarity_residual" => 4.0e-6,
        "max_upper_complementarity_residual" => 5.0e-6,
        "max_lower_complementarity_product" => 4.0e-6,
        "max_upper_complementarity_product" => 5.0e-6,
        "max_complementarity_tau_violation" => 0.0,
        "complementarity_tau_gate_pass" => true,
    )
    smoke = ReducedDCDFBAMPCCSmokeResult(
        MOI.OPTIMIZE_NOT_CALLED,
        MOI.NO_SOLUTION,
        NaN,
        1.2e-3,
        0.0,
        0.0,
        3.0e-5,
        4.0e-6,
        5.0e-6,
        "Ipopt",
        0.0,
        metadata,
    )
    attempt = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke,
        thresholds,
        true,
        false,
        Dict{String, Any}("residuals_available" => true),
        metadata,
        nothing,
    )
    spec = (
        window_id = "window_007",
        window_index = 7,
        t0 = 12.0,
        tfinal = 14.0,
        window_hours = 2.0,
        nfe = 4,
        degree = 3,
        boundary_dt = 0.5,
    )
    err = FermentationDFBA.ReducedDCDFBAMPCCWindowNoCandidateError(attempt)
    row = FermentationDFBA._reduced_mpcc_window_no_candidate_row(spec, attempt, err)

    @test row["window_id"] == "window_007"
    @test row["window_status"] == "failed"
    @test row["candidate_allows_continuation"] == false
    @test row["continuation_acceptance_reason"] == "pre_solve_guard_blocked_no_candidate"
    @test row["solver_call_performed"] == false
    @test row["pre_solve_guard_required"] == true
    @test row["pre_solve_guard_passed"] == false
    @test row["pre_solve_guard_failure_component"] == "scaling_plan_not_ready"
    @test row["pre_solve_residual_thresholds_satisfied"] == true
    @test row["pre_solve_scaling_plan_ready_for_guarded_solve_attempt"] == false
    @test row["pre_solve_scaling_blocking_warning_count"] == 0
    @test row["pre_solve_scaling_review_warning_count"] == 1
    @test row["pre_solve_warning_count"] == 1
    @test row["pre_solve_first_warning"] ==
          "scaling_plan_not_ready_for_guarded_solve_attempt"
    @test row["guarded_solve_attempt_blocked"] == true
    @test row["dominant_residual"] == "max_mass_balance_residual"
    @test row["max_mass_balance_residual"] == 1.2e-3
    @test row["max_lower_complementarity_residual"] == 4.0e-6
    @test row["tau_continuation_blocking_stage"] == 1
    @test row["tau_continuation_blocking_reason"] == "pre_solve_guard_blocked"
    @test occursin("dominant_residual=max_mass_balance_residual", row["error_message"])
end

@testset "Reduced MPCC windowed continuation synthetic aggregation" begin
    initial = _reduced_mpcc_window_test_initial_state()
    first, first_final = _reduced_mpcc_window_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, _ = _reduced_mpcc_window_test_comparison(
        t0 = 0.25,
        tfinal = 0.5,
        initial_state = first_final,
        biomass_offset = 0.02,
        trajectory_ready = false,
        solver_status = "ITERATION_LIMIT",
    )
    second.metadata["cross_window_flux_dual_start_applied"] = true
    second.metadata["cross_window_flux_dual_start_policy"] =
        "previous_window_final_collocation_flux_duals_constant_over_target_window"
    second.metadata["cross_window_flux_dual_start_source"] = "previous_window_candidate"
    second.metadata["cross_window_flux_dual_start_source_tau"] = 1.0e-6

    result = run_reduced_dcdfba_mpcc_windowed_continuation([first, second])
    table = result.window_table
    metadata = result.metadata

    @test result isa ReducedDCDFBAMPCCWindowedContinuationResult
    @test result.window_comparisons == [first, second]
    @test result.sequential_reference isa SimulationResult
    @test result.boundary_candidate isa SimulationResult
    @test size(table, 1) == 2
    @test table[1, "window_id"] == "window_001"
    @test table[2, "window_id"] == "window_002"
    @test table[1, "window_status"] == "completed"
    @test table[1, "candidate_allows_continuation"] == true
    @test table[2, "candidate_allows_continuation"] == true
    @test table[2, "continuation_acceptance_policy"] == "residual_feasible"
    @test table[2, "continuation_acceptance_reason"] ==
          "iteration_limit_residual_feasible"
    @test table[2, "continuation_state_drift_gate_pass"] == true
    @test table[2, "iteration_limit_policy_accepted"] == true
    @test table[1, "candidate_trajectory_ready"] == true
    @test table[2, "candidate_trajectory_ready"] == false
    @test table[2, "candidate_iteration_limit_residual_feasible"] == true
    @test table[2, "initial_state_source"] == "previous_candidate_final_boundary_state"
    @test table[2, "next_initial_state_source"] == "candidate_final_boundary_state"
    @test table[2, "hsl_required"] == false
    @test table[2, "ma57_required"] == false
    @test table[2, "indices_reacciones_used"] == false
    @test table[2, "r0001_used_as_oxygen"] == false
    @test table[2, "cross_window_flux_dual_start_applied"] == true
    @test table[2, "cross_window_flux_dual_start_policy"] ==
          "previous_window_final_collocation_flux_duals_constant_over_target_window"
    @test table[2, "cross_window_flux_dual_start_source_tau"] == 1.0e-6

    @test result.boundary_candidate.time == [0.0, 0.25, 0.5]
    @test size(result.boundary_candidate.states) == (19, 3)
    @test size(result.state_metrics_table, 1) == 20
    @test size(result.aligned_timeseries_table, 1) == 3

    @test metadata["windowed_continuation_type"] ==
          "reduced_dcdfba_mpcc_windowed_continuation_diagnostics"
    @test metadata["n_requested_windows"] == 2
    @test metadata["n_completed_windows"] == 2
    @test metadata["n_failed_windows"] == 0
    @test metadata["continuation_completed"] == true
    @test metadata["continuation_acceptance_policy"] == "residual_feasible"
    @test metadata["continuation_state_drift_gate_enabled"] == false
    @test metadata["continuation_policy_reason_counts"]["iteration_limit_residual_feasible"] == 1
    @test metadata["continuation_policy_rejected_window_count"] == 0
    @test metadata["iteration_limit_policy_accepted_window_count"] == 1
    @test metadata["all_completed_windows_residual_feasible"] == true
    @test metadata["all_completed_windows_allow_continuation"] == true
    @test metadata["all_completed_windows_trajectory_ready"] == false
    @test metadata["cross_window_flux_dual_start_applied_window_count"] == 1
    @test metadata["residual_feasible_window_count"] == 2
    @test metadata["trajectory_ready_window_count"] == 1
    @test metadata["iteration_limit_residual_feasible_window_count"] == 1
    @test metadata["n_total_boundary_points"] == 3
    @test metadata["n_total_collocation_points"] == 6
    @test metadata["total_horizon_reached"] == 0.5
    @test metadata["sequential_reference_available"] == true
    @test metadata["boundary_candidate_available"] == true
    @test metadata["global_state_metrics_available"] == true
    @test isapprox(metadata["global_final_biomass_difference"], 0.02; atol = 1.0e-12)
    @test metadata["outputs_written"] == false
    @test metadata["windowed_continuation_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["scientific_baseline"] == "full_dfba_cold_deferred"
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["reduced_full_equivalence_claimed"] == false
    @test metadata["persistent_lp_baseline_used"] == false
end

@testset "Reduced MPCC windowed continuation acceptance policies" begin
    initial = _reduced_mpcc_window_test_initial_state()
    first, first_final = _reduced_mpcc_window_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, _ = _reduced_mpcc_window_test_comparison(
        t0 = 0.25,
        tfinal = 0.5,
        initial_state = first_final,
        biomass_offset = 0.02,
        trajectory_ready = false,
        solver_status = "ITERATION_LIMIT",
    )

    strict = run_reduced_dcdfba_mpcc_windowed_continuation(
        [first, second];
        continuation_acceptance_policy = "trajectory_ready",
    )
    @test strict.window_table[1, "candidate_allows_continuation"] == true
    @test strict.window_table[2, "candidate_allows_continuation"] == false
    @test strict.window_table[2, "continuation_acceptance_reason"] ==
          "trajectory_ready_required"
    @test strict.window_table[2, "iteration_limit_policy_accepted"] == false
    @test strict.metadata["continuation_completed"] == false
    @test strict.metadata["continuation_policy_rejected_window_count"] == 1
    @test strict.metadata["iteration_limit_policy_accepted_window_count"] == 0

    gated = run_reduced_dcdfba_mpcc_windowed_continuation(
        [first, second];
        continuation_acceptance_policy =
            "iteration_limit_residual_feasible_state_drift",
        continuation_state_relative_rmse_threshold = 1.0,
    )
    @test gated.window_table[2, "candidate_allows_continuation"] == true
    @test gated.window_table[2, "continuation_acceptance_reason"] ==
          "iteration_limit_residual_feasible_state_drift_pass"
    @test gated.window_table[2, "continuation_state_drift_gate_pass"] == true
    @test gated.window_table[2, "iteration_limit_policy_accepted"] == true
    @test gated.metadata["continuation_state_drift_gate_enabled"] == true
    @test gated.metadata["iteration_limit_policy_accepted_window_count"] == 1

    blocked = run_reduced_dcdfba_mpcc_windowed_continuation(
        [first, second];
        continuation_acceptance_policy =
            "iteration_limit_residual_feasible_state_drift",
        continuation_state_relative_rmse_threshold = 0.0,
    )
    @test blocked.window_table[2, "candidate_allows_continuation"] == false
    @test blocked.window_table[2, "continuation_acceptance_reason"] ==
          "state_drift_gate_failed"
    @test blocked.window_table[2, "continuation_state_drift_gate_pass"] == false
    @test blocked.metadata["continuation_completed"] == false
    @test blocked.metadata["continuation_policy_rejected_window_count"] == 1

    review_only_row = FermentationDFBA._reduced_mpcc_window_completed_row(
        2,
        second;
        continuation_acceptance_policy =
            "iteration_limit_residual_feasible_state_drift",
        continuation_state_relative_rmse_threshold = 0.0,
        state_drift_blocks_continuation = false,
    )
    @test review_only_row["candidate_allows_continuation"] == true
    @test review_only_row["continuation_acceptance_reason"] ==
          "iteration_limit_residual_feasible_state_drift_review_only"
    @test review_only_row["continuation_state_drift_gate_pass"] == false
    @test review_only_row["continuation_state_drift_blocks_continuation"] == false
    @test review_only_row["iteration_limit_policy_accepted"] == true

    status_review_decision =
        FermentationDFBA._reduced_mpcc_window_continuation_decision(
            Dict{String, Any}(
                "candidate_residual_feasible" => true,
                "candidate_trajectory_ready" => false,
                "candidate_iteration_limit_residual_feasible" => false,
            ),
            second.state_metrics_table,
            true;
            continuation_acceptance_policy =
                "iteration_limit_residual_feasible_state_drift",
            continuation_state_abs_difference_threshold = 0.0,
            continuation_state_relative_rmse_threshold = 0.0,
            state_drift_blocks_continuation = false,
        )
    @test status_review_decision.allows_continuation == true
    @test status_review_decision.reason ==
          "residual_feasible_state_drift_status_review_only"
    @test status_review_decision.iteration_limit_policy_accepted == false

    @test_throws ArgumentError run_reduced_dcdfba_mpcc_windowed_continuation(
        [first, second];
        continuation_acceptance_policy = "invalid",
    )
    @test_throws ArgumentError run_reduced_dcdfba_mpcc_windowed_continuation(
        [first, second];
        continuation_state_relative_rmse_threshold = -1.0,
    )
end

@testset "Reduced MPCC windowed continuation validation" begin
    @test_throws ArgumentError run_reduced_dcdfba_mpcc_windowed_continuation(
        ReducedDCDFBAMPCCSequentialComparisonResult[],
    )

    initial = _reduced_mpcc_window_test_initial_state()
    first, _ = _reduced_mpcc_window_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    mismatched_reference = SimulationResult(
        [0.0, 0.3],
        first.sequential_result.states;
        metadata = copy(first.sequential_result.metadata),
    )
    @test_throws ArgumentError run_reduced_dcdfba_mpcc_windowed_continuation(
        [first];
        sequential_reference = mismatched_reference,
    )

    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_window_specs(0.0, 0.0, 1, 1, 3)
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_window_specs(0.0, 0.25, 0, 1, 3)
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_window_specs(0.0, 0.25, 1, 0, 3)
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_window_specs(0.0, 0.25, 1, 1, 2)
end

@testset "Reduced MPCC windowed continuation outputs and plots" begin
    initial = _reduced_mpcc_window_test_initial_state()
    first, first_final = _reduced_mpcc_window_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, _ = _reduced_mpcc_window_test_comparison(
        t0 = 0.25,
        tfinal = 0.5,
        initial_state = first_final,
        biomass_offset = 0.02,
        trajectory_ready = false,
        solver_status = "ITERATION_LIMIT",
    )
    result = run_reduced_dcdfba_mpcc_windowed_continuation([first, second])

    mktempdir() do dir
        paths = write_reduced_dcdfba_mpcc_windowed_report(result, dir)

        for key in (
            "diagnostics_window_table",
            "diagnostics_state_metrics",
            "diagnostics_aligned_timeseries",
            "diagnostics_metadata",
            "plot_core_states",
            "plot_nitrogen_reserves",
            "plot_aroma_products",
            "plot_state_relative_rmse",
            "global_start_values_start_values",
            "global_start_values_metadata",
            "global_start_values_array_manifest",
        )
            @test haskey(paths, key)
            @test isfile(paths[key])
        end
        @test result.metadata["outputs_written"] == true
        @test occursin("<svg", read(paths["plot_core_states"], String))
        @test occursin("windowed MPCC", read(paths["plot_core_states"], String))
        @test occursin("biomass", read(paths["plot_core_states"], String))

        @test_throws ErrorException write_reduced_dcdfba_mpcc_windowed_report(result, dir)
        overwritten = write_reduced_dcdfba_mpcc_windowed_report(result, dir; overwrite = true)
        @test sort(collect(keys(overwritten))) == sort(collect(keys(paths)))
    end
end

@testset "Reduced MPCC windowed selective-refinement diagnostics" begin
    window_table = DataFrame(
        "window_id" => ["window_001", "window_002"],
        "window_index" => [1, 2],
        "t0" => [0.0, 2.0],
        "tfinal" => [2.0, 4.0],
        "solver_status" => ["LOCALLY_SOLVED", "ITERATION_LIMIT"],
        "primal_status" => ["FEASIBLE_POINT", "NEARLY_FEASIBLE_POINT"],
        "candidate_residual_feasible" => [true, true],
        "candidate_trajectory_ready" => [true, false],
        "tau_continuation_selected_tau" => [1.0e-4, 1.0e-2],
        "tau_continuation_coarse_tau_fallback_applied" => [false, true],
        "dominant_residual" => [
            "max_lower_complementarity_residual",
            "max_upper_complementarity_residual",
        ],
    )
    aligned = DataFrame(
        "time" => [0.0, 1.0, 2.0, 3.0, 4.0],
        "biomass_sequential" => [1.0, 1.1, 1.2, 1.3, 1.4],
        "biomass_mpcc_candidate" => [1.0, 1.11, 1.2, 1.7, 1.75],
        "methionol_sequential" => [0.0, 0.02, 0.04, 0.06, 0.08],
        "methionol_mpcc_candidate" => [0.0, 0.03, 0.04, 0.12, 0.08],
    )
    aligned[!, "biomass_difference_mpcc_minus_sequential"] =
        aligned[!, "biomass_mpcc_candidate"] .- aligned[!, "biomass_sequential"]
    aligned[!, "methionol_difference_mpcc_minus_sequential"] =
        aligned[!, "methionol_mpcc_candidate"] .- aligned[!, "methionol_sequential"]
    state_metrics = DataFrame(
        "state_name" => ["biomass", "methionol"],
        "relative_rmse" => [0.1, 0.4],
    )

    result = diagnose_reduced_dcdfba_mpcc_windowed_refinement(
        window_table,
        aligned,
        state_metrics,
    )
    @test result isa ReducedDCDFBAMPCCWindowedRefinementDiagnosticResult
    @test nrow(result.window_refinement_candidates) == 2
    @test nrow(result.state_window_errors) == 4
    @test nrow(result.boundary_jumps) == 2
    @test result.window_refinement_candidates[1, "window_id"] == "window_002"
    @test result.window_refinement_candidates[1, "coarse_tau_fallback"] == true
    @test result.metadata["mpcc_rerun_performed"] == false

    mktempdir() do dir
        diagnostics_dir = joinpath(dir, "artifacts", "diagnostics")
        mkpath(diagnostics_dir)
        CSV.write(joinpath(diagnostics_dir, "window_table.csv"), window_table)
        CSV.write(joinpath(diagnostics_dir, "aligned_timeseries.csv"), aligned)
        CSV.write(joinpath(diagnostics_dir, "state_metrics.csv"), state_metrics)

        output_dir = joinpath(dir, "refinement")
        artifact_result = diagnose_reduced_dcdfba_mpcc_windowed_refinement_artifacts(
            joinpath(dir, "artifacts");
            output_dir = output_dir,
            overwrite = true,
        )
        @test nrow(artifact_result.window_refinement_candidates) == 2
        for filename in (
            "window_refinement_candidates.csv",
            "state_window_errors.csv",
            "boundary_jumps.csv",
            "metadata.toml",
            "window_refinement_score.svg",
        )
            @test isfile(joinpath(output_dir, filename))
        end
        @test occursin("<svg", read(joinpath(output_dir, "window_refinement_score.svg"), String))
    end
end

@testset "Reduced MPCC windowed selective-refinement selection and export" begin
    candidates = DataFrame(
        "window_id" => ["window_005", "window_008", "window_010"],
        "window_index" => [5, 8, 10],
        "t0" => [8.0, 14.0, 18.0],
        "tfinal" => [10.0, 16.0, 20.0],
        "refinement_rank" => [1, 2, 3],
        "refinement_score" => [600.0, 500.0, 100.0],
        "refinement_priority" => ["high", "high", "medium"],
        "coarse_tau_fallback" => [true, true, false],
    )

    selected = FermentationDFBA._reduced_mpcc_selective_refinement_select_windows(
        candidates;
        top_n = 1,
        window_ids = String[],
        only_coarse_tau_fallback = true,
        minimum_priority = "high",
    )
    @test nrow(selected) == 1
    @test selected[1, "window_id"] == "window_005"

    requested = FermentationDFBA._reduced_mpcc_selective_refinement_select_windows(
        candidates;
        top_n = 1,
        window_ids = ["window_010"],
        only_coarse_tau_fallback = true,
        minimum_priority = "high",
    )
    @test nrow(requested) == 1
    @test requested[1, "window_id"] == "window_010"

    result = ReducedDCDFBAMPCCWindowedSelectiveRefinementResult(
        selected,
        DataFrame("window_id" => ["window_005"], "solver_status" => ["LOCALLY_SOLVED"]),
        DataFrame(
            "window_id" => ["window_005"],
            "original_tau" => [1.0e-2],
            "refined_tau" => [1.0e-6],
        ),
        DataFrame(
            "window_id" => ["window_005"],
            "state_name" => ["biomass"],
            "relative_rmse" => [0.01],
        ),
        DataFrame(
            "selection_index" => [1, 1],
            "window_id" => ["window_005", "window_005"],
            "window_index" => [5, 5],
            "t0" => [8.0, 8.0],
            "tfinal" => [10.0, 10.0],
            "time" => [8.0, 10.0],
            "biomass_sequential" => [1.0, 1.1],
            "biomass_mpcc_candidate" => [1.0, 1.101],
            "biomass_difference_mpcc_minus_sequential" => [0.0, 0.001],
        ),
        Dict{String, Any}(
            "result_type" => "synthetic_selective_refinement",
            "n_selected_windows" => 1,
        ),
    )
    mktempdir() do dir
        paths = export_reduced_dcdfba_mpcc_windowed_selective_refinement(result, dir)
        for key in (
            "selected_windows",
            "refined_window_table",
            "before_after_table",
            "refined_state_metrics",
            "refined_aligned_timeseries",
            "metadata",
        )
            @test haskey(paths, key)
            @test isfile(paths[key])
        end
        @test_throws ErrorException export_reduced_dcdfba_mpcc_windowed_selective_refinement(result, dir)
        overwritten = export_reduced_dcdfba_mpcc_windowed_selective_refinement(
            result,
            dir;
            overwrite = true,
        )
        @test sort(collect(keys(overwritten))) == sort(collect(keys(paths)))
    end
end

@testset "Reduced MPCC windowed selective replacement export and plots" begin
    window_table = DataFrame(
        "window_id" => ["window_001", "window_002"],
        "window_index" => [1, 2],
        "window_status" => ["completed", "completed"],
    )
    aligned = DataFrame(
        "time" => [0.0, 1.0, 2.0],
        "biomass_sequential" => [1.0, 1.0, 1.0],
        "biomass_mpcc_candidate" => [1.0, 1.5, 2.0],
        "biomass_difference_mpcc_minus_sequential" => [0.0, 0.5, 1.0],
        "glucose_sequential" => [3.0, 2.0, 1.0],
        "glucose_mpcc_candidate" => [3.0, 2.5, 1.5],
        "glucose_difference_mpcc_minus_sequential" => [0.0, 0.5, 0.5],
    )
    state_metrics = FermentationDFBA._reduced_mpcc_selective_replacement_state_metrics(aligned)
    before_after = DataFrame(
        "window_id" => ["window_001"],
        "window_index" => [1],
        "t0" => [0.0],
        "tfinal" => [1.0],
        "original_tau" => [1.0e-4],
        "refined_tau" => [1.0e-6],
        "original_residual_feasible" => [true],
        "refined_residual_feasible" => [true],
        "original_trajectory_ready" => [false],
        "refined_trajectory_ready" => [true],
        "original_max_state_abs_difference" => [0.5],
        "refined_max_state_abs_difference" => [0.02],
        "original_max_state_relative_rmse" => [0.2],
        "refined_max_state_relative_rmse" => [0.01],
    )
    refined_aligned = DataFrame(
        "selection_index" => [1, 1],
        "window_id" => ["window_001", "window_001"],
        "window_index" => [1, 1],
        "t0" => [0.0, 0.0],
        "tfinal" => [1.0, 1.0],
        "time" => [0.0, 1.0],
        "biomass_sequential" => [1.0, 1.0],
        "biomass_mpcc_candidate" => [1.0, 1.02],
        "biomass_difference_mpcc_minus_sequential" => [0.0, 0.02],
        "glucose_sequential" => [3.0, 2.0],
        "glucose_mpcc_candidate" => [3.0, 2.02],
        "glucose_difference_mpcc_minus_sequential" => [0.0, 0.02],
    )

    result = apply_reduced_dcdfba_mpcc_windowed_selective_replacements(
        window_table,
        state_metrics,
        aligned,
        before_after,
        refined_aligned;
        replacement_policy = "trajectory_ready",
    )
    @test result.metadata["n_applied_replacements"] == 1
    @test result.aligned_timeseries_table[2, "biomass_mpcc_candidate"] == 1.02
    @test result.aligned_timeseries_table[1, "biomass_mpcc_candidate"] == 1.0
    @test result.aligned_timeseries_table[2, "biomass_difference_mpcc_minus_sequential"] ≈ 0.02

    mktempdir() do dir
        paths = write_reduced_dcdfba_mpcc_windowed_selective_replacement_report(result, dir)
        for key in (
            "diagnostics_replacement_table",
            "diagnostics_aligned_timeseries",
            "diagnostics_state_metrics",
            "diagnostics_metadata",
            "plot_core_states",
            "plot_state_relative_rmse",
        )
            @test haskey(paths, key)
            @test isfile(paths[key])
        end
        @test occursin("<svg", read(paths["plot_core_states"], String))
    end
end

@testset "Reduced MPCC windowed continuation opt-in real run" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_WINDOWED", "0") == "1"
        project_root = normpath(joinpath(@__DIR__, ".."))
        model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        result = run_reduced_dcdfba_mpcc_windowed_continuation(
            model,
            reaction_map;
            window_hours = 0.25,
            n_windows = 2,
            nfe_per_window = 1,
            degree = 3,
        )

        @test result isa ReducedDCDFBAMPCCWindowedContinuationResult
        @test size(result.window_table, 1) >= 1
        @test result.metadata["outputs_written"] == false
        @test result.metadata["windowed_continuation_is_scientific_simulation"] == false
        @test result.metadata["full_dfba_cold_reference_deferred"] == true
    else
        @info "Skipping reduced MPCC windowed continuation real run; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_WINDOWED=1 to run it."
        @test true
    end
end
