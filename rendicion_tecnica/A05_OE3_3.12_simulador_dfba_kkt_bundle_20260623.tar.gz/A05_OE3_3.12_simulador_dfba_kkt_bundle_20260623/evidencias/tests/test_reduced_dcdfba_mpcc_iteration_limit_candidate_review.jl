using DataFrames

const REDUCED_MPCC_ITERATION_LIMIT_REVIEW_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _reduced_mpcc_iteration_limit_review_candidate(
    window_index::Int;
    ready::Bool,
)
    t0 = (window_index - 1) * 0.5
    tfinal = window_index * 0.5
    states = zeros(19, 2)
    states[1, :] .= [0.5, 0.51]
    states[3, :] .= [110.0, 109.8]
    boundary = SimulationResult(
        [t0, tfinal],
        states;
        metadata = Dict{String, Any}(
            "state_names" => copy(REDUCED_MPCC_ITERATION_LIMIT_REVIEW_STATE_NAMES),
            "model_scope" => "reduced",
            "trajectory_candidate_ready" => ready,
            "is_scientific_simulation" => false,
        ),
    )
    collocation = SimulationResult(
        [t0 + 0.1, t0 + 0.3, tfinal],
        repeat(states[:, 2:2], 1, 3);
        metadata = Dict{String, Any}(
            "state_names" => copy(REDUCED_MPCC_ITERATION_LIMIT_REVIEW_STATE_NAMES),
            "model_scope" => "reduced",
            "trajectory_candidate_ready" => ready,
            "is_scientific_simulation" => false,
        ),
    )
    diagnostics = ReducedDCDFBAMPCCCandidateDiagnostics(
        states,
        reshape(repeat(states[:, 2:2], 1, 3), 19, 1, 3),
        zeros(19, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(1, 1, 3),
        Dict{String, Float64}(
            "max_rhs_residual" => 0.0,
            "max_mass_balance_residual" => 5.0e-7,
            "max_lower_bound_violation" => 0.0,
            "max_upper_bound_violation" => 0.0,
            "max_stationarity_residual" => 0.0,
            "max_lower_complementarity_residual" => 0.0,
            "max_upper_complementarity_residual" => 0.0,
        ),
        Dict{String, Float64}(),
        Dict{String, Float64}(),
        ["max_mass_balance_residual"],
        String[],
        Dict{String, Any}(
            "candidate_solver_status" => ready ? "LOCALLY_SOLVED" : "ITERATION_LIMIT",
            "candidate_residual_feasible" => true,
            "candidate_iteration_limit_residual_feasible" => !ready,
            "candidate_trajectory_extraction_ready" => ready,
            "candidate_is_scientific_simulation" => false,
        ),
    )
    metadata = Dict{String, Any}(
        "trajectory_candidate_ready" => ready,
        "trajectory_candidate_extracted_despite_not_ready" => !ready,
        "trajectory_candidate_is_scientific_simulation" => false,
        "trajectory_candidate_solved_trajectory_claimed" => false,
        "candidate_residual_feasible" => true,
        "candidate_iteration_limit_residual_feasible" => !ready,
        "model_scope" => "reduced",
        "first_mpcc_target" => "reduced_dfba",
    )
    return ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary,
        collocation,
        diagnostics,
        metadata,
    )
end

function _reduced_mpcc_iteration_limit_review_comparison(
    window_index::Int;
    ready::Bool,
)
    t0 = (window_index - 1) * 0.5
    tfinal = window_index * 0.5
    states = zeros(19, 2)
    states[1, :] .= [0.5, 0.51]
    sequential = SimulationResult(
        [t0, tfinal],
        states;
        metadata = Dict{String, Any}(
            "state_names" => copy(REDUCED_MPCC_ITERATION_LIMIT_REVIEW_STATE_NAMES),
            "model_scope" => "reduced",
        ),
    )
    return ReducedDCDFBAMPCCSequentialComparisonResult(
        sequential,
        _reduced_mpcc_iteration_limit_review_candidate(window_index; ready = ready),
        DataFrame(),
        DataFrame(),
        DataFrame(),
        Dict{String, Any}(
            "initial_time" => t0,
            "final_time" => tfinal,
            "candidate_trajectory_ready" => ready,
            "candidate_iteration_limit_residual_feasible" => !ready,
        ),
    )
end

function _reduced_mpcc_iteration_limit_review_attempt()
    residual_thresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(max_mass_balance_residual = 5.0e-6)
    thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
        residual_thresholds = residual_thresholds,
    )
    viability_table = DataFrame(
        "candidate_id" => ["window_001", "window_002", "window_003"],
        "source_type" => fill("windowed_continuation_window", 3),
        "source_row_status" => fill("completed", 3),
        "traffic_light" => ["green", "yellow", "red"],
        "viability_class" => [
            "simulation_viable_candidate",
            "iteration_limit_residual_feasible_candidate",
            "residual_thresholds_failed",
        ],
        "simulation_viable" => [true, false, false],
        "trajectory_ready" => [true, false, false],
        "residual_feasible" => [true, true, false],
        "iteration_limit_residual_feasible" => [false, true, false],
        "residual_thresholds_satisfied" => [true, true, false],
        "residuals_pass" => [true, true, false],
        "state_drift_pass" => [true, true, false],
        "window_index" => [1, 2, 3],
        "window_hours" => [0.5, 0.5, 0.5],
        "nfe" => [2, 2, 2],
        "degree" => [3, 3, 3],
        "solver_status" => ["LOCALLY_SOLVED", "ITERATION_LIMIT", "ITERATION_LIMIT"],
        "primal_status" => fill("FEASIBLE_POINT", 3),
        "max_mass_balance_residual" => [5.0e-7, 6.0e-7, 1.0e-5],
        "max_state_relative_rmse" => [0.001, 0.002, 0.05],
        "dominant_residual" =>
            fill("max_mass_balance_residual", 3),
        "blocking_reasons" => [
            "",
            "candidate_not_trajectory_ready",
            "candidate_not_residual_feasible;residual_thresholds_failed",
        ],
        "review_reasons" => [
            "full_dfba_cold_reference_deferred",
            "iteration_limit_residual_feasible",
            "residual_thresholds_failed",
        ],
    )
    continuation = ReducedDCDFBAMPCCWindowedContinuationResult(
        DataFrame(
            "window_id" => ["window_001", "window_002", "window_003"],
            "window_index" => [1, 2, 3],
        ),
        [
            _reduced_mpcc_iteration_limit_review_comparison(1; ready = true),
            _reduced_mpcc_iteration_limit_review_comparison(2; ready = false),
            _reduced_mpcc_iteration_limit_review_comparison(3; ready = false),
        ],
        nothing,
        nothing,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}("total_horizon_reached" => 1.5),
    )
    report = ReducedDCDFBAMPCCSimulationViabilityReport(
        "windowed_continuation",
        viability_table,
        thresholds,
        Dict{String, Any}("overall_traffic_light" => "red"),
    )
    return ReducedDCDFBAMPCCWindowedSimulationAttemptResult(
        continuation,
        report,
        DataFrame(),
        Dict{String, Any}(
            "target_horizon" => 1.5,
            "horizon_reached" => 1.5,
            "target_completed" => true,
            "attempt_traffic_light" => "red",
            "attempt_viable" => false,
        ),
    )
end

function _reduced_mpcc_iteration_limit_review_empty_policy(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult,
)
    return ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult(
        DataFrame(),
        ReducedDCDFBAMPCCWindowRetryDiagnosticResult[],
        attempt,
        Dict{String, Any}(
            "diagnostic_type" => "reduced_dcdfba_mpcc_windowed_retry_policy_diagnostics",
            "n_selected_windows" => 0,
            "n_retried_windows" => 0,
            "green_recovered_count" => 0,
            "trajectory_ready_recovered_count" => 0,
            "residual_feasible_recovered_count" => 0,
            "all_selected_windows_recovered_green" => false,
            "all_selected_windows_recovered_trajectory_ready" => false,
            "retry_replacement_applied" => false,
        ),
    )
end

@testset "Reduced MPCC iteration-limit candidate review" begin
    attempt = _reduced_mpcc_iteration_limit_review_attempt()
    review = review_reduced_dcdfba_mpcc_iteration_limit_candidates(attempt)

    @test review isa ReducedDCDFBAMPCCIterationLimitCandidateReviewResult
    @test review.source_attempt === attempt
    @test size(review.review_table, 1) == 3
    @test length(review.trajectory_candidates) == 1
    @test review.trajectory_candidates[1] ===
          attempt.continuation_result.window_comparisons[2].trajectory_candidate
    @test review.metadata["review_type"] ==
          "reduced_dcdfba_mpcc_iteration_limit_candidate_review"
    @test review.metadata["selected_candidate_count"] == 1
    @test review.metadata["diagnostic_extraction_allowed_count"] == 1
    @test review.metadata["trajectory_candidate_count"] == 1
    @test review.metadata["any_scientific_acceptance_allowed"] == false
    @test review.metadata["recommended_next_action"] ==
          "compare_iteration_limit_candidate_state_drift_before_policy_change"
    @test review.metadata["outputs_written"] == false
    @test review.metadata["iteration_limit_candidate_review_is_scientific_simulation"] ==
          false
    @test review.metadata["solved_trajectory_claimed"] == false
    @test review.metadata["retry_replacement_applied"] == false
    @test review.metadata["windowed_candidate_rebuilt"] == false
    @test review.metadata["first_mpcc_target"] == "reduced_dfba"
    @test review.metadata["full_model_kkt_deferred"] == true
    @test review.metadata["dfvb_kkt_deferred"] == true
    @test review.metadata["hsl_required"] == false
    @test review.metadata["ma57_required"] == false
    @test review.metadata["indices_reacciones_used"] == false
    @test review.metadata["r0001_used_as_oxygen"] == false

    table = review.review_table
    selected = table[table.window_id .== "window_002", :][1, :]
    rejected = table[table.window_id .== "window_003", :][1, :]
    @test selected["selected_for_review"] == true
    @test selected["selection_reason"] == "iteration_limit_residual_feasible"
    @test selected["review_decision"] ==
          "diagnostic_only_iteration_limit_candidate_review"
    @test selected["diagnostic_extraction_allowed"] == true
    @test selected["scientific_acceptance_allowed"] == false
    @test selected["trajectory_candidate_available"] == true
    @test selected["trajectory_candidate_ready"] == false
    @test selected["trajectory_candidate_extracted_despite_not_ready"] == true
    @test isapprox(selected["max_mass_balance_ratio"], 0.12; atol = 0.0, rtol = 1.0e-12)
    @test rejected["selected_for_review"] == false
    @test rejected["selection_reason"] == "iteration_limit_but_not_residual_feasible"
    @test rejected["diagnostic_extraction_allowed"] == false

    limited = review_reduced_dcdfba_mpcc_iteration_limit_candidates(
        attempt;
        max_candidates = 0,
    )
    @test length(limited.trajectory_candidates) == 0
    @test limited.metadata["selected_candidate_count"] == 1
    @test limited.metadata["diagnostic_extraction_allowed_count"] == 0
    @test limited.review_table[2, "review_decision"] ==
          "selected_but_max_candidates_reached"
    @test_throws ArgumentError review_reduced_dcdfba_mpcc_iteration_limit_candidates(
        attempt;
        max_candidates = -1,
    )
end

@testset "Reduced MPCC iteration-limit candidate review from termination diagnostics" begin
    attempt = _reduced_mpcc_iteration_limit_review_attempt()
    retry_aware = attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
        attempt,
        _reduced_mpcc_iteration_limit_review_empty_policy(attempt),
    )
    termination = diagnose_reduced_dcdfba_mpcc_solver_termination(retry_aware)
    review = review_reduced_dcdfba_mpcc_iteration_limit_candidates(termination)

    @test review.metadata["source_kind"] == "solver_termination_retry_aware_attempt"
    @test review.metadata["retry_aware_attempt_attached"] == true
    @test review.metadata["solver_termination_diagnostic_attached"] == true
    @test review.metadata["dominant_termination_blocker"] ==
          termination.metadata["dominant_termination_blocker"]
    @test review.metadata["solver_termination_recommended_next_action"] ==
          termination.metadata["recommended_next_action"]
    @test length(review.trajectory_candidates) == 1

    unattached = diagnose_reduced_dcdfba_mpcc_solver_termination(attempt)
    @test_throws ArgumentError review_reduced_dcdfba_mpcc_iteration_limit_candidates(
        unattached,
    )
end
