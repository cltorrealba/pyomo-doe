import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_mpcc_smoke_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

@testset "Reduced DC-dFBA MPCC smoke problem contract" begin
    model, reaction_map = _reduced_dcdfba_mpcc_smoke_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map)

    @test problem isa ReducedDCDFBAMPCCSmokeProblem
    @test problem.nlp isa ReducedDCDFBACollocationNLP
    @test problem.rhs_residuals === nothing
    @test problem.primal_feasibility isa ReducedDCDFBAPrimalFeasibilityScaffold
    @test problem.bound_feasibility isa ReducedDCDFBABoundFeasibilityScaffold
    @test problem.stationarity isa ReducedDCDFBAStationarityScaffold
    @test problem.complementarity isa ReducedDCDFBAComplementarityScaffold
    @test length(problem.flux_start) == 1488
    @test all(isfinite, problem.flux_start)

    @test problem.primal_feasibility.layout.total_primal_feasibility_constraints == 1079 * 3
    @test problem.bound_feasibility.layout.n_total_bound_feasibility_constraints == 2 * 1488 * 3
    @test problem.stationarity.layout.n_stationarity_constraints == 1488 * 3
    @test problem.complementarity.layout.n_total_complementarity_constraints == 2 * 1488 * 3
    fixed_reaction_index = reaction_index(model, "r_0217")
    fixed_flux = problem.nlp.flux[fixed_reaction_index, 1, 1]
    @test !JuMP.has_lower_bound(fixed_flux)
    @test !JuMP.has_upper_bound(fixed_flux)
    biomass_index = reaction_index(model, problem.nlp.kkt_problem.reaction_roles.biomass_growth)
    biomass_flux = problem.nlp.flux[biomass_index, 1, 1]
    @test JuMP.has_lower_bound(biomass_flux)
    @test JuMP.has_upper_bound(biomass_flux)
    audit = audit_reduced_mpcc_nlp_structure(problem)
    @test audit.n_fixed_variables == 0
    @test audit.dof_balance >= 0
    @test audit.too_few_degrees_of_freedom_risk == false
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA MPCC smoke preserves custom kinetic parameters" begin
    model, reaction_map = _reduced_dcdfba_mpcc_smoke_test_model_and_map()
    params = default_zenteno_parameters(
        phase_proxy_mode = :free_nitrogen,
        TURNOVER_THRESHOLD = 1.0e-4,
    )
    problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        params = params,
        use_dynamic_bounds = true,
        dynamic_bounds_mode = :smooth_phase,
        dynamic_phase_proxy_mode = :free_nitrogen,
    )

    @test problem.nlp.kkt_problem.params.TURNOVER_THRESHOLD == 1.0e-4
    @test problem.nlp.kkt_problem.params.phase_proxy_mode == :free_nitrogen
    @test problem.nlp.metadata["dynamic_turnover_threshold"] == 1.0e-4
    @test problem.nlp.metadata["dynamic_phase_proxy_mode"] == "free_nitrogen"
end

@testset "Reduced DC-dFBA MPCC smoke metadata guardrails" begin
    model, reaction_map = _reduced_dcdfba_mpcc_smoke_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map)
    metadata = problem.metadata

    @test metadata["problem_type"] == "reduced_dcdfba_mpcc_smoke"
    @test metadata["problem_scope"] == "guarded_reduced_mpcc_solver_entry_smoke"
    @test metadata["optimizer"] == "Ipopt"
    @test metadata["linear_solver"] == "mumps"
    @test metadata["ipopt_max_iter"] == 0
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["model_scope"] == "reduced"
    @test metadata["grid_tspan"] == (0.0, 0.25)
    @test metadata["grid_nfe"] == 1
    @test metadata["collocation_degree"] == 3
    @test metadata["rhs_residuals_included"] == false
    @test metadata["static_fba_flux_start_built"] == true
    @test metadata["static_fba_flux_start_objective_rxn_id"] == "r_2111"
    @test metadata["static_fba_flux_start_status"] in ("OPTIMAL", "LOCALLY_SOLVED")
    @test metadata["static_fba_flux_start_mass_balance_residual"] <= 1.0e-7
    @test metadata["static_fba_flux_start_max_lower_bound_violation"] <= 1.0e-7
    @test metadata["static_fba_flux_start_max_upper_bound_violation"] <= 1.0e-7
    @test metadata["base_flux_bounds_applied"] == false
    @test metadata["base_flux_bounds_partially_applied"] == true
    @test metadata["fixed_flux_variable_bounds_deferred"] == true
    @test metadata["fixed_flux_variable_bound_policy"] ==
          "lb_eq_ub_enforced_by_bound_feasibility_rows_not_variable_bounds"
    @test metadata["fixed_flux_bounds_enforced_by_bound_feasibility_rows"] == true
    @test metadata["fixed_flux_bound_feasibility_reduces_ipopt_fixed_variable_pressure"] == true
    @test metadata["fixed_flux_reaction_count"] == 7
    @test metadata["fixed_flux_collocation_variable_count"] == 21
    @test metadata["fixed_flux_variable_lower_bound_skipped_count"] == 21
    @test metadata["fixed_flux_variable_upper_bound_skipped_count"] == 21
    @test metadata["state_nonnegative_bounds_enabled"] == false
    @test metadata["state_nonnegative_boundary_lower_bound_count"] == 0
    @test metadata["state_nonnegative_collocation_lower_bound_count"] == 0
    @test metadata["mass_balance_constraints_built"] == true
    @test metadata["bound_feasibility_constraints_built"] == true
    @test metadata["stationarity_constraints_built"] == true
    @test metadata["mpcc_complementarity_built"] == true
    @test metadata["kkt_constraints_built"] == true
    @test metadata["full_simultaneous_dfba_solver_built"] == false
    @test metadata["dynamic_flux_bounds_applied"] == false
    @test metadata["solver_call_performed"] == false
    @test metadata["sequential_initialization_built"] == false
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["smoke_result_is_scientific_simulation"] == false

    @test problem.nlp.metadata["problem_type"] == "reduced_dcdfba_mpcc_smoke"
    @test problem.nlp.metadata["solver_call_performed"] == false
end

@testset "Reduced DC-dFBA MPCC smoke state nonnegative bounds opt-in" begin
    model, reaction_map = _reduced_dcdfba_mpcc_smoke_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        state_nonnegative_bounds = true,
    )

    @test JuMP.has_lower_bound(problem.nlp.state_boundary[1, 1])
    @test JuMP.lower_bound(problem.nlp.state_boundary[1, 1]) == 0.0
    @test JuMP.has_lower_bound(problem.nlp.state_collocation[1, 1, 1])
    @test JuMP.lower_bound(problem.nlp.state_collocation[1, 1, 1]) == 0.0
    @test !JuMP.has_lower_bound(problem.nlp.state_derivative[1, 1, 1])
    @test problem.metadata["state_nonnegative_bounds_enabled"] == true
    @test problem.metadata["state_nonnegative_boundary_lower_bound_count"] == 19 * 2
    @test problem.metadata["state_nonnegative_collocation_lower_bound_count"] == 19 * 3

    JuMP.set_start_value(problem.nlp.state_boundary[1, 2], -0.25)
    JuMP.set_start_value(problem.nlp.state_collocation[1, 1, 1], -0.5)
    clamp_metadata =
        FermentationDFBA._reduced_dcdfba_clamp_state_starts_to_nonnegative_bounds!(
            problem.nlp;
            requested = true,
        )
    @test clamp_metadata["state_nonnegative_start_clamp_applied"] == true
    @test clamp_metadata["state_nonnegative_start_clamp_boundary_negative_count_before"] == 1
    @test clamp_metadata["state_nonnegative_start_clamp_collocation_negative_count_before"] == 1
    @test clamp_metadata["state_nonnegative_start_clamp_boundary_negative_count_after"] == 0
    @test clamp_metadata["state_nonnegative_start_clamp_collocation_negative_count_after"] == 0
    @test clamp_metadata["state_nonnegative_start_clamp_max_boundary_adjustment"] == 0.25
    @test clamp_metadata["state_nonnegative_start_clamp_max_collocation_adjustment"] == 0.5
    @test JuMP.start_value(problem.nlp.state_boundary[1, 2]) == 0.0
    @test JuMP.start_value(problem.nlp.state_collocation[1, 1, 1]) == 0.0
end

@testset "Reduced DC-dFBA MPCC smoke with RHS residual scaffold" begin
    model, reaction_map = _reduced_dcdfba_mpcc_smoke_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map; include_rhs = true)

    @test problem.rhs_residuals isa ReducedDCDFBARHSResidualScaffold
    @test problem.rhs_residuals.layout.total_rhs_residual_constraints == 19 * 3
    @test problem.metadata["rhs_residuals_included"] == true
    @test problem.nlp.metadata["ode_rhs_constraints_built"] == true
    @test problem.nlp.metadata["mpcc_complementarity_built"] == true
    @test problem.nlp.metadata["solver_call_performed"] == false
end

@testset "Reduced DC-dFBA MPCC smoke validation" begin
    model, reaction_map = _reduced_dcdfba_mpcc_smoke_test_model_and_map()
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        ipopt_max_iter = -1,
    )
    @test_throws ArgumentError solve_reduced_dcdfba_mpcc_smoke(
        model,
        reaction_map;
        ipopt_max_iter = -1,
    )
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        objective_coefficients = zeros(Float64, 2),
    )
end

@testset "Reduced DC-dFBA MPCC smoke solve opt-in" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_SOLVE", "0") == "1"
        model, reaction_map = _reduced_dcdfba_mpcc_smoke_test_model_and_map()
        result = solve_reduced_dcdfba_mpcc_smoke(model, reaction_map)

        @test result isa ReducedDCDFBAMPCCSmokeResult
        @test result.status in (MOI.ITERATION_LIMIT, MOI.LOCALLY_SOLVED, MOI.ALMOST_LOCALLY_SOLVED, MOI.OPTIMAL)
        @test result.primal_status in (
            MOI.FEASIBLE_POINT,
            MOI.NEARLY_FEASIBLE_POINT,
            MOI.INFEASIBLE_POINT,
            MOI.UNKNOWN_RESULT_STATUS,
        )
        @test result.metadata["solver_result_count"] >= 1
        @test isfinite(result.objective_value)
        @test result.solver_name == "Ipopt"
        @test result.solve_elapsed_seconds >= 0.0
        @test isfinite(result.max_mass_balance_residual)
        @test isfinite(result.max_lower_bound_violation)
        @test isfinite(result.max_upper_bound_violation)
        @test isfinite(result.max_stationarity_residual)
        @test isfinite(result.max_lower_complementarity_residual)
        @test isfinite(result.max_upper_complementarity_residual)
        @test result.metadata["solver_call_performed"] == true
        @test result.metadata["smoke_result_is_scientific_simulation"] == false
    else
        @info "Skipping guarded reduced MPCC solve smoke; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_SOLVE=1 to run it."
        @test true
    end
end
