import JuMP
import MathOptInterface as MOI
import SparseArrays: findnz

function _reduced_dcdfba_stationarity_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_stationarity_ready_nlp(model, reaction_map)
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    primal = add_reduced_dcdfba_primal_feasibility!(nlp)
    bound = add_reduced_dcdfba_bound_feasibility!(nlp)
    return nlp, primal, bound
end

@testset "Reduced DC-dFBA stationarity scaffold contract" begin
    model, reaction_map = _reduced_dcdfba_stationarity_test_model_and_map()
    nlp, primal, bound = _reduced_dcdfba_stationarity_ready_nlp(model, reaction_map)
    variable_count_before = JuMP.num_variables(nlp.jump_model)
    stationarity = add_reduced_dcdfba_stationarity!(nlp, bound)

    @test primal.layout.total_primal_feasibility_constraints == 1079 * 3
    @test bound.layout.n_total_bound_feasibility_constraints == 2 * 1488 * 3
    @test stationarity isa ReducedDCDFBAStationarityScaffold
    @test stationarity.nlp === nlp
    @test stationarity.bound_feasibility === bound
    @test stationarity.layout isa ReducedDCDFBAStationarityLayout
    @test size(stationarity.mass_balance_duals) == (1079, 1, 3)
    @test size(stationarity.stationarity_constraints) == (1488, 1, 3)
    @test all(variable -> variable isa JuMP.VariableRef, stationarity.mass_balance_duals)
    @test all(constraint -> constraint isa JuMP.ConstraintRef, stationarity.stationarity_constraints)
    @test JuMP.num_variables(nlp.jump_model) == variable_count_before + 1079 * 3
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
    @test length(stationarity.objective_coefficients) == 1488
    @test all(iszero, stationarity.objective_coefficients)

    layout = stationarity.layout
    @test layout.n_metabolites == size(model.S, 1) == 1079
    @test layout.n_reactions == size(model.S, 2) == 1488
    @test layout.nfe == 1
    @test layout.collocation_degree == 3
    @test layout.n_collocation_points == 3
    @test layout.n_mass_balance_dual_variables == 1079 * 3
    @test layout.n_stationarity_constraints == 1488 * 3
    @test layout.n_objective_coefficients == 1488
    @test length(stationarity.stationarity_constraints) == layout.n_stationarity_constraints
end

@testset "Reduced DC-dFBA stationarity expression coefficients" begin
    model, reaction_map = _reduced_dcdfba_stationarity_test_model_and_map()
    nlp, _, bound = _reduced_dcdfba_stationarity_ready_nlp(model, reaction_map)
    objective_coefficients = zeros(Float64, length(model.rxn_ids))
    biomass_index = reaction_index(model, "r_2111")
    glucose_index = reaction_index(model, "r_1714")
    objective_coefficients[biomass_index] = -1.0
    objective_coefficients[glucose_index] = 2.0

    stationarity = add_reduced_dcdfba_stationarity!(
        nlp,
        bound;
        objective_coefficients = objective_coefficients,
    )

    biomass_constraint = stationarity.stationarity_constraints[biomass_index, 1, 1]
    glucose_constraint = stationarity.stationarity_constraints[glucose_index, 1, 1]
    @test JuMP.normalized_coefficient(
        biomass_constraint,
        bound.lower_bound_duals[biomass_index, 1, 1],
    ) == 1.0
    @test JuMP.normalized_coefficient(
        biomass_constraint,
        bound.upper_bound_duals[biomass_index, 1, 1],
    ) == 1.0
    @test JuMP.normalized_rhs(biomass_constraint) == 1.0
    @test JuMP.normalized_rhs(glucose_constraint) == -2.0

    row_indices, column_indices, values = findnz(model.S)
    for reaction_index_value in (biomass_index, glucose_index)
        entry_index = findfirst(==(reaction_index_value), column_indices)
        @test entry_index !== nothing
        metabolite_index = row_indices[entry_index]
        coefficient = values[entry_index]
        constraint = stationarity.stationarity_constraints[reaction_index_value, 1, 1]
        dual = stationarity.mass_balance_duals[metabolite_index, 1, 1]
        @test JuMP.normalized_coefficient(constraint, dual) == coefficient
    end
end

@testset "Reduced DC-dFBA stationarity dual variables" begin
    model, reaction_map = _reduced_dcdfba_stationarity_test_model_and_map()
    nlp, _, bound = _reduced_dcdfba_stationarity_ready_nlp(model, reaction_map)
    stationarity = add_reduced_dcdfba_stationarity!(nlp, bound)

    for metabolite_index in (1, 100, 1079), collocation_index in 1:3
        dual = stationarity.mass_balance_duals[metabolite_index, 1, collocation_index]
        @test !JuMP.has_lower_bound(dual)
        @test !JuMP.has_upper_bound(dual)
        @test JuMP.start_value(dual) == 0.0
    end
end

@testset "Reduced DC-dFBA stationarity metadata guardrails" begin
    model, reaction_map = _reduced_dcdfba_stationarity_test_model_and_map()
    nlp, _, bound = _reduced_dcdfba_stationarity_ready_nlp(model, reaction_map)
    @test nlp.metadata["stationarity_constraints_built"] == false

    stationarity = add_reduced_dcdfba_stationarity!(nlp, bound)
    metadata = stationarity.metadata

    @test metadata["stationarity_constraints_built"] == true
    @test metadata["reduced_fba_stationarity_built"] == true
    @test metadata["dual_feasibility_constraints_built"] == true
    @test metadata["stationarity_component"] == "c + S'lambda + alpha_L + alpha_U = 0 at each collocation point"
    @test metadata["stationarity_objective_convention"] == "minimize c'v"
    @test metadata["stationarity_max_objective_policy"] == "pass negated objective weights for a max c'v FBA objective"
    @test metadata["stationarity_objective_coefficients_policy"] == "zero_default"
    @test metadata["stationarity_nonzero_objective_coefficients"] == 0
    @test metadata["stationarity_total_constraints"] == 1488 * 3
    @test metadata["stationarity_reaction_count"] == 1488
    @test metadata["mass_balance_dual_variables_built"] == true
    @test metadata["mass_balance_dual_sign"] == "free"
    @test metadata["mass_balance_dual_variables"] == 1079 * 3
    @test metadata["kkt_constraints_built"] == false
    @test metadata["mpcc_complementarity_built"] == false
    @test metadata["lower_bound_complementarity_built"] == false
    @test metadata["upper_bound_complementarity_built"] == false
    @test metadata["dynamic_flux_bounds_applied"] == false
    @test metadata["solver_call_performed"] == false
    @test metadata["sequential_initialization_built"] == false
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false

    @test nlp.metadata["stationarity_constraints_built"] == true
    @test nlp.metadata["reduced_fba_stationarity_built"] == true
    @test nlp.metadata["dual_feasibility_constraints_built"] == true
    @test nlp.metadata["kkt_constraints_built"] == false
    @test nlp.metadata["mpcc_complementarity_built"] == false
end

@testset "Reduced DC-dFBA stationarity after RHS, primal, and bound feasibility" begin
    model, reaction_map = _reduced_dcdfba_stationarity_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    rhs = add_reduced_dcdfba_rhs_residuals!(nlp)
    primal = add_reduced_dcdfba_primal_feasibility!(nlp)
    bound = add_reduced_dcdfba_bound_feasibility!(nlp)
    stationarity = add_reduced_dcdfba_stationarity!(nlp, bound)

    @test rhs.layout.total_rhs_residual_constraints == 19 * 3
    @test primal.layout.total_primal_feasibility_constraints == 1079 * 3
    @test bound.layout.n_total_bound_feasibility_constraints == 2 * 1488 * 3
    @test stationarity.layout.n_stationarity_constraints == 1488 * 3
    @test nlp.metadata["ode_rhs_constraints_built"] == true
    @test nlp.metadata["mass_balance_constraints_built"] == true
    @test nlp.metadata["bound_feasibility_constraints_built"] == true
    @test nlp.metadata["stationarity_constraints_built"] == true
    @test nlp.metadata["kkt_constraints_built"] == false
    @test nlp.metadata["mpcc_complementarity_built"] == false
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA stationarity validation" begin
    model, reaction_map = _reduced_dcdfba_stationarity_test_model_and_map()
    nlp_without_primal = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    bound_without_primal = add_reduced_dcdfba_bound_feasibility!(nlp_without_primal)
    @test_throws ArgumentError add_reduced_dcdfba_stationarity!(nlp_without_primal, bound_without_primal)

    nlp, _, bound = _reduced_dcdfba_stationarity_ready_nlp(model, reaction_map)
    @test_throws ArgumentError add_reduced_dcdfba_stationarity!(
        nlp,
        bound;
        objective_coefficients = zeros(Float64, 2),
    )
    invalid_coefficients = zeros(Float64, length(model.rxn_ids))
    invalid_coefficients[1] = NaN
    @test_throws ArgumentError add_reduced_dcdfba_stationarity!(
        nlp,
        bound;
        objective_coefficients = invalid_coefficients,
    )

    stationarity = add_reduced_dcdfba_stationarity!(nlp, bound)
    @test stationarity.layout.n_stationarity_constraints == 1488 * 3
    @test_throws ArgumentError add_reduced_dcdfba_stationarity!(nlp, bound)

    other_nlp, _, other_bound = _reduced_dcdfba_stationarity_ready_nlp(model, reaction_map)
    @test_throws ArgumentError add_reduced_dcdfba_stationarity!(other_nlp, bound)
    @test add_reduced_dcdfba_stationarity!(other_nlp, other_bound).layout.n_stationarity_constraints == 1488 * 3
end
