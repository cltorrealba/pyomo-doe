import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_dynamic_flux_lp_starts_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_dynamic_flux_lp_starts_test_simulation()
    time = [0.0, 0.25]
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    states = hcat(initial_state, initial_state)
    fluxes = reshape([0.02, 0.02], 1, 2)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

@testset "Reduced DC-dFBA dynamic local FBA flux starts metadata" begin
    model, reaction_map = _reduced_dcdfba_dynamic_flux_lp_starts_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map; use_dynamic_bounds = true)
    metadata = problem.metadata

    @test metadata["dynamic_flux_lp_start_applied"] == true
    @test metadata["dynamic_flux_lp_start_policy"] ==
          "solve_weighted_local_fba_at_each_collocation_point"
    @test metadata["dynamic_flux_lp_start_collocation_points"] == 3
    @test metadata["dynamic_flux_lp_start_solve_attempt_count"] == 3
    @test metadata["dynamic_flux_lp_start_optimal_count"] == 3
    @test metadata["dynamic_flux_lp_start_status_counts"]["OPTIMAL"] == 3
    @test metadata["dynamic_flux_lp_start_solver"] == "HiGHS"
    @test metadata["dynamic_flux_lp_start_time_limit_seconds"] === missing
    @test metadata["dynamic_flux_lp_start_trace_enabled"] == false
    @test metadata["dynamic_flux_lp_start_max_points"] == 0
    @test metadata["dynamic_flux_lp_start_truncated_by_max_points"] == false
    @test metadata["dynamic_flux_lp_start_fail_fast"] == true
    @test metadata["dynamic_flux_lp_start_last_attempt_element_index"] == 1
    @test metadata["dynamic_flux_lp_start_last_attempt_collocation_index"] == 3
    @test metadata["dynamic_flux_lp_start_last_attempt_ordinal"] == 3
    @test metadata["dynamic_flux_lp_start_max_solve_elapsed_seconds"] >= 0.0
    @test metadata["dynamic_flux_lp_start_objective_policy"] ==
          "zenteno_dynamic_objective_weights_at_collocation_state"
    @test metadata["dynamic_flux_lp_start_objective_value_is_biomass_flux"] == false
    @test isfinite(metadata["dynamic_flux_lp_start_objective_value_min"])
    @test isfinite(metadata["dynamic_flux_lp_start_objective_value_max"])
    @test metadata["dynamic_flux_lp_start_max_mass_balance_residual"] <= 1.0e-8
    @test metadata["dynamic_flux_lp_start_max_lower_bound_violation"] <= 1.0e-8
    @test metadata["dynamic_flux_lp_start_max_upper_bound_violation"] <= 1.0e-8
    @test metadata["dynamic_flux_lp_start_max_adjustment_from_previous"] > 0.0
    @test metadata["dynamic_flux_lp_start_indices_reacciones_used"] == false
    @test metadata["dynamic_flux_lp_start_r0001_used_as_oxygen"] == false
    @test problem.nlp.metadata["dynamic_flux_lp_start_applied"] == true
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA dynamic local FBA flux starts point limit diagnostics" begin
    withenv(
        "MPCC_DYNAMIC_FLUX_LP_MAX_POINTS" => "2",
        "MPCC_DYNAMIC_FLUX_LP_TIME_LIMIT" => "60.0",
    ) do
        model, reaction_map = _reduced_dcdfba_dynamic_flux_lp_starts_test_model_and_map()
        problem =
            build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map; use_dynamic_bounds = true)
        metadata = problem.metadata

        @test metadata["dynamic_flux_lp_start_collocation_points"] == 2
        @test metadata["dynamic_flux_lp_start_solve_attempt_count"] == 2
        @test metadata["dynamic_flux_lp_start_optimal_count"] == 2
        @test metadata["dynamic_flux_lp_start_truncated_by_max_points"] == true
        @test metadata["dynamic_flux_lp_start_max_points"] == 2
        @test metadata["dynamic_flux_lp_start_time_limit_seconds"] == 60.0
        @test metadata["dynamic_flux_lp_start_optimizer_attributes"]["time_limit"] == 60.0
        @test metadata["dynamic_flux_lp_start_last_attempt_ordinal"] == 2
    end
end

@testset "Reduced DC-dFBA dynamic local FBA flux starts skipped without dynamic bounds" begin
    model, reaction_map = _reduced_dcdfba_dynamic_flux_lp_starts_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map)
    metadata = problem.metadata

    @test metadata["dynamic_flux_lp_start_applied"] == false
    @test metadata["dynamic_flux_lp_start_policy"] == "not_applied_no_dynamic_bounds"
    @test metadata["dynamic_flux_lp_start_collocation_points"] == 0
    @test metadata["dynamic_flux_lp_start_optimal_count"] == 0
    @test metadata["dynamic_flux_lp_start_max_mass_balance_residual"] == 0.0
    @test metadata["dynamic_flux_lp_start_max_lower_bound_violation"] == 0.0
    @test metadata["dynamic_flux_lp_start_max_upper_bound_violation"] == 0.0
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA solve-attempt diagnostics after dynamic local FBA flux starts" begin
    model, reaction_map = _reduced_dcdfba_dynamic_flux_lp_starts_test_model_and_map()
    simulation = _reduced_dcdfba_dynamic_flux_lp_starts_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)

    @test problem.metadata["dynamic_flux_lp_start_applied"] == true
    @test problem.metadata["dynamic_flux_lp_start_optimal_count"] == 3
    @test problem.metadata["dynamic_flux_lp_start_max_mass_balance_residual"] <= 1.0e-8
    @test report.metadata["dynamic_flux_lp_start_applied"] == true
    @test report.scaling_summary["dynamic_flux_lp_start_optimal_count"] == 3.0
    @test report.scaling_summary["dynamic_flux_lp_start_max_mass_balance_residual"] <= 1.0e-8
    @test report.residual_values["max_mass_balance_residual"] <= 1.0e-8
    @test report.residual_values["max_lower_bound_violation"] <= 1.0e-8
    @test report.residual_values["max_upper_bound_violation"] <= 1.0e-8
    @test !("max_mass_balance_residual_above_threshold" in report.warnings)
    @test !("max_lower_bound_violation_above_threshold" in report.warnings)
    @test !("max_upper_bound_violation_above_threshold" in report.warnings)
    @test report.metadata["solver_call_performed"] == false
    @test report.metadata["solve_attempt_is_scientific_simulation"] == false
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end
