using DataFrames

function _reduced_mpcc_retry_policy_attempt()
    residual_thresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(max_mass_balance_residual = 5.0e-6)
    thresholds =
        default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            residual_thresholds = residual_thresholds,
        )
    viability_table = DataFrame(
        "candidate_id" => ["window_001", "window_002", "window_003"],
        "source_type" => fill("windowed_continuation_window", 3),
        "source_row_status" => fill("completed", 3),
        "traffic_light" => ["green", "yellow", "yellow"],
        "viability_class" => [
            "simulation_viable_candidate",
            "iteration_limit_residual_feasible_candidate",
            "iteration_limit_residual_feasible_candidate",
        ],
        "simulation_viable" => [true, false, false],
        "trajectory_ready" => [true, false, false],
        "residual_feasible" => [true, true, true],
        "iteration_limit_residual_feasible" => [false, true, true],
        "window_index" => [1, 2, 3],
        "window_hours" => [0.5, 0.5, 0.5],
        "nfe" => [2, 2, 2],
        "degree" => [3, 3, 3],
        "solver_status" => ["LOCALLY_SOLVED", "ITERATION_LIMIT", "ITERATION_LIMIT"],
        "primal_status" => fill("FEASIBLE_POINT", 3),
        "max_mass_balance_residual" => [5.0e-7, 2.0e-6, 3.0e-6],
        "max_state_relative_rmse" => [0.001, 0.002, 0.003],
        "blocking_reasons" => ["", "candidate_not_trajectory_ready", "candidate_not_trajectory_ready"],
        "review_reasons" => ["", "iteration_limit_residual_feasible", "iteration_limit_residual_feasible"],
    )
    report = ReducedDCDFBAMPCCSimulationViabilityReport(
        "windowed_continuation",
        viability_table,
        thresholds,
        Dict{String, Any}("overall_traffic_light" => "yellow"),
    )
    continuation = ReducedDCDFBAMPCCWindowedContinuationResult(
        DataFrame(),
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        nothing,
        nothing,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}("total_horizon_reached" => 1.5),
    )
    return ReducedDCDFBAMPCCWindowedSimulationAttemptResult(
        continuation,
        report,
        DataFrame(),
        Dict{String, Any}(
            "target_horizon" => 1.5,
            "horizon_reached" => 1.5,
            "target_completed" => true,
            "attempt_traffic_light" => "yellow",
        ),
    )
end

function _reduced_mpcc_retry_policy_retry_result(;
    window_index::Int,
    recovered_green::Bool,
    recovered_trajectory::Bool,
)
    source_id = "window_" * lpad(string(window_index), 3, '0')
    best_case = recovered_green || recovered_trajectory ? "retry_002" : "retry_001"
    retry_table = DataFrame(
        "retry_case_id" => ["retry_001", "retry_002"],
        "source_window_id" => [source_id, source_id],
        "source_window_index" => [window_index, window_index],
        "ipopt_max_iter" => [200, 300],
        "solver_status" => [
            "ITERATION_LIMIT",
            recovered_trajectory ? "LOCALLY_SOLVED" : "ITERATION_LIMIT",
        ],
        "traffic_light" => [
            "yellow",
            recovered_green ? "green" : "yellow",
        ],
        "viability_class" => [
            "iteration_limit_residual_feasible_candidate",
            recovered_green ? "simulation_viable_candidate" :
            "iteration_limit_residual_feasible_candidate",
        ],
        "residual_feasible" => [true, true],
        "trajectory_ready" => [false, recovered_trajectory],
        "max_mass_balance_residual" => [2.0e-6, recovered_green ? 4.0e-7 : 2.5e-6],
        "max_mass_balance_ratio" => [0.4, recovered_green ? 0.08 : 0.5],
        "max_state_relative_rmse" => [0.002, recovered_green ? 0.001 : 0.003],
    )
    metadata = Dict{String, Any}(
        "retry_diagnostic_type" => "reduced_dcdfba_mpcc_window_retry_diagnostics",
        "source_window_id" => source_id,
        "source_window_index" => window_index,
        "source_window_t0" => (window_index - 1) * 0.5,
        "source_window_tfinal" => window_index * 0.5,
        "source_window_hours" => 0.5,
        "source_traffic_light" => "yellow",
        "source_viability_class" => "iteration_limit_residual_feasible_candidate",
        "source_solver_status" => "ITERATION_LIMIT",
        "source_residual_feasible" => true,
        "source_max_mass_balance_residual" => 3.0e-6,
        "source_max_mass_balance_ratio" => 0.6,
        "source_blocking_reasons" => "candidate_not_trajectory_ready",
        "n_retry_cases" => 2,
        "green_retry_count" => recovered_green ? 1 : 0,
        "yellow_retry_count" => recovered_green ? 1 : 2,
        "red_retry_count" => 0,
        "residual_feasible_retry_count" => 2,
        "best_retry_case_id" => best_case,
        "best_retry_ipopt_max_iter" => best_case == "retry_002" ? 300 : 200,
        "best_retry_traffic_light" => recovered_green ? "green" : "yellow",
        "best_retry_viability_class" =>
            recovered_green ? "simulation_viable_candidate" :
            "iteration_limit_residual_feasible_candidate",
        "best_retry_max_mass_balance_residual" =>
            recovered_green ? 4.0e-7 : 2.0e-6,
        "best_retry_max_mass_balance_ratio" => recovered_green ? 0.08 : 0.4,
        "retry_recovered_residual_feasibility" => false,
        "retry_recovered_green_window" => recovered_green,
    )
    return ReducedDCDFBAMPCCWindowRetryDiagnosticResult(
        retry_table,
        ReducedDCDFBAMPCCSolveAttemptSweepResult[],
        ReducedDCDFBAMPCCSimulationViabilityReport[],
        metadata,
    )
end

@testset "Reduced MPCC windowed retry policy diagnostics aggregation" begin
    attempt = _reduced_mpcc_retry_policy_attempt()
    retry_results = [
        _reduced_mpcc_retry_policy_retry_result(
            window_index = 2,
            recovered_green = true,
            recovered_trajectory = true,
        ),
        _reduced_mpcc_retry_policy_retry_result(
            window_index = 3,
            recovered_green = false,
            recovered_trajectory = false,
        ),
    ]
    diagnostic = diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        attempt,
        retry_results;
        max_retry_windows = 2,
        ipopt_max_iter_values = [200, 300],
    )

    @test diagnostic isa ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult
    @test diagnostic.source_attempt === attempt
    @test diagnostic.retry_results == retry_results
    @test size(diagnostic.retry_policy_table, 1) == 2
    @test diagnostic.retry_policy_table[1, "source_window_id"] == "window_002"
    @test diagnostic.retry_policy_table[1, "recovered_green_window"] == true
    @test diagnostic.retry_policy_table[1, "recovered_trajectory_ready"] == true
    @test diagnostic.retry_policy_table[1, "best_retry_ipopt_max_iter"] == 300
    @test diagnostic.retry_policy_table[2, "source_window_id"] == "window_003"
    @test diagnostic.retry_policy_table[2, "recovered_green_window"] == false
    @test diagnostic.retry_policy_table[2, "recovered_trajectory_ready"] == false
    @test diagnostic.metadata["diagnostic_type"] ==
          "reduced_dcdfba_mpcc_windowed_retry_policy_diagnostics"
    @test diagnostic.metadata["selected_window_indices"] == [2, 3]
    @test diagnostic.metadata["n_selected_windows"] == 2
    @test diagnostic.metadata["n_retried_windows"] == 2
    @test diagnostic.metadata["green_recovered_count"] == 1
    @test diagnostic.metadata["trajectory_ready_recovered_count"] == 1
    @test diagnostic.metadata["first_unrecovered_window_id"] == "window_003"
    @test diagnostic.metadata["recommended_next_action"] ==
          "review_partial_trajectory_ready_retry_recovery"
    @test diagnostic.metadata["outputs_written"] == false
    @test diagnostic.metadata["retry_policy_diagnostic_is_scientific_simulation"] == false
    @test diagnostic.metadata["solved_trajectory_claimed"] == false
    @test diagnostic.metadata["first_mpcc_target"] == "reduced_dfba"
    @test diagnostic.metadata["hsl_required"] == false
    @test diagnostic.metadata["ma57_required"] == false
    @test diagnostic.metadata["indices_reacciones_used"] == false
    @test diagnostic.metadata["r0001_used_as_oxygen"] == false
end

@testset "Reduced MPCC windowed retry policy diagnostics validation" begin
    attempt = _reduced_mpcc_retry_policy_attempt()

    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        attempt,
        ReducedDCDFBAMPCCWindowRetryDiagnosticResult[];
        selection_policy = "invalid",
    )
    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        attempt,
        ReducedDCDFBAMPCCWindowRetryDiagnosticResult[];
        max_retry_windows = -1,
    )
    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        attempt,
        ReducedDCDFBAMPCCWindowRetryDiagnosticResult[];
        window_indices = [2, 2],
    )
    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        attempt,
        ReducedDCDFBAMPCCWindowRetryDiagnosticResult[];
        window_indices = [99],
    )

    empty = diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        attempt,
        ReducedDCDFBAMPCCWindowRetryDiagnosticResult[];
        max_retry_windows = 0,
    )
    @test size(empty.retry_policy_table, 1) == 0
    @test empty.metadata["n_selected_windows"] == 0
    @test empty.metadata["recommended_next_action"] ==
          "no_retry_windows_selected_review_attempt_status"
end
