import CSV
import TOML
using DataFrames

const REDUCED_DFBA_WARM_TEST_PROJECT_ROOT = normpath(joinpath(@__DIR__, ".."))
const REDUCED_DFBA_WARM_TEST_SCRIPT_PATH =
    joinpath(REDUCED_DFBA_WARM_TEST_PROJECT_ROOT, "scripts", "main_benchmark_reduced_dfba_warm_start.jl")
const REDUCED_DFBA_WARM_TEST_CACHE = Ref{Any}(nothing)

const REDUCED_DFBA_WARM_TEST_SUMMARY_COLUMNS = [
    "scenario_id",
    "lp_strategy",
    "model_reuse",
    "primal_start",
    "basis_warm_start",
    "highs_solver",
    "highs_simplex_strategy",
    "n_evaluations",
    "successful_solves",
    "one_time_build_elapsed_seconds",
    "total_elapsed_seconds",
    "total_update_elapsed_seconds",
    "total_solve_elapsed_seconds",
    "mean_elapsed_seconds",
    "mean_update_elapsed_seconds",
    "mean_solve_elapsed_seconds",
    "total_simplex_iterations",
    "mean_simplex_iterations",
    "warm_start_applied_count",
    "basis_warm_start_applied_count",
    "basis_warm_start_failed_count",
    "basis_capture_count",
    "final_objective_value",
    "final_biomass_flux",
    "max_abs_objective_difference_vs_cold",
    "max_abs_flux_difference_vs_cold",
    "max_abs_dy_difference_vs_cold",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "notes",
]

const REDUCED_DFBA_WARM_TEST_SOLVE_COLUMNS = [
    "scenario_id",
    "eval_index",
    "mode",
    "objective_value",
    "biomass_flux",
    "elapsed_seconds",
    "update_elapsed_seconds",
    "solve_elapsed_seconds",
    "solver_reported_solve_time_seconds",
    "simplex_iterations",
    "warm_start_applied",
    "basis_warm_start_applied",
    "basis_warm_start_failed",
    "basis_capture_succeeded",
    "mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "objective_difference_vs_cold",
    "max_abs_flux_difference_vs_cold",
    "max_abs_dy_difference_vs_cold",
]

function _reduced_dfba_warm_test_result()
    if REDUCED_DFBA_WARM_TEST_CACHE[] === nothing
        model = load_reduced_model(joinpath(REDUCED_DFBA_WARM_TEST_PROJECT_ROOT, "config", "reduced_model_paths.example.toml"))
        reaction_map = load_reaction_map(
            joinpath(REDUCED_DFBA_WARM_TEST_PROJECT_ROOT, "config", "reaction_map_reduced.example.toml"),
        )
        REDUCED_DFBA_WARM_TEST_CACHE[] =
            benchmark_reduced_dfba_warm_start(model, reaction_map; n_evaluations = 3)
    end
    return REDUCED_DFBA_WARM_TEST_CACHE[]
end

function _reduced_dfba_warm_summary_row(table::DataFrame, scenario_id::AbstractString)
    row_index = findfirst(==(String(scenario_id)), String.(table[!, "scenario_id"]))
    row_index === nothing && error("Missing reduced DFBA warm-start summary row $(String(scenario_id)).")
    return table[row_index, :]
end

@testset "Reduced DFBA warm-start benchmark tables" begin
    result = _reduced_dfba_warm_test_result()

    @test result isa ReducedDFBAWarmStartBenchmarkResult
    @test names(result.summary_table) == REDUCED_DFBA_WARM_TEST_SUMMARY_COLUMNS
    @test names(result.solve_table) == REDUCED_DFBA_WARM_TEST_SOLVE_COLUMNS
    @test nrow(result.summary_table) == 4
    @test nrow(result.solve_table) == 12
    @test result.summary_table[!, "scenario_id"] == [
        "cold_rebuild",
        "persistent_no_start",
        "persistent_primal_start",
        "persistent_basis_primal_simplex",
    ]
    @test all(==(3), result.summary_table[!, "n_evaluations"])
    @test all(==(3), result.summary_table[!, "successful_solves"])

    cold = _reduced_dfba_warm_summary_row(result.summary_table, "cold_rebuild")
    no_start = _reduced_dfba_warm_summary_row(result.summary_table, "persistent_no_start")
    primal_start = _reduced_dfba_warm_summary_row(result.summary_table, "persistent_primal_start")
    basis_start = _reduced_dfba_warm_summary_row(result.summary_table, "persistent_basis_primal_simplex")

    @test cold["model_reuse"] == false
    @test cold["primal_start"] == false
    @test cold["basis_warm_start"] == false
    @test no_start["model_reuse"] == true
    @test no_start["primal_start"] == false
    @test no_start["basis_warm_start"] == false
    @test primal_start["model_reuse"] == true
    @test primal_start["primal_start"] == true
    @test primal_start["basis_warm_start"] == false
    @test primal_start["warm_start_applied_count"] == 2
    @test basis_start["model_reuse"] == true
    @test basis_start["primal_start"] == false
    @test basis_start["basis_warm_start"] == true
    @test basis_start["highs_simplex_strategy"] == "primal"
    @test basis_start["basis_warm_start_applied_count"] == 2
    @test basis_start["basis_capture_count"] == 3
    @test basis_start["basis_warm_start_failed_count"] == 0

    for row in eachrow(result.summary_table)
        @test row["max_abs_objective_difference_vs_cold"] <= 1.0e-6
        @test row["max_abs_dy_difference_vs_cold"] <= 1.0e-6
        @test isfinite(Float64(row["max_abs_flux_difference_vs_cold"]))
        @test row["max_mass_balance_residual"] <= 1.0e-8
    end

    @test result.metadata["benchmark_name"] == "reduced_dfba_lp_reuse_warm_start"
    @test result.metadata["model_reuse_included"] == true
    @test result.metadata["primal_start_included"] == true
    @test result.metadata["basis_warm_start_included"] == true
    @test result.metadata["basis_highs_simplex_strategy"] == "primal"
    @test result.metadata["default_simulation_path_changed"] == false
    @test result.metadata["ode_simulation_lp_reuse_guarded"] == true
    @test result.metadata["rhs_equivalence_checked"] == true
    @test result.metadata["trajectory_equivalence_checked"] == false
    @test result.metadata["trajectory_equivalence_passed"] == false
    @test result.metadata["experimental_lp_reuse"] == true
    @test result.metadata["scientific_output_equivalent"] == false
    @test result.metadata["gurobi_required"] == false
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test result.metadata["oxygen_reaction_id"] == "r_1992"
    @test occursin("RHS LP benchmark", result.metadata["interpretation_note"])
    @test occursin("adaptive ODE trajectories", result.metadata["rhs_equivalence_note"])
    @test occursin("experimental_non_equivalent_ode", no_start["notes"])
    @test occursin("experimental_non_equivalent_ode", primal_start["notes"])
    @test occursin("experimental_non_equivalent_ode", basis_start["notes"])
end

@testset "Reduced DFBA warm-start benchmark export" begin
    result = _reduced_dfba_warm_test_result()
    output_dir = mktempdir()
    paths = export_reduced_dfba_warm_start_benchmark(result, output_dir)

    @test isfile(paths["summary"])
    @test isfile(paths["solves"])
    @test isfile(paths["metadata"])
    @test names(CSV.read(paths["summary"], DataFrame)) == REDUCED_DFBA_WARM_TEST_SUMMARY_COLUMNS
    @test names(CSV.read(paths["solves"], DataFrame)) == REDUCED_DFBA_WARM_TEST_SOLVE_COLUMNS

    metadata = TOML.parsefile(paths["metadata"])
    @test metadata["benchmark_name"] == "reduced_dfba_lp_reuse_warm_start"
    @test metadata["basis_warm_start_included"] == true
    @test metadata["basis_highs_simplex_strategy"] == "primal"
    @test metadata["ode_simulation_lp_reuse_guarded"] == true
    @test metadata["rhs_equivalence_checked"] == true
    @test metadata["trajectory_equivalence_checked"] == false
    @test metadata["trajectory_equivalence_passed"] == false
    @test metadata["experimental_lp_reuse"] == true
    @test metadata["scientific_output_equivalent"] == false
    @test metadata["gurobi_required"] == false

    @test_throws ErrorException export_reduced_dfba_warm_start_benchmark(result, output_dir)
    @test export_reduced_dfba_warm_start_benchmark(result, output_dir; overwrite = true) isa Dict{String, String}
end

@testset "Reduced DFBA warm-start benchmark script contract" begin
    @test isfile(REDUCED_DFBA_WARM_TEST_SCRIPT_PATH)
    script_text = read(REDUCED_DFBA_WARM_TEST_SCRIPT_PATH, String)
    for required_text in (
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "DFBA_WARM_BENCH_N_EVALUATIONS",
        "DFBA_WARM_BENCH_LP_ATOL",
        "DFBA_WARM_BENCH_HIGHS_SOLVER",
        "DFBA_WARM_BENCH_SIMPLEX_STRATEGY",
        "DFBA_WARM_BENCH_OUTPUT_DIR",
        "results\", \"benchmarks\", \"reduced_dfba_warm_start_latest",
        "benchmark_reduced_dfba_warm_start",
        "export_reduced_dfba_warm_start_benchmark",
        "basis_warm_start_included",
        "basis_highs_simplex_strategy",
        "ode_simulation_lp_reuse_guarded",
        "rhs_equivalence_checked",
        "trajectory_equivalence_checked",
        "trajectory_equivalence_passed",
        "experimental_lp_reuse",
        "scientific_output_equivalent",
        "rhs_equivalence_note",
        "primal_start_included",
        "model_reuse_included",
        "r0001_used_as_oxygen",
        "oxygen_reaction_id",
    )
        @test occursin(required_text, script_text)
    end
    @test !occursin("Gurobi", script_text)
    @test !occursin("DFBA_SOLVER_BACKEND", script_text)
end
