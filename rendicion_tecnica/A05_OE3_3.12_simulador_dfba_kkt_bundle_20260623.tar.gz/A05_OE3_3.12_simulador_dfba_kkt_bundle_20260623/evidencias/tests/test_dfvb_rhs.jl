import MathOptInterface as DFVB_RHS_MOI

const DFVB_RHS_DIAGNOSTIC_TOLERANCE = 1.0e-6
const DFVB_RHS_RTOL = 1.0e-7
const DFVB_RHS_ATOL = 1.0e-9
const DFVB_RHS_REAL_CACHE = Ref{Any}(nothing)
const DFVB_RHS_FULL_MODEL_CACHE = Ref{Any}(nothing)
const DFVB_RHS_FULL_REACTION_MAP_CACHE = Ref{Any}(nothing)

function _dfvb_rhs_real_artifacts()
    if DFVB_RHS_REAL_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        DFVB_RHS_REAL_CACHE[] = load_dfvb_artifacts(
            joinpath(project_root, "config", "dfvb_artifact_paths.example.toml");
            load_alpha_trajectories = false,
            load_active_alpha_trajectories = false,
            load_state_trajectories = false,
        )
    end
    return DFVB_RHS_REAL_CACHE[]
end

function _dfvb_rhs_full_model()
    if DFVB_RHS_FULL_MODEL_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        DFVB_RHS_FULL_MODEL_CACHE[] = load_full_model(joinpath(project_root, "config", "full_model_paths.example.toml"))
    end
    return DFVB_RHS_FULL_MODEL_CACHE[]
end

function _dfvb_rhs_full_reaction_map()
    if DFVB_RHS_FULL_REACTION_MAP_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        DFVB_RHS_FULL_REACTION_MAP_CACHE[] = load_reaction_map(joinpath(project_root, "config", "reaction_map_full.example.toml"))
    end
    return DFVB_RHS_FULL_REACTION_MAP_CACHE[]
end

function _dfvb_rhs_turnover_state()
    return ZentenoState(
        0.5,
        0.0,
        110.0,
        110.0,
        0.0,
        0.0,
        0.23,
        0.185,
        zeros(5),
        zeros(6),
    )
end

function _dfvb_rhs_all_isapprox(actual, expected; rtol = DFVB_RHS_RTOL, atol = DFVB_RHS_ATOL)
    return length(actual) == length(expected) &&
        all(isapprox(actual[i], expected[i]; rtol = rtol, atol = atol) for i in eachindex(expected))
end

@testset "Sequential DFVB RHS growth mode smoke" begin
    model = _dfvb_rhs_full_model()
    reaction_map = _dfvb_rhs_full_reaction_map()
    artifacts = _dfvb_rhs_real_artifacts()
    state = default_zenteno_initial_state()
    params = default_zenteno_parameters()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    result = compute_dfvb_rhs(
        model,
        reaction_map,
        artifacts,
        zenteno_state_to_vector(state);
        params = params,
        use_active_alpha = true,
    )

    biomass_flux = result.fluxes_by_rxn["r_2111"]
    weighted_objective_growth = result.dfvb.objective_value * state.biomass
    nitrogen_fluxes = [result.fluxes_by_rxn[rxn_id] for rxn_id in params.nitrogen_source_ids]
    expected_nitrogen =
        sum(nitrogen_fluxes .* params.nitrogen_atom_counts .* params.MW_N .* state.biomass)
    expected_carbohydrate =
        max(0.0, biomass_flux) * state.biomass * params.CARB_CONTENT_0 -
        state.carbohydrate * params.K_DEATH

    @test result isa DFVBRHSResult
    @test length(result.dy) == 19
    @test result.mode == :growth
    @test result.metadata["mode"] == "growth"
    @test result.dfvb.status == DFVB_RHS_MOI.OPTIMAL
    @test result.metadata["dfvb_status"] == DFVB_RHS_MOI.OPTIMAL
    @test length(result.alpha) == 490
    @test length(result.alpha_ids) == 490
    @test result.alpha == result.dfvb.alpha
    @test result.alpha_ids == result.dfvb.alpha_ids
    @test result.metadata["use_active_alpha"] == true
    @test result.metadata["alpha_scope"] == "active"
    @test result.metadata["n_alpha"] == 490
    @test result.metadata["rhs_type"] == "dfvb"
    @test result.metadata["problem_type"] == "dfvb_rhs"
    @test result.fluxes_by_rxn["r_2111"] > 0.0
    @test isapprox(result.dy[1], biomass_flux * state.biomass; rtol = DFVB_RHS_RTOL, atol = DFVB_RHS_ATOL)
    @test !isapprox(result.dy[1], weighted_objective_growth; rtol = DFVB_RHS_RTOL, atol = DFVB_RHS_ATOL)
    @test isapprox(result.dy[2], expected_nitrogen; rtol = DFVB_RHS_RTOL, atol = DFVB_RHS_ATOL)
    @test isapprox(result.dy[8], expected_carbohydrate; rtol = DFVB_RHS_RTOL, atol = DFVB_RHS_ATOL)
    @test result.dy[6] == 0.0
    @test haskey(result.fluxes_by_rxn, "r_4048")
    @test haskey(result.fluxes_by_rxn, "r_1992")
    @test haskey(result.fluxes_by_rxn, "r_0001")
    @test isapprox(result.fluxes_by_rxn["r_1992"], 0.0; atol = 1.0e-7)
    @test result.metadata["oxygen_reaction_id"] == "r_1992"
    @test result.metadata["oxygen_derivative_policy"] == "forced_zero_dfvb_r1992"
    @test result.metadata["oxygen_flux_r_1992"] == result.fluxes_by_rxn["r_1992"]
    @test result.metadata["r0001_flux"] == result.fluxes_by_rxn["r_0001"]
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test result.metadata["indices_reacciones_used"] == false
    @test result.metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test result.metadata["objective_value_is_not_biomass_flux"] == true
    @test result.dfvb.mass_balance_residual <= DFVB_RHS_DIAGNOSTIC_TOLERANCE
    @test result.dfvb.max_lower_bound_violation <= DFVB_RHS_DIAGNOSTIC_TOLERANCE
    @test result.dfvb.max_upper_bound_violation <= DFVB_RHS_DIAGNOSTIC_TOLERANCE
    @test result.metadata["mass_balance_residual"] == result.dfvb.mass_balance_residual
    @test result.metadata["max_lower_bound_violation"] == result.dfvb.max_lower_bound_violation
    @test result.metadata["max_upper_bound_violation"] == result.dfvb.max_upper_bound_violation
    @test model.lb == original_lb
    @test model.ub == original_ub
end

@testset "Sequential DFVB RHS turnover mode smoke" begin
    model = _dfvb_rhs_full_model()
    reaction_map = _dfvb_rhs_full_reaction_map()
    artifacts = _dfvb_rhs_real_artifacts()
    state = _dfvb_rhs_turnover_state()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    result = compute_dfvb_rhs(
        model,
        reaction_map,
        artifacts,
        zenteno_state_to_vector(state);
        use_active_alpha = true,
    )

    @test result isa DFVBRHSResult
    @test length(result.dy) == 19
    @test result.mode == :turnover
    @test result.metadata["mode"] == "turnover"
    @test result.dfvb.status == DFVB_RHS_MOI.OPTIMAL
    @test length(result.alpha) == 490
    @test result.metadata["use_active_alpha"] == true
    @test result.dy[1] == 0.0
    @test isapprox(result.fluxes_by_rxn["r_2111"], 0.0; atol = DFVB_RHS_ATOL)
    @test result.dy[2] == 0.0
    @test result.dy[6] == 0.0
    @test all(iszero, result.dy[9:13])
    @test result.metadata["oxygen_derivative_policy"] == "forced_zero_dfvb_r1992"
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test result.metadata["indices_reacciones_used"] == false
    @test result.metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test isapprox(result.fluxes_by_rxn["r_1992"], 0.0; atol = 1.0e-7)
    @test result.dfvb.mass_balance_residual <= DFVB_RHS_DIAGNOSTIC_TOLERANCE
    @test result.dfvb.max_lower_bound_violation <= DFVB_RHS_DIAGNOSTIC_TOLERANCE
    @test result.dfvb.max_upper_bound_violation <= DFVB_RHS_DIAGNOSTIC_TOLERANCE
    @test model.lb == original_lb
    @test model.ub == original_ub
end

@testset "Sequential DFVB RHS wrapper" begin
    model = _dfvb_rhs_full_model()
    reaction_map = _dfvb_rhs_full_reaction_map()
    artifacts = _dfvb_rhs_real_artifacts()
    state = default_zenteno_initial_state()
    u = zenteno_state_to_vector(state)

    context = DFVBContext(model, reaction_map, artifacts)
    rhs_result = compute_dfvb_rhs(model, reaction_map, artifacts, u)
    du = similar(u)
    returned = dfvb_rhs!(du, u, context, 0.0)

    @test context.model === model
    @test context.reaction_map === reaction_map
    @test context.artifacts === artifacts
    @test context.params isa ZentenoKineticParameters
    @test context.use_active_alpha == true
    @test context.silent == true
    @test context.atol == 1.0e-8
    @test context.nonoptimal_policy == :error
    @test returned === nothing
    @test length(du) == 19
    @test _dfvb_rhs_all_isapprox(du, rhs_result.dy)

    @test_throws ErrorException DFVBContext(model, reaction_map, artifacts; atol = 0.0)
    @test_throws ErrorException DFVBContext(model, reaction_map, artifacts; atol = -1.0e-8)
    @test_throws ErrorException DFVBContext(model, reaction_map, artifacts; nonoptimal_policy = :return_zero)
    @test_throws ErrorException dfvb_rhs!(zeros(18), u, context, 0.0)
    @test_throws ErrorException dfvb_rhs!(zeros(19), u[1:18], context, 0.0)
end
