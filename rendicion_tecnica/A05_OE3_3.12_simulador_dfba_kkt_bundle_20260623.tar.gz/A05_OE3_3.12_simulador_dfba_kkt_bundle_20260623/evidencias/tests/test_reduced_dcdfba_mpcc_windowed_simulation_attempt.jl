const REDUCED_MPCC_ATTEMPT_TEST_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _reduced_mpcc_attempt_test_initial_state()
    y = zeros(19)
    y[1] = 1.0
    y[2] = 0.1
    y[3] = 10.0
    y[4] = 8.0
    y[5] = 0.0
    y[6] = 0.0
    y[7] = 0.2
    y[8] = 0.1
    y[9:19] .= 0.01
    return y
end

function _reduced_mpcc_attempt_test_sequential_states(initial_state::AbstractVector)
    states = repeat(Float64.(initial_state), 1, 2)
    states[1, 2] += 0.1
    states[2, 2] -= 0.01
    states[3, 2] -= 0.5
    states[4, 2] -= 0.25
    states[5, 2] += 0.2
    states[6, 2] = 0.0
    states[7, 2] += 0.01
    states[8, 2] += 0.005
    return states
end

function _reduced_mpcc_attempt_test_comparison(;
    t0::Float64,
    tfinal::Float64,
    initial_state::AbstractVector,
    biomass_offset::Float64,
    trajectory_ready::Bool,
    solver_status::String,
)
    times = [t0, tfinal]
    sequential_states = _reduced_mpcc_attempt_test_sequential_states(initial_state)
    candidate_states = copy(sequential_states)
    candidate_states[1, 2] += biomass_offset

    sequential = SimulationResult(
        times,
        sequential_states;
        metadata = Dict{String, Any}(
            "model_id" => "synthetic_reduced_sequential_window",
            "model_scope" => "reduced",
            "state_names" => copy(REDUCED_MPCC_ATTEMPT_TEST_STATE_NAMES),
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "mode_history" => Symbol[],
            "mass_balance_residuals" => Float64[],
            "max_lower_bound_violations" => Float64[],
            "max_upper_bound_violations" => Float64[],
            "min_state_value" => minimum(sequential_states),
            "has_negative_saved_states" => false,
            "reconstruct_fluxes" => false,
        ),
    )
    boundary_metadata = Dict{String, Any}(
        "model_id" => "synthetic_reduced_mpcc_window",
        "model_scope" => "reduced",
        "state_names" => copy(REDUCED_MPCC_ATTEMPT_TEST_STATE_NAMES),
        "retcode" => solver_status,
        "termination_reason" => "windowed_mpcc_candidate_diagnostic_only",
        "is_scientific_simulation" => false,
        "min_state_value" => minimum(candidate_states),
    )
    boundary = SimulationResult(times, candidate_states; metadata = boundary_metadata)
    collocation_times = collect(range(t0, tfinal; length = 3))
    collocation_states = repeat(candidate_states[:, 2:2], 1, 3)
    collocation = SimulationResult(
        collocation_times,
        collocation_states;
        metadata = copy(boundary_metadata),
    )
    residuals = Dict{String, Float64}(
        "max_rhs_residual" => 1.0e-12,
        "max_mass_balance_residual" => 5.0e-7,
        "max_lower_bound_violation" => 0.0,
        "max_upper_bound_violation" => 0.0,
        "max_stationarity_residual" => 1.0e-8,
        "max_lower_complementarity_residual" => 5.0e-7,
        "max_upper_complementarity_residual" => 5.0e-7,
    )
    candidate_metadata = Dict{String, Any}(
        "candidate_solver_status" => solver_status,
        "candidate_primal_status" => "FEASIBLE_POINT",
        "candidate_residual_thresholds_satisfied" => true,
        "candidate_residual_feasible" => true,
        "candidate_iteration_limit_residual_feasible" => solver_status == "ITERATION_LIMIT",
        "candidate_warning_count" => solver_status == "ITERATION_LIMIT" ? 1 : 0,
        "candidate_dominant_residual" => "max_mass_balance_residual",
        "candidate_trajectory_extraction_ready" => trajectory_ready,
        "trajectory_candidate_ready" => trajectory_ready,
        "trajectory_candidate_is_scientific_simulation" => false,
        "trajectory_candidate_is_validated_simulation" => false,
        "trajectory_candidate_solved_trajectory_claimed" => false,
        "post_solve_next_recommended_action" =>
            trajectory_ready ? "extract_candidate_trajectory" :
            "review_iteration_limit_residual_feasible_candidate",
        "solve_elapsed_seconds" => trajectory_ready ? 2.0 : 3.0,
        "candidate_grid_nfe" => 1,
        "candidate_collocation_degree" => 3,
        "candidate_grid_tspan" => (t0, tfinal),
        "candidate_boundary_times" => copy(times),
        "candidate_collocation_times" => copy(collocation_times),
        "candidate_state_names" => copy(REDUCED_MPCC_ATTEMPT_TEST_STATE_NAMES),
    )
    diagnostics = ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(candidate_states),
        reshape(copy(collocation_states), 19, 1, 3),
        zeros(19, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(1, 1, 3),
        residuals,
        Dict{String, Float64}(),
        Dict{String, Float64}(),
        String[],
        trajectory_ready ? String[] : ["candidate_solver_status_blocks_trajectory_extraction"],
        copy(candidate_metadata),
    )
    trajectory_metadata = copy(candidate_metadata)
    trajectory_metadata["model_scope"] = "reduced"
    trajectory = ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary,
        collocation,
        diagnostics,
        trajectory_metadata,
    )
    return compare_reduced_dcdfba_mpcc_to_sequential(sequential, trajectory), copy(candidate_states[:, end])
end

@testset "Reduced MPCC windowed simulation attempt synthetic aggregation" begin
    initial = _reduced_mpcc_attempt_test_initial_state()
    first, first_final = _reduced_mpcc_attempt_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, _ = _reduced_mpcc_attempt_test_comparison(
        t0 = 0.25,
        tfinal = 0.5,
        initial_state = first_final,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )

    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first, second])
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 0.5,
    )
    table = attempt.attempt_table
    metadata = attempt.metadata

    @test attempt isa ReducedDCDFBAMPCCWindowedSimulationAttemptResult
    @test attempt.continuation_result === continuation
    @test attempt.viability_report isa ReducedDCDFBAMPCCSimulationViabilityReport
    @test size(table, 1) == 3
    @test "windowed_global" in String.(table[!, "candidate_id"])
    @test table[!, "target_horizon"] == fill(0.5, 3)
    @test all(==(true), table[!, "target_completed"])
    @test all(==("green"), String.(table[!, "attempt_traffic_light"]))
    @test all(==(true), table[!, "attempt_viable"])

    @test metadata["attempt_type"] == "reduced_dcdfba_mpcc_windowed_simulation_attempt"
    @test metadata["target_horizon"] == 0.5
    @test metadata["target_is_72h"] == false
    @test metadata["horizon_reached"] == 0.5
    @test metadata["horizon_gap"] == 0.0
    @test metadata["target_completion_fraction"] == 1.0
    @test metadata["target_completed"] == true
    @test metadata["attempt_traffic_light"] == "green"
    @test metadata["attempt_viable"] == true
    @test metadata["n_requested_windows"] == 2
    @test metadata["n_completed_windows"] == 2
    @test metadata["n_failed_windows"] == 0
    @test metadata["continuation_acceptance_policy"] == "residual_feasible"
    @test metadata["continuation_state_relative_rmse_threshold"] ≈ 2.0e-2
    @test metadata["continuation_state_drift_gate_enabled"] == false
    @test metadata["continuation_policy_rejected_window_count"] == 0
    @test metadata["iteration_limit_policy_accepted_window_count"] == 0
    @test metadata["window_green_count"] == 2
    @test metadata["window_yellow_count"] == 0
    @test metadata["window_red_count"] == 0
    @test metadata["all_windows_green"] == true
    @test metadata["first_non_green_window_id"] === missing
    @test metadata["first_red_window_id"] === missing
    @test metadata["first_not_residual_feasible_window_id"] === missing
    @test metadata["outputs_written"] == false
    @test metadata["attempt_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["scientific_baseline"] == "full_dfba_cold_deferred"
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["recommended_next_action"] ==
          "review_windowed_target_candidate_before_scientific_use"
end

@testset "Reduced MPCC windowed simulation attempt target gate" begin
    initial = _reduced_mpcc_attempt_test_initial_state()
    first, _ = _reduced_mpcc_attempt_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first])
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 0.5,
    )

    @test attempt.metadata["horizon_reached"] == 0.25
    @test attempt.metadata["horizon_gap"] == 0.25
    @test attempt.metadata["target_completed"] == false
    @test attempt.metadata["attempt_traffic_light"] == "red"
    @test attempt.metadata["attempt_viable"] == false
    @test attempt.metadata["first_red_window_id"] === missing
    @test attempt.metadata["first_not_residual_feasible_window_id"] === missing
    @test attempt.metadata["recommended_next_action"] ==
          "extend_or_repair_windowed_continuation_to_target"
end

@testset "Reduced MPCC windowed simulation attempt validation" begin
    initial = _reduced_mpcc_attempt_test_initial_state()
    first, _ = _reduced_mpcc_attempt_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first])

    @test_throws ArgumentError attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 0.0,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_windowed_attempt_n_windows_from_target(
        0.5,
        0.3,
    )
    @test FermentationDFBA._reduced_mpcc_windowed_attempt_n_windows_from_target(
        72.0,
        0.5,
    ) == 144
end

@testset "Reduced MPCC windowed simulation attempt opt-in real run" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_WINDOWED_ATTEMPT", "0") == "1"
        project_root = normpath(joinpath(@__DIR__, ".."))
        model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        result = attempt_reduced_dcdfba_mpcc_windowed_simulation(
            model,
            reaction_map;
            target_horizon = 0.5,
            window_hours = 0.25,
            nfe_per_window = 1,
            degree = 3,
        )

        @test result isa ReducedDCDFBAMPCCWindowedSimulationAttemptResult
        @test size(result.attempt_table, 1) >= 1
        @test result.metadata["outputs_written"] == false
        @test result.metadata["attempt_is_scientific_simulation"] == false
        @test result.metadata["full_dfba_cold_reference_deferred"] == true
    else
        @info "Skipping reduced MPCC windowed simulation attempt real run; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_WINDOWED_ATTEMPT=1 to run it."
        @test true
    end
end
