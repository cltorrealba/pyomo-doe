using DataFrames

const REDUCED_MPCC_RETRY_TEST_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _reduced_mpcc_retry_dummy_comparison(t0::Float64, tfinal::Float64)
    states = zeros(19, 2)
    states[1, :] .= [0.5, 0.51]
    states[3, :] .= [110.0, 109.9]
    states[4, :] .= [110.0, 109.95]
    sequential = SimulationResult(
        [t0, tfinal],
        states;
        metadata = Dict{String, Any}(
            "state_names" => copy(REDUCED_MPCC_RETRY_TEST_STATE_NAMES),
            "model_scope" => "reduced",
            "retcode" => "Success",
            "termination_reason" => "synthetic",
        ),
    )
    boundary = SimulationResult(
        [t0, tfinal],
        copy(states);
        metadata = Dict{String, Any}(
            "state_names" => copy(REDUCED_MPCC_RETRY_TEST_STATE_NAMES),
            "model_scope" => "reduced",
            "retcode" => "ITERATION_LIMIT",
        ),
    )
    collocation = SimulationResult(
        [t0 + 0.1, t0 + 0.3, tfinal],
        repeat(states[:, 2:2], 1, 3);
        metadata = Dict{String, Any}(
            "state_names" => copy(REDUCED_MPCC_RETRY_TEST_STATE_NAMES),
            "model_scope" => "reduced",
            "retcode" => "ITERATION_LIMIT",
        ),
    )
    diagnostics = ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(states),
        reshape(repeat(states[:, 2:2], 1, 3), 19, 1, 3),
        zeros(19, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(1, 1, 3),
        Dict{String, Float64}(
            "max_rhs_residual" => 0.0,
            "max_mass_balance_residual" => 2.0e-6,
            "max_lower_bound_violation" => 0.0,
            "max_upper_bound_violation" => 0.0,
            "max_stationarity_residual" => 0.0,
            "max_lower_complementarity_residual" => 0.0,
            "max_upper_complementarity_residual" => 0.0,
        ),
        Dict{String, Float64}(),
        Dict{String, Float64}(),
        ["max_mass_balance_residual"],
        String[],
        Dict{String, Any}("model_scope" => "reduced"),
    )
    trajectory = ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary,
        collocation,
        diagnostics,
        Dict{String, Any}("model_scope" => "reduced"),
    )
    return ReducedDCDFBAMPCCSequentialComparisonResult(
        sequential,
        trajectory,
        DataFrame(),
        DataFrame(),
        DataFrame(),
        Dict{String, Any}("initial_time" => t0, "final_time" => tfinal),
    )
end

function _reduced_mpcc_retry_source_attempt()
    comparisons = [
        _reduced_mpcc_retry_dummy_comparison((i - 1) * 0.5, i * 0.5) for i in 1:14
    ]
    window_table = DataFrame(
        "window_id" => ["window_014"],
        "window_index" => [14],
        "t0" => [6.5],
        "tfinal" => [7.0],
        "window_hours" => [0.5],
        "nfe" => [2],
        "degree" => [3],
        "boundary_dt" => [0.25],
        "window_status" => ["completed"],
    )
    continuation = ReducedDCDFBAMPCCWindowedContinuationResult(
        window_table,
        comparisons,
        nothing,
        nothing,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}(
            "total_horizon_reached" => 7.0,
            "continuation_completed" => false,
        ),
    )
    thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds()
    viability_table = DataFrame(
        "candidate_id" => ["window_014"],
        "source_type" => ["windowed_continuation_window"],
        "source_row_status" => ["completed"],
        "traffic_light" => ["red"],
        "viability_class" => ["residual_thresholds_failed"],
        "residual_feasible" => [false],
        "iteration_limit_residual_feasible" => [false],
        "trajectory_ready" => [false],
        "residuals_pass" => [false],
        "state_drift_pass" => [true],
        "window_index" => [14],
        "nfe" => [2],
        "degree" => [3],
        "solver_status" => ["ITERATION_LIMIT"],
        "primal_status" => ["FEASIBLE_POINT"],
        "solve_elapsed_seconds" => [25.0],
        "max_rhs_residual" => [0.0],
        "max_mass_balance_residual" => [2.0e-6],
        "max_lower_bound_violation" => [0.0],
        "max_upper_bound_violation" => [0.0],
        "max_stationarity_residual" => [0.0],
        "max_lower_complementarity_residual" => [0.0],
        "max_upper_complementarity_residual" => [0.0],
        "max_state_relative_rmse" => [1.0e-5],
        "blocking_reasons" =>
            ["candidate_not_residual_feasible;residual_thresholds_failed"],
        "review_reasons" => ["full_dfba_cold_reference_deferred"],
        "next_recommended_action" => ["improve_residuals_before_trajectory_extraction"],
    )
    source_report = ReducedDCDFBAMPCCSimulationViabilityReport(
        "windowed_continuation",
        viability_table,
        thresholds,
        Dict{String, Any}("overall_traffic_light" => "red"),
    )
    return ReducedDCDFBAMPCCWindowedSimulationAttemptResult(
        continuation,
        source_report,
        DataFrame(),
        Dict{String, Any}(
            "target_horizon" => 72.0,
            "horizon_reached" => 7.0,
            "attempt_traffic_light" => "red",
            "first_not_residual_feasible_window_index" => 14,
            "first_red_window_index" => 14,
            "first_non_green_window_index" => 14,
        ),
    )
end

function _reduced_mpcc_retry_report(;
    mass_balance::Float64,
    traffic_light::String,
    viability_class::String,
    residual_feasible::Bool,
    trajectory_ready::Bool,
)
    thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds()
    table = DataFrame(
        "candidate_id" => ["scenario_001"],
        "source_type" => ["solve_attempt_sweep"],
        "source_row_status" => ["completed"],
        "traffic_light" => [traffic_light],
        "viability_class" => [viability_class],
        "residual_feasible" => [residual_feasible],
        "iteration_limit_residual_feasible" =>
            [traffic_light == "yellow" && residual_feasible],
        "trajectory_ready" => [trajectory_ready],
        "residuals_pass" => [mass_balance <= thresholds.max_mass_balance_residual],
        "state_drift_pass" => [true],
        "solver_status" => [trajectory_ready ? "LOCALLY_SOLVED" : "ITERATION_LIMIT"],
        "primal_status" => ["FEASIBLE_POINT"],
        "solve_elapsed_seconds" => [30.0],
        "max_rhs_residual" => [0.0],
        "max_mass_balance_residual" => [mass_balance],
        "max_lower_bound_violation" => [0.0],
        "max_upper_bound_violation" => [0.0],
        "max_stationarity_residual" => [0.0],
        "max_lower_complementarity_residual" => [0.0],
        "max_upper_complementarity_residual" => [0.0],
        "max_state_relative_rmse" => [1.0e-5],
        "blocking_reasons" => [traffic_light == "green" ? "" : "candidate_not_trajectory_ready"],
        "review_reasons" => ["full_dfba_cold_reference_deferred"],
        "next_recommended_action" =>
            [traffic_light == "green" ? "review_green_candidate_before_scientific_use" :
             "improve_solver_termination_before_simulation"],
    )
    return ReducedDCDFBAMPCCSimulationViabilityReport(
        "solve_attempt_sweep",
        table,
        thresholds,
        Dict{String, Any}("overall_traffic_light" => traffic_light),
    )
end

@testset "Reduced MPCC window retry diagnostics aggregation" begin
    attempt = _reduced_mpcc_retry_source_attempt()
    reports = [
        _reduced_mpcc_retry_report(
            mass_balance = 1.5e-6,
            traffic_light = "red",
            viability_class = "residual_thresholds_failed",
            residual_feasible = false,
            trajectory_ready = false,
        ),
        _reduced_mpcc_retry_report(
            mass_balance = 5.0e-7,
            traffic_light = "green",
            viability_class = "simulation_viable_candidate",
            residual_feasible = true,
            trajectory_ready = true,
        ),
    ]
    result = diagnose_reduced_dcdfba_mpcc_window_retry(
        attempt,
        reports;
        window_index = 14,
        ipopt_max_iter_values = [200, 500],
    )

    @test result isa ReducedDCDFBAMPCCWindowRetryDiagnosticResult
    @test size(result.retry_table, 1) == 2
    @test result.metadata["retry_diagnostic_type"] ==
          "reduced_dcdfba_mpcc_window_retry_diagnostics"
    @test result.metadata["source_window_id"] == "window_014"
    @test result.metadata["source_window_t0"] == 6.5
    @test result.metadata["source_window_tfinal"] == 7.0
    @test result.metadata["source_max_mass_balance_ratio"] == 2.0
    @test result.metadata["best_retry_case_id"] == "retry_002"
    @test result.metadata["best_retry_ipopt_max_iter"] == 500
    @test result.metadata["best_retry_max_mass_balance_ratio"] == 0.5
    @test result.metadata["retry_recovered_residual_feasibility"] == true
    @test result.metadata["retry_recovered_green_window"] == true
    @test result.metadata["recommended_next_action"] ==
          "resume_windowed_attempt_with_retry_policy"
    @test result.metadata["outputs_written"] == false
    @test result.metadata["retry_diagnostic_is_scientific_simulation"] == false
    @test result.metadata["first_mpcc_target"] == "reduced_dfba"
    @test result.metadata["hsl_required"] == false
    @test result.metadata["ma57_required"] == false

    table = result.retry_table
    @test table[1, "max_mass_balance_ratio"] == 1.5
    @test table[1, "improved_mass_balance_vs_source"] == true
    @test table[1, "became_residual_feasible"] == false
    @test table[2, "became_residual_feasible"] == true
    @test table[2, "became_green"] == true
end

@testset "Reduced MPCC window retry diagnostics validation" begin
    attempt = _reduced_mpcc_retry_source_attempt()
    report = _reduced_mpcc_retry_report(
        mass_balance = 5.0e-7,
        traffic_light = "green",
        viability_class = "simulation_viable_candidate",
        residual_feasible = true,
        trajectory_ready = true,
    )

    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_window_retry(
        attempt,
        ReducedDCDFBAMPCCSimulationViabilityReport[];
        window_index = 14,
        ipopt_max_iter_values = [200],
    )
    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_window_retry(
        attempt,
        [report];
        window_index = 14,
        ipopt_max_iter_values = Int[],
    )
    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_window_retry(
        attempt,
        [report];
        window_index = 14,
        ipopt_max_iter_values = [200, 500],
    )
    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_window_retry(
        attempt,
        [report];
        window_index = 20,
        ipopt_max_iter_values = [200],
    )
end
