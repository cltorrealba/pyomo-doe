import MathOptInterface as MOI

const FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE = 1.0e-6
const FULL_DFBA_RHS_RTOL = 1.0e-5
const FULL_DFBA_RHS_ATOL = 1.0e-7

@testset "Full sequential DFBA RHS smoke" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")

    model = load_full_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    reaction_report = validate_reaction_map(model, reaction_map)
    @test reaction_report.ok
    @test reaction_map.core["oxygen_exchange"] == "r_1992"
    @test reaction_map.core["oxygen_exchange"] != "r_0001"

    original_lb = copy(model.lb)
    original_ub = copy(model.ub)
    params = default_zenteno_parameters()
    y0 = zenteno_state_to_vector(default_zenteno_initial_state())

    result = compute_dfba_rhs(model, reaction_map, y0; params = params, atol = 1.0e-8)

    @test result isa DFBARHSResult
    @test length(result.dy) == 19
    @test result.mode == :growth
    @test result.fba.status == MOI.OPTIMAL
    @test result.fba.metadata["objective_type"] == "weighted"
    @test isapprox(result.fba.objective_value, 0.8748248651386076; rtol = FULL_DFBA_RHS_RTOL, atol = FULL_DFBA_RHS_ATOL)

    biomass_flux = result.fluxes_by_rxn["r_2111"]
    @test isapprox(biomass_flux, 0.07522486513860753; rtol = FULL_DFBA_RHS_RTOL, atol = FULL_DFBA_RHS_ATOL)
    @test isapprox(result.dy[1], biomass_flux * y0[1]; rtol = FULL_DFBA_RHS_RTOL, atol = FULL_DFBA_RHS_ATOL)
    @test !isapprox(result.dy[1], result.fba.objective_value * y0[1]; rtol = FULL_DFBA_RHS_RTOL, atol = FULL_DFBA_RHS_ATOL)

    expected_carbohydrate =
        max(0.0, biomass_flux) * y0[1] * params.CARB_CONTENT_0 -
        y0[8] * params.K_DEATH
    @test result.dy[6] == 0.0
    @test isapprox(result.dy[8], expected_carbohydrate; rtol = FULL_DFBA_RHS_RTOL, atol = FULL_DFBA_RHS_ATOL)

    @test has_reaction(model, "r_4048")
    @test haskey(result.fluxes_by_rxn, "r_4048")
    @test result.metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"

    oxygen_index = reaction_index(model, "r_1992")
    @test has_reaction(model, "r_1992")
    @test isapprox(model.lb[oxygen_index], 0.0; atol = 0.0, rtol = 0.0)
    @test isapprox(model.ub[oxygen_index], 0.0; atol = 0.0, rtol = 0.0)
    @test result.metadata["oxygen_derivative_policy"] == "forced_zero_present_r_1992_closed_by_bounds"
    @test result.metadata["oxygen_exchange_reaction_id"] == "r_1992"
    @test result.metadata["oxygen_exchange_present"] == true
    @test result.metadata["oxygen_exchange_closed"] == true
    @test isapprox(result.metadata["oxygen_exchange_lb"], 0.0; atol = 0.0, rtol = 0.0)
    @test isapprox(result.metadata["oxygen_exchange_ub"], 0.0; atol = 0.0, rtol = 0.0)
    @test result.metadata["indices_reacciones_used"] == false
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test !haskey(result.fluxes_by_rxn, "r_0001")

    @test result.fba.mass_balance_residual <= FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE
    @test result.fba.max_lower_bound_violation <= FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE
    @test result.fba.max_upper_bound_violation <= FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE
    @test model.lb == original_lb
    @test model.ub == original_ub
end
