const METRICS_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _synthetic_metrics_states()
    states = zeros(19, 3)
    states[1, :] .= [1.0, 1.5, 2.0]
    states[2, :] .= [0.1, 0.05, 0.0]
    states[3, :] .= [10.0, 5.0, 0.0]
    states[4, :] .= [8.0, 4.0, 0.0]
    states[5, :] .= [0.0, 2.0, 5.0]
    states[6, :] .= [0.0, 0.0, 0.0]
    states[7, :] .= [0.2, 0.25, 0.3]
    states[8, :] .= [0.1, 0.15, 0.2]
    return states
end

function _synthetic_metrics_metadata()
    return Dict{String, Any}(
        "state_names" => copy(METRICS_STATE_NAMES),
        "model_scope" => "reduced",
        "mode_history" => [:growth, :growth, :turnover],
        "mass_balance_residuals" => [1.0e-10, 2.0e-10, 3.0e-10],
        "max_lower_bound_violations" => [0.0, 1.0e-11, 2.0e-11],
        "max_upper_bound_violations" => [0.0, 3.0e-11, 4.0e-11],
        "retcode" => "Success",
        "termination_reason" => "completed_tspan",
        "termination_time" => 2.0,
        "algorithm" => "SyntheticAlgorithm",
        "min_state_value" => 0.0,
        "has_negative_saved_states" => false,
        "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "sugar_depletion_tol" => 1.0e-6,
    )
end

function _synthetic_metrics_result(; fluxes = zeros(2, 3), metadata = _synthetic_metrics_metadata())
    return SimulationResult(
        [0.0, 1.0, 2.0],
        _synthetic_metrics_states();
        fluxes = fluxes,
        metadata = metadata,
    )
end

function _load_reduced_metrics_inputs()
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    reaction_report = validate_reaction_map(model, reaction_map)
    @test reaction_report.ok

    return model, reaction_map
end

@testset "Simulation summary metrics synthetic result" begin
    result = _synthetic_metrics_result()

    @test total_sugar(result; time_index = 1) == 18.0
    @test total_sugar(result; time_index = 3) == 0.0
    @test time_to_sugar_depletion(result; tol = 1.0e-6) == 2.0
    @test mode_counts(result) == Dict(:growth => 2, :turnover => 1)

    diagnostics = diagnostic_summary(result)
    @test diagnostics["has_diagnostics"] == true
    @test diagnostics["max_mass_balance_residual"] == 3.0e-10
    @test diagnostics["max_lower_bound_violation"] == 2.0e-11
    @test diagnostics["max_upper_bound_violation"] == 4.0e-11

    summary = summarize_simulation(result)
    @test summary["initial_time"] == 0.0
    @test summary["final_time"] == 2.0
    @test summary["n_saved_points"] == 3
    @test summary["n_states"] == 19
    @test summary["n_fluxes"] == 2
    @test summary["n_alphas"] == 0
    @test summary["alpha_scope"] === nothing
    @test summary["model_scope"] == "reduced"
    @test summary["retcode"] == "Success"
    @test summary["termination_reason"] == "completed_tspan"
    @test summary["termination_time"] == 2.0
    @test summary["algorithm"] == "SyntheticAlgorithm"
    @test summary["final_biomass"] == 2.0
    @test summary["final_total_sugar"] == 0.0
    @test summary["sugar_consumed"] == 18.0
    @test summary["ethanol_produced"] == 5.0
    @test summary["max_ethanol"] == 5.0
    @test summary["mode_counts"] == Dict(:growth => 2, :turnover => 1)
    @test summary["max_mass_balance_residual"] == 3.0e-10
    @test summary["max_lower_bound_violation"] == 2.0e-11
    @test summary["max_upper_bound_violation"] == 4.0e-11
    @test summary["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test summary["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
end

@testset "Simulation summary metrics handle missing fluxes" begin
    result = _synthetic_metrics_result(; fluxes = nothing)
    summary = summarize_simulation(result)

    @test result.fluxes === nothing
    @test summary["n_fluxes"] == 0
    @test summary["n_alphas"] == 0
    @test summary["n_saved_points"] == length(result.time)
end

@testset "Simulation summary metrics handle missing metadata" begin
    result = _synthetic_metrics_result(; metadata = Dict{String, Any}())

    @test mode_counts(result) == Dict{Symbol, Int}()

    diagnostics = diagnostic_summary(result)
    @test diagnostics["has_diagnostics"] == false
    @test diagnostics["max_mass_balance_residual"] === nothing
    @test diagnostics["max_lower_bound_violation"] === nothing
    @test diagnostics["max_upper_bound_violation"] === nothing

    summary = summarize_simulation(result)
    @test summary["n_saved_points"] == 3
    @test summary["final_biomass"] == 2.0
    @test summary["final_total_sugar"] == 0.0
    @test summary["mode_counts"] == Dict{Symbol, Int}()
    @test summary["model_scope"] == "unknown"
    @test summary["retcode"] === nothing
    @test summary["oxygen_derivative_policy"] === nothing
    @test summary["carbohydrate_derivative_policy"] === nothing
end

@testset "Simulation summary metrics real short simulation" begin
    model, reaction_map = _load_reduced_metrics_inputs()
    result = simulate_reduced_dfba(model, reaction_map; tspan = (0.0, 1.0), saveat = 1.0)
    summary = summarize_simulation(result)

    @test summary isa Dict{String, Any}
    @test summary["n_saved_points"] == length(result.time)
    @test summary["final_biomass"] >= summary["initial_biomass"] - 1.0e-8
    @test summary["final_total_sugar"] <= summary["initial_total_sugar"] + 1.0e-8
    @test summary["final_ethanol"] >= summary["initial_ethanol"] - 1.0e-8
    @test summary["final_oxygen"] == 0.0
    @test summary["model_scope"] == "reduced"
    @test summary["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test summary["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
end

@testset "Simulation summary metrics validation errors" begin
    result = _synthetic_metrics_result()

    @test_throws ErrorException total_sugar(result; time_index = 0)
    @test_throws ErrorException total_sugar(result; time_index = 4)
    @test_throws ErrorException time_to_sugar_depletion(result; tol = -1.0)
end
