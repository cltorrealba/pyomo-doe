import MathOptInterface as MOI

@testset "Reduced FBA after Zenteno dynamic bounds" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    paths = load_reduced_model_paths(paths_config)
    model = load_reduced_model(paths)
    reaction_map = load_reaction_map(reaction_map_config)
    reaction_report = validate_reaction_map(model, reaction_map)
    @test reaction_report.ok

    state = default_zenteno_initial_state()
    params = default_zenteno_parameters()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    bounds = zenteno_dynamic_bounds(model, reaction_map, state, params)
    @test model.lb == original_lb
    @test model.ub == original_ub

    updated_model = apply_dynamic_bounds(model, bounds)
    @test model.lb == original_lb
    @test model.ub == original_ub
    @test all(updated_model.lb .<= updated_model.ub)

    result = solve_fba(updated_model; objective_rxn_id = "r_2111")
    diagnostic_tolerance = 1.0e-6
    flux_tolerance = 1.0e-8
    objective_value = 0.07522361546230504

    @test result.status == MOI.OPTIMAL
    @test length(result.fluxes) == length(model.rxn_ids)
    @test result.objective_rxn_id == "r_2111"
    @test isapprox(result.objective_value, objective_value; rtol = 1.0e-7, atol = 1.0e-9)
    @test result.mass_balance_residual <= diagnostic_tolerance
    @test result.max_lower_bound_violation <= diagnostic_tolerance
    @test result.max_upper_bound_violation <= diagnostic_tolerance

    residual = check_mass_balance(updated_model, result.fluxes; atol = diagnostic_tolerance)
    bound_report = check_bound_violations(updated_model, result.fluxes; atol = diagnostic_tolerance)
    @test residual <= diagnostic_tolerance
    @test bound_report.max_lower_violation <= diagnostic_tolerance
    @test bound_report.max_upper_violation <= diagnostic_tolerance
    @test bound_report.n_lower_violations == 0
    @test bound_report.n_upper_violations == 0

    flux(rxn_id) = result.fluxes[reaction_index(updated_model, rxn_id)]
    lower_bound(rxn_id) = updated_model.lb[reaction_index(updated_model, rxn_id)]
    upper_bound(rxn_id) = updated_model.ub[reaction_index(updated_model, rxn_id)]

    @test isapprox(flux("r_1714"), lower_bound("r_1714"); rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_1714"), -2.6200722894347632; rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_1709"), lower_bound("r_1709"); rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_1709"), -1.1004155402525355; rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_1761"), upper_bound("r_1761"); rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_1761"), 5.823741603610602; rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_4046"), 0.7; rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_2111"), result.objective_value; rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_4047"), result.objective_value; rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_4048"), result.objective_value; rtol = 1.0e-7, atol = flux_tolerance)

    @test !has_reaction(model, "r_1992")
    @test !haskey(bounds.lb_updates, "r_1992")
    @test !haskey(bounds.ub_updates, "r_1992")
    @test !haskey(bounds.lb_updates, "r_0001")
    @test !haskey(bounds.ub_updates, "r_0001")
    if has_reaction(model, "r_0001")
        r_0001_index = reaction_index(model, "r_0001")
        @test updated_model.lb[r_0001_index] == original_lb[r_0001_index]
        @test updated_model.ub[r_0001_index] == original_ub[r_0001_index]
    end

    @test has_reaction(model, "r_4048")
    @test !haskey(bounds.lb_updates, "r_4048")
    @test !haskey(bounds.ub_updates, "r_4048")
    r_4048_index = reaction_index(model, "r_4048")
    @test updated_model.lb[r_4048_index] == original_lb[r_4048_index]
    @test updated_model.ub[r_4048_index] == original_ub[r_4048_index]
end

@testset "Reduced weighted FBA after Zenteno growth dynamic bounds" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    reaction_report = validate_reaction_map(model, reaction_map)
    @test reaction_report.ok

    bounds = zenteno_dynamic_bounds(model, reaction_map, default_zenteno_initial_state())
    @test bounds.mode == :growth

    updated_model = apply_dynamic_bounds(model, bounds)
    result = solve_fba(updated_model; objective_weights = bounds.objective_weights)
    diagnostic_tolerance = 1.0e-6
    flux_tolerance = 1.0e-8
    biomass_flux_value = 0.07488355184042153

    @test result.status == MOI.OPTIMAL
    @test length(result.fluxes) == length(model.rxn_ids)
    @test result.objective_rxn_id === nothing
    @test result.objective_index === nothing
    @test result.objective_weights == bounds.objective_weights
    @test result.objective_description == "weighted"
    @test result.metadata["objective_type"] == "weighted"
    @test result.metadata["n_objective_terms"] == length(bounds.objective_weights)
    @test result.mass_balance_residual <= diagnostic_tolerance
    @test result.max_lower_bound_violation <= diagnostic_tolerance
    @test result.max_upper_bound_violation <= diagnostic_tolerance

    flux(rxn_id) = result.fluxes[reaction_index(updated_model, rxn_id)]
    lower_bound(rxn_id) = updated_model.lb[reaction_index(updated_model, rxn_id)]
    upper_bound(rxn_id) = updated_model.ub[reaction_index(updated_model, rxn_id)]
    weighted_objective = sum(weight * flux(rxn_id) for (rxn_id, weight) in bounds.objective_weights)

    @test isapprox(result.objective_value, weighted_objective; rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_1714"), lower_bound("r_1714"); rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_1709"), lower_bound("r_1709"); rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_1761"), upper_bound("r_1761"); rtol = 1.0e-7, atol = flux_tolerance)

    for rxn_id in ("r_1903", "r_1897", "r_1914", "r_1902", "r_1913")
        @test isapprox(flux(rxn_id), -0.15992; rtol = 1.0e-7, atol = flux_tolerance)
    end
    @test isapprox(flux("r_2111"), biomass_flux_value; rtol = 1.0e-7, atol = flux_tolerance)

    @test !has_reaction(model, "r_1992")
    @test !haskey(bounds.lb_updates, "r_1992")
    @test !haskey(bounds.ub_updates, "r_1992")
    @test !haskey(bounds.lb_updates, "r_0001")
    @test !haskey(bounds.ub_updates, "r_0001")
    @test has_reaction(model, "r_4048")
    @test !haskey(bounds.lb_updates, "r_4048")
    @test !haskey(bounds.ub_updates, "r_4048")
end

@testset "Reduced weighted FBA after Zenteno turnover dynamic bounds" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    reaction_report = validate_reaction_map(model, reaction_map)
    @test reaction_report.ok

    turnover_state = ZentenoState(
        0.5,
        0.0,
        110.0,
        110.0,
        0.0,
        0.0,
        0.23,
        0.185,
        zeros(5),
        zeros(6),
    )
    bounds = zenteno_dynamic_bounds(model, reaction_map, turnover_state)
    @test bounds.mode == :turnover
    @test bounds.objective_weights["r_4046"] == 1.0
    @test bounds.objective_weights["r_4047"] == 1.0

    updated_model = apply_dynamic_bounds(model, bounds)
    result = solve_fba(updated_model; objective_weights = bounds.objective_weights)
    diagnostic_tolerance = 1.0e-6
    flux_tolerance = 1.0e-8

    @test result.status == MOI.OPTIMAL
    @test length(result.fluxes) == length(model.rxn_ids)
    @test result.objective_rxn_id === nothing
    @test result.objective_index === nothing
    @test result.objective_weights == bounds.objective_weights
    @test result.objective_description == "weighted"
    @test result.metadata["objective_type"] == "weighted"
    @test result.mass_balance_residual <= diagnostic_tolerance
    @test result.max_lower_bound_violation <= diagnostic_tolerance
    @test result.max_upper_bound_violation <= diagnostic_tolerance

    flux(rxn_id) = result.fluxes[reaction_index(updated_model, rxn_id)]
    lower_bound(rxn_id) = updated_model.lb[reaction_index(updated_model, rxn_id)]
    upper_bound(rxn_id) = updated_model.ub[reaction_index(updated_model, rxn_id)]
    weighted_objective = sum(weight * flux(rxn_id) for (rxn_id, weight) in bounds.objective_weights)

    @test isapprox(result.objective_value, weighted_objective; rtol = 1.0e-7, atol = flux_tolerance)
    @test isapprox(flux("r_2111"), 0.0; atol = flux_tolerance)
    @test lower_bound("r_4046") - flux_tolerance <= flux("r_4046") <= upper_bound("r_4046") + flux_tolerance
    @test isfinite(flux("r_4047"))

    @test !has_reaction(model, "r_1992")
    @test !haskey(bounds.lb_updates, "r_1992")
    @test !haskey(bounds.ub_updates, "r_1992")
    @test !haskey(bounds.lb_updates, "r_0001")
    @test !haskey(bounds.ub_updates, "r_0001")
    @test has_reaction(model, "r_4048")
    @test !haskey(bounds.lb_updates, "r_4048")
    @test !haskey(bounds.ub_updates, "r_4048")
end
