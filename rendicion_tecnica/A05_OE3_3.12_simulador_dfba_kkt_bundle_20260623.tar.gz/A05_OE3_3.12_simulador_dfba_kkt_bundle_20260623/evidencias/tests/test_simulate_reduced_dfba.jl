import OrdinaryDiffEq

const SIM_DFBA_DIAGNOSTIC_TOLERANCE = 1.0e-5
const SIM_DFBA_RUNTIME_KEYS = (
    "simulation_elapsed_seconds",
    "ode_solve_elapsed_seconds",
    "rhs_elapsed_seconds",
    "history_reconstruction_elapsed_seconds",
    "rhs_call_count",
    "rhs_lp_solve_count",
    "flux_reconstruction_solve_count",
    "total_lp_solve_count",
    "reconstruct_fluxes",
    "fba_variant",
    "quadratic_penalty",
    "l1_penalty",
    "lp_reuse",
    "lp_primal_start",
    "lp_basis_warm_start",
    "lp_reuse_highs_solver",
    "lp_simplex_strategy",
    "lp_reuse_strategy",
    "lp_warm_start_strategy",
    "allow_experimental_lp_reuse",
    "experimental_lp_reuse",
    "trajectory_equivalence_checked",
    "trajectory_equivalence_passed",
    "scientific_output_equivalent",
    "lp_reuse_validity_note",
    "lp_reuse_build_elapsed_seconds",
    "lp_reuse_update_elapsed_seconds",
    "lp_reuse_solve_elapsed_seconds",
    "lp_reuse_warm_start_applied_count",
    "lp_reuse_basis_warm_start_applied_count",
    "lp_reuse_basis_warm_start_failed_count",
    "lp_reuse_basis_capture_count",
    "lp_reuse_simplex_iterations",
    "qpfba_persistent_fallback_count",
)

function _load_reduced_simulation_inputs()
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    reaction_report = validate_reaction_map(model, reaction_map)
    @test reaction_report.ok

    return model, reaction_map
end

function _synthetic_sugar_depletion_inputs()
    params = default_zenteno_parameters()
    reaction_map = ReactionMap(
        core = Dict(
            "biomass_growth" => "r_2111",
            "glucose_exchange" => "r_1714",
            "fructose_exchange" => "r_1709",
            "ethanol_exchange" => "r_1761",
            "oxygen_exchange" => "r_1992",
            "atp_maintenance" => "r_4046",
            "protein_exchange" => "r_4047",
            "carbohydrate_exchange" => "r_4048",
        ),
        nitrogen_sources = Dict("n_source_$(rxn_id)" => rxn_id for rxn_id in params.nitrogen_source_ids),
        amino_acids = Dict(
            "phenylalanine" => "r_1714",
            "leucine" => "r_1709",
            "valine" => "r_1914",
            "methionine" => "r_1902",
            "tyrosine" => "r_1913",
        ),
        aromas = Dict(
            "phenylethanol" => "r_1589",
            "isoamyl_alcohol" => "r_1862",
            "isobutanol" => "r_1866",
            "methionol" => "r_4668",
            "tyrosol" => "r_4677",
            "ethyl_acetate" => "r_1765",
        ),
        disabled_reactions = Dict("oxygen_exchange" => "r_1992"),
    )

    rxn_ids = String[]
    for group in (
        values(reaction_map.core),
        values(reaction_map.nitrogen_sources),
        values(reaction_map.amino_acids),
        values(reaction_map.aromas),
    )
        for rxn_id in group
            cleaned_id = strip(String(rxn_id))
            if cleaned_id != "r_1992" && !(cleaned_id in rxn_ids)
                push!(rxn_ids, cleaned_id)
            end
        end
    end
    sort!(rxn_ids)

    lb = fill(-1000.0, length(rxn_ids))
    ub = fill(1000.0, length(rxn_ids))
    ub[findfirst(==("r_2111"), rxn_ids)] = 0.0
    model = MetabolicModel(
        zeros(1, length(rxn_ids)),
        lb,
        ub,
        rxn_ids,
        ["m_zero"];
        model_id = "synthetic_sugar_depletion",
    )

    return model, reaction_map
end

function _assert_simulation_history_consistency(result::SimulationResult)
    metadata = result.metadata
    n_time = length(result.time)

    @test size(result.states, 2) == n_time
    @test result.fluxes !== nothing
    @test size(result.fluxes, 2) == n_time
    @test metadata["n_saved_points"] == n_time
    @test metadata["n_fluxes"] == size(result.fluxes, 1)
    @test length(metadata["flux_rxn_ids"]) == metadata["n_fluxes"]
    @test length(metadata["mode_history"]) == n_time
    @test length(metadata["rhs_status_history"]) == n_time
    @test length(metadata["mass_balance_residuals"]) == n_time
    @test length(metadata["max_lower_bound_violations"]) == n_time
    @test length(metadata["max_upper_bound_violations"]) == n_time
    @test length(metadata["negative_state_min_by_state"]) == size(result.states, 1)
    @test metadata["has_negative_saved_states"] == !isempty(metadata["negative_state_locations"])
end

function _assert_runtime_diagnostics_present(metadata)
    for key in SIM_DFBA_RUNTIME_KEYS
        @test haskey(metadata, key)
    end
    for key in (
        "simulation_elapsed_seconds",
        "ode_solve_elapsed_seconds",
        "rhs_elapsed_seconds",
        "history_reconstruction_elapsed_seconds",
        "lp_reuse_build_elapsed_seconds",
        "lp_reuse_update_elapsed_seconds",
        "lp_reuse_solve_elapsed_seconds",
    )
        @test isfinite(metadata[key])
        @test metadata[key] >= 0.0
    end
    for key in (
        "rhs_call_count",
        "rhs_lp_solve_count",
        "flux_reconstruction_solve_count",
        "total_lp_solve_count",
        "lp_reuse_warm_start_applied_count",
        "lp_reuse_basis_warm_start_applied_count",
        "lp_reuse_basis_warm_start_failed_count",
        "lp_reuse_basis_capture_count",
        "lp_reuse_simplex_iterations",
        "qpfba_persistent_fallback_count",
    )
        @test metadata[key] isa Integer
        @test metadata[key] >= 0
    end
    @test metadata["lp_reuse"] isa Bool
    @test metadata["fba_variant"] isa AbstractString
    @test metadata["quadratic_penalty"] isa Real
    @test metadata["l1_penalty"] isa Real
    @test metadata["lp_primal_start"] isa Bool
    @test metadata["lp_basis_warm_start"] isa Bool
    @test metadata["lp_reuse_highs_solver"] isa AbstractString
    @test metadata["lp_simplex_strategy"] isa AbstractString
    @test metadata["lp_reuse_strategy"] isa AbstractString
    @test metadata["lp_warm_start_strategy"] isa AbstractString
    @test metadata["allow_experimental_lp_reuse"] isa Bool
    @test metadata["experimental_lp_reuse"] isa Bool
    @test metadata["trajectory_equivalence_checked"] isa Bool
    @test metadata["trajectory_equivalence_passed"] isa Bool
    @test metadata["scientific_output_equivalent"] isa Bool
    @test metadata["lp_reuse_validity_note"] isa AbstractString
end

@testset "Zenteno state vector conversion" begin
    state = default_zenteno_initial_state()
    y = zenteno_state_to_vector(state)

    @test length(y) == 19
    parsed = zenteno_state_from_vector(y)
    @test parsed.biomass == state.biomass
    @test parsed.nitrogen == state.nitrogen
    @test parsed.glucose == state.glucose
    @test parsed.fructose == state.fructose
    @test parsed.amino_acids == state.amino_acids
    @test parsed.aromas == state.aromas

    invalid_amino_acids = ZentenoState(
        0.5,
        0.07,
        110.0,
        110.0,
        0.0,
        0.0,
        0.23,
        0.185,
        Float64[],
        zeros(6),
    )
    invalid_aromas = ZentenoState(
        0.5,
        0.07,
        110.0,
        110.0,
        0.0,
        0.0,
        0.23,
        0.185,
        fill(0.9995, 5),
        Float64[],
    )

    @test_throws ErrorException zenteno_state_to_vector(invalid_amino_acids)
    @test_throws ErrorException zenteno_state_to_vector(invalid_aromas)
end

@testset "SimulationResult constructor validation" begin
    valid = SimulationResult([0.0, 1.0], zeros(19, 2); fluxes = zeros(3, 2), alphas = zeros(4, 2))

    @test valid.time == [0.0, 1.0]
    @test size(valid.states) == (19, 2)
    @test size(valid.fluxes) == (3, 2)
    @test size(valid.alphas) == (4, 2)
    @test_throws ErrorException SimulationResult([0.0, 1.0], zeros(19, 1))
    @test_throws ErrorException SimulationResult([0.0], zeros(19, 1); fluxes = zeros(3, 2))
    @test_throws ErrorException SimulationResult([0.0], zeros(19, 1); alphas = zeros(4, 2))
end

@testset "Sequential reduced DFBA ODE simulation smoke test" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    y0 = zenteno_state_to_vector(default_zenteno_initial_state())

    result = simulate_reduced_dfba(model, reaction_map; y0 = y0, tspan = (0.0, 2.0), saveat = 1.0)

    @test result isa SimulationResult
    _assert_simulation_history_consistency(result)
    @test length(result.time) >= 2
    @test size(result.states, 1) == 19
    @test size(result.states, 2) == length(result.time)
    @test result.fluxes !== nothing
    @test size(result.fluxes, 2) == length(result.time)
    @test haskey(result.metadata, "flux_rxn_ids")
    @test !("r_1992" in result.metadata["flux_rxn_ids"])
    @test !("r_0001" in result.metadata["flux_rxn_ids"])
    @test all(isapprox(value, 0.0; atol = 1.0e-9) for value in result.states[6, :])
    @test all(isfinite, result.states)
    @test all(isapprox(result.states[i, 1], y0[i]; rtol = 1.0e-9, atol = 1.0e-9) for i in eachindex(y0))
end

@testset "Sequential reduced DFBA ODE metadata and diagnostics" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    result = simulate_reduced_dfba(model, reaction_map; tspan = (0.0, 2.0), saveat = 1.0)
    metadata = result.metadata
    n_time = length(result.time)

    for key in (
        "state_names",
        "model_scope",
        "flux_rxn_ids",
        "retcode",
        "algorithm",
        "tspan",
        "saveat",
        "stop_on_sugar_depletion",
        "sugar_depletion_tol",
        "nonnegative",
        "mode_history",
        "rhs_status_history",
        "mass_balance_residuals",
        "max_lower_bound_violations",
        "max_upper_bound_violations",
        "termination_reason",
        "termination_time",
        "dynamic_control_schedule_enabled",
        "dynamic_control_policy",
        "dynamic_control_temperature_profile",
        "dynamic_control_fda_total_product_g_L",
        "dynamic_control_organic_total_product_g_L",
        "dynamic_control_penalty",
        "dynamic_control_volatilization_enabled",
        "min_state_value",
        "has_negative_saved_states",
        "negative_state_policy",
        "negative_state_min_by_state",
        "negative_state_locations",
        "n_saved_points",
        "n_fluxes",
        SIM_DFBA_RUNTIME_KEYS...,
    )
        @test haskey(metadata, key)
    end

    _assert_simulation_history_consistency(result)
    _assert_runtime_diagnostics_present(metadata)
    @test metadata["retcode"] == "Success"
    @test metadata["model_scope"] == "reduced"
    @test metadata["termination_reason"] == "completed_tspan"
    @test metadata["termination_time"] == result.time[end]
    @test metadata["dynamic_control_schedule_enabled"] == false
    @test metadata["dynamic_control_policy"] == "disabled_static_temperature_no_additions"
    @test metadata["dynamic_control_fda_total_product_g_L"] == 0.0
    @test metadata["dynamic_control_organic_total_product_g_L"] == 0.0
    @test metadata["dynamic_control_penalty"] == 0.0
    @test metadata["dynamic_control_volatilization_enabled"] == false
    @test metadata["n_saved_points"] == n_time
    @test metadata["n_fluxes"] == size(result.fluxes, 1)
    @test length(metadata["mode_history"]) == n_time
    @test length(metadata["rhs_status_history"]) == n_time
    @test length(metadata["mass_balance_residuals"]) == n_time
    @test length(metadata["max_lower_bound_violations"]) == n_time
    @test length(metadata["max_upper_bound_violations"]) == n_time
    @test maximum(metadata["mass_balance_residuals"]) <= SIM_DFBA_DIAGNOSTIC_TOLERANCE
    @test maximum(metadata["max_lower_bound_violations"]) <= SIM_DFBA_DIAGNOSTIC_TOLERANCE
    @test maximum(metadata["max_upper_bound_violations"]) <= SIM_DFBA_DIAGNOSTIC_TOLERANCE
    @test metadata["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test metadata["oxygen_exchange_reaction_id"] == "r_1992"
    @test metadata["oxygen_exchange_present"] == false
    @test ismissing(metadata["oxygen_exchange_closed"])
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test !("r_1992" in metadata["flux_rxn_ids"])
    @test !("r_0001" in metadata["flux_rxn_ids"])
    @test "r_4048" in metadata["flux_rxn_ids"]
end

@testset "Sequential reduced DFBA ODE runtime diagnostics with reconstruction" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    result = simulate_reduced_dfba(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        saveat = 1.0,
        reconstruct_fluxes = true,
    )
    metadata = result.metadata

    @test result.fluxes !== nothing
    _assert_runtime_diagnostics_present(metadata)
    @test metadata["reconstruct_fluxes"] == true
    @test metadata["rhs_call_count"] > 0
    @test metadata["rhs_lp_solve_count"] == metadata["rhs_call_count"]
    @test metadata["flux_reconstruction_solve_count"] == length(result.time)
    @test metadata["total_lp_solve_count"] ==
        metadata["rhs_lp_solve_count"] + metadata["flux_reconstruction_solve_count"]

    summary = summarize_simulation(result)
    for key in SIM_DFBA_RUNTIME_KEYS
        @test summary[key] == metadata[key]
    end
end

@testset "Sequential reduced DFBA ODE runtime diagnostics without reconstruction" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    result = simulate_reduced_dfba(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        saveat = 1.0,
        reconstruct_fluxes = false,
    )
    metadata = result.metadata

    @test result.fluxes === nothing
    _assert_runtime_diagnostics_present(metadata)
    @test metadata["model_scope"] == "reduced"
    @test metadata["reconstruct_fluxes"] == false
    @test metadata["flux_rxn_ids"] == String[]
    @test isempty(metadata["mode_history"])
    @test isempty(metadata["rhs_status_history"])
    @test isempty(metadata["mass_balance_residuals"])
    @test metadata["rhs_call_count"] > 0
    @test metadata["rhs_lp_solve_count"] == metadata["rhs_call_count"]
    @test metadata["flux_reconstruction_solve_count"] == 0
    @test metadata["total_lp_solve_count"] == metadata["rhs_lp_solve_count"]

    summary = summarize_simulation(result)
    @test summary["model_scope"] == "reduced"
    @test summary["n_fluxes"] == 0
    @test summary["reconstruct_fluxes"] == false
    @test summary["total_lp_solve_count"] == metadata["total_lp_solve_count"]
end

@testset "Sequential reduced DFBA ODE persistent LP reuse guard" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    common_kwargs = (
        tspan = (0.0, 0.25),
        saveat = 0.25,
        algorithm = OrdinaryDiffEq.Tsit5(),
        reconstruct_fluxes = false,
    )

    reference = simulate_reduced_dfba(model, reaction_map; common_kwargs...)
    err = try
        simulate_reduced_dfba(
            model,
            reaction_map;
            common_kwargs...,
            lp_reuse = true,
            lp_primal_start = false,
        )
        nothing
    catch err
        err
    end
    @test err isa ErrorException
    @test occursin("experimental", sprint(showerror, err))

    reused = simulate_reduced_dfba(
        model,
        reaction_map;
        common_kwargs...,
        lp_reuse = true,
        lp_primal_start = false,
        allow_experimental_lp_reuse = true,
    )

    @test reused.time == reference.time
    @test size(reused.states) == size(reference.states)
    _assert_runtime_diagnostics_present(reused.metadata)
    @test reused.metadata["lp_reuse"] == true
    @test reused.metadata["lp_primal_start"] == false
    @test reused.metadata["lp_basis_warm_start"] == false
    @test reused.metadata["allow_experimental_lp_reuse"] == true
    @test reused.metadata["experimental_lp_reuse"] == true
    @test reused.metadata["trajectory_equivalence_checked"] == false
    @test reused.metadata["trajectory_equivalence_passed"] == false
    @test reused.metadata["scientific_output_equivalent"] == false
    @test reused.metadata["lp_reuse_strategy"] == "persistent_model"
    @test reused.metadata["lp_warm_start_strategy"] == "none"
    @test reused.metadata["lp_reuse_warm_start_applied_count"] == 0
    @test reused.metadata["lp_reuse_basis_warm_start_applied_count"] == 0
    @test reused.metadata["lp_reuse_basis_capture_count"] == 0
    @test reused.metadata["lp_reuse_build_elapsed_seconds"] >= 0.0
    @test reused.metadata["lp_reuse_update_elapsed_seconds"] >= 0.0
    @test reused.metadata["lp_reuse_solve_elapsed_seconds"] >= 0.0

    summary = summarize_simulation(reused)
    for key in SIM_DFBA_RUNTIME_KEYS
        @test summary[key] == reused.metadata[key]
    end
end

@testset "Sequential reduced DFBA ODE persistent LP primal starts" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    result = simulate_reduced_dfba(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        saveat = 0.25,
        algorithm = OrdinaryDiffEq.Tsit5(),
        reconstruct_fluxes = false,
        lp_reuse = true,
        lp_primal_start = true,
        allow_experimental_lp_reuse = true,
    )

    @test result isa SimulationResult
    @test all(isfinite, result.states)
    @test result.metadata["lp_reuse"] == true
    @test result.metadata["lp_primal_start"] == true
    @test result.metadata["lp_basis_warm_start"] == false
    @test result.metadata["allow_experimental_lp_reuse"] == true
    @test result.metadata["experimental_lp_reuse"] == true
    @test result.metadata["scientific_output_equivalent"] == false
    @test result.metadata["lp_reuse_strategy"] == "persistent_model"
    @test result.metadata["lp_warm_start_strategy"] == "primal_start"
    @test result.metadata["lp_reuse_warm_start_applied_count"] >= 1
    @test result.metadata["lp_reuse_update_elapsed_seconds"] >= 0.0
    @test result.metadata["lp_reuse_solve_elapsed_seconds"] >= 0.0
end

@testset "Sequential reduced DFBA ODE persistent LP basis warm starts" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    result = simulate_reduced_dfba(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        saveat = 0.25,
        algorithm = OrdinaryDiffEq.Tsit5(),
        reconstruct_fluxes = false,
        lp_reuse = true,
        lp_basis_warm_start = true,
        allow_experimental_lp_reuse = true,
    )

    @test result isa SimulationResult
    @test all(isfinite, result.states)
    @test result.metadata["lp_reuse"] == true
    @test result.metadata["lp_primal_start"] == false
    @test result.metadata["lp_basis_warm_start"] == true
    @test result.metadata["allow_experimental_lp_reuse"] == true
    @test result.metadata["experimental_lp_reuse"] == true
    @test result.metadata["scientific_output_equivalent"] == false
    @test result.metadata["lp_simplex_strategy"] == "primal"
    @test result.metadata["lp_warm_start_strategy"] == "basis_warm_start"
    @test result.metadata["lp_reuse_basis_warm_start_applied_count"] >= 1
    @test result.metadata["lp_reuse_basis_warm_start_failed_count"] == 0
    @test result.metadata["lp_reuse_basis_capture_count"] >=
        result.metadata["lp_reuse_basis_warm_start_applied_count"]
end

@testset "Sequential reduced DFBA ODE alias and deterministic repeated runs" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    reference = simulate_reduced_dfba(model, reaction_map; tspan = (0.0, 1.0), saveat = 1.0)
    alias_result = simulate_ode(model, reaction_map; tspan = (0.0, 1.0), saveat = 1.0)
    repeated = simulate_reduced_dfba(model, reaction_map; tspan = (0.0, 1.0), saveat = 1.0)

    @test reference isa SimulationResult
    @test alias_result isa SimulationResult
    @test repeated isa SimulationResult
    @test alias_result.time == reference.time
    @test size(alias_result.states) == size(reference.states)
    @test alias_result.metadata["termination_reason"] == reference.metadata["termination_reason"]
    @test alias_result.metadata["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test alias_result.metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"

    @test repeated.time == reference.time
    @test all(isapprox(repeated.states[i], reference.states[i]; rtol = 1.0e-7, atol = 1.0e-8) for i in eachindex(reference.states))
    @test all(isapprox(repeated.fluxes[i], reference.fluxes[i]; rtol = 1.0e-7, atol = 1.0e-8) for i in eachindex(reference.fluxes))
    @test repeated.metadata["termination_reason"] == reference.metadata["termination_reason"]
    @test model.lb == original_lb
    @test model.ub == original_ub
end

@testset "Sequential reduced DFBA ODE does not mutate model bounds" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    simulate_reduced_dfba(model, reaction_map; tspan = (0.0, 1.0), saveat = 1.0)

    @test model.lb == original_lb
    @test model.ub == original_ub
end

@testset "Sequential reduced DFBA ODE input validation" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    y0 = zenteno_state_to_vector(default_zenteno_initial_state())
    y_nonfinite = copy(y0)
    y_nonfinite[1] = NaN

    @test_throws ErrorException simulate_reduced_dfba(model, reaction_map; y0 = y0[1:18], tspan = (0.0, 1.0))
    @test_throws ErrorException simulate_reduced_dfba(model, reaction_map; y0 = y_nonfinite, tspan = (0.0, 1.0))
    @test_throws ErrorException simulate_reduced_dfba(model, reaction_map; y0 = y0, tspan = (1.0, 1.0))
    @test_throws ErrorException simulate_reduced_dfba(model, reaction_map; y0 = y0, tspan = (0.0, 1.0), lp_atol = 0.0)
    @test_throws ErrorException simulate_reduced_dfba(model, reaction_map; y0 = y0, tspan = (0.0, 1.0), ode_abstol = 0.0)
    @test_throws ErrorException simulate_reduced_dfba(model, reaction_map; y0 = y0, tspan = (0.0, 1.0), ode_reltol = 0.0)
    @test_throws ErrorException simulate_reduced_dfba(model, reaction_map; y0 = y0, tspan = (0.0, 1.0), lp_primal_start = true)
    @test_throws ErrorException simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = (0.0, 1.0),
        lp_basis_warm_start = true,
    )
    @test_throws ErrorException simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = (0.0, 1.0),
        sugar_depletion_tol = -1.0,
    )
end

@testset "Sequential reduced DFBA ODE negative initial state policy" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    y0 = zenteno_state_to_vector(default_zenteno_initial_state())
    y0[6] = -1.0

    err = try
        simulate_reduced_dfba(
            model,
            reaction_map;
            y0 = y0,
            tspan = (0.0, 1.0),
            saveat = 1.0,
            nonnegative = true,
        )
        nothing
    catch err
        err
    end

    @test err isa ErrorException
    @test occursin("nonnegative=true", sprint(showerror, err))

    relaxed_result = try
        simulate_reduced_dfba(
            model,
            reaction_map;
            y0 = y0,
            tspan = (0.0, 0.1),
            saveat = 0.1,
            nonnegative = false,
        )
    catch err
        err
    end
    if relaxed_result isa SimulationResult
        @test relaxed_result.metadata["nonnegative"] == false
        @test relaxed_result.metadata["has_negative_saved_states"] == true
        @test (6, 1) in relaxed_result.metadata["negative_state_locations"]
    else
        @test relaxed_result isa Exception
        @test !occursin("nonnegative=true", sprint(showerror, relaxed_result))
    end
end

@testset "Sequential reduced DFBA ODE initial sugar depletion" begin
    model, reaction_map = _load_reduced_simulation_inputs()
    y0 = zenteno_state_to_vector(default_zenteno_initial_state())
    y0[3] = 5.0e-7
    y0[4] = 5.0e-7

    result = simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = (0.0, 2.0),
        saveat = 1.0,
        stop_on_sugar_depletion = true,
    )

    _assert_simulation_history_consistency(result)
    @test length(result.time) == 1
    @test result.time[1] == 0.0
    @test result.metadata["retcode"] == "NotRun"
    @test result.metadata["termination_reason"] == "sugar_depletion_at_initial_time"
    @test result.metadata["termination_time"] == 0.0
    _assert_runtime_diagnostics_present(result.metadata)
    @test result.metadata["rhs_call_count"] == 0
    @test result.metadata["rhs_lp_solve_count"] == 0
    @test result.metadata["flux_reconstruction_solve_count"] == 0
    @test result.metadata["total_lp_solve_count"] == 0
    @test result.metadata["reconstruct_fluxes"] == true
    @test result.metadata["mode_history"] == [:sugar_depleted]
    @test result.metadata["rhs_status_history"] == ["NOT_EVALUATED_SUGAR_DEPLETION"]
    @test all(isnan, result.fluxes)
    @test isnan(result.metadata["mass_balance_residuals"][1])
    @test result.metadata["sugar_depleted_flux_policy"] ==
        "Fluxes and diagnostics are NaN when RHS is not evaluated at sugar-depleted saved states."
    @test result.states[3, end] + result.states[4, end] <= result.metadata["sugar_depletion_tol"]
end

@testset "Sequential reduced DFBA ODE saved-time sugar depletion policy" begin
    model, reaction_map = _synthetic_sugar_depletion_inputs()
    y0 = zenteno_state_to_vector(default_zenteno_initial_state())
    y0[3] = 0.01
    y0[4] = 0.01

    truncated = simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = (0.0, 1.0),
        saveat = 1.0,
        stop_on_sugar_depletion = true,
    )
    untruncated = simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = y0,
        tspan = (0.0, 1.0),
        saveat = 1.0,
        stop_on_sugar_depletion = false,
    )

    @test y0[3] + y0[4] > truncated.metadata["sugar_depletion_tol"]
    _assert_simulation_history_consistency(truncated)
    @test truncated.metadata["termination_reason"] == "sugar_depletion_at_saved_time"
    @test truncated.metadata["termination_time"] == truncated.time[end]
    @test truncated.metadata["mode_history"][end] == :sugar_depleted
    @test truncated.metadata["rhs_status_history"][end] == "NOT_EVALUATED_SUGAR_DEPLETION"
    @test all(isnan, truncated.fluxes[:, end])
    @test isnan(truncated.metadata["mass_balance_residuals"][end])
    @test truncated.states[3, end] + truncated.states[4, end] <= truncated.metadata["sugar_depletion_tol"]

    _assert_simulation_history_consistency(untruncated)
    @test untruncated.metadata["stop_on_sugar_depletion"] == false
    @test untruncated.metadata["termination_reason"] == "completed_tspan"
    @test untruncated.time[end] == 1.0
    @test all(status == "OPTIMAL" for status in untruncated.metadata["rhs_status_history"])
    @test all(isfinite, untruncated.fluxes)
end
