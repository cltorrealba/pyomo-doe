using FermentationDFBA
using Test

const SCRIPT_ENTRYPOINT_PROJECT_ROOT = normpath(joinpath(@__DIR__, ".."))
const SCRIPT_ENTRYPOINT_HELPER_PATH = joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "ode_script_helpers.jl")
const SCRIPT_ENTRYPOINT_SIMULATE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_simulate_reduced_dfba.jl")
const SCRIPT_ENTRYPOINT_FULL_SIMULATE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_simulate_full_dfba.jl")
const SCRIPT_ENTRYPOINT_DFVB_SIMULATE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_simulate_dfvb.jl")
const SCRIPT_ENTRYPOINT_DFVB_BASELINE_REPORT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_dfvb_baseline_report.jl")
const SCRIPT_ENTRYPOINT_DFVB_MATLAB_COMPARE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_compare_dfvb_matlab_baseline.jl")
const SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_PREVIEW_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_dynamic_control_schedule_preview.jl")
const SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_EXPORT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_export_reduced_dfba_dynamic_controls.jl")
const SCRIPT_ENTRYPOINT_DYNAMIC_TEMPERATURE_OBJECTIVE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_dynamic_temperature_objective_smoke.jl")
const SCRIPT_ENTRYPOINT_DYNAMIC_TEMPERATURE_SEARCH_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_dynamic_temperature_pattern_search.jl")
const SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_OBJECTIVE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_dynamic_control_objective_smoke.jl")
const SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_POLICY_SELECTION_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_dynamic_control_policy_selection.jl")
const SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_LOCAL_PILOT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_dynamic_control_local_pilot_design.jl")
const SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_LIBERATED_SPEC_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_dynamic_control_liberated_spec.jl")
const SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_SEQUENTIAL_SENSITIVITY_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "scripts",
    "main_dynamic_control_sequential_sensitivity.jl",
)
const SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_SEQUENTIAL_ATLAS_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "scripts",
    "main_dynamic_control_sequential_atlas.jl",
)
const SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_SEQUENTIAL_EXTENDED_ATLAS_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "scripts",
    "main_dynamic_control_sequential_extended_atlas.jl",
)
const SCRIPT_ENTRYPOINT_MPCC_FIXED_CONTROL_PREFLIGHT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_fixed_control_policy_preflight.jl")
const SCRIPT_ENTRYPOINT_MPCC_FIXED_CONTROL_SMOKE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_fixed_control_policy_smoke.jl")
const SCRIPT_ENTRYPOINT_MPCC_FIXED_CONTROL_SOLVE_ATTEMPT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_fixed_control_policy_solve_attempt.jl")
const SCRIPT_ENTRYPOINT_MPCC_REPAIR_SUBSTEP_ANALYSIS_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "scripts",
    "main_analyze_mpcc_repair_substeps.py",
)
const SCRIPT_ENTRYPOINT_REDUCED_DCDFBA_COLLOCATION_NLP_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "src",
    "Simultaneous",
    "reduced_dcdfba_collocation_nlp.jl",
)
const SCRIPT_ENTRYPOINT_CLUSTER_FIXED_CONTROL_SOLVE_ATTEMPT_SWEEP_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "cluster_uc_fixed_control_solve_attempt_sweep.sbatch",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_LOCAL_PILOT_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "cluster_uc_dynamic_control_local_pilot_fixed_mpcc.sbatch",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_LIBERATED_PILOT_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "cluster_uc_dynamic_control_liberated_mpcc_pilot.sbatch",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_OBJECTIVE_LEVERAGE_SUBMIT_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "submit_cluster_uc_dynamic_control_objective_leverage.sh",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_EXTENDED_NEARDRY_SUBMIT_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "submit_cluster_uc_dynamic_control_extended_neardry_mpcc.sh",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_H264_SUBSTEP_TRACE_SUBMIT_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "submit_cluster_uc_dynamic_control_h264_substep_trace.sh",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_SEQUENTIAL_ATLAS_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "cluster_uc_dynamic_control_sequential_atlas.sbatch",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_SEQUENTIAL_ATLAS_SUBMIT_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "submit_cluster_uc_dynamic_control_sequential_atlas.sh",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_DIRECT_DIAGNOSTIC_SUBMIT_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "submit_cluster_uc_dynamic_control_direct_diagnostic.sh",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_FIXED_BANK_SUBMIT_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "submit_cluster_uc_dynamic_control_fixed_bank.sh",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_RELAXED_FUNNEL_SUBMIT_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "submit_cluster_uc_dynamic_control_relaxed_funnel.sh",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_NEXT_H168_DIRECT_TEMPERATURE_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "next_dynamic_control_h168_direct_temperature_submit.sh",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_NEXT_H168_DIRECT_FDA_PATH = joinpath(
    SCRIPT_ENTRYPOINT_PROJECT_ROOT,
    "repro",
    "next_dynamic_control_h168_direct_fda_submit.sh",
)
const SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_OBJECTIVE_LEVERAGE_VARIANTS_PATH =
    joinpath(
        SCRIPT_ENTRYPOINT_PROJECT_ROOT,
        "repro",
        "cluster_uc_dynamic_control_objective_leverage_variants.tsv",
    )
const SCRIPT_ENTRYPOINT_SEQ_COMPARE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_compare_sequential_dfba_full_reduced.jl")
const SCRIPT_ENTRYPOINT_SEQ_MODEL_COMPARE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_compare_sequential_model_comparison.jl")
const SCRIPT_ENTRYPOINT_EXPORT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_export_reduced_dfba.jl")
const SCRIPT_ENTRYPOINT_MPCC_SWEEP_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_sweep_reduced_mpcc_solve_attempts.jl")
const SCRIPT_ENTRYPOINT_MPCC_ITER_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_sweep_reduced_mpcc_ipopt_iterations.jl")
const SCRIPT_ENTRYPOINT_MPCC_MESH_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_sweep_reduced_mpcc_mesh_refinement.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOW_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_continuation.jl")
const SCRIPT_ENTRYPOINT_MPCC_VIABILITY_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_simulation_viability.jl")
const SCRIPT_ENTRYPOINT_MPCC_FRONTIER_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_viability_frontier.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_ATTEMPT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_72h_attempt.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_72H_RUNNER_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_72h_simulation.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_TOLERANCE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_tolerance_sensitivity.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_DRIFT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_drift_diagnostics.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_REFINEMENT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_refinement_diagnostics.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_SELECTIVE_REFINEMENT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_selective_refinement.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_SELECTIVE_REPLACEMENT_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_apply_selective_replacements.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_RETRY_POLICY_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_retry_policy_diagnostics.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_RETRY_AWARE_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_retry_aware_attempt.jl")
const SCRIPT_ENTRYPOINT_MPCC_CASCADE_RETRY_HORIZON_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_cascade_retry_horizon_smoke.jl")
const SCRIPT_ENTRYPOINT_MPCC_GLOBAL_POLISH_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_global_polish_smoke.jl")
const SCRIPT_ENTRYPOINT_MPCC_GLOBAL_POLISH_HORIZON_SWEEP_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_global_polish_horizon_sweep.jl")
const SCRIPT_ENTRYPOINT_MPCC_GLOBAL_POLISH_RETRY_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_global_polish_retry.jl")
const SCRIPT_ENTRYPOINT_MPCC_WINDOWED_POLICY_HORIZON_SWEEP_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_windowed_policy_horizon_sweep.jl")
const SCRIPT_ENTRYPOINT_MPCC_SOLVER_TERMINATION_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_solver_termination_diagnostics.jl")
const SCRIPT_ENTRYPOINT_MPCC_ITERATION_LIMIT_REVIEW_PATH =
    joinpath(SCRIPT_ENTRYPOINT_PROJECT_ROOT, "scripts", "main_reduced_mpcc_iteration_limit_candidate_review.jl")

include(SCRIPT_ENTRYPOINT_HELPER_PATH)

function _script_entrypoint_text(path::AbstractString)
    @test isfile(path)
    return read(path, String)
end

@testset "Reduced DFBA script ODE configuration helper" begin
    helper_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_HELPER_PATH)

    for required_text in (
        "DEFAULT_SCRIPT_ALGORITHM = \"Tsit5\"",
        "DEFAULT_SCRIPT_ODE_ABSTOL = 1.0e-8",
        "DEFAULT_SCRIPT_ODE_RELTOL = 1.0e-8",
        "DEFAULT_SCRIPT_LP_ATOL = 1.0e-8",
        "DFBA_ALGORITHM",
        "DFBA_ODE_ABSTOL",
        "DFBA_ODE_RELTOL",
        "DFBA_LP_ATOL",
        "DFBA_INITIAL_YAN_MGN_L",
        "DFBA_INITIAL_YAN_POLICY",
        "DFBA_INITIAL_GLUCOSE_G_L",
        "DFBA_INITIAL_FRUCTOSE_G_L",
        "_script_dynamic_control_schedule_config",
        "DFBA_DYNAMIC_CONTROL_HORIZON_HOURS",
        "DFBA_DYNAMIC_CONTROL_INTERVAL_HOURS",
        "DFBA_DYNAMIC_CONTROL_SAMPLE_DT_HOURS",
        "DFBA_DYNAMIC_TEMPERATURE_WIDTH_HOURS",
        "DFBA_DYNAMIC_ADDITION_WIDTH_HOURS",
        "DFBA_DYNAMIC_T_MIN_C",
        "DFBA_DYNAMIC_T_MAX_C",
        "DFBA_DYNAMIC_FDA_TOTAL_LIMIT_G_L",
        "DFBA_DYNAMIC_TEMPERATURE_VALUES_C",
        "DFBA_DYNAMIC_FDA_DOSES_G_L",
        "DFBA_DYNAMIC_ORG_DOSES_G_L",
        "OrdinaryDiffEq.Tsit5()",
        "Rodas5P(autodiff = OrdinaryDiffEq.AutoFiniteDiff())",
    )
        @test occursin(required_text, helper_text)
    end

    withenv("DFBA_ALGORITHM" => nothing) do
        config = _script_ode_algorithm_config("DFBA_ALGORITHM")
        @test config.algorithm_label == "Tsit5"
        @test String(nameof(typeof(config.algorithm))) == "Tsit5"
    end

    withenv("DFBA_ALGORITHM" => "Rodas5P") do
        config = _script_ode_algorithm_config("DFBA_ALGORITHM")
        @test config.algorithm_label == "Rodas5P"
        @test String(nameof(typeof(config.algorithm))) == "Rodas5P"
    end

    withenv("DFBA_ALGORITHM" => "invalid") do
        @test_throws ErrorException _script_ode_algorithm_config("DFBA_ALGORITHM")
    end

    withenv(
        "DFBA_ODE_ABSTOL" => "1.0e-7",
        "DFBA_ODE_RELTOL" => "1.0e-6",
        "DFBA_LP_ATOL" => "1.0e-5",
    ) do
        tolerance_config = _script_tolerance_config()
        @test isapprox(tolerance_config.ode_abstol, 1.0e-7; atol = 0.0, rtol = 1.0e-12)
        @test isapprox(tolerance_config.ode_reltol, 1.0e-6; atol = 0.0, rtol = 1.0e-12)
        @test isapprox(tolerance_config.lp_atol, 1.0e-5; atol = 0.0, rtol = 1.0e-12)
    end

    withenv("DFBA_ODE_ABSTOL" => "0.0") do
        @test_throws ErrorException _script_tolerance_config()
    end

    params = default_zenteno_parameters()
    withenv("DFBA_INITIAL_YAN_MGN_L" => nothing, "DFBA_INITIAL_YAN_POLICY" => nothing) do
        initial_config = _script_initial_state_config(params)
        @test initial_config.y0[2] == 0.07
        @test initial_config.metadata["initial_yan_policy"] == "default"
    end

    withenv("DFBA_INITIAL_YAN_MGN_L" => "200", "DFBA_INITIAL_YAN_POLICY" => "ammonium_balance") do
        initial_config = _script_initial_state_config(params)
        default_y0 = zenteno_state_to_vector(default_zenteno_initial_state())
        amino_acid_n_gn_l = sum(default_y0[9:13]) * params.MW_N
        @test isapprox(initial_config.y0[2], 0.2 - amino_acid_n_gn_l; atol = 0.0, rtol = 1.0e-12)
        @test isapprox(
            initial_config.metadata["initial_total_yan_equivalent_mgN_L"],
            200.0;
            atol = 1.0e-12,
            rtol = 0.0,
        )
        @test initial_config.metadata["initial_condition_policy"] ==
              "yan_ammonium_balance_from_default_amino_acids"
    end

    withenv(
        "DFBA_INITIAL_YAN_MGN_L" => "200",
        "DFBA_INITIAL_YAN_POLICY" => "ammonium_balance",
        "DFBA_INITIAL_GLUCOSE_G_L" => "75",
        "DFBA_INITIAL_FRUCTOSE_G_L" => "75",
    ) do
        initial_config = _script_initial_state_config(params)
        @test initial_config.y0[3] == 75.0
        @test initial_config.y0[4] == 75.0
        @test initial_config.metadata["initial_sugar_policy"] == "env_override"
        @test initial_config.metadata["initial_total_sugar_g_L"] == 150.0
        @test initial_config.metadata["initial_condition_policy"] ==
              "yan_ammonium_balance_and_custom_initial_sugars"
    end
end

@testset "Dynamic control preview script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_PREVIEW_PATH)

    for required_text in (
        "_script_dynamic_control_schedule_config",
        "DFBA_DYNAMIC_CONTROL_OUTPUT_DIR",
        "sample_dynamic_control_schedule",
        "dynamic_control_schedule.csv",
        "dynamic_control_summary.csv",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Reduced DFBA simulate script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_SIMULATE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "DFBA_TFINAL_HOURS",
        "DFBA_SAVEAT_HOURS",
        "DFBA_RECONSTRUCT_FLUXES",
        "DFBA_LP_REUSE",
        "DFBA_LP_PRIMAL_START",
        "DFBA_LP_BASIS_WARM_START",
        "DFBA_ALLOW_EXPERIMENTAL_LP_REUSE",
        "DFBA_LP_REUSE_HIGHS_SOLVER",
        "DFBA_LP_SIMPLEX_STRATEGY",
        "DFBA_SOLVER_BACKEND",
        "DFBA_PHASE_PROXY_MODE",
        "DFBA_TURNOVER_THRESHOLD",
        "DFBA_ALGORITHM",
        "y0 = initial_state_config.y0",
        "params = params",
        "algorithm = algorithm_config.algorithm",
        "ode_abstol = tolerance_config.ode_abstol",
        "ode_reltol = tolerance_config.ode_reltol",
        "lp_atol = tolerance_config.lp_atol",
        "lp_reuse = lp_reuse",
        "lp_primal_start = lp_primal_start",
        "lp_reuse_highs_solver = lp_reuse_highs_solver",
        "lp_basis_warm_start = lp_basis_warm_start",
        "lp_simplex_strategy = lp_simplex_strategy",
        "allow_experimental_lp_reuse = allow_experimental_lp_reuse",
        "algorithm_label",
        "script_algorithm_label",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("DFBA_BENCH_ALGORITHM", script_text)
end

@testset "Full DFBA short simulate script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_FULL_SIMULATE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "full_model_paths.example.toml",
        "reaction_map_full.example.toml",
        "DFBA_FULL_TFINAL_HOURS",
        "DFBA_FULL_SAVEAT_HOURS",
        "DFBA_FULL_RECONSTRUCT_FLUXES",
        "simulate_full_dfba",
        "tspan = (0.0, tfinal)",
        "saveat = saveat",
        "reconstruct_fluxes = reconstruct_fluxes",
        "model_scope",
        "This is a short full ODE smoke path. Long full simulations are not default.",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("DFBA_SOLVER_BACKEND", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "Sequential DFVB short simulate script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DFVB_SIMULATE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "full_model_paths.example.toml",
        "reaction_map_full.example.toml",
        "dfvb_artifact_paths.example.toml",
        "DFVB_TFINAL_HOURS",
        "DFVB_SAVEAT_HOURS",
        "DFVB_RECONSTRUCT_FLUXES",
        "DFVB_RECONSTRUCT_ALPHAS",
        "simulate_dfvb",
        "algorithm = OrdinaryDiffEq.Tsit5()",
        "use_active_alpha = true",
        "reconstruct_fluxes = reconstruct_fluxes",
        "reconstruct_alphas = reconstruct_alphas",
        "Short sequential DFVB ODE smoke only; not KKT/MPCC.",
        "r0001_used_as_oxygen",
        "indices_reacciones_used",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("DFBA_SOLVER_BACKEND", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "MATLAB DFVB baseline report script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DFVB_BASELINE_REPORT_PATH)

    for required_text in (
        "dfvb_artifact_paths.example.toml",
        "load_alpha_trajectories = true",
        "load_active_alpha_trajectories = true",
        "load_state_trajectories = true",
        "validate_dfvb_artifacts",
        "build_dfvb_baseline_report",
        "export_dfvb_baseline_report",
        "write_dfvb_baseline_report_plots",
        "results\", \"dfvb_baseline\", \"latest",
        "alpha_mapping_note",
        "exchange_partition_note",
        "r0001_used_as_oxygen",
        "oxygen_reaction_id",
        "julia_simulation_run",
        "lp_solve_run",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("DFVB_TFINAL_HOURS", script_text)
    @test !occursin("simulate_dfvb", script_text)
    @test !occursin("ODEProblem", script_text)
    @test !occursin("OrdinaryDiffEq", script_text)
    @test !occursin("solve_dynamic_dfvb_lp", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "Julia-vs-MATLAB DFVB comparison script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DFVB_MATLAB_COMPARE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "full_model_paths.example.toml",
        "reaction_map_full.example.toml",
        "dfvb_artifact_paths.example.toml",
        "load_alpha_trajectories = false",
        "load_active_alpha_trajectories = false",
        "load_state_trajectories = true",
        "DFVB_MATLAB_COMPARE_TFINAL_HOURS",
        "DFVB_MATLAB_COMPARE_SAVEAT_HOURS",
        "DFVB_MATLAB_COMPARE_ALIGNMENT",
        "compare_dfvb_to_matlab_baseline",
        "export_dfvb_matlab_comparison",
        "write_dfvb_matlab_comparison_plots",
        "results\", \"dfvb_matlab_comparison\", \"latest",
        "algorithm = OrdinaryDiffEq.Tsit5()",
        "reconstruct_alphas = true",
        "reconstruct_fluxes = false",
        "alignment_policy = alignment_policy",
        "alpha_comparison_included",
        "flux_comparison_included",
        "r0001_used_as_oxygen",
        "oxygen_reaction_id",
        "interpretation_note",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("DFBA_SOLVER_BACKEND", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("DFVB_TFINAL_HOURS", script_text)
end

@testset "Sequential full-vs-reduced DFBA comparison script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_SEQ_COMPARE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "full_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "reaction_map_full.example.toml",
        "DFBA_SEQ_COMPARE_TFINAL_HOURS",
        "DFBA_SEQ_COMPARE_SAVEAT_HOURS",
        "DFBA_SEQ_COMPARE_RECONSTRUCT_FLUXES",
        "DFBA_SEQ_COMPARE_ALLOW_LONG_FULL",
        "DFBA_SEQ_COMPARE_ALLOW_DENSE_OUTPUT",
        "DFBA_SEQ_COMPARE_ADAPTIVE",
        "DFBA_SEQ_COMPARE_DT_HOURS",
        "DFBA_SEQ_COMPARE_PROGRESS_SECONDS",
        "DFBA_SEQ_COMPARE_MAX_RHS_CALLS",
        "DFBA_SEQ_COMPARE_MAX_WALLTIME_SECONDS",
        "SequentialDFBARuntimePolicy",
        "compare_sequential_dfba_full_reduced",
        "export_sequential_dfba_comparison",
        "write_sequential_dfba_comparison_plots",
        "results\", \"sequential_dfba_comparison\", \"latest",
        "algorithm = OrdinaryDiffEq.Tsit5()",
        "adaptive = adaptive",
        "dt = dt",
        "progress_interval_seconds = progress_interval_seconds",
        "max_rhs_calls = max_rhs_calls",
        "max_walltime_seconds = max_walltime_seconds",
        "runtime_policy = runtime_policy",
        "runtime_policy_label",
        "flux_comparison_included",
        "oxygen_note",
        "carbohydrate_note",
        "interpretation_note",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("DFBA_SOLVER_BACKEND", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "Consolidated sequential DFBA/DFVB comparison script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_SEQ_MODEL_COMPARE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "full_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "reaction_map_full.example.toml",
        "dfvb_artifact_paths.example.toml",
        "load_alpha_trajectories = false",
        "load_active_alpha_trajectories = false",
        "load_state_trajectories = true",
        "SEQ_MODEL_COMPARE_TFINAL_HOURS",
        "SEQ_MODEL_COMPARE_SAVEAT_HOURS",
        "SEQ_MODEL_COMPARE_ALIGNMENT",
        "compare_sequential_models",
        "export_sequential_model_comparison",
        "write_sequential_model_comparison_plots",
        "results\", \"sequential_model_comparison\", \"latest",
        "algorithm = OrdinaryDiffEq.Tsit5()",
        "reconstruct_fluxes = false",
        "reconstruct_alphas = false",
        "alignment_policy = alignment_policy",
        "flux_comparison_included",
        "alpha_comparison_included",
        "r0001_used_as_oxygen",
        "oxygen_reaction_id",
        "carbohydrate_policy_note",
        "interpretation_note",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("DFBA_SOLVER_BACKEND", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "Reduced DFBA export script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_EXPORT_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "DFBA_TFINAL_HOURS",
        "DFBA_SAVEAT_HOURS",
        "DFBA_RECONSTRUCT_FLUXES",
        "DFBA_LP_REUSE",
        "DFBA_LP_PRIMAL_START",
        "DFBA_LP_BASIS_WARM_START",
        "DFBA_ALLOW_EXPERIMENTAL_LP_REUSE",
        "DFBA_LP_REUSE_HIGHS_SOLVER",
        "DFBA_LP_SIMPLEX_STRATEGY",
        "DFBA_SOLVER_BACKEND",
        "DFBA_OUTPUT_DIR",
        "DFBA_EXPORT_OVERWRITE",
        "DFBA_PHASE_PROXY_MODE",
        "DFBA_TURNOVER_THRESHOLD",
        "DFBA_PROGRESS_INTERVAL_SECONDS",
        "DFBA_MAX_RHS_CALLS",
        "DFBA_MAX_WALLTIME_SECONDS",
        "DFBA_ALGORITHM",
        "y0 = initial_state_config.y0",
        "params = params",
        "algorithm = algorithm_config.algorithm",
        "ode_abstol = tolerance_config.ode_abstol",
        "ode_reltol = tolerance_config.ode_reltol",
        "lp_atol = tolerance_config.lp_atol",
        "progress_interval_seconds = progress_interval_seconds",
        "max_rhs_calls = max_rhs_calls",
        "max_walltime_seconds = max_walltime_seconds",
        "lp_reuse = lp_reuse",
        "lp_primal_start = lp_primal_start",
        "lp_reuse_highs_solver = lp_reuse_highs_solver",
        "lp_basis_warm_start = lp_basis_warm_start",
        "lp_simplex_strategy = lp_simplex_strategy",
        "allow_experimental_lp_reuse = allow_experimental_lp_reuse",
        "algorithm_label",
        "script_algorithm_label",
        "solver_label",
        "export_simulation_result",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("DFBA_BENCH_ALGORITHM", script_text)
end

@testset "Reduced DFBA dynamic-control export script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_EXPORT_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "solver_backend_helpers.jl",
        "_script_dynamic_control_schedule_config",
        "DFBA_DYNAMIC_TFINAL_HOURS",
        "DFBA_DYNAMIC_SAVEAT_HOURS",
        "DFBA_DYNAMIC_RECONSTRUCT_FLUXES",
        "DFBA_DYNAMIC_WRITE_PLOTS",
        "DFBA_DYNAMIC_LP_REUSE",
        "DFBA_DYNAMIC_LP_PRIMAL_START",
        "DFBA_DYNAMIC_LP_BASIS_WARM_START",
        "DFBA_DYNAMIC_ALLOW_EXPERIMENTAL_LP_REUSE",
        "DFBA_DYNAMIC_LP_REUSE_HIGHS_SOLVER",
        "DFBA_DYNAMIC_LP_SIMPLEX_STRATEGY",
        "DFBA_DYNAMIC_SOLVER_BACKEND",
        "DFBA_DYNAMIC_OUTPUT_DIR",
        "DFBA_DYNAMIC_EXPORT_OVERWRITE",
        "DFBA_DYNAMIC_PHASE_PROXY_MODE",
        "DFBA_DYNAMIC_TURNOVER_THRESHOLD",
        "DFBA_DYNAMIC_PROGRESS_INTERVAL_SECONDS",
        "DFBA_DYNAMIC_MAX_RHS_CALLS",
        "DFBA_DYNAMIC_MAX_WALLTIME_SECONDS",
        "DFBA_DYNAMIC_ALGORITHM",
        "DFBA_DYNAMIC_ODE_ABSTOL",
        "DFBA_DYNAMIC_ODE_RELTOL",
        "DFBA_DYNAMIC_LP_ATOL",
        "dynamic_control_schedule = schedule",
        "export_simulation_result",
        "write_default_trajectory_plots",
        "dynamic_control_schedule.csv",
        "dynamic_control_summary.csv",
        "script_algorithm_label",
        "solver_label",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("MPCC", script_text)
    @test !occursin("Ipopt", script_text)
end

@testset "Dynamic temperature objective smoke script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_TEMPERATURE_OBJECTIVE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "solver_backend_helpers.jl",
        "evaluate_dynamic_temperature_objective",
        "dynamic_temperature_control_value_count",
        "DFBA_DYNAMIC_OPT_HORIZON_HOURS",
        "DFBA_DYNAMIC_OPT_CONTROL_INTERVAL_HOURS",
        "DFBA_DYNAMIC_OPT_TEMPERATURE_WIDTH_HOURS",
        "DFBA_DYNAMIC_OPT_T_MIN_C",
        "DFBA_DYNAMIC_OPT_T_MAX_C",
        "DFBA_DYNAMIC_OPT_TEMPERATURE_PROFILES_C",
        "DFBA_DYNAMIC_OPT_OUTPUT_DIR",
        "DFBA_DYNAMIC_OPT_FINAL_SUGAR_WEIGHT",
        "DFBA_DYNAMIC_OPT_ETHANOL_REWARD_WEIGHT",
        "DFBA_DYNAMIC_OPT_TEMPERATURE_SMOOTHNESS_WEIGHT",
        "DFBA_DYNAMIC_OPT_TEMPERATURE_MOVE_WEIGHT",
        "DFBA_DYNAMIC_OPT_SOLVER_BACKEND",
        "DFBA_DYNAMIC_OPT_ALGORITHM",
        "dynamic_temperature_objective_candidates.csv",
        "dynamic_temperature_objective_metadata.toml",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("MPCC", script_text)
    @test !occursin("Ipopt", script_text)
end

@testset "Dynamic temperature pattern search script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_TEMPERATURE_SEARCH_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "solver_backend_helpers.jl",
        "optimize_dynamic_temperature_pattern_search",
        "DFBA_DYNAMIC_SEARCH_HORIZON_HOURS",
        "DFBA_DYNAMIC_SEARCH_CONTROL_INTERVAL_HOURS",
        "DFBA_DYNAMIC_SEARCH_TEMPERATURE_WIDTH_HOURS",
        "DFBA_DYNAMIC_SEARCH_T_MIN_C",
        "DFBA_DYNAMIC_SEARCH_T_MAX_C",
        "DFBA_DYNAMIC_SEARCH_FIX_INITIAL_T",
        "DFBA_DYNAMIC_SEARCH_INITIAL_STEP_C",
        "DFBA_DYNAMIC_SEARCH_MIN_STEP_C",
        "DFBA_DYNAMIC_SEARCH_MAX_EVALUATIONS",
        "DFBA_DYNAMIC_SEARCH_OUTPUT_DIR",
        "DFBA_DYNAMIC_SEARCH_FINAL_SUGAR_WEIGHT",
        "DFBA_DYNAMIC_SEARCH_ETHANOL_REWARD_WEIGHT",
        "DFBA_DYNAMIC_SEARCH_TEMPERATURE_SMOOTHNESS_WEIGHT",
        "DFBA_DYNAMIC_SEARCH_SOLVER_BACKEND",
        "DFBA_DYNAMIC_SEARCH_ALGORITHM",
        "dynamic_temperature_pattern_search_candidates.csv",
        "dynamic_temperature_pattern_search_metadata.toml",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("MPCC", script_text)
    @test !occursin("Ipopt", script_text)
end

@testset "Dynamic control objective smoke script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_OBJECTIVE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "solver_backend_helpers.jl",
        "evaluate_dynamic_control_objective",
        "springferm_xtrem_organic_composition",
        "FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G",
        "dynamic_control_candidate_designs",
        "DFBA_DYNAMIC_CONTROL_OPT_HORIZON_HOURS",
        "DFBA_DYNAMIC_CONTROL_OPT_INTERVAL_HOURS",
        "DFBA_DYNAMIC_CONTROL_OPT_TEMPERATURE_WIDTH_HOURS",
        "DFBA_DYNAMIC_CONTROL_OPT_ADDITION_WIDTH_HOURS",
        "DFBA_DYNAMIC_CONTROL_OPT_T_MIN_C",
        "DFBA_DYNAMIC_CONTROL_OPT_T_MAX_C",
        "DFBA_DYNAMIC_CONTROL_OPT_CANDIDATE_SET",
        "DFBA_DYNAMIC_CONTROL_OPT_MAX_CANDIDATES",
        "DynamicControlSelectionCriteria",
        "dynamic_control_apply_selection_gates!",
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_FINAL_SUGAR_MAX_G_L",
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MIN_AROMA_SCORE",
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MAX_ENERGY_PROXY",
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MAX_NUTRIENT_G_L",
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_COUNT",
        "DFBA_DYNAMIC_CONTROL_OPT_WRITE_PLOTS",
        "DFBA_DYNAMIC_CONTROL_OPT_WRITE_PARTIAL_CSV",
        "DFBA_DYNAMIC_CONTROL_OPT_PLOT_CANDIDATE_COUNT",
        "DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_MODE",
        "DFBA_DYNAMIC_CONTROL_OPT_TERMINAL_SUGAR_GATE_G_L",
        "DFBA_DYNAMIC_CONTROL_OPT_TERMINAL_SUGAR_FEASIBILITY_MODE",
        "DFBA_DYNAMIC_CONTROL_OPT_PRODUCTIVITY_SUGAR_EXCESS_WEIGHT",
        "DFBA_DYNAMIC_CONTROL_OPT_THERMAL_ENERGY_WEIGHT",
        "write_dynamic_control_pareto_plots",
        "write_dynamic_control_candidate_plots",
        "DFBA_DYNAMIC_CONTROL_OPT_OUTPUT_DIR",
        "DFBA_DYNAMIC_CONTROL_OPT_RESIDUAL_SUGAR_WEIGHT",
        "DFBA_DYNAMIC_CONTROL_OPT_AROMA_DESIRABILITY_WEIGHT",
        "DFBA_DYNAMIC_CONTROL_OPT_COOLING_ENERGY_WEIGHT",
        "DFBA_DYNAMIC_CONTROL_OPT_TEMPERATURE_ENERGY_SCALE_C",
        "DFBA_DYNAMIC_CONTROL_OPT_FDA_TOTAL_DOSE_WEIGHT",
        "DFBA_DYNAMIC_CONTROL_OPT_ORG_TOTAL_DOSE_WEIGHT",
        "DFBA_DYNAMIC_CONTROL_OPT_SOLVER_BACKEND",
        "DFBA_DYNAMIC_CONTROL_OPT_ALGORITHM",
        "dynamic_control_objective_candidates.csv",
        "dynamic_control_objective_candidates_partial.csv",
        "dynamic_control_objective_shortlist.csv",
        "dynamic_control_objective_metadata.toml",
        "dynamic_control_objective_candidate_failed",
        "failed_exception",
        "exception_message",
        "productivity_sugar_excess_auc_normalized",
        "thermal_energy_proxy_unweighted",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("MPCC", script_text)
    @test !occursin("Ipopt", script_text)
end

@testset "Dynamic control policy selection script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_POLICY_SELECTION_PATH)

    for required_text in (
        "DFBA_DYNAMIC_CONTROL_POLICY_CANDIDATES_CSV",
        "DFBA_DYNAMIC_CONTROL_POLICY_METADATA_TOML",
        "DFBA_DYNAMIC_CONTROL_POLICY_SELECTED_IDS",
        "DFBA_DYNAMIC_CONTROL_POLICY_INCLUDE_SCALAR_BEST",
        "DFBA_DYNAMIC_CONTROL_POLICY_OUTPUT_DIR",
        "dynamic_control_policy_selection.csv",
        "dynamic_control_policy_selection.toml",
        "control_policy_ready",
        "mpcc_fixed_control_replay_ready",
        "selection_ready_for_reduced_mpcc_fixed_control_preflight",
        "main_reduced_mpcc_fixed_control_policy_preflight.jl",
        "solves_run",
        "false",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("optimize!", script_text)
    @test !occursin("solve_reduced_dcdfba_mpcc", script_text)
    @test !occursin("simulate_reduced_dfba", script_text)
end

@testset "Dynamic control local pilot design script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_LOCAL_PILOT_PATH)

    for required_text in (
        "MPCC_DYNAMIC_CONTROL_PILOT_BASE_SELECTION_CSV",
        "MPCC_DYNAMIC_CONTROL_PILOT_BASE_CANDIDATE_ID",
        "MPCC_DYNAMIC_CONTROL_PILOT_OUTPUT_DIR",
        "MPCC_DYNAMIC_CONTROL_PILOT_SCHEDULE_HOURS",
        "MPCC_DYNAMIC_CONTROL_PILOT_INTERVAL_HOURS",
        "MPCC_DYNAMIC_CONTROL_PILOT_T_MIN_C",
        "MPCC_DYNAMIC_CONTROL_PILOT_T_MAX_C",
        "MPCC_DYNAMIC_CONTROL_PILOT_TEMPERATURE_STEP_C",
        "MPCC_DYNAMIC_CONTROL_PILOT_ORGANIC_STEP_G_L",
        "MPCC_DYNAMIC_CONTROL_PILOT_FDA_STEP_G_L",
        "MPCC_DYNAMIC_CONTROL_PILOT_TEMPERATURE_SLOT_COUNT",
        "MPCC_DYNAMIC_CONTROL_PILOT_ADDITION_SLOT_COUNT",
        "MPCC_DYNAMIC_CONTROL_PILOT_MAX_CANDIDATES",
        "MPCC_DYNAMIC_CONTROL_PILOT_INCLUDE_NUTRIENT_EQUIVALENT_SWAP",
        "springferm_xtrem_organic_composition",
        "FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L",
        "dynamic_control_local_pilot_candidates.csv",
        "dynamic_control_local_pilot_runlist.txt",
        "dynamic_control_local_pilot_metadata.toml",
        "control_policy_ready",
        "pilot_control_liberation_mode",
        "outer_loop_local_policy_trust_region",
        "fully_simultaneous_controls",
        "false",
        "fixed_control_mpcc_required_next",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("optimize!", script_text)
    @test !occursin("solve_reduced_dcdfba_mpcc", script_text)
    @test !occursin("simulate_reduced_dfba", script_text)
end

@testset "Dynamic control sequential sensitivity checkpoint contract" begin
    script_text =
        _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_SEQUENTIAL_SENSITIVITY_PATH)

    for required_text in (
        "_sens_write_result_tables",
        "MPCC_DYNAMIC_CONTROL_SENSITIVITY_FDA_INDICES",
        "MPCC_DYNAMIC_CONTROL_SENSITIVITY_ORGANIC_INDICES",
        "fda_indices",
        "organic_indices",
        "dynamic_control_sequential_sensitivity$(suffix).csv",
        "dynamic_control_sequential_sensitivity_ranked$(suffix).csv",
        "suffix = \"_partial\"",
        "dynamic_control_sensitivity_partial_csv",
        "suffix::AbstractString = \"\"",
        "result_path = _sens_write_result_tables(output_dir, rows)",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("optimize!", script_text)
end

@testset "Dynamic control sequential atlas wrapper contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_SEQUENTIAL_ATLAS_PATH)

    for required_text in (
        "DFBA_DYNAMIC_CONTROL_OPT_HORIZON_HOURS",
        "168",
        "DFBA_DYNAMIC_CONTROL_OPT_CANDIDATE_SET",
        "atlas",
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_FINAL_SUGAR_MAX_G_L",
        "DFBA_DYNAMIC_CONTROL_OPT_TERMINAL_SUGAR_GATE_G_L",
        "DFBA_DYNAMIC_CONTROL_OPT_PRODUCTIVITY_SUGAR_EXCESS_WEIGHT",
        "DFBA_DYNAMIC_CONTROL_OPT_THERMAL_ENERGY_WEIGHT",
        "main_dynamic_control_objective_smoke.jl",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("optimize!", script_text)
end

@testset "Dynamic control liberated decision spec script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_LIBERATED_SPEC_PATH)

    for required_text in (
        "MPCC_DYNAMIC_CONTROL_LIBERATION_BASE_SELECTION_CSV",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_BASE_CANDIDATE_ID",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_OUTPUT_DIR",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_SCHEDULE_HOURS",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_INTERVAL_HOURS",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_SLOT_COUNT",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_SLOT_COUNT",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_INDICES",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_INDICES",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_START_OFFSETS_C",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_START_OFFSETS_G_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_START_OFFSETS_G_L",
        "_lib_resized",
        "_lib_parse_liberation_indices",
        "_lib_parse_indexed_float_offsets",
        "_lib_apply_start_offsets",
        "source_temperature_value_count",
        "addition_dose_count",
        "temperature_indices_raw",
        "addition_indices_raw",
        "temperature_start_offsets_C",
        "fda_start_offsets_g_L",
        "organic_start_offsets_g_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_TRUST_C",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_TRUST_G_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_TRUST_G_L",
        "dynamic_control_decision_spec",
        "dynamic_control_decision_table",
        "dynamic_control_schedule_from_decision_spec",
        "dynamic_control_liberated_decision_spec.csv",
        "dynamic_control_liberated_start_schedule.csv",
        "dynamic_control_liberated_metadata.toml",
        "embedded_mpcc_control_decision_spec",
        "fully_simultaneous_controls",
        "false",
        "mpcc_embedding_ready",
        "mpcc_fixed_control_sane_required",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("optimize!", script_text)
    @test !occursin("solve_reduced_dcdfba_mpcc", script_text)
    @test !occursin("simulate_reduced_dfba", script_text)
end

@testset "Reduced MPCC fixed-control policy preflight script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_FIXED_CONTROL_PREFLIGHT_PATH)

    for required_text in (
        "solver_backend_helpers.jl",
        "MPCC_FIXED_CONTROL_POLICY_SELECTION_CSV",
        "MPCC_FIXED_CONTROL_OUTPUT_DIR",
        "MPCC_FIXED_CONTROL_PREFLIGHT_HOURS",
        "MPCC_FIXED_CONTROL_NFE",
        "MPCC_FIXED_CONTROL_SCHEDULE_HOURS",
        "MPCC_FIXED_CONTROL_INTERVAL_HOURS",
        "dynamic_control_schedule = schedule",
        "include_rhs = true",
        "use_dynamic_bounds = true",
        "apply_default_start_initializers",
        "reduced_mpcc_fixed_control_policy_preflight.csv",
        "reduced_mpcc_fixed_control_policy_preflight.toml",
        "mpcc_fixed_control_replay_ready",
        "solver_call_performed",
        "false",
    )
        @test occursin(required_text, script_text)
    end

    @test occursin("build_reduced_dcdfba_mpcc_smoke_problem", script_text)
    @test !occursin("optimize!", script_text)
    @test !occursin("solve_reduced_dcdfba_mpcc", script_text)
    @test !occursin("simulate_reduced_dfba", script_text)
end

@testset "Reduced MPCC fixed-control policy smoke script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_FIXED_CONTROL_SMOKE_PATH)

    for required_text in (
        "solver_backend_helpers.jl",
        "ode_script_helpers.jl",
        "MPCC_FIXED_CONTROL_POLICY_SELECTION_CSV",
        "MPCC_FIXED_CONTROL_CANDIDATE_ID",
        "MPCC_FIXED_CONTROL_OUTPUT_DIR",
        "MPCC_FIXED_CONTROL_SMOKE_HOURS",
        "MPCC_FIXED_CONTROL_MAX_ITER",
        "MPCC_FIXED_CONTROL_NFE",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_HOURS",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_ALGORITHM",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_RECONSTRUCT_FLUXES",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_STOP_ON_SUGAR_DEPLETION",
        "MPCC_FIXED_CONTROL_COMPLEMENTARITY_MODE",
        "MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU",
        "MPCC_FIXED_CONTROL_COLLOCATION_CONSISTENT_STATE_STARTS",
        "MPCC_FIXED_CONTROL_SCHEDULE_HOURS",
        "MPCC_FIXED_CONTROL_INTERVAL_HOURS",
        "dynamic_control_schedule = schedule",
        "sequential_initialization = sequential_result",
        "collocation_consistent_state_starts = collocation_consistent_state_starts",
        "complementarity_mode = complementarity_mode",
        "complementarity_tau = complementarity_tau",
        "include_rhs = true",
        "use_dynamic_bounds = true",
        "reduced_mpcc_fixed_control_policy_smoke.csv",
        "reduced_mpcc_fixed_control_policy_smoke.toml",
        "mpcc_fixed_control_replay_ready",
        "solver_call_performed",
        "smoke_result_is_scientific_simulation",
        "false",
    )
        @test occursin(required_text, script_text)
    end

    @test occursin("solve_reduced_dcdfba_mpcc_smoke", script_text)
    @test occursin("simulate_reduced_dfba", script_text)
    @test occursin("ipopt_max_iter = ipopt_max_iter", script_text)
    @test occursin("linear_solver = linear_solver", script_text)
end

@testset "Reduced MPCC fixed-control policy solve-attempt script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_FIXED_CONTROL_SOLVE_ATTEMPT_PATH)

    for required_text in (
        "solver_backend_helpers.jl",
        "ode_script_helpers.jl",
        "MPCC_FIXED_CONTROL_POLICY_SELECTION_CSV",
        "MPCC_FIXED_CONTROL_CANDIDATE_ID",
        "MPCC_FIXED_CONTROL_CASE_ID",
        "MPCC_FIXED_CONTROL_OUTPUT_DIR",
        "MPCC_FIXED_CONTROL_SOLVE_HOURS",
        "MPCC_FIXED_CONTROL_MAX_ITER",
        "MPCC_FIXED_CONTROL_NFE",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_HOURS",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_POLICY",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TOL",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_ELEMENTS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SCORE",
        "fixed_control_entrypoint_phase",
        "before_using_FermentationDFBA",
        "before_mpcc_solve_attempt",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_REFRESH",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_FLUX_PROJECTION",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION_TRIGGER_THRESHOLD",
        "active_complementarity_flux_projection_guard_enabled",
        "active_complementarity_flux_projection_guard_accepted",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT_TRIGGER_THRESHOLD",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_ACCEPT_TOL",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_DAMPING_FACTORS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_REFRESH_RHS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD_SCORE",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_SCORE",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_ACCEPT_TOL",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ENABLED",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_GUARD_SCORE",
        "MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP",
        "MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP_ELEMENTS",
        "MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP_BUDGET_FRACTION",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_ALGORITHM",
        "MPCC_FIXED_CONTROL_COMPLEMENTARITY_MODE",
        "MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU",
        "MPCC_FIXED_CONTROL_IPOPT_PROFILE",
        "MPCC_FIXED_CONTROL_REQUIRE_PRE_SOLVE_READY",
        "MPCC_FIXED_CONTROL_PRE_SOLVE_ONLY",
        "MPCC_FIXED_CONTROL_RESIDUAL_LOCATION_TOP_N",
        "MPCC_FIXED_CONTROL_COMPLEMENTARITY_LOCATION_TOP_N",
        "MPCC_FIXED_CONTROL_THRESHOLD_MAX_RHS_RESIDUAL",
        "MPCC_FIXED_CONTROL_THRESHOLD_MAX_MASS_BALANCE_RESIDUAL",
        "MPCC_FIXED_CONTROL_DYNAMIC_CONTROL_DECISIONS",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ENABLED",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_MODE",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_SLOT_COUNT",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_SLOT_COUNT",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_INDICES",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_INDICES",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_START_OFFSETS_C",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_START_OFFSETS_G_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_START_OFFSETS_G_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_TRUST_C",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_TRUST_G_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_TRUST_G_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_SAMPLE_DT_HOURS",
        "_fixed_control_resized",
        "_fixed_control_parse_indexed_float_offsets",
        "_fixed_control_apply_start_offsets",
        "normalized == \"explicit\" && requested_count <= 0 && return Int[]",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TARGET_STATE",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_REWARD_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_SCALE_G_L",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_THERMAL_ENERGY_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_WEIGHT",
        "reduced_mpcc_dynamic_control_objective_config_from_env",
        "_fixed_control_liberation_indices",
        "dynamic_control_decision_spec_value",
        "dynamic_control_decision_spec = dynamic_control_decision_spec_value",
        "dynamic_control_objective_config = dynamic_control_objective_config",
        "dynamic_control_decision_table",
        "dynamic_control_schedule_from_decision_spec",
        "sample_dynamic_control_schedule",
        "reduced_mpcc_dynamic_control_decision_spec.csv",
        "reduced_mpcc_dynamic_control_start_schedule.csv",
        "dynamic_control_schedule = schedule",
        "sequential_initialization = sequential_result",
        "residual_thresholds = residual_thresholds",
        "require_pre_solve_ready = require_pre_solve_ready",
        "reduced_mpcc_fixed_control_policy_solve_attempt.csv",
        "reduced_mpcc_fixed_control_policy_solve_attempt.toml",
        "reduced_mpcc_fixed_control_policy_residual_locations.csv",
        "reduced_mpcc_fixed_control_policy_complementarity_locations.csv",
        "reduced_mpcc_fixed_control_policy_bound_violation_locations.csv",
        "reduced_mpcc_fixed_control_policy_rhs_residual_locations.csv",
        "reduced_mpcc_fixed_control_policy_repair_trace.csv",
        "reduced_mpcc_fixed_control_policy_repair_substeps.csv",
        "case_id",
        "solve_horizon_h",
        "ipopt_max_iter",
        "grid_element_length_h",
        "sequential_saveat_policy",
        "collocation_repair_elements",
        "collocation_consistent_state_start_converged",
        "collocation_consistent_state_start_iterations",
        "collocation_consistent_state_start_max_iterations",
        "collocation_consistent_state_start_element_indices",
        "collocation_consistent_state_start_final_collocation_residual",
        "collocation_consistent_state_start_final_continuity_residual",
        "collocation_consistent_state_start_final_rhs_residual",
        "collocation_consistent_state_start_final_state_refresh_enabled",
        "collocation_consistent_state_start_final_flux_projection_enabled",
        "collocation_consistent_state_start_final_complementarity_flux_projection_enabled",
        "active_complementarity_flux_projection_max_lower_complementarity_after",
        "collocation_consistent_state_start_final_selective_dual_fit_enabled",
        "collocation_consistent_state_start_last_final_selective_dual_fit_applied",
        "selective_fixed_flux_stationarity_dual_fit_accepted",
        "collocation_consistent_state_start_final_state_after_rhs_enabled",
        "collocation_consistent_state_start_last_final_state_after_rhs_applied",
        "collocation_consistent_state_start_final_state_after_rhs_guard_enabled",
        "collocation_consistent_state_start_final_state_after_rhs_guard_accepted",
        "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_enabled",
        "bound_dual_complementarity_clip_enabled",
        "bound_dual_complementarity_clip_applied",
        "bound_dual_complementarity_clip_elements",
        "bound_dual_complementarity_clip_max_stationarity_residual_after",
        "bound_dual_complementarity_clip_max_lower_complementarity_residual_after",
        "top_residual_location",
        "top_complementarity_location",
        "complementarity_location_csv",
        "top_bound_violation_location",
        "bound_violation_location_csv",
        "top_rhs_residual_location",
        "rhs_residual_location_csv",
        "repair_trace_csv",
        "repair_trace_row_count",
        "repair_substep_trace_csv",
        "repair_substep_trace_row_count",
        "collocation_consistent_state_start_repair_trace",
        "collocation_consistent_state_start_repair_trace_count",
        "collocation_consistent_state_start_repair_substep_trace",
        "collocation_consistent_state_start_repair_substep_trace_count",
        "collocation_integration",
        "continuity",
        "residual_thresholds_satisfied",
        "guarded_solve_attempt_allowed",
        "candidate_values_available",
        "candidate_residual_feasible",
        "candidate_values_source",
        "candidate_selection_policy",
        "candidate_selection_reason",
        "selected_candidate_source",
        "selected_candidate_is_pre_solve_start",
        "selected_candidate_is_post_solve",
        "selected_candidate_residual_feasible",
        "selected_candidate_terminal_state_values_available",
        "selected_candidate_terminal_total_sugar_g_L",
        "selected_candidate_terminal_isoamyl_alcohol_g_L",
        "mpcc_dynamic_control_decision_spec_provided",
        "mpcc_dynamic_control_variable_policy",
        "mpcc_dynamic_control_variables_coupled_to_rhs",
        "mpcc_dynamic_control_variables_coupled_to_dynamic_bounds",
        "rhs_residual_uses_control_decision_variables",
        "dynamic_flux_bounds_use_control_decision_variables",
        "fully_simultaneous_controls",
        "control_variable_count",
        "control_free_variable_count",
        "free_temperature_count",
        "free_fda_count",
        "free_organic_count",
        "dynamic_control_reference_regularization_enabled",
        "dynamic_control_reference_regularization_weight",
        "dynamic_control_reference_regularization_term_count",
        "dynamic_control_objective_enabled",
        "dynamic_control_objective_mode",
        "dynamic_control_objective_requested_target_state",
        "dynamic_control_objective_resolved_target_state",
        "dynamic_control_objective_target_state_alias_policy",
        "dynamic_control_objective_target_component_count",
        "dynamic_control_objective_target_component_names",
        "dynamic_control_objective_terminal_reward_weight",
        "dynamic_control_objective_terminal_state_scale_g_L",
        "dynamic_control_objective_terminal_sugar_weight",
        "dynamic_control_objective_terminal_sugar_scale_g_L",
        "dynamic_control_objective_terminal_sugar_terms",
        "dynamic_control_objective_integrated_sugar_weight",
        "dynamic_control_objective_integrated_sugar_scale_g_L",
        "dynamic_control_objective_integrated_sugar_terms",
        "dynamic_control_objective_nutrient_weight",
        "dynamic_control_objective_thermal_energy_weight",
        "dynamic_control_objective_temperature_smoothness_weight",
        "dynamic_control_objective_term_count",
        "post_solve_candidate_accepted",
        "post_solve_candidate_rejected",
        "post_solve_candidate_rejection_reason",
        "post_solve_candidate_dynamic_control_values_captured",
        "post_solve_candidate_dynamic_control_delta_vs_pre_solve_available",
        "post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve",
        "post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve",
        "post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve",
        "solve_attempt_linear_solver",
        "solve_attempt_ipopt_profile",
        "solve_attempt_ipopt_hessian_approximation",
        "solve_attempt_is_scientific_simulation",
        "false",
    )
        @test occursin(required_text, script_text)
    end

    @test occursin("solve_reduced_dcdfba_mpcc_solve_attempt", script_text)
    @test occursin("simulate_reduced_dfba", script_text)
    @test occursin("ipopt_max_iter = ipopt_max_iter", script_text)
    @test occursin("linear_solver = linear_solver", script_text)
end

@testset "Reduced MPCC solve-attempt core clipping contract" begin
    core_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_REDUCED_DCDFBA_COLLOCATION_NLP_PATH)

    for required_text in (
        "bound_dual_complementarity_clip::Bool = false",
        "bound_dual_complementarity_clip_element_indices = collocation_consistent_state_start_element_indices",
        "bound_dual_complementarity_clip_budget_fraction::Real",
        "final_state_after_rhs::Bool = false",
        "final_state_after_rhs_guard::Bool = true",
        "final_state_after_rhs_refresh_rhs::Bool = false",
        "final_state_after_rhs_guard_score",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SCORE",
        "candidate_threshold_ratio",
        "final_complementarity_flux_projection",
        "_reduced_dcdfba_project_active_complementarity_flux_starts!",
        "active_complementarity_flux_projection_trigger_threshold",
        "active_complementarity_flux_projection_guard_enabled",
        "active_complementarity_flux_projection_guard_accepted",
        "final_selective_dual_fit::Bool = false",
        "final_selective_dual_fit = options.final_selective_dual_fit",
        "final_state_after_rhs = options.final_state_after_rhs",
        "final_state_after_rhs_guard = options.final_state_after_rhs_guard",
        "final_state_after_rhs_refresh_rhs =",
        "final_state_after_rhs_guard_score =",
        "score_policy = final_state_after_rhs_guard_score",
        "collocation_consistent_state_start_final_state_after_rhs_enabled",
        "collocation_consistent_state_start_final_state_after_rhs_guard_enabled",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_DAMPING_FACTORS",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_REFRESH_RHS",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD_SCORE",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ENABLED",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS",
        "collocation_consistent_state_start_post_tail_repair_accepted",
        "_reduced_dcdfba_clip_bound_dual_starts_for_complementarity!",
        "bound_dual_complementarity_clip = bound_dual_complementarity_clip",
        "bound_dual_complementarity_clip_element_indices =",
        "bound_dual_complementarity_clip_budget_fraction =",
        "\"bound_dual_complementarity_clip_\"",
        "reduced_dcdfba_mpcc_bound_violation_location_rows",
        "reduced_dcdfba_mpcc_complementarity_location_rows",
        "reduced_dcdfba_mpcc_rhs_residual_location_rows",
        "top_bound_violation_location_reaction_id",
        "top_complementarity_location_reaction_id",
        "top_rhs_residual_location_state_name",
        "ReducedDCDFBADynamicControlDecisionScaffold",
        "dynamic_control_decision_spec = nothing",
        "build_reduced_dcdfba_dynamic_control_decision_scaffold!",
        "scaffold_variables_not_yet_coupled",
        "coupled_control_decision_variables",
        "control_variable_count",
        "free_temperature_count",
        "free_fda_count",
        "free_organic_count",
        "control_bounds_ok",
        "control_starts_ok",
        "MPCC_DYNAMIC_CONTROL_REFERENCE_REGULARIZATION_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_REWARD_POLICY",
        "_reduced_dcdfba_add_dynamic_control_objective!",
        "dynamic_control_objective_enabled",
        "isoamyl_acetate_not_explicit_in_reduced_state_vector",
        "white_wine_aroma_blend",
        "available_reduced_aroma_linear_blend",
        "terminal_plus_integrated_flux",
        "dynamic_control_objective_integrated_aroma_reward_terms",
        "dynamic_control_objective_terminal_sugar_terms",
        "dynamic_control_objective_integrated_sugar_terms",
        "radau_time_average_of_squared_total_sugar",
        "radau_time_average_of_squared_total_sugar_excess_slack",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_POLICY",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_MAX_G_L",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_TEMPERATURE_REWARD_WEIGHT",
        "dynamic_control_objective_direct_temperature_reward_terms",
        "dynamic_control_objective_direct_fda_reward_terms",
        "dynamic_control_objective_direct_organic_reward_terms",
        "_reduced_dcdfba_add_dynamic_control_reference_regularization!",
        "dynamic_control_reference_regularization_enabled",
        "mpcc_dynamic_control_variables_coupled_to_rhs",
        "rhs_residual_uses_control_decision_variables",
        "dynamic_flux_bounds_use_control_decision_variables",
    )
        @test occursin(required_text, core_text)
    end
end

@testset "Cluster UC fixed-control solve-attempt sweep sbatch contract" begin
    script_text =
        _script_entrypoint_text(SCRIPT_ENTRYPOINT_CLUSTER_FIXED_CONTROL_SOLVE_ATTEMPT_SWEEP_PATH)

    for required_text in (
        "#SBATCH --ntasks=1",
        "#SBATCH --cpus-per-task=8",
        "#SBATCH --mem=32G",
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MPCC_IPOPT_HSLLIB",
        "MPCC_IPOPT_HESSIAN_APPROXIMATION",
        "limited-memory",
        "MPCC_IPOPT_WARM_START_INIT_POINT",
        "MPCC_IPOPT_WARM_START_BOUND_PUSH",
        "MPCC_FIXED_SWEEP_HORIZONS_HOURS",
        "MPCC_FIXED_SWEEP_NFE_VALUES",
        "MPCC_FIXED_SWEEP_MAX_ITERS",
        "MPCC_FIXED_SWEEP_REPAIR_ELEMENTS",
        "MPCC_FIXED_SWEEP_MAX_CASES",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TOL",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_ELEMENTS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SCORE",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_POLICY",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_REFRESH",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_FLUX_PROJECTION",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION_TRIGGER_THRESHOLD",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT_TRIGGER_THRESHOLD",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_ACCEPT_TOL",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_DAMPING_FACTORS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_REFRESH_RHS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD_SCORE",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_SCORE",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_ACCEPT_TOL",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ENABLED",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_GUARD_SCORE",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MONOTONE",
        "MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP",
        "MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP_ELEMENTS",
        "MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP_BUDGET_FRACTION",
        "MPCC_FIXED_CONTROL_CASE_ID",
        "MPCC_FIXED_CONTROL_OUTPUT_DIR",
        "MPCC_FIXED_CONTROL_REQUIRE_PRE_SOLVE_READY",
        "MPCC_FIXED_CONTROL_PRE_SOLVE_ONLY",
        "MPCC_FIXED_CONTROL_COMPLEMENTARITY_MODE",
        "MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU",
        "MPCC_FIXED_CONTROL_COMPLEMENTARITY_LOCATION_TOP_N",
        "MPCC_FIXED_CONTROL_LINEAR_SOLVER",
        "ma86",
        "scripts/main_reduced_mpcc_fixed_control_policy_solve_attempt.jl",
        "reduced_mpcc_fixed_control_solve_attempt_sweep.csv",
        "reduced_mpcc_fixed_control_solve_attempt_sweep_failures.csv",
        "scientific_simulation=false",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC dynamic-control local pilot fixed-MPCC sbatch contract" begin
    script_text =
        _script_entrypoint_text(SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_LOCAL_PILOT_PATH)

    for required_text in (
        "#SBATCH --ntasks=1",
        "#SBATCH --cpus-per-task=8",
        "#SBATCH --mem=32G",
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MPCC_IPOPT_HSLLIB",
        "MPCC_IPOPT_HESSIAN_APPROXIMATION",
        "limited-memory",
        "MPCC_DYNAMIC_CONTROL_PILOT_BASE_SELECTION_CSV",
        "MPCC_DYNAMIC_CONTROL_PILOT_BASE_CANDIDATE_ID",
        "MPCC_DYNAMIC_CONTROL_PILOT_MAX_EVALS",
        "MPCC_DYNAMIC_CONTROL_PILOT_TEMPERATURE_STEP_C",
        "MPCC_DYNAMIC_CONTROL_PILOT_ORGANIC_STEP_G_L",
        "MPCC_DYNAMIC_CONTROL_PILOT_FDA_STEP_G_L",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_POLICY",
        "collocation_grid",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MONOTONE",
        "MPCC_FIXED_CONTROL_LINEAR_SOLVER",
        "ma86",
        "scripts/main_dynamic_control_local_pilot_design.jl",
        "scripts/main_reduced_mpcc_fixed_control_policy_solve_attempt.jl",
        "dynamic_control_local_pilot_fixed_mpcc_attempts.csv",
        "dynamic_control_local_pilot_fixed_mpcc_failures.csv",
        "control_liberation_mode=outer_loop_local_policy_trust_region",
        "fully_simultaneous_controls=false",
        "scientific_simulation=false",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC dynamic-control liberated MPCC pilot sbatch contract" begin
    script_text =
        _script_entrypoint_text(SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_LIBERATED_PILOT_PATH)

    for required_text in (
        "#SBATCH --ntasks=1",
        "#SBATCH --cpus-per-task=8",
        "#SBATCH --mem=32G",
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "OPENBLAS_NUM_THREADS:-1",
        "MPCC_IPOPT_HSLLIB",
        "MPCC_IPOPT_HESSIAN_APPROXIMATION",
        "limited-memory",
        "MPCC_FIXED_CONTROL_POLICY_SELECTION_CSV",
        "MPCC_FIXED_CONTROL_OUTPUT_DIR",
        "MPCC_FIXED_CONTROL_SOLVE_HOURS",
        "MPCC_FIXED_CONTROL_NFE",
        "MPCC_FIXED_CONTROL_MESH_BREAKPOINTS_HOURS",
        "MPCC_FIXED_CONTROL_MAX_ITER",
        "MPCC_FIXED_CONTROL_DYNAMIC_CONTROL_DECISIONS",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ENABLED",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_MODE",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_SLOT_COUNT",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_SLOT_COUNT",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_INDICES",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_INDICES",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_START_OFFSETS_C",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_START_OFFSETS_G_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_START_OFFSETS_G_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_TRUST_C",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_TRUST_G_L",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_TRUST_G_L",
        "MPCC_DYNAMIC_CONTROL_REFERENCE_REGULARIZATION_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TARGET_STATE",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_REWARD_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_SCALE_G_L",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_SCALE_G_L",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_THERMAL_ENERGY_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_WEIGHT",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_POLICY",
        "collocation_grid",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SCORE",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD",
        "MPCC_FIXED_CONTROL_LINEAR_SOLVER",
        "ma86",
        "scripts/main_reduced_mpcc_fixed_control_policy_solve_attempt.jl",
        "reduced_mpcc_dynamic_control_decision_spec.csv",
        "dynamic_control_reference_regularization_weight",
        "dynamic_control_objective_mode",
        "dynamic_control_objective_target_state",
        "dynamic_control_objective_terminal_sugar_weight",
        "dynamic_control_objective_terminal_sugar_scale_g_L",
        "dynamic_control_objective_integrated_sugar_weight",
        "dynamic_control_objective_integrated_sugar_scale_g_L",
        "dynamic_control_objective_direct_temperature_reward_weight",
        "dynamic_control_objective_direct_fda_reward_weight",
        "dynamic_control_objective_direct_organic_reward_weight",
        "fully_simultaneous_controls=true",
        "scientific_simulation=false",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "MPCC repair substep analysis contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_REPAIR_SUBSTEP_ANALYSIS_PATH)

    for required_text in (
        "Analyze fixed-control MPCC repair substep traces.",
        "--substeps-csv",
        "{args.prefix}_transitions.csv",
        "dominant_diagnostic_category",
        "state_refresh",
        "flux_bound_projection",
        "rhs_derivative_refresh",
        "Target terminal flux/bound projection",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC dynamic-control objective leverage submit contract" begin
    script_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_OBJECTIVE_LEVERAGE_SUBMIT_PATH,
    )

    for required_text in (
        "default_objective_target_state=\"isoamyl_acetate\"",
        "default_objective_target_state=\"white_wine_aroma_blend\"",
        "DESCRIBE_ONLY=\"\${DESCRIBE_ONLY:-0}\"",
        "[[ \"\$variant_id\" == blend_integrated* ]]",
        "objective_target_state=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_TARGET_STATE:-\$default_objective_target_state}\"",
        "terminal_sugar_weight \\",
        "terminal_sugar_scale_g_L \\",
        "integrated_sugar_weight \\",
        "integrated_sugar_scale_g_L \\",
        "objective_terminal_sugar_weight=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_WEIGHT:-\$terminal_sugar_weight}\"",
        "objective_terminal_sugar_scale_g_L=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_SCALE_G_L:-\$terminal_sugar_scale_g_L}\"",
        "objective_integrated_sugar_weight=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_WEIGHT:-\$integrated_sugar_weight}\"",
        "objective_integrated_sugar_scale_g_L=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_SCALE_G_L:-\$integrated_sugar_scale_g_L}\"",
        "objective_integrated_sugar_policy=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_POLICY:-excess_slack}\"",
        "objective_integrated_sugar_max_g_L=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_MAX_G_L:-5.0}\"",
        "objective_fda_weight=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_FDA_WEIGHT:-1.0}\"",
        "objective_organic_weight=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_ORGANIC_WEIGHT:-1.0}\"",
        "objective_nutrient_scale_g_L=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_SCALE_G_L:-1.0}\"",
        "objective_ambient_temperature_C=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_AMBIENT_TEMPERATURE_C:-20.0}\"",
        "objective_temperature_scale_C=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SCALE_C:-10.0}\"",
        "objective_temperature_smoothness_scale_C=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_SCALE_C:-5.0}\"",
        "objective_direct_temperature_reward_weight=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_TEMPERATURE_REWARD_WEIGHT:-0.0}\"",
        "reference_regularization_weight=\"\${MPCC_DYNAMIC_CONTROL_REFERENCE_REGULARIZATION_WEIGHT:-\$reference_regularization_weight}\"",
        "objective_mode=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE:-aroma_nutrient_energy}\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE=\"\$objective_mode\"",
        "temperature_trust_C=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_TRUST_C:-\$temperature_trust_C}\"",
        "control_liberation_mode=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_MODE:-full}\"",
        "mesh_breakpoints_hours=\"\${MPCC_FIXED_CONTROL_MESH_BREAKPOINTS_HOURS:-}\"",
        "fixed_control_mesh_breakpoints_hours",
        "MPCC_FIXED_CONTROL_MESH_BREAKPOINTS_HOURS=\"\$mesh_breakpoints_hours\"",
        "MPCC_FIXED_CONTROL_IPOPT_PROFILE=\"\${MPCC_FIXED_CONTROL_IPOPT_PROFILE:-feasibility_handoff}\"",
        "control_liberation_temperature_indices=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_INDICES:-}\"",
        "control_liberation_addition_indices=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_INDICES:-}\"",
        "control_liberation_temperature_start_offsets_C=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_START_OFFSETS_C:-}\"",
        "control_liberation_fda_start_offsets_g_L=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_START_OFFSETS_G_L:-}\"",
        "control_liberation_organic_start_offsets_g_L=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_START_OFFSETS_G_L:-}\"",
        "[[ \"\$DESCRIBE_ONLY\" != \"1\" && \"\$variant_id\" == extended_* ]]",
        "extended dynamic-control variants require explicit",
        "MPCC_DYNAMIC_CONTROL_LIBERATED_POLICY_SELECTION_CSV",
        "MPCC_DYNAMIC_CONTROL_LIBERATED_CANDIDATE_ID",
        "legacy 168 h default candidate",
        "post_tail_repair_guard_accept_tol=\"\${MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_GUARD_ACCEPT_TOL:-0.0}\"",
        "post_tail_repair_damping_factors=\"\${MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_DAMPING_FACTORS:-1.0,0.5,0.25,0.1,0.05,0.01}\"",
        "post_tail_repair_refresh_dynamic_flux=\"\${MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_REFRESH_DYNAMIC_FLUX:-1}\"",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TRACE_SUBSTEPS=\"\${MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TRACE_SUBSTEPS:-0}\"",
        "collocation_repair_trace_substeps",
        "collocation_repair_flux_refresh_guard",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD=\"\${MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD:-0}\"",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_SCORE=\"\${MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_SCORE:-candidate_threshold_ratio}\"",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_ACCEPT_TOL=\"\${MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_ACCEPT_TOL:-0.0}\"",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_MODE=\"\$control_liberation_mode\"",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_INDICES=\"\$control_liberation_temperature_indices\"",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_INDICES=\"\$control_liberation_addition_indices\"",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_START_OFFSETS_C=\"\$control_liberation_temperature_start_offsets_C\"",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_START_OFFSETS_G_L=\"\$control_liberation_fda_start_offsets_g_L\"",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_START_OFFSETS_G_L=\"\$control_liberation_organic_start_offsets_g_L\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TARGET_STATE=\"\$objective_target_state\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_WEIGHT=\"\$objective_terminal_sugar_weight\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_SCALE_G_L=\"\$objective_terminal_sugar_scale_g_L\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_WEIGHT=\"\$objective_integrated_sugar_weight\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_SCALE_G_L=\"\$objective_integrated_sugar_scale_g_L\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_POLICY=\"\$objective_integrated_sugar_policy\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_MAX_G_L=\"\$objective_integrated_sugar_max_g_L\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_FDA_WEIGHT=\"\$objective_fda_weight\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_ORGANIC_WEIGHT=\"\$objective_organic_weight\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_SCALE_G_L=\"\$objective_nutrient_scale_g_L\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_AMBIENT_TEMPERATURE_C=\"\$objective_ambient_temperature_C\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SCALE_C=\"\$objective_temperature_scale_C\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_SCALE_C=\"\$objective_temperature_smoothness_scale_C\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_TEMPERATURE_REWARD_WEIGHT=\"\$objective_direct_temperature_reward_weight\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_FDA_REWARD_WEIGHT=\"\$objective_direct_fda_reward_weight\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_ORGANIC_REWARD_WEIGHT=\"\$objective_direct_organic_reward_weight\"",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_GUARD_ACCEPT_TOL=\"\$post_tail_repair_guard_accept_tol\"",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_DAMPING_FACTORS=\"\$post_tail_repair_damping_factors\"",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_REFRESH_DYNAMIC_FLUX=\"\$post_tail_repair_refresh_dynamic_flux\"",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC dynamic-control extended near-dry submit contract" begin
    script_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_EXTENDED_NEARDRY_SUBMIT_PATH,
    )

    for required_text in (
        "Only light CSV preparation and Slurm inspection are performed on the login node.",
        "scripts/main_prepare_dynamic_control_policy_selection.py",
        "MPCC_EXTENDED_NEARDRY_DEVELOPMENT_READY_IGNORE_GATES=1",
        "--development-ready-ignore-gates",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_STOP_ON_SUGAR_DEPLETION=\"\${MPCC_FIXED_CONTROL_SEQUENTIAL_STOP_ON_SUGAR_DEPLETION:-false}\"",
        "MPCC_FIXED_CONTROL_SEQUENTIAL_SUGAR_DEPLETION_TOL=\"\${MPCC_FIXED_CONTROL_SEQUENTIAL_SUGAR_DEPLETION_TOL:-\$sugar_gate_g_L}\"",
        "bash repro/submit_cluster_uc_dynamic_control_objective_leverage.sh \"\$variant_id\"",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC h264 substep trace submit contract" begin
    script_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_H264_SUBSTEP_TRACE_SUBMIT_PATH,
    )

    for required_text in (
        "timeout 20s sinfo",
        "timeout 20s squeue -u \"$USER\"",
        "extended_h264_neardry_gate12_productivity_nfe132_substeps_iter0",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TRACE_SUBSTEPS",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_MODE=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_MODE:-locked}\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE:-off}\"",
        "MPCC_JULIA_COMPILED_MODULES=\"\${MPCC_JULIA_COMPILED_MODULES:-no}\"",
        "main_analyze_mpcc_repair_substeps.py",
        "reduced_mpcc_fixed_control_policy_repair_substeps.csv",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC fixed-control bank submit contract" begin
    script_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_FIXED_BANK_SUBMIT_PATH,
    )

    for required_text in (
        "locked fixed-control MPCC bank",
        "MPCC_FIXED_BANK_POLICY_SELECTION_CSV",
        "flat25__fda_early_3p0_limit",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_MODE=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_MODE:-locked}\"",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE=\"\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE:-off}\"",
        "MPCC_REDUCED_DCDFBA_BASE_OBJECTIVE_MODE=\"\${MPCC_REDUCED_DCDFBA_BASE_OBJECTIVE_MODE:-zero}\"",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD=\"\${MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD:-1}\"",
        "OPENBLAS_NUM_THREADS",
        "sbatch \"\${sbatch_args[@]}\" \"\$SBATCH_TEMPLATE\"",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC dynamic-control relaxed funnel submit contract" begin
    script_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_RELAXED_FUNNEL_SUBMIT_PATH,
    )

    for required_text in (
        "broad-start relaxed dynamic-control MPCC funnel",
        "cross-horizon-audit",
        "same-grid-stateflux",
        "MPCC_FIXED_CONTROL_FLUX_DUAL_START_MODE=none",
        "MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=0",
        "MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START=1",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ENABLED=1",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_STATE=\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_STATE:-protein}",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_SCALE_G_L=\${MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_SCALE_G_L:-1e-6}",
        "MPCC_DYNAMIC_FLUX_LP_RELAXED_FALLBACK=\${MPCC_DYNAMIC_FLUX_LP_RELAXED_FALLBACK:-1}",
        "MPCC_FIXED_CONTROL_IPOPT_PROFILE=\${MPCC_FIXED_CONTROL_IPOPT_PROFILE:-strict}",
        "--pre-solve-only",
        "MPCC_FIXED_CONTROL_PRE_SOLVE_ONLY=\$PRE_SOLVE_ONLY",
        "timeout 20s sinfo",
        "timeout 20s squeue -u \"\$USER\"",
        "bash \"\$STAGED_SUBMITTER\" \"\${staged_args[@]}\"",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC next h168 direct temperature submit contract" begin
    script_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_NEXT_H168_DIRECT_TEMPERATURE_PATH,
    )

    for required_text in (
        "job 741785",
        "flat25",
        "OPENBLAS_NUM_THREADS",
        "SLURM_MEM",
        "submit_cluster_uc_dynamic_control_direct_diagnostic.sh temperature",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC next h168 direct FDA submit contract" begin
    script_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_NEXT_H168_DIRECT_FDA_PATH,
    )

    for required_text in (
        "job 741785",
        "flat25",
        "OPENBLAS_NUM_THREADS",
        "SLURM_MEM",
        "submit_cluster_uc_dynamic_control_direct_diagnostic.sh fda",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC dynamic-control sequential atlas contracts" begin
    sbatch_text =
        _script_entrypoint_text(SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_SEQUENTIAL_ATLAS_PATH)
    submit_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_SEQUENTIAL_ATLAS_SUBMIT_PATH,
    )
    extended_script_text =
        _script_entrypoint_text(SCRIPT_ENTRYPOINT_DYNAMIC_CONTROL_SEQUENTIAL_EXTENDED_ATLAS_PATH)

    for required_text in (
        "#SBATCH --ntasks=1",
        "#SBATCH --cpus-per-task=4",
        "OPENBLAS_NUM_THREADS",
        "DFBA_DYNAMIC_CONTROL_OPT_OUTPUT_DIR",
        "DFBA_DYNAMIC_CONTROL_OPT_CANDIDATE_SET",
        "DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_MODE",
        "DFBA_DYNAMIC_CONTROL_ATLAS_SCRIPT",
        "DFBA_DYNAMIC_CONTROL_OPT_TERMINAL_SUGAR_FEASIBILITY_MODE",
        "DFBA_DYNAMIC_CONTROL_OPT_MAX_WALLTIME_SECONDS",
        "DFBA_DYNAMIC_CONTROL_OPT_PROGRESS_INTERVAL_SECONDS",
        "DFBA_DYNAMIC_CONTROL_OPT_WRITE_PARTIAL_CSV",
        "scripts/main_dynamic_control_sequential_atlas.jl",
    )
        @test occursin(required_text, sbatch_text)
    end
    @test !occursin("MPCC_IPOPT_HSLLIB", sbatch_text)
    @test !occursin("Ipopt", sbatch_text)

    for required_text in (
        "sinfo",
        "squeue -u \"\$USER\"",
        "sbatch",
        "--ntasks=1",
        "--cpus-per-task=\"\${SLURM_CPUS_PER_TASK:-4}\"",
        "DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_MODE=\"\${DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_MODE:-off}\"",
        "DFBA_DYNAMIC_CONTROL_EXTENDED_ATLAS_DEPENDENCY",
        "--dependency=\"\$DFBA_DYNAMIC_CONTROL_EXTENDED_ATLAS_DEPENDENCY\"",
        "scripts/main_dynamic_control_sequential_extended_atlas.jl",
    )
        @test occursin(required_text, submit_text)
    end
    @test !occursin("julia --project", submit_text)

    for required_text in (
        "DFBA_DYNAMIC_CONTROL_OPT_HORIZON_HOURS",
        "\"240\"",
        "DFBA_DYNAMIC_CONTROL_OPT_CANDIDATE_SET",
        "\"horizon_frontier\"",
        "DFBA_DYNAMIC_CONTROL_OPT_MAX_CANDIDATES",
        "\"12\"",
        "DFBA_DYNAMIC_CONTROL_OPT_TERMINAL_SUGAR_FEASIBILITY_MODE",
        "\"numeric_health\"",
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_FINAL_SUGAR_MAX_G_L",
        "\"Inf\"",
        "DFBA_DYNAMIC_CONTROL_OPT_STOP_ON_SUGAR_DEPLETION",
        "\"false\"",
        "main_dynamic_control_objective_smoke.jl",
    )
        @test occursin(required_text, extended_script_text)
    end
end

@testset "Cluster UC dynamic-control direct diagnostic submit contract" begin
    script_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_DIRECT_DIAGNOSTIC_SUBMIT_PATH,
    )

    for required_text in (
        "temperature|fda|organic",
        "MPCC_REDUCED_DCDFBA_BASE_OBJECTIVE_MODE",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_TEMPERATURE_REWARD_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_FDA_REWARD_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_DIRECT_ORGANIC_REWARD_WEIGHT",
        "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_EXCESS_WEIGHT",
        "flat25__fda_early_3p0_limit",
        "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=\"\${MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER:-8}\"",
        "MPCC_DYNAMIC_CONTROL_LIBERATION_MODE=\"\${MPCC_DYNAMIC_CONTROL_LIBERATION_MODE:-explicit}\"",
        "h168_repair8_direct_\${diagnostic}_control_diagnostic",
        "submit_cluster_uc_dynamic_control_objective_leverage.sh",
    )
        @test occursin(required_text, script_text)
    end
end

@testset "Cluster UC dynamic-control objective leverage variant table contract" begin
    table_text = _script_entrypoint_text(
        SCRIPT_ENTRYPOINT_CLUSTER_DYNAMIC_CONTROL_OBJECTIVE_LEVERAGE_VARIANTS_PATH,
    )
    lines = split(strip(table_text), '\n')
    header = split(first(lines), '\t')
    @test header == [
        "variant_id",
        "terminal_reward_weight",
        "terminal_state_scale_g_L",
        "terminal_sugar_weight",
        "terminal_sugar_scale_g_L",
        "integrated_sugar_weight",
        "integrated_sugar_scale_g_L",
        "nutrient_weight",
        "thermal_energy_weight",
        "temperature_smoothness_weight",
        "reference_regularization_weight",
        "temperature_trust_C",
        "fda_trust_g_L",
        "organic_trust_g_L",
        "max_iter",
        "note",
    ]
    for line in lines[2:end]
        @test length(split(line, '\t')) == length(header)
    end
    @test occursin("reward1_scale1mg_sugar0p5_reg0p02_iter13", table_text)
    @test occursin("reward1_scale1mg_sugar1_reg0p02_iter13", table_text)
    @test occursin("reward1_scale1mg_integratedsugar100_reg0p02_iter13", table_text)
    @test occursin("reward1_scale1mg_integratedsugar100_reg0_softcost_iter13", table_text)
end

@testset "Reduced MPCC horizon/nfe sweep script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_SWEEP_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_SWEEP_PROFILE",
        "MPCC_SWEEP_HORIZONS_HOURS",
        "MPCC_SWEEP_NFE_VALUES",
        "MPCC_SWEEP_MAX_SCENARIOS",
        "MPCC_SWEEP_ALLOW_LARGE_GRID",
        "MPCC_SWEEP_CONTINUE_ON_ERROR",
        "MPCC_SWEEP_REQUIRE_PREFLIGHT",
        "MPCC_SWEEP_SILENT",
        "MPCC_SWEEP_IPOPT_MAX_ITER",
        "sweep_reduced_dcdfba_mpcc_solve_attempts",
        "degree = 3",
        "outputs_written",
        "sweep_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "best_state_match_scenario_id",
        "scenario_table",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC Ipopt iteration sensitivity script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_ITER_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_ITER_PROFILE",
        "MPCC_ITER_HORIZONS_HOURS",
        "MPCC_ITER_NFE_VALUES",
        "MPCC_ITER_MAX_ITER_VALUES",
        "MPCC_ITER_MAX_SOLVES",
        "MPCC_ITER_ALLOW_LARGE_GRID",
        "MPCC_ITER_CONTINUE_ON_ERROR",
        "MPCC_ITER_REQUIRE_PREFLIGHT",
        "MPCC_ITER_SILENT",
        "sweep_reduced_dcdfba_mpcc_ipopt_iterations",
        "degree = 3",
        "outputs_written",
        "sensitivity_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "first_trajectory_ready_ipopt_max_iter_by_scenario",
        "sensitivity_table",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC mesh refinement sensitivity script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_MESH_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_MESH_PROFILE",
        "MPCC_MESH_HORIZONS_HOURS",
        "MPCC_MESH_NFE_VALUES",
        "MPCC_MESH_MAX_SCENARIOS",
        "MPCC_MESH_ALLOW_LARGE_GRID",
        "MPCC_MESH_CONTINUE_ON_ERROR",
        "MPCC_MESH_REQUIRE_PREFLIGHT",
        "MPCC_MESH_SILENT",
        "MPCC_MESH_IPOPT_MAX_ITER",
        "sweep_reduced_dcdfba_mpcc_mesh_refinement",
        "degree = 3",
        "outputs_written",
        "mesh_sensitivity_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "first_trajectory_ready_nfe_by_horizon",
        "best_state_match_nfe_by_horizon",
        "mesh_table",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC windowed continuation script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOW_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_WINDOW_PROFILE",
        "MPCC_WINDOW_HOURS",
        "MPCC_WINDOW_COUNT",
        "MPCC_WINDOW_NFE",
        "MPCC_WINDOW_MAX_WINDOWS",
        "MPCC_WINDOW_ALLOW_LONG",
        "MPCC_WINDOW_CONTINUE_ON_ERROR",
        "MPCC_WINDOW_REQUIRE_PREFLIGHT",
        "MPCC_WINDOW_SILENT",
        "MPCC_WINDOW_COARSE_MODE",
        "MPCC_WINDOW_COARSE_ACCEPT_BEST_STAGE",
        "MPCC_WINDOW_WRITE_OUTPUTS",
        "MPCC_WINDOW_OUTPUT_DIR",
        "MPCC_WINDOW_OUTPUT_OVERWRITE",
        "MPCC_WINDOW_IPOPT_MAX_ITER",
        "MPCC_IPOPT_LINEAR_SOLVER",
        "ipopt_warm_start_init_point",
        "ipopt_max_wall_time_seconds",
        "MPCC_WINDOW_USE_TAU_CONTINUATION",
        "MPCC_WINDOW_PROPAGATE_FLUX_DUAL_STARTS",
        "MPCC_WINDOW_INITIAL_STATE_PROPAGATION",
        "MPCC_RESIDUAL_MAX_RHS",
        "MPCC_RESIDUAL_MAX_MASS",
        "MPCC_RESIDUAL_MAX_BOUND",
        "MPCC_RESIDUAL_MAX_LOWER_BOUND",
        "MPCC_RESIDUAL_MAX_UPPER_BOUND",
        "MPCC_RESIDUAL_MAX_STATIONARITY",
        "MPCC_RESIDUAL_MAX_COMPLEMENTARITY",
        "MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY",
        "MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY",
        "default_reduced_dcdfba_mpcc_residual_thresholds",
        "reduced_mpcc_complementarity_mode_from_env",
        "reduced_mpcc_tau_schedule_from_env",
        "reduced_mpcc_tau_stage_max_iters_from_env",
        "tau_stage_max_iters",
        "MPCC_TAU_STAGE_MAX_ITERS",
        "MPCC_TAU_FINAL_RETRY_MAX_ITER",
        "MPCC_WINDOW_CONTINUATION_POLICY",
        "MPCC_WINDOW_STATE_ABS_DIFF_THRESHOLD",
        "MPCC_WINDOW_STATE_REL_RMSE_THRESHOLD",
        "DFBA_PHASE_PROXY_MODE",
        "DFBA_TURNOVER_THRESHOLD",
        "initial_state_config = _script_initial_state_config(params)",
        "y0 = initial_state_config.y0",
        "params = params",
        "phase_proxy_mode",
        "turnover_threshold",
        "initial_total_sugar_g_L",
        "initial_total_yan_equivalent_mgN_L",
        "run_reduced_dcdfba_mpcc_windowed_continuation",
        "write_reduced_dcdfba_mpcc_windowed_report",
        "profile == \"2h4nfe\"",
        "window_hours = \"2.0\"",
        "nfe_per_window = 4",
        "linear_solver = linear_solver",
        "residual_thresholds = residual_thresholds",
        "coarse_mode",
        "allow_coarse_tau_fallback",
        "tau_schedule = tau_schedule",
        "tau_stage_max_iters = tau_stage_max_iters",
        "allow_coarse_tau_fallback = allow_coarse_tau_fallback",
        "propagate_flux_dual_starts = propagate_flux_dual_starts",
        "initial_state_propagation_policy",
        "continuation_acceptance_policy",
        "continuation_state_relative_rmse_threshold",
        "degree = 3",
        "outputs_written",
        "output_dir",
        "diagnostic_output_dir",
        "plot_output_dir",
        "output_paths",
        "windowed_continuation_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "continuation_completed",
        "first_failed_window_id",
        "metadata_continuation_acceptance_policy",
        "continuation_state_drift_gate_enabled",
        "continuation_policy_rejected_window_count",
        "iteration_limit_policy_accepted_window_count",
        "cross_window_flux_dual_start_enabled",
        "cross_window_flux_dual_start_applied_window_count",
        "tau_continuation_polish_failed_window_count",
        "tau_continuation_final_retry_window_count",
        "tau_continuation_coarse_tau_fallback_window_count",
        "tau_final_retry_max_iter",
        "residual_max_mass",
        "initial_state_propagation_policy",
        "residual_max_lower_complementarity",
        "residual_max_upper_complementarity",
        "accepted_tau",
        "attempted_final_tau",
        "coarse_fallback",
        "residual_source",
        "polish_failed",
        "final_retry",
        "final_retry_count",
        "blocking_stage",
        "blocking_reason",
        "solver_call",
        "pre_guard",
        "pre_guard_pass",
        "pre_guard_component",
        "pre_residuals_ok",
        "pre_scaling_ok",
        "pre_blocking_warnings",
        "pre_review_warnings",
        "pre_first_warning",
        "guard_blocked",
        "dominant_residual",
        "drift_blocks",
        "max_bound_l",
        "max_bound_u",
        "max_stationarity",
        "state_seed",
        "next_y0",
        "global_state_metrics_available",
        "window_table",
        "continuation_acceptance_reason",
        "iteration_limit_policy_accepted",
        "error_type",
        "error_message",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "Reduced MPCC windowed refinement diagnostics script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_REFINEMENT_PATH)

    for required_text in (
        "MPCC_WINDOW_ARTIFACT_DIR",
        "MPCC_REFINEMENT_OUTPUT_DIR",
        "MPCC_REFINEMENT_OUTPUT_OVERWRITE",
        "MPCC_REFINEMENT_TOP_N",
        "MPCC_REFINEMENT_BOUNDARY_REL_JUMP",
        "MPCC_REFINEMENT_WINDOW_REL_RMSE",
        "MPCC_REFINEMENT_WINDOW_ABS_DIFF",
        "diagnose_reduced_dcdfba_mpcc_windowed_refinement_artifacts",
        "window_refinement_candidates",
        "state_window_errors",
        "boundary_jumps",
        "window_refinement_score_plot",
        "top_refinement_windows",
        "mpcc_rerun_performed",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "Reduced MPCC windowed selective refinement script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_SELECTIVE_REFINEMENT_PATH)

    for required_text in (
        "MPCC_SELECTIVE_REFINEMENT_ARTIFACT_DIR",
        "MPCC_SELECTIVE_REFINEMENT_DIAGNOSTIC_DIR",
        "MPCC_SELECTIVE_REFINEMENT_OUTPUT_DIR",
        "MPCC_SELECTIVE_REFINEMENT_OUTPUT_OVERWRITE",
        "MPCC_SELECTIVE_REFINEMENT_TOP_N",
        "MPCC_SELECTIVE_REFINEMENT_WINDOW_IDS",
        "MPCC_SELECTIVE_REFINEMENT_ONLY_COARSE",
        "MPCC_SELECTIVE_REFINEMENT_MIN_PRIORITY",
        "MPCC_SELECTIVE_REFINEMENT_IPOPT_MAX_ITER",
        "MPCC_SELECTIVE_REFINEMENT_ALLOW_COARSE_FALLBACK",
        "MPCC_SELECTIVE_REFINEMENT_REQUIRE_PREFLIGHT",
        "MPCC_SELECTIVE_REFINEMENT_CONTINUE_ON_ERROR",
        "MPCC_SELECTIVE_REFINEMENT_SILENT",
        "MPCC_RESIDUAL_MAX_RHS",
        "MPCC_RESIDUAL_MAX_MASS",
        "MPCC_RESIDUAL_MAX_BOUND",
        "MPCC_RESIDUAL_MAX_LOWER_BOUND",
        "MPCC_RESIDUAL_MAX_UPPER_BOUND",
        "MPCC_RESIDUAL_MAX_STATIONARITY",
        "MPCC_RESIDUAL_MAX_COMPLEMENTARITY",
        "MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY",
        "MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY",
        "default_reduced_dcdfba_mpcc_residual_thresholds",
        "run_reduced_dcdfba_mpcc_windowed_selective_refinement_artifacts",
        "export_reduced_dcdfba_mpcc_windowed_selective_refinement",
        "residual_thresholds = residual_thresholds",
        "selective_refinement_progress",
        "selective_refinement_tau",
        "before_after_table",
        "refined_aligned_timeseries",
        "outputs_written",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "Reduced MPCC windowed selective replacement script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_SELECTIVE_REPLACEMENT_PATH)

    for required_text in (
        "MPCC_REPLACEMENT_ARTIFACT_DIR",
        "MPCC_REPLACEMENT_SELECTIVE_DIRS",
        "MPCC_REPLACEMENT_OUTPUT_DIR",
        "MPCC_REPLACEMENT_OUTPUT_OVERWRITE",
        "MPCC_REPLACEMENT_POLICY",
        "MPCC_REPLACEMENT_INCLUDE_LEFT_BOUNDARY",
        "apply_reduced_dcdfba_mpcc_windowed_selective_replacement_artifacts",
        "write_reduced_dcdfba_mpcc_windowed_selective_replacement_report",
        "replacement_table",
        "plot_core_states",
        "outputs_written",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_reduced_model", script_text)
    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "Reduced MPCC simulation viability script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_VIABILITY_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_VIABILITY_SOURCE",
        "MPCC_VIABILITY_IPOPT_MAX_ITER",
        "MPCC_VIABILITY_REQUIRE_PREFLIGHT",
        "MPCC_VIABILITY_CONTINUE_ON_ERROR",
        "MPCC_VIABILITY_HORIZON_HOURS",
        "MPCC_VIABILITY_NFE",
        "MPCC_VIABILITY_MESH_NFE_VALUES",
        "MPCC_VIABILITY_WINDOW_HOURS",
        "MPCC_VIABILITY_WINDOW_COUNT",
        "MPCC_VIABILITY_WINDOW_NFE",
        "MPCC_VIABILITY_MAX_WINDOWS",
        "MPCC_VIABILITY_ALLOW_LONG",
        "sweep_reduced_dcdfba_mpcc_solve_attempts",
        "sweep_reduced_dcdfba_mpcc_mesh_refinement",
        "run_reduced_dcdfba_mpcc_windowed_continuation",
        "assess_reduced_dcdfba_mpcc_simulation_viability",
        "overall_traffic_light",
        "overall_simulation_viable",
        "simulation_viable_candidate_count",
        "recommended_next_action",
        "viability_table",
        "outputs_written",
        "viability_report_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC simulation viability frontier script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_FRONTIER_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_FRONTIER_PROFILE",
        "MPCC_FRONTIER_HORIZONS_HOURS",
        "MPCC_FRONTIER_BOUNDARY_DT_HOURS",
        "MPCC_FRONTIER_NFE_VALUES",
        "MPCC_FRONTIER_MAX_CASES",
        "MPCC_FRONTIER_ALLOW_LARGE",
        "MPCC_FRONTIER_STOP_AFTER_FIRST_NON_GREEN",
        "MPCC_FRONTIER_CONTINUE_ON_ERROR",
        "MPCC_FRONTIER_REQUIRE_PREFLIGHT",
        "MPCC_FRONTIER_SILENT",
        "MPCC_FRONTIER_IPOPT_MAX_ITER",
        "sweep_reduced_dcdfba_mpcc_simulation_viability_frontier",
        "degree = 3",
        "outputs_written",
        "frontier_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "frontier_reached_green",
        "frontier_blocked",
        "last_green_case_id",
        "first_non_green_case_id",
        "frontier_table",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC windowed 72h attempt script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_ATTEMPT_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_WINDOWED_ATTEMPT_PROFILE",
        "MPCC_WINDOWED_ATTEMPT_TARGET_HOURS",
        "MPCC_WINDOWED_ATTEMPT_WINDOW_HOURS",
        "MPCC_WINDOWED_ATTEMPT_NFE",
        "MPCC_WINDOWED_ATTEMPT_MAX_WINDOWS",
        "MPCC_WINDOWED_ATTEMPT_ALLOW_LONG",
        "MPCC_WINDOWED_ATTEMPT_CONTINUE_ON_ERROR",
        "MPCC_WINDOWED_ATTEMPT_REQUIRE_PREFLIGHT",
        "MPCC_WINDOWED_ATTEMPT_SILENT",
        "MPCC_WINDOWED_ATTEMPT_PROGRESS",
        "MPCC_WINDOWED_ATTEMPT_RETRY_ON_FAILURE",
        "MPCC_WINDOWED_ATTEMPT_RETRY_MAX_ITERS",
        "MPCC_WINDOWED_ATTEMPT_IPOPT_MAX_ITER",
        "MPCC_IPOPT_LINEAR_SOLVER",
        "MPCC_WINDOWED_ATTEMPT_USE_TAU_CONTINUATION",
        "MPCC_WINDOWED_ATTEMPT_CONTINUATION_POLICY",
        "MPCC_WINDOWED_ATTEMPT_STATE_REL_RMSE_THRESHOLD",
        "attempt_reduced_dcdfba_mpcc_windowed_simulation",
        "continuation_acceptance_policy",
        "continuation_state_relative_rmse_threshold",
        "diagnose_reduced_dcdfba_mpcc_windowed_failure",
        "diagnose_reduced_dcdfba_mpcc_window_retry",
        "window_callback",
        "profile == \"72h\"",
        "profile == \"2h4nfe\"",
        "target_horizon = \"72.0\"",
        "window_hours = \"2.0\"",
        "nfe_per_window = 4",
        "max_windows = 36",
        "window_hours = \"0.5\"",
        "nfe_per_window = 2",
        "max_windows = 144",
        "linear_solver = linear_solver",
        "tau_schedule = tau_schedule",
        "degree = 3",
        "outputs_written",
        "attempt_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "target_completed",
        "attempt_traffic_light",
        "horizon_reached",
        "horizon_gap",
        "metadata_continuation_acceptance_policy",
        "continuation_state_drift_gate_enabled",
        "continuation_policy_rejected_window_count",
        "iteration_limit_policy_accepted_window_count",
        "first_non_green_window_id",
        "failure_diagnostic_type",
        "failure_dominant_residual_name",
        "failure_dominant_mass_balance_metabolite_id",
        "retry_on_failure",
        "retry_diagnostic_type",
        "retry_table",
        "failure_window_summary",
        "top_mass_balance_rows",
        "attempt_table",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC windowed 72h simulation runner script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_72H_RUNNER_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_WINDOWED_72H_RUNNER_PROFILE",
        "MPCC_WINDOWED_72H_RUNNER_TARGET_HOURS",
        "MPCC_WINDOWED_72H_RUNNER_WINDOW_HOURS",
        "MPCC_WINDOWED_72H_RUNNER_NFE",
        "MPCC_WINDOWED_72H_RUNNER_MAX_WINDOWS",
        "MPCC_WINDOWED_72H_RUNNER_ALLOW_LONG",
        "MPCC_WINDOWED_72H_RUNNER_CONTINUE_ON_ERROR",
        "MPCC_WINDOWED_72H_RUNNER_REQUIRE_PREFLIGHT",
        "MPCC_WINDOWED_72H_RUNNER_SILENT",
        "MPCC_WINDOWED_72H_RUNNER_PROGRESS",
        "MPCC_WINDOWED_72H_RUNNER_IPOPT_MAX_ITER",
        "MPCC_IPOPT_LINEAR_SOLVER",
        "MPCC_WINDOWED_72H_RUNNER_USE_TAU_CONTINUATION",
        "MPCC_WINDOWED_72H_RUNNER_CONTINUATION_POLICY",
        "MPCC_WINDOWED_72H_RUNNER_STATE_REL_RMSE_THRESHOLD",
        "MPCC_REDUCED_MPCC_IPOPT_PROFILE",
        "reduced_mpcc_ipopt_profile_name_from_env",
        "run_reduced_dcdfba_mpcc_windowed_72h_simulation",
        "continuation_acceptance_policy",
        "continuation_state_relative_rmse_threshold",
        "window_callback",
        "profile == \"72h\"",
        "profile == \"2h4nfe\"",
        "target_horizon = \"72.0\"",
        "window_hours = \"2.0\"",
        "nfe_per_window = 4",
        "max_windows = 36",
        "window_hours = \"0.5\"",
        "nfe_per_window = 2",
        "max_windows = 144",
        "linear_solver = linear_solver",
        "tau_schedule = tau_schedule",
        "degree = 3",
        "outputs_written",
        "runner_is_scientific_simulation",
        "runner_is_validated_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "global_monolithic_mpcc_solve_attempted",
        "global_polish_deferred",
        "target_is_72h",
        "target_completed",
        "runner_traffic_light",
        "runner_status",
        "candidate_ready_for_review",
        "horizon_reached",
        "horizon_gap",
        "metadata_continuation_acceptance_policy",
        "continuation_state_drift_gate_enabled",
        "first_non_green_window_id",
        "runner_table",
        "window_table",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC windowed tolerance sensitivity script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_TOLERANCE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_WINDOWED_TOL_PROFILE",
        "MPCC_WINDOWED_TOL_TARGET_HOURS",
        "MPCC_WINDOWED_TOL_WINDOW_HOURS",
        "MPCC_WINDOWED_TOL_NFE",
        "MPCC_WINDOWED_TOL_MAX_WINDOWS",
        "MPCC_WINDOWED_TOL_ALLOW_LONG",
        "MPCC_WINDOWED_TOL_MASS_THRESHOLDS",
        "MPCC_WINDOWED_TOL_MAX_CASES",
        "MPCC_WINDOWED_TOL_ALLOW_LARGE",
        "MPCC_WINDOWED_TOL_CONTINUE_ON_ERROR",
        "MPCC_WINDOWED_TOL_REQUIRE_PREFLIGHT",
        "MPCC_WINDOWED_TOL_SILENT",
        "MPCC_WINDOWED_TOL_PROGRESS",
        "MPCC_WINDOWED_TOL_IPOPT_MAX_ITER",
        "sweep_reduced_dcdfba_mpcc_windowed_tolerances",
        "profile == \"72h\"",
        "target_horizon = \"72.0\"",
        "window_hours = \"0.5\"",
        "nfe_per_window = 2",
        "max_windows = 144",
        "mass_thresholds = \"1e-6,2e-6,5e-6,1e-5\"",
        "outputs_written",
        "sensitivity_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "best_mass_threshold",
        "first_horizon_extension_threshold",
        "target_recovered_by_relaxation",
        "tolerance_sensitivity_table",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC windowed drift diagnostics script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_DRIFT_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_WINDOWED_DRIFT_PROFILE",
        "MPCC_WINDOWED_DRIFT_TARGET_HOURS",
        "MPCC_WINDOWED_DRIFT_WINDOW_HOURS",
        "MPCC_WINDOWED_DRIFT_NFE",
        "MPCC_WINDOWED_DRIFT_MAX_WINDOWS",
        "MPCC_WINDOWED_DRIFT_ALLOW_LONG",
        "MPCC_WINDOWED_DRIFT_MASS_THRESHOLD",
        "MPCC_WINDOWED_DRIFT_CONTINUE_ON_ERROR",
        "MPCC_WINDOWED_DRIFT_REQUIRE_PREFLIGHT",
        "MPCC_WINDOWED_DRIFT_SILENT",
        "MPCC_WINDOWED_DRIFT_PROGRESS",
        "MPCC_WINDOWED_DRIFT_IPOPT_MAX_ITER",
        "MPCC_WINDOWED_DRIFT_USE_TAU_CONTINUATION",
        "MPCC_WINDOWED_DRIFT_CONTINUATION_POLICY",
        "MPCC_WINDOWED_DRIFT_STATE_ABS_DIFF_THRESHOLD",
        "MPCC_WINDOWED_DRIFT_STATE_REL_RMSE_THRESHOLD",
        "MPCC_IPOPT_LINEAR_SOLVER",
        "reduced_mpcc_tau_schedule_from_env",
        "diagnose_reduced_dcdfba_mpcc_windowed_drift",
        "profile == \"2h4nfe\"",
        "window_hours = \"2.0\"",
        "nfe_per_window = 4",
        "profile == \"8h\"",
        "target_horizon = \"8.0\"",
        "target_horizon = \"72.0\"",
        "window_hours = \"0.5\"",
        "nfe_per_window = 2",
        "max_windows = 144",
        "mass_threshold = \"5e-6\"",
        "outputs_written",
        "drift_diagnostic_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "window_drift_table",
        "top_global_state_drift",
        "top_timepoint_drift",
        "dominant_global_relative_state",
        "first_state_drift_window_id",
        "recommended_next_action",
        "tau_schedule = tau_schedule",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC windowed retry policy diagnostics script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_RETRY_POLICY_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_WINDOWED_RETRY_PROFILE",
        "MPCC_WINDOWED_RETRY_TARGET_HOURS",
        "MPCC_WINDOWED_RETRY_WINDOW_HOURS",
        "MPCC_WINDOWED_RETRY_NFE",
        "MPCC_WINDOWED_RETRY_MAX_WINDOWS",
        "MPCC_WINDOWED_RETRY_ALLOW_LONG",
        "MPCC_WINDOWED_RETRY_MASS_THRESHOLD",
        "MPCC_WINDOWED_RETRY_MAX_RETRY_WINDOWS",
        "MPCC_WINDOWED_RETRY_MAX_ITERS",
        "MPCC_WINDOWED_RETRY_SELECTION_POLICY",
        "MPCC_WINDOWED_RETRY_CONTINUE_ON_ERROR",
        "MPCC_WINDOWED_RETRY_REQUIRE_PREFLIGHT",
        "MPCC_WINDOWED_RETRY_SILENT",
        "MPCC_WINDOWED_RETRY_PROGRESS",
        "MPCC_WINDOWED_RETRY_IPOPT_MAX_ITER",
        "attempt_reduced_dcdfba_mpcc_windowed_simulation",
        "diagnose_reduced_dcdfba_mpcc_windowed_retry_policy",
        "profile == \"8h\"",
        "target_horizon = \"8.0\"",
        "target_horizon = \"72.0\"",
        "window_hours = \"0.5\"",
        "nfe_per_window = 2",
        "max_windows = 144",
        "mass_threshold = \"5e-6\"",
        "retry_max_iters = \"200,300\"",
        "outputs_written",
        "retry_policy_diagnostic_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "retry_policy_table",
        "selected_window_indices",
        "green_recovered_count",
        "trajectory_ready_recovered_count",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC retry-aware windowed attempt script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_RETRY_AWARE_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_WINDOWED_RETRY_AWARE_PROFILE",
        "MPCC_WINDOWED_RETRY_AWARE_TARGET_HOURS",
        "MPCC_WINDOWED_RETRY_AWARE_WINDOW_HOURS",
        "MPCC_WINDOWED_RETRY_AWARE_NFE",
        "MPCC_WINDOWED_RETRY_AWARE_MAX_WINDOWS",
        "MPCC_WINDOWED_RETRY_AWARE_ALLOW_LONG",
        "MPCC_WINDOWED_RETRY_AWARE_MASS_THRESHOLD",
        "MPCC_WINDOWED_RETRY_AWARE_MAX_RETRY_WINDOWS",
        "MPCC_WINDOWED_RETRY_AWARE_MAX_ITERS",
        "MPCC_WINDOWED_RETRY_AWARE_SELECTION_POLICY",
        "MPCC_WINDOWED_RETRY_AWARE_APPLY_REPLACEMENTS",
        "MPCC_WINDOWED_RETRY_AWARE_REPLACEMENT_POLICY",
        "MPCC_WINDOWED_RETRY_AWARE_TERMINAL_ONLY",
        "MPCC_WINDOWED_RETRY_AWARE_CASCADE_REBUILD",
        "MPCC_WINDOWED_RETRY_AWARE_CONTINUE_ON_ERROR",
        "MPCC_WINDOWED_RETRY_AWARE_REQUIRE_PREFLIGHT",
        "MPCC_WINDOWED_RETRY_AWARE_SILENT",
        "MPCC_WINDOWED_RETRY_AWARE_PROGRESS",
        "MPCC_WINDOWED_RETRY_AWARE_IPOPT_MAX_ITER",
        "attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries",
        "apply_reduced_dcdfba_mpcc_window_retry_replacements",
        "cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements",
        "profile == \"8h\"",
        "target_horizon = \"8.0\"",
        "target_horizon = \"72.0\"",
        "window_hours = \"0.5\"",
        "nfe_per_window = 2",
        "max_windows = 144",
        "mass_threshold = \"5e-6\"",
        "retry_max_iters = \"200,300\"",
        "outputs_written",
        "retry_aware_attempt_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "retry_aware_traffic_light",
        "retry_replacement_recommended",
        "retry_replacement_applied",
        "windowed_candidate_rebuilt",
        "replacement_type",
        "replacement_table",
        "cascade_rebuild_type",
        "cascade_table",
        "rebuilt_attempt_traffic_light",
        "summary_table",
        "retry_policy_table",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC cascade retry horizon smoke script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_CASCADE_RETRY_HORIZON_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_CASCADE_RETRY_HORIZON_PROFILE",
        "MPCC_CASCADE_RETRY_HORIZON_TARGET_HOURS",
        "MPCC_CASCADE_RETRY_HORIZON_WINDOW_HOURS",
        "MPCC_CASCADE_RETRY_HORIZON_NFE",
        "MPCC_CASCADE_RETRY_HORIZON_MAX_CASES",
        "MPCC_CASCADE_RETRY_HORIZON_MAX_WINDOWS",
        "MPCC_CASCADE_RETRY_HORIZON_ALLOW_LARGE",
        "MPCC_CASCADE_RETRY_HORIZON_ALLOW_LONG",
        "MPCC_CASCADE_RETRY_HORIZON_MAX_RETRY_WINDOWS",
        "MPCC_CASCADE_RETRY_HORIZON_MAX_ITERS",
        "MPCC_CASCADE_RETRY_HORIZON_CASCADE_MAX_ITER",
        "MPCC_CASCADE_RETRY_HORIZON_MASS_THRESHOLD",
        "MPCC_CASCADE_RETRY_HORIZON_SOURCE_MAX_ITER",
        "MPCC_CASCADE_RETRY_HORIZON_SELECTION_POLICY",
        "MPCC_CASCADE_RETRY_HORIZON_REPLACEMENT_POLICY",
        "MPCC_CASCADE_RETRY_HORIZON_CONTINUE_ON_ERROR",
        "MPCC_CASCADE_RETRY_HORIZON_REQUIRE_PREFLIGHT",
        "MPCC_CASCADE_RETRY_HORIZON_SILENT",
        "MPCC_CASCADE_RETRY_HORIZON_PROGRESS",
        "MPCC_CASCADE_RETRY_HORIZON_STOP_AFTER_FIRST_NON_GREEN",
        "smoke_reduced_dcdfba_mpcc_cascade_retry_horizons",
        "profile == \"focused\"",
        "profile == \"72h\"",
        "target_horizons = \"1.0,1.5\"",
        "target_horizons = \"1.0,2.0,4.0,8.0,16.0,32.0,72.0\"",
        "window_hours = \"0.5\"",
        "nfe = 2",
        "mass_threshold = \"5e-6\"",
        "retry_max_iters = \"200,300,500\"",
        "outputs_written",
        "smoke_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "cascade_rebuild_applied_count",
        "retry_replacement_applied_count",
        "nonterminal_replacement_count",
        "downstream_resolve_case_count",
        "max_rebuilt_horizon_reached",
        "first_nonterminal_cascade_case_id",
        "cascade_horizon_table",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC global polish smoke script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_GLOBAL_POLISH_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_GLOBAL_POLISH_PROFILE",
        "MPCC_GLOBAL_POLISH_SOURCE",
        "MPCC_GLOBAL_POLISH_ARTIFACT_DIR",
        "MPCC_GLOBAL_POLISH_PREFER_DENSE_START_ARTIFACT",
        "MPCC_GLOBAL_POLISH_DENSE_START_VALUES_PATH",
        "MPCC_GLOBAL_POLISH_SANITIZE_DENSE_START_DUALS",
        "MPCC_GLOBAL_POLISH_DENSE_START_KKT_REFRESH_POLICY",
        "MPCC_GLOBAL_POLISH_START_KKT_REFRESH_FORCE",
        "MPCC_GLOBAL_POLISH_APPLY_DEFAULT_START_INITIALIZERS",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_ENABLED",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_ELEMENTS",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MAX_ITER",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TOL",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_RESTORE_BEST",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MONOTONE",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE_SUBSTEPS",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_REFRESH",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_FLUX_PROJECTION",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_DUAL_FIT",
        "MPCC_GLOBAL_POLISH_POST_REPAIR_FIXED_FLUX_DUAL_FIT",
        "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_KKT_REFRESH",
        "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_KKT_REFRESH_ELEMENTS",
        "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_COLLOCATION_REPAIR",
        "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_FIXED_FLUX_DUAL_FIT",
        "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_FIXED_FLUX_DUAL_FIT_ELEMENTS",
        "MPCC_GLOBAL_POLISH_SELECTIVE_FIXED_FLUX_DUAL_FIT",
        "MPCC_GLOBAL_POLISH_POST_SOLVE_FLUX_BOUND_PROJECTION_REPAIR",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_MAX_ITER",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_DAMPING_FACTORS",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MONOTONE_ACCEPT_TOL",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE_EVERY",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_STAGNATION_ITERATIONS",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_STAGNATION_TOL",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ENABLED",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS",
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_GUARD_SCORE",
        "MPCC_GLOBAL_POLISH_EXPORT_PRE_SOLVE_START",
        "MPCC_GLOBAL_POLISH_PRE_SOLVE_START_DIR",
        "MPCC_GLOBAL_POLISH_TARGET_HOURS",
        "MPCC_GLOBAL_POLISH_WINDOW_HOURS",
        "MPCC_GLOBAL_POLISH_NFE",
        "MPCC_GLOBAL_POLISH_MAX_WINDOWS",
        "MPCC_GLOBAL_POLISH_ALLOW_LONG",
        "MPCC_GLOBAL_POLISH_SOURCE_MAX_ITER",
        "MPCC_GLOBAL_POLISH_MAX_RETRY_WINDOWS",
        "MPCC_GLOBAL_POLISH_RETRY_MAX_ITERS",
        "MPCC_GLOBAL_POLISH_CASCADE_MAX_ITER",
        "MPCC_GLOBAL_POLISH_MAX_ITER",
        "MPCC_GLOBAL_POLISH_MASS_THRESHOLD",
        "MPCC_RESIDUAL_MAX_RHS",
        "MPCC_RESIDUAL_MAX_MASS",
        "MPCC_RESIDUAL_MAX_BOUND",
        "MPCC_RESIDUAL_MAX_LOWER_BOUND",
        "MPCC_RESIDUAL_MAX_UPPER_BOUND",
        "MPCC_RESIDUAL_MAX_STATIONARITY",
        "MPCC_RESIDUAL_MAX_COMPLEMENTARITY",
        "MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY",
        "MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY",
        "MPCC_GLOBAL_POLISH_SELECTION_POLICY",
        "MPCC_GLOBAL_POLISH_REPLACEMENT_POLICY",
        "MPCC_GLOBAL_POLISH_SOURCE_REQUIRE_PREFLIGHT",
        "MPCC_GLOBAL_POLISH_REQUIRE_PREFLIGHT",
        "MPCC_GLOBAL_POLISH_SOURCE_COMPLETE_REQUIRED",
        "MPCC_GLOBAL_POLISH_CONTINUE_ON_ERROR",
        "MPCC_GLOBAL_POLISH_SILENT",
        "MPCC_GLOBAL_POLISH_PROGRESS",
        "MPCC_GLOBAL_POLISH_OUTPUT_DIR",
        "MPCC_GLOBAL_POLISH_OUTPUT_OVERWRITE",
        "DFBA_PHASE_PROXY_MODE",
        "DFBA_TURNOVER_THRESHOLD",
        "initial_state_config = _script_initial_state_config(params)",
        "y0 = initial_state_config.y0",
        "params = params",
        "phase_proxy_mode",
        "turnover_threshold",
        "initial_total_sugar_g_L",
        "initial_total_yan_equivalent_mgN_L",
        "reduced_mpcc_ipopt_profile_name_from_env",
        "ipopt_linear_solver_from_env",
        "reduced_mpcc_complementarity_tau_from_env",
        "smoke_reduced_dcdfba_mpcc_cascade_retry_horizons",
        "run_reduced_dcdfba_mpcc_windowed_continuation",
        "polish_reduced_dcdfba_mpcc_windowed_artifacts",
        "polish_reduced_dcdfba_mpcc_windowed_candidate",
        "write_reduced_dcdfba_mpcc_global_polish_report",
        "ipopt_profile",
        "profile == \"focused\"",
        "target_horizon = \"0.5\"",
        "target_horizon = \"1.0\"",
        "source_mode = \"cascade\"",
        "source_mode == \"artifacts\"",
        "nfe_per_window = 2",
        "mass_threshold = \"5e-6\"",
        "retry_max_iters = \"200,300,500\"",
        "outputs_written",
        "global_polish_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "global_polish_source_kind",
        "source_complete_required",
        "residual_max_lower_complementarity",
        "global_nfe",
        "nlp_structure_total_variables",
        "nlp_structure_equality_constraints",
        "nlp_structure_inequality_constraints",
        "nlp_structure_fixed_variable_count",
        "nlp_structure_effective_variable_count",
        "nlp_structure_dof_balance",
        "nlp_structure_too_few_degrees_of_freedom_risk",
        "nlp_structure_fixed_variable_treatment_hint",
        "pre_solve_guard_passed",
        "global_polish_collocation_repair_applied",
        "collocation_consistent_state_start_final_collocation_residual",
        "acceptable_solver_status",
        "almost_locally_solved_accepted",
        "candidate_residual_feasible",
        "candidate_trajectory_ready",
        "max_mass_balance_residual",
        "max_state_relative_rmse",
        "start_summary_table",
        "output_diagnostics_metadata",
        "output_plot_core_states",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
end

@testset "Reduced MPCC global polish horizon sweep script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_GLOBAL_POLISH_HORIZON_SWEEP_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_GLOBAL_POLISH_SWEEP_PROFILE",
        "MPCC_GLOBAL_POLISH_SWEEP_TARGET_HOURS",
        "MPCC_GLOBAL_POLISH_SWEEP_SOURCE",
        "MPCC_GLOBAL_POLISH_SWEEP_WINDOW_HOURS",
        "MPCC_GLOBAL_POLISH_SWEEP_NFE",
        "MPCC_GLOBAL_POLISH_SWEEP_MAX_CASES",
        "MPCC_GLOBAL_POLISH_SWEEP_MAX_WINDOWS",
        "MPCC_GLOBAL_POLISH_SWEEP_ALLOW_LARGE",
        "MPCC_GLOBAL_POLISH_SWEEP_ALLOW_LONG",
        "MPCC_GLOBAL_POLISH_SWEEP_SOURCE_MAX_ITER",
        "MPCC_GLOBAL_POLISH_SWEEP_MAX_RETRY_WINDOWS",
        "MPCC_GLOBAL_POLISH_SWEEP_RETRY_MAX_ITERS",
        "MPCC_GLOBAL_POLISH_SWEEP_CASCADE_MAX_ITER",
        "MPCC_GLOBAL_POLISH_SWEEP_GLOBAL_MAX_ITER",
        "MPCC_GLOBAL_POLISH_SWEEP_MASS_THRESHOLD",
        "MPCC_GLOBAL_POLISH_SWEEP_SELECTION_POLICY",
        "MPCC_GLOBAL_POLISH_SWEEP_REPLACEMENT_POLICY",
        "MPCC_GLOBAL_POLISH_SWEEP_SOURCE_REQUIRE_PREFLIGHT",
        "MPCC_GLOBAL_POLISH_SWEEP_GLOBAL_REQUIRE_PREFLIGHT",
        "MPCC_GLOBAL_POLISH_SWEEP_CONTINUE_ON_ERROR",
        "MPCC_GLOBAL_POLISH_SWEEP_SILENT",
        "MPCC_GLOBAL_POLISH_SWEEP_PROGRESS",
        "MPCC_GLOBAL_POLISH_SWEEP_STOP_AFTER_FIRST_NON_GREEN",
        "reduced_mpcc_ipopt_profile_name_from_env",
        "sweep_reduced_dcdfba_mpcc_global_polish_horizons",
        "ipopt_profile",
        "profile == \"grid\"",
        "target_horizons = \"0.5,1.0,1.5,2.0,3.0,4.0\"",
        "source_mode = \"cascade\"",
        "window_hours = \"0.5\"",
        "nfe = 2",
        "max_windows = 144",
        "mass_threshold = \"5e-6\"",
        "retry_max_iters = \"200,300,500\"",
        "outputs_written",
        "sweep_is_scientific_simulation",
        "solved_trajectory_claimed",
        "scientific_baseline",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "green_count",
        "yellow_count",
        "red_count",
        "global_polish_viable_count",
        "acceptable_solver_status",
        "almost_locally_solved_accepted",
        "target_completed_count",
        "nlp_structure_dof_risk_count",
        "nlp_structure_min_dof_balance",
        "nlp_structure_dof_balance",
        "nlp_structure_fixed_variable_count",
        "nlp_structure_too_few_degrees_of_freedom_risk",
        "best_green_case_id",
        "first_non_green_case_id",
        "max_horizon_reached",
        "total_solve_elapsed_seconds",
        "global_polish_table",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC global polish retry script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_GLOBAL_POLISH_RETRY_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_GLOBAL_POLISH_RETRY_PROFILE",
        "MPCC_GLOBAL_POLISH_RETRY_TARGET_HOURS",
        "MPCC_GLOBAL_POLISH_RETRY_SOURCE",
        "MPCC_GLOBAL_POLISH_RETRY_WINDOW_HOURS",
        "MPCC_GLOBAL_POLISH_RETRY_NFE",
        "MPCC_GLOBAL_POLISH_RETRY_MAX_CASES",
        "MPCC_GLOBAL_POLISH_RETRY_MAX_WINDOWS",
        "MPCC_GLOBAL_POLISH_RETRY_MAX_RETRY_ATTEMPTS",
        "MPCC_GLOBAL_POLISH_RETRY_ALLOW_LARGE",
        "MPCC_GLOBAL_POLISH_RETRY_ALLOW_LONG",
        "MPCC_GLOBAL_POLISH_RETRY_SOURCE_MAX_ITER",
        "MPCC_GLOBAL_POLISH_RETRY_SOURCE_MAX_RETRY_WINDOWS",
        "MPCC_GLOBAL_POLISH_RETRY_SOURCE_RETRY_MAX_ITERS",
        "MPCC_GLOBAL_POLISH_RETRY_CASCADE_MAX_ITER",
        "MPCC_GLOBAL_POLISH_RETRY_BASE_GLOBAL_MAX_ITER",
        "MPCC_GLOBAL_POLISH_RETRY_GLOBAL_MAX_ITERS",
        "MPCC_GLOBAL_POLISH_RETRY_MASS_THRESHOLD",
        "MPCC_GLOBAL_POLISH_RETRY_SELECTION_POLICY",
        "MPCC_GLOBAL_POLISH_RETRY_REPLACEMENT_POLICY",
        "MPCC_GLOBAL_POLISH_RETRY_POLICY",
        "MPCC_GLOBAL_POLISH_RETRY_SOURCE_REQUIRE_PREFLIGHT",
        "MPCC_GLOBAL_POLISH_RETRY_BASE_GLOBAL_REQUIRE_PREFLIGHT",
        "MPCC_GLOBAL_POLISH_RETRY_REQUIRE_PREFLIGHT",
        "MPCC_GLOBAL_POLISH_RETRY_CONTINUE_ON_ERROR",
        "MPCC_GLOBAL_POLISH_RETRY_SILENT",
        "MPCC_GLOBAL_POLISH_RETRY_PROGRESS",
        "MPCC_GLOBAL_POLISH_RETRY_STOP_ON_GREEN",
        "MPCC_GLOBAL_POLISH_RETRY_IPOPT_PRINT_LEVEL",
        "MPCC_GLOBAL_POLISH_RETRY_IPOPT_PRINT_FREQUENCY_ITER",
        "MPCC_GLOBAL_POLISH_RETRY_IPOPT_PRINT_FREQUENCY_TIME",
        "reduced_mpcc_ipopt_profile_name_from_env",
        "sweep_reduced_dcdfba_mpcc_global_polish_horizons",
        "retry_reduced_dcdfba_mpcc_global_polish_iteration_limits",
        "reduced_mpcc_ipopt_optimizer",
        "ipopt_profile",
        "profile == \"focused\"",
        "profile == \"grid\"",
        "target_horizons = \"1.5\"",
        "target_horizons = \"1.5,3.0\"",
        "target_horizons = \"0.5,1.0,1.5,2.0,3.0,4.0\"",
        "source_mode = \"cascade\"",
        "window_hours = \"0.5\"",
        "nfe = 2",
        "max_windows = 144",
        "base_global_max_iter = 500",
        "retry_global_max_iters = \"1000\"",
        "mass_threshold = \"5e-6\"",
        "outputs_written",
        "retry_is_scientific_simulation",
        "solved_trajectory_claimed",
        "scientific_baseline",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "base_global_polish_table",
        "global_polish_retry_table",
        "nlp_structure_dof_balance",
        "nlp_structure_fixed_variable_count",
        "nlp_structure_too_few_degrees_of_freedom_risk",
        "retryable_case_count",
        "retry_attempt_count",
        "recovered_case_count",
        "unrecovered_case_count",
        "all_retryable_cases_recovered",
        "best_recovered_target_horizon",
        "total_retry_solve_elapsed_seconds",
        "retry_ipopt_print_level",
        "retry_ipopt_print_frequency_iter",
        "retry_ipopt_print_frequency_time",
        "retry_silent",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC windowed policy horizon sweep script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_WINDOWED_POLICY_HORIZON_SWEEP_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_WINDOWED_POLICY_SWEEP_PROFILE",
        "MPCC_WINDOWED_POLICY_SWEEP_TARGET_HOURS",
        "MPCC_WINDOWED_POLICY_SWEEP_WINDOW_HOURS",
        "MPCC_WINDOWED_POLICY_SWEEP_NFE",
        "MPCC_WINDOWED_POLICY_SWEEP_CONTINUATION_POLICIES",
        "MPCC_WINDOWED_POLICY_SWEEP_STATE_REL_RMSE_THRESHOLDS",
        "MPCC_WINDOWED_POLICY_SWEEP_MAX_CASES",
        "MPCC_WINDOWED_POLICY_SWEEP_MAX_WINDOWS",
        "MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LARGE",
        "MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LONG",
        "MPCC_WINDOWED_POLICY_SWEEP_CONTINUE_ON_ERROR",
        "MPCC_WINDOWED_POLICY_SWEEP_REQUIRE_PREFLIGHT",
        "MPCC_WINDOWED_POLICY_SWEEP_SILENT",
        "MPCC_WINDOWED_POLICY_SWEEP_PROGRESS",
        "MPCC_WINDOWED_POLICY_SWEEP_STOP_AFTER_FIRST_NON_GREEN",
        "MPCC_WINDOWED_POLICY_SWEEP_MASS_THRESHOLD",
        "MPCC_WINDOWED_POLICY_SWEEP_IPOPT_MAX_ITER",
        "MPCC_WINDOWED_POLICY_SWEEP_LINEAR_SOLVERS",
        "MPCC_WINDOWED_POLICY_SWEEP_COMPLEMENTARITY_TAUS",
        "MPCC_WINDOWED_POLICY_SWEEP_USE_TAU_CONTINUATION",
        "sweep_reduced_dcdfba_mpcc_windowed_policy_horizons",
        "profile == \"72h\"",
        "profile == \"2h4nfe\"",
        "target_horizons = \"2.0,4.0,8.0,16.0,32.0,72.0\"",
        "window_hours_values = \"2.0\"",
        "nfe_values = \"4\"",
        "profile == \"2h4nfe\" ? \"mumps,spral\" : \"mumps\"",
        "target_horizons = \"0.5,1.0,2.0,4.0,8.0,16.0,32.0,72.0\"",
        "window_hours_values = \"0.5\"",
        "nfe_values = \"2\"",
        "policies = \"iteration_limit_residual_feasible_state_drift\"",
        "linear_solver_values = linear_solvers",
        "complementarity_tau_values = complementarity_taus",
        "tau_schedule = tau_schedule",
        "max_windows = 144",
        "outputs_written",
        "sweep_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "best_green_case_id",
        "best_green_policy",
        "scale_candidate_count",
        "review_before_scaling_count",
        "blocked_case_count",
        "best_scale_candidate_case_id",
        "best_scale_candidate_next_target_horizon_hint",
        "first_blocked_primary_blocker",
        "scale_readiness",
        "primary_blocker",
        "scale_recommended_next_action",
        "next_target_horizon_hint",
        "max_horizon_reached",
        "first_non_green_case_id",
        "policy_horizon_table",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC solver termination diagnostics script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_SOLVER_TERMINATION_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_SOLVER_TERM_PROFILE",
        "MPCC_SOLVER_TERM_TARGET_HOURS",
        "MPCC_SOLVER_TERM_WINDOW_HOURS",
        "MPCC_SOLVER_TERM_NFE",
        "MPCC_SOLVER_TERM_MAX_WINDOWS",
        "MPCC_SOLVER_TERM_ALLOW_LONG",
        "MPCC_SOLVER_TERM_MASS_THRESHOLD",
        "MPCC_SOLVER_TERM_MAX_RETRY_WINDOWS",
        "MPCC_SOLVER_TERM_MAX_ITERS",
        "MPCC_SOLVER_TERM_SELECTION_POLICY",
        "MPCC_SOLVER_TERM_CONTINUE_ON_ERROR",
        "MPCC_SOLVER_TERM_REQUIRE_PREFLIGHT",
        "MPCC_SOLVER_TERM_SILENT",
        "MPCC_SOLVER_TERM_PROGRESS",
        "MPCC_SOLVER_TERM_IPOPT_MAX_ITER",
        "attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries",
        "diagnose_reduced_dcdfba_mpcc_solver_termination",
        "profile == \"8h\"",
        "target_horizon = \"8.0\"",
        "target_horizon = \"72.0\"",
        "window_hours = \"0.5\"",
        "nfe_per_window = 2",
        "max_windows = 144",
        "mass_threshold = \"5e-6\"",
        "retry_max_iters = \"200,300\"",
        "outputs_written",
        "solver_termination_diagnostic_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "termination_table",
        "residual_gate_table",
        "transition_table",
        "dominant_termination_blocker",
        "dominant_residual",
        "first_blocked_window_id",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end

@testset "Reduced MPCC iteration-limit candidate review script contract" begin
    script_text = _script_entrypoint_text(SCRIPT_ENTRYPOINT_MPCC_ITERATION_LIMIT_REVIEW_PATH)

    for required_text in (
        "ode_script_helpers.jl",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "MPCC_ITER_LIMIT_REVIEW_PROFILE",
        "MPCC_ITER_LIMIT_REVIEW_TARGET_HOURS",
        "MPCC_ITER_LIMIT_REVIEW_WINDOW_HOURS",
        "MPCC_ITER_LIMIT_REVIEW_NFE",
        "MPCC_ITER_LIMIT_REVIEW_MAX_WINDOWS",
        "MPCC_ITER_LIMIT_REVIEW_ALLOW_LONG",
        "MPCC_ITER_LIMIT_REVIEW_MASS_THRESHOLD",
        "MPCC_ITER_LIMIT_REVIEW_MAX_RETRY_WINDOWS",
        "MPCC_ITER_LIMIT_REVIEW_MAX_ITERS",
        "MPCC_ITER_LIMIT_REVIEW_MAX_CANDIDATES",
        "MPCC_ITER_LIMIT_REVIEW_SELECTION_POLICY",
        "MPCC_ITER_LIMIT_REVIEW_CONTINUE_ON_ERROR",
        "MPCC_ITER_LIMIT_REVIEW_REQUIRE_PREFLIGHT",
        "MPCC_ITER_LIMIT_REVIEW_SILENT",
        "MPCC_ITER_LIMIT_REVIEW_PROGRESS",
        "MPCC_ITER_LIMIT_REVIEW_IPOPT_MAX_ITER",
        "attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries",
        "diagnose_reduced_dcdfba_mpcc_solver_termination",
        "review_reduced_dcdfba_mpcc_iteration_limit_candidates",
        "profile == \"8h\"",
        "target_horizon = \"8.0\"",
        "target_horizon = \"72.0\"",
        "window_hours = \"0.5\"",
        "nfe_per_window = 2",
        "max_windows = 144",
        "mass_threshold = \"5e-6\"",
        "retry_max_iters = \"200,300\"",
        "outputs_written",
        "iteration_limit_candidate_review_is_scientific_simulation",
        "solved_trajectory_claimed",
        "first_mpcc_target",
        "full_model_kkt_deferred",
        "dfvb_kkt_deferred",
        "hsl_required",
        "ma57_required",
        "indices_reacciones_used",
        "r0001_used_as_oxygen",
        "iteration_limit_candidate_review_table",
        "selected_candidate_count",
        "diagnostic_extraction_allowed_count",
        "any_scientific_acceptance_allowed",
        "retry_replacement_applied",
        "windowed_candidate_rebuilt",
        "recommended_next_action",
    )
        @test occursin(required_text, script_text)
    end

    @test !occursin("load_full_model", script_text)
    @test !occursin("load_dfvb", script_text)
    @test !occursin("Gurobi", script_text)
    @test !occursin("export_", script_text)
    @test !occursin("write_", script_text)
end
