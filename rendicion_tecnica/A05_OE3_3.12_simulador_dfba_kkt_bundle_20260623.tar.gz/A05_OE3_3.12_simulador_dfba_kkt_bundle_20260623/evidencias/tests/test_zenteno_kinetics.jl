@testset "Zenteno state parsing" begin
    state = default_zenteno_initial_state()

    @test state.biomass == 0.5
    @test state.nitrogen == 0.07
    @test state.glucose == 110.0
    @test state.fructose == 110.0
    @test state.ethanol == 0.0
    @test state.oxygen == 0.0
    @test state.protein == 0.23
    @test state.carbohydrate == 0.185
    @test state.amino_acids == fill(0.9995, 5)
    @test state.aromas == zeros(6)

    parsed = zenteno_state_from_vector(collect(1.0:19.0))
    @test parsed.biomass == 1.0
    @test parsed.amino_acids == collect(9.0:13.0)
    @test parsed.aromas == collect(14.0:19.0)

    @test_throws ErrorException zenteno_state_from_vector([1.0, 2.0])
end

@testset "Zenteno initial kinetic rates" begin
    state = default_zenteno_initial_state()
    params = default_zenteno_parameters()
    rates = zenteno_kinetic_rates(state, params)

    @test isapprox(rates.mu, 0.09023711939325897; rtol = 1.0e-8)
    @test isapprox(rates.betaG, 0.20122483175906017; rtol = 1.0e-8)
    @test isapprox(rates.betaF, 0.0670749439192802; rtol = 1.0e-8)
    @test isapprox(rates.fermentation_hexose, 3.03931349835064; rtol = 1.0e-8)
    @test isapprox(rates.vg, 0.4720217433754092; rtol = 1.0e-8)
    @test isapprox(rates.vf, 0.1982464620697358; rtol = 1.0e-8)
    @test isapprox(rates.vn, 0.004582890776701826; rtol = 1.0e-8)
    @test isapprox(rates.ve, 5.823741603610602; rtol = 1.0e-8)
    @test length(rates.v_aroma_forced) == 6
    @test rates.total_nitrogen_proxy > params.TURNOVER_THRESHOLD
end

@testset "Reduced Zenteno dynamic bounds" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    state = default_zenteno_initial_state()
    params = default_zenteno_parameters()
    bounds = zenteno_dynamic_bounds(model, reaction_map, state, params)

    @test bounds.mode == :growth
    @test isapprox(bounds.lb_updates["r_1714"], -2.6200722894347632; rtol = 1.0e-8)
    @test isapprox(bounds.lb_updates["r_1709"], -1.1004155402525355; rtol = 1.0e-8)
    @test isapprox(bounds.ub_updates["r_1761"], 5.823741603610602; rtol = 1.0e-8)

    amino_acid_ids = ["r_1903", "r_1897", "r_1914", "r_1902", "r_1913"]
    @test all(isapprox(bounds.lb_updates[rxn_id], -0.15992; atol = 1.0e-12) for rxn_id in amino_acid_ids)
    @test all(bounds.objective_weights[rxn_id] == -1.0 for rxn_id in amino_acid_ids)
    @test bounds.objective_weights["r_2111"] == 1.0

    aroma_ids = ["r_1589", "r_1862", "r_1866", "r_4668", "r_4677", "r_1765"]
    @test count(rxn_id -> haskey(bounds.lb_updates, rxn_id), params.nitrogen_source_ids) == 9
    @test count(rxn_id -> haskey(bounds.lb_updates, rxn_id), aroma_ids) == 6

    for rxn_id in ("r_1992", "r_0001", "r_4048")
        @test !haskey(bounds.lb_updates, rxn_id)
        @test !haskey(bounds.ub_updates, rxn_id)
        @test !haskey(bounds.objective_weights, rxn_id)
    end

    @test reaction_map.core["carbohydrate_exchange"] == "r_4048"
    @test has_reaction(model, "r_4048")
    @test bounds.metadata["oxygen_exchange_bound_updated"] == false
    @test bounds.metadata["carbohydrate_exchange_bound_updated"] == false
    @test bounds.metadata["indices_reacciones_used"] == false
end

@testset "Zenteno turnover dynamic bounds" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    state = ZentenoState(0.5, 0.0, 110.0, 110.0, 0.0, 0.0, 0.23, 0.185, zeros(5), zeros(6))
    bounds = zenteno_dynamic_bounds(model, reaction_map, state)

    @test bounds.mode == :turnover
    @test bounds.lb_updates["r_2111"] == 0.0
    @test bounds.ub_updates["r_2111"] == 0.0
    @test bounds.lb_updates["r_4046"] == 0.7
    @test bounds.ub_updates["r_4046"] == 1.0e3
    @test bounds.objective_weights["r_4046"] == 1.0
    @test bounds.objective_weights["r_4047"] == 1.0

    for rxn_id in ("r_1992", "r_0001", "r_4048")
        @test !haskey(bounds.lb_updates, rxn_id)
        @test !haskey(bounds.ub_updates, rxn_id)
        @test !haskey(bounds.objective_weights, rxn_id)
    end
end

@testset "Zenteno dynamic phase proxy selection" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    nitrogen_depleted_with_amino_acids =
        ZentenoState(0.5, 0.0, 110.0, 110.0, 0.0, 0.0, 0.23, 0.185, fill(0.9995, 5), zeros(6))

    legacy_bounds = zenteno_dynamic_bounds(model, reaction_map, nitrogen_depleted_with_amino_acids)
    free_nitrogen_bounds = zenteno_dynamic_bounds(
        model,
        reaction_map,
        nitrogen_depleted_with_amino_acids,
        default_zenteno_parameters(phase_proxy_mode = :free_nitrogen),
    )

    @test legacy_bounds.mode == :growth
    @test legacy_bounds.metadata["phase_proxy_mode"] == "total_molecular_weight"
    @test legacy_bounds.metadata["phase_proxy_value"] > legacy_bounds.metadata["turnover_threshold"]
    @test free_nitrogen_bounds.mode == :turnover
    @test free_nitrogen_bounds.metadata["phase_proxy_mode"] == "free_nitrogen"
    @test free_nitrogen_bounds.metadata["phase_proxy_definition"] == "N_free"
    @test free_nitrogen_bounds.metadata["phase_proxy_value"] == 0.0

    @test_throws ArgumentError default_zenteno_parameters(phase_proxy_mode = :bad_proxy)
end

@testset "Zenteno dynamic bounds do not mutate models" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    bounds = zenteno_dynamic_bounds(model, reaction_map, default_zenteno_initial_state())
    @test model.lb == original_lb
    @test model.ub == original_ub

    updated_model = apply_dynamic_bounds(model, bounds)
    @test model.lb == original_lb
    @test model.ub == original_ub
    @test updated_model.lb[reaction_index(updated_model, "r_1714")] == bounds.lb_updates["r_1714"]
    @test updated_model.ub[reaction_index(updated_model, "r_1761")] == bounds.ub_updates["r_1761"]
    @test updated_model.lb != original_lb
    @test updated_model.ub != original_ub
end

@testset "Zenteno dynamic bound consistency" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    bounds = zenteno_dynamic_bounds(model, reaction_map, default_zenteno_initial_state())
    updated_model = apply_dynamic_bounds(model, bounds)

    @test all(updated_model.lb .<= updated_model.ub)
    @test validate_reduced_model_dimensions(updated_model).ok
end
