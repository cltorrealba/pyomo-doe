using DataFrames

function _synthetic_dynamic_control_plot_result()
    states = zeros(19, 4)
    states[1, :] .= [0.5, 0.7, 0.9, 1.1]
    states[2, :] .= [0.07, 0.05, 0.02, 0.0]
    states[3, :] .= [110.0, 90.0, 60.0, 30.0]
    states[4, :] .= [110.0, 92.0, 65.0, 35.0]
    states[5, :] .= [0.0, 8.0, 20.0, 35.0]
    states[7, :] .= [0.2, 0.25, 0.3, 0.32]
    states[8, :] .= [0.1, 0.15, 0.2, 0.24]
    states[9:13, :] .= 0.4
    states[14, :] .= [0.0, 0.01, 0.025, 0.04]
    states[15, :] .= [0.0, 0.02, 0.07, 0.12]
    states[16, :] .= [0.0, 0.01, 0.03, 0.04]
    states[17, :] .= [0.0, 0.0005, 0.001, 0.002]
    states[18, :] .= [0.0, 0.004, 0.01, 0.02]
    states[19, :] .= [0.0, 0.01, 0.03, 0.06]
    metadata = Dict{String, Any}(
        "state_names" => FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES,
        "retcode" => "Success",
        "termination_reason" => "completed_tspan",
        "termination_time" => 72.0,
        "min_state_value" => 0.0,
        "has_negative_saved_states" => false,
        "rhs_call_count" => 4,
        "total_lp_solve_count" => 4,
    )
    simulation = SimulationResult([0.0, 24.0, 48.0, 72.0], states; metadata = metadata)
    schedule = dynamic_control_schedule_from_values(
        [18.0, 22.0, 22.0, 22.0, 22.0, 22.0];
        horizon_h = 72.0,
        control_interval_h = 12.0,
        fda_doses_g_L = zeros(5),
        organic_doses_g_L = [0.2, 0.0, 0.0, 0.0, 0.0],
    )
    return DynamicControlObjectiveResult(
        1.0,
        true,
        "accepted",
        Dict{String, Float64}("failure_penalty" => 0.0),
        summarize_simulation(simulation),
        schedule,
        simulation,
        Dict{String, Any}(),
    )
end

@testset "Dynamic control schedule plots" begin
    schedule = dynamic_control_schedule_from_values(
        [18.0, 22.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
        fda_doses_g_L = [1.0],
        organic_doses_g_L = [0.2],
    )
    mktempdir() do dir
        paths = write_dynamic_control_schedule_plots(schedule, dir; stop_h = 24.0)
        for key in ("temperature", "nutrient_cumulative", "nutrient_rates")
            @test haskey(paths, key)
            @test isfile(paths[key])
            @test occursin("<svg", read(paths[key], String))
        end
    end
end

@testset "Dynamic control candidate plots" begin
    evaluation = _synthetic_dynamic_control_plot_result()
    mktempdir() do dir
        paths = write_dynamic_control_candidate_plots(
            evaluation,
            dir;
            candidate_id = "synthetic_candidate",
            horizon_h = 72.0,
        )
        @test haskey(paths, "trajectory_sugars")
        @test haskey(paths, "schedule_temperature")
        @test haskey(paths, "candidate_id")
        @test occursin("synthetic_candidate", read(paths["candidate_id"], String))
    end
end

@testset "Dynamic control Pareto plots" begin
    table = DataFrame(
        candidate_id = ["a", "b", "c"],
        final_total_sugar = [120.0, 100.0, 140.0],
        aroma_desirability_score = [0.1, 0.3, 0.2],
        cooling_energy_proxy_unweighted = [80.0, 110.0, 50.0],
        nutrient_total_product_g_L = [0.0, 0.2, 1.0],
        pareto_candidate = [true, true, false],
        selected_for_review = [false, true, false],
        selection_rank = [0, 1, 0],
    )
    mktempdir() do dir
        paths = write_dynamic_control_pareto_plots(table, dir)
        for key in ("sugar_aroma", "sugar_energy", "sugar_nutrient")
            @test haskey(paths, key)
            @test isfile(paths[key])
            contents = read(paths[key], String)
            @test occursin("<svg", contents)
            @test occursin("red: selected", contents)
        end
    end
end
