import JuMP
import MathOptInterface as MOI

@testset "Ipopt/MUMPS reduced toy NLP smoke contract" begin
    problem = build_reduced_toy_nlp_smoke_problem()

    @test problem isa ReducedToyNLPProblem
    @test problem.jump_model isa JuMP.Model
    @test problem.x isa JuMP.VariableRef
    @test problem.y isa JuMP.VariableRef
    @test problem.linear_constraint isa JuMP.ConstraintRef
    @test problem.bilinear_constraint isa JuMP.ConstraintRef
    @test JuMP.num_variables(problem.jump_model) == 2

    metadata = problem.metadata
    @test metadata["problem_type"] == "reduced_toy_nlp_smoke"
    @test metadata["problem_scope"] == "reduced_solver_setup_only"
    @test metadata["optimizer"] == "Ipopt"
    @test metadata["linear_solver"] == "mumps"
    @test metadata["ipopt_warm_start_init_point"] == false
    @test metadata["ipopt_warm_start_init_point_option"] == "no"
    @test metadata["ipopt_warm_start_bound_push"] === missing
    @test metadata["ipopt_warm_start_bound_frac"] === missing
    @test metadata["ipopt_warm_start_slack_bound_push"] === missing
    @test metadata["ipopt_warm_start_slack_bound_frac"] === missing
    @test metadata["ipopt_warm_start_mult_bound_push"] === missing
    @test metadata["ipopt_hessian_approximation"] == "exact"
    @test metadata["ipopt_hessian_approximation_configured"] == false
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["dfba_model_loaded"] == false
    @test metadata["dfvb_model_loaded"] == false
    @test metadata["kkt_constraints_built"] == false
    @test metadata["mpcc_complementarity_built"] == false
    @test metadata["direct_collocation_dynamic_constraints_built"] == false
    @test metadata["sequential_initialization_built"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["expected_x"] == 1.0
    @test metadata["expected_y"] == 0.5
end

@testset "Ipopt linear solver backend selection" begin
    spral_problem = build_reduced_toy_nlp_smoke_problem(; linear_solver = "spral")
    spral_metadata = spral_problem.metadata
    @test spral_metadata["linear_solver"] == "spral"
    @test spral_metadata["linear_solver_source"] == "argument"
    @test spral_metadata["spral_available_from_ipopt_jll"] == true
    @test spral_metadata["pardiso_opt_in"] == false
    @test spral_metadata["hsl_required"] == false

    pardiso_problem = build_reduced_toy_nlp_smoke_problem(; linear_solver = "pardiso")
    pardiso_metadata = pardiso_problem.metadata
    @test pardiso_metadata["linear_solver"] == "pardiso"
    @test pardiso_metadata["pardiso_opt_in"] == true

    @test ipopt_linear_solver_from_env("ma57") == "ma57"
    @test_throws ArgumentError ipopt_optimizer(; linear_solver = "not_a_solver")
    @test_throws ArgumentError ipopt_optimizer(;
        linear_solver = "ma86",
        hsllib = joinpath(tempdir(), "missing_libhsl.dll"),
    )
    @test_throws ArgumentError build_reduced_toy_nlp_smoke_problem(;
        linear_solver = "not_a_solver",
    )
end

@testset "Ipopt Hessian approximation option" begin
    old_env = get(ENV, "MPCC_IPOPT_HESSIAN_APPROXIMATION", nothing)
    try
        ENV["MPCC_IPOPT_HESSIAN_APPROXIMATION"] = "limited_memory"
        @test ipopt_hessian_approximation_from_env() == "limited-memory"
        limited_memory_problem = build_reduced_toy_nlp_smoke_problem()
        @test limited_memory_problem.metadata["ipopt_hessian_approximation"] ==
              "limited-memory"
        @test limited_memory_problem.metadata["ipopt_hessian_approximation_configured"] ==
              true

        ENV["MPCC_IPOPT_HESSIAN_APPROXIMATION"] = "exact"
        @test ipopt_hessian_approximation_from_env() == "exact"
        exact_problem = build_reduced_toy_nlp_smoke_problem()
        @test exact_problem.metadata["ipopt_hessian_approximation"] == "exact"
        @test exact_problem.metadata["ipopt_hessian_approximation_configured"] == true

        ENV["MPCC_IPOPT_HESSIAN_APPROXIMATION"] = "bad"
        @test_throws ArgumentError ipopt_optimizer()
    finally
        if old_env === nothing
            delete!(ENV, "MPCC_IPOPT_HESSIAN_APPROXIMATION")
        else
            ENV["MPCC_IPOPT_HESSIAN_APPROXIMATION"] = old_env
        end
    end
end

@testset "Ipopt warm-start init-point option" begin
    old_env = get(ENV, "MPCC_IPOPT_WARM_START_INIT_POINT", nothing)
    try
        ENV["MPCC_IPOPT_WARM_START_INIT_POINT"] = "1"
        @test ipopt_warm_start_init_point_from_env() == true
        warm_problem = build_reduced_toy_nlp_smoke_problem()
        @test warm_problem.metadata["ipopt_warm_start_init_point"] == true
        @test warm_problem.metadata["ipopt_warm_start_init_point_option"] == "yes"

        ENV["MPCC_IPOPT_WARM_START_INIT_POINT"] = "0"
        @test ipopt_warm_start_init_point_from_env() == false
        cold_problem = build_reduced_toy_nlp_smoke_problem()
        @test cold_problem.metadata["ipopt_warm_start_init_point"] == false

        ENV["MPCC_IPOPT_WARM_START_INIT_POINT"] = "bad"
        @test_throws ArgumentError ipopt_optimizer()
    finally
        if old_env === nothing
            delete!(ENV, "MPCC_IPOPT_WARM_START_INIT_POINT")
        else
            ENV["MPCC_IPOPT_WARM_START_INIT_POINT"] = old_env
        end
    end
end

@testset "Ipopt warm-start bound-push options" begin
    env_names = (
        "MPCC_IPOPT_WARM_START_BOUND_PUSH",
        "MPCC_IPOPT_WARM_START_BOUND_FRAC",
        "MPCC_IPOPT_WARM_START_SLACK_BOUND_PUSH",
        "MPCC_IPOPT_WARM_START_SLACK_BOUND_FRAC",
        "MPCC_IPOPT_WARM_START_MULT_BOUND_PUSH",
    )
    old_env = Dict(name => get(ENV, name, nothing) for name in env_names)
    try
        ENV["MPCC_IPOPT_WARM_START_BOUND_PUSH"] = "1e-10"
        ENV["MPCC_IPOPT_WARM_START_BOUND_FRAC"] = "2e-10"
        ENV["MPCC_IPOPT_WARM_START_SLACK_BOUND_PUSH"] = "3e-10"
        ENV["MPCC_IPOPT_WARM_START_SLACK_BOUND_FRAC"] = "4e-10"
        ENV["MPCC_IPOPT_WARM_START_MULT_BOUND_PUSH"] = "5e-10"

        @test ipopt_warm_start_bound_push_from_env() == 1.0e-10
        @test ipopt_warm_start_bound_frac_from_env() == 2.0e-10
        @test ipopt_warm_start_slack_bound_push_from_env() == 3.0e-10
        @test ipopt_warm_start_slack_bound_frac_from_env() == 4.0e-10
        @test ipopt_warm_start_mult_bound_push_from_env() == 5.0e-10

        warm_problem = build_reduced_toy_nlp_smoke_problem()
        metadata = warm_problem.metadata
        @test metadata["ipopt_warm_start_bound_push"] == 1.0e-10
        @test metadata["ipopt_warm_start_bound_push_env"] ==
              "MPCC_IPOPT_WARM_START_BOUND_PUSH"
        @test metadata["ipopt_warm_start_bound_frac"] == 2.0e-10
        @test metadata["ipopt_warm_start_slack_bound_push"] == 3.0e-10
        @test metadata["ipopt_warm_start_slack_bound_frac"] == 4.0e-10
        @test metadata["ipopt_warm_start_mult_bound_push"] == 5.0e-10

        ENV["MPCC_IPOPT_WARM_START_BOUND_PUSH"] = "0.0"
        @test_throws ArgumentError ipopt_optimizer()
    finally
        for (name, value) in old_env
            if value === nothing
                delete!(ENV, name)
            else
                ENV[name] = value
            end
        end
    end
end

@testset "Ipopt max wall-time option" begin
    old_env = get(ENV, "MPCC_IPOPT_MAX_WALL_TIME_SECONDS", nothing)
    try
        ENV["MPCC_IPOPT_MAX_WALL_TIME_SECONDS"] = "900"
        @test ipopt_max_wall_time_from_env() == 900.0
        timed_problem = build_reduced_toy_nlp_smoke_problem()
        @test timed_problem.metadata["ipopt_max_wall_time_seconds"] == 900.0
        @test timed_problem.metadata["ipopt_max_wall_time_env"] ==
              "MPCC_IPOPT_MAX_WALL_TIME_SECONDS"

        ENV["MPCC_IPOPT_MAX_WALL_TIME_SECONDS"] = "bad"
        @test_throws ArgumentError ipopt_optimizer()
    finally
        if old_env === nothing
            delete!(ENV, "MPCC_IPOPT_MAX_WALL_TIME_SECONDS")
        else
            ENV["MPCC_IPOPT_MAX_WALL_TIME_SECONDS"] = old_env
        end
    end
end

@testset "Ipopt/MUMPS reduced toy NLP smoke solve" begin
    result = solve_reduced_toy_nlp_smoke()

    @test result isa ReducedToyNLPSmokeResult
    @test result.status in (MOI.LOCALLY_SOLVED, MOI.OPTIMAL)
    @test result.primal_status == MOI.FEASIBLE_POINT
    @test isapprox(result.objective_value, 0.0; atol = 1.0e-10)
    @test isapprox(result.x, 1.0; atol = 1.0e-7)
    @test isapprox(result.y, 0.5; atol = 1.0e-7)
    @test isapprox(result.linear_constraint_residual, 0.0; atol = 1.0e-8)
    @test isapprox(result.bilinear_constraint_residual, 0.0; atol = 1.0e-8)
    @test result.solver_name == "Ipopt"

    metadata = result.metadata
    @test metadata["solver_call_performed"] == true
    @test metadata["solver_status"] == string(result.status)
    @test metadata["primal_status"] == string(result.primal_status)
    @test metadata["solver_name"] == "Ipopt"
    @test haskey(metadata, "solver_reported_solve_time_seconds")
    @test metadata["linear_solver"] == "mumps"
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["kkt_constraints_built"] == false
    @test metadata["mpcc_complementarity_built"] == false
end

@testset "Ipopt/MUMPS reduced toy NLP smoke validation" begin
    optimizer = ipopt_mumps_optimizer(;
        max_iter = 100,
        tol = 1.0e-6,
        constr_viol_tol = 1.0e-6,
        dual_inf_tol = 1.0e2,
        compl_inf_tol = 1.0e-5,
        acceptable_tol = 1.0e-5,
        acceptable_constr_viol_tol = 1.0e-6,
        acceptable_compl_inf_tol = 1.0e-5,
        acceptable_dual_inf_tol = 1.0e-5,
        acceptable_obj_change_tol = 1.0e-8,
        acceptable_iter = 5,
        mu_strategy = "adaptive",
        fixed_variable_treatment = "relax_bounds",
        bound_push = 1.0e-8,
        bound_frac = 1.0e-8,
        warm_start_bound_push = 1.0e-10,
        warm_start_bound_frac = 1.0e-10,
        warm_start_slack_bound_push = 1.0e-10,
        warm_start_slack_bound_frac = 1.0e-10,
        warm_start_mult_bound_push = 1.0e-10,
        honor_original_bounds = "yes",
        print_frequency_iter = 1,
        print_frequency_time = 0.0,
    )
    problem = build_reduced_toy_nlp_smoke_problem(; optimizer = optimizer)

    @test problem isa ReducedToyNLPProblem
    @test JuMP.num_variables(problem.jump_model) == 2
    @test_throws ArgumentError ipopt_mumps_optimizer(; print_level = -1)
    @test_throws ArgumentError ipopt_mumps_optimizer(; max_iter = -1)
    @test_throws ArgumentError ipopt_mumps_optimizer(; tol = 0.0)
    @test_throws ArgumentError ipopt_mumps_optimizer(; constr_viol_tol = 0.0)
    @test_throws ArgumentError ipopt_mumps_optimizer(; acceptable_tol = Inf)
    @test_throws ArgumentError ipopt_mumps_optimizer(; acceptable_iter = -1)
    @test_throws ArgumentError ipopt_mumps_optimizer(; mu_strategy = "bad")
    @test_throws ArgumentError ipopt_mumps_optimizer(; fixed_variable_treatment = "bad")
    @test_throws ArgumentError ipopt_mumps_optimizer(; bound_push = 0.0)
    @test_throws ArgumentError ipopt_mumps_optimizer(; warm_start_bound_push = 0.0)
    @test_throws ArgumentError ipopt_mumps_optimizer(; warm_start_bound_frac = 0.0)
    @test_throws ArgumentError ipopt_mumps_optimizer(; warm_start_slack_bound_push = 0.0)
    @test_throws ArgumentError ipopt_mumps_optimizer(; warm_start_slack_bound_frac = 0.0)
    @test_throws ArgumentError ipopt_mumps_optimizer(; warm_start_mult_bound_push = 0.0)
    @test_throws ArgumentError ipopt_mumps_optimizer(; honor_original_bounds = "maybe")
    @test_throws ArgumentError ipopt_mumps_optimizer(; print_frequency_iter = 0)
    @test_throws ArgumentError ipopt_mumps_optimizer(; print_frequency_time = -1.0)
end
