using CSV
using DataFrames
using SparseArrays
using TOML

const DFVB_BASELINE_TEST_STATE_COLUMNS = copy(FermentationDFBA.DFVB_ARTIFACT_STATE_COLUMNS)
const DFVB_BASELINE_REAL_ARTIFACT_CACHE = Ref{Any}(nothing)

function _dfvb_baseline_test_state_table()
    table = DataFrame("time" => [0.0, 1.0, 2.0])
    for (i, state_name) in enumerate(DFVB_BASELINE_TEST_STATE_COLUMNS[2:end])
        if state_name == "oxygen"
            table[!, state_name] = [0.0, 0.0, 0.0]
        else
            table[!, state_name] = [Float64(i), Float64(i) + 0.5, Float64(i) + 1.0]
        end
    end
    return table
end

function _dfvb_baseline_test_artifacts()
    paths = DFVBArtifactPaths("synthetic_dfvb_baseline", ntuple(i -> "synthetic_$i", 17)...)
    manifest = DFVBArtifactManifest(4, 2, 3, 1, 3, 3, true, 2, Dict{String, Any}("synthetic" => true))
    reaction_order = DataFrame(
        "reaction_index" => 1:4,
        "reaction_id" => ["r_0001", "r_1992", "r_2111", "r_4048"],
        "is_exchange" => [true, false, false, false],
        "is_internal" => [false, true, true, true],
        "exchange_position" => [1, missing, missing, missing],
        "internal_position" => [missing, 1, 2, 3],
        "is_active_exchange" => [true, false, false, false],
        "is_active_internal" => [false, true, true, true],
        "is_inactive_exchange" => [false, false, false, false],
        "is_inactive_internal" => [false, false, false, false],
        "model_scope" => fill("synthetic", 4),
    )
    reduced_order = DataFrame(
        "reduced_reaction_index" => 1:4,
        "original_reaction_index" => 1:4,
        "reaction_id" => ["r_0001", "r_1992", "r_2111", "r_4048"],
    )
    exchange_partition = DataFrame(
        "model_scope" => ["synthetic"],
        "partition" => ["exchange"],
        "partition_position" => [1],
        "reaction_index" => [1],
        "reaction_id" => ["r_0001"],
        "is_active" => [true],
        "is_inactive_forced_zero" => [false],
    )
    n_metadata = DataFrame(
        "alpha_index" => 1:3,
        "source_alpha_index" => 1:3,
        "source_alpha_id" => ["alpha_1", "alpha_2", "alpha_3"],
        "is_active" => [false, true, true],
        "model_scope" => fill("synthetic", 3),
    )
    n_active_metadata = DataFrame(
        "alpha_index" => 1:2,
        "source_alpha_index" => [2, 3],
        "source_alpha_id" => ["alpha_2", "alpha_3"],
        "is_active" => [true, true],
        "model_scope" => fill("synthetic", 2),
    )
    active_alpha_indices = DataFrame(
        "active_alpha_index" => 1:2,
        "source_alpha_index" => [2, 3],
        "source_alpha_id" => ["alpha_2", "alpha_3"],
    )
    alpha_bounds = DataFrame(
        "alpha_index" => 1:3,
        "source_alpha_index" => 1:3,
        "source_alpha_id" => ["alpha_1", "alpha_2", "alpha_3"],
        "lower_bound" => fill(-1.0, 3),
        "upper_bound" => fill(1.0, 3),
        "model_scope" => fill("synthetic", 3),
    )
    alpha_bounds_active = DataFrame(
        "alpha_index" => 1:2,
        "source_alpha_index" => [2, 3],
        "source_alpha_id" => ["alpha_2", "alpha_3"],
        "lower_bound" => fill(-1.0, 2),
        "upper_bound" => fill(1.0, 2),
        "model_scope" => fill("synthetic", 2),
    )
    alpha_trajectories = DataFrame(
        "time" => [0.0, 1.0, 2.0],
        "alpha_1" => [0.0, 0.0, 0.0],
        "alpha_2" => [0.0, 0.5, 1.0],
        "alpha_3" => [1.0, 0.5, 0.0],
    )
    alpha_trajectories_active = DataFrame(
        "time" => [0.0, 1.0, 2.0],
        "alpha_1" => [0.0, 0.5, 1.0],
        "alpha_2" => [-1.0, 0.0, 1.0],
    )
    inactive_reactions = DataFrame("model_scope" => String[], "partition" => String[], "reaction_id" => String[])

    return DFVBArtifacts(
        paths,
        manifest,
        reaction_order,
        reduced_order,
        exchange_partition,
        copy(exchange_partition),
        spzeros(4, 3),
        n_metadata,
        spzeros(4, 2),
        n_active_metadata,
        active_alpha_indices,
        alpha_bounds,
        alpha_bounds_active,
        alpha_trajectories,
        alpha_trajectories_active,
        _dfvb_baseline_test_state_table(),
        inactive_reactions,
        copy(inactive_reactions),
        Dict{String, Any}(
            "artifact_id" => "synthetic_dfvb_baseline",
            "r0001_used_as_oxygen" => false,
        ),
    )
end

function _dfvb_baseline_real_artifacts()
    cached = DFVB_BASELINE_REAL_ARTIFACT_CACHE[]
    cached === nothing || return cached
    project_root = normpath(joinpath(@__DIR__, ".."))
    config_path = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")
    artifacts = load_dfvb_artifacts(
        config_path;
        load_alpha_trajectories = true,
        load_active_alpha_trajectories = true,
        load_state_trajectories = true,
    )
    DFVB_BASELINE_REAL_ARTIFACT_CACHE[] = artifacts
    return artifacts
end

@testset "Synthetic DFVB baseline report" begin
    report = build_dfvb_baseline_report(_dfvb_baseline_test_artifacts())

    @test report isa DFVBBaselineReport
    @test nrow(report.state_summary) == 19
    @test nrow(report.state_timeseries) == 3
    @test ncol(report.state_timeseries) == 20
    @test count(==("active"), String.(report.alpha_summary[!, "alpha_scope"])) == 2
    @test count(==("full"), String.(report.alpha_summary[!, "alpha_scope"])) == 3
    @test nrow(report.active_alpha_mapping) == 2
    @test report.active_alpha_mapping[1, "active_alpha_id"] == "alpha_1"
    @test report.active_alpha_mapping[1, "source_alpha_index"] == 2
    @test report.active_alpha_mapping[1, "source_alpha_id"] == "alpha_2"
    @test report.metadata["r0001_used_as_oxygen"] == false
    @test report.metadata["julia_simulation_run"] == false
    @test report.metadata["lp_solve_run"] == false
end

@testset "Real DFVB baseline report smoke" begin
    report = build_dfvb_baseline_report(_dfvb_baseline_real_artifacts())

    @test nrow(report.state_timeseries) == 2094
    @test nrow(report.state_summary) == 19
    @test report.state_timeseries[1, "time"] == 0.0
    @test report.state_timeseries[end, "time"] == 72.0
    @test report.metadata["n_active_alphas"] == 490
    @test report.metadata["n_full_alphas"] == 1538
    @test report.metadata["report_type"] == "matlab_dfvb_baseline_trajectory_report"
    @test report.metadata["r0001_used_as_oxygen"] == false
    @test report.metadata["oxygen_reaction_id"] == "r_1992"
end

@testset "DFVB baseline report export" begin
    report = build_dfvb_baseline_report(_dfvb_baseline_test_artifacts())

    mktempdir() do output_dir
        paths = export_dfvb_baseline_report(report, output_dir; overwrite = false)
        for key in ("state_summary", "state_timeseries", "alpha_summary", "active_alpha_mapping", "metadata")
            @test isfile(paths[key])
        end

        state_summary = CSV.read(paths["state_summary"], DataFrame)
        alpha_summary = CSV.read(paths["alpha_summary"], DataFrame)
        mapping = CSV.read(paths["active_alpha_mapping"], DataFrame)
        metadata = TOML.parsefile(paths["metadata"])

        @test "state_name" in names(state_summary)
        @test "alpha_scope" in names(alpha_summary)
        @test "source_alpha_id" in names(mapping)
        @test metadata["report_type"] == "matlab_dfvb_baseline_trajectory_report"
        @test metadata["r0001_used_as_oxygen"] == false
        @test metadata["full_alpha_timeseries_exported"] == false
    end
end

@testset "DFVB baseline report SVG plots" begin
    report = build_dfvb_baseline_report(_dfvb_baseline_test_artifacts())

    mktempdir() do output_dir
        paths = write_dfvb_baseline_report_plots(report, output_dir; overwrite = false)
        for key in ("core_states", "state_ranges", "alpha_ranges")
            @test isfile(paths[key])
            @test occursin("<svg", read(paths[key], String))
        end
    end
end

@testset "DFVB baseline report overwrite behavior" begin
    report = build_dfvb_baseline_report(_dfvb_baseline_test_artifacts())

    mktempdir() do output_dir
        export_dfvb_baseline_report(report, output_dir; overwrite = false)
        @test_throws ErrorException export_dfvb_baseline_report(report, output_dir; overwrite = false)
        paths = export_dfvb_baseline_report(report, output_dir; overwrite = true)
        @test isfile(paths["metadata"])

        write_dfvb_baseline_report_plots(report, output_dir; overwrite = false)
        @test_throws ErrorException write_dfvb_baseline_report_plots(report, output_dir; overwrite = false)
        plot_paths = write_dfvb_baseline_report_plots(report, output_dir; overwrite = true)
        @test isfile(plot_paths["alpha_ranges"])
    end
end
