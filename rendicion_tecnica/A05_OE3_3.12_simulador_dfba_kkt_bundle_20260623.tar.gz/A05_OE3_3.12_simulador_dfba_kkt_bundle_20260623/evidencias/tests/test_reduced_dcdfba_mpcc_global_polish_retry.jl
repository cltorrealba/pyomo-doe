@testset "Reduced MPCC global polish iteration-limit retry aggregation" begin
    green = _reduced_mpcc_global_polish_horizon_test_result(
        target_horizon = 0.5,
        trajectory_ready = true,
    )
    yellow = _reduced_mpcc_global_polish_horizon_test_result(
        target_horizon = 1.5,
        trajectory_ready = false,
        solve_elapsed_seconds = 200.0,
        max_state_relative_rmse = 4.0e-3,
    )
    base_sweep = sweep_reduced_dcdfba_mpcc_global_polish_horizons([green, yellow])

    calls = Int[]
    retry = retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
        base_sweep;
        retry_ipopt_max_iter_values = [1000],
        retry_runner = function (base_result, retry_iter, retry_attempt_index, base_row)
            push!(calls, retry_iter)
            @test base_result === yellow
            @test retry_attempt_index == 1
            @test base_row["global_polish_case_id"] == "global_polish_horizon_002"
            return _reduced_mpcc_global_polish_horizon_test_result(
                target_horizon = 1.5,
                trajectory_ready = true,
                solve_elapsed_seconds = 31.0,
                max_state_relative_rmse = 1.0e-4,
            )
        end,
    )

    table = retry.retry_table
    metadata = retry.metadata

    @test retry isa ReducedDCDFBAMPCCGlobalPolishRetryResult
    @test retry.base_sweep === base_sweep
    @test calls == [1000]
    @test nrow(table) == 1
    @test table[1, "global_polish_retry_case_id"] == "global_polish_retry_001"
    @test table[1, "base_global_polish_case_id"] == "global_polish_horizon_002"
    @test table[1, "target_horizon"] == 1.5
    @test table[1, "base_global_polish_traffic_light"] == "yellow"
    @test table[1, "base_solver_status"] == "ITERATION_LIMIT"
    @test table[1, "base_candidate_residual_feasible"] == true
    @test table[1, "base_candidate_trajectory_ready"] == false
    @test table[1, "retry_ipopt_max_iter"] == 1000
    @test table[1, "retry_status"] == "completed"
    @test table[1, "retry_global_polish_traffic_light"] == "green"
    @test table[1, "retry_recovered"] == true
    @test table[1, "retry_solver_status"] == "LOCALLY_SOLVED"
    @test table[1, "retry_candidate_residual_feasible"] == true
    @test table[1, "retry_candidate_trajectory_ready"] == true
    @test table[1, "outputs_written"] == false
    @test table[1, "hsl_required"] == false
    @test table[1, "ma57_required"] == false
    @test table[1, "indices_reacciones_used"] == false
    @test table[1, "r0001_used_as_oxygen"] == false

    @test metadata["retry_type"] ==
          "reduced_dcdfba_mpcc_global_polish_iteration_limit_retry"
    @test metadata["retry_policy"] == "residual_feasible_iteration_limit"
    @test metadata["retry_ipopt_max_iter_values"] == [1000]
    @test metadata["base_n_cases"] == 2
    @test metadata["base_green_count"] == 1
    @test metadata["base_yellow_count"] == 1
    @test metadata["retryable_case_count"] == 1
    @test metadata["retried_case_count"] == 1
    @test metadata["retry_attempt_count"] == 1
    @test metadata["retry_green_count"] == 1
    @test metadata["recovered_case_count"] == 1
    @test metadata["unrecovered_case_count"] == 0
    @test metadata["all_retryable_cases_recovered"] == true
    @test metadata["best_recovered_case_id"] == "global_polish_horizon_002"
    @test metadata["best_recovered_target_horizon"] == 1.5
    @test metadata["best_recovered_retry_ipopt_max_iter"] == 1000
    @test metadata["recommended_next_action"] == "extend_global_polish_horizon_grid"
    @test metadata["outputs_written"] == false
    @test metadata["retry_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["dfvb_kkt_deferred"] == true
end

@testset "Reduced MPCC global polish retry stops after green" begin
    yellow = _reduced_mpcc_global_polish_horizon_test_result(
        target_horizon = 1.5,
        trajectory_ready = false,
    )
    base_sweep = sweep_reduced_dcdfba_mpcc_global_polish_horizons([yellow])
    calls = Int[]

    retry = retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
        base_sweep;
        retry_ipopt_max_iter_values = [750, 1000],
        stop_on_green = true,
        retry_runner = function (_, retry_iter, _, _)
            push!(calls, retry_iter)
            return _reduced_mpcc_global_polish_horizon_test_result(
                target_horizon = 1.5,
                trajectory_ready = true,
            )
        end,
    )

    @test calls == [750]
    @test nrow(retry.retry_table) == 1
    @test retry.metadata["recovered_case_count"] == 1
    @test retry.metadata["best_recovered_retry_ipopt_max_iter"] == 750
end

@testset "Reduced MPCC global polish retry reports unrecovered cases" begin
    yellow = _reduced_mpcc_global_polish_horizon_test_result(
        target_horizon = 3.0,
        trajectory_ready = false,
    )
    base_sweep = sweep_reduced_dcdfba_mpcc_global_polish_horizons([yellow])

    retry = retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
        base_sweep;
        retry_ipopt_max_iter_values = [750, 1000],
        stop_on_green = true,
        retry_runner = function (_, retry_iter, _, _)
            return _reduced_mpcc_global_polish_horizon_test_result(
                target_horizon = 3.0,
                trajectory_ready = false,
                solve_elapsed_seconds = retry_iter / 10,
            )
        end,
    )

    @test nrow(retry.retry_table) == 2
    @test retry.metadata["retry_yellow_count"] == 2
    @test retry.metadata["recovered_case_count"] == 0
    @test retry.metadata["unrecovered_case_count"] == 1
    @test retry.metadata["all_retryable_cases_recovered"] == false
    @test retry.metadata["unrecovered_case_ids"] == ["global_polish_horizon_001"]
    @test retry.metadata["recommended_next_action"] ==
          "inspect_global_polish_iteration_limit_retry_failures"
end

@testset "Reduced MPCC global polish retry no-op and validation" begin
    green = _reduced_mpcc_global_polish_horizon_test_result(
        target_horizon = 0.5,
        trajectory_ready = true,
    )
    base_sweep = sweep_reduced_dcdfba_mpcc_global_polish_horizons([green])

    retry = retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
        base_sweep;
        retry_ipopt_max_iter_values = [1000],
        retry_runner = function (_, _, _, _)
            error("retry_runner should not be called for all-green base sweep")
        end,
    )

    @test nrow(retry.retry_table) == 0
    @test retry.metadata["retryable_case_count"] == 0
    @test retry.metadata["retry_attempt_count"] == 0
    @test retry.metadata["recommended_next_action"] == "extend_global_polish_horizon_grid"

    @test_throws ArgumentError retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
        base_sweep;
        retry_ipopt_max_iter_values = [1000],
    )
    @test_throws ArgumentError retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
        base_sweep;
        retry_ipopt_max_iter_values = Int[],
        retry_runner = (_, _, _, _) -> green,
    )
    @test_throws ArgumentError retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
        base_sweep;
        retry_policy = "bad_policy",
        retry_runner = (_, _, _, _) -> green,
    )
end
