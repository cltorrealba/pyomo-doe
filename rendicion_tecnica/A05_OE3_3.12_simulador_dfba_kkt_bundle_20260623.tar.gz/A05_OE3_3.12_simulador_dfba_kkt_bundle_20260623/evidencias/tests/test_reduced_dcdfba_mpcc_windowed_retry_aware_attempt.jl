using DataFrames

function _reduced_mpcc_retry_aware_base_attempt(;
    traffic_light::String,
    attempt_viable::Bool,
    target_completed::Bool = true,
)
    thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
        residual_thresholds =
            default_reduced_dcdfba_mpcc_residual_thresholds(max_mass_balance_residual = 5.0e-6),
    )
    continuation = ReducedDCDFBAMPCCWindowedContinuationResult(
        DataFrame(),
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        nothing,
        nothing,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}("total_horizon_reached" => 1.0),
    )
    report = ReducedDCDFBAMPCCSimulationViabilityReport(
        "windowed_continuation",
        DataFrame(),
        thresholds,
        Dict{String, Any}("overall_traffic_light" => traffic_light),
    )
    return ReducedDCDFBAMPCCWindowedSimulationAttemptResult(
        continuation,
        report,
        DataFrame(),
        Dict{String, Any}(
            "target_horizon" => 1.0,
            "horizon_reached" => 1.0,
            "target_completed" => target_completed,
            "attempt_traffic_light" => traffic_light,
            "attempt_viable" => attempt_viable,
        ),
    )
end

function _reduced_mpcc_retry_aware_policy(
    attempt::ReducedDCDFBAMPCCWindowedSimulationAttemptResult;
    selected::Int,
    green_recovered::Int,
    trajectory_recovered::Int,
    residual_recovered::Int,
    all_green::Bool,
    all_trajectory::Bool,
    first_unrecovered = missing,
)
    table = DataFrame(
        "source_window_id" => selected == 0 ? String[] : ["window_002"],
        "source_window_index" => selected == 0 ? Int[] : [2],
        "recovered_green_window" => selected == 0 ? Bool[] : [green_recovered > 0],
        "recovered_trajectory_ready" => selected == 0 ? Bool[] : [trajectory_recovered > 0],
    )
    metadata = Dict{String, Any}(
        "diagnostic_type" => "reduced_dcdfba_mpcc_windowed_retry_policy_diagnostics",
        "target_horizon" => get(attempt.metadata, "target_horizon", missing),
        "horizon_reached" => get(attempt.metadata, "horizon_reached", missing),
        "target_completed" => get(attempt.metadata, "target_completed", missing),
        "attempt_traffic_light" => get(attempt.metadata, "attempt_traffic_light", missing),
        "source_selection_policy" => "iteration_limit_or_not_ready",
        "selected_window_indices" => selected == 0 ? Int[] : [2],
        "ipopt_max_iter_values" => [200, 300],
        "n_selected_windows" => selected,
        "n_retried_windows" => selected,
        "n_retry_results" => selected,
        "green_recovered_count" => green_recovered,
        "trajectory_ready_recovered_count" => trajectory_recovered,
        "residual_feasible_recovered_count" => residual_recovered,
        "all_selected_windows_recovered_green" => all_green,
        "all_selected_windows_recovered_trajectory_ready" => all_trajectory,
        "first_unrecovered_window_id" => first_unrecovered,
        "first_unrecovered_window_index" => first_unrecovered === missing ? missing : 2,
        "recommended_next_action" => "synthetic_retry_policy_action",
        "outputs_written" => false,
        "retry_policy_diagnostic_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
    )
    return ReducedDCDFBAMPCCWindowedRetryPolicyDiagnosticResult(
        table,
        ReducedDCDFBAMPCCWindowRetryDiagnosticResult[],
        attempt,
        metadata,
    )
end

@testset "Reduced MPCC retry-aware windowed attempt aggregation" begin
    base_green = _reduced_mpcc_retry_aware_base_attempt(
        traffic_light = "green",
        attempt_viable = true,
    )
    no_retry = _reduced_mpcc_retry_aware_policy(
        base_green;
        selected = 0,
        green_recovered = 0,
        trajectory_recovered = 0,
        residual_recovered = 0,
        all_green = false,
        all_trajectory = false,
    )
    green_result = attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
        base_green,
        no_retry,
    )

    @test green_result isa ReducedDCDFBAMPCCWindowedRetryAwareAttemptResult
    @test green_result.base_attempt === base_green
    @test green_result.retry_policy_diagnostic === no_retry
    @test green_result.metadata["retry_aware_traffic_light"] == "green"
    @test green_result.metadata["retry_aware_viable"] == true
    @test green_result.metadata["retry_policy_applied"] == false
    @test green_result.metadata["retry_replacement_recommended"] == false
    @test green_result.metadata["recommended_next_action"] ==
          "review_base_green_windowed_candidate_before_scientific_use"
    @test size(green_result.summary_table, 1) == 1
    @test green_result.summary_table[1, "candidate_id"] == "retry_aware_windowed_attempt"

    base_yellow = _reduced_mpcc_retry_aware_base_attempt(
        traffic_light = "yellow",
        attempt_viable = false,
    )
    recovered_policy = _reduced_mpcc_retry_aware_policy(
        base_yellow;
        selected = 1,
        green_recovered = 1,
        trajectory_recovered = 1,
        residual_recovered = 0,
        all_green = true,
        all_trajectory = true,
    )
    recovered_result = attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
        base_yellow,
        recovered_policy,
    )

    @test recovered_result.metadata["retry_aware_traffic_light"] == "yellow"
    @test recovered_result.metadata["retry_aware_viable"] == false
    @test recovered_result.metadata["retry_policy_applied"] == true
    @test recovered_result.metadata["retry_replacement_recommended"] == true
    @test recovered_result.metadata["retry_replacement_applied"] == false
    @test recovered_result.metadata["windowed_candidate_rebuilt"] == false
    @test recovered_result.metadata["green_recovered_count"] == 1
    @test recovered_result.metadata["trajectory_ready_recovered_count"] == 1
    @test recovered_result.metadata["recommended_next_action"] ==
          "apply_retry_replacements_and_reassess_windowed_candidate"
    @test recovered_result.metadata["outputs_written"] == false
    @test recovered_result.metadata["retry_aware_attempt_is_scientific_simulation"] ==
          false
    @test recovered_result.metadata["solved_trajectory_claimed"] == false
    @test recovered_result.metadata["first_mpcc_target"] == "reduced_dfba"
    @test recovered_result.metadata["hsl_required"] == false
    @test recovered_result.metadata["ma57_required"] == false
    @test recovered_result.metadata["indices_reacciones_used"] == false
    @test recovered_result.metadata["r0001_used_as_oxygen"] == false

    unrecovered_policy = _reduced_mpcc_retry_aware_policy(
        base_yellow;
        selected = 1,
        green_recovered = 0,
        trajectory_recovered = 0,
        residual_recovered = 1,
        all_green = false,
        all_trajectory = false,
        first_unrecovered = "window_002",
    )
    unrecovered_result = attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
        base_yellow,
        unrecovered_policy,
    )

    @test unrecovered_result.metadata["retry_aware_traffic_light"] == "yellow"
    @test unrecovered_result.metadata["retry_replacement_recommended"] == false
    @test unrecovered_result.metadata["first_unrecovered_window_id"] == "window_002"
    @test unrecovered_result.metadata["recommended_next_action"] ==
          "inspect_solver_scaling_before_retry_replacement"
end

@testset "Reduced MPCC retry-aware windowed attempt validation" begin
    attempt = _reduced_mpcc_retry_aware_base_attempt(
        traffic_light = "yellow",
        attempt_viable = false,
    )
    other_attempt = _reduced_mpcc_retry_aware_base_attempt(
        traffic_light = "yellow",
        attempt_viable = false,
    )
    mismatched_policy = _reduced_mpcc_retry_aware_policy(
        other_attempt;
        selected = 0,
        green_recovered = 0,
        trajectory_recovered = 0,
        residual_recovered = 0,
        all_green = false,
        all_trajectory = false,
    )

    @test_throws ArgumentError attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
        attempt,
        mismatched_policy,
    )
end
