import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_primal_feasibility_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

@testset "Reduced DC-dFBA primal feasibility scaffold contract" begin
    model, reaction_map = _reduced_dcdfba_primal_feasibility_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    variable_count_before = JuMP.num_variables(nlp.jump_model)
    primal = add_reduced_dcdfba_primal_feasibility!(nlp)

    @test primal isa ReducedDCDFBAPrimalFeasibilityScaffold
    @test primal.nlp === nlp
    @test primal.layout isa ReducedDCDFBAPrimalFeasibilityLayout
    @test size(primal.mass_balance_constraints) == (1079, 1, 3)
    @test all(constraint -> constraint isa JuMP.ConstraintRef, primal.mass_balance_constraints)
    @test JuMP.num_variables(nlp.jump_model) == variable_count_before
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED

    layout = primal.layout
    @test layout.n_metabolites == size(model.S, 1) == 1079
    @test layout.n_reactions == size(model.S, 2) == 1488
    @test layout.nfe == 1
    @test layout.collocation_degree == 3
    @test layout.n_collocation_points == 3
    @test layout.n_mass_balance_constraints == 1079 * 3
    @test layout.total_primal_feasibility_constraints == layout.n_mass_balance_constraints
    @test length(primal.mass_balance_constraints) == layout.total_primal_feasibility_constraints
end

@testset "Reduced DC-dFBA primal feasibility metadata guardrails" begin
    model, reaction_map = _reduced_dcdfba_primal_feasibility_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    @test nlp.metadata["mass_balance_constraints_built"] == false

    primal = add_reduced_dcdfba_primal_feasibility!(nlp)
    metadata = primal.metadata

    @test metadata["mass_balance_constraints_built"] == true
    @test metadata["reduced_fba_primal_feasibility_built"] == true
    @test metadata["primal_feasibility_component"] == "S*v = 0 at each collocation point"
    @test metadata["primal_feasibility_total_constraints"] == 1079 * 3
    @test metadata["primal_feasibility_metabolite_count"] == 1079
    @test metadata["primal_feasibility_reaction_count"] == 1488
    @test metadata["bound_feasibility_constraints_built"] == false
    @test metadata["stationarity_constraints_built"] == false
    @test metadata["kkt_constraints_built"] == false
    @test metadata["mpcc_complementarity_built"] == false
    @test metadata["dynamic_flux_bounds_applied"] == false
    @test metadata["solver_call_performed"] == false
    @test metadata["sequential_initialization_built"] == false
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false

    @test nlp.metadata["mass_balance_constraints_built"] == true
    @test nlp.metadata["reduced_fba_primal_feasibility_built"] == true
    @test nlp.metadata["bound_feasibility_constraints_built"] == false
    @test nlp.metadata["stationarity_constraints_built"] == false
    @test nlp.metadata["kkt_constraints_built"] == false
    @test nlp.metadata["mpcc_complementarity_built"] == false
end

@testset "Reduced DC-dFBA primal feasibility after RHS residuals" begin
    model, reaction_map = _reduced_dcdfba_primal_feasibility_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    rhs = add_reduced_dcdfba_rhs_residuals!(nlp)
    primal = add_reduced_dcdfba_primal_feasibility!(nlp)

    @test rhs.layout.total_rhs_residual_constraints == 19 * 3
    @test primal.layout.total_primal_feasibility_constraints == 1079 * 3
    @test nlp.metadata["ode_rhs_constraints_built"] == true
    @test nlp.metadata["rhs_residual_scaffold_built"] == true
    @test nlp.metadata["mass_balance_constraints_built"] == true
    @test nlp.metadata["reduced_fba_primal_feasibility_built"] == true
    @test nlp.metadata["stationarity_constraints_built"] == false
    @test nlp.metadata["kkt_constraints_built"] == false
    @test nlp.metadata["mpcc_complementarity_built"] == false
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA primal feasibility validation" begin
    model, reaction_map = _reduced_dcdfba_primal_feasibility_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )

    primal = add_reduced_dcdfba_primal_feasibility!(nlp)
    @test primal.layout.n_mass_balance_constraints == 1079 * 3
    @test_throws ArgumentError add_reduced_dcdfba_primal_feasibility!(nlp)
end
