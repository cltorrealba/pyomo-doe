import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_complementarity_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_complementarity_ready_nlp(model, reaction_map)
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    primal = add_reduced_dcdfba_primal_feasibility!(nlp)
    bound = add_reduced_dcdfba_bound_feasibility!(nlp)
    stationarity = add_reduced_dcdfba_stationarity!(nlp, bound)
    return nlp, primal, bound, stationarity
end

@testset "Reduced DC-dFBA complementarity scaffold contract" begin
    model, reaction_map = _reduced_dcdfba_complementarity_test_model_and_map()
    nlp, primal, bound, stationarity = _reduced_dcdfba_complementarity_ready_nlp(model, reaction_map)
    variable_count_before = JuMP.num_variables(nlp.jump_model)
    complementarity = add_reduced_dcdfba_complementarity!(nlp, stationarity)

    @test primal.layout.total_primal_feasibility_constraints == 1079 * 3
    @test bound.layout.n_total_bound_feasibility_constraints == 2 * 1488 * 3
    @test stationarity.layout.n_stationarity_constraints == 1488 * 3
    @test complementarity isa ReducedDCDFBAComplementarityScaffold
    @test complementarity.nlp === nlp
    @test complementarity.stationarity === stationarity
    @test complementarity.layout isa ReducedDCDFBAComplementarityLayout
    @test size(complementarity.lower_bound_complementarity_constraints) == (1488, 1, 3)
    @test size(complementarity.upper_bound_complementarity_constraints) == (1488, 1, 3)
    @test all(
        constraint -> constraint isa JuMP.ConstraintRef,
        complementarity.lower_bound_complementarity_constraints,
    )
    @test all(
        constraint -> constraint isa JuMP.ConstraintRef,
        complementarity.upper_bound_complementarity_constraints,
    )
    @test JuMP.num_variables(nlp.jump_model) == variable_count_before
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED

    layout = complementarity.layout
    @test layout.n_reactions == size(model.S, 2) == 1488
    @test layout.nfe == 1
    @test layout.collocation_degree == 3
    @test layout.n_collocation_points == 3
    @test layout.n_lower_bound_complementarity_constraints == 1488 * 3
    @test layout.n_upper_bound_complementarity_constraints == 1488 * 3
    @test layout.n_total_complementarity_constraints == 2 * 1488 * 3
    @test length(complementarity.lower_bound_complementarity_constraints) +
          length(complementarity.upper_bound_complementarity_constraints) ==
          layout.n_total_complementarity_constraints
end

@testset "Reduced DC-dFBA complementarity expression coefficients" begin
    model, reaction_map = _reduced_dcdfba_complementarity_test_model_and_map()
    nlp, _, bound, stationarity = _reduced_dcdfba_complementarity_ready_nlp(model, reaction_map)
    complementarity = add_reduced_dcdfba_complementarity!(nlp, stationarity)
    reaction_sample = [
        reaction_index(model, "r_2111"),
        reaction_index(model, "r_1714"),
        reaction_index(model, "r_1709"),
        reaction_index(model, "r_1761"),
        reaction_index(model, "r_4048"),
    ]

    for reaction_index_value in reaction_sample
        lower_constraint =
            complementarity.lower_bound_complementarity_constraints[reaction_index_value, 1, 1]
        upper_constraint =
            complementarity.upper_bound_complementarity_constraints[reaction_index_value, 1, 1]
        flux = nlp.flux[reaction_index_value, 1, 1]
        lower_dual = bound.lower_bound_duals[reaction_index_value, 1, 1]
        upper_dual = bound.upper_bound_duals[reaction_index_value, 1, 1]

        @test JuMP.normalized_coefficient(lower_constraint, flux, lower_dual) == 1.0
        @test JuMP.normalized_coefficient(lower_constraint, lower_dual) ==
              -model.lb[reaction_index_value]
        @test JuMP.normalized_rhs(lower_constraint) == 0.0

        @test JuMP.normalized_coefficient(upper_constraint, flux, upper_dual) == 1.0
        @test JuMP.normalized_coefficient(upper_constraint, upper_dual) ==
              -model.ub[reaction_index_value]
        @test JuMP.normalized_rhs(upper_constraint) == 0.0
    end
end

@testset "Reduced DC-dFBA Scholtes complementarity relaxation" begin
    model, reaction_map = _reduced_dcdfba_complementarity_test_model_and_map()
    nlp, _, bound, stationarity = _reduced_dcdfba_complementarity_ready_nlp(model, reaction_map)
    tau = 1.0e-4
    complementarity = add_reduced_dcdfba_complementarity!(
        nlp,
        stationarity;
        complementarity_mode = :scholtes,
        complementarity_tau = tau,
    )
    metadata = complementarity.metadata

    @test metadata["complementarity_mode"] == "scholtes"
    @test metadata["complementarity_tau"] == tau
    @test metadata["complementarity_constraint_type"] == "scholtes_inequalities"
    @test metadata["lower_bound_complementarity_form"] ==
          "-((v - lb) * alpha_L) <= tau"
    @test metadata["upper_bound_complementarity_form"] ==
          "-((v - ub) * alpha_U) <= tau"

    reaction_index_value = reaction_index(model, "r_2111")
    lower_constraint =
        complementarity.lower_bound_complementarity_constraints[reaction_index_value, 1, 1]
    upper_constraint =
        complementarity.upper_bound_complementarity_constraints[reaction_index_value, 1, 1]
    flux = nlp.flux[reaction_index_value, 1, 1]
    lower_dual = bound.lower_bound_duals[reaction_index_value, 1, 1]
    upper_dual = bound.upper_bound_duals[reaction_index_value, 1, 1]

    @test JuMP.normalized_coefficient(lower_constraint, flux, lower_dual) == -1.0
    @test JuMP.normalized_coefficient(lower_constraint, lower_dual) ==
          model.lb[reaction_index_value]
    @test JuMP.normalized_rhs(lower_constraint) == tau

    @test JuMP.normalized_coefficient(upper_constraint, flux, upper_dual) == -1.0
    @test JuMP.normalized_coefficient(upper_constraint, upper_dual) ==
          model.ub[reaction_index_value]
    @test JuMP.normalized_rhs(upper_constraint) == tau
end

@testset "Reduced DC-dFBA complementarity metadata guardrails" begin
    model, reaction_map = _reduced_dcdfba_complementarity_test_model_and_map()
    nlp, _, _, stationarity = _reduced_dcdfba_complementarity_ready_nlp(model, reaction_map)
    @test nlp.metadata["mpcc_complementarity_built"] == false
    @test nlp.metadata["kkt_constraints_built"] == false

    complementarity = add_reduced_dcdfba_complementarity!(nlp, stationarity)
    metadata = complementarity.metadata

    @test metadata["mpcc_complementarity_built"] == true
    @test metadata["reduced_fba_complementarity_built"] == true
    @test metadata["reduced_fba_kkt_constraints_built"] == true
    @test metadata["kkt_constraints_built"] == true
    @test metadata["lower_bound_complementarity_built"] == true
    @test metadata["upper_bound_complementarity_built"] == true
    @test metadata["lower_bound_complementarity_form"] == "(v - lb) * alpha_L = 0"
    @test metadata["upper_bound_complementarity_form"] == "(v - ub) * alpha_U = 0"
    @test metadata["lower_bound_dual_sign"] == "nonpositive"
    @test metadata["upper_bound_dual_sign"] == "nonnegative"
    @test metadata["complementarity_constraint_type"] == "quadratic_equalities"
    @test metadata["complementarity_lower_constraints"] == 1488 * 3
    @test metadata["complementarity_upper_constraints"] == 1488 * 3
    @test metadata["complementarity_total_constraints"] == 2 * 1488 * 3
    @test metadata["mpcc_formulation_scope"] == "reduced_fba_fixed_bounds_at_collocation_points"
    @test metadata["full_simultaneous_dfba_solver_built"] == false
    @test metadata["dynamic_flux_bounds_applied"] == false
    @test metadata["solver_call_performed"] == false
    @test metadata["sequential_initialization_built"] == false
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false

    @test nlp.metadata["mpcc_complementarity_built"] == true
    @test nlp.metadata["reduced_fba_complementarity_built"] == true
    @test nlp.metadata["kkt_constraints_built"] == true
    @test nlp.metadata["solver_call_performed"] == false
end

@testset "Reduced DC-dFBA complementarity after RHS, primal, bound, and stationarity" begin
    model, reaction_map = _reduced_dcdfba_complementarity_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    rhs = add_reduced_dcdfba_rhs_residuals!(nlp)
    primal = add_reduced_dcdfba_primal_feasibility!(nlp)
    bound = add_reduced_dcdfba_bound_feasibility!(nlp)
    stationarity = add_reduced_dcdfba_stationarity!(nlp, bound)
    complementarity = add_reduced_dcdfba_complementarity!(nlp, stationarity)

    @test rhs.layout.total_rhs_residual_constraints == 19 * 3
    @test primal.layout.total_primal_feasibility_constraints == 1079 * 3
    @test bound.layout.n_total_bound_feasibility_constraints == 2 * 1488 * 3
    @test stationarity.layout.n_stationarity_constraints == 1488 * 3
    @test complementarity.layout.n_total_complementarity_constraints == 2 * 1488 * 3
    @test nlp.metadata["ode_rhs_constraints_built"] == true
    @test nlp.metadata["mass_balance_constraints_built"] == true
    @test nlp.metadata["bound_feasibility_constraints_built"] == true
    @test nlp.metadata["stationarity_constraints_built"] == true
    @test nlp.metadata["mpcc_complementarity_built"] == true
    @test nlp.metadata["kkt_constraints_built"] == true
    @test nlp.metadata["solver_call_performed"] == false
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA complementarity validation" begin
    model, reaction_map = _reduced_dcdfba_complementarity_test_model_and_map()
    nlp, _, _, stationarity = _reduced_dcdfba_complementarity_ready_nlp(model, reaction_map)
    complementarity = add_reduced_dcdfba_complementarity!(nlp, stationarity)

    @test complementarity.layout.n_total_complementarity_constraints == 2 * 1488 * 3
    @test_throws ArgumentError add_reduced_dcdfba_complementarity!(nlp, stationarity)

    other_nlp, _, _, other_stationarity =
        _reduced_dcdfba_complementarity_ready_nlp(model, reaction_map)
    @test_throws ArgumentError add_reduced_dcdfba_complementarity!(other_nlp, stationarity)
    @test add_reduced_dcdfba_complementarity!(other_nlp, other_stationarity).layout.n_total_complementarity_constraints ==
          2 * 1488 * 3
end
