import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_sequential_initialization_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_sequential_initialization_test_simulation()
    time = [0.0, 0.5, 1.0]
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    slopes = 0.01 .* collect(1.0:19.0)
    states = hcat((initial_state .+ slopes .* t for t in time)...)
    flux_rxn_ids = ["r_2111", "r_1714"]
    fluxes = hcat(([0.1 + 0.02 * t, -2.0 + 0.5 * t] for t in time)...)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => flux_rxn_ids,
            "model_scope" => "reduced",
            "termination_reason" => "completed_tspan",
        ),
    )
end

@testset "Reduced DC-dFBA sequential initialization contract" begin
    model, reaction_map = _reduced_dcdfba_sequential_initialization_test_model_and_map()
    simulation = _reduced_dcdfba_sequential_initialization_test_simulation()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        nfe = 2,
    )

    init = initialize_reduced_dcdfba_from_simulation!(nlp, simulation)

    @test init isa ReducedDCDFBASequentialInitialization
    @test init.nlp === nlp
    @test size(init.state_boundary_starts) == (19, 3)
    @test size(init.state_collocation_starts) == (19, 2, 3)
    @test size(init.state_derivative_starts) == (19, 2, 3)
    @test size(init.flux_starts) == (1488, 2, 3)
    @test init.flux_reaction_ids == ["r_2111", "r_1714"]
    @test init.initialized_flux_indices == sort([
        reaction_index(model, "r_2111"),
        reaction_index(model, "r_1714"),
    ])
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA sequential initialization state and flux starts" begin
    model, reaction_map = _reduced_dcdfba_sequential_initialization_test_model_and_map()
    simulation = _reduced_dcdfba_sequential_initialization_test_simulation()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        nfe = 2,
    )
    carbohydrate_index = reaction_index(model, "r_4048")
    carbohydrate_start_before = JuMP.start_value(nlp.flux[carbohydrate_index, 1, 1])

    init = initialize_reduced_dcdfba_from_simulation!(nlp, simulation)
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    slopes = 0.01 .* collect(1.0:19.0)
    biomass_flux_index = reaction_index(model, "r_2111")
    glucose_flux_index = reaction_index(model, "r_1714")

    @test JuMP.start_value(nlp.state_boundary[1, 1]) == initial_state[1]
    @test isapprox(JuMP.start_value(nlp.state_boundary[1, 2]), initial_state[1] + slopes[1] * 0.5)
    @test isapprox(JuMP.start_value(nlp.state_boundary[1, 3]), initial_state[1] + slopes[1])

    for e in 1:2, j in 1:3
        t = collocation_time(nlp.kkt_problem.grid, e, j)
        @test isapprox(JuMP.start_value(nlp.state_collocation[3, e, j]), initial_state[3] + slopes[3] * t)
        @test isapprox(JuMP.start_value(nlp.state_derivative[3, e, j]), slopes[3])
        @test isapprox(JuMP.start_value(nlp.flux[biomass_flux_index, e, j]), 0.1 + 0.02 * t)
        @test isapprox(JuMP.start_value(nlp.flux[glucose_flux_index, e, j]), -2.0 + 0.5 * t)
    end

    @test JuMP.start_value(nlp.flux[carbohydrate_index, 1, 1]) == carbohydrate_start_before
    @test init.metadata["sequential_initialization_flux_fallback_policy"] ==
          "preserve_existing_start_for_missing_reactions"
end

@testset "Reduced DC-dFBA sequential initialization metadata guardrails" begin
    model, reaction_map = _reduced_dcdfba_sequential_initialization_test_model_and_map()
    simulation = _reduced_dcdfba_sequential_initialization_test_simulation()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        nfe = 2,
    )
    init = initialize_reduced_dcdfba_from_simulation!(nlp, simulation)
    metadata = init.metadata

    @test metadata["sequential_initialization_built"] == true
    @test metadata["sequential_initialization_source"] == "SimulationResult"
    @test metadata["sequential_initialization_state_policy"] == "piecewise_linear_interpolation_at_grid_times"
    @test metadata["sequential_initialization_derivative_policy"] == "piecewise_linear_saved_state_slopes"
    @test metadata["sequential_initialization_flux_policy"] == "provided_fluxes_or_existing"
    @test metadata["sequential_initialization_flux_clamp_policy"] ==
          "clamp_provided_flux_starts_to_base_bounds"
    @test metadata["sequential_initialization_time_points"] == 3
    @test metadata["sequential_initialization_grid_tspan"] == (0.0, 1.0)
    @test metadata["sequential_initialization_grid_nfe"] == 2
    @test metadata["sequential_initialization_collocation_degree"] == 3
    @test metadata["sequential_initialization_flux_reaction_count"] == 2
    @test metadata["sequential_initialization_missing_flux_start_count"] == 1486
    @test metadata["sequential_initialization_simulation_model_scope"] == "reduced"
    @test metadata["sequential_initialization_simulation_termination_reason"] == "completed_tspan"
    @test metadata["sequential_initialization_is_scientific_solution"] == false
    @test metadata["solver_call_performed"] == false
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false

    @test nlp.metadata["sequential_initialization_built"] == true
    @test nlp.metadata["solver_call_performed"] == false
end

@testset "Reduced DC-dFBA sequential initialization smoke integration" begin
    model, reaction_map = _reduced_dcdfba_sequential_initialization_test_model_and_map()
    simulation = _reduced_dcdfba_sequential_initialization_test_simulation()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        nfe = 2,
        sequential_initialization = simulation,
    )

    @test problem.sequential_initialization isa ReducedDCDFBASequentialInitialization
    @test problem.metadata["sequential_initialization_built"] == true
    @test problem.metadata["sequential_initialization_source"] == "SimulationResult"
    @test problem.metadata["sequential_initialization_flux_reaction_count"] == 2
    @test problem.metadata["solver_call_performed"] == false
    @test problem.metadata["smoke_result_is_scientific_simulation"] == false
    @test problem.primal_feasibility.layout.total_primal_feasibility_constraints == 1079 * 2 * 3
    @test problem.complementarity.layout.n_total_complementarity_constraints == 2 * 1488 * 2 * 3
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA sequential initialization validation" begin
    model, reaction_map = _reduced_dcdfba_sequential_initialization_test_model_and_map()
    simulation = _reduced_dcdfba_sequential_initialization_test_simulation()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        nfe = 2,
    )
    @test_throws ArgumentError initialize_reduced_dcdfba_from_simulation!(
        nlp,
        simulation;
        flux_start_policy = :unsupported,
    )

    init = initialize_reduced_dcdfba_from_simulation!(nlp, simulation)
    @test init.metadata["sequential_initialization_built"] == true
    @test_throws ArgumentError initialize_reduced_dcdfba_from_simulation!(nlp, simulation)

    short_simulation = SimulationResult(
        [0.0, 0.5],
        simulation.states[:, 1:2];
        metadata = Dict{String, Any}(),
    )
    uncovered_nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        nfe = 2,
    )
    @test_throws ArgumentError initialize_reduced_dcdfba_from_simulation!(uncovered_nlp, short_simulation)

    oxygen_simulation = SimulationResult(
        simulation.time,
        simulation.states;
        fluxes = reshape([0.0, 0.0, 0.0], 1, 3),
        metadata = Dict{String, Any}("flux_rxn_ids" => ["r_1992"]),
    )
    oxygen_nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        nfe = 2,
    )
    @test_throws ArgumentError initialize_reduced_dcdfba_from_simulation!(oxygen_nlp, oxygen_simulation)
end
