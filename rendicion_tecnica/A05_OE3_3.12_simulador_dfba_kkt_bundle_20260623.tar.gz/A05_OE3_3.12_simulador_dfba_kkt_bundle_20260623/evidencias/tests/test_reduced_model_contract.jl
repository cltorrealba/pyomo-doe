@testset "Reduced model data contract" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)

    @test size(model.S) == (1079, 1488)
    @test length(model.rxn_ids) == 1488
    @test length(model.met_ids) == 1079
    @test length(model.lb) == 1488
    @test length(model.ub) == 1488
    @test all(model.lb .<= model.ub)

    for rxn_id in ("r_2111", "r_1714", "r_1709", "r_1761", "r_4046", "r_4047", "r_4048")
        @test has_reaction(model, rxn_id)
    end
    @test !has_reaction(model, "r_1992")

    reaction_map = load_reaction_map(reaction_map_config)
    report = validate_reaction_map(model, reaction_map)

    @test report.ok
    @test report.disabled_reactions["oxygen_exchange"] == "r_1992"
    @test !haskey(report.disabled_reactions, "carbohydrate_exchange")
    @test report.found_required_reactions["carbohydrate_exchange"] == "r_4048"
    @test !haskey(report.missing_required_reactions, "oxygen_exchange")
    @test !haskey(report.missing_required_reactions, "carbohydrate_exchange")
end
