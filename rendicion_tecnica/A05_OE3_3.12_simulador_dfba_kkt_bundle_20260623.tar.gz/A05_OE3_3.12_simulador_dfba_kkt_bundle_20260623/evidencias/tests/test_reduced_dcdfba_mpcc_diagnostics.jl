import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_mpcc_diagnostics_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_mpcc_diagnostics_test_simulation()
    time = [0.0, 0.25]
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    states = hcat(initial_state, initial_state)
    fluxes = reshape([0.02, 0.02], 1, 2)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

@testset "Reduced DC-dFBA MPCC start diagnostics" begin
    model, reaction_map = _reduced_dcdfba_mpcc_diagnostics_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_diagnostics_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)

    @test report isa ReducedDCDFBAMPCCDiagnosticReport
    @test report.metadata["diagnostic_report_built"] == true
    @test report.metadata["diagnostic_source"] == "initial_start_values"
    @test report.metadata["solver_call_performed"] == false
    @test report.metadata["diagnostic_report_is_scientific_simulation"] == false
    @test report.metadata["solve_attempt_is_scientific_simulation"] == false
    @test report.metadata["first_mpcc_target"] == "reduced_dfba"
    @test report.metadata["hsl_required"] == false
    @test report.metadata["ma57_required"] == false
    @test report.metadata["indices_reacciones_used"] == false
    @test report.metadata["r0001_used_as_oxygen"] == false

    expected_keys = [
        "max_rhs_residual",
        "max_mass_balance_residual",
        "max_lower_bound_violation",
        "max_upper_bound_violation",
        "max_stationarity_residual",
        "max_lower_complementarity_residual",
        "max_upper_complementarity_residual",
    ]
    @test sort(collect(keys(report.residual_values))) == sort(expected_keys)
    @test sort(collect(keys(report.residual_thresholds))) == sort(expected_keys)
    @test sort(collect(keys(report.residual_ratios))) == sort(expected_keys)
    @test report.residuals_available == true
    @test report.dominant_residual == first(report.ranked_residuals)
    @test all(isfinite, values(report.residual_values))
    @test all(isfinite, values(report.residual_thresholds))
    @test all(value -> isfinite(value) || isinf(value), values(report.residual_ratios))

    @test report.scaling_summary["state_boundary_start_abs_max"] > 0.0
    @test report.scaling_summary["state_collocation_start_abs_max"] > 0.0
    @test report.scaling_summary["flux_start_abs_max"] >= 0.0
    @test report.scaling_summary["lower_bound_dual_start_abs_max"] > 0.0
    @test report.scaling_summary["upper_bound_dual_start_abs_max"] > 0.0
    @test report.scaling_summary["mass_balance_dual_start_abs_max"] > 0.0
    @test report.scaling_summary["stationarity_dual_start_max_stationarity_residual_after"] <=
          1.0e-10
    @test report.scaling_summary["stationarity_dual_start_max_lower_complementarity_residual_after"] <=
          1.0e-10
    @test report.scaling_summary["stationarity_dual_start_max_upper_complementarity_residual_after"] <=
          1.0e-10
    @test report.scaling_summary["dynamic_lower_bound_reaction_count"] > 0.0
    @test report.scaling_summary["dynamic_upper_bound_reaction_count"] > 0.0
    @test report.warnings isa Vector{String}
    @test report.metadata["diagnostic_warning_count"] == length(report.warnings)
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA MPCC result diagnostics" begin
    thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
    smoke_result = ReducedDCDFBAMPCCSmokeResult(
        MOI.ITERATION_LIMIT,
        MOI.FEASIBLE_POINT,
        0.0,
        2.0e-7,
        0.0,
        0.0,
        3.0e-4,
        0.0,
        0.0,
        "Ipopt",
        0.0,
        Dict{String, Any}(
            "solver_call_performed" => true,
            "solve_attempt_is_scientific_simulation" => false,
        ),
    )
    residual_report = Dict{String, Any}(
        "residuals_available" => true,
        "residual_thresholds_satisfied" => false,
        "max_rhs_residual" => 5.0e-7,
    )
    result = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        thresholds,
        true,
        false,
        residual_report,
        Dict{String, Any}(
            "solver_call_performed" => true,
            "solve_attempt_is_scientific_simulation" => false,
        ),
        nothing,
    )

    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(result)

    @test report isa ReducedDCDFBAMPCCDiagnosticReport
    @test report.metadata["diagnostic_source"] == "solve_result"
    @test report.metadata["solver_call_performed"] == true
    @test report.residuals_available == true
    @test report.residual_thresholds_satisfied == false
    @test report.dominant_residual == "max_stationarity_residual"
    @test isapprox(report.residual_ratios["max_stationarity_residual"], 30.0)
    @test "max_stationarity_residual_above_threshold" in report.warnings
    @test isempty(report.scaling_summary)
    @test report.metadata["diagnostic_report_is_scientific_simulation"] == false
    @test report.metadata["residual_thresholds_are_scientific_acceptance_criteria"] == false
end
