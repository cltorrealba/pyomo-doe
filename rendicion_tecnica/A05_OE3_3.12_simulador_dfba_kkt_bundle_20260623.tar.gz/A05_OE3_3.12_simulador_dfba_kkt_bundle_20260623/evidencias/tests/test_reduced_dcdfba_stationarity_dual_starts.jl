import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_stationarity_dual_starts_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_stationarity_dual_starts_test_simulation()
    time = [0.0, 0.25]
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    states = hcat(initial_state, initial_state)
    fluxes = reshape([0.02, 0.02], 1, 2)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

@testset "Reduced DC-dFBA stationarity dual starts skipped for zero objective" begin
    model, reaction_map = _reduced_dcdfba_stationarity_dual_starts_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map)
    metadata = problem.metadata

    @test metadata["stationarity_dual_start_applied"] == false
    @test metadata["stationarity_dual_start_policy"] == "not_applied_zero_stationarity_objective"
    @test metadata["stationarity_dual_start_collocation_points"] == 0
    @test metadata["stationarity_dual_start_optimal_count"] == 0
    @test metadata["stationarity_dual_start_solver"] == "not_called"
    @test metadata["stationarity_dual_start_objective_nonzero_count"] == 0
    @test metadata["stationarity_dual_start_flux_start_updated"] == false
    @test metadata["stationarity_dual_start_mass_balance_duals_changed"] == false
    @test metadata["stationarity_dual_start_bound_duals_changed"] == false
    @test metadata["stationarity_dual_start_max_stationarity_residual_after"] <= 1.0e-12
    @test metadata["stationarity_dual_start_mass_balance_dual_abs_max"] == 0.0
    @test metadata["stationarity_dual_start_lower_bound_dual_abs_max"] == 0.0
    @test metadata["stationarity_dual_start_upper_bound_dual_abs_max"] == 0.0
    @test metadata["stationarity_dual_start_indices_reacciones_used"] == false
    @test metadata["stationarity_dual_start_r0001_used_as_oxygen"] == false
    @test metadata["stationarity_dual_start_is_scientific_simulation"] == false
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA local LP KKT dual starts metadata" begin
    model, reaction_map = _reduced_dcdfba_stationarity_dual_starts_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        include_rhs = true,
        use_dynamic_bounds = true,
    )
    metadata = problem.metadata

    @test metadata["stationarity_dual_start_applied"] == true
    @test metadata["stationarity_dual_start_policy"] ==
          "solve_local_minimization_lp_for_primal_and_kkt_dual_starts"
    @test metadata["stationarity_dual_start_collocation_points"] == 3
    @test metadata["stationarity_dual_start_optimal_count"] == 3
    @test metadata["stationarity_dual_start_status_counts"]["OPTIMAL"] == 3
    @test metadata["stationarity_dual_start_solver"] == "HiGHS"
    @test metadata["stationarity_dual_start_objective_policy"] ==
          "stationarity_minimization_coefficients"
    @test metadata["stationarity_dual_start_objective_nonzero_count"] == 6
    @test metadata["stationarity_dual_start_flux_start_updated"] == true
    @test metadata["stationarity_dual_start_mass_balance_duals_changed"] == true
    @test metadata["stationarity_dual_start_bound_duals_changed"] == true
    @test metadata["stationarity_dual_start_max_stationarity_residual_before"] >= 1.0
    @test metadata["stationarity_dual_start_max_stationarity_residual_after"] <= 1.0e-10
    @test metadata["stationarity_dual_start_max_lower_complementarity_residual_after"] <= 1.0e-10
    @test metadata["stationarity_dual_start_max_upper_complementarity_residual_after"] <= 1.0e-10
    @test metadata["stationarity_dual_start_max_mass_balance_residual"] <= 1.0e-8
    @test metadata["stationarity_dual_start_max_lower_bound_violation"] <= 1.0e-8
    @test metadata["stationarity_dual_start_max_upper_bound_violation"] <= 1.0e-8
    @test metadata["stationarity_dual_start_mass_balance_dual_abs_max"] > 0.0
    @test metadata["stationarity_dual_start_lower_bound_dual_abs_max"] > 0.0
    @test metadata["stationarity_dual_start_upper_bound_dual_abs_max"] > 0.0
    @test metadata["stationarity_dual_start_max_dual_sign_clipping"] <= 1.0e-12
    @test metadata["stationarity_dual_start_indices_reacciones_used"] == false
    @test metadata["stationarity_dual_start_r0001_used_as_oxygen"] == false
    @test metadata["stationarity_dual_start_is_scientific_simulation"] == false
    @test problem.nlp.metadata["stationarity_dual_start_applied"] == true
    @test problem.metadata["rhs_consistent_derivative_start_max_rhs_residual_after"] <= 1.0e-12
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA fixed-flux stationarity dual fit preserves flux starts" begin
    model, reaction_map = _reduced_dcdfba_stationarity_dual_starts_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        include_rhs = true,
        use_dynamic_bounds = true,
    )
    flux_before = map(value -> Float64(JuMP.start_value(value)), problem.nlp.flux)

    for value in problem.bound_feasibility.lower_bound_duals
        JuMP.set_start_value(value, 0.0)
    end
    for value in problem.bound_feasibility.upper_bound_duals
        JuMP.set_start_value(value, 0.0)
    end
    for value in problem.stationarity.mass_balance_duals
        JuMP.set_start_value(value, 0.0)
    end

    metadata =
        FermentationDFBA._reduced_dcdfba_apply_fixed_flux_stationarity_dual_fit_starts!(
            problem;
            complementarity_tau = 1.0e-4,
        )
    flux_after = map(value -> Float64(JuMP.start_value(value)), problem.nlp.flux)

    @test metadata["fixed_flux_stationarity_dual_fit_applied"] == true
    @test metadata["fixed_flux_stationarity_dual_fit_flux_start_updated"] == false
    @test metadata["fixed_flux_stationarity_dual_fit_optimal_count"] == 3
    @test metadata["fixed_flux_stationarity_dual_fit_status_counts"]["OPTIMAL"] == 3
    @test maximum(abs.(flux_after .- flux_before)) <= 1.0e-12
    @test metadata["fixed_flux_stationarity_dual_fit_max_stationarity_residual_before"] >=
          1.0
    @test metadata["fixed_flux_stationarity_dual_fit_max_stationarity_residual_after"] <=
          1.0e-7
    @test metadata["fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after"] <=
          1.0e-4 + 1.0e-8
    @test metadata["fixed_flux_stationarity_dual_fit_max_upper_complementarity_residual_after"] <=
          1.0e-4 + 1.0e-8
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA solve-attempt diagnostics after stationarity dual starts" begin
    model, reaction_map = _reduced_dcdfba_stationarity_dual_starts_test_model_and_map()
    simulation = _reduced_dcdfba_stationarity_dual_starts_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)

    @test report.metadata["stationarity_dual_start_applied"] == true
    @test report.scaling_summary["stationarity_dual_start_collocation_points"] == 3.0
    @test report.scaling_summary["stationarity_dual_start_optimal_count"] == 3.0
    @test report.scaling_summary["stationarity_dual_start_max_stationarity_residual_before"] >= 0.0
    @test report.scaling_summary["stationarity_dual_start_max_stationarity_residual_after"] <= 1.0e-10
    @test report.scaling_summary["stationarity_dual_start_max_lower_complementarity_residual_after"] <= 1.0e-10
    @test report.scaling_summary["stationarity_dual_start_max_upper_complementarity_residual_after"] <= 1.0e-10
    @test report.residual_values["max_stationarity_residual"] <= 1.0e-10
    @test report.residual_values["max_lower_complementarity_residual"] <= 1.0e-10
    @test report.residual_values["max_upper_complementarity_residual"] <= 1.0e-10
    @test report.residual_thresholds_satisfied == true
    @test !("max_stationarity_residual_above_threshold" in report.warnings)
    @test !("stationarity_dual_start_dual_sign_clipping_large" in report.warnings)
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end
