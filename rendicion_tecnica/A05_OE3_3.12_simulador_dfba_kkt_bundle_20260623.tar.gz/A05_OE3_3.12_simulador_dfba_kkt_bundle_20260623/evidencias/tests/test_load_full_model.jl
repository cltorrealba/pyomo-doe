using SparseArrays

function _write_synthetic_full_model_fixture(dir::AbstractString; bad_ub_length::Bool = false)
    model_dir = joinpath(dir, "data", "full")
    config_dir = joinpath(dir, "config")
    mkpath(model_dir)
    mkpath(config_dir)

    write(joinpath(model_dir, "S_matrix.csv"), "metabolite_id,r_a,r_b,r_c\nm1,1,0,-1\nm2,0,2,-2\n")
    write(joinpath(model_dir, "lb_vector.csv"), "0\n-10\n0\n")
    ub_contents = bad_ub_length ? "ub\n100\n10\n" : "ub\n100\n10\n100\n"
    write(joinpath(model_dir, "ub_vector.csv"), ub_contents)

    config_path = joinpath(config_dir, "full_model_paths.example.toml")
    write(
        config_path,
        """
        model_id = "synthetic_full_config"

        base_dir = "data/full"
        s = "S_matrix.csv"
        lb = "lb_vector.csv"
        ub = "ub_vector.csv"
        """,
    )
    return config_path
end

@testset "Full model path config loader" begin
    mktempdir() do dir
        config_path = _write_synthetic_full_model_fixture(dir)
        paths = load_full_model_paths(config_path)

        @test paths.model_id == "synthetic_full_config"
        @test isfile(paths.s_path)
        @test isfile(paths.lb_path)
        @test isfile(paths.ub_path)
        @test validate_model_files(paths).ok
    end
end

@testset "Full model loader synthetic fixture" begin
    mktempdir() do dir
        config_path = _write_synthetic_full_model_fixture(dir)
        model = load_full_model(config_path)

        @test model.model_id == "synthetic_full_config"
        @test size(model.S) == (2, 3)
        @test model.S isa SparseMatrixCSC{Float64, Int}
        @test model.S[1, 1] == 1.0
        @test model.S[2, 2] == 2.0
        @test model.rxn_ids == ["r_a", "r_b", "r_c"]
        @test model.met_ids == ["m1", "m2"]
        @test model.lb == [0.0, -10.0, 0.0]
        @test model.ub == [100.0, 10.0, 100.0]
        @test validate_full_model_dimensions(model).ok
    end
end

@testset "Full model validation rejects invalid synthetic models" begin
    bad_bounds = MetabolicModel(
        reshape([1.0], 1, 1),
        [1.0],
        [0.0],
        ["r_a"],
        ["m1"];
        model_id = "bad_bounds",
    )
    @test !validate_full_model_dimensions(bad_bounds).ok
    @test_throws ErrorException validate_full_model_dimensions(bad_bounds; throw_on_error = true)

    bad_dimensions = MetabolicModel(
        [1.0 0.0],
        [0.0],
        [1.0],
        ["r_a", "r_b"],
        ["m1"];
        model_id = "bad_dimensions",
    )
    @test !validate_full_model_dimensions(bad_dimensions).ok

    duplicated_reactions = MetabolicModel(
        [1.0 0.0],
        [0.0, 0.0],
        [1.0, 1.0],
        ["r_a", "r_a"],
        ["m1"];
        model_id = "duplicated_reactions",
    )
    @test !validate_full_model_dimensions(duplicated_reactions).ok

    nonfinite_s = MetabolicModel(
        reshape([NaN], 1, 1),
        [0.0],
        [1.0],
        ["r_a"],
        ["m1"];
        model_id = "nonfinite_s",
    )
    @test !validate_full_model_dimensions(nonfinite_s).ok

    mktempdir() do dir
        config_path = _write_synthetic_full_model_fixture(dir; bad_ub_length = true)
        @test_throws ErrorException load_full_model(config_path)
    end
end
