import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_collocation_nlp_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

@testset "Reduced DC-dFBA collocation NLP scaffold contract" begin
    model, reaction_map = _reduced_dcdfba_collocation_nlp_test_model_and_map()
    grid = build_finite_element_grid((0.0, 0.25); nfe = 1, degree = 3)
    kkt_problem = build_kkt_dfba_problem(model, reaction_map, grid)
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    nlp = build_reduced_dcdfba_collocation_nlp(kkt_problem; initial_state = initial_state)

    @test nlp isa ReducedDCDFBACollocationNLP
    @test nlp.kkt_problem === kkt_problem
    @test nlp.jump_model isa JuMP.Model
    @test nlp.dimensions isa ReducedDCDFBACollocationNLPDimensions
    @test nlp.initial_state == initial_state

    dimensions = nlp.dimensions
    @test dimensions.n_states == 19
    @test dimensions.n_reactions == size(model.S, 2) == 1488
    @test dimensions.nfe == 1
    @test dimensions.collocation_degree == 3
    @test dimensions.n_collocation_points == 3
    @test dimensions.n_state_boundary_variables == 19 * 2
    @test dimensions.n_state_collocation_variables == 19 * 3
    @test dimensions.n_state_derivative_variables == 19 * 3
    @test dimensions.n_flux_variables == 1488 * 3
    @test dimensions.n_total_variables ==
        dimensions.n_state_boundary_variables +
        dimensions.n_state_collocation_variables +
        dimensions.n_state_derivative_variables +
        dimensions.n_flux_variables
    @test dimensions.n_collocation_integration_constraints == 19 * 3
    @test dimensions.n_continuity_constraints == 19
    @test dimensions.n_initial_condition_constraints == 19
    @test dimensions.n_total_constraints ==
        dimensions.n_collocation_integration_constraints +
        dimensions.n_continuity_constraints +
        dimensions.n_initial_condition_constraints

    @test size(nlp.state_boundary) == (19, 2)
    @test size(nlp.state_collocation) == (19, 1, 3)
    @test size(nlp.state_derivative) == (19, 1, 3)
    @test size(nlp.flux) == (1488, 1, 3)
    @test length(nlp.collocation_integration_constraints) == dimensions.n_collocation_integration_constraints
    @test length(nlp.continuity_constraints) == dimensions.n_continuity_constraints
    @test length(nlp.initial_condition_constraints) == dimensions.n_initial_condition_constraints
    @test JuMP.num_variables(nlp.jump_model) == dimensions.n_total_variables
    @test JuMP.objective_sense(nlp.jump_model) == MOI.MIN_SENSE
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA collocation NLP variable starts and bounds" begin
    model, reaction_map = _reduced_dcdfba_collocation_nlp_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    initial_state = nlp.initial_state

    for state_index in (1, 6, 8, 19)
        @test JuMP.start_value(nlp.state_boundary[state_index, 1]) == initial_state[state_index]
        @test JuMP.start_value(nlp.state_boundary[state_index, 2]) == initial_state[state_index]
        @test JuMP.start_value(nlp.state_collocation[state_index, 1, 1]) == initial_state[state_index]
        @test JuMP.start_value(nlp.state_derivative[state_index, 1, 1]) == 0.0
    end
    @test !JuMP.has_lower_bound(nlp.state_boundary[1, 1])
    @test !JuMP.has_lower_bound(nlp.state_collocation[1, 1, 1])
    @test !JuMP.has_lower_bound(nlp.state_derivative[1, 1, 1])
    @test nlp.metadata["state_nonnegative_bounds_enabled"] == false
    @test nlp.metadata["state_nonnegative_boundary_lower_bound_count"] == 0
    @test nlp.metadata["state_nonnegative_collocation_lower_bound_count"] == 0
    @test nlp.metadata["state_nonnegative_derivative_lower_bound_count"] == 0

    bounded_nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
        state_nonnegative_bounds = true,
    )
    @test JuMP.has_lower_bound(bounded_nlp.state_boundary[1, 1])
    @test JuMP.lower_bound(bounded_nlp.state_boundary[1, 1]) == 0.0
    @test JuMP.has_lower_bound(bounded_nlp.state_collocation[1, 1, 1])
    @test JuMP.lower_bound(bounded_nlp.state_collocation[1, 1, 1]) == 0.0
    @test !JuMP.has_lower_bound(bounded_nlp.state_derivative[1, 1, 1])
    @test bounded_nlp.metadata["state_nonnegative_bounds_enabled"] == true
    @test bounded_nlp.metadata["state_nonnegative_boundary_lower_bound_count"] == 19 * 2
    @test bounded_nlp.metadata["state_nonnegative_collocation_lower_bound_count"] == 19 * 3
    @test bounded_nlp.metadata["state_nonnegative_derivative_lower_bound_count"] == 0

    reaction_samples = [
        reaction_index(model, nlp.kkt_problem.reaction_roles.biomass_growth),
        reaction_index(model, nlp.kkt_problem.reaction_roles.glucose_exchange),
        reaction_index(model, nlp.kkt_problem.reaction_roles.fructose_exchange),
        reaction_index(model, nlp.kkt_problem.reaction_roles.ethanol_exchange),
    ]
    for reaction_index_value in reaction_samples
        variable = nlp.flux[reaction_index_value, 1, 1]
        @test JuMP.lower_bound(variable) == model.lb[reaction_index_value]
        @test JuMP.upper_bound(variable) == model.ub[reaction_index_value]
        @test JuMP.start_value(variable) ==
            clamp(0.0, model.lb[reaction_index_value], model.ub[reaction_index_value])
    end

    fixed_reaction_index = reaction_index(model, "r_0217")
    fixed_variable = nlp.flux[fixed_reaction_index, 1, 1]
    @test JuMP.lower_bound(fixed_variable) == 0.0
    @test JuMP.upper_bound(fixed_variable) == 0.0
    @test nlp.metadata["fixed_flux_variable_bounds_deferred"] == false
    @test nlp.metadata["fixed_flux_reaction_count"] == 7
    @test nlp.metadata["fixed_flux_collocation_variable_count"] == 21
end

@testset "Reduced DC-dFBA collocation NLP metadata guardrails" begin
    model, reaction_map = _reduced_dcdfba_collocation_nlp_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    metadata = nlp.metadata

    @test metadata["problem_type"] == "reduced_dcdfba_collocation_nlp_scaffold"
    @test metadata["model_scope"] == "reduced"
    @test metadata["grid_tspan"] == (0.0, 0.25)
    @test metadata["grid_nfe"] == 1
    @test metadata["collocation_degree"] == 3
    @test metadata["jump_model_built"] == true
    @test metadata["solver_call_performed"] == false
    @test metadata["optimizer"] == "Ipopt"
    @test metadata["linear_solver"] == "mumps"
    @test metadata["ipopt_required"] == true
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["state_variables_built"] == true
    @test metadata["state_derivative_variables_built"] == true
    @test metadata["flux_variables_built"] == true
    @test metadata["base_flux_bounds_applied"] == true
    @test metadata["dynamic_flux_bounds_applied"] == false
    @test metadata["collocation_integration_constraints_built"] == true
    @test metadata["finite_element_continuity_constraints_built"] == true
    @test metadata["initial_condition_constraints_built"] == true
    @test metadata["ode_rhs_constraints_built"] == false
    @test metadata["mass_balance_constraints_built"] == false
    @test metadata["bound_feasibility_constraints_built"] == false
    @test metadata["stationarity_constraints_built"] == false
    @test metadata["kkt_constraints_built"] == false
    @test metadata["mpcc_complementarity_built"] == false
    @test metadata["direct_collocation_dynamic_constraints_built"] == false
    @test metadata["sequential_initialization_built"] == false
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["sequential_scientific_baseline"] == "full_dfba_cold"
    @test metadata["persistent_lp_warm_start_policy"] == "diagnostic_only_not_scientific_equivalence"
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["oxygen_exchange_reaction_id"] == "r_1992"
    @test metadata["oxygen_exchange_present"] == false
    @test metadata["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test metadata["carbohydrate_exchange_reaction_id"] == "r_4048"
    @test metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test metadata["weighted_objective_value_is_biomass_flux"] == false
end

@testset "Reduced DC-dFBA collocation NLP validation" begin
    model, reaction_map = _reduced_dcdfba_collocation_nlp_test_model_and_map()

    @test_throws ArgumentError build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
        initial_state = zeros(18),
    )
    invalid_state = zenteno_state_to_vector(default_zenteno_initial_state())
    invalid_state[3] = NaN
    @test_throws ArgumentError build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
        initial_state = invalid_state,
    )
    @test_throws ArgumentError build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
        degree = 2,
    )
    @test_throws ArgumentError build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 0,
    )
    @test_throws ArgumentError build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
        model_scope = "full",
    )
end
