const REDUCED_MPCC_FAILURE_TEST_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _reduced_mpcc_failure_test_comparison()
    times = [0.0, 0.25]
    states = zeros(19, 2)
    states[1, :] .= [0.5, 0.51]
    states[2, :] .= [0.07, 0.069]
    states[3, :] .= [110.0, 109.9]
    states[4, :] .= [110.0, 109.95]
    states[6, :] .= 0.0
    states[7, :] .= [0.23, 0.24]
    states[8, :] .= [0.185, 0.19]
    states[9:19, :] .= 0.1

    sequential = SimulationResult(
        times,
        states;
        metadata = Dict{String, Any}(
            "model_id" => "synthetic_reduced_sequential_window",
            "model_scope" => "reduced",
            "state_names" => copy(REDUCED_MPCC_FAILURE_TEST_STATE_NAMES),
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "mode_history" => Symbol[],
            "mass_balance_residuals" => Float64[],
            "max_lower_bound_violations" => Float64[],
            "max_upper_bound_violations" => Float64[],
            "min_state_value" => minimum(states),
            "has_negative_saved_states" => false,
            "reconstruct_fluxes" => false,
        ),
    )

    boundary_metadata = Dict{String, Any}(
        "model_id" => "synthetic_reduced_mpcc_window",
        "model_scope" => "reduced",
        "state_names" => copy(REDUCED_MPCC_FAILURE_TEST_STATE_NAMES),
        "retcode" => "ITERATION_LIMIT",
        "termination_reason" => "windowed_mpcc_candidate_diagnostic_only",
        "is_scientific_simulation" => false,
        "min_state_value" => minimum(states),
    )
    boundary = SimulationResult(times, copy(states); metadata = boundary_metadata)
    collocation_times = [0.05, 0.15, 0.25]
    collocation_states = repeat(states[:, 2:2], 1, 3)
    collocation = SimulationResult(
        collocation_times,
        collocation_states;
        metadata = copy(boundary_metadata),
    )

    flux = zeros(2, 1, 3)
    flux[:, 1, 1] .= [5.0e-7, 0.0]
    flux[:, 1, 2] .= [2.0e-6, 0.0]
    flux[:, 1, 3] .= [1.0e-7, 0.0]
    residuals = Dict{String, Float64}(
        "max_rhs_residual" => 1.0e-12,
        "max_mass_balance_residual" => 2.0e-6,
        "max_lower_bound_violation" => 0.0,
        "max_upper_bound_violation" => 0.0,
        "max_stationarity_residual" => 1.0e-8,
        "max_lower_complementarity_residual" => 1.0e-7,
        "max_upper_complementarity_residual" => 1.0e-7,
    )
    candidate_metadata = Dict{String, Any}(
        "candidate_solver_status" => "ITERATION_LIMIT",
        "candidate_primal_status" => "FEASIBLE_POINT",
        "candidate_residual_thresholds_satisfied" => false,
        "candidate_residual_feasible" => false,
        "candidate_iteration_limit_residual_feasible" => false,
        "candidate_warning_count" => 2,
        "candidate_dominant_residual" => "max_mass_balance_residual",
        "candidate_trajectory_extraction_ready" => false,
        "trajectory_candidate_ready" => false,
        "trajectory_candidate_is_scientific_simulation" => false,
        "trajectory_candidate_is_validated_simulation" => false,
        "trajectory_candidate_solved_trajectory_claimed" => false,
        "post_solve_next_recommended_action" => "improve_residuals_before_trajectory_extraction",
        "solve_elapsed_seconds" => 1.5,
        "candidate_grid_nfe" => 1,
        "candidate_collocation_degree" => 3,
        "candidate_grid_tspan" => (0.0, 0.25),
        "candidate_boundary_times" => copy(times),
        "candidate_collocation_times" => copy(collocation_times),
        "candidate_state_names" => copy(REDUCED_MPCC_FAILURE_TEST_STATE_NAMES),
    )
    diagnostics = ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(states),
        reshape(copy(collocation_states), 19, 1, 3),
        zeros(19, 1, 3),
        flux,
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(1, 1, 3),
        residuals,
        Dict{String, Float64}(
            "max_rhs_residual" => 1.0e-6,
            "max_mass_balance_residual" => 1.0e-6,
            "max_lower_bound_violation" => 1.0e-6,
            "max_upper_bound_violation" => 1.0e-6,
            "max_stationarity_residual" => 1.0e-5,
            "max_lower_complementarity_residual" => 1.0e-5,
            "max_upper_complementarity_residual" => 1.0e-5,
        ),
        Dict{String, Float64}(),
        ["max_mass_balance_residual"],
        ["candidate_residual_thresholds_failed"],
        copy(candidate_metadata),
    )
    trajectory_metadata = copy(candidate_metadata)
    trajectory_metadata["model_scope"] = "reduced"
    trajectory = ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary,
        collocation,
        diagnostics,
        trajectory_metadata,
    )
    return compare_reduced_dcdfba_mpcc_to_sequential(sequential, trajectory)
end

@testset "Reduced MPCC windowed failure diagnostics mass-balance localization" begin
    comparison = _reduced_mpcc_failure_test_comparison()
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([comparison])
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 0.25,
    )
    model = MetabolicModel(
        [1.0 -1.0],
        [-10.0, -10.0],
        [10.0, 10.0],
        ["r_a", "r_b"],
        ["met_a"];
        model_id = "synthetic_reduced_mass_balance_model",
    )

    diagnostic = diagnose_reduced_dcdfba_mpcc_windowed_failure(
        attempt,
        model;
        top_n_mass_balance = 3,
    )

    @test diagnostic isa ReducedDCDFBAMPCCWindowedFailureDiagnosticResult
    @test size(diagnostic.window_summary_table, 1) == 2
    @test size(diagnostic.residual_ratio_table, 1) == 14
    @test size(diagnostic.mass_balance_table, 1) == 3
    @test diagnostic.metadata["diagnostic_type"] ==
          "reduced_dcdfba_mpcc_windowed_failure_diagnostics"
    @test diagnostic.metadata["first_red_window_id"] == "window_001"
    @test diagnostic.metadata["first_not_residual_feasible_window_id"] == "window_001"
    @test diagnostic.metadata["dominant_residual_name"] == "max_mass_balance_residual"
    @test diagnostic.metadata["dominant_residual_ratio"] == 2.0
    @test diagnostic.metadata["dominant_mass_balance_candidate_id"] == "window_001"
    @test diagnostic.metadata["dominant_mass_balance_metabolite_id"] == "met_a"
    @test diagnostic.metadata["dominant_mass_balance_element_index"] == 1
    @test diagnostic.metadata["dominant_mass_balance_collocation_index"] == 2
    @test diagnostic.metadata["dominant_mass_balance_residual"] == 2.0e-6
    @test diagnostic.metadata["dominant_mass_balance_ratio"] == 2.0
    @test diagnostic.metadata["recommended_next_action"] ==
          "inspect_mass_balance_row_scaling_and_flux_starts"
    @test diagnostic.metadata["outputs_written"] == false
    @test diagnostic.metadata["failure_diagnostic_is_scientific_simulation"] == false
    @test diagnostic.metadata["first_mpcc_target"] == "reduced_dfba"
    @test diagnostic.metadata["hsl_required"] == false
    @test diagnostic.metadata["ma57_required"] == false
    @test diagnostic.metadata["indices_reacciones_used"] == false
    @test diagnostic.metadata["r0001_used_as_oxygen"] == false

    mass_table = diagnostic.mass_balance_table
    @test mass_table[1, "candidate_id"] == "window_001"
    @test mass_table[1, "metabolite_id"] == "met_a"
    @test mass_table[1, "is_window_max"] == true
    @test mass_table[1, "is_attempt_max"] == true
    @test mass_table[1, "ratio"] == 2.0
end

@testset "Reduced MPCC windowed failure diagnostics validation" begin
    comparison = _reduced_mpcc_failure_test_comparison()
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([comparison])
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 0.25,
    )
    model = MetabolicModel(
        [1.0 -1.0],
        [-10.0, -10.0],
        [10.0, 10.0],
        ["r_a", "r_b"],
        ["met_a"];
        model_id = "synthetic_reduced_mass_balance_model",
    )
    bad_model = MetabolicModel(
        [1.0 0.0 0.0],
        [-10.0, -10.0, -10.0],
        [10.0, 10.0, 10.0],
        ["r_a", "r_b", "r_c"],
        ["met_a"];
        model_id = "bad_synthetic_model",
    )

    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_windowed_failure(
        attempt,
        model;
        top_n_mass_balance = 0,
    )
    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_windowed_failure(
        attempt,
        bad_model,
    )
end
