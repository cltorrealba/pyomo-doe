import DataFrames: DataFrame
import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_mpcc_solve_attempt_test_simulation(;
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state()),
)
    time = [0.0, 0.25]
    states = hcat(initial_state, initial_state)
    fluxes = reshape([0.02, 0.02], 1, 2)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

@testset "Reduced DC-dFBA MPCC residual thresholds" begin
    thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()

    @test thresholds isa ReducedDCDFBAMPCCResidualThresholds
    @test thresholds.max_rhs_residual == 1.0e-6
    @test thresholds.max_mass_balance_residual == 1.0e-6
    @test thresholds.max_lower_bound_violation == 1.0e-6
    @test thresholds.max_upper_bound_violation == 1.0e-6
    @test thresholds.max_stationarity_residual == 1.0e-5
    @test thresholds.max_lower_complementarity_residual == 1.0e-5
    @test thresholds.max_upper_complementarity_residual == 1.0e-5

    custom = default_reduced_dcdfba_mpcc_residual_thresholds(; max_rhs_residual = 2.0e-4)
    @test custom.max_rhs_residual == 2.0e-4
    @test_throws ArgumentError default_reduced_dcdfba_mpcc_residual_thresholds(;
        max_rhs_residual = -1.0,
    )
end

@testset "Reduced DC-dFBA MPCC Ipopt stability profiles" begin
    @test reduced_mpcc_ipopt_profile_names() ==
          ["strict", "acceptable", "feasibility_first", "feasibility_handoff", "stability"]

    acceptable = reduced_mpcc_ipopt_profile()
    @test acceptable isa ReducedMPCCIpoptProfile
    @test acceptable.name == "acceptable"
    @test acceptable.tol == 1.0e-6
    @test acceptable.acceptable_dual_inf_tol == 1.0e-5
    @test acceptable.fixed_variable_treatment == "relax_bounds"

    stability = reduced_mpcc_ipopt_profile("stability")
    @test stability.acceptable_dual_inf_tol == 1.0e3
    @test stability.acceptable_constr_viol_tol == 5.0e-6
    @test stability.bound_push == 1.0e-8
    @test stability.honor_original_bounds == "yes"

    optimizer = reduced_mpcc_ipopt_optimizer(; profile = "feasibility_first", max_iter = 0)
    problem = build_reduced_toy_nlp_smoke_problem(; optimizer = optimizer)
    @test problem isa ReducedToyNLPProblem

    old_env = get(ENV, "MPCC_REDUCED_MPCC_IPOPT_PROFILE", nothing)
    try
        ENV["MPCC_REDUCED_MPCC_IPOPT_PROFILE"] = "stability"
        @test reduced_mpcc_ipopt_profile_name_from_env() == "stability"
    finally
        if old_env === nothing
            delete!(ENV, "MPCC_REDUCED_MPCC_IPOPT_PROFILE")
        else
            ENV["MPCC_REDUCED_MPCC_IPOPT_PROFILE"] = old_env
        end
    end

    @test_throws ArgumentError reduced_mpcc_ipopt_profile("not_a_profile")
end

@testset "Reduced MPCC NLP structure audit counts fixed-variable pressure" begin
    model = JuMP.Model()
    JuMP.@variable(model, 0.0 <= x <= 1.0)
    JuMP.@variable(model, y)
    JuMP.@variable(model, 0.0 <= z <= 1.0e-12)
    JuMP.fix(y, 2.0; force = true)
    JuMP.@constraint(model, x + y == 3.0)
    JuMP.@constraint(model, x + y <= 3.5)

    audit = audit_reduced_mpcc_nlp_structure(model; nearly_fixed_tol = 1.0e-9)

    @test audit isa ReducedMPCCNLPStructureAudit
    @test audit.n_total_variables == 3
    @test audit.n_equality_constraints == 1
    @test audit.n_inequality_constraints == 1
    @test audit.n_fixed_variables == 1
    @test audit.n_nearly_fixed_variables == 1
    @test audit.n_variables_with_lower_and_upper_bounds == 2
    @test audit.n_variables_with_no_bounds == 1
    @test audit.n_effective_variables == audit.n_total_variables - audit.n_fixed_variables
    @test audit.dof_balance == audit.n_effective_variables - audit.n_equality_constraints
    @test audit.too_few_degrees_of_freedom_risk == (audit.dof_balance < 0)
    @test audit.metadata["nlp_structure_audit_built"] == true
    @test audit.metadata["nlp_structure_solver_call_performed"] == false
    @test audit.metadata["nlp_structure_mutates_model"] == false
    @test_throws ArgumentError audit_reduced_mpcc_nlp_structure(
        model;
        nearly_fixed_tol = -1.0,
    )
end

@testset "Reduced DC-dFBA MPCC solve-attempt problem contract" begin
    model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation()
    thresholds = default_reduced_dcdfba_mpcc_residual_thresholds(; max_stationarity_residual = 1.0)
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        residual_thresholds = thresholds,
        ipopt_max_iter = 0,
    )

    @test problem isa ReducedDCDFBAMPCCSolveAttemptProblem
    @test problem.smoke_problem isa ReducedDCDFBAMPCCSmokeProblem
    @test problem.residual_thresholds === thresholds
    @test problem.smoke_problem.rhs_residuals isa ReducedDCDFBARHSResidualScaffold
    @test problem.smoke_problem.dynamic_bounds isa ReducedDCDFBADynamicBoundsScaffold
    @test problem.smoke_problem.sequential_initialization isa ReducedDCDFBASequentialInitialization
    @test problem.smoke_problem.nlp.initial_state == simulation.states[:, 1]
    @test problem.metadata["mpcc_initial_state_source"] ==
          "sequential_initialization_first_saved_state"
    @test problem.metadata["mpcc_initial_state_matches_sequential_initialization"] == true
    @test problem.smoke_problem.primal_feasibility.layout.total_primal_feasibility_constraints == 1079 * 3
    @test problem.smoke_problem.complementarity.layout.n_total_complementarity_constraints == 2 * 1488 * 3
    audit = audit_reduced_mpcc_nlp_structure(problem)
    @test audit.n_total_variables == problem.metadata["nlp_structure_total_variables"]
    @test audit.n_equality_constraints ==
          problem.metadata["nlp_structure_equality_constraints"]
    @test problem.metadata["nlp_structure_audit_built"] == true
    @test problem.metadata["nlp_structure_effective_variable_count"] ==
          problem.metadata["nlp_structure_total_variables"] -
          problem.metadata["nlp_structure_fixed_variable_count"]
    @test problem.metadata["nlp_structure_dof_balance"] ==
          problem.metadata["nlp_structure_effective_variable_count"] -
          problem.metadata["nlp_structure_equality_constraints"]
    @test problem.metadata["nlp_structure_fixed_variable_count"] == 0
    @test problem.metadata["nlp_structure_dof_balance"] > 0
    @test problem.metadata["nlp_structure_too_few_degrees_of_freedom_risk"] ==
          (problem.metadata["nlp_structure_dof_balance"] < 0)
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA MPCC dynamic-control decision scaffold" begin
    model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation()
    schedule = reference_dynamic_control_schedule(
        horizon_h = 24.0,
        control_interval_h = 12.0,
        temperature_values_C = [20.0, 20.5],
        fda_doses_g_L = [0.0],
        organic_doses_g_L = [0.0],
    )
    spec = dynamic_control_decision_spec(
        schedule;
        temperature_free_indices = [2],
        addition_free_indices = [1],
        temperature_trust_region_C = 0.25,
        fda_trust_region_g_L = 0.10,
        organic_trust_region_g_L = 0.02,
    )
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = spec,
        ipopt_max_iter = 0,
    )

    scaffold = problem.smoke_problem.dynamic_control_decisions
    @test scaffold isa ReducedDCDFBADynamicControlDecisionScaffold
    @test scaffold.spec === spec
    @test length(scaffold.temperature_variables) == 2
    @test length(scaffold.fda_variables) == 1
    @test length(scaffold.organic_variables) == 1
    @test problem.metadata["mpcc_dynamic_control_variable_policy"] ==
          "coupled_control_decision_variables"
    @test problem.metadata["control_variable_count"] == 4
    @test problem.metadata["control_free_variable_count"] == 3
    @test problem.metadata["control_fixed_variable_count"] == 1
    @test problem.metadata["free_temperature_count"] == 1
    @test problem.metadata["free_fda_count"] == 1
    @test problem.metadata["free_organic_count"] == 1
    @test problem.metadata["control_bounds_ok"] == true
    @test problem.metadata["control_starts_ok"] == true
    @test problem.metadata["fully_simultaneous_controls"] == true
    @test problem.metadata["mpcc_dynamic_control_variables_coupled_to_rhs"] == true
    @test problem.metadata["mpcc_dynamic_control_variables_coupled_to_dynamic_bounds"] == true
    @test problem.metadata["rhs_residual_uses_control_decision_variables"] == true
    @test problem.metadata["dynamic_flux_bounds_use_control_decision_variables"] == true
    @test problem.metadata["mpcc_dynamic_control_decision_embedding_ready"] == true
    @test problem.metadata["dynamic_control_reference_regularization_enabled"] == false
    @test problem.metadata["dynamic_control_reference_regularization_weight"] == 0.0
    @test problem.metadata["dynamic_control_reference_regularization_term_count"] == 0
    @test JuMP.start_value(scaffold.temperature_variables[1]) == 20.0
    @test JuMP.lower_bound(scaffold.temperature_variables[1]) == 20.0
    @test JuMP.upper_bound(scaffold.temperature_variables[1]) == 20.0
    @test JuMP.start_value(scaffold.temperature_variables[2]) == 20.5
    @test JuMP.lower_bound(scaffold.temperature_variables[2]) == 20.25
    @test JuMP.upper_bound(scaffold.temperature_variables[2]) == 20.75
    @test JuMP.start_value(scaffold.fda_variables[1]) == 0.0
    @test JuMP.lower_bound(scaffold.fda_variables[1]) == 0.0
    @test JuMP.upper_bound(scaffold.fda_variables[1]) == 0.10
    @test JuMP.start_value(scaffold.organic_variables[1]) == 0.0
    @test JuMP.lower_bound(scaffold.organic_variables[1]) == 0.0
    @test JuMP.upper_bound(scaffold.organic_variables[1]) == 0.02
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
    pre_solve_values =
        FermentationDFBA._reduced_dcdfba_mpcc_pre_solve_candidate_value_arrays_or_nothing(
            problem.smoke_problem,
        )
    @test pre_solve_values !== nothing
    @test pre_solve_values.dynamic_control_temperature_C == [20.0, 20.5]
    @test pre_solve_values.dynamic_control_fda_g_L == [0.0]
    @test pre_solve_values.dynamic_control_organic_g_L == [0.0]
    captured_controls =
        FermentationDFBA._reduced_dcdfba_mpcc_candidate_dynamic_control_values(pre_solve_values)
    @test captured_controls !== nothing
    captured_temperature_18h =
        FermentationDFBA._reduced_dcdfba_dynamic_control_temperature_C_value(
            scaffold,
            captured_controls,
            18.0,
        )
    JuMP.set_start_value(scaffold.temperature_variables[2], 20.75)
    @test FermentationDFBA._reduced_dcdfba_dynamic_control_temperature_C_value(
        scaffold,
        captured_controls,
        18.0,
    ) == captured_temperature_18h
    @test FermentationDFBA._reduced_dcdfba_dynamic_control_temperature_C_value(
        scaffold,
        18.0,
    ) > captured_temperature_18h

    regularized_problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = spec,
        dynamic_control_reference_regularization_weight = 1.0,
        ipopt_max_iter = 0,
    )
    @test regularized_problem.metadata["dynamic_control_reference_regularization_enabled"] == true
    @test regularized_problem.metadata["dynamic_control_reference_regularization_weight"] == 1.0
    @test regularized_problem.metadata["dynamic_control_reference_regularization_term_count"] == 3
    @test regularized_problem.metadata["dynamic_control_reference_regularization_temperature_terms"] == 1
    @test regularized_problem.metadata["dynamic_control_reference_regularization_fda_terms"] == 1
    @test regularized_problem.metadata["dynamic_control_reference_regularization_organic_terms"] == 1

    objective_config = ReducedDCDFBADynamicControlObjectiveConfig(
        mode = "aroma_nutrient_energy",
        target_state = "isoamyl_acetate",
        terminal_reward_weight = 0.25,
        nutrient_weight = 0.1,
        thermal_energy_weight = 0.05,
        temperature_smoothness_weight = 0.05,
    )
    objective_problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = spec,
        dynamic_control_objective_config = objective_config,
        ipopt_max_iter = 0,
    )
    @test objective_problem.metadata["dynamic_control_objective_enabled"] == true
    @test objective_problem.metadata["dynamic_control_objective_mode"] ==
          "aroma_nutrient_energy"
    @test objective_problem.metadata["dynamic_control_objective_requested_target_state"] ==
          "isoamyl_acetate"
    @test objective_problem.metadata["dynamic_control_objective_resolved_target_state"] ==
          "isoamyl_alcohol"
    @test objective_problem.metadata["dynamic_control_objective_target_state_alias_policy"] ==
          "isoamyl_acetate_not_explicit_in_reduced_state_vector"
    @test objective_problem.metadata["dynamic_control_objective_target_component_count"] == 1
    @test objective_problem.metadata["dynamic_control_objective_target_component_names"] ==
          ["isoamyl_alcohol"]
    @test objective_problem.metadata["dynamic_control_objective_aroma_reward_policy"] ==
          "terminal"
    @test objective_problem.metadata["dynamic_control_objective_term_count"] == 4
    @test objective_problem.metadata["dynamic_control_objective_terminal_reward_terms"] == 1
    @test objective_problem.metadata["dynamic_control_objective_integrated_aroma_reward_terms"] == 0
    @test objective_problem.metadata["dynamic_control_objective_terminal_sugar_weight"] ==
          0.0
    @test objective_problem.metadata["dynamic_control_objective_terminal_sugar_terms"] == 0
    @test objective_problem.metadata["dynamic_control_objective_integrated_sugar_weight"] ==
          0.0
    @test objective_problem.metadata["dynamic_control_objective_integrated_sugar_terms"] == 0
    @test objective_problem.metadata["dynamic_control_objective_nutrient_terms"] == 1
    @test objective_problem.metadata["dynamic_control_objective_thermal_energy_terms"] == 1
    @test objective_problem.metadata["dynamic_control_objective_temperature_smoothness_terms"] ==
          1

    sugar_progress_config = ReducedDCDFBADynamicControlObjectiveConfig(
        mode = "aroma_nutrient_energy",
        target_state = "isoamyl_acetate",
        terminal_reward_weight = 0.25,
        terminal_sugar_weight = 0.3,
        terminal_sugar_scale_g_L = 100.0,
        nutrient_weight = 0.1,
        thermal_energy_weight = 0.05,
        temperature_smoothness_weight = 0.05,
    )
    sugar_progress_problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = spec,
        dynamic_control_objective_config = sugar_progress_config,
        ipopt_max_iter = 0,
    )
    @test sugar_progress_problem.metadata["dynamic_control_objective_term_count"] == 5
    @test sugar_progress_problem.metadata["dynamic_control_objective_terminal_sugar_weight"] ==
          0.3
    @test sugar_progress_problem.metadata["dynamic_control_objective_terminal_sugar_scale_g_L"] ==
          100.0
    @test sugar_progress_problem.metadata["dynamic_control_objective_terminal_sugar_terms"] ==
          1
    @test sugar_progress_problem.metadata["dynamic_control_objective_integrated_sugar_terms"] ==
          0

    integrated_sugar_progress_config = ReducedDCDFBADynamicControlObjectiveConfig(
        mode = "aroma_nutrient_energy",
        target_state = "isoamyl_acetate",
        terminal_reward_weight = 0.25,
        integrated_sugar_weight = 0.4,
        integrated_sugar_scale_g_L = 100.0,
        nutrient_weight = 0.1,
        thermal_energy_weight = 0.05,
        temperature_smoothness_weight = 0.05,
    )
    integrated_sugar_progress_problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = spec,
        dynamic_control_objective_config = integrated_sugar_progress_config,
        ipopt_max_iter = 0,
    )
    @test integrated_sugar_progress_problem.metadata["dynamic_control_objective_term_count"] ==
          5
    @test integrated_sugar_progress_problem.metadata["dynamic_control_objective_integrated_sugar_weight"] ==
          0.4
    @test integrated_sugar_progress_problem.metadata["dynamic_control_objective_integrated_sugar_scale_g_L"] ==
          100.0
    @test integrated_sugar_progress_problem.metadata["dynamic_control_objective_integrated_sugar_config_policy"] ==
          "squared_total"
    @test integrated_sugar_progress_problem.metadata["dynamic_control_objective_integrated_sugar_terms"] ==
          1
    @test integrated_sugar_progress_problem.metadata["dynamic_control_objective_integrated_sugar_policy"] ==
          "radau_time_average_of_squared_total_sugar"
    @test integrated_sugar_progress_problem.metadata["dynamic_control_objective_integrated_sugar_slack_count"] ==
          0

    integrated_sugar_excess_config = ReducedDCDFBADynamicControlObjectiveConfig(
        mode = "aroma_nutrient_energy",
        target_state = "isoamyl_acetate",
        terminal_reward_weight = 0.25,
        integrated_sugar_weight = 0.4,
        integrated_sugar_scale_g_L = 100.0,
        integrated_sugar_policy = "excess_slack",
        integrated_sugar_max_g_L = 5.0,
        nutrient_weight = 0.1,
        thermal_energy_weight = 0.05,
        temperature_smoothness_weight = 0.05,
    )
    integrated_sugar_excess_problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = spec,
        dynamic_control_objective_config = integrated_sugar_excess_config,
        ipopt_max_iter = 0,
    )
    @test integrated_sugar_excess_problem.metadata["dynamic_control_objective_integrated_sugar_config_policy"] ==
          "excess_slack"
    @test integrated_sugar_excess_problem.metadata["dynamic_control_objective_integrated_sugar_policy"] ==
          "radau_time_average_of_squared_total_sugar_excess_slack"
    @test integrated_sugar_excess_problem.metadata["dynamic_control_objective_integrated_sugar_slack_count"] >
          0
    @test integrated_sugar_excess_problem.metadata["dynamic_control_objective_integrated_sugar_constraint_count"] ==
          integrated_sugar_excess_problem.metadata["dynamic_control_objective_integrated_sugar_slack_count"]

    blend_config = ReducedDCDFBADynamicControlObjectiveConfig(
        mode = "aroma_nutrient_energy",
        target_state = "white_wine_aroma_blend",
        terminal_reward_weight = 0.25,
        nutrient_weight = 0.1,
        thermal_energy_weight = 0.05,
        temperature_smoothness_weight = 0.05,
    )
    blend_problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = spec,
        dynamic_control_objective_config = blend_config,
        ipopt_max_iter = 0,
    )
    @test blend_problem.metadata["dynamic_control_objective_enabled"] == true
    @test blend_problem.metadata["dynamic_control_objective_resolved_target_state"] ==
          "white_wine_aroma_blend"
    @test blend_problem.metadata["dynamic_control_objective_target_state_alias_policy"] ==
          "available_reduced_aroma_linear_blend"
    @test blend_problem.metadata["dynamic_control_objective_target_state_index"] == 0
    @test blend_problem.metadata["dynamic_control_objective_target_component_count"] == 6
    @test "ethyl_acetate" in
          blend_problem.metadata["dynamic_control_objective_target_component_names"]
    @test "isoamyl_alcohol" in
          blend_problem.metadata["dynamic_control_objective_target_component_names"]
    @test blend_problem.metadata["dynamic_control_objective_terminal_reward_terms"] == 1

    integrated_blend_config = ReducedDCDFBADynamicControlObjectiveConfig(
        mode = "aroma_nutrient_energy",
        target_state = "white_wine_aroma_blend",
        terminal_reward_weight = 0.25,
        aroma_reward_policy = "terminal_plus_integrated_flux",
        nutrient_weight = 0.1,
        thermal_energy_weight = 0.05,
        temperature_smoothness_weight = 0.05,
    )
    integrated_blend_problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = spec,
        dynamic_control_objective_config = integrated_blend_config,
        ipopt_max_iter = 0,
    )
    @test integrated_blend_problem.metadata["dynamic_control_objective_aroma_reward_policy"] ==
          "terminal_plus_integrated_flux"
    @test integrated_blend_problem.metadata["dynamic_control_objective_terminal_reward_terms"] ==
          1
    @test integrated_blend_problem.metadata["dynamic_control_objective_integrated_aroma_reward_terms"] ==
          1
    @test integrated_blend_problem.metadata["dynamic_control_objective_term_count"] == 5
    @test integrated_blend_problem.metadata["dynamic_control_objective_terminal_sugar_terms"] ==
          0
    @test integrated_blend_problem.metadata["dynamic_control_objective_integrated_sugar_terms"] ==
          0

    @test_throws ArgumentError build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        dynamic_control_decision_spec = spec,
        ipopt_max_iter = 0,
    )
end

@testset "Reduced DC-dFBA MPCC solve-attempt uses local sequential initial state" begin
    model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    shifted_initial = zenteno_state_to_vector(default_zenteno_initial_state())
    shifted_initial[1] += 0.25
    shifted_initial[3] -= 1.0
    shifted_initial[4] -= 0.5
    shifted_initial[5] += 0.2
    simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation(
        initial_state = shifted_initial,
    )
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )

    @test problem.smoke_problem.nlp.initial_state == shifted_initial
    @test JuMP.start_value(problem.smoke_problem.nlp.state_boundary[1, 1]) ==
          shifted_initial[1]
    @test JuMP.start_value(problem.smoke_problem.nlp.state_boundary[3, 1]) ==
          shifted_initial[3]
    @test problem.metadata["mpcc_initial_state_source"] ==
          "sequential_initialization_first_saved_state"
    @test problem.metadata["mpcc_initial_state_matches_sequential_initialization"] == true

    mismatched_initial = copy(shifted_initial)
    mismatched_initial[1] += 0.1
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        initial_state = mismatched_initial,
        ipopt_max_iter = 0,
    )
end

@testset "Reduced DC-dFBA MPCC cross-window flux and dual start seed" begin
    model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    n_states = problem.smoke_problem.nlp.dimensions.n_states
    n_reactions = problem.smoke_problem.nlp.dimensions.n_reactions
    n_metabolites = problem.smoke_problem.nlp.kkt_problem.dimensions.n_metabolites
    nfe = problem.smoke_problem.nlp.dimensions.nfe
    degree = problem.smoke_problem.nlp.dimensions.collocation_degree
    flux_starts =
        FermentationDFBA._reduced_dcdfba_start_array_or_nothing(problem.smoke_problem.nlp.flux)
    flux_seed = Array{Float64, 3}(undef, n_reactions, 1, degree)
    for j in 1:degree
        flux_seed[:, 1, j] .= flux_starts[:, end, end]
    end
    lower_seed = fill(0.2, n_reactions, 1, degree)
    upper_seed = fill(-0.3, n_reactions, 1, degree)
    mass_seed = fill(0.12, n_metabolites, 1, degree)
    seed = ReducedDCDFBAMPCCCandidateDiagnostics(
        zeros(n_states, 2),
        zeros(n_states, 1, degree),
        zeros(n_states, 1, degree),
        flux_seed,
        lower_seed,
        upper_seed,
        mass_seed,
        Dict{String, Float64}(),
        Dict{String, Float64}(),
        Dict{String, Float64}(),
        String[],
        String[],
        Dict{String, Any}(
            "candidate_solver_status" => "LOCALLY_SOLVED",
            "candidate_residual_feasible" => true,
            "tau_continuation_stage_index" => 3,
            "complementarity_tau" => 1.0e-6,
        ),
    )

    metadata =
        FermentationDFBA._apply_reduced_dcdfba_mpcc_flux_dual_start_seed!(problem, seed)

    @test metadata["cross_window_flux_dual_start_applied"] == true
    @test metadata["cross_window_flux_dual_start_source_stage_index"] == 3
    @test metadata["cross_window_flux_dual_start_source_tau"] == 1.0e-6
    @test metadata["cross_window_flux_dual_start_target_collocation_points"] ==
          nfe * degree
    @test metadata["cross_window_flux_dual_start_max_lower_dual_sign_clipping"] == 0.2
    @test metadata["cross_window_flux_dual_start_max_upper_dual_sign_clipping"] == 0.3
    @test metadata["cross_window_flux_dual_start_rhs_derivatives_refreshed"] == true
    @test all(
        JuMP.start_value(problem.smoke_problem.bound_feasibility.lower_bound_duals[r, e, j]) <=
        0.0 for r in 1:n_reactions, e in 1:nfe, j in 1:degree
    )
    @test all(
        JuMP.start_value(problem.smoke_problem.bound_feasibility.upper_bound_duals[r, e, j]) >=
        0.0 for r in 1:n_reactions, e in 1:nfe, j in 1:degree
    )
    @test all(
        JuMP.start_value(problem.smoke_problem.stationarity.mass_balance_duals[m, e, j]) ==
        0.12 for m in 1:n_metabolites, e in 1:nfe, j in 1:degree
    )
end

@testset "Reduced DC-dFBA MPCC solve-attempt metadata guardrails" begin
    model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    metadata = problem.metadata

    @test metadata["problem_type"] == "reduced_dcdfba_mpcc_solve_attempt"
    @test metadata["problem_scope"] == "guarded_reduced_dynamic_mpcc_solve_attempt"
    @test metadata["solve_attempt_guarded"] == true
    @test metadata["solve_attempt_requires_rhs_residuals"] == true
    @test metadata["solve_attempt_requires_dynamic_bounds"] == true
    @test metadata["solve_attempt_requires_sequential_initialization"] == true
    @test metadata["rhs_residuals_included"] == true
    @test metadata["dynamic_flux_bounds_applied"] == true
    @test metadata["sequential_initialization_built"] == true
    @test metadata["ipopt_max_iter"] == 0
    @test metadata["solve_attempt_optimizer_profile"] == "acceptable"
    @test metadata["solve_attempt_optimizer_profile_is_default"] == true
    @test metadata["solve_attempt_ipopt_profile"] == "acceptable"
    @test metadata["solve_attempt_ipopt_profile_env"] == "MPCC_REDUCED_MPCC_IPOPT_PROFILE"
    @test metadata["solve_attempt_ipopt_max_iter"] == 0
    @test metadata["solve_attempt_ipopt_warm_start_init_point"] == false
    @test metadata["solve_attempt_ipopt_warm_start_init_point_env"] ==
          "MPCC_IPOPT_WARM_START_INIT_POINT"
    @test metadata["solve_attempt_ipopt_warm_start_dual_starts_provided"] ==
          false
    @test metadata["solve_attempt_ipopt_warm_start_bound_push"] === missing
    @test metadata["solve_attempt_ipopt_warm_start_bound_push_env"] ==
          "MPCC_IPOPT_WARM_START_BOUND_PUSH"
    @test metadata["solve_attempt_ipopt_warm_start_bound_frac"] === missing
    @test metadata["solve_attempt_ipopt_warm_start_slack_bound_push"] === missing
    @test metadata["solve_attempt_ipopt_warm_start_slack_bound_frac"] === missing
    @test metadata["solve_attempt_ipopt_warm_start_mult_bound_push"] === missing
    @test metadata["solve_attempt_ipopt_tol"] == 1.0e-6
    @test metadata["solve_attempt_ipopt_constr_viol_tol"] === missing
    @test metadata["solve_attempt_ipopt_dual_inf_tol"] === missing
    @test metadata["solve_attempt_ipopt_compl_inf_tol"] === missing
    @test metadata["solve_attempt_ipopt_acceptable_tol"] == 1.0e-5
    @test metadata["solve_attempt_ipopt_acceptable_constr_viol_tol"] == 1.0e-6
    @test metadata["solve_attempt_ipopt_acceptable_compl_inf_tol"] == 1.0e-5
    @test metadata["solve_attempt_ipopt_acceptable_dual_inf_tol"] == 1.0e-5
    @test metadata["solve_attempt_ipopt_acceptable_obj_change_tol"] === missing
    @test metadata["solve_attempt_ipopt_acceptable_iter"] == 5
    @test metadata["solve_attempt_ipopt_mu_strategy"] == "adaptive"
    @test metadata["solve_attempt_ipopt_fixed_variable_treatment"] == "relax_bounds"
    @test metadata["solve_attempt_ipopt_bound_push"] === missing
    @test metadata["solve_attempt_ipopt_bound_frac"] === missing
    @test metadata["solve_attempt_ipopt_honor_original_bounds"] == "yes"
    @test metadata["base_flux_bounds_applied"] == false
    @test metadata["base_flux_bounds_partially_applied"] == true
    @test metadata["fixed_flux_variable_bounds_deferred"] == true
    @test metadata["fixed_flux_bounds_enforced_by_bound_feasibility_rows"] == true
    @test metadata["fixed_flux_bound_feasibility_reduces_ipopt_fixed_variable_pressure"] == true
    @test metadata["fixed_flux_reaction_count"] == 7
    @test metadata["fixed_flux_collocation_variable_count"] == 21
    @test metadata["nlp_structure_audit_built"] == true
    @test metadata["nlp_structure_audit_scope"] == "reduced_mpcc_jump_model"
    @test metadata["nlp_structure_total_variables"] > 0
    @test metadata["nlp_structure_equality_constraints"] > 0
    @test metadata["nlp_structure_inequality_constraints"] > 0
    @test metadata["nlp_structure_fixed_variable_count"] == 0
    @test metadata["nlp_structure_nearly_fixed_variable_count"] >= 0
    @test metadata["nlp_structure_dof_balance"] > 0
    @test metadata["nlp_structure_too_few_degrees_of_freedom_risk"] == false
    @test metadata["nlp_structure_fixed_variable_treatment_hint"] isa String
    @test metadata["nlp_structure_ipopt_dof_warning_likely"] ==
          metadata["nlp_structure_too_few_degrees_of_freedom_risk"]
    @test metadata["nlp_structure_solver_call_performed"] == false
    @test metadata["linear_solver"] == "mumps"
    @test metadata["linear_solver_source"] == "argument"
    @test metadata["solve_attempt_linear_solver"] == "mumps"
    @test metadata["spral_available_from_ipopt_jll"] == true
    @test metadata["pardiso_opt_in"] == false
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["solve_attempt_hsl_required"] == false
    @test metadata["solve_attempt_ma57_required"] == false
    @test metadata["complementarity_mode"] == "scholtes"
    @test metadata["complementarity_tau"] == 1.0e-4
    @test metadata["complementarity_tau_gate_tolerance"] ≈ 1.0e-7
    @test metadata["complementarity_tau_gate_tolerance_source"] == "auto_abs_rel"
    @test metadata["complementarity_tau_gate_tolerance_override"] === missing
    @test metadata["complementarity_tau_gate_abs_tolerance_default"] == 1.0e-8
    @test metadata["complementarity_tau_gate_rel_tolerance_default"] == 1.0e-3
    @test metadata["complementarity_constraint_type"] == "scholtes_inequalities"
    @test metadata["complementarity_relaxation_sign_policy"] ==
          "sign_consistent_nonnegative_kkt_products"
    @test metadata["model_scope"] == "reduced"
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["solver_call_performed"] == false
    @test metadata["solve_attempt_is_scientific_simulation"] == false
    @test metadata["residual_threshold_max_rhs_residual"] == 1.0e-6
    @test metadata["residual_threshold_max_stationarity_residual"] == 1.0e-5
    @test metadata["residual_thresholds_are_scientific_acceptance_criteria"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false

    @test problem.smoke_problem.metadata["problem_type"] == "reduced_dcdfba_mpcc_solve_attempt"
    @test problem.smoke_problem.nlp.metadata["problem_type"] == "reduced_dcdfba_mpcc_solve_attempt"
end

@testset "Reduced DC-dFBA MPCC solve-attempt validation" begin
    model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation()
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = -1,
    )
    bad_thresholds = ReducedDCDFBAMPCCResidualThresholds(-1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0)
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        residual_thresholds = bad_thresholds,
    )
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_profile = "bad_profile",
    )
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        linear_solver = "bad_solver",
    )
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        complementarity_mode = :bad_mode,
    )
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        complementarity_tau = -1.0e-4,
    )
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        complementarity_tau_gate_tol = -1.0e-8,
    )
end

@testset "Reduced DC-dFBA MPCC solve-attempt pre-solve gate metadata" begin
    model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)
    metadata = FermentationDFBA._reduced_dcdfba_mpcc_solve_attempt_pre_solve_metadata(
        report,
        true,
    )

    @test metadata["pre_solve_diagnostic_report_built"] == true
    @test metadata["pre_solve_guard_required"] == true
    @test metadata["pre_solve_guard_passed"] == true
    @test metadata["pre_solve_guard_policy"] == "residual_thresholds_only"
    @test metadata["pre_solve_residuals_available"] == true
    @test metadata["pre_solve_residual_thresholds_satisfied"] == true
    @test metadata["pre_solve_scaling_plan_ready_for_guarded_solve_attempt"] == true
    @test metadata["pre_solve_scaling_warnings_block_solver"] == false
    @test metadata["pre_solve_scaling_warning_policy"] ==
          "diagnostic_only_after_residual_thresholds_pass"
    @test metadata["pre_solve_scaling_blocking_warning_count"] == 0
    @test metadata["pre_solve_scaling_review_warning_count"] >= 0
    @test metadata["guarded_solve_attempt_allowed"] == true
    @test metadata["guarded_solve_attempt_blocked"] == false
    @test metadata["pre_solve_is_scientific_simulation"] == false

    scaling_warning_metadata = copy(report.metadata)
    scaling_warning_metadata["scaling_plan_ready_for_guarded_solve_attempt"] = false
    scaling_warning_metadata["scaling_blocking_warning_count"] = 2
    scaling_warning_report = ReducedDCDFBAMPCCDiagnosticReport(
        report.residual_values,
        report.residual_thresholds,
        report.residual_ratios,
        report.ranked_residuals,
        report.dominant_residual,
        true,
        true,
        report.scaling_summary,
        ["state_collocation_start_scale_spread_large"],
        scaling_warning_metadata,
    )
    scaling_warning_gate =
        FermentationDFBA._reduced_dcdfba_mpcc_solve_attempt_pre_solve_metadata(
            scaling_warning_report,
            true,
        )
    @test scaling_warning_gate["pre_solve_guard_passed"] == true
    @test scaling_warning_gate["pre_solve_guard_failure_component"] == "none"
    @test scaling_warning_gate["pre_solve_scaling_plan_ready_for_guarded_solve_attempt"] ==
          false
    @test scaling_warning_gate["pre_solve_scaling_blocking_warning_count"] == 2
    @test scaling_warning_gate["guarded_solve_attempt_allowed"] == true
    @test scaling_warning_gate["guarded_solve_attempt_blocked"] == false
end

@testset "Reduced DC-dFBA MPCC pre-solve gate includes structural state starts" begin
    model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )

    variable = problem.smoke_problem.nlp.state_collocation[1, 1, 1]
    JuMP.set_start_value(variable, JuMP.start_value(variable) + 1.0e-2)
    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)
    metadata = FermentationDFBA._reduced_dcdfba_mpcc_solve_attempt_pre_solve_metadata(
        report,
        true,
    )

    @test haskey(report.residual_values, "max_collocation_integration_residual")
    @test haskey(report.residual_values, "max_continuity_residual")
    @test haskey(report.residual_values, "max_initial_condition_residual")
    @test report.residual_values["max_collocation_integration_residual"] >
          report.residual_thresholds["max_collocation_integration_residual"]
    @test report.residual_thresholds_satisfied == false
    @test metadata["pre_solve_guard_passed"] == false
    @test metadata["pre_solve_guard_failure_component"] == "residual_thresholds_failed"
    @test metadata["guarded_solve_attempt_blocked"] == true
end

@testset "Reduced DC-dFBA MPCC tau continuation configuration" begin
    old_env = get(ENV, "MPCC_TAU_SCHEDULE", nothing)
    old_gate_env = get(ENV, "MPCC_COMPLEMENTARITY_TAU_GATE_TOL", nothing)
    old_stage_iter_env = get(ENV, "MPCC_TAU_STAGE_MAX_ITERS", nothing)
    try
        delete!(ENV, "MPCC_TAU_SCHEDULE")
        delete!(ENV, "MPCC_COMPLEMENTARITY_TAU_GATE_TOL")
        delete!(ENV, "MPCC_TAU_STAGE_MAX_ITERS")
        @test reduced_mpcc_tau_schedule_from_env([1.0e-2, 1.0e-4]) ==
              [1.0e-2, 1.0e-4]
        @test reduced_mpcc_tau_stage_max_iters_from_env() === nothing
        @test reduced_mpcc_complementarity_tau_gate_tol_from_env() === nothing
        @test reduced_mpcc_complementarity_tau_gate_tol_from_env(2.0e-8) == 2.0e-8
        ENV["MPCC_COMPLEMENTARITY_TAU_GATE_TOL"] = "3e-8"
        @test reduced_mpcc_complementarity_tau_gate_tol_from_env() == 3.0e-8
        ENV["MPCC_COMPLEMENTARITY_TAU_GATE_TOL"] = "bad"
        @test_throws ArgumentError reduced_mpcc_complementarity_tau_gate_tol_from_env()
        ENV["MPCC_TAU_SCHEDULE"] = "1e-2,1e-4,1e-6"
        @test reduced_mpcc_tau_schedule_from_env() == [1.0e-2, 1.0e-4, 1.0e-6]
        ENV["MPCC_TAU_SCHEDULE"] = "1e-2,bad"
        @test_throws ArgumentError reduced_mpcc_tau_schedule_from_env()
        ENV["MPCC_TAU_STAGE_MAX_ITERS"] = "500,800,300"
        @test reduced_mpcc_tau_stage_max_iters_from_env() == [500, 800, 300]
        ENV["MPCC_TAU_STAGE_MAX_ITERS"] = "default,250"
        @test reduced_mpcc_tau_stage_max_iters_from_env() == Union{Nothing, Int}[nothing, 250]
        ENV["MPCC_TAU_STAGE_MAX_ITERS"] = "1,bad"
        @test_throws ArgumentError reduced_mpcc_tau_stage_max_iters_from_env()
    finally
        if old_env === nothing
            delete!(ENV, "MPCC_TAU_SCHEDULE")
        else
            ENV["MPCC_TAU_SCHEDULE"] = old_env
        end
        if old_gate_env === nothing
            delete!(ENV, "MPCC_COMPLEMENTARITY_TAU_GATE_TOL")
        else
            ENV["MPCC_COMPLEMENTARITY_TAU_GATE_TOL"] = old_gate_env
        end
        if old_stage_iter_env === nothing
            delete!(ENV, "MPCC_TAU_STAGE_MAX_ITERS")
        else
            ENV["MPCC_TAU_STAGE_MAX_ITERS"] = old_stage_iter_env
        end
    end
end

@testset "Reduced DC-dFBA MPCC Scholtes tau gate tolerance" begin
    model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
    simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
        complementarity_tau = 1.0e-4,
    )

    auto_status = FermentationDFBA._reduced_dcdfba_mpcc_complementarity_tau_status(
        problem.smoke_problem,
        1.00005e-4,
        9.0e-5,
    )
    @test auto_status.max_complementarity_tau_violation ≈ 5.0e-9
    @test auto_status.complementarity_tau_gate_tolerance ≈ 1.0e-7
    @test auto_status.complementarity_tau_gate_tolerance_source == "auto_abs_rel"
    @test auto_status.complementarity_tau_gate_pass == true

    strict_problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
        complementarity_tau = 1.0e-4,
        complementarity_tau_gate_tol = 0.0,
    )
    strict_status = FermentationDFBA._reduced_dcdfba_mpcc_complementarity_tau_status(
        strict_problem.smoke_problem,
        1.00005e-4,
        9.0e-5,
    )
    @test strict_status.complementarity_tau_gate_tolerance == 0.0
    @test strict_status.complementarity_tau_gate_tolerance_source == "argument_or_env"
    @test strict_status.complementarity_tau_gate_pass == false
end

@testset "Reduced DC-dFBA MPCC Scholtes complementarity residual gate" begin
    thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
    scholtes_metadata = Dict{String, Any}(
        "complementarity_mode" => "scholtes",
        "complementarity_tau" => 1.0e-4,
    )
    effective_thresholds =
        FermentationDFBA._reduced_dcdfba_mpcc_effective_threshold_values(
            scholtes_metadata,
            thresholds,
        )

    @test effective_thresholds["max_lower_complementarity_residual"] ≈ 1.001e-4
    @test effective_thresholds["max_upper_complementarity_residual"] ≈ 1.001e-4

    relaxed_products = Dict{String, Float64}(
        "max_lower_complementarity_residual" => 5.0e-5,
        "max_upper_complementarity_residual" => 9.0e-5,
    )
    @test all(key -> relaxed_products[key] <= effective_thresholds[key], keys(relaxed_products))

    excessive_products = Dict{String, Float64}(
        "max_lower_complementarity_residual" => 2.0e-4,
        "max_upper_complementarity_residual" => 9.0e-5,
    )
    @test !all(key -> excessive_products[key] <= effective_thresholds[key], keys(excessive_products))

    exact_thresholds =
        FermentationDFBA._reduced_dcdfba_mpcc_effective_threshold_values(
            Dict{String, Any}("complementarity_mode" => "exact"),
            thresholds,
        )
    @test exact_thresholds["max_lower_complementarity_residual"] == 1.0e-5
    @test exact_thresholds["max_upper_complementarity_residual"] == 1.0e-5
end

@testset "Reduced DC-dFBA MPCC tau continuation stage advancement" begin
    function tau_stage_test_result(metadata::Dict{String, Any}; residuals_available = true)
        smoke_result = ReducedDCDFBAMPCCSmokeResult(
            MOI.ITERATION_LIMIT,
            MOI.FEASIBLE_POINT,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            "Ipopt",
            0.0,
            Dict{String, Any}(),
        )
        return ReducedDCDFBAMPCCSolveAttemptResult(
            smoke_result,
            default_reduced_dcdfba_mpcc_residual_thresholds(),
            residuals_available,
            false,
            Dict{String, Any}(),
            metadata,
            nothing,
        )
    end

    intermediate_metadata = Dict{String, Any}(
        "candidate_values_available" => true,
        "pre_solve_guard_required" => true,
        "pre_solve_guard_passed" => true,
        "post_solve_residuals_available" => true,
        "post_solve_primal_status_allows_residual_candidate" => true,
        "complementarity_tau_gate_pass" => true,
        "candidate_residual_feasible" => false,
    )
    intermediate_result = tau_stage_test_result(intermediate_metadata)
    advancement = FermentationDFBA._reduced_dcdfba_mpcc_tau_stage_advancement_metadata(
        intermediate_result,
        1,
        2,
    )

    @test advancement["tau_continuation_stage_is_final"] == false
    @test advancement["tau_continuation_stage_advance_allowed"] == true
    @test advancement["tau_continuation_stage_advance_reason"] ==
          "finite_candidate_tau_gate_pass"

    final_advancement = FermentationDFBA._reduced_dcdfba_mpcc_tau_stage_advancement_metadata(
        intermediate_result,
        2,
        2,
    )
    @test final_advancement["tau_continuation_stage_is_final"] == true
    @test final_advancement["tau_continuation_stage_advance_allowed"] == false
    @test final_advancement["tau_continuation_stage_advance_reason"] ==
          "final_stage_no_advance_needed"

    blocked_metadata = copy(intermediate_metadata)
    blocked_metadata["complementarity_tau_gate_pass"] = false
    blocked_advancement = FermentationDFBA._reduced_dcdfba_mpcc_tau_stage_advancement_metadata(
        tau_stage_test_result(blocked_metadata),
        1,
        2,
    )
    @test blocked_advancement["tau_continuation_stage_advance_allowed"] == false
    @test blocked_advancement["tau_continuation_stage_advance_reason"] == "tau_gate_failed"

    diagnostic_stage_metadata = copy(intermediate_metadata)
    diagnostic_stage_metadata["pre_solve_guard_required"] = false
    diagnostic_stage_metadata["pre_solve_guard_passed"] = false
    diagnostic_advancement = FermentationDFBA._reduced_dcdfba_mpcc_tau_stage_advancement_metadata(
        tau_stage_test_result(diagnostic_stage_metadata),
        1,
        2,
    )
    @test diagnostic_advancement["tau_continuation_stage_pre_solve_required"] == false
    @test diagnostic_advancement["tau_continuation_stage_pre_solve_passed"] == true
    @test diagnostic_advancement["tau_continuation_stage_advance_allowed"] == true

    stage1_metadata = copy(intermediate_metadata)
    stage1_metadata["tau_continuation_stage_index"] = 1
    stage1_metadata["complementarity_tau"] = 1.0e-4
    stage1_metadata["tau_continuation_stage_advance_allowed"] = true
    stage1_metadata["cross_window_flux_dual_start_applied"] = true
    stage1_metadata["cross_window_flux_dual_start_policy"] =
        "previous_window_final_collocation_flux_duals_constant_over_target_window"
    stage1_metadata["cross_window_flux_dual_start_source_tau"] = 1.0e-6
    stage1_metadata["cross_window_flux_dual_start_max_flux_projection_adjustment"] =
        2.0e-5
    stage1_result = tau_stage_test_result(stage1_metadata)

    stage2_metadata = copy(intermediate_metadata)
    stage2_metadata["tau_continuation_stage_index"] = 2
    stage2_metadata["complementarity_tau"] = 1.0e-6
    stage2_metadata["candidate_residual_feasible"] = true
    stage2_metadata["complementarity_tau_gate_pass"] = false
    stage2_result = tau_stage_test_result(stage2_metadata)
    summary = FermentationDFBA._reduced_dcdfba_mpcc_tau_continuation_metadata(
        [1.0e-4, 1.0e-6],
        ReducedDCDFBAMPCCSolveAttemptResult[stage1_result, stage2_result],
        DataFrame(),
        stage2_result,
        :scholtes,
        "mumps",
        "acceptable",
    )
    @test summary["tau_continuation_completed"] == false
    @test summary["tau_continuation_final_residual_feasible"] == true
    @test summary["tau_continuation_final_tau_gate_pass"] == false
    @test summary["tau_continuation_blocking_reason"] == "final_tau_gate_failed"
    @test summary["cross_window_flux_dual_start_applied"] == true
    @test summary["cross_window_flux_dual_start_source_tau"] == 1.0e-6
    @test summary["cross_window_flux_dual_start_max_flux_projection_adjustment"] ==
          2.0e-5

    fallback_stage1_metadata = copy(intermediate_metadata)
    fallback_stage1_metadata["tau_continuation_stage_index"] = 1
    fallback_stage1_metadata["complementarity_tau"] = 1.0e-4
    fallback_stage1_metadata["candidate_residual_feasible"] = true
    fallback_stage1_result = tau_stage_test_result(fallback_stage1_metadata)

    fallback_stage2_metadata = copy(intermediate_metadata)
    fallback_stage2_metadata["tau_continuation_stage_index"] = 2
    fallback_stage2_metadata["complementarity_tau"] = 1.0e-6
    fallback_stage2_metadata["candidate_residual_feasible"] = false
    fallback_stage2_result = tau_stage_test_result(fallback_stage2_metadata)
    selection = FermentationDFBA._reduced_dcdfba_mpcc_select_tau_continuation_result(
        ReducedDCDFBAMPCCSolveAttemptResult[fallback_stage1_result, fallback_stage2_result],
    )
    @test selection.stage_index == 1
    @test selection.selected_by_fallback == true
    @test selection.reason ==
          "selected_best_residual_feasible_stage_before_polish_failure"
    fallback_summary = FermentationDFBA._reduced_dcdfba_mpcc_tau_continuation_metadata(
        [1.0e-4, 1.0e-6],
        ReducedDCDFBAMPCCSolveAttemptResult[fallback_stage1_result, fallback_stage2_result],
        DataFrame(),
        fallback_stage1_result,
        :scholtes,
        "mumps",
        "acceptable",
        selection,
        [800, 250],
    )
    @test fallback_summary["tau_continuation_selected_stage_index"] == 1
    @test fallback_summary["tau_continuation_selected_tau"] == 1.0e-4
    @test fallback_summary["tau_continuation_attempted_final_tau"] == 1.0e-6
    @test fallback_summary["tau_continuation_polish_failed"] == true
    @test fallback_summary["tau_continuation_blocking_reason"] ==
          "polish_stage_failed_selected_best_residual_feasible_stage"
    @test fallback_summary["tau_stage_max_iters"] == [800, 250]

    coarse_stage1_metadata = copy(intermediate_metadata)
    coarse_stage1_metadata["tau_continuation_stage_index"] = 1
    coarse_stage1_metadata["complementarity_tau"] = 1.0e-2
    coarse_stage1_metadata["candidate_residual_feasible"] = false
    coarse_stage1_metadata["complementarity_tau_gate_pass"] = true
    coarse_stage1_metadata["max_rhs_residual"] = 1.0e-9
    coarse_stage1_metadata["max_mass_balance_residual"] = 1.0e-9
    coarse_stage1_metadata["max_lower_bound_violation"] = 0.0
    coarse_stage1_metadata["max_upper_bound_violation"] = 0.0
    coarse_stage1_metadata["max_stationarity_residual"] = 1.0e-9
    coarse_stage1_metadata["max_lower_complementarity_residual"] = 1.0e-2
    coarse_stage1_metadata["max_upper_complementarity_residual"] = 1.0e-2
    coarse_stage1_result = tau_stage_test_result(coarse_stage1_metadata)

    coarse_stage2_metadata = copy(coarse_stage1_metadata)
    coarse_stage2_metadata["tau_continuation_stage_index"] = 2
    coarse_stage2_metadata["complementarity_tau"] = 1.0e-4
    coarse_stage2_metadata["max_mass_balance_residual"] = 1.0e-2
    coarse_stage2_metadata["max_lower_complementarity_residual"] = 1.0e-4
    coarse_stage2_metadata["max_upper_complementarity_residual"] = 1.0e-4
    coarse_stage2_result = tau_stage_test_result(coarse_stage2_metadata)

    coarse_selection =
        FermentationDFBA._reduced_dcdfba_mpcc_select_tau_continuation_result(
            ReducedDCDFBAMPCCSolveAttemptResult[
                coarse_stage1_result,
                coarse_stage2_result,
            ];
            allow_coarse_tau_fallback = true,
        )
    @test coarse_selection.stage_index == 1
    @test coarse_selection.selected_by_coarse_tau_fallback == true
    @test coarse_selection.reason ==
          "selected_coarse_tau_stage_residual_feasible_fallback"
    coarse_summary = FermentationDFBA._reduced_dcdfba_mpcc_tau_continuation_metadata(
        [1.0e-2, 1.0e-4],
        ReducedDCDFBAMPCCSolveAttemptResult[
            coarse_stage1_result,
            coarse_stage2_result,
        ],
        DataFrame(),
        coarse_stage1_result,
        :scholtes,
        "mumps",
        "acceptable",
        coarse_selection,
        [500, 800],
        true,
    )
    @test coarse_summary["tau_continuation_completed"] == false
    @test coarse_summary["tau_continuation_final_residual_feasible"] == true
    @test coarse_summary["tau_continuation_coarse_tau_fallback_applied"] == true
    @test coarse_summary["tau_continuation_selected_tau"] == 1.0e-2
    @test coarse_summary["tau_continuation_polish_failed"] == false
    @test coarse_summary["tau_continuation_blocking_reason"] ==
          "coarse_tau_stage_fallback_selected_after_final_stage_failure"

    FermentationDFBA._reduced_dcdfba_mpcc_apply_coarse_tau_fallback_metadata!(
        coarse_stage1_result,
        coarse_summary,
    )
    @test coarse_stage1_result.metadata["candidate_residual_feasible"] == true
    @test coarse_stage1_result.metadata["candidate_residual_feasible_source"] ==
          "coarse_tau_stage_fallback"
    @test coarse_stage1_result.metadata[
        "candidate_residual_feasible_strict_before_coarse_tau_fallback"
    ] == false
end

@testset "Reduced DC-dFBA MPCC solve-attempt post-solve candidate metadata" begin
    thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
    good_result = ReducedDCDFBAMPCCSmokeResult(
        MOI.LOCALLY_SOLVED,
        MOI.FEASIBLE_POINT,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        "Ipopt",
        0.0,
        Dict{String, Any}(),
    )
    good_report = Dict{String, Any}(
        "residuals_available" => true,
        "residual_thresholds_satisfied" => true,
        "dominant_residual" => "max_rhs_residual",
        "residual_thresholds_are_scientific_acceptance_criteria" => false,
    )
    good_metadata = FermentationDFBA._reduced_dcdfba_mpcc_solve_attempt_post_solve_metadata(
        good_result,
        good_report,
    )

    @test thresholds.max_rhs_residual == 1.0e-6
    @test good_metadata["post_solve_diagnostic_report_built"] == true
    @test good_metadata["post_solve_status_allows_trajectory_candidate"] == true
    @test good_metadata["post_solve_primal_status_allows_residual_candidate"] == true
    @test good_metadata["post_solve_residuals_available"] == true
    @test good_metadata["post_solve_residual_thresholds_satisfied"] == true
    @test good_metadata["post_solve_residual_feasible_candidate"] == true
    @test good_metadata["post_solve_iteration_limit_residual_feasible_candidate"] == false
    @test good_metadata["post_solve_requires_status_before_trajectory_extraction"] == false
    @test good_metadata["post_solve_next_recommended_action"] == "extract_candidate_trajectory"
    @test good_metadata["trajectory_extraction_ready"] == true
    @test good_metadata["solved_trajectory_claimed"] == false
    @test good_metadata["post_solve_is_scientific_simulation"] == false

    limited_result = ReducedDCDFBAMPCCSmokeResult(
        MOI.ITERATION_LIMIT,
        MOI.NEARLY_FEASIBLE_POINT,
        NaN,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        "Ipopt",
        0.0,
        Dict{String, Any}(),
    )
    limited_metadata =
        FermentationDFBA._reduced_dcdfba_mpcc_solve_attempt_post_solve_metadata(
            limited_result,
            good_report,
        )
    @test limited_metadata["post_solve_status_allows_trajectory_candidate"] == false
    @test limited_metadata["post_solve_primal_status_allows_residual_candidate"] == true
    @test limited_metadata["post_solve_residual_feasible_candidate"] == true
    @test limited_metadata["post_solve_iteration_limit_residual_feasible_candidate"] == true
    @test limited_metadata["post_solve_requires_status_before_trajectory_extraction"] == true
    @test limited_metadata["post_solve_next_recommended_action"] ==
          "review_iteration_limit_residual_feasible_candidate"
    @test limited_metadata["trajectory_extraction_ready"] == false
end

@testset "Reduced DC-dFBA MPCC solve-attempt candidate selection" begin
    function solve_attempt_selection_candidate(;
        source::AbstractString,
        residual_feasible::Bool,
        trajectory_ready::Bool,
        failed_residual_scale::Float64 = 1.0,
    )
        residual_values = Dict{String, Float64}(
            "max_rhs_residual" => residual_feasible ? 1.0e-10 : failed_residual_scale * 1.0e-3,
            "max_mass_balance_residual" =>
                residual_feasible ? 2.0e-7 : failed_residual_scale * 2.0e-3,
            "max_lower_bound_violation" => 0.0,
            "max_upper_bound_violation" => 0.0,
            "max_stationarity_residual" => 1.0e-8,
            "max_lower_complementarity_residual" => 1.0e-7,
            "max_upper_complementarity_residual" => 0.0,
        )
        residual_thresholds = Dict{String, Float64}(
            "max_rhs_residual" => 1.0e-6,
            "max_mass_balance_residual" => 1.0e-6,
            "max_lower_bound_violation" => 1.0e-6,
            "max_upper_bound_violation" => 1.0e-6,
            "max_stationarity_residual" => 1.0e-5,
            "max_lower_complementarity_residual" => 1.0e-5,
            "max_upper_complementarity_residual" => 1.0e-5,
        )
        residual_ratios = Dict(
            key => residual_values[key] / residual_thresholds[key] for
            key in keys(residual_values)
        )
        metadata = Dict{String, Any}(
            "candidate_values_source" => String(source),
            "candidate_residual_feasible" => residual_feasible,
            "candidate_trajectory_extraction_ready" => trajectory_ready,
            "candidate_dominant_residual" => "max_mass_balance_residual",
            "candidate_dynamic_control_values_captured" => true,
            "candidate_dynamic_control_temperature_C_values" =>
                source == "post_solve_values" ? [19.0, 21.0] : [18.0, 22.0],
            "candidate_dynamic_control_fda_g_L_values" =>
                source == "post_solve_values" ? [0.01, 0.02] : [0.0, 0.0],
            "candidate_dynamic_control_organic_g_L_values" =>
                source == "post_solve_values" ? [0.3, 0.1] : [0.4, 0.0],
            "candidate_is_scientific_simulation" => false,
            "solved_trajectory_claimed" => false,
        )
        return ReducedDCDFBAMPCCCandidateDiagnostics(
            zeros(2, 2),
            zeros(2, 1, 1),
            zeros(2, 1, 1),
            zeros(1, 1, 1),
            zeros(1, 1, 1),
            zeros(1, 1, 1),
            zeros(1, 1, 1),
            residual_values,
            residual_thresholds,
            residual_ratios,
            collect(keys(residual_values)),
            String[],
            metadata,
        )
    end

    pre_candidate = solve_attempt_selection_candidate(
        source = "pre_solve_start_values",
        residual_feasible = true,
        trajectory_ready = false,
    )
    post_candidate = solve_attempt_selection_candidate(
        source = "post_solve_values",
        residual_feasible = true,
        trajectory_ready = false,
    )
    selected = FermentationDFBA._reduced_dcdfba_mpcc_select_solve_attempt_candidate(
        pre_candidate,
        post_candidate,
    )
    @test selected.candidate === post_candidate
    @test selected.metadata["post_solve_candidate_accepted"] == true
    @test selected.metadata["selected_candidate_is_post_solve"] == true
    @test selected.metadata["selected_candidate_source"] == "post_solve_values"
    @test selected.metadata["candidate_selection_reason"] ==
          "post_solve_candidate_residual_feasible"

    failed_post_candidate = solve_attempt_selection_candidate(
        source = "post_solve_values",
        residual_feasible = false,
        trajectory_ready = false,
    )
    fallback = FermentationDFBA._reduced_dcdfba_mpcc_select_solve_attempt_candidate(
        pre_candidate,
        failed_post_candidate,
    )
    @test fallback.candidate === pre_candidate
    @test fallback.metadata["post_solve_candidate_accepted"] == false
    @test fallback.metadata["post_solve_candidate_rejected"] == true
    @test fallback.metadata["post_solve_candidate_rejection_reason"] ==
          "not_residual_feasible"
    @test fallback.metadata["selected_candidate_is_pre_solve_start"] == true
    @test fallback.metadata["selected_candidate_source"] == "pre_solve_start_values"
    @test fallback.metadata["candidate_selection_reason"] ==
          "post_solve_candidate_not_residual_feasible_fallback_to_pre_solve_start"
    @test fallback.metadata["pre_solve_candidate_dynamic_control_values_captured"] == true
    @test fallback.metadata["pre_solve_candidate_dynamic_control_temperature_C_values"] ==
          [18.0, 22.0]
    @test fallback.metadata["post_solve_candidate_dynamic_control_values_captured"] == true
    @test fallback.metadata["post_solve_candidate_dynamic_control_temperature_C_values"] ==
          [19.0, 21.0]
    @test fallback.metadata["post_solve_candidate_dynamic_control_fda_g_L_values"] ==
          [0.01, 0.02]
    @test fallback.metadata["post_solve_candidate_dynamic_control_organic_g_L_values"] ==
          [0.3, 0.1]
    @test fallback.metadata["post_solve_candidate_dynamic_control_delta_vs_pre_solve_available"] ==
          true
    @test fallback.metadata["post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve"] ==
          1.0
    @test fallback.metadata["post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve"] ≈
          0.03
    @test fallback.metadata["post_solve_candidate_dynamic_control_organic_g_L_max_abs_delta_vs_pre_solve"] ≈
          0.1

    requires_ready = FermentationDFBA._reduced_dcdfba_mpcc_select_solve_attempt_candidate(
        pre_candidate,
        post_candidate;
        accept_post_solve_requires_trajectory_ready = true,
    )
    @test requires_ready.candidate === pre_candidate
    @test requires_ready.metadata["post_solve_candidate_rejection_reason"] ==
          "not_trajectory_ready"
    @test requires_ready.metadata["candidate_selection_reason"] ==
          "post_solve_candidate_not_trajectory_ready_fallback_to_pre_solve_start"

    failed_pre_candidate = solve_attempt_selection_candidate(
        source = "pre_solve_start_values",
        residual_feasible = false,
        trajectory_ready = false,
        failed_residual_scale = 0.01,
    )
    worse_failed_post_candidate = solve_attempt_selection_candidate(
        source = "post_solve_values",
        residual_feasible = false,
        trajectory_ready = false,
        failed_residual_scale = 1.0,
    )
    best_failed = FermentationDFBA._reduced_dcdfba_mpcc_select_solve_attempt_candidate(
        failed_pre_candidate,
        worse_failed_post_candidate,
    )
    @test best_failed.candidate === failed_pre_candidate
    @test best_failed.metadata["selected_candidate_is_pre_solve_start"] == true
    @test best_failed.metadata["candidate_selection_reason"] ==
          "pre_solve_start_retained_for_diagnostics_lower_residual_score"
    @test best_failed.metadata["candidate_selection_pre_solve_residual_score"] <
          best_failed.metadata["candidate_selection_post_solve_residual_score"]
end

@testset "Reduced DC-dFBA MPCC solve-attempt opt-in" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_DYNAMIC_SOLVE", "0") == "1"
        model, reaction_map = _reduced_dcdfba_mpcc_solve_attempt_test_model_and_map()
        simulation = _reduced_dcdfba_mpcc_solve_attempt_test_simulation()
        result = solve_reduced_dcdfba_mpcc_solve_attempt(
            model,
            reaction_map;
            sequential_initialization = simulation,
            ipopt_max_iter = 0,
        )

        @test result isa ReducedDCDFBAMPCCSolveAttemptResult
        @test result.smoke_result isa ReducedDCDFBAMPCCSmokeResult
        @test result.smoke_result.status in (
            MOI.ITERATION_LIMIT,
            MOI.LOCALLY_SOLVED,
            MOI.ALMOST_LOCALLY_SOLVED,
            MOI.OPTIMAL,
        )
        @test result.residuals_available == true
        @test result.residual_thresholds_satisfied isa Bool
        @test result.metadata["solver_call_performed"] == true
        @test result.metadata["pre_solve_diagnostic_report_built"] == true
        @test result.metadata["pre_solve_guard_passed"] == true
        @test result.metadata["guarded_solve_attempt_allowed"] == true
        @test result.metadata["post_solve_diagnostic_report_built"] == true
        @test result.metadata["trajectory_extraction_ready"] isa Bool
        @test result.metadata["solved_trajectory_claimed"] == false
        @test result.metadata["solve_attempt_is_scientific_simulation"] == false
        @test result.metadata["rhs_residuals_included"] == true
        @test result.metadata["dynamic_flux_bounds_applied"] == true
        @test result.metadata["sequential_initialization_built"] == true
        @test isfinite(result.residual_report["max_rhs_residual"])
        @test isfinite(result.residual_report["max_mass_balance_residual"])
        @test isfinite(result.residual_report["max_stationarity_residual"])
        @test haskey(result.residual_report, "dominant_residual")
        @test haskey(result.residual_report, "ranked_residuals")
        @test haskey(result.residual_report, "residual_ratios")
        @test haskey(result.residual_report, "residual_threshold_report")
    else
        @info "Skipping guarded reduced dynamic MPCC solve attempt; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_DYNAMIC_SOLVE=1 to run it."
        @test true
    end
end
