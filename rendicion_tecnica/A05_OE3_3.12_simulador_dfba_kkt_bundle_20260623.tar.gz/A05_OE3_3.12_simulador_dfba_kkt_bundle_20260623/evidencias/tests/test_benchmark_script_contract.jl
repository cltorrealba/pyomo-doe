import CSV
import TOML
using DataFrames

const BENCHMARK_CONTRACT_PROJECT_ROOT = normpath(joinpath(@__DIR__, ".."))
const BENCHMARK_CONTRACT_SCRIPT_PATH = joinpath(BENCHMARK_CONTRACT_PROJECT_ROOT, "scripts", "main_benchmark.jl")
const BENCHMARK_CONTRACT_EXPECTED_COLUMNS = [
    "scenario_id",
    "model_id",
    "solver_label",
    "algorithm_label",
    "tspan_start",
    "tspan_end",
    "saveat",
    "ode_abstol",
    "ode_reltol",
    "lp_atol",
    "reconstruct_fluxes",
    "retcode",
    "termination_reason",
    "final_time",
    "n_saved_points",
    "n_states",
    "n_fluxes",
    "final_biomass",
    "final_glucose",
    "final_fructose",
    "final_total_sugar",
    "sugar_consumed",
    "final_ethanol",
    "ethanol_produced",
    "mode_count_growth",
    "mode_count_turnover",
    "mode_count_sugar_depleted",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "min_state_value",
    "has_negative_saved_states",
    "simulation_elapsed_seconds",
    "ode_solve_elapsed_seconds",
    "rhs_elapsed_seconds",
    "history_reconstruction_elapsed_seconds",
    "scenario_elapsed_seconds",
    "rhs_call_count",
    "rhs_lp_solve_count",
    "flux_reconstruction_solve_count",
    "total_lp_solve_count",
    "oxygen_derivative_policy",
    "carbohydrate_derivative_policy",
]
const BENCHMARK_CONTRACT_REQUIRED_COMPARISON_COLUMNS = [
    "scenario_id",
    "solver_label",
    "algorithm_label",
    "ode_abstol",
    "ode_reltol",
    "lp_atol",
    "reconstruct_fluxes",
    "retcode",
    "termination_reason",
    "final_time",
    "final_biomass",
    "final_total_sugar",
    "final_ethanol",
    "simulation_elapsed_seconds",
    "ode_solve_elapsed_seconds",
    "rhs_elapsed_seconds",
    "history_reconstruction_elapsed_seconds",
    "scenario_elapsed_seconds",
    "rhs_call_count",
    "rhs_lp_solve_count",
    "flux_reconstruction_solve_count",
    "total_lp_solve_count",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "oxygen_derivative_policy",
    "carbohydrate_derivative_policy",
]
const BENCHMARK_CONTRACT_EXPECTED_MULTI_BACKEND_SCENARIO_IDS = [
    "highs_reconstruct_true",
    "highs_reconstruct_false",
    "gurobi_reconstruct_true",
    "gurobi_reconstruct_false",
]

function _benchmark_contract_script_text()
    @test isfile(BENCHMARK_CONTRACT_SCRIPT_PATH)
    return read(BENCHMARK_CONTRACT_SCRIPT_PATH, String)
end

function _benchmark_contract_run_script(output_dir::AbstractString)
    cmd = addenv(
        `$(Base.julia_cmd()) --project=$BENCHMARK_CONTRACT_PROJECT_ROOT $BENCHMARK_CONTRACT_SCRIPT_PATH`,
        "DFBA_BENCH_TFINAL_HOURS" => "0.25",
        "DFBA_BENCH_SAVEAT_HOURS" => "0.25",
        "DFBA_BENCH_OUTPUT_DIR" => output_dir,
        "DFBA_BENCH_SOLVER_BACKENDS" => "HiGHS",
        "DFBA_BENCH_ALGORITHM" => "Tsit5",
        "DFBA_BENCH_ODE_ABSTOL" => "1.0e-7",
        "DFBA_BENCH_ODE_RELTOL" => "1.0e-7",
        "DFBA_BENCH_LP_ATOL" => "1.0e-7",
        "DFBA_BENCH_RECONSTRUCT" => "false",
    )
    run(pipeline(cmd; stdout = devnull, stderr = devnull))
    return nothing
end

@testset "Benchmark script structural output contract" begin
    script_text = _benchmark_contract_script_text()

    for required_text in (
        "benchmark_summary.csv",
        "benchmark_metadata.toml",
        "DFBA_BENCH_TFINAL_HOURS",
        "DFBA_BENCH_SAVEAT_HOURS",
        "DFBA_BENCH_OUTPUT_DIR",
        "DFBA_BENCH_RECONSTRUCT",
        "DFBA_BENCH_SOLVER_BACKENDS",
        "DFBA_BENCH_ALGORITHM",
        "DFBA_BENCH_ODE_ABSTOL",
        "DFBA_BENCH_ODE_RELTOL",
        "DFBA_BENCH_LP_ATOL",
        "DFBA_BENCH_ALLOW_GUROBI_RODAS5P",
        "const BENCHMARK_SUMMARY_COLUMNS",
        "DEFAULT_BENCHMARK_SOLVER_BACKEND = \"HiGHS\"",
        "DEFAULT_BENCHMARK_ALGORITHM = \"Rodas5P\"",
        "DEFAULT_BENCHMARK_ODE_ABSTOL = 1.0e-8",
        "DEFAULT_BENCHMARK_ODE_RELTOL = 1.0e-8",
        "DEFAULT_BENCHMARK_LP_ATOL = 1.0e-8",
    )
        @test occursin(required_text, script_text)
    end

    for column in BENCHMARK_CONTRACT_EXPECTED_COLUMNS
        @test occursin("\"$column\"", script_text)
    end

    for column in BENCHMARK_CONTRACT_REQUIRED_COMPARISON_COLUMNS
        @test column in BENCHMARK_CONTRACT_EXPECTED_COLUMNS
        @test occursin("\"$column\"", script_text)
    end
end

@testset "Benchmark script multi-backend comparison contract" begin
    script_text = _benchmark_contract_script_text()

    @test occursin("backend_id = lowercase(solver_label)", script_text)
    @test occursin(
        "scenario_id = \"\$(backend.backend_id)_\$(reconstruction.scenario_id)\"",
        script_text,
    )
    @test occursin("DFBA_BENCH_SOLVER_BACKENDS", script_text)
    @test occursin("DFBA_BENCH_ALGORITHM", script_text)
    @test occursin("DFBA_BENCH_ODE_ABSTOL", script_text)
    @test occursin("DFBA_BENCH_ODE_RELTOL", script_text)
    @test occursin("DFBA_BENCH_LP_ATOL", script_text)
    @test occursin("DFBA_BENCH_ALLOW_GUROBI_RODAS5P", script_text)
    @test occursin("DEFAULT_BENCHMARK_SOLVER_BACKEND = \"HiGHS\"", script_text)
    @test occursin("algorithm = algorithm_config.algorithm", script_text)
    @test occursin("ode_abstol = tolerance_config.ode_abstol", script_text)
    @test occursin("ode_reltol = tolerance_config.ode_reltol", script_text)
    @test occursin("lp_atol = tolerance_config.lp_atol", script_text)
    @test occursin("Rodas5P(autodiff = OrdinaryDiffEq.AutoFiniteDiff())", script_text)
    @test occursin("OrdinaryDiffEq.Tsit5()", script_text)
    @test occursin("Gurobi benchmark with Rodas5P is disabled by default", script_text)

    for scenario_id in BENCHMARK_CONTRACT_EXPECTED_MULTI_BACKEND_SCENARIO_IDS
        expected_backend = startswith(scenario_id, "gurobi_") ? "Gurobi" : "HiGHS"
        expected_reconstruct = endswith(scenario_id, "_true") ? "reconstruct_true" : "reconstruct_false"
        expected_backend_id = lowercase(expected_backend)
        @test scenario_id == "$(expected_backend_id)_$(expected_reconstruct)"
    end

    for metadata_key in (
        "selected_solver_backends",
        "solver_labels",
        "scenario_ids",
        "algorithm_label",
        "selected_algorithms",
        "default_algorithm_label",
        "ode_abstol",
        "ode_reltol",
        "lp_atol",
        "allow_gurobi_rodas5p",
        "optional_solver_backend_note",
    )
        @test occursin("\"$metadata_key\"", script_text)
    end

    @test occursin("FERMENTATIONDFBA_TEST_BENCHMARK", read(@__FILE__, String))
end

if get(ENV, "FERMENTATIONDFBA_TEST_BENCHMARK", "") == "1"
    @testset "Optional benchmark script temp execution contract" begin
        mktempdir() do output_dir
            _benchmark_contract_run_script(output_dir)

            summary_path = joinpath(output_dir, "benchmark_summary.csv")
            metadata_path = joinpath(output_dir, "benchmark_metadata.toml")
            @test isfile(summary_path)
            @test isfile(metadata_path)

            summary = DataFrame(CSV.File(summary_path))
            metadata = TOML.parsefile(metadata_path)

            @test names(summary) == BENCHMARK_CONTRACT_EXPECTED_COLUMNS
            @test nrow(summary) == 1
            @test summary[1, "scenario_id"] == "highs_reconstruct_false"
            @test summary[1, "solver_label"] == "HiGHS"
            @test summary[1, "algorithm_label"] == "Tsit5"
            @test isapprox(summary[1, "ode_abstol"], 1.0e-7; atol = 0.0, rtol = 1.0e-12)
            @test isapprox(summary[1, "ode_reltol"], 1.0e-7; atol = 0.0, rtol = 1.0e-12)
            @test isapprox(summary[1, "lp_atol"], 1.0e-7; atol = 0.0, rtol = 1.0e-12)
            @test summary[1, "reconstruct_fluxes"] == false
            @test summary[1, "retcode"] == "Success"
            @test summary[1, "oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
            @test summary[1, "carbohydrate_derivative_policy"] == "empirical_not_r_4048"

            @test metadata["benchmark_name"] == "sequential_reduced_dfba"
            @test metadata["created_by_script"] == "scripts/main_benchmark.jl"
            @test metadata["algorithm_label"] == "Tsit5"
            @test metadata["selected_algorithms"] == ["Tsit5"]
            @test metadata["default_algorithm_label"] == "Rodas5P"
            @test isapprox(metadata["ode_abstol"], 1.0e-7; atol = 0.0, rtol = 1.0e-12)
            @test isapprox(metadata["ode_reltol"], 1.0e-7; atol = 0.0, rtol = 1.0e-12)
            @test isapprox(metadata["lp_atol"], 1.0e-7; atol = 0.0, rtol = 1.0e-12)
            @test metadata["allow_gurobi_rodas5p"] == false
            @test metadata["selected_solver_backends"] == ["HiGHS"]
            @test metadata["solver_labels"] == ["HiGHS"]
            @test metadata["scenario_ids"] == ["highs_reconstruct_false"]
        end
    end
else
    @info(
        "Skipping optional benchmark script temp execution contract; " *
        "set FERMENTATIONDFBA_TEST_BENCHMARK=1 to enable it.",
    )
end
