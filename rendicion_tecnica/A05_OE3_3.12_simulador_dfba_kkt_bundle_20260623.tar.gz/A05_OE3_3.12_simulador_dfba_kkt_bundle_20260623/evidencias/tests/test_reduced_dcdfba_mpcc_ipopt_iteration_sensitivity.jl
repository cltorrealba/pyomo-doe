using DataFrames

function _reduced_mpcc_ipopt_iter_test_sweep(;
    first_scenario_ready::Bool,
    first_scenario_solver_status::String,
    second_scenario_ready::Bool,
    second_scenario_solver_status::String,
    solve_scale::Float64,
)
    table = DataFrame(
        "scenario_id" => ["scenario_001", "scenario_002"],
        "scenario_status" => ["completed", "completed"],
        "t0" => [0.0, 0.0],
        "tfinal" => [0.25, 1.0],
        "horizon" => [0.25, 1.0],
        "nfe" => [1, 2],
        "degree" => [3, 3],
        "boundary_dt" => [0.25, 0.5],
        "n_boundary_points" => [2, 3],
        "n_collocation_points" => [3, 6],
        "solver_status" => [first_scenario_solver_status, second_scenario_solver_status],
        "primal_status" => ["FEASIBLE_POINT", "FEASIBLE_POINT"],
        "solve_elapsed_seconds" => [10.0 * solve_scale, 30.0 * solve_scale],
        "candidate_residual_feasible" => [true, true],
        "candidate_iteration_limit_residual_feasible" => [
            first_scenario_solver_status == "ITERATION_LIMIT",
            second_scenario_solver_status == "ITERATION_LIMIT",
        ],
        "candidate_trajectory_ready" => [first_scenario_ready, second_scenario_ready],
        "candidate_is_scientific_simulation" => [false, false],
        "residual_thresholds_satisfied" => [true, true],
        "dominant_residual" => ["max_mass_balance_residual", "max_mass_balance_residual"],
        "next_recommended_action" => [
            first_scenario_ready ? "extract_candidate_trajectory" :
            "review_iteration_limit_residual_feasible_candidate",
            second_scenario_ready ? "extract_candidate_trajectory" :
            "review_iteration_limit_residual_feasible_candidate",
        ],
        "candidate_warning_count" => [first_scenario_ready ? 0 : 1, second_scenario_ready ? 0 : 1],
        "max_rhs_residual" => [1.0e-12, 2.0e-12],
        "max_mass_balance_residual" => [4.0e-7, 7.0e-7],
        "max_lower_bound_violation" => [0.0, 0.0],
        "max_upper_bound_violation" => [0.0, 0.0],
        "max_stationarity_residual" => [1.0e-8, 2.0e-8],
        "max_lower_complementarity_residual" => [5.0e-7, 7.0e-7],
        "max_upper_complementarity_residual" => [4.0e-7, 8.0e-7],
        "max_state_abs_difference" => [1.0e-7 / solve_scale, 1.0e-6 / solve_scale],
        "max_state_rmse" => [8.0e-8 / solve_scale, 9.0e-7 / solve_scale],
        "max_state_relative_rmse" => [1.0e-4 / solve_scale, 2.0e-4 / solve_scale],
        "final_biomass_difference" => [1.0e-7, 1.0e-6],
        "final_glucose_difference" => [-1.0e-8, -1.0e-7],
        "final_fructose_difference" => [-1.0e-8, -1.0e-7],
        "final_ethanol_difference" => [1.0e-8, 1.0e-7],
        "final_total_sugar_difference" => [-2.0e-8, -2.0e-7],
        "min_candidate_state_value" => [0.0, 0.0],
        "full_dfba_cold_reference_deferred" => [true, true],
        "reduced_full_equivalence_claimed" => [false, false],
        "persistent_lp_baseline_used" => [false, false],
        "indices_reacciones_used" => [false, false],
        "r0001_used_as_oxygen" => [false, false],
        "error_type" => [missing, missing],
        "error_message" => [missing, missing],
    )
    metadata = Dict{String, Any}(
        "sweep_type" => "synthetic_reduced_mpcc_solve_attempt_short_horizon_sweep",
        "n_scenarios" => 2,
        "n_completed_scenarios" => 2,
        "outputs_written" => false,
        "sweep_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
    )
    return ReducedDCDFBAMPCCSolveAttemptSweepResult(
        table,
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        metadata,
    )
end

@testset "Reduced MPCC Ipopt iteration sensitivity synthetic aggregation" begin
    sweep_100 = _reduced_mpcc_ipopt_iter_test_sweep(
        first_scenario_ready = false,
        first_scenario_solver_status = "ITERATION_LIMIT",
        second_scenario_ready = false,
        second_scenario_solver_status = "ITERATION_LIMIT",
        solve_scale = 1.0,
    )
    sweep_500 = _reduced_mpcc_ipopt_iter_test_sweep(
        first_scenario_ready = true,
        first_scenario_solver_status = "LOCALLY_SOLVED",
        second_scenario_ready = false,
        second_scenario_solver_status = "ITERATION_LIMIT",
        solve_scale = 2.0,
    )

    sensitivity = sweep_reduced_dcdfba_mpcc_ipopt_iterations(
        [sweep_100, sweep_500];
        ipopt_max_iter_values = [100, 500],
    )
    table = sensitivity.sensitivity_table
    metadata = sensitivity.metadata

    @test sensitivity isa ReducedDCDFBAMPCCIpoptIterationSensitivityResult
    @test sensitivity.sweep_results == [sweep_100, sweep_500]
    @test size(table, 1) == 4
    @test table[1, "iteration_case_id"] == "iter_001_scenario_001"
    @test table[3, "iteration_case_id"] == "iter_002_scenario_001"
    @test table[1, "ipopt_max_iter"] == 100
    @test table[3, "ipopt_max_iter"] == 500
    @test table[1, "candidate_trajectory_ready"] == false
    @test table[3, "candidate_trajectory_ready"] == true
    @test table[3, "trajectory_ready_improved_vs_previous_iter"] == true
    @test table[4, "trajectory_ready_improved_vs_previous_iter"] == false
    @test table[1, "residual_feasible_improved_vs_previous_iter"] == true
    @test table[3, "solver_status"] == "LOCALLY_SOLVED"
    @test table[3, "next_recommended_action"] == "extract_candidate_trajectory"
    @test table[1, "scientific_baseline"] == "full_dfba_cold_deferred"
    @test table[1, "full_dfba_cold_reference_deferred"] == true
    @test table[1, "reduced_full_equivalence_claimed"] == false
    @test table[1, "persistent_lp_baseline_used"] == false
    @test table[1, "hsl_required"] == false
    @test table[1, "ma57_required"] == false
    @test table[1, "indices_reacciones_used"] == false
    @test table[1, "r0001_used_as_oxygen"] == false

    @test metadata["sensitivity_type"] == "reduced_dcdfba_mpcc_ipopt_iteration_sensitivity"
    @test metadata["ipopt_max_iter_values"] == [100, 500]
    @test metadata["n_rows"] == 4
    @test metadata["n_completed_rows"] == 4
    @test metadata["residual_feasible_row_count"] == 4
    @test metadata["trajectory_ready_row_count"] == 1
    @test metadata["iteration_limit_residual_feasible_row_count"] == 3
    @test metadata["solver_status_counts"]["ITERATION_LIMIT"] == 3
    @test metadata["solver_status_counts"]["LOCALLY_SOLVED"] == 1
    @test metadata["first_trajectory_ready_ipopt_max_iter_by_scenario"]["horizon=0.25;nfe=1"] == 500
    @test metadata["first_trajectory_ready_ipopt_max_iter_by_scenario"]["horizon=1.0;nfe=2"] === missing
    @test metadata["scenarios_with_trajectory_ready_count"] == 1
    @test metadata["outputs_written"] == false
    @test metadata["sensitivity_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
end

@testset "Reduced MPCC Ipopt iteration sensitivity validation" begin
    sweep = _reduced_mpcc_ipopt_iter_test_sweep(
        first_scenario_ready = false,
        first_scenario_solver_status = "ITERATION_LIMIT",
        second_scenario_ready = false,
        second_scenario_solver_status = "ITERATION_LIMIT",
        solve_scale = 1.0,
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_ipopt_iterations(
        ReducedDCDFBAMPCCSolveAttemptSweepResult[];
        ipopt_max_iter_values = [100],
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_ipopt_iterations(
        [sweep];
        ipopt_max_iter_values = Int[],
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_ipopt_iterations(
        [sweep];
        ipopt_max_iter_values = [-1],
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_ipopt_iterations(
        [sweep];
        ipopt_max_iter_values = [100, 100],
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_ipopt_iterations(
        [sweep];
        ipopt_max_iter_values = [100, 200],
    )
end

@testset "Reduced MPCC Ipopt iteration sensitivity opt-in real run" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_IPOPT_ITERATIONS", "0") == "1"
        project_root = normpath(joinpath(@__DIR__, ".."))
        model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        sensitivity = sweep_reduced_dcdfba_mpcc_ipopt_iterations(
            model,
            reaction_map;
            horizons = [0.25],
            nfe_values = [1],
            ipopt_max_iter_values = [100, 200],
            degree = 3,
        )

        @test sensitivity isa ReducedDCDFBAMPCCIpoptIterationSensitivityResult
        @test size(sensitivity.sensitivity_table, 1) == 2
        @test sensitivity.metadata["outputs_written"] == false
        @test sensitivity.metadata["sensitivity_is_scientific_simulation"] == false
        @test sensitivity.metadata["full_dfba_cold_reference_deferred"] == true
    else
        @info "Skipping reduced MPCC Ipopt iteration sensitivity real run; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_IPOPT_ITERATIONS=1 to run it."
        @test true
    end
end
