import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_rhs_derivative_starts_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_rhs_derivative_starts_test_simulation()
    time = [0.0, 0.25]
    initial_state = zenteno_state_to_vector(default_zenteno_initial_state())
    states = hcat(initial_state, initial_state)
    fluxes = reshape([0.02, 0.02], 1, 2)
    return SimulationResult(
        time,
        states;
        fluxes = fluxes,
        metadata = Dict{String, Any}(
            "flux_rxn_ids" => ["r_2111"],
            "model_scope" => "reduced",
            "termination_reason" => "synthetic_constant_state",
        ),
    )
end

@testset "Reduced DC-dFBA RHS-consistent derivative starts metadata" begin
    model, reaction_map = _reduced_dcdfba_rhs_derivative_starts_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        include_rhs = true,
        use_dynamic_bounds = true,
    )
    metadata = problem.metadata

    @test metadata["rhs_consistent_derivative_start_applied"] == true
    @test metadata["rhs_consistent_derivative_start_policy"] ==
          "set_state_derivative_starts_to_reduced_dfba_rhs_at_collocation_points"
    @test metadata["rhs_consistent_derivative_start_collocation_points"] == 3
    @test metadata["rhs_consistent_derivative_start_max_adjustment"] > 0.0
    @test metadata["rhs_consistent_derivative_start_max_abs_value"] > 0.0
    @test metadata["rhs_consistent_derivative_start_max_rhs_residual_after"] <= 1.0e-12
    @test metadata["rhs_consistent_derivative_start_oxygen_derivative_policy"] ==
          "dy6_fixed_zero_for_reduced_model"
    @test metadata["rhs_consistent_derivative_start_carbohydrate_policy"] ==
          "empirical_rhs_not_driven_by_r_4048"
    @test metadata["rhs_consistent_derivative_start_is_scientific_simulation"] == false
    @test problem.nlp.metadata["rhs_consistent_derivative_start_applied"] == true
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA RHS-consistent derivative starts skipped without RHS" begin
    model, reaction_map = _reduced_dcdfba_rhs_derivative_starts_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map; use_dynamic_bounds = true)
    metadata = problem.metadata

    @test metadata["rhs_consistent_derivative_start_applied"] == false
    @test metadata["rhs_consistent_derivative_start_policy"] == "not_applied_no_rhs_residuals"
    @test metadata["rhs_consistent_derivative_start_collocation_points"] == 0
    @test metadata["rhs_consistent_derivative_start_max_adjustment"] == 0.0
    @test metadata["rhs_consistent_derivative_start_max_abs_value"] == 0.0
    @test isnan(metadata["rhs_consistent_derivative_start_max_rhs_residual_after"])
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA solve-attempt diagnostics after RHS-consistent derivative starts" begin
    model, reaction_map = _reduced_dcdfba_rhs_derivative_starts_test_model_and_map()
    simulation = _reduced_dcdfba_rhs_derivative_starts_test_simulation()
    problem = build_reduced_dcdfba_mpcc_solve_attempt_problem(
        model,
        reaction_map;
        sequential_initialization = simulation,
        ipopt_max_iter = 0,
    )
    report = diagnose_reduced_dcdfba_mpcc_solve_attempt(problem)

    @test problem.metadata["rhs_consistent_derivative_start_applied"] == true
    @test problem.metadata["rhs_consistent_derivative_start_max_rhs_residual_after"] <= 1.0e-12
    @test report.metadata["rhs_consistent_derivative_start_applied"] == true
    @test report.scaling_summary["rhs_consistent_derivative_start_collocation_points"] == 3.0
    @test report.scaling_summary["rhs_consistent_derivative_start_max_rhs_residual_after"] <= 1.0e-12
    @test report.residual_values["max_rhs_residual"] <= 1.0e-12
    @test report.residual_values["max_mass_balance_residual"] <= 1.0e-8
    @test report.residual_values["max_lower_bound_violation"] <= 1.0e-8
    @test report.residual_values["max_upper_bound_violation"] <= 1.0e-8
    @test report.residual_values["max_stationarity_residual"] <= 1.0e-10
    @test report.residual_thresholds_satisfied == true
    @test !("max_rhs_residual_above_threshold" in report.warnings)
    @test !("rhs_consistent_derivative_start_rhs_residual_large" in report.warnings)
    @test report.dominant_residual == "max_mass_balance_residual"
    @test !("max_stationarity_residual_above_threshold" in report.warnings)
    @test report.metadata["solver_call_performed"] == false
    @test report.metadata["solve_attempt_is_scientific_simulation"] == false
    @test JuMP.termination_status(problem.smoke_problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end
