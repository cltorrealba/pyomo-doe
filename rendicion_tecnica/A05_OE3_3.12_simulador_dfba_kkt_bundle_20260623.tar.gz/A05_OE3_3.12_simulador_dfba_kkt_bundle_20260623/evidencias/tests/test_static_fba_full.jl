import MathOptInterface as MOI

@testset "Full static FBA smoke solve" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")

    model = load_full_model(paths_config)
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    result = solve_fba(model; objective_rxn_id = "r_2111", atol = 1.0e-6)

    @test result.status == MOI.OPTIMAL
    @test length(result.fluxes) == 4131
    @test result.objective_rxn_id == "r_2111"
    @test result.objective_index == reaction_index(model, "r_2111")
    @test result.objective_value > 0.0
    @test isapprox(result.objective_value, 0.07866618384648842; rtol = 1.0e-5, atol = 1.0e-7)
    @test result.mass_balance_residual <= 1.0e-6
    @test result.max_lower_bound_violation <= 1.0e-6
    @test result.max_upper_bound_violation <= 1.0e-6

    oxygen_flux = result.fluxes[reaction_index(model, "r_1992")]
    @test isapprox(oxygen_flux, 0.0; atol = 1.0e-8)
    @test has_reaction(model, "r_4048")

    @test model.lb == original_lb
    @test model.ub == original_ub
end
