@testset "Reduced MPCC windowed 72h simulation runner synthetic candidate" begin
    initial = _reduced_mpcc_attempt_test_initial_state()
    first, first_final = _reduced_mpcc_attempt_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, _ = _reduced_mpcc_attempt_test_comparison(
        t0 = 0.25,
        tfinal = 0.5,
        initial_state = first_final,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )

    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first, second])
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 0.5,
    )
    runner = run_reduced_dcdfba_mpcc_windowed_72h_simulation(attempt)
    metadata = runner.metadata
    table = runner.runner_table

    @test runner isa ReducedDCDFBAMPCCWindowed72HSimulationRunnerResult
    @test runner.attempt_result === attempt
    @test runner.boundary_result === continuation.boundary_candidate
    @test runner.sequential_reference === continuation.sequential_reference
    @test size(table, 1) == 1
    @test table[1, "runner_id"] == "windowed_72h_runner"
    @test table[1, "target_horizon"] == 0.5
    @test table[1, "target_is_72h"] == false
    @test table[1, "runner_traffic_light"] == "green"
    @test table[1, "runner_status"] == "candidate_ready_for_review"
    @test table[1, "runner_viable"] == true
    @test table[1, "candidate_ready_for_review"] == true

    @test metadata["runner_type"] ==
          "reduced_dcdfba_mpcc_windowed_72h_simulation_runner"
    @test metadata["runner_strategy"] == "serial_windowed_reduced_mpcc_continuation"
    @test metadata["runner_scope"] == "reduced_dfba_windowed_candidate"
    @test metadata["attempt_type"] == "reduced_dcdfba_mpcc_windowed_simulation_attempt"
    @test metadata["target_horizon"] == 0.5
    @test metadata["target_is_72h"] == false
    @test metadata["horizon_reached"] == 0.5
    @test metadata["horizon_gap"] == 0.0
    @test metadata["target_completed"] == true
    @test metadata["runner_traffic_light"] == "green"
    @test metadata["runner_status"] == "candidate_ready_for_review"
    @test metadata["runner_viable"] == true
    @test metadata["candidate_ready_for_review"] == true
    @test metadata["boundary_candidate_available"] == true
    @test metadata["sequential_reference_available"] == true
    @test metadata["global_state_metrics_available"] == true
    @test metadata["n_requested_windows"] == 2
    @test metadata["n_completed_windows"] == 2
    @test metadata["n_failed_windows"] == 0
    @test metadata["outputs_written"] == false
    @test metadata["runner_is_scientific_simulation"] == false
    @test metadata["runner_is_validated_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["scientific_baseline"] == "full_dfba_cold_deferred"
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["uses_window_retries"] == false
    @test metadata["uses_retry_replacement"] == false
    @test metadata["uses_cascade_rebuild"] == false
    @test metadata["global_monolithic_mpcc_solve_attempted"] == false
    @test metadata["global_polish_deferred"] == true
    @test metadata["global_polish_deferred_reason"] ==
          "monolithic_mumps_linear_algebra_cost"
    @test metadata["recommended_next_action"] == "extend_windowed_runner_to_72h"
end

@testset "Reduced MPCC windowed 72h simulation runner target gate" begin
    initial = _reduced_mpcc_attempt_test_initial_state()
    first, _ = _reduced_mpcc_attempt_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first])
    runner = run_reduced_dcdfba_mpcc_windowed_72h_simulation(
        continuation;
        target_horizon = 72.0,
    )

    @test runner.metadata["target_horizon"] == 72.0
    @test runner.metadata["target_is_72h"] == true
    @test runner.metadata["target_completed"] == false
    @test runner.metadata["runner_traffic_light"] == "red"
    @test runner.metadata["runner_status"] == "target_incomplete"
    @test runner.metadata["runner_viable"] == false
    @test runner.metadata["candidate_ready_for_review"] == false
    @test runner.metadata["horizon_reached"] == 0.25
    @test runner.metadata["horizon_gap"] ≈ 71.75
    @test runner.metadata["recommended_next_action"] ==
          "repair_or_extend_windowed_runner_to_target"
end

@testset "Reduced MPCC windowed 72h simulation runner validation" begin
    initial = _reduced_mpcc_attempt_test_initial_state()
    first, _ = _reduced_mpcc_attempt_test_comparison(
        t0 = 0.0,
        tfinal = 0.25,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first])
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 0.25,
    )

    @test_throws ArgumentError run_reduced_dcdfba_mpcc_windowed_72h_simulation(
        continuation;
        target_horizon = 0.0,
    )
    @test_throws ArgumentError run_reduced_dcdfba_mpcc_windowed_72h_simulation(
        attempt;
        expected_target_horizon = 0.5,
    )
    @test run_reduced_dcdfba_mpcc_windowed_72h_simulation(
        attempt;
        expected_target_horizon = 0.25,
    ).metadata["target_horizon"] == 0.25
end

@testset "Reduced MPCC windowed 72h simulation runner opt-in real run" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_WINDOWED_72H_RUNNER", "0") == "1"
        project_root = normpath(joinpath(@__DIR__, ".."))
        model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        result = run_reduced_dcdfba_mpcc_windowed_72h_simulation(
            model,
            reaction_map;
            target_horizon = 0.5,
            window_hours = 0.5,
            nfe_per_window = 2,
            degree = 3,
        )

        @test result isa ReducedDCDFBAMPCCWindowed72HSimulationRunnerResult
        @test size(result.runner_table, 1) == 1
        @test result.metadata["outputs_written"] == false
        @test result.metadata["runner_is_scientific_simulation"] == false
        @test result.metadata["global_monolithic_mpcc_solve_attempted"] == false
    else
        @info "Skipping reduced MPCC windowed 72h runner real run; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_WINDOWED_72H_RUNNER=1 to run it."
        @test true
    end
end
