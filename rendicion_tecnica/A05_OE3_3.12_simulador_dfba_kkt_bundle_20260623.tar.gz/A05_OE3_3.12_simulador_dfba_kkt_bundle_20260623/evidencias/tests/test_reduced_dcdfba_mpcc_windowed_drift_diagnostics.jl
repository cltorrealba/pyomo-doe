const REDUCED_MPCC_DRIFT_TEST_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _reduced_mpcc_drift_test_initial_state()
    y = zeros(19)
    y[1] = 1.0
    y[2] = 0.1
    y[3] = 10.0
    y[4] = 8.0
    y[5] = 0.2
    y[6] = 0.0
    y[7] = 0.2
    y[8] = 0.1
    y[9:19] .= 0.01
    return y
end

function _reduced_mpcc_drift_test_comparison(;
    t0::Float64,
    tfinal::Float64,
    initial_state::AbstractVector,
    ethanol_offset::Float64,
    trajectory_ready::Bool,
    solver_status::String,
)
    times = [t0, tfinal]
    sequential_states = repeat(Float64.(initial_state), 1, 2)
    sequential_states[1, 2] += 0.1
    sequential_states[3, 2] -= 0.5
    sequential_states[4, 2] -= 0.25
    sequential_states[5, 2] += 0.2
    sequential_states[6, 2] = 0.0

    candidate_states = copy(sequential_states)
    candidate_states[5, 2] += ethanol_offset

    sequential = SimulationResult(
        times,
        sequential_states;
        metadata = Dict{String, Any}(
            "model_scope" => "reduced",
            "state_names" => copy(REDUCED_MPCC_DRIFT_TEST_STATE_NAMES),
            "retcode" => "Success",
            "termination_reason" => "synthetic",
        ),
    )
    boundary = SimulationResult(
        times,
        candidate_states;
        metadata = Dict{String, Any}(
            "model_scope" => "reduced",
            "state_names" => copy(REDUCED_MPCC_DRIFT_TEST_STATE_NAMES),
            "retcode" => solver_status,
            "is_scientific_simulation" => false,
        ),
    )
    collocation = SimulationResult(
        [t0 + (tfinal - t0) / 3, t0 + 2 * (tfinal - t0) / 3, tfinal],
        repeat(candidate_states[:, 2:2], 1, 3);
        metadata = copy(boundary.metadata),
    )
    diagnostics = ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(candidate_states),
        reshape(repeat(candidate_states[:, 2:2], 1, 3), 19, 1, 3),
        zeros(19, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(1, 1, 3),
        Dict{String, Float64}(
            "max_rhs_residual" => 1.0e-12,
            "max_mass_balance_residual" => 5.0e-7,
            "max_lower_bound_violation" => 0.0,
            "max_upper_bound_violation" => 0.0,
            "max_stationarity_residual" => 1.0e-8,
            "max_lower_complementarity_residual" => 5.0e-7,
            "max_upper_complementarity_residual" => 5.0e-7,
        ),
        Dict{String, Float64}(),
        Dict{String, Float64}(),
        String[],
        trajectory_ready ? String[] : ["candidate_solver_status_blocks_trajectory_extraction"],
        Dict{String, Any}("model_scope" => "reduced"),
    )
    trajectory_metadata = Dict{String, Any}(
        "model_scope" => "reduced",
        "candidate_solver_status" => solver_status,
        "candidate_primal_status" => "FEASIBLE_POINT",
        "candidate_residual_thresholds_satisfied" => true,
        "candidate_residual_feasible" => true,
        "candidate_iteration_limit_residual_feasible" => solver_status == "ITERATION_LIMIT",
        "candidate_warning_count" => solver_status == "ITERATION_LIMIT" ? 1 : 0,
        "candidate_trajectory_ready" => trajectory_ready,
        "trajectory_candidate_ready" => trajectory_ready,
        "trajectory_candidate_is_scientific_simulation" => false,
        "trajectory_candidate_is_validated_simulation" => false,
        "trajectory_candidate_solved_trajectory_claimed" => false,
        "post_solve_next_recommended_action" =>
            trajectory_ready ? "extract_candidate_trajectory" :
            "review_iteration_limit_residual_feasible_candidate",
        "solve_elapsed_seconds" => 3.0,
        "candidate_grid_nfe" => 1,
        "candidate_collocation_degree" => 3,
        "candidate_grid_tspan" => (t0, tfinal),
        "candidate_state_names" => copy(REDUCED_MPCC_DRIFT_TEST_STATE_NAMES),
    )
    trajectory = ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary,
        collocation,
        diagnostics,
        trajectory_metadata,
    )
    return compare_reduced_dcdfba_mpcc_to_sequential(sequential, trajectory),
           copy(candidate_states[:, end])
end

@testset "Reduced MPCC windowed drift diagnostics synthetic aggregation" begin
    initial = _reduced_mpcc_drift_test_initial_state()
    first, first_final = _reduced_mpcc_drift_test_comparison(
        t0 = 0.0,
        tfinal = 0.5,
        initial_state = initial,
        ethanol_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, _ = _reduced_mpcc_drift_test_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = first_final,
        ethanol_offset = 0.08,
        trajectory_ready = false,
        solver_status = "ITERATION_LIMIT",
    )
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first, second])
    thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
        max_state_abs_difference = 0.05,
        max_state_relative_rmse = 0.05,
    )
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 1.0,
        thresholds = thresholds,
    )

    diagnostic = diagnose_reduced_dcdfba_mpcc_windowed_drift(
        attempt;
        thresholds = thresholds,
    )

    @test diagnostic isa ReducedDCDFBAMPCCWindowedDriftDiagnosticResult
    @test diagnostic.attempt_result === attempt
    @test size(diagnostic.window_drift_table, 1) == 2
    @test size(diagnostic.state_drift_table, 1) == 60
    @test size(diagnostic.timepoint_drift_table, 1) == 140
    @test diagnostic.window_drift_table[1, "state_drift_pass"] == true
    @test diagnostic.window_drift_table[2, "state_drift_pass"] == false
    @test diagnostic.window_drift_table[2, "dominant_abs_state"] == "ethanol"
    @test diagnostic.window_drift_table[2, "dominant_relative_state"] == "ethanol"
    @test diagnostic.window_drift_table[2, "solver_status"] == "ITERATION_LIMIT"
    @test diagnostic.metadata["diagnostic_type"] ==
          "reduced_dcdfba_mpcc_windowed_drift_diagnostics"
    @test diagnostic.metadata["first_state_drift_window_id"] == "window_002"
    @test diagnostic.metadata["first_not_trajectory_ready_window_id"] == "window_002"
    @test diagnostic.metadata["first_iteration_limit_window_id"] == "window_002"
    @test diagnostic.metadata["dominant_global_abs_state"] == "ethanol"
    @test diagnostic.metadata["dominant_global_relative_state"] == "ethanol"
    @test diagnostic.metadata["drift_pattern"] == "accumulated_windowed_drift"
    @test diagnostic.metadata["drift_coincides_with_iteration_limit"] == true
    @test diagnostic.metadata["recommended_next_action"] ==
          "inspect_solver_termination_and_state_propagation_at_first_drift_window"
    @test diagnostic.metadata["outputs_written"] == false
    @test diagnostic.metadata["drift_diagnostic_is_scientific_simulation"] == false
    @test diagnostic.metadata["solved_trajectory_claimed"] == false
    @test diagnostic.metadata["first_mpcc_target"] == "reduced_dfba"
    @test diagnostic.metadata["hsl_required"] == false
    @test diagnostic.metadata["ma57_required"] == false
    @test diagnostic.metadata["indices_reacciones_used"] == false
    @test diagnostic.metadata["r0001_used_as_oxygen"] == false

    ethanol_global = filter(
        row -> row.scope == "global" && row.state_name == "ethanol",
        diagnostic.state_drift_table,
    )
    @test size(ethanol_global, 1) == 1
    @test ethanol_global[1, "state_drift_pass"] == false
    @test ethanol_global[1, "is_focus_state"] == true
end

@testset "Reduced MPCC windowed drift diagnostics validation" begin
    initial = _reduced_mpcc_drift_test_initial_state()
    first, _ = _reduced_mpcc_drift_test_comparison(
        t0 = 0.0,
        tfinal = 0.5,
        initial_state = initial,
        ethanol_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first])

    @test diagnose_reduced_dcdfba_mpcc_windowed_drift(continuation) isa
          ReducedDCDFBAMPCCWindowedDriftDiagnosticResult
    @test_throws ArgumentError diagnose_reduced_dcdfba_mpcc_windowed_drift(
        continuation;
        thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
            max_state_relative_rmse = -1.0,
        ),
    )
end
