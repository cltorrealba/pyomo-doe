using DataFrames

function _reduced_mpcc_cascade_retry_horizon_test_result(;
    accepted::Bool,
    target_horizon::Float64 = 1.5,
)
    attempt, second_initial = _reduced_mpcc_retry_cascade_attempt()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = second_initial,
        trajectory_ready = accepted,
        solver_status = accepted ? "LOCALLY_SOLVED" : "ITERATION_LIMIT",
        biomass_offset = accepted ? 0.0 : 0.04,
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 2,
        traffic_light = accepted ? "green" : "yellow",
        residual_feasible = true,
        trajectory_ready = accepted,
        ipopt_max_iter = 500,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)
    runner = function (spec, y0)
        return _reduced_mpcc_retry_replacement_comparison(
            t0 = Float64(spec.t0),
            tfinal = Float64(spec.tfinal),
            initial_state = y0,
            trajectory_ready = true,
            solver_status = "LOCALLY_SOLVED",
            biomass_offset = 0.0,
        )
    end
    cascade = cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        policy;
        window_runner = runner,
    )
    return cascade
end

@testset "Reduced MPCC cascade retry horizon smoke aggregation" begin
    recovered = _reduced_mpcc_cascade_retry_horizon_test_result(accepted = true)
    unrecovered = _reduced_mpcc_cascade_retry_horizon_test_result(accepted = false)

    smoke = smoke_reduced_dcdfba_mpcc_cascade_retry_horizons([recovered, unrecovered])
    table = smoke.cascade_horizon_table
    metadata = smoke.metadata

    @test smoke isa ReducedDCDFBAMPCCWindowedCascadeRetryHorizonSmokeResult
    @test size(table, 1) == 2
    @test table[1, "cascade_horizon_case_id"] == "cascade_retry_horizon_001"
    @test table[1, "case_status"] == "completed"
    @test table[1, "cascade_rebuild_applied"] == true
    @test table[1, "retry_replacement_applied"] == true
    @test table[1, "windowed_candidate_rebuilt"] == true
    @test table[1, "cascade_replacement_window_index"] == 2
    @test table[1, "n_downstream_windows_requested"] == 1
    @test table[1, "n_downstream_windows_resolved"] == 1
    @test table[1, "nonterminal_replacement_applied"] == true
    @test table[2, "cascade_rebuild_applied"] == false
    @test table[2, "retry_replacement_applied"] == false
    @test table[2, "windowed_candidate_rebuilt"] == false
    @test table[2, "nonterminal_replacement_applied"] == false
    @test all(==(false), table[!, "outputs_written"])
    @test all(==(false), table[!, "smoke_is_scientific_simulation"])
    @test all(==(false), table[!, "solved_trajectory_claimed"])
    @test all(==("reduced_dfba"), table[!, "first_mpcc_target"])
    @test all(==(true), table[!, "full_model_kkt_deferred"])
    @test all(==(true), table[!, "dfvb_kkt_deferred"])
    @test all(==(false), table[!, "hsl_required"])
    @test all(==(false), table[!, "ma57_required"])
    @test all(==(false), table[!, "indices_reacciones_used"])
    @test all(==(false), table[!, "r0001_used_as_oxygen"])

    @test metadata["smoke_type"] ==
          "reduced_dcdfba_mpcc_windowed_cascade_retry_horizon_smoke"
    @test metadata["n_requested_cases"] == 2
    @test metadata["n_cases"] == 2
    @test metadata["n_completed_cases"] == 2
    @test metadata["n_failed_cases"] == 0
    @test metadata["n_cascade_results"] == 2
    @test metadata["cascade_rebuild_applied_count"] == 1
    @test metadata["retry_replacement_applied_count"] == 1
    @test metadata["nonterminal_replacement_count"] == 1
    @test metadata["downstream_resolve_case_count"] == 1
    @test metadata["first_nonterminal_cascade_case_id"] ==
          "cascade_retry_horizon_001"
    @test metadata["outputs_written"] == false
    @test metadata["smoke_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["recommended_next_action"] in (
        "extend_cascade_retry_horizon_grid",
        "inspect_first_non_green_cascade_retry_horizon",
    )
end

@testset "Reduced MPCC cascade retry horizon smoke validation" begin
    result = _reduced_mpcc_cascade_retry_horizon_test_result(accepted = true)

    @test_throws ArgumentError smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(
        ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult[],
    )
    retry_aware_attempt = _reduced_mpcc_retry_aware_base_attempt(
        traffic_light = "yellow",
        attempt_viable = false,
    )
    retry_aware_policy = _reduced_mpcc_retry_aware_policy(
        retry_aware_attempt;
        selected = 0,
        green_recovered = 0,
        trajectory_recovered = 0,
        residual_recovered = 0,
        all_green = false,
        all_trajectory = false,
    )
    retry_aware = attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
        retry_aware_attempt,
        retry_aware_policy,
    )
    @test_throws ArgumentError smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(
        [result];
        retry_aware_results = [retry_aware, retry_aware],
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_cascade_retry_horizon_specs(
        [0.75],
        0.0,
        0.5,
        2,
        3,
        100,
        [200, 300],
        500,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_cascade_retry_horizon_specs(
        [1.0],
        0.0,
        0.5,
        0,
        3,
        100,
        [200, 300],
        500,
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_cascade_retry_horizon_specs(
        [1.0],
        0.0,
        0.5,
        2,
        2,
        100,
        [200, 300],
        500,
    )
end
