using DataFrames

@testset "Dynamic control objective schedule helpers" begin
    schedule = dynamic_control_schedule_from_values(
        [20.0, 22.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
        fda_doses_g_L = [1.0],
        organic_doses_g_L = [0.2],
    )

    @test schedule.temperature_transition_times_h == [12.0]
    @test schedule.temperature_values_C == [20.0, 22.0]
    @test length(schedule.fda_events) == 1
    @test length(schedule.organic_events) == 1
    @test schedule.fda_events[1].total_product_g_L == 1.0
    @test schedule.organic_events[1].total_product_g_L == 0.2
    @test schedule.fda_nitrogen_fraction_gN_per_g == FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G

    @test_throws ArgumentError dynamic_control_schedule_from_values(
        [20.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
    )
end

@testset "Dynamic control candidate designs" begin
    smoke_designs = dynamic_control_candidate_designs(
        horizon_h = 48.0,
        control_interval_h = 12.0,
        temperature_profile_set = :smoke,
        nutrient_strategy_set = :smoke,
    )
    @test length(smoke_designs) == 12
    @test smoke_designs[1].candidate_id == "flat20__none"
    @test smoke_designs[1].profile_id == "flat20"
    @test smoke_designs[1].nutrient_strategy_id == "none"
    @test length(smoke_designs[1].temperature_values_C) == 4
    @test length(smoke_designs[1].fda_doses_g_L) == 3
    @test length(smoke_designs[1].organic_doses_g_L) == 3
    @test any(design -> design.nutrient_strategy_id == "springferm_early_0p2", smoke_designs)
    @test any(design -> design.profile_id == "cool18x2_warm22", smoke_designs)

    frontier_designs = dynamic_control_candidate_designs(
        horizon_h = 240.0,
        control_interval_h = 12.0,
        temperature_profile_set = :horizon_frontier,
        nutrient_strategy_set = :horizon_frontier,
        max_candidates = 8,
    )
    @test length(frontier_designs) == 8
    @test frontier_designs[1].candidate_id == "flat25__springferm_early_1p0_stress"
    @test frontier_designs[2].candidate_id == "flat25__springferm_split_0p5_0p5_mid"
    @test any(design -> design.profile_id == "warm25_until168_cool20", frontier_designs)
    @test all(length(design.temperature_values_C) == 20 for design in frontier_designs)
    @test all(length(design.fda_doses_g_L) == 19 for design in frontier_designs)
    @test sum(frontier_designs[2].organic_doses_g_L) == 1.0

    fda_frontier_designs = dynamic_control_candidate_designs(
        horizon_h = 336.0,
        control_interval_h = 12.0,
        temperature_profile_set = :horizon_fda_frontier,
        nutrient_strategy_set = :horizon_fda_frontier,
        max_candidates = 8,
    )
    @test length(fda_frontier_designs) == 8
    @test fda_frontier_designs[1].candidate_id == "flat25__fda_early_3p0_limit"
    @test fda_frontier_designs[2].candidate_id == "flat25__fda_early_2p5_late0p5"
    @test fda_frontier_designs[3].candidate_id == "flat25__fda_split_1p5_1p5_mid"
    @test all(design -> design.organic_doses_g_L == zeros(27), fda_frontier_designs)
    @test all(sum(design.fda_doses_g_L) <= 3.0 for design in fda_frontier_designs)
    @test all(length(design.temperature_values_C) == 28 for design in fda_frontier_designs)
    @test all(length(design.fda_doses_g_L) == 27 for design in fda_frontier_designs)

    limited_designs = dynamic_control_candidate_designs(
        horizon_h = 48.0,
        control_interval_h = 12.0,
        max_candidates = 5,
    )
    @test length(limited_designs) == 5
    @test allunique(design.candidate_id for design in limited_designs)
    @test limited_designs[4].candidate_id == "cool18_warm22__springferm_early_0p2"
    @test sum(limited_designs[4].organic_doses_g_L) == 0.2

    @test_throws ArgumentError dynamic_control_candidate_designs(max_candidates = 0)
    @test_throws ArgumentError dynamic_control_candidate_designs(temperature_profile_set = :bad)
    @test_throws ArgumentError DynamicControlCandidateDesign(
        candidate_id = "bad",
        profile_id = "flat20",
        nutrient_strategy_id = "bad",
        temperature_values_C = [20.0],
        fda_doses_g_L = [1.0],
        organic_doses_g_L = [0.0, 0.0],
    )
end

@testset "Dynamic control selection gates" begin
    table = DataFrame(
        candidate_id = ["a", "b", "c"],
        objective_value = [10.0, 8.0, 12.0],
        feasible = [true, true, false],
        final_total_sugar = [80.0, 130.0, 60.0],
        aroma_desirability_score = [0.2, 0.4, 0.9],
        cooling_energy_proxy_unweighted = [40.0, 35.0, 20.0],
        nutrient_total_product_g_L = [0.2, 0.0, 0.6],
        min_state_value = [0.0, -1.0e-9, 0.0],
        pareto_candidate = [true, true, true],
    )
    criteria = DynamicControlSelectionCriteria(
        final_total_sugar_max_g_L = 100.0,
        aroma_desirability_min_score = 0.1,
        cooling_energy_proxy_max = 50.0,
        nutrient_total_product_max_g_L = 0.5,
        max_negative_state_deficit = 1.0e-8,
        shortlist_count = 2,
    )
    dynamic_control_apply_selection_gates!(table; criteria = criteria)

    @test table.gate_pass == [true, false, false]
    @test table.selected_for_review == [true, false, false]
    @test table.selection_rank == [1, 0, 0]
    @test table.selection_basis[1] == "gate_pass_pareto"

    fallback = DataFrame(
        candidate_id = ["a", "b"],
        objective_value = [10.0, 8.0],
        feasible = [true, true],
        final_total_sugar = [180.0, 130.0],
        aroma_desirability_score = [0.2, 0.4],
        cooling_energy_proxy_unweighted = [40.0, 35.0],
        nutrient_total_product_g_L = [0.2, 0.0],
        min_state_value = [0.0, 0.0],
        pareto_candidate = [false, true],
    )
    dynamic_control_apply_selection_gates!(
        fallback;
        criteria = DynamicControlSelectionCriteria(
            final_total_sugar_max_g_L = 100.0,
            shortlist_count = 1,
        ),
    )
    @test fallback.selected_for_review == [false, true]
    @test fallback.selection_basis[2] == "feasible_fallback_pareto"

    @test_throws ArgumentError DynamicControlSelectionCriteria(shortlist_count = 0)
    @test_throws ArgumentError DynamicControlSelectionCriteria(aroma_desirability_min_score = 2.0)
end

@testset "Aroma desirability and cooling-energy proxy" begin
    window = AromaDesirabilityWindow("phenylethanol", 0.0, 1.0, 2.0; weight = 1.0)
    @test aroma_desirability_score(0.0, window) == 0.0
    @test aroma_desirability_score(1.0, window) == 1.0
    @test aroma_desirability_score(2.0, window) == 0.0
    @test isapprox(aroma_desirability_score(0.5, window), 0.5; atol = 1.0e-12)

    states = zeros(19, 3)
    states[3, :] .= [100.0, 90.0, 85.0]
    states[4, :] .= [100.0, 90.0, 85.0]
    states[14, :] .= [0.0, 0.5, 1.0]
    result = SimulationResult(
        [0.0, 12.0, 24.0],
        states;
        metadata = Dict{String, Any}(
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "termination_time" => 24.0,
            "min_state_value" => 0.0,
            "state_names" => FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES,
        ),
    )
    schedule = dynamic_control_schedule_from_values(
        [18.0, 18.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
    )

    @test aroma_desirability_score(result, [window]) == 1.0
    @test isapprox(
        dynamic_control_energy_proxy(
            result,
            schedule;
            ambient_temperature_C = 20.0,
            fermentation_heat_weight = 1.0,
            cold_setpoint_weight = 0.02,
            downward_temperature_move_weight = 0.0,
        ),
        30.0 + 0.02 * 2.0 * 24.0;
        atol = 1.0e-10,
    )
    @test isapprox(
        dynamic_control_thermal_energy_proxy(
            schedule;
            ambient_temperature_C = 20.0,
            temperature_scale_C = 5.0,
        ),
        ((18.0 - 20.0) / 5.0)^2;
        atol = 1.0e-12,
    )
    @test isfinite(dynamic_control_time_to_sugar_threshold(result; threshold_g_L = 175.0))
    @test dynamic_control_time_to_sugar_threshold(result; threshold_g_L = 5.0) == Inf
    @test dynamic_control_sugar_excess_auc(result; threshold_g_L = 5.0) > 0.0
end

@testset "Dynamic control objective terms" begin
    states = zeros(19, 2)
    states[3, :] .= [100.0, 1.0]
    states[4, :] .= [100.0, 1.0]
    states[5, :] .= [0.0, 50.0]
    states[14, :] .= [0.0, 1.0]
    result = SimulationResult(
        [0.0, 24.0],
        states;
        metadata = Dict{String, Any}(
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "termination_time" => 24.0,
            "min_state_value" => 0.0,
            "state_names" => FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES,
        ),
    )
    schedule = dynamic_control_schedule_from_values(
        [20.0, 22.0];
        horizon_h = 24.0,
        control_interval_h = 12.0,
        fda_doses_g_L = [1.0],
        organic_doses_g_L = [0.2],
    )
    weights = DynamicControlObjectiveWeights(
        residual_sugar_target_g_L = 2.0,
        residual_sugar_weight = 1.0,
        terminal_sugar_gate_g_L = 5.0,
        productivity_sugar_excess_weight = 1.0,
        productivity_sugar_excess_scale_g_L = 150.0,
        fermentation_time_weight = 0.1,
        ethanol_reward_weight = 0.5,
        aroma_desirability_weight = 10.0,
        cooling_energy_weight = 0.0,
        thermal_energy_weight = 0.1,
        temperature_energy_scale_C = 5.0,
        fda_total_dose_weight = 0.5,
        organic_total_dose_weight = 0.5,
        nutrient_pulse_weight = 0.1,
        temperature_smoothness_weight = 0.02,
        aroma_windows = [AromaDesirabilityWindow("phenylethanol", 0.0, 1.0, 2.0)],
    )

    terms = dynamic_control_objective_terms(result, schedule; weights = weights, horizon_h = 24.0)
    @test terms["residual_sugar_penalty"] == 0.0
    @test isapprox(
        terms["productivity_sugar_excess_auc_penalty"],
        (2340.0 / (24.0 * 150.0))^2;
        atol = 1.0e-12,
    )
    @test isapprox(terms["fermentation_time_penalty"], 2.4; atol = 1.0e-12)
    @test terms["ethanol_reward"] == -25.0
    @test terms["aroma_desirability_penalty"] == 0.0
    @test terms["fda_total_dose_penalty"] == 0.5
    @test terms["organic_total_dose_penalty"] == 0.1
    @test isapprox(terms["thermal_energy_proxy"], 0.1 * 0.08; atol = 1.0e-12)
    @test isapprox(terms["nutrient_pulse_penalty"], 0.104; atol = 1.0e-12)
    @test isapprox(terms["temperature_smoothness"], 0.08; atol = 1.0e-12)
    @test dynamic_control_objective_value(terms) < 0.0

    failed = SimulationResult(
        [0.0, 10.0],
        states;
        metadata = Dict{String, Any}(
            "retcode" => "Failure",
            "termination_reason" => "solver_error",
            "termination_time" => 10.0,
            "min_state_value" => -2.0e-9,
            "state_names" => FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES,
        ),
    )
    failed_terms =
        dynamic_control_objective_terms(failed, schedule; weights = weights, horizon_h = 24.0)
    @test failed_terms["failure_penalty"] == weights.failure_penalty
    @test failed_terms["incomplete_horizon_penalty"] > 0.0
    @test failed_terms["negative_state_penalty"] > 0.0
end

@testset "Dynamic control objective validation" begin
    @test_throws ArgumentError AromaDesirabilityWindow("phenylethanol", 1.0, 0.5, 2.0)
    @test_throws ArgumentError AromaDesirabilityWindow("phenylethanol", 0.0, 1.0, 2.0; weight = -1.0)
    @test_throws ArgumentError DynamicControlObjectiveWeights(residual_sugar_weight = -1.0)
    @test_throws ArgumentError DynamicControlObjectiveWeights(
        aroma_windows = ["phenylethanol"],
    )
    @test DynamicControlObjectiveWeights(
        terminal_sugar_feasibility_mode = :numeric_health,
    ).terminal_sugar_feasibility_mode == :numeric_health
    @test DynamicControlObjectiveWeights(
        terminal_sugar_feasibility_mode = "horizon-diagnostic",
    ).terminal_sugar_feasibility_mode == :numeric_health
    @test_throws ArgumentError DynamicControlObjectiveWeights(
        terminal_sugar_feasibility_mode = :bad_mode,
    )

    summary = Dict{String, Any}(
        "retcode" => "Success",
        "termination_reason" => "completed_tspan",
        "final_time" => 24.0,
        "final_total_sugar" => 80.0,
        "min_state_value" => 0.0,
    )
    @test !FermentationDFBA._dynamic_control_objective_feasible(
        summary,
        DynamicControlObjectiveWeights(
            terminal_sugar_gate_g_L = 5.0,
            terminal_sugar_feasibility_mode = :strict_dryness,
        ),
        24.0,
    )
    @test FermentationDFBA._dynamic_control_objective_feasible(
        summary,
        DynamicControlObjectiveWeights(
            terminal_sugar_gate_g_L = 5.0,
            terminal_sugar_feasibility_mode = :numeric_health,
        ),
        24.0,
    )
end
