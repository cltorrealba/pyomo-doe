import CSV
using DataFrames

const PLOT_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _synthetic_plot_result()
    states = zeros(19, 4)
    states[1, :] .= [0.5, 0.6, 0.8, 1.0]
    states[2, :] .= [0.07, 0.06, 0.04, 0.02]
    states[3, :] .= [110.0, 80.0, 40.0, 5.0]
    states[4, :] .= [105.0, 90.0, 50.0, 10.0]
    states[5, :] .= [0.0, 5.0, 18.0, 28.0]
    states[6, :] .= 0.0
    states[7, :] .= [0.23, 0.28, 0.31, 0.32]
    states[8, :] .= [0.18, 0.20, 0.24, 0.27]
    states[9:13, :] .= 0.5
    states[14, :] .= [0.0, 0.01, 0.02, 0.03]
    states[15, :] .= [0.0, 0.001, 0.002, 0.003]
    states[16, :] .= [0.0, 0.004, 0.006, 0.009]
    states[17, :] .= [0.0, 0.001, 0.002, 0.004]
    states[18, :] .= [0.0, 0.01, 0.025, 0.04]
    states[19, :] .= [0.0, 0.0001, 0.0002, 0.0003]

    metadata = Dict{String, Any}(
        "model_id" => "synthetic_plot_model",
        "state_names" => copy(PLOT_STATE_NAMES),
        "flux_rxn_ids" => ["r_2111", "r_4048"],
        "mode_history" => [:growth, :growth, :turnover, :sugar_depleted],
        "rhs_status_history" => ["OPTIMAL", "OPTIMAL", "OPTIMAL", "NOT_EVALUATED_SUGAR_DEPLETION"],
        "mass_balance_residuals" => [0.0, 0.0, 0.0, NaN],
        "max_lower_bound_violations" => [0.0, 0.0, 0.0, NaN],
        "max_upper_bound_violations" => [0.0, 0.0, 0.0, NaN],
        "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "retcode" => "Success",
        "termination_reason" => "completed_tspan",
        "termination_time" => 3.0,
        "algorithm" => "SyntheticAlgorithm",
        "tspan" => (0.0, 3.0),
        "saveat" => 1.0,
        "sugar_depletion_tol" => 1.0e-6,
        "min_state_value" => 0.0,
        "has_negative_saved_states" => false,
        "simulation_elapsed_seconds" => 1.0,
        "ode_solve_elapsed_seconds" => 0.8,
        "rhs_elapsed_seconds" => 0.6,
        "history_reconstruction_elapsed_seconds" => 0.2,
        "rhs_call_count" => 8,
        "rhs_lp_solve_count" => 8,
        "flux_reconstruction_solve_count" => 4,
        "total_lp_solve_count" => 12,
        "reconstruct_fluxes" => true,
    )
    return SimulationResult([0.0, 1.0, 2.0, 3.0], states; fluxes = zeros(2, 4), metadata = metadata)
end

@testset "Trajectory SVG plot from SimulationResult" begin
    result = _synthetic_plot_result()

    mktempdir() do dir
        path = joinpath(dir, "trajectory.svg")
        written = write_trajectory_plot(
            result,
            path;
            variables = ["biomass", "total_sugar", "ethanol"],
            title = "Synthetic trajectory",
        )

        @test written == normpath(path)
        @test isfile(path)
        contents = read(path, String)
        @test occursin("<svg", contents)
        @test occursin("Synthetic trajectory", contents)
        @test occursin("biomass", contents)
        @test occursin("total_sugar", contents)
        @test occursin("ethanol", contents)
    end
end

@testset "Default trajectory SVG plots from SimulationResult" begin
    result = _synthetic_plot_result()

    mktempdir() do dir
        paths = write_default_trajectory_plots(result, dir)

        for key in (
            "biomass_ethanol",
            "sugars",
            "nitrogen_reserves",
            "aroma_products",
            "mode_timeline",
        )
            @test haskey(paths, key)
            @test isfile(paths[key])
            @test occursin("<svg", read(paths[key], String))
        end

        @test_throws ErrorException write_default_trajectory_plots(result, dir)
        overwritten = write_default_trajectory_plots(result, dir; overwrite = true)
        @test sort(collect(keys(overwritten))) == sort(collect(keys(paths)))
    end
end

@testset "Trajectory SVG plots from exported CSV report" begin
    result = _synthetic_plot_result()

    mktempdir() do dir
        export_dir = joinpath(dir, "export")
        export_simulation_result(result, export_dir)
        paths = write_exported_trajectory_plots(export_dir)

        @test isdir(joinpath(export_dir, "plots"))
        @test haskey(paths, "sugars")
        @test haskey(paths, "mode_timeline")
        @test isfile(paths["sugars"])
        @test occursin("Sugar trajectories", read(paths["sugars"], String))

        states = DataFrame(CSV.File(joinpath(export_dir, "states.csv")))
        direct_path = joinpath(dir, "direct.svg")
        write_trajectory_plot(states, direct_path; variables = ["glucose", "fructose"])
        @test isfile(direct_path)
    end
end

@testset "Trajectory plot input validation" begin
    result = _synthetic_plot_result()

    mktempdir() do dir
        path = joinpath(dir, "missing.svg")
        @test_throws ErrorException write_trajectory_plot(result, path; variables = ["not_a_state"])
        write_trajectory_plot(result, path; variables = ["biomass"])
        @test_throws ErrorException write_trajectory_plot(result, path; variables = ["biomass"])
        @test isfile(write_trajectory_plot(result, path; variables = ["biomass"], overwrite = true))
    end
end
