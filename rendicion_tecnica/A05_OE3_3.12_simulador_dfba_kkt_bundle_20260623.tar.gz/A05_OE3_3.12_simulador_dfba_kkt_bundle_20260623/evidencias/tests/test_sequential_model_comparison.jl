import CSV
import TOML
using DataFrames

const SEQ_MODEL_TEST_STATE_NAMES = copy(FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES)
const SEQ_MODEL_REAL_COMPARISON_CACHE = Ref{Any}(nothing)

const SEQ_MODEL_TEST_SUMMARY_COLUMNS = [
    "source",
    "model_scope",
    "retcode",
    "termination_reason",
    "initial_time",
    "final_time",
    "n_time_points",
    "n_states",
    "n_alphas",
    "initial_biomass",
    "final_biomass",
    "initial_glucose",
    "final_glucose",
    "initial_fructose",
    "final_fructose",
    "initial_total_sugar",
    "final_total_sugar",
    "initial_ethanol",
    "final_ethanol",
    "final_oxygen",
    "simulation_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
    "alpha_scope",
    "reconstruct_fluxes",
    "reconstruct_alphas",
]

const SEQ_MODEL_TEST_STATE_METRIC_COLUMNS = [
    "state_name",
    "reduced_dfba_final",
    "full_dfba_final",
    "julia_dfvb_final",
    "matlab_dfvb_final_aligned",
    "full_minus_reduced",
    "julia_dfvb_minus_full",
    "julia_dfvb_minus_matlab",
    "rmse_reduced_vs_full",
    "rmse_julia_dfvb_vs_full",
    "rmse_julia_dfvb_vs_matlab",
    "relative_rmse_julia_dfvb_vs_matlab",
    "notes",
]

function _seq_model_synthetic_states(offset::Real)
    states = zeros(19, 3)
    for (i, state_name) in enumerate(SEQ_MODEL_TEST_STATE_NAMES)
        if state_name == "oxygen"
            states[i, :] .= 0.0
        else
            baseline_aligned = [Float64(i), Float64(i) + 1.0, Float64(i) + 3.0]
            states[i, :] .= baseline_aligned .+ Float64(offset)
        end
    end
    return states
end

function _seq_model_synthetic_result(source::AbstractString, model_scope::AbstractString, offset::Real)
    states = _seq_model_synthetic_states(offset)
    return SimulationResult(
        [0.0, 0.5, 1.5],
        states;
        fluxes = nothing,
        alphas = nothing,
        metadata = Dict{String, Any}(
            "model_scope" => String(model_scope),
            "state_names" => copy(SEQ_MODEL_TEST_STATE_NAMES),
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "termination_time" => 1.5,
            "algorithm" => "SyntheticAlgorithm",
            "alpha_scope" => source == "julia_dfvb" ? "active_not_reconstructed" : "not_applicable",
            "mode_history" => Symbol[],
            "mass_balance_residuals" => Float64[],
            "max_lower_bound_violations" => Float64[],
            "max_upper_bound_violations" => Float64[],
            "min_state_value" => minimum(states),
            "has_negative_saved_states" => false,
            "oxygen_derivative_policy" => source == "full_dfba" ?
                "forced_zero_present_r_1992_closed_by_bounds" :
                "forced_zero_absent_or_dfvb_r1992",
            "carbohydrate_derivative_policy" => "empirical_not_r_4048",
            "simulation_elapsed_seconds" => source == "full_dfba" ? 2.0 : 1.0,
            "rhs_call_count" => source == "full_dfba" ? 12 : 6,
            "total_lp_solve_count" => source == "full_dfba" ? 12 : 6,
            "reconstruct_fluxes" => false,
            "reconstruct_alphas" => false,
            "sugar_depletion_tol" => 1.0e-6,
        ),
    )
end

function _seq_model_synthetic_baseline_report()
    table = DataFrame("time" => [0.0, 1.0, 2.0])
    for (i, state_name) in enumerate(SEQ_MODEL_TEST_STATE_NAMES)
        if state_name == "oxygen"
            table[!, state_name] = [0.0, 0.0, 0.0]
        else
            base = Float64(i)
            table[!, state_name] = [base, base + 2.0, base + 4.0]
        end
    end
    return DFVBBaselineReport(
        DataFrame(),
        table,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}(
            "report_type" => "matlab_dfvb_baseline_trajectory_report",
            "source" => "matlab_dfvb_export",
            "state_names" => copy(SEQ_MODEL_TEST_STATE_NAMES),
            "n_active_alphas" => 2,
            "n_full_alphas" => 3,
            "r0001_used_as_oxygen" => false,
            "oxygen_reaction_id" => "r_1992",
            "artifact_id" => "synthetic_dfvb_artifact",
        ),
    )
end

function _seq_model_synthetic_comparison(; baseline_report = _seq_model_synthetic_baseline_report())
    return FermentationDFBA._sequential_model_comparison_from_results(
        _seq_model_synthetic_result("reduced_dfba", "reduced", 0.0),
        _seq_model_synthetic_result("full_dfba", "full", 0.5),
        _seq_model_synthetic_result("julia_dfvb", "dfvb", 1.0),
        baseline_report;
        tspan = (0.0, 1.5),
        saveat = 0.5,
        algorithm_label = "SyntheticAlgorithm",
        ode_abstol = 1.0e-8,
        ode_reltol = 1.0e-8,
        lp_atol = 1.0e-8,
        reconstruct_fluxes = false,
        reconstruct_alphas = false,
        alignment_policy = "linear_interpolation_to_reference_times",
        reduced_model_id = "synthetic_reduced_model",
        full_model_id = "synthetic_full_model",
        dfvb_artifact_id = "synthetic_dfvb_artifact",
    )
end

function _seq_model_real_comparison()
    if SEQ_MODEL_REAL_COMPARISON_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        reduced_model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        full_model = load_full_model(joinpath(project_root, "config", "full_model_paths.example.toml"))
        reduced_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        full_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_full.example.toml"))
        artifacts = load_dfvb_artifacts(
            joinpath(project_root, "config", "dfvb_artifact_paths.example.toml");
            load_alpha_trajectories = false,
            load_active_alpha_trajectories = false,
            load_state_trajectories = true,
        )
        validation = validate_dfvb_artifacts(artifacts)
        @test validation.ok
        SEQ_MODEL_REAL_COMPARISON_CACHE[] = compare_sequential_models(
            reduced_model,
            reduced_map,
            full_model,
            full_map,
            artifacts;
            tspan = (0.0, 0.25),
            saveat = 0.25,
            reconstruct_fluxes = false,
            reconstruct_alphas = false,
        )
    end
    return SEQ_MODEL_REAL_COMPARISON_CACHE[]
end

function _seq_model_state_row(table::DataFrame, state_name::AbstractString)
    row_index = findfirst(==(String(state_name)), String.(table[!, "state_name"]))
    row_index === nothing && error("Missing sequential model state metrics row $(String(state_name)).")
    return table[row_index, :]
end

function _seq_model_summary_row(table::DataFrame, source::AbstractString)
    row_index = findfirst(==(String(source)), String.(table[!, "source"]))
    row_index === nothing && error("Missing sequential model summary row $(String(source)).")
    return table[row_index, :]
end

@testset "Synthetic consolidated sequential model comparison schema" begin
    comparison = _seq_model_synthetic_comparison()

    @test comparison isa SequentialModelComparisonResult
    @test names(comparison.summary_table) == SEQ_MODEL_TEST_SUMMARY_COLUMNS
    @test names(comparison.state_metrics_table) == SEQ_MODEL_TEST_STATE_METRIC_COLUMNS
    @test nrow(comparison.summary_table) == 4
    @test nrow(comparison.state_metrics_table) == 19
    @test nrow(comparison.aligned_timeseries_table) == length(comparison.julia_dfvb.time)
    @test comparison.summary_table[!, "source"] == [
        "reduced_dfba",
        "full_dfba",
        "julia_dfvb",
        "matlab_dfvb_baseline",
    ]
    @test "biomass_reduced_dfba" in names(comparison.aligned_timeseries_table)
    @test "biomass_full_dfba" in names(comparison.aligned_timeseries_table)
    @test "biomass_julia_dfvb" in names(comparison.aligned_timeseries_table)
    @test "biomass_matlab_dfvb" in names(comparison.aligned_timeseries_table)
    @test "biomass_full_minus_reduced" in names(comparison.aligned_timeseries_table)
    @test "biomass_julia_dfvb_minus_matlab" in names(comparison.aligned_timeseries_table)
    @test !any(column -> occursin("flux", lowercase(column)), names(comparison.aligned_timeseries_table))
    @test !any(column -> occursin("alpha", lowercase(column)), names(comparison.aligned_timeseries_table))

    biomass = _seq_model_state_row(comparison.state_metrics_table, "biomass")
    @test biomass["reduced_dfba_final"] == 4.0
    @test biomass["full_dfba_final"] == 4.5
    @test biomass["julia_dfvb_final"] == 5.0
    @test biomass["matlab_dfvb_final_aligned"] == 4.0
    @test biomass["full_minus_reduced"] == 0.5
    @test biomass["julia_dfvb_minus_full"] == 0.5
    @test biomass["julia_dfvb_minus_matlab"] == 1.0
    @test isapprox(biomass["rmse_reduced_vs_full"], 0.5; atol = 1.0e-12)
    @test isapprox(biomass["rmse_julia_dfvb_vs_full"], 0.5; atol = 1.0e-12)
    @test isapprox(biomass["rmse_julia_dfvb_vs_matlab"], 1.0; atol = 1.0e-12)
    @test isapprox(biomass["relative_rmse_julia_dfvb_vs_matlab"], 1.0 / 5.0; atol = 1.0e-12)

    oxygen = _seq_model_state_row(comparison.state_metrics_table, "oxygen")
    @test oxygen["rmse_reduced_vs_full"] == 0.0
    @test oxygen["rmse_julia_dfvb_vs_matlab"] == 0.0
    @test occursin("r_1992", oxygen["notes"])

    carbohydrate = _seq_model_state_row(comparison.state_metrics_table, "carbohydrate")
    @test occursin("r_4048", carbohydrate["notes"])

    @test comparison.metadata["comparison_type"] == "sequential_dfba_dfvb_multimodel_comparison"
    @test comparison.metadata["sources"] == [
        "reduced_dfba",
        "full_dfba",
        "julia_dfvb",
        "matlab_dfvb_baseline",
    ]
    @test comparison.metadata["state_comparison_included"] == true
    @test comparison.metadata["flux_comparison_included"] == false
    @test comparison.metadata["alpha_comparison_included"] == false
    @test comparison.metadata["alignment_policy"] == "linear_interpolation_to_reference_times"
    @test comparison.metadata["reference_time_source"] == "julia_common_grid"
    @test comparison.metadata["matlab_interpolation_used"] == true
    @test comparison.metadata["r0001_used_as_oxygen"] == false
    @test comparison.metadata["oxygen_reaction_id"] == "r_1992"

    @test_throws ErrorException FermentationDFBA._sequential_model_comparison_from_results(
        comparison.reduced_dfba,
        comparison.full_dfba,
        comparison.julia_dfvb,
        comparison.matlab_dfvb_baseline;
        tspan = (0.0, 1.5),
        saveat = 0.5,
        algorithm_label = "SyntheticAlgorithm",
        reconstruct_fluxes = true,
    )
    @test_throws ErrorException FermentationDFBA._sequential_model_comparison_from_results(
        comparison.reduced_dfba,
        comparison.full_dfba,
        comparison.julia_dfvb,
        comparison.matlab_dfvb_baseline;
        tspan = (0.0, 1.5),
        saveat = 0.5,
        algorithm_label = "SyntheticAlgorithm",
        reconstruct_alphas = true,
    )
end

@testset "Sequential model MATLAB interpolation and alignment guards" begin
    comparison = _seq_model_synthetic_comparison()
    aligned = FermentationDFBA._sequential_model_aligned_matlab_baseline(
        comparison.matlab_dfvb_baseline,
        [0.0, 0.5, 1.5],
        ["biomass", "glucose"],
    )
    @test aligned[!, "time"] == [0.0, 0.5, 1.5]
    @test aligned[!, "biomass"] == [1.0, 2.0, 4.0]
    @test aligned[!, "glucose"] == [3.0, 4.0, 6.0]
    @test_throws ErrorException FermentationDFBA._sequential_model_aligned_matlab_baseline(
        comparison.matlab_dfvb_baseline,
        [-0.1],
        ["biomass"],
    )
    @test_throws ErrorException FermentationDFBA._sequential_model_aligned_matlab_baseline(
        comparison.matlab_dfvb_baseline,
        [2.1],
        ["biomass"],
    )
end

@testset "Real short consolidated sequential model comparison smoke" begin
    comparison = _seq_model_real_comparison()

    @test Set(comparison.summary_table[!, "source"]) == Set([
        "reduced_dfba",
        "full_dfba",
        "julia_dfvb",
        "matlab_dfvb_baseline",
    ])
    @test _seq_model_summary_row(comparison.summary_table, "reduced_dfba")["retcode"] == "Success"
    @test _seq_model_summary_row(comparison.summary_table, "full_dfba")["retcode"] == "Success"
    @test _seq_model_summary_row(comparison.summary_table, "julia_dfvb")["retcode"] == "Success"
    @test _seq_model_summary_row(comparison.summary_table, "matlab_dfvb_baseline")["retcode"] == "artifact"
    @test nrow(comparison.state_metrics_table) == 19
    @test nrow(comparison.aligned_timeseries_table) == length(comparison.julia_dfvb.time)
    @test comparison.metadata["comparison_type"] == "sequential_dfba_dfvb_multimodel_comparison"
    @test comparison.metadata["state_comparison_included"] == true
    @test comparison.metadata["flux_comparison_included"] == false
    @test comparison.metadata["alpha_comparison_included"] == false
    @test comparison.metadata["r0001_used_as_oxygen"] == false
    @test comparison.metadata["oxygen_reaction_id"] == "r_1992"

    oxygen = _seq_model_state_row(comparison.state_metrics_table, "oxygen")
    for column in (
        "reduced_dfba_final",
        "full_dfba_final",
        "julia_dfvb_final",
        "matlab_dfvb_final_aligned",
    )
        @test isfinite(Float64(oxygen[column]))
        @test abs(Float64(oxygen[column])) <= 1.0e-8
    end

    @test !any(column -> occursin("flux", lowercase(column)), names(comparison.aligned_timeseries_table))
    @test !any(column -> occursin("alpha", lowercase(column)), names(comparison.aligned_timeseries_table))
end

@testset "Sequential model comparison export" begin
    comparison = _seq_model_synthetic_comparison()
    output_dir = mktempdir()
    paths = export_sequential_model_comparison(comparison, output_dir)

    @test isfile(paths["summary"])
    @test isfile(paths["state_metrics"])
    @test isfile(paths["aligned_timeseries"])
    @test isfile(paths["metadata"])
    @test names(CSV.read(paths["summary"], DataFrame)) == SEQ_MODEL_TEST_SUMMARY_COLUMNS
    @test names(CSV.read(paths["state_metrics"], DataFrame)) == SEQ_MODEL_TEST_STATE_METRIC_COLUMNS
    @test nrow(CSV.read(paths["aligned_timeseries"], DataFrame)) == 3

    metadata = TOML.parsefile(paths["metadata"])
    @test metadata["comparison_type"] == "sequential_dfba_dfvb_multimodel_comparison"
    @test metadata["flux_comparison_included"] == false
    @test metadata["alpha_comparison_included"] == false
    @test metadata["oxygen_reaction_id"] == "r_1992"
end

@testset "Sequential model comparison SVG plots" begin
    comparison = _seq_model_synthetic_comparison()
    output_dir = mktempdir()
    paths = write_sequential_model_comparison_plots(comparison, output_dir)

    @test isfile(paths["core_states"])
    @test isfile(paths["state_rmse"])
    @test isfile(paths["runtime_counters"])
    for path in values(paths)
        @test occursin("<svg", read(path, String))
    end
end

@testset "Sequential model comparison overwrite behavior" begin
    comparison = _seq_model_synthetic_comparison()
    output_dir = mktempdir()
    export_sequential_model_comparison(comparison, output_dir)
    @test_throws ErrorException export_sequential_model_comparison(comparison, output_dir)
    @test export_sequential_model_comparison(comparison, output_dir; overwrite = true) isa Dict{String, String}

    plot_dir = mktempdir()
    write_sequential_model_comparison_plots(comparison, plot_dir)
    @test_throws ErrorException write_sequential_model_comparison_plots(comparison, plot_dir)
    @test write_sequential_model_comparison_plots(comparison, plot_dir; overwrite = true) isa Dict{String, String}
end
