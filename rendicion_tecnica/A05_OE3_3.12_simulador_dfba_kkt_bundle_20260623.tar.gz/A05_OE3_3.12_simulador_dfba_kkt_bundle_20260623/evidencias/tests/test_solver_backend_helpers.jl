include(joinpath(@__DIR__, "..", "scripts", "solver_backend_helpers.jl"))

import JuMP
import MathOptInterface as MOI

const SOLVER_BACKEND_TEST_PROJECT_ROOT = normpath(joinpath(@__DIR__, ".."))
const SOLVER_BACKEND_TEST_PROJECT_PATH = joinpath(SOLVER_BACKEND_TEST_PROJECT_ROOT, "Project.toml")
const SOLVER_BACKEND_TEST_MANIFEST_PATH = joinpath(SOLVER_BACKEND_TEST_PROJECT_ROOT, "Manifest.toml")

function _with_temporary_env_var(f::Function, name::AbstractString, value)
    key = String(name)
    had_key = haskey(ENV, key)
    old_value = get(ENV, key, "")
    try
        if value === nothing
            delete!(ENV, key)
        else
            ENV[key] = String(value)
        end
        return f()
    finally
        if had_key
            ENV[key] = old_value
        else
            delete!(ENV, key)
        end
    end
end

function _error_message(f::Function)
    try
        f()
        return nothing
    catch err
        return sprint(showerror, err)
    end
end

function _test_error_contains(f::Function, expected_patterns::AbstractVector{<:AbstractString})
    message = _error_message(f)
    @test message !== nothing
    if message !== nothing
        for pattern in expected_patterns
            @test occursin(pattern, message)
        end
    end
    return message
end

function _gurobi_resolve_result()
    try
        optimizer, solver_label = _resolve_solver_backend("Gurobi")
        return (optimizer = optimizer, solver_label = solver_label, error = nothing)
    catch err
        return (optimizer = nothing, solver_label = nothing, error = err)
    end
end

function _project_file_snapshots()
    snapshots = Dict{String, String}()
    for path in (SOLVER_BACKEND_TEST_PROJECT_PATH, SOLVER_BACKEND_TEST_MANIFEST_PATH)
        if isfile(path)
            snapshots[path] = read(path, String)
        end
    end
    return snapshots
end

function _assert_project_file_snapshots_unchanged(snapshots)
    for (path, contents) in snapshots
        @test isfile(path)
        if isfile(path)
            @test read(path, String) == contents
        end
    end
    return nothing
end

function _assert_gurobi_error_or_active_success(result, expected_patterns)
    if result.error === nothing
        @test result.optimizer !== nothing
        @test result.solver_label == "Gurobi"
    else
        message = sprint(showerror, result.error)
        for pattern in expected_patterns
            @test occursin(pattern, message)
        end
    end
    return nothing
end

@testset "Script solver backend list parsing" begin
    @test _parse_solver_backend_list("HiGHS") == ["HiGHS"]
    @test _parse_solver_backend_list("HiGHS,Gurobi") == ["HiGHS", "Gurobi"]
    @test _parse_solver_backend_list(" highs , gurobi ") == ["HiGHS", "Gurobi"]

    _test_error_contains(
        () -> _parse_solver_backend_list("HiGHS,highs"),
        ["Duplicate solver backend requested: HiGHS"],
    )
    _test_error_contains(
        () -> _parse_solver_backend_list("gurobi,GUROBI"),
        ["Duplicate solver backend requested: Gurobi"],
    )
    _test_error_contains(() -> _parse_solver_backend_list("CPLEX"), ["Unsupported solver backend: CPLEX"])
    _test_error_contains(() -> _parse_solver_backend_list("HiGHS,,Gurobi"), ["empty entry"])
    _test_error_contains(() -> _parse_solver_backend_list("HiGHS,"), ["empty entry"])
    _test_error_contains(() -> _parse_solver_backend_list(""), ["must include at least one backend"])
end

@testset "Script HiGHS solver backend resolution" begin
    optimizer, solver_label = _resolve_solver_backend("HiGHS")
    @test optimizer === nothing
    @test solver_label == "HiGHS"

    optimizer_lower, solver_label_lower = _resolve_solver_backend("highs")
    @test optimizer_lower === nothing
    @test solver_label_lower == "HiGHS"

    optimizer_upper, solver_label_upper = _resolve_solver_backend("HIGHS")
    @test optimizer_upper === nothing
    @test solver_label_upper == "HiGHS"

    _test_error_contains(() -> _resolve_solver_backend("CPLEX"), ["Unsupported solver backend: CPLEX"])
end

@testset "Script solver backend environment restoration" begin
    key = "DFBA_GUROBI_PACKAGE_PATH"
    had_key = haskey(ENV, key)
    old_value = get(ENV, key, "")

    try
        _with_temporary_env_var(key, "temporary-gurobi-path") do
            @test ENV[key] == "temporary-gurobi-path"
        end
        @test haskey(ENV, key) == had_key
        if had_key
            @test ENV[key] == old_value
        end

        _with_temporary_env_var(key, nothing) do
            @test !haskey(ENV, key)
        end
        @test haskey(ENV, key) == had_key
        if had_key
            @test ENV[key] == old_value
        end
    finally
        if had_key
            ENV[key] = old_value
        else
            delete!(ENV, key)
        end
    end
end

@testset "Script Gurobi backend missing path behavior" begin
    _with_temporary_env_var("DFBA_GUROBI_PACKAGE_PATH", nothing) do
        result = _gurobi_resolve_result()
        _assert_gurobi_error_or_active_success(
            result,
            ["Gurobi backend requested", "DFBA_GUROBI_PACKAGE_PATH", "HiGHS"],
        )
    end
end

@testset "Script Gurobi backend invalid local path behavior" begin
    missing_path = joinpath(tempdir(), "dfba_missing_gurobi_package_path_for_tests")
    ispath(missing_path) && error("Unexpected existing test path: $missing_path")

    _with_temporary_env_var("DFBA_GUROBI_PACKAGE_PATH", missing_path) do
        result = _gurobi_resolve_result()
        _assert_gurobi_error_or_active_success(
            result,
            ["Gurobi backend requested", "DFBA_GUROBI_PACKAGE_PATH", missing_path, "HiGHS"],
        )
    end
end

@testset "Script Gurobi backend local package path validation" begin
    mktempdir() do package_dir
        _with_temporary_env_var("DFBA_GUROBI_PACKAGE_PATH", package_dir) do
            result = _gurobi_resolve_result()
            _assert_gurobi_error_or_active_success(
                result,
                ["Gurobi backend requested", "DFBA_GUROBI_PACKAGE_PATH", "Project.toml"],
            )
        end
    end

    mktempdir() do package_dir
        write(
            joinpath(package_dir, "Project.toml"),
            """
            name = "Gurobi"
            uuid = "2e9cd046-0924-5485-92f1-d5272153d98b"
            version = "0.0.0"
            """,
        )
        _with_temporary_env_var("DFBA_GUROBI_PACKAGE_PATH", package_dir) do
            result = _gurobi_resolve_result()
            _assert_gurobi_error_or_active_success(
                result,
                ["Gurobi backend requested", "DFBA_GUROBI_PACKAGE_PATH", "src/Gurobi.jl"],
            )
        end
    end
end

@testset "Script Gurobi backend failure does not mutate project files" begin
    missing_path = joinpath(tempdir(), "dfba_missing_gurobi_package_path_for_mutation_guard")
    ispath(missing_path) && error("Unexpected existing test path: $missing_path")
    snapshots = _project_file_snapshots()

    _with_temporary_env_var("DFBA_GUROBI_PACKAGE_PATH", missing_path) do
        _test_error_contains(
            () -> _validated_gurobi_package_path(missing_path, ErrorException("synthetic active import failure")),
            ["Gurobi backend requested", "DFBA_GUROBI_PACKAGE_PATH", missing_path],
        )
    end

    _assert_project_file_snapshots_unchanged(snapshots)
end

if get(ENV, "FERMENTATIONDFBA_TEST_GUROBI", "") == "1"
    @testset "Optional local Gurobi backend tiny LP smoke test" begin
        package_path = strip(get(ENV, "DFBA_GUROBI_PACKAGE_PATH", ""))
        @test !isempty(package_path)
        @test isdir(package_path)
        @test isfile(joinpath(package_path, "Project.toml"))
        @test isfile(joinpath(package_path, "src", "Gurobi.jl"))

        snapshots = _project_file_snapshots()
        optimizer, solver_label = _resolve_solver_backend("Gurobi")
        @test solver_label == "Gurobi"
        @test optimizer !== nothing

        model = JuMP.Model(optimizer)
        JuMP.set_silent(model)
        JuMP.@variable(model, 0 <= x <= 1)
        JuMP.@objective(model, Max, x)
        JuMP.optimize!(model)

        @test JuMP.termination_status(model) == MOI.OPTIMAL
        @test isapprox(JuMP.objective_value(model), 1.0; atol = 1.0e-8)
        @test isapprox(JuMP.value(x), 1.0; atol = 1.0e-8)
        _assert_project_file_snapshots_unchanged(snapshots)
    end
else
    @info(
        "Skipping optional local Gurobi backend tiny LP smoke test; " *
        "set FERMENTATIONDFBA_TEST_GUROBI=1 and DFBA_GUROBI_PACKAGE_PATH to enable it.",
    )
end
