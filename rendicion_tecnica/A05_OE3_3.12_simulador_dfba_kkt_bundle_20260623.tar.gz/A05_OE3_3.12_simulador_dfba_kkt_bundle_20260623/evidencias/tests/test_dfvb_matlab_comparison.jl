import CSV
import TOML
using DataFrames

const DFVB_MATLAB_TEST_STATE_NAMES = copy(FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES)
const DFVB_MATLAB_REAL_COMPARISON_CACHE = Ref{Any}(nothing)

const DFVB_MATLAB_TEST_SUMMARY_COLUMNS = [
    "source",
    "model_scope",
    "retcode",
    "initial_time",
    "final_time",
    "n_time_points",
    "n_states",
    "n_alphas",
    "initial_biomass",
    "final_biomass",
    "initial_glucose",
    "final_glucose",
    "initial_fructose",
    "final_fructose",
    "initial_total_sugar",
    "final_total_sugar",
    "initial_ethanol",
    "final_ethanol",
    "final_oxygen",
    "simulation_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
    "alpha_scope",
]

const DFVB_MATLAB_TEST_STATE_METRIC_COLUMNS = [
    "state_name",
    "initial_julia",
    "initial_matlab_aligned",
    "final_julia",
    "final_matlab_aligned",
    "final_difference_julia_minus_matlab",
    "max_abs_difference",
    "rmse",
    "relative_rmse",
    "julia_min",
    "julia_max",
    "matlab_aligned_min",
    "matlab_aligned_max",
    "notes",
]

function _dfvb_matlab_synthetic_baseline_report()
    table = DataFrame("time" => [0.0, 1.0, 2.0])
    for (i, state_name) in enumerate(DFVB_MATLAB_TEST_STATE_NAMES)
        if state_name == "oxygen"
            table[!, state_name] = [0.0, 0.0, 0.0]
        else
            base = Float64(i)
            table[!, state_name] = [base, base + 2.0, base + 4.0]
        end
    end
    return DFVBBaselineReport(
        DataFrame(),
        table,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}(
            "report_type" => "matlab_dfvb_baseline_trajectory_report",
            "source" => "matlab_dfvb_export",
            "state_names" => copy(DFVB_MATLAB_TEST_STATE_NAMES),
            "n_active_alphas" => 2,
            "r0001_used_as_oxygen" => false,
            "oxygen_reaction_id" => "r_1992",
            "alpha_mapping_note" => "synthetic alpha mapping note",
            "exchange_partition_note" => "synthetic exchange partition note",
        ),
    )
end

function _dfvb_matlab_synthetic_julia_result()
    time = [0.0, 0.5, 1.5]
    states = zeros(19, 3)
    for (i, state_name) in enumerate(DFVB_MATLAB_TEST_STATE_NAMES)
        if state_name == "oxygen"
            states[i, :] .= 0.0
        else
            baseline_aligned = [Float64(i), Float64(i) + 1.0, Float64(i) + 3.0]
            offset = state_name == "biomass" ? 1.0 : 0.25
            states[i, :] .= baseline_aligned .+ offset
        end
    end
    return SimulationResult(
        time,
        states;
        fluxes = nothing,
        metadata = Dict{String, Any}(
            "model_scope" => "dfvb",
            "state_names" => copy(DFVB_MATLAB_TEST_STATE_NAMES),
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "termination_time" => 1.5,
            "algorithm" => "SyntheticAlgorithm",
            "alpha_scope" => "active",
            "mode_history" => Symbol[],
            "mass_balance_residuals" => Float64[],
            "max_lower_bound_violations" => Float64[],
            "max_upper_bound_violations" => Float64[],
            "min_state_value" => minimum(states),
            "has_negative_saved_states" => false,
            "oxygen_derivative_policy" => "forced_zero_dfvb_r1992",
            "carbohydrate_derivative_policy" => "empirical_not_r_4048",
            "simulation_elapsed_seconds" => 1.25,
            "rhs_call_count" => 4,
            "total_lp_solve_count" => 7,
            "reconstruct_alphas" => false,
            "reconstruct_fluxes" => false,
            "sugar_depletion_tol" => 1.0e-6,
        ),
    )
end

function _dfvb_matlab_synthetic_comparison()
    return FermentationDFBA._dfvb_matlab_comparison_from_results(
        _dfvb_matlab_synthetic_julia_result(),
        _dfvb_matlab_synthetic_baseline_report();
        alignment_policy = "linear_interpolation_to_julia_times",
        julia_tspan = (0.0, 1.5),
        julia_saveat = 0.5,
        julia_algorithm_label = "SyntheticAlgorithm",
        julia_reconstruct_alphas = false,
        julia_reconstruct_fluxes = false,
    )
end

function _dfvb_matlab_real_comparison()
    if DFVB_MATLAB_REAL_COMPARISON_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        model = load_full_model(joinpath(project_root, "config", "full_model_paths.example.toml"))
        reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_full.example.toml"))
        reaction_report = validate_reaction_map(model, reaction_map)
        @test reaction_report.ok
        artifacts = load_dfvb_artifacts(
            joinpath(project_root, "config", "dfvb_artifact_paths.example.toml");
            load_alpha_trajectories = false,
            load_active_alpha_trajectories = false,
            load_state_trajectories = true,
        )
        validation = validate_dfvb_artifacts(artifacts)
        @test validation.ok
        DFVB_MATLAB_REAL_COMPARISON_CACHE[] = compare_dfvb_to_matlab_baseline(
            model,
            reaction_map,
            artifacts;
            tspan = (0.0, 0.25),
            saveat = 0.25,
            reconstruct_alphas = true,
            reconstruct_fluxes = false,
        )
    end
    return DFVB_MATLAB_REAL_COMPARISON_CACHE[]
end

function _dfvb_matlab_test_state_row(table::DataFrame, state_name::AbstractString)
    row_index = findfirst(==(String(state_name)), String.(table[!, "state_name"]))
    row_index === nothing && error("Missing DFVB MATLAB state metrics row $(String(state_name)).")
    return table[row_index, :]
end

@testset "DFVB MATLAB baseline interpolation helper" begin
    baseline = DataFrame(
        "time" => [0.0, 1.0, 2.0],
        "biomass" => [0.0, 2.0, 4.0],
        "glucose" => [10.0, 8.0, 6.0],
    )
    aligned = FermentationDFBA._interpolate_baseline_states_to_times(
        baseline[!, "time"],
        baseline,
        [0.0, 0.5, 1.5],
        ["biomass", "glucose"],
    )

    @test aligned[!, "time"] == [0.0, 0.5, 1.5]
    @test aligned[!, "biomass"] == [0.0, 1.0, 3.0]
    @test aligned[!, "glucose"] == [10.0, 9.0, 7.0]
    @test_throws ErrorException FermentationDFBA._interpolate_baseline_states_to_times(
        baseline[!, "time"],
        baseline,
        [-0.1],
        ["biomass"],
    )
    @test_throws ErrorException FermentationDFBA._interpolate_baseline_states_to_times(
        [0.0, 1.0, 1.0],
        baseline,
        [0.5],
        ["biomass"],
    )
end

@testset "Synthetic Julia-vs-MATLAB DFVB comparison tables" begin
    comparison = _dfvb_matlab_synthetic_comparison()

    @test comparison isa DFVBMatlabComparisonResult
    @test names(comparison.summary_table) == DFVB_MATLAB_TEST_SUMMARY_COLUMNS
    @test names(comparison.state_metrics) == DFVB_MATLAB_TEST_STATE_METRIC_COLUMNS
    @test nrow(comparison.summary_table) == 2
    @test nrow(comparison.state_metrics) == 19
    @test nrow(comparison.aligned_state_timeseries) == length(comparison.julia_result.time)
    @test "biomass_julia" in names(comparison.aligned_state_timeseries)
    @test "biomass_matlab" in names(comparison.aligned_state_timeseries)
    @test "biomass_difference_julia_minus_matlab" in names(comparison.aligned_state_timeseries)

    biomass = _dfvb_matlab_test_state_row(comparison.state_metrics, "biomass")
    @test biomass["initial_julia"] == 2.0
    @test biomass["initial_matlab_aligned"] == 1.0
    @test biomass["final_difference_julia_minus_matlab"] == 1.0
    @test biomass["max_abs_difference"] == 1.0
    @test biomass["rmse"] == 1.0
    @test isapprox(biomass["relative_rmse"], 1.0 / 5.0; atol = 1.0e-12)

    oxygen = _dfvb_matlab_test_state_row(comparison.state_metrics, "oxygen")
    @test oxygen["rmse"] == 0.0
    @test oxygen["relative_rmse"] == 0.0
    @test occursin("r_1992", oxygen["notes"])

    carbohydrate = _dfvb_matlab_test_state_row(comparison.state_metrics, "carbohydrate")
    @test occursin("r_4048", carbohydrate["notes"])

    @test comparison.metadata["comparison_type"] == "julia_dfvb_vs_matlab_dfvb_baseline"
    @test comparison.metadata["alignment_policy"] == "linear_interpolation_to_julia_times"
    @test comparison.metadata["alpha_comparison_included"] == false
    @test comparison.metadata["flux_comparison_included"] == false
    @test comparison.metadata["r0001_used_as_oxygen"] == false
    @test comparison.metadata["oxygen_reaction_id"] == "r_1992"
    @test_throws ErrorException FermentationDFBA._dfvb_matlab_comparison_from_results(
        _dfvb_matlab_synthetic_julia_result(),
        _dfvb_matlab_synthetic_baseline_report();
        alignment_policy = "nearest_baseline_time",
    )
end

@testset "Real Julia-vs-MATLAB DFVB comparison smoke" begin
    comparison = _dfvb_matlab_real_comparison()

    @test comparison.julia_result.metadata["retcode"] == "Success"
    @test nrow(comparison.summary_table) == 2
    @test nrow(comparison.state_metrics) == 19
    @test nrow(comparison.aligned_state_timeseries) == length(comparison.julia_result.time)
    @test comparison.metadata["comparison_type"] == "julia_dfvb_vs_matlab_dfvb_baseline"
    @test comparison.metadata["alignment_policy"] == "linear_interpolation_to_julia_times"
    @test comparison.metadata["alpha_comparison_included"] == false
    @test comparison.metadata["flux_comparison_included"] == false
    @test comparison.metadata["r0001_used_as_oxygen"] == false
    @test comparison.metadata["oxygen_reaction_id"] == "r_1992"
    @test comparison.metadata["baseline_n_time_points"] == 2094

    oxygen = _dfvb_matlab_test_state_row(comparison.state_metrics, "oxygen")
    @test isfinite(oxygen["rmse"])
    @test oxygen["max_abs_difference"] <= 1.0e-8

    for column in ("rmse", "relative_rmse", "max_abs_difference")
        @test all(isfinite, Float64.(comparison.state_metrics[!, column]))
    end
end

@testset "DFVB MATLAB comparison export" begin
    comparison = _dfvb_matlab_synthetic_comparison()

    mktempdir() do dir
        paths = export_dfvb_matlab_comparison(comparison, dir)

        for key in ("summary", "state_metrics", "aligned_timeseries", "metadata")
            @test haskey(paths, key)
            @test isfile(paths[key])
        end
        @test !isfile(joinpath(dir, "dfvb_matlab_alpha_comparison.csv"))
        @test !isfile(joinpath(dir, "dfvb_matlab_flux_comparison.csv"))

        summary = DataFrame(CSV.File(paths["summary"]))
        state_metrics = DataFrame(CSV.File(paths["state_metrics"]))
        aligned_timeseries = DataFrame(CSV.File(paths["aligned_timeseries"]))
        metadata = TOML.parsefile(paths["metadata"])

        @test names(summary) == DFVB_MATLAB_TEST_SUMMARY_COLUMNS
        @test names(state_metrics) == DFVB_MATLAB_TEST_STATE_METRIC_COLUMNS
        @test "time" in names(aligned_timeseries)
        @test "ethanol_difference_julia_minus_matlab" in names(aligned_timeseries)
        @test metadata["comparison_type"] == "julia_dfvb_vs_matlab_dfvb_baseline"
        @test metadata["alignment_policy"] == "linear_interpolation_to_julia_times"
        @test metadata["alpha_comparison_included"] == false
        @test metadata["flux_comparison_included"] == false
        @test metadata["r0001_used_as_oxygen"] == false
    end
end

@testset "DFVB MATLAB comparison SVG plots" begin
    comparison = _dfvb_matlab_synthetic_comparison()

    mktempdir() do dir
        paths = write_dfvb_matlab_comparison_plots(comparison, dir)

        for key in ("core_states", "state_rmse", "runtime_counters")
            @test haskey(paths, key)
            @test isfile(paths[key])
            @test occursin("<svg", read(paths[key], String))
        end
        @test occursin("Julia vs MATLAB DFVB core states", read(paths["core_states"], String))
        @test occursin("relative RMSE", read(paths["state_rmse"], String))
        @test occursin("artifact", read(paths["runtime_counters"], String))
    end
end

@testset "DFVB MATLAB comparison overwrite behavior" begin
    comparison = _dfvb_matlab_synthetic_comparison()

    mktempdir() do dir
        export_dfvb_matlab_comparison(comparison, dir)
        @test_throws ErrorException export_dfvb_matlab_comparison(comparison, dir)
        export_paths = export_dfvb_matlab_comparison(comparison, dir; overwrite = true)
        @test isfile(export_paths["summary"])

        plot_dir = joinpath(dir, "plots")
        write_dfvb_matlab_comparison_plots(comparison, plot_dir)
        @test_throws ErrorException write_dfvb_matlab_comparison_plots(comparison, plot_dir)
        plot_paths = write_dfvb_matlab_comparison_plots(comparison, plot_dir; overwrite = true)
        @test isfile(plot_paths["core_states"])
    end
end
