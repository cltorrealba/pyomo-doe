using DataFrames

function _reduced_mpcc_mesh_test_sweep()
    table = DataFrame(
        "scenario_id" => ["scenario_001", "scenario_002", "scenario_003", "scenario_004", "scenario_005"],
        "scenario_status" => ["completed", "completed", "completed", "completed", "completed"],
        "t0" => zeros(5),
        "tfinal" => [0.5, 0.5, 1.0, 1.0, 1.0],
        "horizon" => [0.5, 0.5, 1.0, 1.0, 1.0],
        "nfe" => [1, 2, 1, 2, 4],
        "degree" => fill(3, 5),
        "boundary_dt" => [0.5, 0.25, 1.0, 0.5, 0.25],
        "n_boundary_points" => [2, 3, 2, 3, 5],
        "n_collocation_points" => [3, 6, 3, 6, 12],
        "solver_status" => [
            "LOCALLY_SOLVED",
            "LOCALLY_SOLVED",
            "ITERATION_LIMIT",
            "ITERATION_LIMIT",
            "LOCALLY_SOLVED",
        ],
        "primal_status" => fill("FEASIBLE_POINT", 5),
        "solve_elapsed_seconds" => [4.0, 8.0, 12.0, 30.0, 80.0],
        "candidate_residual_feasible" => fill(true, 5),
        "candidate_iteration_limit_residual_feasible" => [false, false, true, true, false],
        "candidate_trajectory_ready" => [true, true, false, false, true],
        "candidate_is_scientific_simulation" => fill(false, 5),
        "residual_thresholds_satisfied" => fill(true, 5),
        "dominant_residual" => fill("max_mass_balance_residual", 5),
        "next_recommended_action" => [
            "extract_candidate_trajectory",
            "extract_candidate_trajectory",
            "review_iteration_limit_residual_feasible_candidate",
            "review_iteration_limit_residual_feasible_candidate",
            "extract_candidate_trajectory",
        ],
        "candidate_warning_count" => [0, 0, 1, 1, 0],
        "max_rhs_residual" => [1.0e-12, 2.0e-12, 3.0e-12, 4.0e-12, 5.0e-12],
        "max_mass_balance_residual" => [5.0e-7, 4.0e-7, 7.0e-7, 6.0e-7, 5.0e-7],
        "max_lower_bound_violation" => zeros(5),
        "max_upper_bound_violation" => zeros(5),
        "max_stationarity_residual" => fill(1.0e-8, 5),
        "max_lower_complementarity_residual" => [4.0e-7, 3.0e-7, 8.0e-7, 7.0e-7, 2.0e-7],
        "max_upper_complementarity_residual" => [4.0e-7, 3.0e-7, 8.0e-7, 7.0e-7, 2.0e-7],
        "max_state_abs_difference" => [9.0e-6, 7.0e-6, 2.0e-5, 1.0e-6, 8.0e-7],
        "max_state_rmse" => [8.0e-6, 6.0e-6, 1.5e-5, 8.0e-7, 6.0e-7],
        "max_state_relative_rmse" => [0.02, 0.01, 0.03, 1.0e-4, 8.0e-5],
        "final_biomass_difference" => [9.0e-6, 7.0e-6, 2.0e-5, 1.0e-6, 8.0e-7],
        "final_glucose_difference" => [-1.0e-6, -7.0e-7, -2.0e-6, -1.0e-7, -8.0e-8],
        "final_fructose_difference" => [-1.0e-6, -7.0e-7, -2.0e-6, -1.0e-7, -8.0e-8],
        "final_ethanol_difference" => [1.0e-6, 7.0e-7, 2.0e-6, 1.0e-7, 8.0e-8],
        "final_total_sugar_difference" => [-2.0e-6, -1.4e-6, -4.0e-6, -2.0e-7, -1.6e-7],
        "min_candidate_state_value" => zeros(5),
        "full_dfba_cold_reference_deferred" => fill(true, 5),
        "reduced_full_equivalence_claimed" => fill(false, 5),
        "persistent_lp_baseline_used" => fill(false, 5),
        "indices_reacciones_used" => fill(false, 5),
        "r0001_used_as_oxygen" => fill(false, 5),
        "error_type" => fill(missing, 5),
        "error_message" => fill(missing, 5),
    )
    metadata = Dict{String, Any}(
        "sweep_type" => "synthetic_reduced_dcdfba_mpcc_solve_attempt_short_horizon_sweep",
        "n_scenarios" => 5,
        "outputs_written" => false,
        "sweep_is_scientific_simulation" => false,
        "solved_trajectory_claimed" => false,
    )
    return ReducedDCDFBAMPCCSolveAttemptSweepResult(
        table,
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        metadata,
    )
end

@testset "Reduced MPCC mesh refinement sensitivity synthetic aggregation" begin
    sweep = _reduced_mpcc_mesh_test_sweep()
    sensitivity = sweep_reduced_dcdfba_mpcc_mesh_refinement(sweep)
    table = sensitivity.mesh_table
    metadata = sensitivity.metadata

    @test sensitivity isa ReducedDCDFBAMPCCMeshRefinementSensitivityResult
    @test sensitivity.sweep_result === sweep
    @test size(table, 1) == 5
    @test table[1, "mesh_case_id"] == "mesh_001"
    @test table[5, "mesh_case_id"] == "mesh_005"
    @test table[1, "trajectory_ready_improved_vs_coarser_nfe"] == false
    @test table[2, "state_relative_rmse_improved_vs_coarser_nfe"] == true
    @test table[5, "trajectory_ready_improved_vs_coarser_nfe"] == true
    @test table[5, "state_relative_rmse_improved_vs_coarser_nfe"] == true
    @test table[5, "coarser_nfe"] == 2
    @test table[5, "coarser_max_state_relative_rmse"] == 1.0e-4
    @test table[5, "scientific_baseline"] == "full_dfba_cold_deferred"
    @test table[5, "full_dfba_cold_reference_deferred"] == true
    @test table[5, "reduced_full_equivalence_claimed"] == false
    @test table[5, "persistent_lp_baseline_used"] == false
    @test table[5, "hsl_required"] == false
    @test table[5, "ma57_required"] == false
    @test table[5, "indices_reacciones_used"] == false
    @test table[5, "r0001_used_as_oxygen"] == false

    @test metadata["mesh_sensitivity_type"] == "reduced_dcdfba_mpcc_mesh_refinement_sensitivity"
    @test metadata["n_rows"] == 5
    @test metadata["n_completed_rows"] == 5
    @test metadata["n_horizons"] == 2
    @test metadata["nfe_values"] == [1, 2, 4]
    @test metadata["residual_feasible_row_count"] == 5
    @test metadata["trajectory_ready_row_count"] == 3
    @test metadata["mesh_trajectory_ready_improvement_count"] == 1
    @test metadata["mesh_state_relative_rmse_improvement_count"] == 3
    @test metadata["solver_status_counts"]["LOCALLY_SOLVED"] == 3
    @test metadata["solver_status_counts"]["ITERATION_LIMIT"] == 2
    @test metadata["first_trajectory_ready_nfe_by_horizon"]["horizon=0.5"] == 1
    @test metadata["first_trajectory_ready_nfe_by_horizon"]["horizon=1.0"] == 4
    @test metadata["best_state_match_nfe_by_horizon"]["horizon=1.0"] == 4
    @test metadata["horizons_with_trajectory_ready_count"] == 2
    @test metadata["outputs_written"] == false
    @test metadata["mesh_sensitivity_is_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
end

@testset "Reduced MPCC mesh refinement sensitivity validation" begin
    empty = ReducedDCDFBAMPCCSolveAttemptSweepResult(
        DataFrame(),
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        Dict{String, Any}(),
    )
    @test_throws ArgumentError sweep_reduced_dcdfba_mpcc_mesh_refinement(empty)
end

@testset "Reduced MPCC mesh refinement sensitivity opt-in real run" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_MESH", "0") == "1"
        project_root = normpath(joinpath(@__DIR__, ".."))
        model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        sensitivity = sweep_reduced_dcdfba_mpcc_mesh_refinement(
            model,
            reaction_map;
            horizons = [0.5],
            nfe_values = [1, 2],
            degree = 3,
        )

        @test sensitivity isa ReducedDCDFBAMPCCMeshRefinementSensitivityResult
        @test size(sensitivity.mesh_table, 1) == 2
        @test sensitivity.metadata["outputs_written"] == false
        @test sensitivity.metadata["mesh_sensitivity_is_scientific_simulation"] == false
        @test sensitivity.metadata["full_dfba_cold_reference_deferred"] == true
    else
        @info "Skipping reduced MPCC mesh refinement sensitivity real run; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_MESH=1 to run it."
        @test true
    end
end
