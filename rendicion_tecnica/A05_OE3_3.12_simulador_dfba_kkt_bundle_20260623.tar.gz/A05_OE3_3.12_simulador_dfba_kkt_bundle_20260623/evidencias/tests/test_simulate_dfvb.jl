import CSV
import TOML
using DataFrames

const SIM_DFVB_DIAGNOSTIC_TOLERANCE = 1.0e-6
const SIM_DFVB_FULL_INPUT_CACHE = Ref{Any}(nothing)
const SIM_DFVB_ARTIFACT_CACHE = Ref{Any}(nothing)
const SIM_DFVB_ALPHA_RESULT_CACHE = Ref{Any}(nothing)
const SIM_DFVB_NO_ALPHA_RESULT_CACHE = Ref{Any}(nothing)
const SIM_DFVB_FLUX_RESULT_CACHE = Ref{Any}(nothing)

function _load_dfvb_simulation_inputs()
    if SIM_DFVB_FULL_INPUT_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
        reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")

        model = load_full_model(full_paths_config)
        reaction_map = load_reaction_map(reaction_map_config)
        reaction_report = validate_reaction_map(model, reaction_map)
        @test reaction_report.ok
        SIM_DFVB_FULL_INPUT_CACHE[] = (model = model, reaction_map = reaction_map)
    end
    cached = SIM_DFVB_FULL_INPUT_CACHE[]
    return cached.model, cached.reaction_map
end

function _load_dfvb_simulation_artifacts()
    if SIM_DFVB_ARTIFACT_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        artifacts = load_dfvb_artifacts(
            joinpath(project_root, "config", "dfvb_artifact_paths.example.toml");
            load_alpha_trajectories = false,
            load_active_alpha_trajectories = false,
            load_state_trajectories = false,
        )
        validation = validate_dfvb_artifacts(artifacts)
        @test validation.ok
        SIM_DFVB_ARTIFACT_CACHE[] = artifacts
    end
    return SIM_DFVB_ARTIFACT_CACHE[]
end

function _short_dfvb_alpha_result()
    if SIM_DFVB_ALPHA_RESULT_CACHE[] === nothing
        model, reaction_map = _load_dfvb_simulation_inputs()
        artifacts = _load_dfvb_simulation_artifacts()
        SIM_DFVB_ALPHA_RESULT_CACHE[] = simulate_dfvb(
            model,
            reaction_map,
            artifacts;
            tspan = (0.0, 0.25),
            saveat = 0.25,
            reconstruct_fluxes = false,
            reconstruct_alphas = true,
        )
    end
    return SIM_DFVB_ALPHA_RESULT_CACHE[]
end

function _short_dfvb_no_alpha_result()
    if SIM_DFVB_NO_ALPHA_RESULT_CACHE[] === nothing
        model, reaction_map = _load_dfvb_simulation_inputs()
        artifacts = _load_dfvb_simulation_artifacts()
        SIM_DFVB_NO_ALPHA_RESULT_CACHE[] = simulate_dfvb(
            model,
            reaction_map,
            artifacts;
            tspan = (0.0, 0.25),
            saveat = 0.25,
            reconstruct_fluxes = false,
            reconstruct_alphas = false,
        )
    end
    return SIM_DFVB_NO_ALPHA_RESULT_CACHE[]
end

function _short_dfvb_flux_result()
    if SIM_DFVB_FLUX_RESULT_CACHE[] === nothing
        model, reaction_map = _load_dfvb_simulation_inputs()
        artifacts = _load_dfvb_simulation_artifacts()
        SIM_DFVB_FLUX_RESULT_CACHE[] = simulate_dfvb(
            model,
            reaction_map,
            artifacts;
            tspan = (0.0, 0.25),
            saveat = 0.25,
            reconstruct_fluxes = true,
            reconstruct_alphas = true,
        )
    end
    return SIM_DFVB_FLUX_RESULT_CACHE[]
end

function _assert_dfvb_runtime_metadata(metadata)
    for key in (
        "simulation_elapsed_seconds",
        "ode_solve_elapsed_seconds",
        "rhs_elapsed_seconds",
        "history_reconstruction_elapsed_seconds",
        "rhs_call_count",
        "rhs_lp_solve_count",
        "alpha_reconstruction_solve_count",
        "flux_reconstruction_solve_count",
        "saved_state_reconstruction_solve_count",
        "total_lp_solve_count",
        "reconstruct_alphas",
        "reconstruct_fluxes",
    )
        @test haskey(metadata, key)
    end
    for key in (
        "simulation_elapsed_seconds",
        "ode_solve_elapsed_seconds",
        "rhs_elapsed_seconds",
        "history_reconstruction_elapsed_seconds",
    )
        @test isfinite(metadata[key])
        @test metadata[key] >= 0.0
    end
    for key in (
        "rhs_call_count",
        "rhs_lp_solve_count",
        "alpha_reconstruction_solve_count",
        "flux_reconstruction_solve_count",
        "saved_state_reconstruction_solve_count",
        "total_lp_solve_count",
    )
        @test metadata[key] isa Integer
        @test metadata[key] >= 0
    end
end

@testset "Sequential DFVB short simulation with alpha reconstruction" begin
    result = _short_dfvb_alpha_result()
    metadata = result.metadata

    @test result isa SimulationResult
    @test metadata["model_scope"] == "dfvb"
    @test metadata["simulation_type"] == "sequential_dfvb"
    @test metadata["method"] == "dfvb"
    @test metadata["retcode"] == "Success"
    @test size(result.states, 1) == 19
    @test length(result.time) >= 2
    @test all(isapprox(value, 0.0; atol = 1.0e-9) for value in result.states[6, :])
    @test result.fluxes === nothing
    @test result.alphas !== nothing
    @test size(result.alphas, 2) == length(result.time)
    @test size(result.alphas, 1) == 490
    @test metadata["alpha_scope"] == "active"
    @test metadata["alpha_source"] == "reconstructed_saved_states"
    @test metadata["n_alphas"] == 490
    @test length(metadata["alpha_ids"]) == 490
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test maximum(metadata["mass_balance_residuals"]) <= SIM_DFVB_DIAGNOSTIC_TOLERANCE
    @test maximum(metadata["max_lower_bound_violations"]) <= SIM_DFVB_DIAGNOSTIC_TOLERANCE
    @test maximum(metadata["max_upper_bound_violations"]) <= SIM_DFVB_DIAGNOSTIC_TOLERANCE
    @test metadata["alpha_reconstruction_solve_count"] == length(result.time)
    @test metadata["rhs_lp_solve_count"] == metadata["rhs_call_count"]
    @test metadata["total_lp_solve_count"] ==
        metadata["rhs_lp_solve_count"] + metadata["saved_state_reconstruction_solve_count"]
    _assert_dfvb_runtime_metadata(metadata)

    summary = summarize_simulation(result)
    @test summary["model_scope"] == "dfvb"
    @test summary["n_alphas"] == 490
    @test summary["alpha_scope"] == "active"
end

@testset "Sequential DFVB short simulation without alpha reconstruction" begin
    result = _short_dfvb_no_alpha_result()
    metadata = result.metadata

    @test result isa SimulationResult
    @test metadata["model_scope"] == "dfvb"
    @test metadata["retcode"] == "Success"
    @test result.alphas === nothing
    @test result.fluxes === nothing
    @test metadata["reconstruct_alphas"] == false
    @test metadata["n_alphas"] == 0
    @test metadata["alpha_ids"] == String[]
    @test metadata["alpha_source"] == "not_reconstructed"
    @test metadata["alpha_reconstruction_solve_count"] == 0
    @test metadata["flux_reconstruction_solve_count"] == 0
    @test metadata["saved_state_reconstruction_solve_count"] == 0
    @test metadata["total_lp_solve_count"] == metadata["rhs_lp_solve_count"]
    _assert_dfvb_runtime_metadata(metadata)
end

@testset "Sequential DFVB short simulation with optional flux reconstruction" begin
    result = _short_dfvb_flux_result()
    metadata = result.metadata
    flux_rxn_ids = String.(metadata["flux_rxn_ids"])

    @test result.fluxes !== nothing
    @test result.alphas !== nothing
    @test "r_1992" in flux_rxn_ids
    @test !("r_0001" in flux_rxn_ids)
    @test metadata["r0001_used_as_oxygen"] == false
    oxygen_flux_index = findfirst(==("r_1992"), flux_rxn_ids)
    @test oxygen_flux_index !== nothing
    @test all(isapprox(value, 0.0; atol = 1.0e-7) for value in result.fluxes[oxygen_flux_index, :])
    @test metadata["alpha_reconstruction_solve_count"] == length(result.time)
    @test metadata["flux_reconstruction_solve_count"] == length(result.time)
    @test metadata["total_lp_solve_count"] ==
        metadata["rhs_lp_solve_count"] + metadata["saved_state_reconstruction_solve_count"]

    fluxes_table = simulation_fluxes_table(result)
    @test fluxes_table !== nothing
    @test "r_1992" in names(fluxes_table)
    @test !("r_0001" in names(fluxes_table))
end

@testset "Sequential DFVB simulation export with alphas" begin
    result = _short_dfvb_alpha_result()

    mktempdir() do dir
        paths = export_simulation_result(result, dir; model_id = "full_yeast_model")

        for key in ("summary", "states", "alphas", "diagnostics", "metadata")
            @test haskey(paths, key)
            @test isfile(paths[key])
        end
        @test !haskey(paths, "fluxes")
        @test !isfile(joinpath(dir, "fluxes.csv"))

        summary = DataFrame(CSV.File(paths["summary"]))
        alphas = DataFrame(CSV.File(paths["alphas"]))
        metadata = TOML.parsefile(paths["metadata"])

        @test nrow(alphas) == length(result.time)
        @test ncol(alphas) == size(result.alphas, 1) + 1
        @test "time" in names(alphas)
        @test String(summary[1, "model_scope"]) == "dfvb"
        @test summary[1, "n_alphas"] == 490
        @test String(summary[1, "alpha_scope"]) == "active"
        @test metadata["alpha_scope"] == "active"
        @test metadata["alpha_source"] == "reconstructed_saved_states"
        @test length(metadata["alpha_ids"]) == 490
        @test metadata["n_alphas"] == 490
    end
end
