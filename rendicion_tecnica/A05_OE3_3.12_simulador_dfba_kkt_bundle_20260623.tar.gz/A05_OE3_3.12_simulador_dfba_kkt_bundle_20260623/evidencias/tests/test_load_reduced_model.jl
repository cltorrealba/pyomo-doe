@testset "Reduced model loader" begin
    mktempdir() do dir
        reduced_dir = joinpath(dir, "Reduced_model")
        mkpath(reduced_dir)

        write(joinpath(reduced_dir, "S.csv"), "met,S1,S2,S3\nm1,1,0,-1\nm2,0,2,-2\n")
        write(joinpath(reduced_dir, "lb.csv"), "lb\n0\n-10\n0\n")
        write(joinpath(reduced_dir, "ub.csv"), "ub\n100\n10\n100\n")
        write(joinpath(reduced_dir, "rxn_list.csv"), "Var1\nr_a\nr_b\nr_c\n")
        write(joinpath(reduced_dir, "mets_list.csv"), "Var1\nm1\nm2\n")
        write(joinpath(reduced_dir, "Indices_reacciones.csv"), "Parametro,Indice\nexample,1\n")

        paths = ReducedModelPaths(
            s_path = joinpath(reduced_dir, "S.csv"),
            lb_path = joinpath(reduced_dir, "lb.csv"),
            ub_path = joinpath(reduced_dir, "ub.csv"),
            rxn_list_path = joinpath(reduced_dir, "rxn_list.csv"),
            met_list_path = joinpath(reduced_dir, "mets_list.csv"),
            indices_path = joinpath(reduced_dir, "Indices_reacciones.csv"),
        )

        model = load_reduced_model(paths; model_id = "synthetic_reduced")

        @test model.model_id == "synthetic_reduced"
        @test size(model.S) == (2, 3)
        @test model.S[1, 1] == 1.0
        @test model.rxn_ids == ["r_a", "r_b", "r_c"]
        @test model.met_ids == ["m1", "m2"]
        @test model.lb == [0.0, -10.0, 0.0]
        @test model.ub == [100.0, 10.0, 100.0]
        @test validate_reduced_model_dimensions(model).ok
    end
end
