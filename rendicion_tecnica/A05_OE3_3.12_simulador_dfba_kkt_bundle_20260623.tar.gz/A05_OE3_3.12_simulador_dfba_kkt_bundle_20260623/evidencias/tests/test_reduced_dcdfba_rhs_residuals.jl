import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_rhs_residual_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

@testset "Reduced DC-dFBA collocation RHS residual scaffold contract" begin
    model, reaction_map = _reduced_dcdfba_rhs_residual_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    variable_count_before = JuMP.num_variables(nlp.jump_model)
    rhs = add_reduced_dcdfba_rhs_residuals!(nlp)

    @test rhs isa ReducedDCDFBARHSResidualScaffold
    @test rhs.nlp === nlp
    @test rhs.layout isa ReducedDCDFBARHSResidualLayout
    @test rhs.reaction_indices isa ReducedDCDFBARHSReactionIndices
    @test rhs.mode == :growth
    @test size(rhs.constraints) == (19, 1, 3)
    @test all(constraint -> constraint isa JuMP.ConstraintRef, rhs.constraints)
    @test JuMP.num_variables(nlp.jump_model) == variable_count_before
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED

    layout = rhs.layout
    @test layout.biomass_growth == 3
    @test layout.nitrogen == 3
    @test layout.glucose == 3
    @test layout.fructose == 3
    @test layout.ethanol == 3
    @test layout.oxygen == 3
    @test layout.protein == 3
    @test layout.carbohydrate == 3
    @test layout.amino_acids == 5 * 3
    @test layout.aromas == 6 * 3
    @test layout.total_rhs_residual_constraints == 19 * 3
    @test length(rhs.constraints) == layout.total_rhs_residual_constraints
end

@testset "Reduced DC-dFBA collocation RHS residual reaction mapping" begin
    model, reaction_map = _reduced_dcdfba_rhs_residual_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    rhs = add_reduced_dcdfba_rhs_residuals!(nlp)
    indices = rhs.reaction_indices
    roles = nlp.kkt_problem.reaction_roles

    @test indices.biomass_growth == reaction_index(model, "r_2111")
    @test indices.glucose_exchange == reaction_index(model, "r_1714")
    @test indices.fructose_exchange == reaction_index(model, "r_1709")
    @test indices.ethanol_exchange == reaction_index(model, "r_1761")
    @test indices.protein_exchange == reaction_index(model, "r_4047")
    @test indices.carbohydrate_exchange == reaction_index(model, "r_4048")
    @test length(indices.nitrogen_sources) == 9
    @test length(indices.amino_acids) == 5
    @test length(indices.aromas) == 6
    @test indices.nitrogen_sources == reaction_indices(model, roles.nitrogen_sources)
    @test indices.amino_acids == reaction_indices(model, roles.amino_acids)
    @test indices.aromas == reaction_indices(model, roles.aromas)
    @test !has_reaction(model, "r_1992")
    @test !("r_0001" in roles.dynamic_bound_reactions)
end

@testset "Reduced DC-dFBA collocation RHS residual metadata guardrails" begin
    model, reaction_map = _reduced_dcdfba_rhs_residual_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
    @test nlp.metadata["ode_rhs_constraints_built"] == false
    @test nlp.metadata["direct_collocation_dynamic_constraints_built"] == false

    rhs = add_reduced_dcdfba_rhs_residuals!(nlp)
    metadata = rhs.metadata

    @test metadata["ode_rhs_constraints_built"] == true
    @test metadata["direct_collocation_dynamic_constraints_built"] == true
    @test metadata["rhs_residual_scaffold_built"] == true
    @test metadata["rhs_residual_mode_policy"] == "fixed_growth_mode_only"
    @test metadata["rhs_residual_smoothness_policy"] == "smooth_sign_assumed_no_max_operators"
    @test metadata["rhs_residual_total_constraints"] == 57
    @test metadata["rhs_residual_state_count"] == 19
    @test metadata["rhs_residual_uses_flux_variables"] == true
    @test metadata["rhs_residual_uses_state_collocation_variables"] == true
    @test metadata["rhs_residual_uses_state_derivative_variables"] == true
    @test metadata["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test metadata["oxygen_exchange_reaction_id"] == "r_1992"
    @test metadata["oxygen_exchange_present"] == false
    @test metadata["carbohydrate_exchange_reaction_id"] == "r_4048"
    @test metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test metadata["carbohydrate_exchange_flux_used_in_rhs"] == false
    @test metadata["dynamic_flux_bounds_applied"] == false
    @test metadata["mass_balance_constraints_built"] == false
    @test metadata["bound_feasibility_constraints_built"] == false
    @test metadata["stationarity_constraints_built"] == false
    @test metadata["kkt_constraints_built"] == false
    @test metadata["mpcc_complementarity_built"] == false
    @test metadata["solver_call_performed"] == false
    @test metadata["sequential_initialization_built"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false

    @test nlp.metadata["ode_rhs_constraints_built"] == true
    @test nlp.metadata["rhs_residual_scaffold_built"] == true
    @test nlp.metadata["mass_balance_constraints_built"] == false
    @test nlp.metadata["kkt_constraints_built"] == false
    @test nlp.metadata["mpcc_complementarity_built"] == false
end

@testset "Reduced DC-dFBA collocation RHS residual validation" begin
    model, reaction_map = _reduced_dcdfba_rhs_residual_test_model_and_map()
    nlp = build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )

    @test_throws ArgumentError add_reduced_dcdfba_rhs_residuals!(nlp; mode = :turnover)
    rhs = add_reduced_dcdfba_rhs_residuals!(nlp)
    @test rhs.mode == :growth
    @test_throws ArgumentError add_reduced_dcdfba_rhs_residuals!(nlp)
end
