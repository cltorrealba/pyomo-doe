function _kkt_dfba_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

@testset "Reduced KKT-DFBA scaffold contract" begin
    model, reaction_map = _kkt_dfba_test_model_and_map()
    grid = build_finite_element_grid((0.0, 0.5); nfe = 2, degree = 3)
    scaffold = build_kkt_dfba_problem(model, reaction_map, grid)

    @test scaffold isa KKTDFBAProblem
    @test scaffold.model === model
    @test scaffold.reaction_map === reaction_map
    @test scaffold.grid === grid
    @test scaffold.params isa ZentenoKineticParameters
    @test scaffold.dimensions isa KKTDFBADimensions
    @test scaffold.constraint_layout isa KKTDFBAConstraintLayout
    @test scaffold.reaction_roles isa KKTDFBAReactionRoles

    dimensions = scaffold.dimensions
    @test dimensions.n_states == 19
    @test dimensions.n_metabolites == size(model.S, 1) == 1079
    @test dimensions.n_reactions == size(model.S, 2) == 1488
    @test dimensions.nfe == 2
    @test dimensions.collocation_degree == 3
    @test dimensions.n_collocation_points == 6
    @test dimensions.n_state_boundary_variables == 19 * 3
    @test dimensions.n_state_collocation_variables == 19 * 6
    @test dimensions.n_flux_variables == 1488 * 6
    @test dimensions.n_mass_balance_dual_variables == 1079 * 6
    @test dimensions.n_lower_bound_dual_variables == 1488 * 6
    @test dimensions.n_upper_bound_dual_variables == 1488 * 6
    @test dimensions.n_primal_variables ==
        dimensions.n_state_boundary_variables +
        dimensions.n_state_collocation_variables +
        dimensions.n_flux_variables
    @test dimensions.n_dual_variables ==
        dimensions.n_mass_balance_dual_variables +
        dimensions.n_lower_bound_dual_variables +
        dimensions.n_upper_bound_dual_variables
    @test dimensions.n_total_variables == dimensions.n_primal_variables + dimensions.n_dual_variables

    layout = scaffold.constraint_layout
    @test layout.mass_balance == 1079 * 6
    @test layout.lower_bound_feasibility == 1488 * 6
    @test layout.upper_bound_feasibility == 1488 * 6
    @test layout.stationarity == 1488 * 6
    @test layout.lower_bound_complementarity == 1488 * 6
    @test layout.upper_bound_complementarity == 1488 * 6
    @test layout.ode_residual == 19 * 6
    @test layout.continuity == 19 * 2
    @test layout.initial_condition == 19
    @test layout.total_structural_relations ==
        layout.mass_balance +
        layout.lower_bound_feasibility +
        layout.upper_bound_feasibility +
        layout.stationarity +
        layout.lower_bound_complementarity +
        layout.upper_bound_complementarity +
        layout.ode_residual +
        layout.continuity +
        layout.initial_condition
end

@testset "Reduced KKT-DFBA reaction-role policy" begin
    model, reaction_map = _kkt_dfba_test_model_and_map()
    scaffold = build_kkt_dfba_problem(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        nfe = 1,
        degree = 3,
    )
    roles = scaffold.reaction_roles

    @test roles.biomass_growth == "r_2111"
    @test roles.glucose_exchange == "r_1714"
    @test roles.fructose_exchange == "r_1709"
    @test roles.ethanol_exchange == "r_1761"
    @test roles.oxygen_exchange == "r_1992"
    @test roles.atp_maintenance == "r_4046"
    @test roles.protein_exchange == "r_4047"
    @test roles.carbohydrate_exchange == "r_4048"
    @test length(roles.nitrogen_sources) == 9
    @test length(roles.amino_acids) == 5
    @test length(roles.aromas) == 6
    @test "r_1992" ∉ roles.dynamic_bound_reactions
    @test "r_0001" ∉ roles.dynamic_bound_reactions
    @test "r_4048" ∉ roles.dynamic_bound_reactions
    @test "r_2111" in roles.objective_reactions
    @test "r_4046" in roles.objective_reactions
    @test "r_4047" in roles.objective_reactions
    @test all(has_reaction(model, rxn_id) for rxn_id in roles.dynamic_bound_reactions)
    @test all(has_reaction(model, rxn_id) for rxn_id in roles.objective_reactions)
end

@testset "Reduced KKT-DFBA scaffold metadata guardrails" begin
    model, reaction_map = _kkt_dfba_test_model_and_map()
    scaffold = build_kkt_dfba_problem(model, reaction_map; tspan = (0.0, 1.0), nfe = 1)
    metadata = scaffold.metadata

    @test metadata["problem_type"] == "reduced_kkt_dfba_scaffold"
    @test metadata["model_scope"] == "reduced"
    @test metadata["grid_tspan"] == (0.0, 1.0)
    @test metadata["grid_nfe"] == 1
    @test metadata["collocation_degree"] == 3
    @test metadata["flux_discretization"] == "one flux vector per collocation point"
    @test metadata["jump_model_built"] == false
    @test metadata["solver_call_performed"] == false
    @test metadata["ipopt_required"] == false
    @test metadata["hsl_required"] == false
    @test metadata["kkt_constraints_built"] == false
    @test metadata["mpcc_complementarity_built"] == false
    @test metadata["direct_collocation_dynamic_constraints_built"] == false
    @test metadata["sequential_initialization_built"] == false
    @test metadata["dfvb_kkt_deferred"] == true
    @test metadata["full_model_kkt_deferred"] == true
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["sequential_scientific_baseline"] == "full_dfba_cold"
    @test metadata["persistent_lp_warm_start_policy"] == "diagnostic_only_not_scientific_equivalence"
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["oxygen_exchange_reaction_id"] == "r_1992"
    @test metadata["oxygen_exchange_present"] == false
    @test metadata["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test metadata["carbohydrate_exchange_reaction_id"] == "r_4048"
    @test metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test metadata["weighted_objective_value_is_biomass_flux"] == false
end

@testset "Reduced KKT-DFBA scaffold validation" begin
    model, reaction_map = _kkt_dfba_test_model_and_map()
    grid = build_finite_element_grid((0.0, 1.0); nfe = 1)

    @test_throws ArgumentError build_kkt_dfba_problem(model, reaction_map, grid; model_scope = "full")
    @test_throws ArgumentError build_kkt_dfba_problem(model, reaction_map; tspan = (0.0, 1.0), nfe = 1, degree = 2)
    @test_throws ArgumentError build_kkt_dfba_problem(model, reaction_map; tspan = (1.0, 1.0), nfe = 1)
    @test_throws ArgumentError build_kkt_dfba_problem(model, reaction_map; tspan = (0.0, 1.0), nfe = 0)

    full_like_model = MetabolicModel(
        reshape([1.0], 1, 1),
        [0.0],
        [0.0],
        ["r_1992"],
        ["m_o2"];
        model_id = "toy_full_like",
    )
    @test_throws ArgumentError build_kkt_dfba_problem(full_like_model, reaction_map, grid)

    r0001_oxygen_map = ReactionMap(
        core = merge(copy(reaction_map.core), Dict("oxygen_exchange" => "r_0001")),
        nitrogen_sources = reaction_map.nitrogen_sources,
        amino_acids = reaction_map.amino_acids,
        aromas = reaction_map.aromas,
        disabled_reactions = Dict("oxygen_exchange" => "r_0001"),
        disabled_reaction_reasons = Dict("oxygen_exchange" => "invalid oxygen mapping"),
    )
    @test_throws ArgumentError build_kkt_dfba_problem(model, r0001_oxygen_map, grid)

    missing_reaction_map = ReactionMap(
        core = merge(copy(reaction_map.core), Dict("glucose_exchange" => "r_missing")),
        nitrogen_sources = reaction_map.nitrogen_sources,
        amino_acids = reaction_map.amino_acids,
        aromas = reaction_map.aromas,
        disabled_reactions = reaction_map.disabled_reactions,
        disabled_reaction_reasons = reaction_map.disabled_reaction_reasons,
    )
    @test_throws ArgumentError build_kkt_dfba_problem(model, missing_reaction_map, grid)
end
