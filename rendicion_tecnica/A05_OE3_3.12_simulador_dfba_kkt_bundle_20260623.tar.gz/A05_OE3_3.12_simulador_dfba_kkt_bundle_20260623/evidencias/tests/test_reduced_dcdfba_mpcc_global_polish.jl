using DataFrames
using CSV
using Serialization
import JuMP
import MathOptInterface as MOI

if !isdefined(@__MODULE__, :_reduced_mpcc_window_test_initial_state)
    include(joinpath(@__DIR__, "test_reduced_dcdfba_mpcc_windowed_continuation.jl"))
end

function _reduced_mpcc_global_polish_test_continuation(; second_trajectory_ready::Bool = true)
    initial = _reduced_mpcc_window_test_initial_state()
    first, first_final = _reduced_mpcc_window_test_comparison(
        t0 = 0.0,
        tfinal = 0.5,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, _ = _reduced_mpcc_window_test_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = first_final,
        biomass_offset = second_trajectory_ready ? 0.0 : 0.02,
        trajectory_ready = second_trajectory_ready,
        solver_status = second_trajectory_ready ? "LOCALLY_SOLVED" : "ITERATION_LIMIT",
    )
    return run_reduced_dcdfba_mpcc_windowed_continuation([first, second])
end

@testset "Reduced MPCC global polish windowed start assembly" begin
    continuation = _reduced_mpcc_global_polish_test_continuation()
    starts = build_reduced_dcdfba_mpcc_windowed_start_values(continuation)

    @test starts isa ReducedDCDFBAMPCCWindowedStartValues
    @test size(starts.state_boundary) == (19, 3)
    @test size(starts.state_collocation) == (19, 2, 3)
    @test size(starts.state_derivative) == (19, 2, 3)
    @test size(starts.flux) == (2, 2, 3)
    @test size(starts.lower_bound_duals) == (2, 2, 3)
    @test size(starts.upper_bound_duals) == (2, 2, 3)
    @test size(starts.mass_balance_duals) == (1, 2, 3)

    first_candidate =
        continuation.window_comparisons[1].trajectory_candidate.candidate_diagnostics
    second_candidate =
        continuation.window_comparisons[2].trajectory_candidate.candidate_diagnostics

    @test isapprox(starts.state_boundary[:, 1], first_candidate.state_boundary[:, 1])
    @test isapprox(starts.state_boundary[:, 2], first_candidate.state_boundary[:, 2])
    @test isapprox(starts.state_boundary[:, 3], second_candidate.state_boundary[:, 2])
    @test isapprox(starts.state_collocation[:, 1:1, :], first_candidate.state_collocation)
    @test isapprox(starts.state_collocation[:, 2:2, :], second_candidate.state_collocation)
    @test isapprox(starts.flux[:, 1:1, :], first_candidate.flux)
    @test isapprox(starts.flux[:, 2:2, :], second_candidate.flux)

    metadata = starts.metadata
    @test metadata["start_type"] == "reduced_dcdfba_mpcc_windowed_candidate_start_values"
    @test metadata["source_window_count"] == 2
    @test metadata["source_total_nfe"] == 2
    @test metadata["source_local_nfe_values"] == [1, 1]
    @test metadata["source_collocation_degree"] == 3
    @test metadata["source_boundary_times"] == [0.0, 0.5, 1.0]
    @test metadata["source_horizon"] == 1.0
    @test metadata["source_max_boundary_join_mismatch"] <= 1.0e-12
    @test metadata["all_source_candidates_residual_feasible"] == true
    @test metadata["all_source_candidates_trajectory_ready"] == true
    @test metadata["outputs_written"] == false
    @test metadata["start_values_are_scientific_simulation"] == false
    @test metadata["solved_trajectory_claimed"] == false
    @test metadata["first_mpcc_target"] == "reduced_dfba"
    @test metadata["hsl_required"] == false
    @test metadata["ma57_required"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
end

@testset "Reduced MPCC global polish dense dual sanitization" begin
    continuation = _reduced_mpcc_global_polish_test_continuation()
    starts = build_reduced_dcdfba_mpcc_windowed_start_values(continuation)
    poisoned = ReducedDCDFBAMPCCWindowedStartValues(
        starts.state_boundary,
        starts.state_collocation,
        starts.state_derivative,
        starts.flux,
        fill(-12.0, size(starts.lower_bound_duals)),
        fill(34.0, size(starts.upper_bound_duals)),
        fill(56.0, size(starts.mass_balance_duals)),
        copy(starts.metadata),
    )

    sanitized =
        FermentationDFBA._reduced_mpcc_global_polish_sanitize_dense_dual_starts(poisoned)

    @test sanitized.state_boundary == starts.state_boundary
    @test sanitized.state_collocation == starts.state_collocation
    @test sanitized.state_derivative == starts.state_derivative
    @test sanitized.flux == starts.flux
    @test all(iszero, sanitized.lower_bound_duals)
    @test all(iszero, sanitized.upper_bound_duals)
    @test all(iszero, sanitized.mass_balance_duals)
    @test sanitized.metadata["dense_start_dual_sanitize_applied"] == true
    @test sanitized.metadata["dense_start_dual_sanitize_lower_bound_dual_abs_max_before"] ==
          12.0
    @test sanitized.metadata["dense_start_dual_sanitize_upper_bound_dual_abs_max_before"] ==
          34.0
    @test sanitized.metadata["dense_start_dual_sanitize_mass_balance_dual_abs_max_before"] ==
          56.0
    @test sanitized.metadata["dense_start_dual_sanitize_mass_balance_dual_abs_max_after"] ==
          0.0
end

@testset "Reduced MPCC global polish objective configuration" begin
    @test FermentationDFBA._reduced_mpcc_global_polish_objective_mode("legacy") ==
          "legacy_zero_derivative"
    @test FermentationDFBA._reduced_mpcc_global_polish_objective_mode("deoliveira_gap") ==
          "de_oliveira_gap"
    @test FermentationDFBA._reduced_mpcc_global_polish_objective_mode("tracking") ==
          "de_oliveira_tracking"
    @test FermentationDFBA._reduced_mpcc_global_polish_objective_state_reference(
        "windowed_seed",
    ) == "seed"
    @test FermentationDFBA._reduced_mpcc_global_polish_objective_state_reference(
        "windowed_start",
    ) == "seed"
    @test FermentationDFBA._reduced_mpcc_global_polish_objective_state_reference(
        "sequential",
    ) == "sequential_reference"
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_objective_mode(
        "bad_objective",
    )
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_objective_state_reference(
        "bad_reference",
    )
    @test FermentationDFBA._reduced_mpcc_global_polish_nonnegative_weight(0.0, "rho") ==
          0.0
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_nonnegative_weight(
        -1.0,
        "rho",
    )
    trust_start_model = JuMP.Model()
    JuMP.@variable(trust_start_model, trust_start_variable)
    @test FermentationDFBA._reduced_mpcc_global_polish_current_start_value(
        trust_start_variable,
        1.25,
    ) == 1.25
    JuMP.set_start_value(trust_start_variable, 3.5)
    @test FermentationDFBA._reduced_mpcc_global_polish_current_start_value(
        trust_start_variable,
        1.25,
    ) == 3.5
    @test FermentationDFBA._reduced_mpcc_global_polish_trust_region_states(
        "biomass, total_sugar;ethanol",
    ) == ["biomass", "total_sugar", "ethanol"]
    @test FermentationDFBA._reduced_mpcc_global_polish_trust_region_states(
        "total_hexose, sugar",
    ) == ["total_hexose", "sugar"]
    @test FermentationDFBA._reduced_mpcc_global_polish_trust_region_states("core") ==
          [
              "biomass",
              "glucose",
              "fructose",
              "ethanol",
              "total_sugar",
          ]
    @test FermentationDFBA._reduced_mpcc_global_polish_trust_region_states("aromas") ==
          [
              "phenylethanol",
              "isoamyl_alcohol",
              "isobutanol",
              "methionol",
              "tyrosol",
              "ethyl_acetate",
          ]
    @test FermentationDFBA._reduced_mpcc_global_polish_trust_region_states("core,aromas") ==
          [
              "biomass",
              "glucose",
              "fructose",
              "ethanol",
              "total_sugar",
              "phenylethanol",
              "isoamyl_alcohol",
              "isobutanol",
              "methionol",
              "tyrosol",
              "ethyl_acetate",
          ]
    @test FermentationDFBA._reduced_mpcc_global_polish_trust_region_states("traces") ==
          [
              "phenylalanine",
              "leucine",
              "valine",
              "methionine",
              "tyrosine",
              "phenylethanol",
              "isoamyl_alcohol",
              "isobutanol",
              "methionol",
              "tyrosol",
              "ethyl_acetate",
          ]
    @test isempty(FermentationDFBA._reduced_mpcc_global_polish_trust_region_states("off"))
    starts = build_reduced_dcdfba_mpcc_windowed_start_values(
        _reduced_mpcc_global_polish_test_continuation(),
    )
    @test FermentationDFBA._reduced_mpcc_global_polish_state_index(starts, 19, "biomass") ==
          1
    @test FermentationDFBA._reduced_mpcc_global_polish_state_index(
        starts,
        19,
        "not_a_state",
    ) === nothing
    resolved = FermentationDFBA._reduced_mpcc_global_polish_trust_region_state_set(
        starts,
        19,
        ["biomass", "total_sugar"],
    )
    @test resolved.state_indices == [1]
    @test resolved.include_total_sugar == true
    @test resolved.glucose_index == 3
    @test resolved.fructose_index == 4
    resolved_alias = FermentationDFBA._reduced_mpcc_global_polish_trust_region_state_set(
        starts,
        19,
        ["total_hexose"],
    )
    @test isempty(resolved_alias.state_indices)
    @test resolved_alias.include_total_sugar == true
    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_trust_region_state_set(
        starts,
        19,
        ["not_a_state"],
    )
    resolved_aromas = FermentationDFBA._reduced_mpcc_global_polish_trust_region_state_set(
        starts,
        19,
        FermentationDFBA._reduced_mpcc_global_polish_trust_region_states("aromas"),
    )
    @test resolved_aromas.state_indices == collect(14:19)
    @test resolved_aromas.state_names == [
        "phenylethanol",
        "isoamyl_alcohol",
        "isobutanol",
        "methionol",
        "tyrosol",
        "ethyl_acetate",
    ]
    @test FermentationDFBA._reduced_mpcc_global_polish_recommended_action(
        false,
        false,
        false,
        false;
        dominant_residual = "max_continuity_residual",
    ) == "improve_global_structural_feasibility_before_biology"

    comparison = _reduced_mpcc_global_polish_test_continuation().window_comparisons[1]
    same_acceptance =
        FermentationDFBA._reduced_mpcc_global_polish_biological_acceptance(
            comparison,
            comparison;
            enabled = true,
            states = "core",
            relative_tolerance = 0.0,
            absolute_tolerance = 0.0,
            final_states = "biomass,total_sugar",
            final_absolute_tolerance = 0.0,
        )
    @test same_acceptance.passed == true
    @test same_acceptance.metadata["biological_acceptance_trace_states_excluded"] ==
          join(FermentationDFBA.REDUCED_DCDFBA_MPCC_GLOBAL_POLISH_AROMA_TRACE_STATES, ",")

    trace_only_metrics = copy(comparison.state_metrics_table)
    methionol_index = findfirst(==("methionol"), String.(trace_only_metrics[!, "state_name"]))
    @test methionol_index !== nothing
    trace_only_metrics[methionol_index, "relative_rmse"] = 1.0e6
    trace_only_comparison = ReducedDCDFBAMPCCSequentialComparisonResult(
        comparison.sequential_result,
        comparison.trajectory_candidate,
        comparison.summary_table,
        trace_only_metrics,
        comparison.aligned_timeseries_table,
        copy(comparison.metadata),
    )
    trace_only_acceptance =
        FermentationDFBA._reduced_mpcc_global_polish_biological_acceptance(
            comparison,
            trace_only_comparison;
            enabled = true,
            states = "core",
            relative_tolerance = 0.0,
            absolute_tolerance = 0.0,
            final_states = "biomass,total_sugar",
            final_absolute_tolerance = 0.0,
        )
    @test trace_only_acceptance.passed == true

    worse_core_metrics = copy(comparison.state_metrics_table)
    biomass_index = findfirst(==("biomass"), String.(worse_core_metrics[!, "state_name"]))
    @test biomass_index !== nothing
    worse_core_metrics[biomass_index, "relative_rmse"] = 1.0
    worse_core_metrics[biomass_index, "final_difference_mpcc_minus_sequential"] = 1.0
    worse_core_comparison = ReducedDCDFBAMPCCSequentialComparisonResult(
        comparison.sequential_result,
        comparison.trajectory_candidate,
        comparison.summary_table,
        worse_core_metrics,
        comparison.aligned_timeseries_table,
        copy(comparison.metadata),
    )
    worse_core_acceptance =
        FermentationDFBA._reduced_mpcc_global_polish_biological_acceptance(
            comparison,
            worse_core_comparison;
            enabled = true,
            states = "core",
            relative_tolerance = 0.0,
            absolute_tolerance = 0.0,
            final_states = "biomass,total_sugar",
            final_absolute_tolerance = 0.0,
        )
    @test worse_core_acceptance.passed == false
    @test worse_core_acceptance.metadata["biological_acceptance_reason"] ==
          "core_relative_rmse_worse_than_pre_solve_start"
end

@testset "Reduced MPCC global polish start artifact roundtrip" begin
    continuation = _reduced_mpcc_global_polish_test_continuation()
    starts = build_reduced_dcdfba_mpcc_windowed_start_values(continuation)

    mktempdir() do dir
        paths = export_reduced_dcdfba_mpcc_windowed_start_values(starts, dir)
        @test haskey(paths, "start_values")
        @test haskey(paths, "metadata")
        @test haskey(paths, "array_manifest")
        @test isfile(paths["start_values"])
        @test isfile(paths["metadata"])
        @test isfile(paths["array_manifest"])

        manifest = CSV.read(paths["array_manifest"], DataFrame)
        @test manifest.block == [
            "state_boundary",
            "state_collocation",
            "state_derivative",
            "flux",
            "lower_bound_duals",
            "upper_bound_duals",
            "mass_balance_duals",
        ]
        @test all(manifest.all_finite)
        @test all(manifest.finite_value_count .== manifest.total_value_count)

        loaded = load_reduced_dcdfba_mpcc_windowed_start_values(dir)
        @test loaded.metadata["source_total_nfe"] == starts.metadata["source_total_nfe"]
        @test loaded.state_boundary == starts.state_boundary
        @test loaded.state_collocation == starts.state_collocation
        @test loaded.flux == starts.flux
        @test loaded.lower_bound_duals == starts.lower_bound_duals
        @test loaded.upper_bound_duals == starts.upper_bound_duals
        @test loaded.mass_balance_duals == starts.mass_balance_duals
    end
end

@testset "Reduced MPCC global polish artifact horizon extension" begin
    aligned = DataFrame(time = [0.0, 0.5, 1.0])
    for (index, state_name) in enumerate(FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES)
        sequential = [Float64(index), Float64(index) + 1.0, Float64(index) + 2.0]
        mpcc = sequential .+ 0.25
        aligned[!, "$(state_name)_sequential"] = sequential
        aligned[!, "$(state_name)_mpcc_candidate"] = mpcc
        aligned[!, "$(state_name)_difference_mpcc_minus_sequential"] = mpcc .- sequential
    end
    aligned[!, "total_sugar_sequential"] =
        aligned[!, "glucose_sequential"] .+ aligned[!, "fructose_sequential"]
    aligned[!, "total_sugar_mpcc_candidate"] =
        aligned[!, "glucose_mpcc_candidate"] .+ aligned[!, "fructose_mpcc_candidate"]
    aligned[!, "total_sugar_difference_mpcc_minus_sequential"] =
        aligned[!, "total_sugar_mpcc_candidate"] .-
        aligned[!, "total_sugar_sequential"]

    @test_throws ArgumentError FermentationDFBA._reduced_mpcc_global_polish_artifact_simulations(
        aligned;
        target_horizon = 1.5,
    )

    sequential_reference, state_seed, prefix =
        FermentationDFBA._reduced_mpcc_global_polish_artifact_simulations(
            aligned;
            target_horizon = 1.5,
            extension_policy = "linear_terminal_slope",
        )

    @test prefix.time == [0.0, 0.5, 1.0, 1.5]
    @test sequential_reference.metadata["artifact_extension_applied"] == true
    @test sequential_reference.metadata["artifact_extension_tail_hours"] == 0.5
    @test sequential_reference.metadata["artifact_extension_reference_is_scientific"] == false
    @test state_seed.metadata["reference_source"] ==
          "artifact_aligned_timeseries_mpcc_candidate_with_linear_terminal_slope_extension"
    @test prefix[4, "biomass_sequential"] == 4.0
    @test prefix[4, "biomass_mpcc_candidate"] == 4.25
    @test prefix[4, "biomass_difference_mpcc_minus_sequential"] == 0.25
    @test sequential_reference.states[1, end] == 4.0
    @test state_seed.states[1, end] == 4.25
end

@testset "Reduced MPCC global polish pre-solve start export" begin
    continuation = _reduced_mpcc_global_polish_test_continuation()
    starts = build_reduced_dcdfba_mpcc_windowed_start_values(continuation)
    report = ReducedDCDFBAMPCCDiagnosticReport(
        Dict(
            "max_rhs_residual" => 1.0e-9,
            "max_mass_balance_residual" => 2.0e-9,
        ),
        Dict(
            "max_rhs_residual" => 1.0e-6,
            "max_mass_balance_residual" => 1.0e-6,
        ),
        Dict(
            "max_rhs_residual" => 1.0e-3,
            "max_mass_balance_residual" => 2.0e-3,
        ),
        ["max_mass_balance_residual", "max_rhs_residual"],
        "max_mass_balance_residual",
        true,
        true,
        Dict{String, Float64}(),
        String[],
        Dict{String, Any}("diagnostic_report_kind" => "test_pre_solve"),
    )
    pre_solve_metadata = Dict{String, Any}(
        "pre_solve_guard_required" => true,
        "pre_solve_guard_passed" => true,
        "guarded_solve_attempt_blocked" => false,
    )

    mktempdir() do dir
        metadata =
            FermentationDFBA._reduced_mpcc_global_polish_export_pre_solve_start_values!(
                starts,
                report,
                pre_solve_metadata,
                dir;
                overwrite = false,
                start_source_label = "windowed_artifact_dense_state_flux_values_sanitized_duals",
            )
        @test metadata["global_polish_pre_solve_start_exported"] == true
        @test isfile(metadata["global_polish_pre_solve_start_values_path"])
        @test isfile(metadata["global_polish_pre_solve_start_metadata_path"])
        @test isfile(metadata["global_polish_pre_solve_start_array_manifest_path"])

        loaded = load_reduced_dcdfba_mpcc_windowed_start_values(dir)
        @test loaded.state_boundary == starts.state_boundary
        @test loaded.flux == starts.flux
        @test loaded.metadata["start_type"] ==
              "reduced_dcdfba_mpcc_global_polish_pre_solve_start_values"
        @test loaded.metadata["global_polish_pre_solve_start_exported"] == true
        @test loaded.metadata["global_polish_pre_solve_start_residual_thresholds_satisfied"] ==
              true
        @test loaded.metadata["global_polish_pre_solve_start_max_rhs_residual"] ==
              1.0e-9
        @test loaded.metadata["global_polish_pre_solve_start_source"] ==
              "windowed_artifact_dense_state_flux_values_sanitized_duals"
        @test loaded.metadata["start_values_are_scientific_simulation"] == false
        @test loaded.metadata["solved_trajectory_claimed"] == false
    end
end

@testset "Reduced MPCC global polish incremental prefix candidate overlay" begin
    continuation = _reduced_mpcc_global_polish_test_continuation()
    starts = build_reduced_dcdfba_mpcc_windowed_start_values(continuation)
    prefix_candidate =
        continuation.window_comparisons[1].trajectory_candidate.candidate_diagnostics
    prefix_handoff =
        FermentationDFBA._reduced_mpcc_global_polish_prefix_candidate_handoff_report(
            prefix_candidate,
        )
    @test prefix_handoff.ready == true

    overlaid =
        FermentationDFBA._reduced_mpcc_global_polish_overlay_prefix_candidate_starts(
            starts,
            prefix_candidate;
            source_label = "unit_test_prefix_candidate",
        )

    @test overlaid.metadata["incremental_global_prefix_candidate_applied"] == true
    @test overlaid.metadata["incremental_global_prefix_candidate_nfe"] == 1
    @test overlaid.metadata["incremental_global_prefix_preserves_tail_windowed_start"] == true
    @test overlaid.metadata["incremental_global_prefix_candidate_overlay_policy"] ==
          "state_and_derivative_prefix_only"
    @test overlaid.metadata["incremental_global_prefix_candidate_flux_duals_overlayed"] == true
    @test overlaid.state_boundary[:, 1:2] == prefix_candidate.state_boundary
    @test overlaid.state_collocation[:, 1:1, :] == prefix_candidate.state_collocation
    @test overlaid.flux[:, 1:1, :] == prefix_candidate.flux
    @test overlaid.lower_bound_duals[:, 1:1, :] == prefix_candidate.lower_bound_duals
    @test overlaid.upper_bound_duals[:, 1:1, :] == prefix_candidate.upper_bound_duals
    @test overlaid.mass_balance_duals[:, 1:1, :] == prefix_candidate.mass_balance_duals
    @test overlaid.state_boundary[:, 3] == starts.state_boundary[:, 3]
    @test overlaid.metadata["incremental_global_tail_state_shift_repair_applied"] == false

    shifted_prefix_candidate = deepcopy(prefix_candidate)
    shifted_prefix_candidate.state_boundary[1, end] += 0.5
    repaired =
        FermentationDFBA._reduced_mpcc_global_polish_overlay_prefix_candidate_starts(
            starts,
            shifted_prefix_candidate;
            source_label = "unit_test_shifted_prefix_candidate",
        )
    @test repaired.metadata["incremental_global_prefix_candidate_overlay_policy"] ==
          "state_derivative_prefix_with_constant_state_offset_tail_repair"
    @test repaired.metadata["incremental_global_tail_state_shift_repair_applied"] == true
    @test repaired.metadata["incremental_global_prefix_preserves_tail_windowed_start"] == false
    @test repaired.metadata["incremental_global_prefix_tail_join_mismatch_max_abs_before_repair"] ≈
          0.5
    @test repaired.metadata["incremental_global_prefix_tail_join_mismatch_dominant_state_abs"] ≈
          0.5
    @test repaired.metadata["incremental_global_prefix_candidate_join_boundary_delta_after_repair"] ≈
          0.0
    @test repaired.state_boundary[:, 1:2] == shifted_prefix_candidate.state_boundary
    @test repaired.state_boundary[1, 3] ≈ starts.state_boundary[1, 3] + 0.5
    @test repaired.state_collocation[1, 2, 1] ≈ starts.state_collocation[1, 2, 1] + 0.5
    @test repaired.state_derivative[:, 2, :] == starts.state_derivative[:, 2, :]

    tail_reference = SimulationResult(
        Float64.(starts.metadata["source_boundary_times"]),
        copy(starts.state_boundary);
        metadata = Dict{String, Any}(
            "state_names" => copy(FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES),
            "is_scientific_simulation" => false,
        ),
    )
    reanchored =
        FermentationDFBA._reduced_mpcc_global_polish_overlay_prefix_candidate_starts(
            starts,
            shifted_prefix_candidate;
            source_label = "unit_test_shifted_prefix_candidate",
            tail_reference = tail_reference,
            tail_reference_label = "unit_test_tail_reference",
        )
    @test reanchored.metadata["incremental_global_prefix_candidate_overlay_policy"] ==
          "state_derivative_prefix_with_reanchored_tail_reference"
    @test reanchored.metadata["incremental_global_tail_reference_reanchor_source"] ==
          "unit_test_tail_reference"
    @test reanchored.metadata["incremental_global_tail_flux_dual_extension_applied"] ==
          true
    @test reanchored.flux[:, 2, :] == shifted_prefix_candidate.flux[:, 1, :]
    @test reanchored.lower_bound_duals[:, 2, :] ==
          shifted_prefix_candidate.lower_bound_duals[:, 1, :]
    @test reanchored.upper_bound_duals[:, 2, :] ==
          shifted_prefix_candidate.upper_bound_duals[:, 1, :]
    @test reanchored.mass_balance_duals[:, 2, :] ==
          shifted_prefix_candidate.mass_balance_duals[:, 1, :]

    target_starts =
        FermentationDFBA._reduced_mpcc_global_polish_slice_starts(starts, 0.5)
    long_prefix_candidate = ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(starts.state_boundary),
        copy(starts.state_collocation),
        copy(starts.state_derivative),
        copy(starts.flux),
        copy(starts.lower_bound_duals),
        copy(starts.upper_bound_duals),
        copy(starts.mass_balance_duals),
        copy(prefix_candidate.residual_values),
        copy(prefix_candidate.residual_thresholds),
        copy(prefix_candidate.residual_ratios),
        copy(prefix_candidate.ranked_residuals),
        copy(prefix_candidate.warnings),
        copy(prefix_candidate.metadata),
    )
    truncated =
        FermentationDFBA._reduced_mpcc_global_polish_overlay_prefix_candidate_starts(
            target_starts,
            long_prefix_candidate;
            source_label = "unit_test_long_prefix_candidate",
        )
    @test truncated.metadata["incremental_global_prefix_candidate_nfe"] == 1
    @test truncated.metadata["incremental_global_prefix_candidate_source_nfe"] == 2
    @test truncated.metadata["incremental_global_prefix_candidate_truncated_to_target"] == true
    @test truncated.metadata["incremental_global_prefix_tail_join_mismatch_available"] == false
    @test truncated.state_boundary == starts.state_boundary[:, 1:2]
    @test truncated.state_collocation == starts.state_collocation[:, 1:1, :]
    @test truncated.flux == starts.flux[:, 1:1, :]
    @test truncated.lower_bound_duals == starts.lower_bound_duals[:, 1:1, :]
    @test truncated.upper_bound_duals == starts.upper_bound_duals[:, 1:1, :]
    @test truncated.mass_balance_duals == starts.mass_balance_duals[:, 1:1, :]

    bad_prefix_candidate = deepcopy(prefix_candidate)
    bad_prefix_candidate.metadata["candidate_residual_feasible"] = false
    bad_prefix_candidate.metadata["candidate_trajectory_extraction_ready"] = false
    bad_prefix_candidate.metadata["candidate_iteration_limit_residual_feasible"] = false
    bad_prefix_candidate.metadata["candidate_residual_thresholds_satisfied"] = false
    bad_prefix_candidate.metadata["candidate_solver_status"] = "LOCALLY_INFEASIBLE"
    bad_prefix_candidate.metadata["candidate_primal_status"] = "INFEASIBLE_POINT"
    bad_handoff =
        FermentationDFBA._reduced_mpcc_global_polish_prefix_candidate_handoff_report(
            bad_prefix_candidate,
        )
    @test bad_handoff.ready == false
    @test bad_handoff.reason == "infeasible_solver_or_primal_status"

    residual_feasible_infeasible_prefix = deepcopy(bad_prefix_candidate)
    residual_feasible_infeasible_prefix.metadata["candidate_residual_thresholds_satisfied"] =
        true
    review_handoff =
        FermentationDFBA._reduced_mpcc_global_polish_prefix_candidate_handoff_report(
            residual_feasible_infeasible_prefix,
        )
    @test review_handoff.ready == true
    @test review_handoff.reason ==
          "candidate_residual_thresholds_satisfied_infeasible_status_review"

    mktempdir() do dir
        candidate_path = joinpath(dir, "global_candidate_values.jls")
        open(candidate_path, "w") do io
            serialize(io, prefix_candidate)
        end
        loaded = load_reduced_dcdfba_mpcc_global_candidate_values(dir)
        @test loaded.state_boundary == prefix_candidate.state_boundary
        @test loaded.flux == prefix_candidate.flux
    end
end

@testset "Reduced MPCC global polish start validation" begin
    empty = ReducedDCDFBAMPCCWindowedContinuationResult(
        DataFrame(),
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        nothing,
        nothing,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}("continuation_completed" => false),
    )
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_windowed_start_values(empty)

    initial = _reduced_mpcc_window_test_initial_state()
    first, first_final = _reduced_mpcc_window_test_comparison(
        t0 = 0.0,
        tfinal = 0.5,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, _ = _reduced_mpcc_window_test_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = first_final,
        biomass_offset = 0.02,
        trajectory_ready = false,
        solver_status = "ITERATION_LIMIT",
    )
    incomplete = run_reduced_dcdfba_mpcc_windowed_continuation(
        [first, second];
        continuation_acceptance_policy = "trajectory_ready",
    )
    @test incomplete.metadata["continuation_completed"] == false
    @test_throws ArgumentError build_reduced_dcdfba_mpcc_windowed_start_values(incomplete)

    prefix = build_reduced_dcdfba_mpcc_windowed_start_values(
        incomplete;
        require_complete = false,
    )
    @test prefix.metadata["source_completed_required"] == false
    @test prefix.metadata["source_continuation_completed"] == false
    @test prefix.metadata["all_source_candidates_residual_feasible"] == true
    @test prefix.metadata["all_source_candidates_trajectory_ready"] == false
end

@testset "Reduced MPCC global polish residual-feasible post-solve selection" begin
    continuation = _reduced_mpcc_global_polish_test_continuation()
    start_comparison = continuation.window_comparisons[1]
    sequential_reference = start_comparison.sequential_result
    start_candidate =
        deepcopy(start_comparison.trajectory_candidate.candidate_diagnostics)
    thresholds = Dict{String, Float64}(
        "max_rhs_residual" => 1.0e-6,
        "max_collocation_integration_residual" => 1.0e-6,
        "max_continuity_residual" => 1.0e-6,
        "max_initial_condition_residual" => 1.0e-6,
        "max_mass_balance_residual" => 1.0e-6,
        "max_stationarity_residual" => 1.0e-5,
    )
    for (key, threshold) in thresholds
        start_candidate.residual_values[key] = 1.0e-12
        start_candidate.residual_thresholds[key] = threshold
    end
    start_candidate.metadata["candidate_residual_feasible"] = true
    start_candidate.metadata["candidate_residual_thresholds_satisfied"] = true
    start_candidate.metadata["candidate_trajectory_extraction_ready"] = true

    polish_candidate = deepcopy(start_candidate)
    polish_candidate.residual_values["max_rhs_residual"] = 7.0e-7
    polish_candidate.residual_values["max_collocation_integration_residual"] =
        6.0e-7
    polish_candidate.residual_values["max_continuity_residual"] = 5.0e-7
    polish_candidate.residual_values["max_initial_condition_residual"] = 1.0e-10
    polish_candidate.residual_values["max_mass_balance_residual"] = 8.0e-7
    polish_candidate.residual_values["max_stationarity_residual"] = 2.0e-6
    polish_candidate.metadata["candidate_values_source"] =
        "post_solve_values_flux_bound_projection_repair"
    polish_candidate.metadata["candidate_values_available"] = true

    polish_trajectory = ReducedDCDFBAMPCCTrajectoryCandidate(
        start_comparison.trajectory_candidate.boundary_result,
        start_comparison.trajectory_candidate.collocation_result,
        polish_candidate,
        merge(
            copy(start_comparison.trajectory_candidate.metadata),
            Dict{String, Any}(
                "candidate_values_source" =>
                    "post_solve_values_flux_bound_projection_repair",
            ),
        ),
    )
    polish_comparison =
        compare_reduced_dcdfba_mpcc_to_sequential(sequential_reference, polish_trajectory)
    residual_report = Dict{String, Any}(
        "residuals_available" => true,
        "residual_thresholds_satisfied" => true,
    )
    for (key, value) in polish_candidate.residual_values
        residual_report[key] = value
        if haskey(thresholds, key)
            residual_report["$(key)_threshold"] = thresholds[key]
        end
    end
    mpcc_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
    smoke_result = ReducedDCDFBAMPCCSmokeResult(
        MOI.ITERATION_LIMIT,
        MOI.NEARLY_FEASIBLE_POINT,
        NaN,
        polish_candidate.residual_values["max_mass_balance_residual"],
        0.0,
        0.0,
        polish_candidate.residual_values["max_stationarity_residual"],
        0.0,
        0.0,
        "Ipopt",
        0.0,
        Dict{String, Any}(),
    )
    solve_attempt = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        mpcc_thresholds,
        true,
        true,
        residual_report,
        Dict{String, Any}(
            "solver_status" => "ITERATION_LIMIT",
            "primal_status" => "NEARLY_FEASIBLE_POINT",
        ),
        polish_candidate,
    )

    selected = FermentationDFBA._reduced_mpcc_global_polish_select_accepted_candidate(
        start_candidate,
        solve_attempt,
        polish_trajectory,
        polish_comparison,
        sequential_reference;
        biological_acceptance_enabled = true,
    )

    @test selected.candidate === polish_candidate
    @test selected.metadata["post_solve_candidate_accepted"] == true
    @test selected.metadata["selected_candidate_is_post_solve"] == true
    @test selected.metadata["post_solve_candidate_structural_not_worse"] == false
    @test selected.metadata["post_solve_candidate_structural_absolute_feasible"] == true
    @test selected.metadata["post_solve_candidate_structural_acceptance_passed"] ==
          true
    @test selected.metadata["post_solve_candidate_structural_worse_than_pre_solve_start_but_residual_feasible"] ==
          true
    @test selected.metadata["candidate_selection_reason"] ==
          "post_solve_candidate_residual_feasible_structural_score_worse_than_pre_solve_start"

    polish_candidate.metadata["candidate_trajectory_extraction_ready"] = false
    polish_candidate.metadata["trajectory_candidate_ready"] = false
    selected_requires_ready =
        FermentationDFBA._reduced_mpcc_global_polish_select_accepted_candidate(
            start_candidate,
            solve_attempt,
            polish_trajectory,
            polish_comparison,
            sequential_reference;
            biological_acceptance_enabled = true,
            accept_post_solve_requires_trajectory_ready = true,
        )

    @test selected_requires_ready.candidate === start_candidate
    @test selected_requires_ready.metadata["post_solve_candidate_accepted"] == false
    @test selected_requires_ready.metadata["selected_candidate_is_pre_solve_start"] == true
    @test selected_requires_ready.metadata["selected_candidate_trajectory_ready"] == true
    @test selected_requires_ready.metadata["post_solve_candidate_trajectory_ready"] == false
    @test selected_requires_ready.metadata["candidate_selection_reason"] ==
          "post_solve_candidate_not_trajectory_ready_fallback_to_pre_solve_start"
    @test selected_requires_ready.metadata["candidate_selection_accept_post_solve_requires_trajectory_ready"] ==
          true
end

@testset "Reduced MPCC global polish report export" begin
    continuation = _reduced_mpcc_global_polish_test_continuation()
    starts = build_reduced_dcdfba_mpcc_windowed_start_values(continuation)
    thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
    residual_report = Dict{String, Any}(
        "residuals_available" => true,
        "residual_thresholds_satisfied" => true,
        "max_rhs_residual" => 0.0,
        "max_mass_balance_residual" => 0.0,
        "max_lower_bound_violation" => 0.0,
        "max_upper_bound_violation" => 0.0,
        "max_stationarity_residual" => 0.0,
        "max_lower_complementarity_residual" => 0.0,
        "max_upper_complementarity_residual" => 0.0,
    )
    solve_metadata = Dict{String, Any}(
        "solver_status" => "LOCALLY_SOLVED",
        "primal_status" => "FEASIBLE_POINT",
        "solve_elapsed_seconds" => 0.0,
        "guarded_solve_attempt_blocked" => false,
        "global_polish_collocation_repair_enabled" => true,
        "global_polish_collocation_repair_applied" => true,
        "global_polish_collocation_repair_policy" =>
            "fixed_point_state_flux_dual_rhs_start_refresh",
        "collocation_consistent_state_start_iterations" => 2,
        "collocation_consistent_state_start_converged" => true,
        "collocation_consistent_state_start_final_collocation_residual" => 1.0e-9,
        "collocation_consistent_state_start_final_continuity_residual" => 2.0e-9,
        "solve_attempt_ipopt_warm_start_bound_push" => 1.0e-10,
        "solve_attempt_ipopt_warm_start_bound_push_env" =>
            "MPCC_IPOPT_WARM_START_BOUND_PUSH",
        "solve_attempt_ipopt_warm_start_slack_bound_push" => 2.0e-10,
        "nlp_block_violations_available" => true,
        "nlp_block_max_violation" => 2.0e-3,
        "nlp_block_max_violation_block" => "extra_constraints",
        "nlp_block_violation_rows" => [
            Dict{String, Any}(
                "block" => "extra_constraints",
                "kind" => "unmapped_constraint_block",
                "total_count" => 2,
                "finite_count" => 2,
                "evaluation_error_count" => 0,
                "max_violation" => 2.0e-3,
                "mean_violation" => 1.0e-3,
                "rms_violation" => sqrt(2.0e-6),
                "max_abs_body_value" => 1.0,
                "worst_index" => "2",
                "worst_set" => "MathOptInterface.LessThan{Float64}",
            ),
        ],
    )
    smoke_result = ReducedDCDFBAMPCCSmokeResult(
        MOI.LOCALLY_SOLVED,
        MOI.FEASIBLE_POINT,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        "Ipopt",
        0.0,
        solve_metadata,
    )
    solve_attempt = ReducedDCDFBAMPCCSolveAttemptResult(
        smoke_result,
        thresholds,
        true,
        true,
        residual_report,
        solve_metadata,
        nothing,
    )
    start_summary = DataFrame(
        "block" => ["state_boundary"],
        "source_size" => ["(19, 3)"],
        "target_size" => ["(19, 3)"],
        "applied" => [true],
        "finite_value_count" => [length(starts.state_boundary)],
        "total_value_count" => [length(starts.state_boundary)],
        "max_abs_start" => [maximum(abs.(starts.state_boundary))],
    )
    comparison = continuation.window_comparisons[1]
    metadata = FermentationDFBA._reduced_mpcc_global_polish_metadata(
        continuation,
        starts,
        solve_attempt,
        comparison.trajectory_candidate,
        comparison,
        start_summary,
        true,
    )
    @test metadata["global_polish_collocation_repair_enabled"] == true
    @test metadata["global_polish_collocation_repair_applied"] == true
    @test metadata["global_polish_collocation_repair_policy"] ==
          "fixed_point_state_flux_dual_rhs_start_refresh"
    @test metadata["collocation_consistent_state_start_iterations"] == 2
    @test metadata["collocation_consistent_state_start_converged"] == true
    @test metadata["collocation_consistent_state_start_final_collocation_residual"] ==
          1.0e-9
    @test metadata["solve_attempt_ipopt_warm_start_bound_push"] == 1.0e-10
    @test metadata["solve_attempt_ipopt_warm_start_bound_push_env"] ==
          "MPCC_IPOPT_WARM_START_BOUND_PUSH"
    @test metadata["solve_attempt_ipopt_warm_start_slack_bound_push"] == 2.0e-10
    result = ReducedDCDFBAMPCCGlobalPolishResult(
        continuation,
        starts,
        solve_attempt,
        comparison.trajectory_candidate,
        comparison,
        comparison.trajectory_candidate.candidate_diagnostics,
        comparison.trajectory_candidate,
        comparison,
        start_summary,
        metadata,
    )

    mktempdir() do dir
        paths = write_reduced_dcdfba_mpcc_global_polish_report(result, dir)
        for key in (
            "diagnostics_metadata",
            "diagnostics_start_summary",
            "diagnostics_residual_report",
            "diagnostics_solve_metadata",
            "diagnostics_nlp_block_violations",
            "diagnostics_comparison_state_metrics",
            "diagnostics_comparison_aligned_timeseries",
            "plot_core_states",
        )
            @test haskey(paths, key)
            @test isfile(paths[key])
        end
        nlp_block_violations = CSV.read(paths["diagnostics_nlp_block_violations"], DataFrame)
        @test nrow(nlp_block_violations) == 1
        @test nlp_block_violations.block == ["extra_constraints"]
        @test nlp_block_violations.max_violation == [2.0e-3]
        solve_metadata_table = CSV.read(paths["diagnostics_solve_metadata"], DataFrame)
        @test !("nlp_block_violation_rows" in solve_metadata_table.key)
        @test occursin("<svg", read(paths["plot_core_states"], String))
        @test haskey(paths, "global_candidate_values_jls")
        @test isfile(paths["global_candidate_values_jls"])
        @test !occursin(
            joinpath("diagnostics", "global_candidate_values"),
            paths["global_candidate_values_jls"],
        )
        exported_candidate = load_reduced_dcdfba_mpcc_global_candidate_values(
            paths["global_candidate_values_jls"],
        )
        @test isapprox(
            exported_candidate.state_boundary,
            comparison.trajectory_candidate.candidate_diagnostics.state_boundary,
        )
    end

    mktempdir() do dir
        bad_output = joinpath(dir, "output-is-a-file")
        write(bad_output, "not a directory")
        fallback_root = joinpath(dir, "fallback")
        paths = safe_write_reduced_dcdfba_mpcc_global_polish_report(
            result,
            bad_output;
            fallback_root = fallback_root,
        )
        @test get(result.metadata, "recovery_written", false) == true
        @test get(result.metadata, "report_export_failed", false) == true
        @test haskey(paths, "recovery_result_jls")
        @test isfile(paths["recovery_result_jls"])
        @test haskey(paths, "recovery_metadata")
        @test isfile(paths["recovery_metadata"])
        @test startswith(paths["recovery_result_jls"], normpath(fallback_root))
    end
end
