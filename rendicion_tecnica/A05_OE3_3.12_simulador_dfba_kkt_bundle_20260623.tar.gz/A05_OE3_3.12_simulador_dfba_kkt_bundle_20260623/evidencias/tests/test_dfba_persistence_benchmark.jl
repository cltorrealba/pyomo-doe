import CSV
import TOML
using DataFrames

const DFBA_PERSISTENCE_TEST_PROJECT_ROOT = normpath(joinpath(@__DIR__, ".."))
const DFBA_PERSISTENCE_TEST_SCRIPT_PATH =
    joinpath(DFBA_PERSISTENCE_TEST_PROJECT_ROOT, "scripts", "main_benchmark_dfba_persistence.jl")
const DFBA_PERSISTENCE_TEST_72H_SCRIPT_PATH =
    joinpath(DFBA_PERSISTENCE_TEST_PROJECT_ROOT, "scripts", "main_benchmark_dfba_persistence_72h.jl")
const DFBA_PERSISTENCE_TEST_QPFBA_72H_SCRIPT_PATH =
    joinpath(DFBA_PERSISTENCE_TEST_PROJECT_ROOT, "scripts", "main_benchmark_dfba_qpfba_persistence_72h.jl")
const DFBA_PERSISTENCE_TEST_L1PFBA_72H_SCRIPT_PATH =
    joinpath(DFBA_PERSISTENCE_TEST_PROJECT_ROOT, "scripts", "main_benchmark_dfba_l1pfba_persistence_72h.jl")
const DFBA_PERSISTENCE_TEST_CACHE = Ref{Any}(nothing)

const DFBA_PERSISTENCE_TEST_SUMMARY_COLUMNS = [
    "scenario_id",
    "comparison_role",
    "model_scope",
    "matrix_scope",
    "model_id",
    "lp_reuse",
    "lp_primal_start",
    "lp_basis_warm_start",
    "lp_simplex_strategy",
    "fba_variant",
    "quadratic_penalty",
    "l1_penalty",
    "qpfba_persistent_fallback_count",
    "allow_experimental_lp_reuse",
    "retcode",
    "n_saved_points",
    "rhs_call_count",
    "rhs_lp_solve_count",
    "flux_reconstruction_solve_count",
    "total_lp_solve_count",
    "simulation_elapsed_seconds",
    "ode_solve_elapsed_seconds",
    "rhs_elapsed_seconds",
    "history_reconstruction_elapsed_seconds",
    "benchmark_elapsed_seconds",
    "final_biomass",
    "final_total_sugar",
    "final_ethanol",
    "final_oxygen",
    "max_abs_state_difference_vs_full_cold",
    "state_rmse_vs_full_cold",
    "final_biomass_difference_vs_full_cold",
    "final_total_sugar_difference_vs_full_cold",
    "final_ethanol_difference_vs_full_cold",
    "runtime_speedup_vs_full_cold",
    "max_abs_state_tolerance",
    "state_rmse_tolerance",
    "final_state_tolerance",
    "acceptance_required",
    "acceptance_passed_vs_full_cold",
    "notes",
]

function _dfba_persistence_test_result()
    if DFBA_PERSISTENCE_TEST_CACHE[] === nothing
        full_model = load_full_model(joinpath(DFBA_PERSISTENCE_TEST_PROJECT_ROOT, "config", "full_model_paths.example.toml"))
        full_reaction_map = load_reaction_map(
            joinpath(DFBA_PERSISTENCE_TEST_PROJECT_ROOT, "config", "reaction_map_full.example.toml"),
        )
        reduced_model = load_reduced_model(
            joinpath(DFBA_PERSISTENCE_TEST_PROJECT_ROOT, "config", "reduced_model_paths.example.toml"),
        )
        reduced_reaction_map = load_reaction_map(
            joinpath(DFBA_PERSISTENCE_TEST_PROJECT_ROOT, "config", "reaction_map_reduced.example.toml"),
        )
        DFBA_PERSISTENCE_TEST_CACHE[] = benchmark_dfba_persistence(
            full_model,
            full_reaction_map,
            reduced_model,
            reduced_reaction_map;
            tspan = (0.0, 0.05),
            saveat = 0.05,
            reconstruct_fluxes = false,
        )
    end
    return DFBA_PERSISTENCE_TEST_CACHE[]
end

function _dfba_persistence_summary_row(table::DataFrame, scenario_id::AbstractString)
    row_index = findfirst(==(String(scenario_id)), String.(table[!, "scenario_id"]))
    row_index === nothing && error("Missing DFBA persistence summary row $(String(scenario_id)).")
    return table[row_index, :]
end

@testset "DFBA persistence benchmark tables" begin
    result = _dfba_persistence_test_result()

    @test result isa DFBAPersistenceBenchmarkResult
    @test names(result.summary_table) == DFBA_PERSISTENCE_TEST_SUMMARY_COLUMNS
    @test nrow(result.summary_table) == 3
    @test result.summary_table[!, "scenario_id"] == [
        "full_dfba_cold",
        "full_dfba_persistent",
        "reduced_dfba_persistent",
    ]
    @test result.summary_table[!, "retcode"] == ["Success", "Success", "Success"]
    @test "time" in names(result.aligned_timeseries_table)
    @test "biomass_full_dfba_cold" in names(result.aligned_timeseries_table)
    @test "biomass_full_dfba_persistent" in names(result.aligned_timeseries_table)
    @test "biomass_reduced_dfba_persistent" in names(result.aligned_timeseries_table)

    full_cold = _dfba_persistence_summary_row(result.summary_table, "full_dfba_cold")
    full_persistent = _dfba_persistence_summary_row(result.summary_table, "full_dfba_persistent")
    reduced_persistent = _dfba_persistence_summary_row(result.summary_table, "reduced_dfba_persistent")

    @test full_cold["model_scope"] == "full"
    @test full_cold["comparison_role"] == "baseline_reference"
    @test full_cold["matrix_scope"] == "full_S"
    @test full_cold["lp_reuse"] == false
    @test full_cold["fba_variant"] == "fba"
    @test full_cold["quadratic_penalty"] == 0.0
    @test full_cold["l1_penalty"] == 0.0
    @test full_cold["qpfba_persistent_fallback_count"] == 0
    @test full_cold["allow_experimental_lp_reuse"] == false
    @test full_cold["max_abs_state_difference_vs_full_cold"] == 0.0
    @test full_cold["runtime_speedup_vs_full_cold"] == 1.0
    @test full_cold["acceptance_required"] == true
    @test full_cold["acceptance_passed_vs_full_cold"] == true

    @test full_persistent["model_scope"] == "full"
    @test full_persistent["comparison_role"] == "full_persistent_equivalence_candidate"
    @test full_persistent["matrix_scope"] == "full_S"
    @test full_persistent["lp_reuse"] == true
    @test full_persistent["lp_primal_start"] == true
    @test full_persistent["fba_variant"] == "fba"
    @test full_persistent["quadratic_penalty"] == 0.0
    @test full_persistent["l1_penalty"] == 0.0
    @test full_persistent["qpfba_persistent_fallback_count"] == 0
    @test full_persistent["allow_experimental_lp_reuse"] == true
    @test full_persistent["rhs_call_count"] > 0
    @test full_persistent["total_lp_solve_count"] == full_persistent["rhs_lp_solve_count"]
    @test full_persistent["acceptance_required"] == true
    @test full_persistent["acceptance_passed_vs_full_cold"] isa Bool

    @test reduced_persistent["model_scope"] == "reduced"
    @test reduced_persistent["comparison_role"] == "reduced_model_similarity_candidate"
    @test reduced_persistent["matrix_scope"] == "reduced_S"
    @test reduced_persistent["lp_reuse"] == true
    @test reduced_persistent["lp_primal_start"] == true
    @test reduced_persistent["fba_variant"] == "fba"
    @test reduced_persistent["quadratic_penalty"] == 0.0
    @test reduced_persistent["l1_penalty"] == 0.0
    @test reduced_persistent["qpfba_persistent_fallback_count"] == 0
    @test reduced_persistent["allow_experimental_lp_reuse"] == true
    @test reduced_persistent["rhs_call_count"] > 0
    @test isfinite(Float64(reduced_persistent["state_rmse_vs_full_cold"]))
    @test reduced_persistent["acceptance_required"] == false
    @test reduced_persistent["acceptance_passed_vs_full_cold"] isa Bool

    @test result.metadata["benchmark_name"] == "dfba_full_reduced_persistence"
    @test result.metadata["baseline_scenario_id"] == "full_dfba_cold"
    @test result.metadata["benchmark_profile"] == "short"
    @test result.metadata["benchmark_duration_hours"] == 0.05
    @test haskey(result.metadata, "algorithm_label")
    @test result.metadata["adaptive"] == true
    @test result.metadata["dt"] === nothing
    @test result.metadata["fba_variant"] == "fba"
    @test result.metadata["quadratic_penalty"] == 0.0
    @test result.metadata["l1_penalty"] == 0.0
    @test occursin("LP FBA baseline", result.metadata["regularization_note"])
    @test result.metadata["scientific_model_baseline"] == "full_S_DFBA_in_Julia"
    @test result.metadata["performance_reference_scenario"] == "full_dfba_cold"
    @test result.metadata["persistent_primal_start"] == true
    @test result.metadata["persistent_basis_warm_start"] == false
    @test result.metadata["trajectory_similarity_checked"] == true
    @test result.metadata["full_persistent_max_abs_state_tolerance"] == 1.0e-5
    @test result.metadata["full_persistent_state_rmse_tolerance"] == 1.0e-5
    @test result.metadata["full_persistent_final_state_tolerance"] == 1.0e-5
    @test result.metadata["acceptance_required_scenarios"] == ["full_dfba_cold", "full_dfba_persistent"]
    @test result.metadata["progress_interval_seconds"] == 0.0
    @test result.metadata["gurobi_required"] == false
    @test result.metadata["ipopt_required"] == false
    @test result.metadata["hsl_required"] == false
    @test result.metadata["r0001_used_as_oxygen"] == false
    @test result.metadata["oxygen_reaction_id"] == "r_1992"
    @test occursin("input generators", result.metadata["matlab_role_note"])
    @test occursin("does not build an MPCC", result.metadata["mpcc_scope_note"])
end

@testset "DFBA persistence benchmark export" begin
    result = _dfba_persistence_test_result()
    output_dir = mktempdir()
    paths = export_dfba_persistence_benchmark(result, output_dir)

    @test isfile(paths["summary"])
    @test isfile(paths["aligned_timeseries"])
    @test isfile(paths["metadata"])
    @test names(CSV.read(paths["summary"], DataFrame)) == DFBA_PERSISTENCE_TEST_SUMMARY_COLUMNS
    @test "time" in names(CSV.read(paths["aligned_timeseries"], DataFrame))

    metadata = TOML.parsefile(paths["metadata"])
    @test metadata["benchmark_name"] == "dfba_full_reduced_persistence"
    @test metadata["baseline_scenario_id"] == "full_dfba_cold"
    @test metadata["benchmark_profile"] == "short"
    @test metadata["benchmark_duration_hours"] == 0.05
    @test haskey(metadata, "algorithm_label")
    @test metadata["adaptive"] == true
    @test metadata["fba_variant"] == "fba"
    @test metadata["quadratic_penalty"] == 0.0
    @test metadata["l1_penalty"] == 0.0
    @test occursin("LP FBA baseline", metadata["regularization_note"])
    @test metadata["scientific_model_baseline"] == "full_S_DFBA_in_Julia"
    @test metadata["full_persistent_max_abs_state_tolerance"] == 1.0e-5
    @test metadata["acceptance_required_scenarios"] == ["full_dfba_cold", "full_dfba_persistent"]
    @test metadata["progress_interval_seconds"] == 0.0
    @test metadata["gurobi_required"] == false
    @test metadata["ipopt_required"] == false
    @test metadata["hsl_required"] == false

    @test_throws ErrorException export_dfba_persistence_benchmark(result, output_dir)
    @test export_dfba_persistence_benchmark(result, output_dir; overwrite = true) isa Dict{String, String}
end

@testset "DFBA persistence benchmark SVG plots" begin
    result = _dfba_persistence_test_result()
    output_dir = mktempdir()
    paths = write_dfba_persistence_benchmark_plots(result, output_dir)

    @test sort(collect(keys(paths))) == [
        "core_states",
        "final_states",
        "runtime_counters",
        "state_differences",
    ]
    for path in values(paths)
        @test isfile(path)
        @test occursin("<svg", read(path, String))
    end
    @test occursin("DFBA persistence dynamic trajectories", read(paths["core_states"], String))
    @test occursin("DFBA persistence runtime counters", read(paths["runtime_counters"], String))

    @test_throws ErrorException write_dfba_persistence_benchmark_plots(result, output_dir)
    @test write_dfba_persistence_benchmark_plots(result, output_dir; overwrite = true) isa Dict{String, String}
end

@testset "DFBA persistence benchmark script contract" begin
    @test isfile(DFBA_PERSISTENCE_TEST_SCRIPT_PATH)
    script_text = read(DFBA_PERSISTENCE_TEST_SCRIPT_PATH, String)
    for required_text in (
        "full_model_paths.example.toml",
        "reaction_map_full.example.toml",
        "reduced_model_paths.example.toml",
        "reaction_map_reduced.example.toml",
        "DFBA_PERSISTENCE_BENCH_PROFILE",
        "DFBA_PERSISTENCE_BENCH_ALGORITHM",
        "DFBA_PERSISTENCE_BENCH_ADAPTIVE",
        "DFBA_PERSISTENCE_BENCH_DT_HOURS",
        "DFBA_PERSISTENCE_BENCH_TFINAL_HOURS",
        "DFBA_PERSISTENCE_BENCH_SAVEAT_HOURS",
        "DFBA_PERSISTENCE_BENCH_FBA_VARIANT",
        "DFBA_PERSISTENCE_BENCH_QUADRATIC_PENALTY",
        "DFBA_PERSISTENCE_BENCH_L1_PENALTY",
        "DFBA_PERSISTENCE_BENCH_PRIMAL_START",
        "DFBA_PERSISTENCE_BENCH_BASIS_WARM_START",
        "DFBA_PERSISTENCE_BENCH_MAX_RHS_CALLS",
        "DFBA_PERSISTENCE_BENCH_MAX_WALLTIME_SECONDS",
        "DFBA_PERSISTENCE_BENCH_FULL_PERSISTENT_MAX_ABS_STATE_TOL",
        "DFBA_PERSISTENCE_BENCH_FULL_PERSISTENT_STATE_RMSE_TOL",
        "DFBA_PERSISTENCE_BENCH_FULL_PERSISTENT_FINAL_STATE_TOL",
        "DFBA_PERSISTENCE_BENCH_REDUCED_MAX_ABS_STATE_TOL",
        "DFBA_PERSISTENCE_BENCH_REDUCED_STATE_RMSE_TOL",
        "DFBA_PERSISTENCE_BENCH_REDUCED_FINAL_STATE_TOL",
        "DFBA_PERSISTENCE_BENCH_PROGRESS_INTERVAL_SECONDS",
        "DFBA_PERSISTENCE_BENCH_OUTPUT_DIR",
        "results\", \"benchmarks\", \"dfba_persistence_latest",
        "results\", \"benchmarks\", \"dfba_persistence_72h_latest",
        "benchmark_dfba_persistence",
        "export_dfba_persistence_benchmark",
        "write_dfba_persistence_benchmark_plots",
        "written_svg_files",
        "fba_variant",
        "quadratic_penalty",
        "l1_penalty",
        "qpfba_persistent_fallback_count",
        "full_dfba_cold",
        "full_dfba_persistent",
        "reduced_dfba_persistent",
        "scientific_model_baseline",
        "matlab_role_note",
        "mpcc_scope_note",
        "ipopt_required",
        "hsl_required",
        "r0001_used_as_oxygen",
        "oxygen_reaction_id",
    )
        @test occursin(required_text, script_text)
    end
    @test !occursin("Gurobi", script_text)

    @test isfile(DFBA_PERSISTENCE_TEST_72H_SCRIPT_PATH)
    script_72h_text = read(DFBA_PERSISTENCE_TEST_72H_SCRIPT_PATH, String)
    for required_text in (
        "DFBA_PERSISTENCE_BENCH_PROFILE",
        "\"72h\"",
        "DFBA_PERSISTENCE_BENCH_ALGORITHM",
        "\"Tsit5\"",
        "DFBA_PERSISTENCE_BENCH_ADAPTIVE",
        "\"false\"",
        "DFBA_PERSISTENCE_BENCH_DT_HOURS",
        "DFBA_PERSISTENCE_BENCH_TFINAL_HOURS",
        "\"72.0\"",
        "DFBA_PERSISTENCE_BENCH_SAVEAT_HOURS",
        "\"1.0\"",
        "DFBA_PERSISTENCE_BENCH_RECONSTRUCT_FLUXES",
        "DFBA_PERSISTENCE_BENCH_PROGRESS_INTERVAL_SECONDS",
        "\"60.0\"",
        "dfba_persistence_72h_latest",
        "main_benchmark_dfba_persistence.jl",
    )
        @test occursin(required_text, script_72h_text)
    end
    @test !occursin("Gurobi", script_72h_text)

    @test isfile(DFBA_PERSISTENCE_TEST_QPFBA_72H_SCRIPT_PATH)
    qpfba_72h_text = read(DFBA_PERSISTENCE_TEST_QPFBA_72H_SCRIPT_PATH, String)
    for required_text in (
        "DFBA_PERSISTENCE_BENCH_PROFILE",
        "\"72h\"",
        "DFBA_PERSISTENCE_BENCH_FBA_VARIANT",
        "\"qpfba\"",
        "DFBA_PERSISTENCE_BENCH_QUADRATIC_PENALTY",
        "\"1.0e-5\"",
        "DFBA_PERSISTENCE_BENCH_ALGORITHM",
        "\"Tsit5\"",
        "DFBA_PERSISTENCE_BENCH_ADAPTIVE",
        "\"false\"",
        "DFBA_PERSISTENCE_BENCH_DT_HOURS",
        "DFBA_PERSISTENCE_BENCH_HIGHS_SOLVER",
        "\"default\"",
        "dfba_qpfba_persistence_72h_latest",
        "main_benchmark_dfba_persistence.jl",
    )
        @test occursin(required_text, qpfba_72h_text)
    end
    @test !occursin("Gurobi", qpfba_72h_text)

    @test isfile(DFBA_PERSISTENCE_TEST_L1PFBA_72H_SCRIPT_PATH)
    l1pfba_72h_text = read(DFBA_PERSISTENCE_TEST_L1PFBA_72H_SCRIPT_PATH, String)
    for required_text in (
        "DFBA_PERSISTENCE_BENCH_PROFILE",
        "\"72h\"",
        "DFBA_PERSISTENCE_BENCH_FBA_VARIANT",
        "\"l1pfba\"",
        "DFBA_PERSISTENCE_BENCH_L1_PENALTY",
        "\"1.0e-6\"",
        "DFBA_PERSISTENCE_BENCH_ALGORITHM",
        "\"Tsit5\"",
        "DFBA_PERSISTENCE_BENCH_ADAPTIVE",
        "\"false\"",
        "DFBA_PERSISTENCE_BENCH_DT_HOURS",
        "DFBA_PERSISTENCE_BENCH_HIGHS_SOLVER",
        "\"simplex\"",
        "dfba_l1pfba_persistence_72h_latest",
        "main_benchmark_dfba_persistence.jl",
    )
        @test occursin(required_text, l1pfba_72h_text)
    end
    @test !occursin("Gurobi", l1pfba_72h_text)
end
