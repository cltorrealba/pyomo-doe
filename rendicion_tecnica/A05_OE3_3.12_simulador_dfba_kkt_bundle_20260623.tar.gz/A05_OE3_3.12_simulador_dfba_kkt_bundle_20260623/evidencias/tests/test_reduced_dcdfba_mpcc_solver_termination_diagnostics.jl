using DataFrames

function _reduced_mpcc_solver_termination_attempt()
    residual_thresholds =
        default_reduced_dcdfba_mpcc_residual_thresholds(max_mass_balance_residual = 5.0e-6)
    thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
        residual_thresholds = residual_thresholds,
    )
    viability_table = DataFrame(
        "candidate_id" => ["window_001", "window_002", "window_003"],
        "source_type" => fill("windowed_continuation_window", 3),
        "source_row_status" => fill("completed", 3),
        "traffic_light" => ["green", "yellow", "red"],
        "viability_class" => [
            "simulation_viable_candidate",
            "iteration_limit_residual_feasible_candidate",
            "residual_thresholds_failed",
        ],
        "simulation_viable" => [true, false, false],
        "trajectory_ready" => [true, false, false],
        "residual_feasible" => [true, true, false],
        "iteration_limit_residual_feasible" => [false, true, false],
        "residual_thresholds_satisfied" => [true, true, false],
        "residuals_pass" => [true, true, false],
        "state_drift_pass" => [true, true, true],
        "window_index" => [1, 2, 3],
        "window_hours" => [0.5, 0.5, 0.5],
        "nfe" => [2, 2, 2],
        "degree" => [3, 3, 3],
        "solver_status" => ["LOCALLY_SOLVED", "ITERATION_LIMIT", "ITERATION_LIMIT"],
        "primal_status" => fill("FEASIBLE_POINT", 3),
        "solve_elapsed_seconds" => [10.0, 20.0, 30.0],
        "max_rhs_residual" => [1.0e-8, 2.0e-8, 3.0e-8],
        "max_mass_balance_residual" => [5.0e-7, 2.0e-6, 1.0e-5],
        "max_lower_bound_violation" => [0.0, 0.0, 0.0],
        "max_upper_bound_violation" => [0.0, 0.0, 0.0],
        "max_stationarity_residual" => [1.0e-7, 2.0e-7, 3.0e-7],
        "max_lower_complementarity_residual" => [0.0, 0.0, 0.0],
        "max_upper_complementarity_residual" => [0.0, 0.0, 0.0],
        "max_state_relative_rmse" => [0.001, 0.002, 0.003],
        "blocking_reasons" => [
            "",
            "candidate_not_trajectory_ready",
            "candidate_not_residual_feasible;residual_thresholds_failed",
        ],
        "review_reasons" => [
            "full_dfba_cold_reference_deferred",
            "iteration_limit_residual_feasible",
            "residual_thresholds_failed",
        ],
        "next_recommended_action" => [
            "review_green_candidate_before_scientific_use",
            "improve_solver_termination_before_simulation",
            "repair_residual_feasibility_before_simulation",
        ],
    )
    window_table = DataFrame(
        "window_id" => ["window_001", "window_002", "window_003"],
        "window_index" => [1, 2, 3],
        "t0" => [0.0, 0.5, 1.0],
        "tfinal" => [0.5, 1.0, 1.5],
        "window_hours" => [0.5, 0.5, 0.5],
    )
    continuation = ReducedDCDFBAMPCCWindowedContinuationResult(
        window_table,
        ReducedDCDFBAMPCCSequentialComparisonResult[],
        nothing,
        nothing,
        DataFrame(),
        DataFrame(),
        Dict{String, Any}("total_horizon_reached" => 1.5),
    )
    report = ReducedDCDFBAMPCCSimulationViabilityReport(
        "windowed_continuation",
        viability_table,
        thresholds,
        Dict{String, Any}("overall_traffic_light" => "red"),
    )
    return ReducedDCDFBAMPCCWindowedSimulationAttemptResult(
        continuation,
        report,
        DataFrame(),
        Dict{String, Any}(
            "target_horizon" => 1.5,
            "horizon_reached" => 1.5,
            "target_completed" => true,
            "attempt_traffic_light" => "red",
            "attempt_viable" => false,
        ),
    )
end

function _reduced_mpcc_solver_termination_retry_result(;
    window_index::Int,
    recovered_green::Bool,
    recovered_trajectory::Bool,
)
    source_id = "window_" * lpad(string(window_index), 3, '0')
    best_case = recovered_green || recovered_trajectory ? "retry_002" : "retry_001"
    retry_table = DataFrame(
        "retry_case_id" => ["retry_001", "retry_002"],
        "source_window_id" => [source_id, source_id],
        "source_window_index" => [window_index, window_index],
        "source_window_t0" => fill((window_index - 1) * 0.5, 2),
        "source_window_tfinal" => fill(window_index * 0.5, 2),
        "source_window_hours" => fill(0.5, 2),
        "ipopt_max_iter" => [200, 300],
        "solver_status" => [
            "ITERATION_LIMIT",
            recovered_trajectory ? "LOCALLY_SOLVED" : "ITERATION_LIMIT",
        ],
        "primal_status" => fill("FEASIBLE_POINT", 2),
        "traffic_light" => [
            "yellow",
            recovered_green ? "green" : "yellow",
        ],
        "viability_class" => [
            "iteration_limit_residual_feasible_candidate",
            recovered_green ? "simulation_viable_candidate" :
            "iteration_limit_residual_feasible_candidate",
        ],
        "residual_feasible" => [true, true],
        "iteration_limit_residual_feasible" => [true, !recovered_trajectory],
        "trajectory_ready" => [false, recovered_trajectory],
        "residual_thresholds_satisfied" => [true, true],
        "residuals_pass" => [true, true],
        "state_drift_pass" => [true, true],
        "solve_elapsed_seconds" => [25.0, 35.0],
        "max_rhs_residual" => [1.0e-8, 1.0e-8],
        "max_mass_balance_residual" => [
            1.5e-6,
            recovered_green ? 4.0e-7 : 2.0e-6,
        ],
        "max_mass_balance_ratio" => [0.3, recovered_green ? 0.08 : 0.4],
        "max_lower_bound_violation" => [0.0, 0.0],
        "max_upper_bound_violation" => [0.0, 0.0],
        "max_stationarity_residual" => [1.0e-7, 1.0e-7],
        "max_lower_complementarity_residual" => [0.0, 0.0],
        "max_upper_complementarity_residual" => [0.0, 0.0],
        "blocking_reasons" => ["candidate_not_trajectory_ready", ""],
        "review_reasons" => ["iteration_limit_residual_feasible", ""],
    )
    metadata = Dict{String, Any}(
        "retry_diagnostic_type" => "reduced_dcdfba_mpcc_window_retry_diagnostics",
        "source_window_id" => source_id,
        "source_window_index" => window_index,
        "source_window_t0" => (window_index - 1) * 0.5,
        "source_window_tfinal" => window_index * 0.5,
        "source_window_hours" => 0.5,
        "source_traffic_light" => window_index == 3 ? "red" : "yellow",
        "source_viability_class" =>
            window_index == 3 ? "residual_thresholds_failed" :
            "iteration_limit_residual_feasible_candidate",
        "source_solver_status" => "ITERATION_LIMIT",
        "source_residual_feasible" => window_index != 3,
        "source_max_mass_balance_residual" => window_index == 3 ? 1.0e-5 : 2.0e-6,
        "source_max_mass_balance_ratio" => window_index == 3 ? 2.0 : 0.4,
        "source_blocking_reasons" => "candidate_not_trajectory_ready",
        "n_retry_cases" => 2,
        "green_retry_count" => recovered_green ? 1 : 0,
        "yellow_retry_count" => recovered_green ? 1 : 2,
        "red_retry_count" => 0,
        "residual_feasible_retry_count" => 2,
        "best_retry_case_id" => best_case,
        "best_retry_ipopt_max_iter" => best_case == "retry_002" ? 300 : 200,
        "best_retry_traffic_light" => recovered_green ? "green" : "yellow",
        "best_retry_viability_class" =>
            recovered_green ? "simulation_viable_candidate" :
            "iteration_limit_residual_feasible_candidate",
        "best_retry_max_mass_balance_residual" =>
            recovered_green ? 4.0e-7 : 1.5e-6,
        "best_retry_max_mass_balance_ratio" => recovered_green ? 0.08 : 0.3,
        "retry_recovered_residual_feasibility" => window_index == 3,
        "retry_recovered_green_window" => recovered_green,
    )
    return ReducedDCDFBAMPCCWindowRetryDiagnosticResult(
        retry_table,
        ReducedDCDFBAMPCCSolveAttemptSweepResult[],
        ReducedDCDFBAMPCCSimulationViabilityReport[],
        metadata,
    )
end

@testset "Reduced MPCC solver termination diagnostics" begin
    attempt = _reduced_mpcc_solver_termination_attempt()
    diagnostic = diagnose_reduced_dcdfba_mpcc_solver_termination(attempt)

    @test diagnostic isa ReducedDCDFBAMPCCSolverTerminationDiagnosticResult
    @test size(diagnostic.termination_table, 1) == 3
    @test size(diagnostic.residual_gate_table, 1) ==
          3 * 7
    @test size(diagnostic.transition_table, 1) == 0
    @test diagnostic.metadata["diagnostic_type"] ==
          "reduced_dcdfba_mpcc_solver_termination_diagnostics"
    @test diagnostic.metadata["n_windows_analyzed"] == 3
    @test diagnostic.metadata["iteration_limit_count"] == 2
    @test diagnostic.metadata["iteration_limit_residual_feasible_count"] == 1
    @test diagnostic.metadata["trajectory_ready_count"] == 1
    @test diagnostic.metadata["residual_threshold_failure_count"] == 1
    @test diagnostic.metadata["first_blocked_window_id"] == "window_002"
    @test diagnostic.metadata["outputs_written"] == false
    @test diagnostic.metadata["solver_termination_diagnostic_is_scientific_simulation"] ==
          false
    @test diagnostic.metadata["solved_trajectory_claimed"] == false
    @test diagnostic.metadata["first_mpcc_target"] == "reduced_dfba"
    @test diagnostic.metadata["hsl_required"] == false
    @test diagnostic.metadata["ma57_required"] == false
    @test diagnostic.metadata["indices_reacciones_used"] == false
    @test diagnostic.metadata["r0001_used_as_oxygen"] == false

    table = diagnostic.termination_table
    window_002 = table[
        (table.window_id .== "window_002") .&
        (table.phase .== "source_window"),
        :,
    ][1, :]
    window_003 = table[
        (table.window_id .== "window_003") .&
        (table.phase .== "source_window"),
        :,
    ][1, :]
    @test window_002["termination_blocker"] ==
          "iteration_limit_residual_feasible_status_gate"
    @test window_002["likely_cause"] == "solver_iteration_limit_status_gate"
    @test window_002["recommended_next_action"] ==
          "inspect_solver_termination_policy_or_scaling"
    @test window_003["termination_blocker"] == "residual_thresholds_failed"
    @test window_003["dominant_residual"] == "max_mass_balance_residual"
    @test isapprox(window_003["max_residual_ratio"], 2.0; atol = 0.0, rtol = 1.0e-12)
end

@testset "Reduced MPCC solver termination retry transitions" begin
    attempt = _reduced_mpcc_solver_termination_attempt()
    retry_results = [
        _reduced_mpcc_solver_termination_retry_result(
            window_index = 2,
            recovered_green = false,
            recovered_trajectory = false,
        ),
        _reduced_mpcc_solver_termination_retry_result(
            window_index = 3,
            recovered_green = true,
            recovered_trajectory = true,
        ),
    ]
    policy = diagnose_reduced_dcdfba_mpcc_windowed_retry_policy(
        attempt,
        retry_results;
        window_indices = [2, 3],
        max_retry_windows = 2,
        ipopt_max_iter_values = [200, 300],
    )
    retry_aware = attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
        attempt,
        policy,
    )
    diagnostic = diagnose_reduced_dcdfba_mpcc_solver_termination(retry_aware)

    @test diagnostic.retry_aware_attempt === retry_aware
    @test size(diagnostic.termination_table, 1) == 5
    @test size(diagnostic.transition_table, 1) == 2
    @test diagnostic.metadata["source_kind"] == "retry_aware_windowed_attempt"
    @test diagnostic.metadata["n_retry_rows_analyzed"] == 2
    @test diagnostic.metadata["retry_recovered_trajectory_ready_count"] == 1
    @test diagnostic.metadata["retry_recovered_green_count"] == 1
    @test diagnostic.metadata["recommended_next_action"] ==
          "repair_dominant_residual_before_solver_policy_change"
    @test diagnostic.metadata["retry_replacement_applied"] == false

    transitions = diagnostic.transition_table
    transition_002 = transitions[transitions.window_id .== "window_002", :][1, :]
    transition_003 = transitions[transitions.window_id .== "window_003", :][1, :]
    @test transition_002["recovered_trajectory_ready"] == false
    @test transition_002["source_termination_blocker"] ==
          "iteration_limit_residual_feasible_status_gate"
    @test transition_002["best_retry_termination_blocker"] ==
          "iteration_limit_residual_feasible_status_gate"
    @test transition_002["recommended_next_action"] ==
          "inspect_solver_termination_policy_or_scaling"
    @test transition_003["recovered_trajectory_ready"] == true
    @test transition_003["recovered_residual_feasible"] == true
    @test transition_003["recovered_green"] == true
    @test transition_003["residual_ratio_improved"] == true
    @test transition_003["recommended_next_action"] ==
          "review_green_retry_before_window_replacement"
end
