import MathOptInterface as MOI

@testset "Static FBA problem" begin
    toy_model = MetabolicModel(
        [1.0 -1.0 0.0; 0.0 1.0 -1.0],
        [0.0, 0.0, 0.0],
        [10.0, 100.0, 100.0],
        ["r_uptake", "r_internal", "r_biomass"],
        ["met_a", "met_b"];
        model_id = "toy_fba",
    )

    @test reaction_index(toy_model, "r_internal") == 2
    @test reaction_indices(toy_model, ["r_uptake", "r_biomass"]) == [1, 3]
    @test has_reaction(toy_model, "r_biomass")
    @test !has_reaction(toy_model, "r_missing")
    @test_throws ErrorException reaction_index(toy_model, "r_missing")

    result = solve_fba(toy_model; objective_rxn_id = "r_biomass")

    @test result.status == MOI.OPTIMAL
    @test result.objective_value ≈ 10.0 atol = 1.0e-8
    @test length(result.fluxes) == 3
    @test result.fluxes[3] ≈ 10.0 atol = 1.0e-8
    @test result.mass_balance_residual <= 1.0e-8
    @test result.max_lower_bound_violation <= 1.0e-8
    @test result.max_upper_bound_violation <= 1.0e-8

    attributed_result = solve_fba(
        toy_model;
        objective_rxn_id = "r_biomass",
        optimizer_attributes = Dict("time_limit" => 60.0),
    )
    @test attributed_result.status == MOI.OPTIMAL
    @test attributed_result.metadata["optimizer_attributes"]["time_limit"] == 60.0
end

@testset "QP-regularized FBA problem" begin
    degenerate_model = MetabolicModel(
        [1.0 -1.0 -1.0],
        [1.0, 0.0, 0.0],
        [1.0, 1.0, 1.0],
        ["v_in", "v_a", "v_b"],
        ["met_a"];
        model_id = "toy_qpfba",
    )

    lp_result = solve_fba(degenerate_model; objective_weights = Dict("v_a" => 1.0, "v_b" => 1.0))
    qp_result = solve_qp_regularized_fba(
        degenerate_model;
        objective_weights = Dict("v_a" => 1.0, "v_b" => 1.0),
        quadratic_penalty = 1.0e-2,
    )

    @test lp_result.status == MOI.OPTIMAL
    @test qp_result.status == MOI.OPTIMAL
    @test qp_result.metadata["fba_variant"] == "qpfba"
    @test qp_result.metadata["quadratic_penalty"] == 1.0e-2
    @test isapprox(qp_result.objective_value, 1.0; atol = 1.0e-8)
    @test isapprox(qp_result.fluxes[reaction_index(degenerate_model, "v_a")], 0.5; atol = 1.0e-6)
    @test isapprox(qp_result.fluxes[reaction_index(degenerate_model, "v_b")], 0.5; atol = 1.0e-6)
    @test qp_result.metadata["regularized_objective_value"] < qp_result.metadata["primary_objective_value"]
    @test qp_result.mass_balance_residual <= 1.0e-8
    @test qp_result.max_lower_bound_violation <= 1.0e-8
    @test qp_result.max_upper_bound_violation <= 1.0e-8

    @test_throws ErrorException solve_qp_regularized_fba(
        degenerate_model;
        objective_weights = Dict("v_a" => 1.0),
        quadratic_penalty = 0.0,
    )
end

@testset "L1-regularized FBA problem" begin
    loop_model = MetabolicModel(
        [1.0 -1.0 1.0 -1.0],
        [1.0, 0.0, 0.0, 0.0],
        [1.0, 1.0, 100.0, 100.0],
        ["v_in", "v_out", "v_loop_forward", "v_loop_reverse"],
        ["met_a"];
        model_id = "toy_l1pfba",
    )

    l1_result = solve_l1_regularized_fba(
        loop_model;
        objective_rxn_id = "v_out",
        l1_penalty = 1.0e-3,
    )

    @test l1_result.status == MOI.OPTIMAL
    @test l1_result.metadata["fba_variant"] == "l1pfba"
    @test l1_result.metadata["l1_penalty"] == 1.0e-3
    @test l1_result.metadata["objective_type"] == "single_l1pfba"
    @test isapprox(l1_result.objective_value, 1.0; atol = 1.0e-8)
    @test isapprox(l1_result.fluxes[reaction_index(loop_model, "v_in")], 1.0; atol = 1.0e-8)
    @test isapprox(l1_result.fluxes[reaction_index(loop_model, "v_out")], 1.0; atol = 1.0e-8)
    @test isapprox(l1_result.fluxes[reaction_index(loop_model, "v_loop_forward")], 0.0; atol = 1.0e-8)
    @test isapprox(l1_result.fluxes[reaction_index(loop_model, "v_loop_reverse")], 0.0; atol = 1.0e-8)
    @test isapprox(l1_result.metadata["l1_norm_value"], 2.0; atol = 1.0e-8)
    @test l1_result.metadata["regularized_objective_value"] < l1_result.metadata["primary_objective_value"]
    @test l1_result.mass_balance_residual <= 1.0e-8
    @test l1_result.max_lower_bound_violation <= 1.0e-8
    @test l1_result.max_upper_bound_violation <= 1.0e-8

    @test_throws ErrorException solve_l1_regularized_fba(
        loop_model;
        objective_rxn_id = "v_out",
        l1_penalty = 0.0,
    )
end

@testset "Weighted FBA objective" begin
    weighted_model = MetabolicModel(
        [1.0 -1.0 -1.0],
        [1.0, 0.0, 0.0],
        [1.0, 1.0, 1.0],
        ["v_in", "v_biomass", "v_product"],
        ["met_a"];
        model_id = "toy_weighted_fba",
    )

    single_result = solve_fba(weighted_model; objective_rxn_id = "v_biomass")

    @test single_result.status == MOI.OPTIMAL
    @test single_result.objective_rxn_id == "v_biomass"
    @test single_result.objective_index == reaction_index(weighted_model, "v_biomass")
    @test single_result.objective_weights == Dict("v_biomass" => 1.0)
    @test single_result.objective_description == "single:v_biomass"
    @test single_result.metadata["objective_type"] == "single"
    @test single_result.metadata["n_objective_terms"] == 1
    @test isapprox(single_result.objective_value, 1.0; atol = 1.0e-8)
    @test isapprox(single_result.fluxes[reaction_index(weighted_model, "v_biomass")], 1.0; atol = 1.0e-8)
    @test isapprox(single_result.fluxes[reaction_index(weighted_model, "v_product")], 0.0; atol = 1.0e-8)
    @test single_result.mass_balance_residual <= 1.0e-8
    @test single_result.max_lower_bound_violation <= 1.0e-8
    @test single_result.max_upper_bound_violation <= 1.0e-8

    objective_weights = Dict("v_biomass" => 1.0, "v_product" => 2.0)
    weighted_result = solve_fba(weighted_model; objective_weights = objective_weights)
    weighted_objective =
        objective_weights["v_biomass"] * weighted_result.fluxes[reaction_index(weighted_model, "v_biomass")] +
        objective_weights["v_product"] * weighted_result.fluxes[reaction_index(weighted_model, "v_product")]

    @test weighted_result.status == MOI.OPTIMAL
    @test weighted_result.objective_rxn_id === nothing
    @test weighted_result.objective_index === nothing
    @test weighted_result.objective_weights == objective_weights
    @test weighted_result.objective_description == "weighted"
    @test weighted_result.metadata["objective_type"] == "weighted"
    @test weighted_result.metadata["n_objective_terms"] == 2
    @test isapprox(weighted_result.objective_value, weighted_objective; atol = 1.0e-8)
    @test isapprox(weighted_result.objective_value, 2.0; atol = 1.0e-8)
    @test isapprox(weighted_result.fluxes[reaction_index(weighted_model, "v_biomass")], 0.0; atol = 1.0e-8)
    @test isapprox(weighted_result.fluxes[reaction_index(weighted_model, "v_product")], 1.0; atol = 1.0e-8)
    @test weighted_result.mass_balance_residual <= 1.0e-8
    @test weighted_result.max_lower_bound_violation <= 1.0e-8
    @test weighted_result.max_upper_bound_violation <= 1.0e-8

    @test_throws ErrorException solve_fba(weighted_model; objective_weights = Dict{String, Float64}())
    @test_throws ErrorException solve_fba(weighted_model; objective_weights = Dict("v_missing" => 1.0))
    @test_throws ErrorException solve_fba(weighted_model; objective_weights = Dict("v_biomass" => NaN))
    @test_throws ErrorException solve_fba(weighted_model; objective_rxn_id = "v_biomass", objective_weights = objective_weights)
    @test_throws ErrorException solve_fba(weighted_model)
end

@testset "Reduced static FBA smoke solve" begin
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")

    model = load_reduced_model(paths_config)
    result = solve_fba(model; objective_rxn_id = "r_2111", atol = 1.0e-8)

    @test result.status == MOI.OPTIMAL
    @test length(result.fluxes) == 1488
    @test result.objective_rxn_id == "r_2111"
    @test result.objective_index == reaction_index(model, "r_2111")
    @test result.objective_weights == Dict("r_2111" => 1.0)
    @test result.objective_description == "single:r_2111"
    @test result.metadata["objective_type"] == "single"
    @test result.mass_balance_residual <= 1.0e-6
    @test result.max_lower_bound_violation <= 1.0e-6
    @test result.max_upper_bound_violation <= 1.0e-6
end
