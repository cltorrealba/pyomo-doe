import MathOptInterface as MOI

const REDUCED_MPCC_SEQ_TEST_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _reduced_mpcc_seq_test_states()
    states = zeros(19, 2)
    states[1, :] .= [1.0, 1.2]
    states[2, :] .= [0.1, 0.08]
    states[3, :] .= [10.0, 9.0]
    states[4, :] .= [8.0, 7.5]
    states[5, :] .= [0.0, 0.4]
    states[6, :] .= 0.0
    states[7, :] .= [0.2, 0.21]
    states[8, :] .= [0.1, 0.11]
    states[9:19, :] .= 0.01
    return states
end

function _reduced_mpcc_seq_test_sequential_result()
    states = _reduced_mpcc_seq_test_states()
    return SimulationResult(
        [0.0, 0.25],
        states;
        metadata = Dict{String, Any}(
            "model_id" => "synthetic_reduced_sequential",
            "model_scope" => "reduced",
            "state_names" => copy(REDUCED_MPCC_SEQ_TEST_STATE_NAMES),
            "retcode" => "Success",
            "termination_reason" => "completed_tspan",
            "mode_history" => Symbol[],
            "mass_balance_residuals" => Float64[],
            "max_lower_bound_violations" => Float64[],
            "max_upper_bound_violations" => Float64[],
            "min_state_value" => minimum(states),
            "has_negative_saved_states" => false,
            "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
            "carbohydrate_derivative_policy" => "empirical_not_r_4048",
            "reconstruct_fluxes" => false,
        ),
    )
end

function _reduced_mpcc_seq_test_trajectory_candidate(; biomass_offset::Float64 = 0.05)
    boundary_states = _reduced_mpcc_seq_test_states()
    boundary_states[1, 2] += biomass_offset
    boundary_states[3, 2] -= 0.2
    boundary_states[4, 2] -= 0.1
    boundary_states[5, 2] += 0.03

    collocation_states = zeros(19, 3)
    for j in 1:3
        theta = j / 3
        collocation_states[:, j] .= (1.0 - theta) .* boundary_states[:, 1] .+
                                    theta .* boundary_states[:, 2]
    end
    boundary_metadata = Dict{String, Any}(
        "model_id" => "synthetic_reduced_mpcc",
        "model_scope" => "reduced",
        "state_names" => copy(REDUCED_MPCC_SEQ_TEST_STATE_NAMES),
        "retcode" => "ITERATION_LIMIT",
        "termination_reason" => "mpcc_candidate_diagnostic_only_solver_status_blocks_trajectory",
        "is_scientific_simulation" => false,
        "trajectory_candidate_is_scientific_simulation" => false,
    )
    boundary_result = SimulationResult([0.0, 0.25], boundary_states; metadata = boundary_metadata)
    collocation_result = SimulationResult(
        [0.038762756430420556, 0.16123724356957944, 0.25],
        collocation_states;
        metadata = copy(boundary_metadata),
    )
    candidate_metadata = Dict{String, Any}(
        "candidate_solver_status" => "ITERATION_LIMIT",
        "candidate_primal_status" => "FEASIBLE_POINT",
        "candidate_residual_feasible" => true,
        "candidate_iteration_limit_residual_feasible" => true,
        "candidate_warning_count" => 2,
        "trajectory_candidate_ready" => false,
        "trajectory_candidate_is_scientific_simulation" => false,
        "trajectory_candidate_is_validated_simulation" => false,
        "trajectory_candidate_solved_trajectory_claimed" => false,
    )
    candidate = ReducedDCDFBAMPCCCandidateDiagnostics(
        copy(boundary_states),
        reshape(copy(collocation_states), 19, 1, 3),
        zeros(19, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(2, 1, 3),
        zeros(1, 1, 3),
        Dict{String, Float64}(
            "max_rhs_residual" => 1.0e-12,
            "max_mass_balance_residual" => 1.0e-7,
            "max_lower_bound_violation" => 0.0,
            "max_upper_bound_violation" => 0.0,
            "max_stationarity_residual" => 1.0e-8,
            "max_lower_complementarity_residual" => 1.0e-7,
            "max_upper_complementarity_residual" => 1.0e-7,
        ),
        Dict{String, Float64}(),
        Dict{String, Float64}(),
        String[],
        ["candidate_solver_status_blocks_trajectory_extraction"],
        copy(candidate_metadata),
    )
    trajectory_metadata = copy(candidate_metadata)
    trajectory_metadata["model_scope"] = "reduced"
    trajectory_metadata["trajectory_candidate_ready"] = false
    trajectory_metadata["trajectory_candidate_is_scientific_simulation"] = false
    trajectory_metadata["trajectory_candidate_is_validated_simulation"] = false
    trajectory_metadata["trajectory_candidate_solved_trajectory_claimed"] = false
    return ReducedDCDFBAMPCCTrajectoryCandidate(
        boundary_result,
        collocation_result,
        candidate,
        trajectory_metadata,
    )
end

function _reduced_mpcc_seq_state_row(table, state_name::AbstractString)
    row_index = findfirst(==(String(state_name)), String.(table[!, "state_name"]))
    row_index === nothing && error("Missing reduced MPCC sequential state row $(String(state_name)).")
    return table[row_index, :]
end

@testset "Reduced MPCC candidate vs sequential comparison synthetic" begin
    sequential = _reduced_mpcc_seq_test_sequential_result()
    trajectory = _reduced_mpcc_seq_test_trajectory_candidate()
    comparison = compare_reduced_dcdfba_mpcc_to_sequential(sequential, trajectory)

    @test comparison isa ReducedDCDFBAMPCCSequentialComparisonResult
    @test comparison.sequential_result === sequential
    @test comparison.trajectory_candidate === trajectory
    @test size(comparison.summary_table, 1) == 2
    @test size(comparison.state_metrics_table, 1) == 20
    @test size(comparison.aligned_timeseries_table, 1) == 2
    @test comparison.summary_table[1, "source"] == "reduced_sequential_dfba"
    @test comparison.summary_table[2, "source"] == "reduced_mpcc_trajectory_candidate"
    @test comparison.summary_table[1, "is_scientific_baseline"] == false
    @test comparison.summary_table[2, "is_scientific_simulation"] == false
    @test comparison.summary_table[2, "trajectory_candidate_ready"] == false
    @test comparison.summary_table[2, "candidate_residual_feasible"] == true
    @test comparison.summary_table[2, "solver_status"] == "ITERATION_LIMIT"

    biomass = _reduced_mpcc_seq_state_row(comparison.state_metrics_table, "biomass")
    @test isapprox(biomass["final_difference_mpcc_minus_sequential"], 0.05; atol = 1.0e-12)
    @test isapprox(biomass["max_abs_difference"], 0.05; atol = 1.0e-12)
    @test isapprox(biomass["rmse"], sqrt(0.05^2 / 2); atol = 1.0e-12)

    total_sugar = _reduced_mpcc_seq_state_row(comparison.state_metrics_table, "total_sugar")
    @test isapprox(total_sugar["final_difference_mpcc_minus_sequential"], -0.3; atol = 1.0e-12)
    @test occursin("glucose + fructose", total_sugar["notes"])

    oxygen = _reduced_mpcc_seq_state_row(comparison.state_metrics_table, "oxygen")
    @test oxygen["rmse"] == 0.0
    @test occursin("r_1992", oxygen["notes"])

    carbohydrate = _reduced_mpcc_seq_state_row(comparison.state_metrics_table, "carbohydrate")
    @test occursin("not driven by r_4048", carbohydrate["notes"])

    @test "biomass_sequential" in names(comparison.aligned_timeseries_table)
    @test "biomass_mpcc_candidate" in names(comparison.aligned_timeseries_table)
    @test "biomass_difference_mpcc_minus_sequential" in names(comparison.aligned_timeseries_table)
    @test "total_sugar_difference_mpcc_minus_sequential" in names(comparison.aligned_timeseries_table)
    @test isapprox(
        comparison.aligned_timeseries_table[2, "total_sugar_difference_mpcc_minus_sequential"],
        -0.3;
        atol = 1.0e-12,
    )

    metadata = comparison.metadata
    @test metadata["comparison_type"] == "reduced_dcdfba_mpcc_candidate_vs_reduced_sequential_dfba"
    @test metadata["reference_source"] == "reduced_sequential_dfba"
    @test metadata["candidate_source"] == "reduced_mpcc_trajectory_candidate"
    @test metadata["alignment_policy"] == "exact_finite_element_boundary_times"
    @test metadata["reference_is_scientific_baseline"] == false
    @test metadata["scientific_baseline"] == "full_dfba_cold_deferred"
    @test metadata["candidate_is_scientific_simulation"] == false
    @test metadata["candidate_is_validated_simulation"] == false
    @test metadata["candidate_solved_trajectory_claimed"] == false
    @test metadata["candidate_trajectory_ready"] == false
    @test metadata["candidate_residual_feasible"] == true
    @test metadata["candidate_iteration_limit_residual_feasible"] == true
    @test metadata["flux_comparison_included"] == false
    @test metadata["full_dfba_cold_reference_deferred"] == true
    @test metadata["reduced_full_equivalence_claimed"] == false
    @test metadata["persistent_lp_baseline_used"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["n_metric_rows"] == 20
    @test "total_sugar" in metadata["metric_names"]
end

@testset "Reduced MPCC candidate vs sequential comparison validation" begin
    sequential = _reduced_mpcc_seq_test_sequential_result()
    trajectory = _reduced_mpcc_seq_test_trajectory_candidate()
    shifted = SimulationResult(
        [0.0, 0.5],
        sequential.states;
        metadata = copy(sequential.metadata),
    )
    @test_throws ArgumentError compare_reduced_dcdfba_mpcc_to_sequential(shifted, trajectory)
    @test_throws ArgumentError compare_reduced_dcdfba_mpcc_to_sequential(
        sequential,
        trajectory;
        alignment_policy = "linear_interpolation",
    )
end

@testset "Reduced MPCC candidate vs sequential comparison opt-in solve" begin
    if get(ENV, "FERMENTATIONDFBA_TEST_REDUCED_MPCC_DYNAMIC_SOLVE", "0") == "1"
        project_root = normpath(joinpath(@__DIR__, ".."))
        model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
        reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
        comparison = compare_reduced_dcdfba_mpcc_to_sequential(
            model,
            reaction_map;
            tspan = (0.0, 0.25),
            nfe = 1,
            degree = 3,
        )

        @test comparison isa ReducedDCDFBAMPCCSequentialComparisonResult
        @test comparison.metadata["candidate_residual_feasible"] == true
        @test comparison.metadata["candidate_is_scientific_simulation"] == false
        @test comparison.metadata["full_dfba_cold_reference_deferred"] == true
        @test size(comparison.state_metrics_table, 1) == 20
    else
        @info "Skipping reduced MPCC vs sequential opt-in solve; set FERMENTATIONDFBA_TEST_REDUCED_MPCC_DYNAMIC_SOLVE=1 to run it."
        @test true
    end
end
