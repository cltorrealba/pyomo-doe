@testset "Mass balance checks" begin
    model = MetabolicModel(
        [1.0 -1.0; -1.0 1.0],
        [0.0, 0.0],
        [10.0, 10.0],
        ["r_in", "r_out"],
        ["met_a", "met_b"];
        model_id = "toy",
    )

    @test check_mass_balance(model, [2.0, 2.0]) == 0.0
    @test is_mass_balanced(model, [2.0, 2.0])
    @test check_mass_balance(model, [2.0, 1.0]) == 1.0
    @test !is_mass_balanced(model, [2.0, 1.0])
end
