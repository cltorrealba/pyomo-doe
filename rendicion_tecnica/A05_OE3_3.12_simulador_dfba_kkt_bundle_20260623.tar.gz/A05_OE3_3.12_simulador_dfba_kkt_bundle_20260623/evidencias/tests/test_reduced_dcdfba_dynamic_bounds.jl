import JuMP
import MathOptInterface as MOI

function _reduced_dcdfba_dynamic_bounds_test_model_and_map()
    project_root = normpath(joinpath(@__DIR__, ".."))
    model = load_reduced_model(joinpath(project_root, "config", "reduced_model_paths.example.toml"))
    reaction_map = load_reaction_map(joinpath(project_root, "config", "reaction_map_reduced.example.toml"))
    return model, reaction_map
end

function _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    return build_reduced_dcdfba_collocation_nlp(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
    )
end

@testset "Reduced DC-dFBA dynamic bounds scaffold contract" begin
    model, reaction_map = _reduced_dcdfba_dynamic_bounds_test_model_and_map()
    nlp = _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    dynamic_bounds = build_reduced_dcdfba_dynamic_bounds(nlp)

    @test dynamic_bounds isa ReducedDCDFBADynamicBoundsScaffold
    @test dynamic_bounds.nlp === nlp
    @test dynamic_bounds.layout isa ReducedDCDFBADynamicBoundsLayout
    @test dynamic_bounds.mode == :growth
    @test dynamic_bounds.layout.n_reactions == 1488
    @test dynamic_bounds.layout.nfe == 1
    @test dynamic_bounds.layout.collocation_degree == 3
    @test dynamic_bounds.layout.n_collocation_points == 3
    @test dynamic_bounds.layout.n_lower_bound_reactions == 22
    @test dynamic_bounds.layout.n_upper_bound_reactions == 1
    @test dynamic_bounds.layout.n_objective_reactions == 6
    @test dynamic_bounds.layout.n_lower_bound_expressions == 22 * 3
    @test dynamic_bounds.layout.n_upper_bound_expressions == 3
    @test dynamic_bounds.layout.n_objective_coefficients == 1488
    @test length(dynamic_bounds.lower_bound_expressions) == 22 * 3
    @test length(dynamic_bounds.upper_bound_expressions) == 3
    @test length(dynamic_bounds.objective_coefficients) == 1488
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA dynamic bounds reaction policy" begin
    model, reaction_map = _reduced_dcdfba_dynamic_bounds_test_model_and_map()
    nlp = _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    dynamic_bounds = build_reduced_dcdfba_dynamic_bounds(nlp)
    metadata = dynamic_bounds.metadata

    lower_ids = Set(metadata["dynamic_lower_bound_reaction_ids"])
    upper_ids = Set(metadata["dynamic_upper_bound_reaction_ids"])
    objective_ids = Set(metadata["dynamic_objective_reaction_ids"])

    @test reaction_map.core["glucose_exchange"] in lower_ids
    @test reaction_map.core["fructose_exchange"] in lower_ids
    @test reaction_map.core["ethanol_exchange"] in upper_ids
    @test reaction_map.core["biomass_growth"] in objective_ids
    @test all(rxn_id -> rxn_id in lower_ids, values(reaction_map.nitrogen_sources))
    @test all(rxn_id -> rxn_id in lower_ids, values(reaction_map.amino_acids))
    @test all(rxn_id -> rxn_id in lower_ids, values(reaction_map.aromas))
    @test all(rxn_id -> rxn_id in objective_ids, values(reaction_map.amino_acids))
    @test !(reaction_map.core["carbohydrate_exchange"] in lower_ids)
    @test !(reaction_map.core["carbohydrate_exchange"] in upper_ids)
    @test !("r_1992" in lower_ids)
    @test !("r_1992" in upper_ids)
    @test !("r_0001" in lower_ids)
    @test !("r_0001" in upper_ids)
    @test metadata["dynamic_flux_bound_policy"] == "smooth_growth_mode_positive_domain_no_max"
    @test metadata["oxygen_exchange_bound_updated"] == false
    @test metadata["carbohydrate_exchange_bound_updated"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["r0001_used_as_oxygen"] == false

    biomass_index = reaction_index(model, reaction_map.core["biomass_growth"])
    @test dynamic_bounds.objective_coefficients[biomass_index] == -1.0
    for rxn_id in values(reaction_map.amino_acids)
        @test dynamic_bounds.objective_coefficients[reaction_index(model, rxn_id)] == 1.0
    end
    @test count(x -> !iszero(x), dynamic_bounds.objective_coefficients) == 6
end

@testset "Reduced DC-dFBA dynamic bounds in KKT rows" begin
    model, reaction_map = _reduced_dcdfba_dynamic_bounds_test_model_and_map()
    nlp = _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    dynamic_bounds = build_reduced_dcdfba_dynamic_bounds(nlp)
    primal = add_reduced_dcdfba_primal_feasibility!(nlp)
    bound = add_reduced_dcdfba_bound_feasibility!(nlp; dynamic_bounds = dynamic_bounds)
    stationarity = add_reduced_dcdfba_stationarity!(
        nlp,
        bound;
        objective_coefficients = dynamic_bounds.objective_coefficients,
    )
    complementarity = add_reduced_dcdfba_complementarity!(nlp, stationarity)

    @test primal.layout.total_primal_feasibility_constraints == 1079 * 3
    @test bound.dynamic_bounds === dynamic_bounds
    @test bound.metadata["dynamic_flux_bounds_applied"] == true
    @test bound.metadata["dynamic_flux_bound_mode"] == "growth"
    @test stationarity.metadata["dynamic_flux_bounds_applied"] == true
    @test stationarity.metadata["stationarity_nonzero_objective_coefficients"] == 6
    @test complementarity.metadata["dynamic_flux_bounds_applied"] == true
    @test complementarity.metadata["lower_bound_complementarity_form"] ==
          "(v - lb_dynamic_or_base) * alpha_L = 0"
    @test complementarity.metadata["upper_bound_complementarity_form"] ==
          "(v - ub_dynamic_or_base) * alpha_U = 0"
    @test complementarity.metadata["mpcc_formulation_scope"] ==
          "reduced_fba_dynamic_growth_bounds_at_collocation_points"
    @test nlp.metadata["dynamic_flux_bounds_applied"] == true
    @test nlp.metadata["mpcc_complementarity_built"] == true
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED

    carbohydrate_index = reaction_index(model, reaction_map.core["carbohydrate_exchange"])
    lower_constraint = bound.lower_bound_constraints[carbohydrate_index, 1, 1]
    upper_constraint = bound.upper_bound_constraints[carbohydrate_index, 1, 1]
    @test JuMP.normalized_coefficient(lower_constraint, nlp.flux[carbohydrate_index, 1, 1]) == -1.0
    @test JuMP.normalized_rhs(lower_constraint) == -model.lb[carbohydrate_index]
    @test JuMP.normalized_coefficient(upper_constraint, nlp.flux[carbohydrate_index, 1, 1]) == 1.0
    @test JuMP.normalized_rhs(upper_constraint) == model.ub[carbohydrate_index]
end

@testset "Reduced DC-dFBA smooth phase dynamic bounds" begin
    model, reaction_map = _reduced_dcdfba_dynamic_bounds_test_model_and_map()
    nlp = _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    dynamic_bounds = build_reduced_dcdfba_dynamic_bounds(
        nlp;
        mode = :smooth_phase,
        phase_smoothing_width = 2.0e-4,
    )
    metadata = dynamic_bounds.metadata

    @test dynamic_bounds.mode == :smooth_phase
    @test metadata["dynamic_flux_bound_policy"] ==
          "smooth_phase_growth_turnover_total_molecular_weight_logistic"
    @test metadata["turnover_mode_deferred"] == false
    @test metadata["smooth_turnover_mode_embedded"] == true
    @test metadata["dynamic_phase_smoothing_width"] == 2.0e-4
    @test metadata["dynamic_phase_proxy_mode"] == "total_molecular_weight"
    @test metadata["dynamic_phase_proxy_definition"] ==
          "N_free + sum(amino_acids * amino_acid_molecular_weights)"
    @test metadata["dynamic_objective_expression_count"] == 8 * 3

    lower_ids = Set(metadata["dynamic_lower_bound_reaction_ids"])
    upper_ids = Set(metadata["dynamic_upper_bound_reaction_ids"])
    objective_ids = Set(metadata["dynamic_objective_reaction_ids"])

    @test reaction_map.core["atp_maintenance"] in lower_ids
    @test reaction_map.core["atp_maintenance"] in upper_ids
    @test reaction_map.core["biomass_growth"] in upper_ids
    @test reaction_map.core["biomass_growth"] in objective_ids
    @test reaction_map.core["atp_maintenance"] in objective_ids
    @test reaction_map.core["protein_exchange"] in objective_ids
    @test all(rxn_id -> rxn_id in objective_ids, values(reaction_map.amino_acids))
    @test count(!iszero, dynamic_bounds.objective_coefficients) == 0
    @test length(dynamic_bounds.objective_coefficient_expressions) == 8 * 3

    primal = add_reduced_dcdfba_primal_feasibility!(nlp)
    bound = add_reduced_dcdfba_bound_feasibility!(nlp; dynamic_bounds = dynamic_bounds)
    stationarity = add_reduced_dcdfba_stationarity!(
        nlp,
        bound;
        objective_coefficients = dynamic_bounds.objective_coefficients,
        objective_coefficient_expressions = dynamic_bounds.objective_coefficient_expressions,
    )
    complementarity = add_reduced_dcdfba_complementarity!(nlp, stationarity)

    @test primal.layout.total_primal_feasibility_constraints == 1079 * 3
    @test bound.metadata["dynamic_flux_bound_mode"] == "smooth_phase"
    @test stationarity.metadata["dynamic_flux_bound_mode"] == "smooth_phase"
    @test stationarity.metadata["stationarity_nonzero_objective_coefficients"] == 0
    @test stationarity.metadata["stationarity_objective_expression_count"] == 8 * 3
    @test complementarity.metadata["dynamic_flux_bounds_applied"] == true
    @test JuMP.termination_status(nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA smooth phase proxy modes" begin
    model, reaction_map = _reduced_dcdfba_dynamic_bounds_test_model_and_map()

    free_nlp = _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    free_bounds = build_reduced_dcdfba_dynamic_bounds(
        free_nlp;
        mode = :smooth_phase,
        phase_proxy_mode = :free_nitrogen,
    )
    @test free_bounds.metadata["dynamic_phase_proxy_mode"] == "free_nitrogen"
    @test free_bounds.metadata["dynamic_phase_proxy_definition"] == "N_free"
    @test free_bounds.metadata["dynamic_flux_bound_policy"] ==
          "smooth_phase_growth_turnover_free_nitrogen_logistic"

    equivalent_nlp = _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    equivalent_bounds = build_reduced_dcdfba_dynamic_bounds(
        equivalent_nlp;
        mode = :smooth_phase,
        phase_proxy_mode = :nitrogen_equivalent,
    )
    @test equivalent_bounds.metadata["dynamic_phase_proxy_mode"] == "nitrogen_equivalent"
    @test equivalent_bounds.metadata["dynamic_phase_proxy_definition"] ==
          "N_free + sum(amino_acids * MW_N)"
    @test equivalent_bounds.metadata["dynamic_flux_bound_policy"] ==
          "smooth_phase_growth_turnover_nitrogen_equivalent_logistic"

    invalid_nlp = _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    @test_throws ArgumentError build_reduced_dcdfba_dynamic_bounds(
        invalid_nlp;
        mode = :smooth_phase,
        phase_proxy_mode = :bad_proxy,
    )
end

@testset "Reduced DC-dFBA dynamic bounds smoke integration" begin
    model, reaction_map = _reduced_dcdfba_dynamic_bounds_test_model_and_map()
    problem = build_reduced_dcdfba_mpcc_smoke_problem(model, reaction_map; use_dynamic_bounds = true)

    @test problem.dynamic_bounds isa ReducedDCDFBADynamicBoundsScaffold
    @test problem.bound_feasibility.dynamic_bounds === problem.dynamic_bounds
    @test problem.metadata["dynamic_flux_bounds_applied"] == true
    @test problem.metadata["dynamic_flux_bound_mode"] == "growth"
    @test problem.metadata["dynamic_objective_coefficients_applied"] == true
    @test problem.metadata["solver_call_performed"] == false
    @test problem.metadata["smoke_result_is_scientific_simulation"] == false
    @test problem.stationarity.objective_coefficients == problem.dynamic_bounds.objective_coefficients
    @test problem.complementarity.layout.n_total_complementarity_constraints == 2 * 1488 * 3
    @test JuMP.termination_status(problem.nlp.jump_model) == MOI.OPTIMIZE_NOT_CALLED
end

@testset "Reduced DC-dFBA MPCC fixed dynamic-control schedule" begin
    model, reaction_map = _reduced_dcdfba_dynamic_bounds_test_model_and_map()
    schedule = reference_dynamic_control_schedule(
        horizon_h = 0.25,
        control_interval_h = 0.125,
        temperature_values_C = [18.0, 25.0],
        fda_doses_g_L = [0.5],
        organic_doses_g_L = [0.1],
        addition_transition_width_h = 0.5,
    )
    problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
        include_rhs = true,
        use_dynamic_bounds = true,
        dynamic_control_schedule = schedule,
    )
    static_problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        nfe = 1,
        include_rhs = true,
        use_dynamic_bounds = true,
    )

    @test problem.dynamic_control_schedule === schedule
    @test problem.metadata["dynamic_control_schedule_enabled"] == true
    @test problem.metadata["mpcc_dynamic_control_schedule_argument_provided"] == true
    @test problem.metadata["mpcc_dynamic_control_applied_to_rhs"] == true
    @test problem.metadata["mpcc_dynamic_control_applied_to_dynamic_bounds"] == true
    @test problem.metadata["mpcc_fixed_control_replay_ready"] == true
    @test problem.dynamic_bounds.metadata["dynamic_flux_bounds_temperature_policy"] ==
          "fixed_dynamic_control_schedule_temperature_at_collocation_points"
    @test problem.rhs_residuals.metadata["rhs_residual_dynamic_control_policy"] ==
          "fixed_dynamic_control_schedule_temperature_nutrient_and_volatilization_rhs_rates"

    state_values = Float64.(JuMP.start_value.(problem.nlp.state_collocation))
    flux_values = Float64.(JuMP.start_value.(problem.nlp.flux))
    static_state_values = Float64.(JuMP.start_value.(static_problem.nlp.state_collocation))
    glucose_index = reaction_index(model, reaction_map.core["glucose_exchange"])

    dynamic_bounds =
        FermentationDFBA._reduced_dcdfba_numeric_flux_bounds(problem, 1, 1, state_values)
    static_bounds =
        FermentationDFBA._reduced_dcdfba_numeric_flux_bounds(static_problem, 1, 1, static_state_values)
    @test !isapprox(
        dynamic_bounds.lb[glucose_index],
        static_bounds.lb[glucose_index];
        atol = 0.0,
        rtol = 1.0e-8,
    )

    dynamic_expected =
        FermentationDFBA._reduced_dcdfba_mpcc_rhs_expected_vector(problem, state_values, flux_values, 1, 1)
    static_expected = FermentationDFBA._reduced_dcdfba_mpcc_rhs_expected_vector(
        static_problem,
        state_values,
        flux_values,
        1,
        1,
    )
    params = FermentationDFBA._reduced_dcdfba_mpcc_effective_params(problem, 1, 1)
    time_h = FermentationDFBA._reduced_dcdfba_mpcc_collocation_time(problem.nlp, 1, 1)
    rhs_terms = FermentationDFBA._reduced_dcdfba_mpcc_dynamic_control_rhs_terms(
        schedule,
        params,
        state_values[:, 1, 1],
        time_h,
    )

    @test rhs_terms.free_nitrogen_rate_gN_L_h > 0.0
    @test sum(rhs_terms.amino_acid_state_rates_per_h) > 0.0
    @test isapprox(
        dynamic_expected[2] - static_expected[2],
        rhs_terms.free_nitrogen_rate_gN_L_h;
        atol = 1.0e-12,
        rtol = 1.0e-10,
    )
    for k in 1:5
        @test isapprox(
            dynamic_expected[8 + k] - static_expected[8 + k],
            rhs_terms.amino_acid_state_rates_per_h[k];
            atol = 1.0e-12,
            rtol = 1.0e-10,
        )
    end
end

@testset "Reduced DC-dFBA dynamic bounds validation" begin
    model, reaction_map = _reduced_dcdfba_dynamic_bounds_test_model_and_map()
    nlp = _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    @test_throws ArgumentError build_reduced_dcdfba_dynamic_bounds(nlp; mode = :turnover)

    dynamic_bounds = build_reduced_dcdfba_dynamic_bounds(nlp)
    @test_throws ArgumentError build_reduced_dcdfba_dynamic_bounds(nlp)

    other_nlp = _reduced_dcdfba_dynamic_bounds_test_nlp(model, reaction_map)
    @test_throws ArgumentError add_reduced_dcdfba_bound_feasibility!(
        other_nlp;
        dynamic_bounds = dynamic_bounds,
    )
end
