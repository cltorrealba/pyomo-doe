import CSV
import TOML
using DataFrames

const EXPORT_STATE_NAMES = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

function _synthetic_export_states()
    states = zeros(19, 3)
    states[1, :] .= [1.0, 1.5, 2.0]
    states[2, :] .= [0.1, 0.05, 0.0]
    states[3, :] .= [10.0, 5.0, 0.0]
    states[4, :] .= [8.0, 4.0, 0.0]
    states[5, :] .= [0.0, 2.0, 5.0]
    states[6, :] .= [0.0, 0.0, 0.0]
    states[7, :] .= [0.2, 0.25, 0.3]
    states[8, :] .= [0.1, 0.15, 0.2]
    states[9:13, :] .= 0.5
    states[14:19, :] .= 0.01
    return states
end

function _synthetic_export_metadata()
    return Dict{String, Any}(
        "model_id" => "synthetic_export_model",
        "model_scope" => "reduced",
        "state_names" => copy(EXPORT_STATE_NAMES),
        "flux_rxn_ids" => ["r_2111", "r_4048"],
        "mode_history" => [:growth, :turnover, :sugar_depleted],
        "rhs_status_history" => ["OPTIMAL", "OPTIMAL", "NOT_EVALUATED_SUGAR_DEPLETION"],
        "mass_balance_residuals" => [1.0e-10, 2.0e-10, 3.0e-10],
        "max_lower_bound_violations" => [0.0, 1.0e-11, 2.0e-11],
        "max_upper_bound_violations" => [0.0, 3.0e-11, 4.0e-11],
        "retcode" => "Success",
        "termination_reason" => "completed_tspan",
        "termination_time" => 2.0,
        "algorithm" => "SyntheticAlgorithm",
        "tspan" => (0.0, 2.0),
        "saveat" => 1.0,
        "min_state_value" => 0.0,
        "has_negative_saved_states" => false,
        "negative_state_locations" => Tuple{Int, Int}[],
        "oxygen_derivative_policy" => "forced_zero_absent_r_1992",
        "carbohydrate_derivative_policy" => "empirical_not_r_4048",
        "sugar_depletion_tol" => 1.0e-6,
        "simulation_elapsed_seconds" => 1.0,
        "ode_solve_elapsed_seconds" => 0.75,
        "rhs_elapsed_seconds" => 0.5,
        "history_reconstruction_elapsed_seconds" => 0.25,
        "rhs_call_count" => 4,
        "rhs_lp_solve_count" => 4,
        "flux_reconstruction_solve_count" => 3,
        "total_lp_solve_count" => 7,
        "reconstruct_fluxes" => true,
    )
end

function _synthetic_export_result(;
    fluxes = [0.1 0.2 0.3; 1.0 1.1 1.2],
    alphas = nothing,
    metadata = _synthetic_export_metadata(),
)
    return SimulationResult(
        [0.0, 1.0, 2.0],
        _synthetic_export_states();
        fluxes = fluxes,
        alphas = alphas,
        metadata = metadata,
    )
end

function _load_reduced_export_inputs()
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    reaction_report = validate_reaction_map(model, reaction_map)
    @test reaction_report.ok

    return model, reaction_map
end

@testset "Simulation result export table creation synthetic result" begin
    result = _synthetic_export_result()

    summary = simulation_summary_table(result; model_id = "synthetic_override", elapsed_seconds = 1.25)
    states = simulation_states_table(result)
    fluxes = simulation_fluxes_table(result)
    alphas = simulation_alphas_table(result)
    diagnostics = simulation_diagnostics_table(result)

    @test nrow(summary) == 1
    @test summary[1, "model_id"] == "synthetic_override"
    @test summary[1, "model_scope"] == "reduced"
    @test summary[1, "elapsed_seconds"] == 1.25
    @test summary[1, "simulation_elapsed_seconds"] == 1.0
    @test summary[1, "rhs_call_count"] == 4
    @test summary[1, "flux_reconstruction_solve_count"] == 3
    @test summary[1, "total_lp_solve_count"] == 7
    @test summary[1, "reconstruct_fluxes"] == true
    @test summary[1, "n_alphas"] == 0
    @test ismissing(summary[1, "alpha_scope"])
    @test summary[1, "mode_count_growth"] == 1
    @test summary[1, "mode_count_turnover"] == 1
    @test summary[1, "mode_count_sugar_depleted"] == 1
    @test all(
        name -> name in names(summary),
        (
            "model_id",
            "model_scope",
            "retcode",
            "final_biomass",
            "oxygen_derivative_policy",
            "simulation_elapsed_seconds",
            "rhs_call_count",
            "total_lp_solve_count",
            "reconstruct_fluxes",
        ),
    )

    @test nrow(states) == length(result.time)
    @test all(name -> name in names(states), ("time", "biomass", "oxygen", "ethyl_acetate"))
    @test nrow(fluxes) == length(result.time)
    @test all(name -> name in names(fluxes), ("time", "r_2111", "r_4048"))
    @test alphas === nothing
    @test nrow(diagnostics) == length(result.time)
    @test diagnostics[!, "mode"] == ["growth", "turnover", "sugar_depleted"]
    @test diagnostics[!, "rhs_status"] == ["OPTIMAL", "OPTIMAL", "NOT_EVALUATED_SUGAR_DEPLETION"]
end

@testset "Simulation result export alpha table creation synthetic result" begin
    metadata = _synthetic_export_metadata()
    metadata["alpha_ids"] = ["alpha_a", "alpha_b"]
    metadata["alpha_scope"] = "active"
    metadata["alpha_source"] = "synthetic"
    metadata["n_alphas"] = 2
    result = _synthetic_export_result(; fluxes = nothing, alphas = [0.1 0.2 0.3; 1.0 1.1 1.2], metadata = metadata)

    summary = simulation_summary_table(result)
    alphas = simulation_alphas_table(result)

    @test summary[1, "n_alphas"] == 2
    @test summary[1, "alpha_scope"] == "active"
    @test nrow(alphas) == length(result.time)
    @test names(alphas) == ["time", "alpha_a", "alpha_b"]
    @test alphas[!, "alpha_a"] == [0.1, 0.2, 0.3]
    @test_throws ErrorException simulation_alphas_table(
        _synthetic_export_result(;
            fluxes = nothing,
            alphas = zeros(2, 3),
            metadata = merge(metadata, Dict{String, Any}("alpha_ids" => ["alpha_a"])),
        ),
    )

    fallback = _synthetic_export_result(; fluxes = nothing, alphas = zeros(2, 3), metadata = Dict{String, Any}())
    fallback_alphas = simulation_alphas_table(fallback)
    @test names(fallback_alphas) == ["time", "alpha_1", "alpha_2"]
end

@testset "Simulation result export handles missing fluxes" begin
    result = _synthetic_export_result(; fluxes = nothing, metadata = Dict{String, Any}())

    @test simulation_fluxes_table(result) === nothing
    @test simulation_alphas_table(result) === nothing
    diagnostics = simulation_diagnostics_table(result)
    @test nrow(diagnostics) == length(result.time)
    @test all(ismissing, diagnostics[!, "mode"])

    mktempdir() do dir
        paths = export_simulation_result(result, dir)
        @test !haskey(paths, "fluxes")
        @test !haskey(paths, "alphas")
        @test !isfile(joinpath(dir, "fluxes.csv"))
        @test !isfile(joinpath(dir, "alphas.csv"))
        @test isfile(paths["summary"])
        @test isfile(paths["states"])
        @test isfile(paths["diagnostics"])
        @test isfile(paths["metadata"])
    end
end

@testset "Simulation result export writes temporary report files" begin
    result = _synthetic_export_result()

    mktempdir() do dir
        paths = export_simulation_result(result, dir; model_id = "synthetic_export", elapsed_seconds = 2.5)

        for key in ("summary", "states", "fluxes", "diagnostics", "metadata")
            @test haskey(paths, key)
            @test isfile(paths[key])
        end

        summary = DataFrame(CSV.File(paths["summary"]))
        states = DataFrame(CSV.File(paths["states"]))
        fluxes = DataFrame(CSV.File(paths["fluxes"]))
        diagnostics = DataFrame(CSV.File(paths["diagnostics"]))
        metadata = TOML.parsefile(paths["metadata"])

        @test nrow(summary) == 1
        @test summary[1, "model_id"] == "synthetic_export"
        @test summary[1, "model_scope"] == "reduced"
        @test nrow(states) == length(result.time)
        @test "glucose" in names(states)
        @test nrow(fluxes) == length(result.time)
        @test "r_2111" in names(fluxes)
        @test nrow(diagnostics) == length(result.time)
        @test diagnostics[!, "mode"] == ["growth", "turnover", "sugar_depleted"]
        @test metadata["mode_history"] == ["growth", "turnover", "sugar_depleted"]
        @test metadata["tspan"] == [0.0, 2.0]
        @test metadata["elapsed_seconds"] == 2.5
        @test metadata["model_scope"] == "reduced"
        @test metadata["rhs_call_count"] == 4
        @test metadata["total_lp_solve_count"] == 7
        @test metadata["reconstruct_fluxes"] == true
    end
end

@testset "Simulation result export overwrite behavior" begin
    result = _synthetic_export_result()

    mktempdir() do dir
        first_paths = export_simulation_result(result, dir)
        @test isfile(first_paths["summary"])
        @test_throws ErrorException export_simulation_result(result, dir)

        second_paths = export_simulation_result(result, dir; overwrite = true)
        @test isfile(second_paths["summary"])
        @test isfile(second_paths["metadata"])
    end
end

@testset "Simulation result export removes stale flux file on overwrite" begin
    with_fluxes = _synthetic_export_result()
    without_fluxes = _synthetic_export_result(; fluxes = nothing)

    mktempdir() do dir
        unrelated_path = joinpath(dir, "unrelated.txt")
        open(unrelated_path, "w") do io
            write(io, "keep")
        end

        first_paths = export_simulation_result(with_fluxes, dir; overwrite = true)
        @test isfile(first_paths["fluxes"])
        @test isfile(unrelated_path)

        second_paths = export_simulation_result(without_fluxes, dir; overwrite = true)
        @test !haskey(second_paths, "fluxes")
        @test !isfile(joinpath(dir, "fluxes.csv"))
        @test isfile(second_paths["summary"])
        @test isfile(second_paths["metadata"])
        @test isfile(unrelated_path)
    end
end

@testset "Simulation result export removes stale alpha file on overwrite" begin
    metadata = _synthetic_export_metadata()
    metadata["alpha_ids"] = ["alpha_a", "alpha_b"]
    metadata["alpha_scope"] = "active"
    metadata["alpha_source"] = "synthetic"
    metadata["n_alphas"] = 2
    with_alphas = _synthetic_export_result(; fluxes = nothing, alphas = zeros(2, 3), metadata = metadata)
    without_alphas = _synthetic_export_result(; fluxes = nothing, metadata = Dict{String, Any}())

    mktempdir() do dir
        first_paths = export_simulation_result(with_alphas, dir; overwrite = true)
        @test isfile(first_paths["alphas"])

        second_paths = export_simulation_result(without_alphas, dir; overwrite = true)
        @test !haskey(second_paths, "alphas")
        @test !isfile(joinpath(dir, "alphas.csv"))
        @test isfile(second_paths["summary"])
        @test isfile(second_paths["metadata"])
    end
end

@testset "Simulation result export real short simulation" begin
    model, reaction_map = _load_reduced_export_inputs()
    result = simulate_reduced_dfba(model, reaction_map; tspan = (0.0, 1.0), saveat = 1.0)

    mktempdir() do dir
        paths = export_simulation_result(result, dir; model_id = model.model_id)

        @test isfile(paths["summary"])
        @test isfile(paths["states"])
        @test isfile(paths["fluxes"])
        @test isfile(paths["diagnostics"])
        @test isfile(paths["metadata"])

        summary = DataFrame(CSV.File(paths["summary"]))
        states = DataFrame(CSV.File(paths["states"]))
        fluxes = DataFrame(CSV.File(paths["fluxes"]))
        metadata = TOML.parsefile(paths["metadata"])

        @test String(summary[1, "oxygen_derivative_policy"]) == "forced_zero_absent_r_1992"
        @test String(summary[1, "model_scope"]) == "reduced"
        @test String(summary[1, "carbohydrate_derivative_policy"]) == "empirical_not_r_4048"
        @test summary[1, "elapsed_seconds"] == summary[1, "simulation_elapsed_seconds"]
        @test all(
            name -> name in names(summary),
            (
                "simulation_elapsed_seconds",
                "ode_solve_elapsed_seconds",
                "rhs_elapsed_seconds",
                "history_reconstruction_elapsed_seconds",
                "rhs_call_count",
                "rhs_lp_solve_count",
                "flux_reconstruction_solve_count",
                "total_lp_solve_count",
                "reconstruct_fluxes",
            ),
        )
        @test haskey(metadata, "simulation_elapsed_seconds")
        @test haskey(metadata, "ode_solve_elapsed_seconds")
        @test haskey(metadata, "rhs_elapsed_seconds")
        @test haskey(metadata, "history_reconstruction_elapsed_seconds")
        @test haskey(metadata, "rhs_call_count")
        @test haskey(metadata, "rhs_lp_solve_count")
        @test haskey(metadata, "flux_reconstruction_solve_count")
        @test haskey(metadata, "total_lp_solve_count")
        @test haskey(metadata, "reconstruct_fluxes")
        @test "oxygen" in names(states)
        @test !("r_1992" in names(fluxes))
        @test !("r_0001" in names(fluxes))
        @test "r_4048" in names(fluxes)
    end
end

@testset "Simulation result export real no reconstruction omits flux file" begin
    model, reaction_map = _load_reduced_export_inputs()
    result = simulate_reduced_dfba(
        model,
        reaction_map;
        tspan = (0.0, 1.0),
        saveat = 1.0,
        reconstruct_fluxes = false,
    )

    mktempdir() do dir
        paths = export_simulation_result(result, dir; model_id = model.model_id)

        @test result.fluxes === nothing
        @test result.alphas === nothing
        @test !haskey(paths, "fluxes")
        @test !haskey(paths, "alphas")
        @test !isfile(joinpath(dir, "fluxes.csv"))
        @test !isfile(joinpath(dir, "alphas.csv"))

        summary = DataFrame(CSV.File(paths["summary"]))
        diagnostics = DataFrame(CSV.File(paths["diagnostics"]))
        metadata = TOML.parsefile(paths["metadata"])

        @test summary[1, "n_fluxes"] == 0
        @test summary[1, "n_alphas"] == 0
        @test summary[1, "reconstruct_fluxes"] == false
        @test metadata["reconstruct_fluxes"] == false
        @test metadata["flux_reconstruction_solve_count"] == 0
        @test all(ismissing, diagnostics[!, "mode"])
        @test all(ismissing, diagnostics[!, "rhs_status"])
    end
end

@testset "Simulation result export does not mutate result" begin
    result = _synthetic_export_result()
    states_before = copy(result.states)
    fluxes_before = copy(result.fluxes)
    metadata_keys_before = sort(collect(keys(result.metadata)))
    state_names_before = copy(result.metadata["state_names"])
    mode_history_before = copy(result.metadata["mode_history"])
    rhs_status_history_before = copy(result.metadata["rhs_status_history"])

    simulation_summary_table(result)
    simulation_states_table(result)
    simulation_fluxes_table(result)
    simulation_diagnostics_table(result)
    mktempdir() do dir
        export_simulation_result(result, dir)
    end

    @test result.states == states_before
    @test result.fluxes == fluxes_before
    @test sort(collect(keys(result.metadata))) == metadata_keys_before
    @test result.metadata["state_names"] == state_names_before
    @test result.metadata["mode_history"] == mode_history_before
    @test result.metadata["rhs_status_history"] == rhs_status_history_before
end
