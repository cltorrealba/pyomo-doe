import CSV
using DataFrames

const FULL_SIM_DFBA_RUNTIME_KEYS = (
    "simulation_elapsed_seconds",
    "ode_solve_elapsed_seconds",
    "rhs_elapsed_seconds",
    "history_reconstruction_elapsed_seconds",
    "rhs_call_count",
    "rhs_lp_solve_count",
    "flux_reconstruction_solve_count",
    "total_lp_solve_count",
    "reconstruct_fluxes",
    "fba_variant",
    "quadratic_penalty",
    "l1_penalty",
    "lp_reuse",
    "lp_primal_start",
    "lp_basis_warm_start",
    "allow_experimental_lp_reuse",
    "qpfba_persistent_fallback_count",
)
const FULL_SIM_DFBA_CACHE = Ref{Any}(nothing)
const FULL_SIM_DFBA_NO_RECONSTRUCTION_CACHE = Ref{Any}(nothing)

function _load_full_simulation_inputs()
    if FULL_SIM_DFBA_CACHE[] === nothing
        project_root = normpath(joinpath(@__DIR__, ".."))
        paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
        reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")

        model = load_full_model(paths_config)
        reaction_map = load_reaction_map(reaction_map_config)
        reaction_report = validate_reaction_map(model, reaction_map)
        @test reaction_report.ok
        FULL_SIM_DFBA_CACHE[] = (model = model, reaction_map = reaction_map)
    end
    cached = FULL_SIM_DFBA_CACHE[]
    return cached.model, cached.reaction_map
end

function _load_reduced_simulation_regression_inputs()
    project_root = normpath(joinpath(@__DIR__, ".."))
    paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
    reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

    model = load_reduced_model(paths_config)
    reaction_map = load_reaction_map(reaction_map_config)
    reaction_report = validate_reaction_map(model, reaction_map)
    @test reaction_report.ok

    return model, reaction_map
end

function _assert_full_runtime_diagnostics_present(metadata)
    for key in FULL_SIM_DFBA_RUNTIME_KEYS
        @test haskey(metadata, key)
    end
    for key in (
        "simulation_elapsed_seconds",
        "ode_solve_elapsed_seconds",
        "rhs_elapsed_seconds",
        "history_reconstruction_elapsed_seconds",
    )
        @test isfinite(metadata[key])
        @test metadata[key] >= 0.0
    end
    for key in (
        "rhs_call_count",
        "rhs_lp_solve_count",
        "flux_reconstruction_solve_count",
        "total_lp_solve_count",
    )
        @test metadata[key] isa Integer
        @test metadata[key] >= 0
    end
    @test metadata["lp_reuse"] isa Bool
    @test metadata["fba_variant"] isa AbstractString
    @test metadata["quadratic_penalty"] isa Real
    @test metadata["l1_penalty"] isa Real
    @test metadata["lp_primal_start"] isa Bool
    @test metadata["lp_basis_warm_start"] isa Bool
    @test metadata["allow_experimental_lp_reuse"] isa Bool
    @test metadata["qpfba_persistent_fallback_count"] isa Integer
    @test metadata["qpfba_persistent_fallback_count"] >= 0
end

function _full_no_reconstruction_result()
    if FULL_SIM_DFBA_NO_RECONSTRUCTION_CACHE[] === nothing
        model, reaction_map = _load_full_simulation_inputs()
        FULL_SIM_DFBA_NO_RECONSTRUCTION_CACHE[] = simulate_full_dfba(
            model,
            reaction_map;
            tspan = (0.0, 0.25),
            saveat = 0.25,
            reconstruct_fluxes = false,
        )
    end
    return FULL_SIM_DFBA_NO_RECONSTRUCTION_CACHE[]
end

@testset "Sequential full DFBA short ODE simulation without reconstruction" begin
    model, reaction_map = _load_full_simulation_inputs()
    original_lb = copy(model.lb)
    original_ub = copy(model.ub)

    result = _full_no_reconstruction_result()
    metadata = result.metadata

    @test result isa SimulationResult
    @test metadata["model_scope"] == "full"
    @test metadata["retcode"] == "Success"
    @test result.fluxes === nothing
    @test metadata["reconstruct_fluxes"] == false
    @test metadata["oxygen_derivative_policy"] == "forced_zero_present_r_1992_closed_by_bounds"
    @test metadata["oxygen_exchange_reaction_id"] == "r_1992"
    @test metadata["oxygen_exchange_present"] == true
    @test metadata["oxygen_exchange_closed"] == true
    @test isapprox(metadata["oxygen_exchange_lb"], 0.0; atol = 0.0, rtol = 0.0)
    @test isapprox(metadata["oxygen_exchange_ub"], 0.0; atol = 0.0, rtol = 0.0)
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"
    @test all(isapprox(value, 0.0; atol = 1.0e-9) for value in result.states[6, :])
    @test all(isfinite, result.states)
    @test model.lb == original_lb
    @test model.ub == original_ub
    @test metadata["rhs_call_count"] > 0
    @test metadata["rhs_lp_solve_count"] == metadata["rhs_call_count"]
    @test metadata["total_lp_solve_count"] == metadata["rhs_lp_solve_count"]
    _assert_full_runtime_diagnostics_present(metadata)
    @test length(result.time) >= 2
end

@testset "Sequential full DFBA short ODE simulation with reconstruction" begin
    model, reaction_map = _load_full_simulation_inputs()
    result = simulate_full_dfba(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        saveat = 0.25,
        reconstruct_fluxes = true,
    )
    metadata = result.metadata
    flux_rxn_ids = String.(metadata["flux_rxn_ids"])

    @test result.fluxes !== nothing
    @test metadata["model_scope"] == "full"
    @test "r_1992" in flux_rxn_ids
    @test !("r_0001" in flux_rxn_ids)
    oxygen_flux_index = findfirst(==("r_1992"), flux_rxn_ids)
    @test oxygen_flux_index !== nothing
    @test all(isapprox(value, 0.0; atol = 1.0e-7) for value in result.fluxes[oxygen_flux_index, :])
    @test metadata["flux_reconstruction_solve_count"] == length(result.time)
    @test metadata["oxygen_derivative_policy"] == "forced_zero_present_r_1992_closed_by_bounds"
    @test metadata["oxygen_exchange_present"] == true
    @test metadata["oxygen_exchange_closed"] == true
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["indices_reacciones_used"] == false
    @test metadata["carbohydrate_derivative_policy"] == "empirical_not_r_4048"

    fluxes_table = simulation_fluxes_table(result)
    @test fluxes_table !== nothing
    @test "r_1992" in names(fluxes_table)
    @test !("r_0001" in names(fluxes_table))
end

@testset "Sequential full DFBA persistent LP ODE guard" begin
    model, reaction_map = _load_full_simulation_inputs()

    err = try
        simulate_full_dfba(
            model,
            reaction_map;
            tspan = (0.0, 0.05),
            saveat = 0.05,
            reconstruct_fluxes = false,
            lp_reuse = true,
        )
        nothing
    catch err
        err
    end
    @test err isa ErrorException
    @test occursin("experimental", sprint(showerror, err))

    result = simulate_full_dfba(
        model,
        reaction_map;
        tspan = (0.0, 0.05),
        saveat = 0.05,
        reconstruct_fluxes = false,
        lp_reuse = true,
        lp_primal_start = true,
        allow_experimental_lp_reuse = true,
    )
    @test result.metadata["model_scope"] == "full"
    @test result.metadata["lp_reuse"] == true
    @test result.metadata["lp_primal_start"] == true
    @test result.metadata["allow_experimental_lp_reuse"] == true
    @test result.metadata["scientific_output_equivalent"] == false
    @test result.metadata["retcode"] == "Success"
    @test all(isfinite, result.states)
end

@testset "Sequential reduced DFBA short ODE model-scope regression" begin
    model, reaction_map = _load_reduced_simulation_regression_inputs()
    result = simulate_reduced_dfba(
        model,
        reaction_map;
        tspan = (0.0, 0.25),
        saveat = 0.25,
        reconstruct_fluxes = false,
    )
    metadata = result.metadata

    @test metadata["model_scope"] == "reduced"
    @test metadata["oxygen_derivative_policy"] == "forced_zero_absent_r_1992"
    @test metadata["oxygen_exchange_reaction_id"] == "r_1992"
    @test metadata["oxygen_exchange_present"] == false
    @test ismissing(metadata["oxygen_exchange_closed"])
    @test metadata["r0001_used_as_oxygen"] == false
    @test metadata["indices_reacciones_used"] == false
    @test result.fluxes === nothing
end

@testset "Sequential full DFBA short ODE summary and export compatibility" begin
    result = _full_no_reconstruction_result()

    summary = summarize_simulation(result)
    @test summary["model_scope"] == "full"

    summary_table = simulation_summary_table(result)
    @test "model_scope" in names(summary_table)
    @test summary_table[1, "model_scope"] == "full"

    mktempdir() do dir
        paths = export_simulation_result(result, dir; model_id = "full_yeast_model")

        @test !haskey(paths, "fluxes")
        @test !isfile(joinpath(dir, "fluxes.csv"))
        @test isfile(paths["summary"])
        @test isfile(paths["states"])
        @test isfile(paths["diagnostics"])
        @test isfile(paths["metadata"])

        exported_summary = DataFrame(CSV.File(paths["summary"]))
        @test exported_summary[1, "model_scope"] == "full"
        @test exported_summary[1, "reconstruct_fluxes"] == false
    end
end
