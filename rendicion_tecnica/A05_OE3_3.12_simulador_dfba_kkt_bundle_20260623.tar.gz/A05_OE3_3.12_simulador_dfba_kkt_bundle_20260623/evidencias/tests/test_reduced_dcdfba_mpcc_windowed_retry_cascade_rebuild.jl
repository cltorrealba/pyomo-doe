using DataFrames

function _reduced_mpcc_retry_cascade_attempt()
    initial = _reduced_mpcc_window_test_initial_state()
    first, first_final = _reduced_mpcc_window_test_comparison(
        t0 = 0.0,
        tfinal = 0.5,
        initial_state = initial,
        biomass_offset = 0.0,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    second, second_final = _reduced_mpcc_window_test_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = first_final,
        biomass_offset = 0.02,
        trajectory_ready = false,
        solver_status = "ITERATION_LIMIT",
    )
    third, _ = _reduced_mpcc_window_test_comparison(
        t0 = 1.0,
        tfinal = 1.5,
        initial_state = second_final,
        biomass_offset = 0.02,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    continuation = run_reduced_dcdfba_mpcc_windowed_continuation([first, second, third])
    attempt = attempt_reduced_dcdfba_mpcc_windowed_simulation(
        continuation;
        target_horizon = 1.5,
    )
    return attempt, first_final
end

@testset "Reduced MPCC retry cascade rebuild resolves downstream from nonterminal replacement" begin
    attempt, second_initial = _reduced_mpcc_retry_cascade_attempt()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = second_initial,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
        biomass_offset = 0.0,
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 2,
        traffic_light = "green",
        residual_feasible = true,
        trajectory_ready = true,
        ipopt_max_iter = 500,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)

    runner_indices = Int[]
    runner_initials = Vector{Float64}[]
    downstream_result = Ref{Any}(nothing)
    runner = function (spec, y0)
        push!(runner_indices, spec.window_index)
        push!(runner_initials, Float64.(y0))
        comparison = _reduced_mpcc_retry_replacement_comparison(
            t0 = Float64(spec.t0),
            tfinal = Float64(spec.tfinal),
            initial_state = y0,
            trajectory_ready = true,
            solver_status = "LOCALLY_SOLVED",
            biomass_offset = 0.0,
        )
        downstream_result[] = comparison
        return comparison
    end

    result = cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        policy;
        window_runner = runner,
    )

    @test result isa ReducedDCDFBAMPCCWindowedRetryCascadeRebuildResult
    @test result.source_attempt === attempt
    @test result.retry_policy_diagnostic === policy
    @test runner_indices == [3]
    @test length(runner_initials) == 1
    @test runner_initials[1] ≈
          replacement.trajectory_candidate.boundary_result.states[:, end]
    @test result.rebuilt_continuation.window_comparisons[1] ===
          attempt.continuation_result.window_comparisons[1]
    @test result.rebuilt_continuation.window_comparisons[2] === replacement
    @test result.rebuilt_continuation.window_comparisons[3] === downstream_result[]
    @test result.replacement_table[1, "replacement_applied"] == true
    @test result.replacement_table[1, "replacement_reason"] ==
          "accepted_retry_cascade_replacement"
    @test result.cascade_table[1, "cascade_role"] == "source_prefix"
    @test result.cascade_table[2, "cascade_role"] == "retry_replacement"
    @test result.cascade_table[3, "cascade_role"] == "downstream_resolve"
    @test result.cascade_table[2, "replacement_applied"] == true
    @test result.metadata["cascade_rebuild_type"] ==
          "reduced_dcdfba_mpcc_windowed_retry_cascade_rebuild"
    @test result.metadata["cascade_rebuild_applied"] == true
    @test result.metadata["retry_replacement_applied"] == true
    @test result.metadata["windowed_candidate_rebuilt"] == true
    @test result.metadata["cascade_replacement_window_index"] == 2
    @test result.metadata["cascade_replacement_retry_case_id"] == "retry_001"
    @test result.metadata["cascade_replacement_retry_ipopt_max_iter"] == 500
    @test result.metadata["n_downstream_windows_requested"] == 1
    @test result.metadata["n_downstream_windows_resolved"] == 1
    @test result.metadata["outputs_written"] == false
    @test result.metadata["cascade_rebuild_is_scientific_simulation"] == false
    @test result.metadata["solved_trajectory_claimed"] == false
    @test result.metadata["first_mpcc_target"] == "reduced_dfba"
    @test result.metadata["hsl_required"] == false
    @test result.metadata["ma57_required"] == false
    @test result.metadata["indices_reacciones_used"] == false
    @test result.metadata["r0001_used_as_oxygen"] == false
end

@testset "Reduced MPCC retry cascade rebuild does not run without accepted retry" begin
    attempt, second_initial = _reduced_mpcc_retry_cascade_attempt()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = second_initial,
        trajectory_ready = false,
        solver_status = "ITERATION_LIMIT",
        biomass_offset = 0.04,
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 2,
        traffic_light = "yellow",
        residual_feasible = true,
        trajectory_ready = false,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)
    calls = Ref(0)
    runner = function (_spec, _y0)
        calls[] += 1
        error("runner should not be called")
    end

    result = cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        policy;
        window_runner = runner,
    )

    @test calls[] == 0
    @test result.rebuilt_attempt === attempt
    @test result.metadata["cascade_rebuild_applied"] == false
    @test result.metadata["retry_replacement_applied"] == false
    @test result.metadata["windowed_candidate_rebuilt"] == false
    @test result.metadata["recommended_next_action"] ==
          "no_retry_replacement_candidates_available"
end

@testset "Reduced MPCC retry cascade rebuild reports downstream errors" begin
    attempt, second_initial = _reduced_mpcc_retry_cascade_attempt()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = second_initial,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 2,
        traffic_light = "green",
        residual_feasible = true,
        trajectory_ready = true,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)
    runner = function (_spec, _y0)
        error("synthetic downstream failure")
    end

    result = cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        policy;
        window_runner = runner,
        continue_on_error = true,
    )

    @test result.metadata["cascade_rebuild_applied"] == true
    @test result.metadata["cascade_stopped_by_error"] == true
    @test result.metadata["n_downstream_windows_resolved"] == 0
    @test result.metadata["recommended_next_action"] ==
          "inspect_failed_downstream_cascade_window"
    @test result.cascade_table[3, "cascade_role"] == "downstream_failed"
    @test result.cascade_table[3, "window_status"] == "failed"
    @test occursin("synthetic downstream failure", result.cascade_table[3, "error_message"])
end

@testset "Reduced MPCC retry cascade rebuild validation" begin
    attempt, second_initial = _reduced_mpcc_retry_cascade_attempt()
    replacement = _reduced_mpcc_retry_replacement_comparison(
        t0 = 0.5,
        tfinal = 1.0,
        initial_state = second_initial,
        trajectory_ready = true,
        solver_status = "LOCALLY_SOLVED",
    )
    retry = _reduced_mpcc_retry_replacement_retry_result(
        replacement;
        window_index = 2,
        traffic_light = "green",
        residual_feasible = true,
        trajectory_ready = true,
    )
    policy = _reduced_mpcc_retry_replacement_policy(attempt, retry)
    other_attempt, _ = _reduced_mpcc_retry_cascade_attempt()

    @test_throws ArgumentError cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        policy,
    )
    @test_throws ArgumentError cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
        other_attempt,
        policy;
        window_runner = (_spec, _y0) -> replacement,
    )
    @test_throws ArgumentError cascade_rebuild_reduced_dcdfba_mpcc_window_retry_replacements(
        attempt,
        policy;
        window_runner = (_spec, _y0) -> replacement,
        acceptance_policy = "invalid",
    )
end
