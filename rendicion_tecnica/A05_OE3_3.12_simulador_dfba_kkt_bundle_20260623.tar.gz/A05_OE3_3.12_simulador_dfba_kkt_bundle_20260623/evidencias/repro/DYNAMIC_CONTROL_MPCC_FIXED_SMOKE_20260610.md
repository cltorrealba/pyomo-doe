# Fixed-Control Reduced MPCC Smoke, 2026-06-10

Goal: validate a guarded reduced MPCC replay of one dynamic-control policy before
freeing temperature or nutrient controls. All Julia/Ipopt work was run through
Slurm on the UC cluster; login work was limited to edits, inspection, `squeue`,
`sinfo`, and `sbatch`.

Policy:

- `cool18_warm22__springferm_early_0p4`
- 24 h smoke horizon
- sequential reference generated inside the Slurm job with `saveat = 0.25 h`
- MA86 with licensed cluster HSL:
  `/home/cltorrealba/opt/hsl/libhsl-2025.7.21/lib/libhsl.so`
- `OPENBLAS_NUM_THREADS=1`
- no GPU

## Entrypoint

Added:

- `scripts/main_reduced_mpcc_fixed_control_policy_smoke.jl`

The script:

- reads the policy-selection CSV,
- reconstructs the fixed dynamic-control schedule,
- simulates the matching sequential reduced dFBA reference,
- passes that reference as `sequential_initialization`,
- builds RHS + dynamic-bound reduced MPCC rows,
- runs a bounded Ipopt smoke,
- writes `reduced_mpcc_fixed_control_policy_smoke.csv` and `.toml`.

The script is intentionally diagnostic: `smoke_result_is_scientific_simulation=false`.

## Slurm Evidence

Shared run root:

`/home/cltorrealba/mpcc_runs/dynamic_control_fixed_smoke_20260610_151729`

Contract checks:

- `728373`: script-entrypoint contract passed after correcting the command to
  load `FermentationDFBA`.
- `728396`, `728409`, `728418`: updated contracts passed after adding sequential
  initialization, complementarity controls, and collocation-consistent starts.

Rejected/diagnostic smokes:

| Job | Setup | Initial Ipopt row | Outcome |
| --- | --- | --- | --- |
| `728376` | no sequential start, exact complementarity | `inf_pr=1.99e+01`, `inf_du=1.08e+00` | bad start; not a valid baseline |
| `728399` | sequential start, exact complementarity | `inf_pr=1.99e+01`, `inf_du=1.16e+00` | exact complementarity dominates |
| `728411` | sequential start, Scholtes `tau=20` | `inf_pr=1.03e+01`, `inf_du=1.16e+00` | tau gate OK, but Ipopt bound pushes break KKT/FBA starts |
| `728424` | nfe=2, collocation starts, Scholtes `tau=20`, no strict warm-start | `inf_pr=1.03e+01` | confirms Ipopt pushes are harmful |

Accepted smoke configuration:

- sequential initialization from the same fixed policy,
- collocation-consistent state starts enabled,
- Scholtes complementarity with `tau=20`,
- strict Ipopt warm-start:
  - `MPCC_IPOPT_WARM_START_INIT_POINT=1`
  - all warm-start bound/slack/mult pushes/fracs set to `1e-12`,
- limited-memory Hessian,
- MA86.

Results:

| Job | nfe | max_iter | Initial Ipopt row | Final/CSV highlights |
| --- | ---: | ---: | --- | --- |
| `728433` | 2 | 0 | `inf_pr=2.91e-01`, `inf_du=1.17e+00` | `S*v=1.93e-12`, bounds `1.14e-13`, stationarity `6.18e-15`, complementarity `0` |
| `728443` | 2 | 5 | `inf_pr=2.91e-01`, `inf_du=1.17e+00` | final `inf_pr=2.79e-01`; KKT/FBA remained clean |
| `728449` | 4 | 0 | `inf_pr=9.84e-02`, `inf_du=1.33e+00` | `S*v=1.36e-12`, bounds `1.14e-13`, stationarity `3.14e-14`, complementarity `0` |
| `728454` | 4 | 5 | `inf_pr=9.84e-02`, `inf_du=1.33e+00` | final `inf_pr=9.65e-02`; `S*v=2.63e-11`, bounds `<3e-7`, stationarity `3.08e-14` |

No restoration was observed in the accepted smoke line.

## Conclusion

The first robust fixed-control MPCC replay baseline is:

- 24 h,
- `nfe=4`,
- sequential reference start,
- collocation-consistent starts,
- Scholtes `tau=20`,
- strict Ipopt warm-start,
- MA86,
- limited-memory Hessian.

This is not yet a solved simultaneous trajectory. It is a stable solver-entry
baseline showing that the dynamic-control fixed-policy MPCC can be assembled and
entered with clean KKT/FBA starts. The remaining dominant residual is the
collocation defect (`~9.7e-2` for 24 h, nfe=4). Next technical step: wire the
same fixed-control setup into the guarded `solve_attempt` path so residual
threshold reports and candidate diagnostics are generated consistently before
freeing controls.

Follow-up completed in
`repro/DYNAMIC_CONTROL_MPCC_FIXED_SOLVE_ATTEMPT_20260610.md`.
