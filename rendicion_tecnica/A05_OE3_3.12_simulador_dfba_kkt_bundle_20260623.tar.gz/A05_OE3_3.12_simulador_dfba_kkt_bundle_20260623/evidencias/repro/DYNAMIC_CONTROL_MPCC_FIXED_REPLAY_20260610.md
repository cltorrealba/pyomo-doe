# Dynamic control fixed MPCC replay preflight, 2026-06-10

Purpose: wire fixed dynamic-control schedules into the reduced simultaneous
MPCC scaffold before promoting temperature and nutrient profiles to decision
variables. This is a structural/preflight step only: no Ipopt solve is called
and no simultaneous biological trajectory is claimed.

## Implemented wiring

- `build_reduced_dcdfba_dynamic_bounds(...; dynamic_control_schedule=...)`
  now evaluates effective Zenteno parameters at each collocation time. This
  means temperature schedules affect the dynamic glucose, fructose, nitrogen,
  ethanol, amino-acid and aroma flux bound expressions.
- `add_reduced_dcdfba_rhs_residuals!(...; dynamic_control_schedule=...)`
  now adds fixed smooth RHS terms for:
  - FDA ammonium-equivalent nitrogen into state 2.
  - Organic nutrient amino-acid rates into states 9:13.
  - Optional volatilization aroma losses from states 14:19.
- `build_reduced_dcdfba_mpcc_smoke_problem` and
  `build_reduced_dcdfba_mpcc_solve_attempt_problem` accept
  `dynamic_control_schedule`.
- Numeric diagnostics and RHS-consistent derivative starts use the same fixed
  schedule as the constraints.
- The fixed profile is metadata-marked as
  `mpcc_dynamic_control_variable_policy=fixed_profile_not_decision_variable`.

## Preflight script

Script:

- `scripts/main_reduced_mpcc_fixed_control_policy_preflight.jl`

It reads `dynamic_control_policy_selection.csv`, reconstructs each fixed
control schedule, builds a reduced MPCC smoke problem with RHS and dynamic
bounds, and exports a preflight CSV/TOML. It does not call `optimize!`.

Cluster-safe command shape:

```bash
MPCC_FIXED_CONTROL_POLICY_SELECTION_CSV=/path/to/dynamic_control_policy_selection.csv \
MPCC_FIXED_CONTROL_OUTPUT_DIR=/home/cltorrealba/mpcc_runs/dynamic_control_mpcc_fixed_replay_YYYYMMDD_HHMMSS/preflight \
MPCC_FIXED_CONTROL_PREFLIGHT_HOURS=24 \
MPCC_FIXED_CONTROL_NFE=2 \
MPCC_FIXED_CONTROL_MAX_POLICIES=3 \
julia --project=. scripts/main_reduced_mpcc_fixed_control_policy_preflight.jl
```

Run through Slurm on the UC cluster.

## Current artifacts

Output root:

- `/home/cltorrealba/mpcc_runs/dynamic_control_mpcc_fixed_replay_20260610_131549`

Policy selection:

- `selection/dynamic_control_policy_selection.csv`
- `selection/dynamic_control_policy_selection.toml`

MPCC fixed-control preflight:

- `preflight/reduced_mpcc_fixed_control_policy_preflight.csv`
- `preflight/reduced_mpcc_fixed_control_policy_preflight.toml`

Preflight settings:

- Horizon: 24 h.
- `nfe=2`.
- Degree: 3.
- Policies: 3.
- Solver call: false.
- Linear solver setting: `mumps`.

Preflight outcome:

| Candidate | Ready | Variables | Constraints | Solver call |
| --- | ---: | ---: | ---: | ---: |
| `cool18_warm22__springferm_early_0p4` | true | 33,543 | 51,399 | false |
| `cool18_warm22__springferm_split_0p1_0p1` | true | 33,543 | 51,399 | false |
| `flat20__fda_split_0p5_0p5` | true | 33,543 | 51,399 | false |

All three preflights reported
`nlp_structure_too_few_degrees_of_freedom_risk=false`.

## Validation

- `728312`: focused dynamic-bound tests including fixed control schedule;
  completed on `full/n14`, exit `0:0`.
- `728322`: RHS residual and MPCC smoke compatibility tests; completed on
  `full/n14`, exit `0:0`.
- `728323`: MPCC solve-attempt tests without opt-in real solve; completed on
  `full/n14`, exit `0:0`.
- `728331`: script-entrypoint contracts including fixed-control preflight;
  completed on `full/n14`, exit `0:0`.
- `728334`: regenerated policy selection; completed on `full/n14`, exit `0:0`.
- `728341`: fixed-control MPCC preflight for the three selected policies;
  completed on `full/n14`, exit `0:0`.

## Next step

Run a guarded fixed-control smoke solve for one policy only, starting with
`cool18_warm22__springferm_early_0p4`, 24 h, `nfe=2`, limited-memory Hessian,
MA86 if available, low `max_iter`, and strict early cancellation if restoration
or huge `inf_pr` appears. Do not free control variables until this fixed
replay line is numerically sane.
