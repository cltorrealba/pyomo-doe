# Sequential 168 h G75 F75 YAN200 experiment

Date: 2026-06-08
Branch: `workstation_cii`

## Purpose

Check whether the reduced sequential dFBA run dries a 150 g/L sugar must
(`glucose = 75 g/L`, `fructose = 75 g/L`) under the same kinetic parameters and
the explicit YAN 200 mgN/L initialization used in the previous diagnostic.

The motivation is a mismatch against a simple ODE model without dFBA, where the
same nominal parameters reportedly dry the must in about 6 days.

## Code change

Added environment-driven initial sugar overrides for reduced sequential scripts:

```text
DFBA_INITIAL_GLUCOSE_G_L
DFBA_INITIAL_FRUCTOSE_G_L
```

These only modify the initial state vector. Kinetic parameters are unchanged.

## Slurm run

Job:

```text
724387
```

Environment:

```text
DFBA_RUN_TARGET_TAG=sequential_reduced_168h_G75_F75_YAN200_freeN_thr1e4
DFBA_INITIAL_GLUCOSE_G_L=75
DFBA_INITIAL_FRUCTOSE_G_L=75
DFBA_INITIAL_YAN_MGN_L=200
DFBA_INITIAL_YAN_POLICY=ammonium_balance
DFBA_PHASE_PROXY_MODE=free_nitrogen
DFBA_TURNOVER_THRESHOLD=1e-4
OMP_NUM_THREADS=4
OPENBLAS_NUM_THREADS=1
JULIA_NUM_THREADS=1
```

Output:

```text
/home/cltorrealba/mpcc_runs/sequential_reduced_168h_G75_F75_YAN200_freeN_thr1e4_highs_724387_20260608_010900
```

Plots:

```text
/home/cltorrealba/mpcc_runs/sequential_reduced_168h_G75_F75_YAN200_freeN_thr1e4_highs_724387_20260608_010900/plots
```

## Results

Run status:

```text
retcode = Success
termination_reason = completed_tspan
final_time = 168.0 h
initial_total_sugar = 150.0 g/L
final_total_sugar = 21.818654400152873 g/L
sugar_consumed = 128.18134559984713 g/L
final_ethanol = 59.98606820057552
max_mass_balance_residual = 2.5011104298755527e-12
```

The run did not reach sugar depletion by 168 h.

Phase transition:

```text
growth -> turnover at 28.0 h
```

Selected time points:

| time h | biomass | free N | glucose | fructose | total sugar | ethanol |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0.0 | 0.500000 | 0.130000018 | 75.000000 | 75.000000 | 150.000000 | 0.000000 |
| 24.0 | 2.376411 | 0.005400562 | 64.783662 | 68.139705 | 132.923367 | 7.453111 |
| 28.0 | 2.475472 | 0.000099992 | 64.293940 | 66.751518 | 131.045459 | 8.366460 |
| 72.0 | 2.475472 | 0.000099992 | 35.633316 | 50.902602 | 86.535918 | 29.578512 |
| 144.0 | 2.475472 | 0.000099992 | 7.880317 | 26.331003 | 34.211321 | 54.239638 |
| 168.0 | 2.475472 | 0.000099992 | 3.304895 | 18.513759 | 21.818654 | 59.986068 |

## Flux/bound diagnostic

In this run the dFBA LP is generally using the kinetic sugar uptake lower bounds,
so the slow drying is not primarily caused by the LP refusing available sugar
uptake. At representative saved times:

| time h | glucose lb | glucose flux | fructose lb | fructose flux |
| ---: | ---: | ---: | ---: | ---: |
| 0.0 | -2.573303224 | -2.573303224 | -1.296255376 | -1.296255376 |
| 28.0 | -1.833910214 | -1.833910214 | -0.866230775 | -0.866230775 |
| 72.0 | -1.182624194 | -1.182624194 | -0.776306753 | -0.776306753 |
| 144.0 | -0.545752375 | -0.545752375 | -0.749499731 | -0.749499731 |
| 168.0 | -0.309830943 | -0.309830943 | -0.704231401 | -0.704231401 |

At 24 h, glucose is not at its uptake lower bound while fructose is; this is near
the transition and should be checked separately if needed. After turnover, the
recorded fluxes match the kinetic lower bounds.

## Interpretation

The G75/F75 dFBA run still leaves about 21.8 g/L sugar after 7 days. Since the
sugar exchange fluxes are usually at their kinetic uptake bounds, the discrepancy
with the simple ODE model is likely due to a difference in one of these areas:

- the exact ODE sugar uptake equations or units used in the simple model,
- the active biomass/turnover treatment after nitrogen depletion,
- the temperature or inhibition factors used in the ODE implementation,
- whether the simple ODE continues changing biomass or active biomass during the
  post-nitrogen phase.

The next diagnostic should compare the simple ODE sugar RHS against
`zenteno_kinetic_rates` at the same saved states.
