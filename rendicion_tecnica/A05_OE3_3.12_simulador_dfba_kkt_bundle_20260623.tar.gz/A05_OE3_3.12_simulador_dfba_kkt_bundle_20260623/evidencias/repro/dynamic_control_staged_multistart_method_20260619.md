# Dynamic-Control Staged Multistart Method

This note defines the next MPCC strategy after the direct-control diagnostics
showed that objective weights alone do not move controls.

## Principle

Use broad but controlled starts as diagnostics, not as final answers. A seeded
profile is acceptable only if it remains residual-sane and survives subsequent
regularization annealing or mesh refinement. Promotion still requires a
residual-feasible, trajectory-ready candidate; a seeded branch that only looks
biologically attractive but carries large collocation/complementarity defects is
not blessed.

## Stages

- `s0`: direct-control activation. Seed one small explicit subset and add a
  direct reward so the expected control boundary is unambiguous.
- `s1`: mediated productivity objective. Remove direct rewards, keep weak
  reference regularization, and test temperature/FDA/organic starts separately.
- `s1r`: rescue/relaxation diagnostics. Repeat promising `s1` branches with
  guarded complementarity flux projection or sign-preserving bound-dual
  complementarity clipping. These runs are not promotion candidates by
  themselves unless they also satisfy the ordinary residual/trajectory gates.
- `s2`: anneal the reference regularization toward zero for branches that were
  residual-sane in `s1`.
- `s2seed`: same annealing idea, but the starting control profile is imported
  from a prior MPCC candidate via an exported policy CSV. This avoids adding
  another manual offset on top of an already seeded candidate.
- `s3direct`: direct-control diagnostics from flat and interior starts. These
  runs verify that liberated controls are connected and identify lower-bound
  pinning before using state-mediated objectives.
- `s4damped`: interior starts plus weaker direct rewards and positive
  reference regularization. This is the first real bridge from diagnostic
  nudging to residual-sane displaced starts.
- `s5mediated`: direct rewards off, productivity pressure on, and the same
  broad starts/regularization machinery. These runs test whether the serious
  objective can move controls through the RHS/bounds coupling rather than by an
  artificial direct term.
- `s6extend`: only after `s5mediated` is residual-sane, extend horizon and mesh,
  then evaluate the serious objective with dry-gate/productivity/cost/aroma
  terms.

## Current First Bank

The executable bank is
`repro/dynamic_control_staged_multistart_bank_20260619.tsv`, submitted by
`repro/submit_cluster_uc_dynamic_control_staged_multistart.sh`.
Prior MPCC control vectors can be exported into seed policy CSVs with
`scripts/main_export_dynamic_control_seed_policy.py`.

The first jobs are intentionally 72 h, `nfe=72`, explicit slots `1,3,6` for
temperature and `1,3,5` for additions. This keeps the problem small enough to
diagnose while preserving the control/RHS/bounds coupling. The early FDA seed is
preferred over mid-slot FDA because the 72 h sequential sensitivity shows slot 1
improves sugar progress while slots 3 and 5 can be detrimental. Organic is
tested only as tiny slot-3 or slot-3/5 seeds: the final sequential sweep showed
organic slot 1 has the largest progress signal but also negative saved states,
while slots 3 and 5 retain strong progress/aroma signals without that warning.
This avoids repeating the earlier defective slot-1 organic branch.

The bank now exposes these relaxation controls per case:

- `relaxed_mass_weight`: mass-balance weight for the relaxed dynamic-flux LP
  fallback used during start construction.
- `complementarity_tau`: Scholtes tau for the solve attempt.
- `bound_dual_clip`, `bound_dual_clip_elements`,
  `bound_dual_clip_budget_fraction`: optional clipping of bound-dual starts so
  bound-dual complementarity starts inside a prescribed fraction of tau.
- `final_compflux_projection`: guarded final active-flux projection for
  complementarity rescue.

The first clipping cases use `complementarity_tau=1e-3` and
`bound_dual_clip_budget_fraction=0.01`, giving an effective dual-start
complementarity budget of `1e-5`. This is close to the previously useful global
tau scale while still allowing the MPCC solve itself to move.

## Current Evidence

- `s0_temp_high_direct_reg0p05_h72` completed residual-feasible but not
  trajectory-ready. The high-temperature seeded branch was accepted as a
  trajectory shape, but Ipopt did not move controls from the seeded start.
- `s1_fda_early_productivity_reg0p02_h72` completed residual-feasible but not
  trajectory-ready. It is the first branch with measurable post-solve control
  movement: small temperature and FDA deltas, still dominated by lower
  complementarity.
- `s1_org_mid_tiny_productivity_reg0p02_h72` selected the pre-solve start as
  residual-feasible; post-solve was rejected. It has the lowest lower
  complementarity residual among the first base runs, but still fails
  trajectory readiness.
- `s1_org_mid_tiny_productivity_compflux_reg0p02_h72` triggered the guarded
  active complementarity flux projection, but the guard rejected it because the
  projected candidate worsened complementarity. This rules out blind compflux
  projection as the default rescue.
- `s1_fda_early_productivity_compflux_reg0p02_h72` completed as Slurm job
  `743390`. It is residual-feasible but not trajectory-ready. The post-solve
  candidate was selected and moved controls more than the non-compflux FDA
  branch (`temperature_max_abs_delta_vs_start_C=0.0112`,
  `fda_sum_delta_vs_start_g_L=0.00109`), but lower complementarity worsened to
  `1.94e-4`. The guarded complementarity flux projection was enabled but not
  applied. This keeps compflux in the diagnostic toolbox, not as the default
  rescue path.
- `s1_org_mid_tiny_clip_tau1em3_reg0p02_h72` completed as Slurm job `743459`.
  It is not residual-feasible: `max_stationarity_residual=0.190`, lower
  complementarity `7.62e-4`, upper complementarity `6.11e-4`, dominant residual
  `max_stationarity_residual`. It confirms that lowering Scholtes tau to
  `1e-3` plus bound-dual clipping from the original organic start is too
  aggressive and should not be the default rescue.
- Seed policy CSVs were generated for the completed FDA and organic branches:
  `repro/generated/dynamic_control_staged_multistart_20260619/s1_fda_early_postsolve_seed_policy.csv`
  and
  `repro/generated/dynamic_control_staged_multistart_20260619/s1_org_mid_tiny_selected_seed_policy.csv`.
  These enable `s2seed` continuation without hand-writing offsets.
- `s2_org_seed_anneal_reg0_tau1em3_h72` completed as Slurm job `743468` using
  the exported organic seed policy, with reference regularization set to zero
  and bound-dual clipping enabled. It is not residual-feasible:
  `max_stationarity_residual=0.184`, lower complementarity `7.85e-4`, upper
  complementarity `5.98e-4`, dominant residual `max_stationarity_residual`.
  This shows that turning off reference regularization in one jump is too
  aggressive; the next annealing step should use an intermediate regularization
  value or a looser diagnostic stage, not direct promotion.
- `s2_org_seed_anneal_reg0p01_tau1em3_h72` completed as Slurm job `743513`.
  It is not residual-feasible: `max_stationarity_residual=0.184`, lower
  complementarity `7.84e-4`, upper complementarity `5.98e-4`, dominant
  residual `max_stationarity_residual`. The result is nearly identical to the
  `reg=0` tau-`1e-3` branch, so intermediate reference regularization alone
  does not rescue an abrupt tau/clipping jump.
- `s2_org_seed_anneal_reg0p01_tau20_h72` was submitted as Slurm job `743537`
  with the same exported organic seed and intermediate reference
  regularization `0.01`, but with loose Scholtes tau and no bound-dual
  clipping. This isolates the effect of regularization annealing from the
  earlier aggressive tau/clipping changes.
- `s2_org_seed_anneal_reg0p01_tau20_h72` completed residual-feasible but not
  trajectory-ready. Ipopt reported `ALMOST_LOCALLY_SOLVED`, but the selected
  candidate fell back to `pre_solve_start_values` because the post-solve was
  not residual-feasible. Lower complementarity stayed at `2.60e-5` and controls
  barely moved (`temperature_max_abs_delta_vs_start_C=5.58e-7`,
  `organic_sum_delta_vs_start_g_L=8.36e-8`). This confirms that loose tau avoids
  the stationarity blow-up, but the current objective/regularization still does
  not produce a promotable moved post-solve.
- `s2_org_seed_anneal_reg0p01_tau5_h72` is prepared but not submitted. It
  should be submitted only after the tau-10 probes identify a residual-sane
  branch.
- `s2_org_seed_anneal_reg0p005_tau20_h72` was submitted as Slurm job `743584`
  while `s2_org_seed_anneal_reg0p01_tau20_h72` was still running, because it
  keeps loose tau and removes only half of the remaining reference
  regularization. This is the next conservative annealing probe, not a
  promotion candidate by itself.
- `s2_org_seed_anneal_reg0p005_tau20_h72` completed residual-feasible but not
  trajectory-ready, with the same fallback pattern as `reg=0.01`: selected
  source `pre_solve_start_values`, lower complementarity `2.60e-5`, negligible
  control movement. Reducing reference regularization at loose tau preserves
  feasibility but does not by itself create a moved, promotable post-solve.
- `s2_org_seed_anneal_reg0p01_tau10_h72` and
  `s2_org_seed_anneal_reg0p005_tau10_h72` were submitted as Slurm jobs `743623`
  and `743624` to test moderate Scholtes tau without clipping. These are the
  first tau-continuation probes after confirming that tau `20` is safe but
  control-pinned, while tau `1e-3` with clipping is too aggressive.
- `s2_org_seed_anneal_reg0p005_tau10_h72` completed as Slurm job `743624`.
  It is residual-feasible but not trajectory-ready, again selecting
  `pre_solve_start_values`; lower complementarity remained `2.60e-5`, and
  control movement was negligible. Moderate tau without clipping does not by
  itself unpin the organic-seeded branch.
- `s2_org_seed_anneal_reg0p01_tau10_h72` completed as Slurm job `743623` with
  the same pattern as `reg=0.005`: residual-feasible selected fallback,
  `ALMOST_LOCALLY_SOLVED`, lower complementarity `2.60e-5`, and negligible
  control movement. The tau-10/tau-20 comparison shows that gradual tau
  reduction without clipping is numerically safe but does not create a useful
  post-solve step.
- Direct-control diagnostics were added after the tau-continuation probes:
  `s3_direct_temp_flat_reg0_tau20_h72`, `s3_direct_fda_flat_reg0_tau20_h72`,
  and `s3_direct_org_flat_reg0_tau20_h72`. They were submitted as Slurm jobs
  `743692`, `743693`, and `743694` from the flat-control policy with strong
  direct rewards and no integrated-sugar pressure. These runs test whether the
  liberated control variables can move when the objective points directly at
  them, separating control connectivity from state-mediated objective
  sensitivity.
- The direct-control diagnostics completed. Temperature did move in the
  post-solve (`max_abs_delta_vs_start=1.30 C`), but the moved post-solve was
  rejected and the selected candidate fell back to the flat pre-solve start;
  lower complementarity was `9.05e-5`. FDA and organic direct rewards were
  active and selected post-solve residual-feasible candidates, but dose movement
  was only `1e-7 g/L` scale, despite free bounds in slots 1/3/5. Therefore
  temperature controls are connected but blocked by post-solve residual gates,
  while nutrient controls appear pinned at the zero lower bound or by
  bound-dual/start geometry. The next diagnostic should start FDA/organic
  controls strictly inside their bounds.
- Interior-start nutrient direct diagnostics were added and submitted:
  `s3_direct_fda_interior_reg0_tau20_h72` as Slurm job `743768` and
  `s3_direct_org_interior_reg0_tau20_h72` as Slurm job `743769`. They start
  liberated dose slots inside their bounds (`FDA=0.10 g/L`, `ORG=0.025 g/L`)
  under the same strong direct rewards.
- The interior-start nutrient diagnostics completed. FDA moved from
  `[0.10, 0.10, 0.10]` in the free slots to approximately
  `[0.112, 0.114, 0.116]` and selected the post-solve residual-feasible
  candidate, but lower complementarity rose to `1.66e-3`. Organic moved in the
  post-solve from `0.025` to up to `0.033 g/L`, but that moved post-solve was
  rejected and the selected candidate fell back to the interior pre-solve
  start; lower complementarity rose to `1.96e-3`. This confirms that
  lower-bound starts were pinning nutrients, but direct reward `50` is too
  abrupt. The next step should use interior starts with smaller direct rewards
  and reference regularization to create a residual-sane control displacement.
- `s4_damped_fda_interior_reg0p02_reward5_tau20_h72` and
  `s4_damped_org_interior_reg0p02_reward5_tau20_h72` were submitted as Slurm
  jobs `743844` and `743845`. They use the same interior dose starts as the
  `s3direct` diagnostics, but reduce the direct reward from `50` to `5` and
  add reference regularization `0.02`. This is the first implementation of the
  mixed strategy: broad seeding plus regularized relaxation rather than
  immediate promotion.
- The bank now also contains pre-registered continuations:
  `s4` lower-reward (`reward1`) and tight-trust variants if `reward5` creates
  excessive complementarity, plus `s5mediated` productivity variants with
  direct rewards disabled. These should be submitted only after the active
  `s4` jobs identify whether reward damping or trust tightening is the better
  continuation.
- To avoid waiting for a failed `reward5` probe before testing the gentler
  path, the lower-reward continuations were also submitted conservatively:
  `s4_damped_org_interior_reg0p02_reward1_tau20_h72` as Slurm job `743851`
  and `s4_damped_fda_interior_reg0p02_reward1_tau20_h72` as Slurm job
  `743854`. These jobs keep the same interior starts and reference
  regularization, but reduce the direct nutrient reward to `1`.
- The four `s4damped` probes completed. All were residual-feasible but none
  were trajectory-ready; the dominant defect remained lower complementarity.
  Organic branches still selected the pre-solve start (`reward5` lower
  complementarity `1.48e-3`, `reward1` `1.21e-3`). FDA `reward5` moved the
  post-solve by `0.0290 g/L` total but was rejected and fell back to the
  pre-solve start. FDA `reward1` is the best bridge: it selected post-solve
  residual-feasible values, moved FDA by `0.00412 g/L` total, and kept
  stationarity/primal residuals small, but still had lower complementarity
  `1.22e-3`.
- The selected FDA `reward1` post-solve controls were exported to
  `repro/generated/dynamic_control_staged_multistart_20260619/s4_damped_fda_reward1_postsolve_seed_policy.csv`.
  This is a continuation seed, not a blessed candidate.
- `s5_seeded_fda_reward1_postsolve_prod20_reg0p02_tau20_h72` was submitted as
  Slurm job `743911` using that exported policy CSV and candidate id
  `s4_damped_fda_reward1_postsolve_seed`. Direct rewards are disabled and the
  mediated integrated-sugar/productivity term is enabled (`weight=20`).
- `s5_seeded_fda_reward1_postsolve_prod20_reg0p02_tau20_h72` completed
  residual-feasible but not trajectory-ready. It selected post-solve values,
  moved temperature by up to `0.020 C`, moved FDA by `0.000709 g/L` total, and
  improved terminal sugar slightly (`190.44 g/L` versus `190.50 g/L` scale),
  so the mediated objective is connected. The cost is worse lower
  complementarity: `3.48e-3`, dominant at `r_1897`. This branch is useful
  evidence, not promotable.
- Two follow-up `s5seed` probes were submitted from the same exported FDA seed:
  `s5_seeded_fda_reward1_postsolve_prod5_reg0p02_tau20_h72` as Slurm job
  `743977`, lowering integrated-sugar weight from `20` to `5`, and
  `s5_seeded_fda_reward1_postsolve_prod20_reg0p02_compflux_tau20_h72` as Slurm
  job `743978`, keeping productivity weight `20` but enabling guarded final
  complementarity-flux projection.
- The `s5seed` follow-ups completed. Lowering productivity pressure to `5`
  still selected a post-solve residual-feasible candidate and moved controls
  slightly, but lower complementarity stayed high (`3.62e-3`). The guarded
  complementarity-flux projection run was worse: the projection triggered at
  155 points, the guard rejected it, the selected candidate fell back to the
  pre-solve start, and lower complementarity rose to `7.79e-3`. Therefore the
  current bottleneck is not simply objective weight. The next technical line
  should target the flux-complementarity geometry directly before extending
  horizon or releasing more controls.
- `s6tau` and `s6mesh` split that next line into two complementary probes.
  `s6tau` continues the best objective-mediated `s5` post-solve seed with
  tighter Scholtes tau (`1e-3` and `5e-4`) and no bound-dual clipping, testing
  whether the lower-complementarity defect can be reduced without destroying
  stationarity. `s6mesh` adds a regularized broad-start funnel from the flat22
  development policy: flat, warm+FDA, cool-early/warm-late+FDA,
  warm-early/cool-late+organic, and mixed FDA/organic starts. These cases use
  loose tau, stronger reference regularization, modest trust regions, direct
  rewards disabled, and the mediated productivity objective. Their role is to
  find residual-sane basins, not to define the final optimum.
- First active Slurm runs for this split are `744049`/`744050` for the seeded
  tau-continuations and `744067`/`744068` for the first two broad-start mesh
  cases. Promotion remains blocked until a candidate is residual-feasible,
  trajectory-ready or demonstrably improving the dominant lower-complementarity
  defect, and reproducible through continuation rather than a single seeded
  accident.
- `s6_tau_seeded_fda_prod20_reg0p02_tau5em4_h72` completed as Slurm job
  `744050`. It reached Ipopt iteration limit with `NEARLY_FEASIBLE_POINT`, no
  restoration crash, and selected the residual-feasible pre-solve fallback
  because the post-solve was not residual-feasible. It is not promotable
  (`selected_candidate_trajectory_ready=false`), but it is useful evidence:
  stationarity stayed tiny (`4.95e-14`), mass-balance and bound violations
  stayed small, and the dominant lower-complementarity scale was reduced to
  about `5.00e-4`. The post-solve moved controls only slightly
  (`temperature max delta 0.0108 C`, FDA net sum delta `-4.99e-4 g/L`) before
  rejection. Therefore strict tau without clipping is numerically safer than
  the older clipped jump, but it still does not produce an acceptable moved
  candidate from the `s5` seed by itself.
- `s6_tau_seeded_fda_prod20_reg0p02_tau1em3_h72` completed as Slurm job
  `744049` with the same qualitative outcome and worse complementarity scale:
  iteration limit, `NEARLY_FEASIBLE_POINT`, post-solve rejected, selected
  residual-feasible pre-solve fallback, and `selected_candidate_trajectory_ready=false`.
  Its dominant lower-complementarity residual was `9.9978e-4`, with the same
  `r_1914` location family. This closes the `s5 -> strict tau` branch as a
  diagnostic: tau tightening alone can bound the defect scale, but it does not
  produce a useful moved post-solve candidate from that seed.
- `s6_mesh_warm_fda_prod20_reg0p05_tau20_h72` completed as Slurm job `744068`.
  It also reached iteration limit with `NEARLY_FEASIBLE_POINT` and selected
  the residual-feasible pre-solve fallback because the post-solve was not
  residual-feasible. This is not promotable either, but it shows why the broad
  mesh is useful: the warm+FDA start itself is residual-feasible, has lower
  terminal sugar (`188.56 g/L`) than the `s5` seeded continuation fallback
  (`190.48 g/L`), and keeps the dominant lower-complementarity scale around
  `3.22e-4` with tiny stationarity residual. The rejected post-solve moved
  controls only mildly (`temperature max delta 0.0194 C`, FDA sum delta
  `6.30e-4 g/L`). This branch is a better continuation seed than `s5`, but it
  still needs a continuation step that preserves post-solve residual
  feasibility.
- `s6_mesh_flat22_prod20_reg0p05_tau20_h72` completed as Slurm job `744067`.
  This is the first useful broad-start result in the current funnel: Ipopt
  ended at iteration limit with `FEASIBLE_POINT`, the post-solve candidate was
  residual-feasible and selected, and stationarity remained tiny
  (`2.54e-14`). It is still not trajectory-ready because lower
  complementarity remains dominant (`3.24e-4`, reaction `r_1912`), but it
  materially improves the state trajectory relative to the previous seeded
  branch: selected terminal sugar is `175.00 g/L` and selected terminal
  isoamyl-alcohol proxy is `3.47e-4 g/L`. Control movement is very mild
  (`temperature max delta 0.0056 C`, nutrient deltas near zero), so this is
  primarily a numerically better MPCC basin rather than an optimized control
  policy. The selected candidate was exported to
  `repro/generated/dynamic_control_staged_multistart_20260619/s6_mesh_flat22_postsolve_seed_policy.csv`
  for tau-continuation.
- `s7_tau_flat22_postsolve_seed_prod20_reg0p05_tau1em3_h72` completed as
  Slurm job `744111`. It confirms an important limitation of the current
  continuation machinery: exporting only the control policy does not preserve
  the full MPCC post-solve basin from `744067`. The run reconstructed the
  simultaneous start from the exported controls, reached iteration limit with
  `FEASIBLE_POINT`, but rejected the post-solve and selected the pre-solve
  fallback. Terminal sugar stayed close to the exported policy trajectory
  (`175.05 g/L`), but lower complementarity rose to the tau scale
  (`9.93e-4`) and the selected isoamyl-alcohol proxy dropped relative to
  `744067`. Therefore the next engineering step is not another policy-only
  tau run; it is a full fixed-control MPCC candidate handoff/export/import path
  that can preserve states, fluxes, duals, and controls from a residual-feasible
  selected candidate when horizon, mesh, and decision layout are unchanged.
- The first handoff-support change was added after these runs: the fixed-control
  policy solve attempt now serializes the selected `CandidateDiagnostics` object
  to `reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
  whenever a selected candidate is available, and records the path in metadata.
  This does not retroactively create a full handoff for job `744067`, but it
  makes the next broad-start repeats suitable for exact candidate export. The
  edited entrypoint was parse-validated on the cluster through Slurm job
  `744169` (`parse_ok`).
- The staged submitter now accepts and validates
  `MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS`, so tau-continuation can
  import a complete MPCC candidate rather than only an exported control-policy
  CSV. The first producer rerun,
  `s6_mesh_flat22_prod20_reg0p05_tau20_h72`, completed as Slurm job `744183`
  and wrote
  `reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`. The
  first full-candidate continuation,
  `s7_tau_flat22_postsolve_seed_prod20_reg0p05_tau1em3_h72`, is Slurm job
  `744226`. Its log confirms successful deserialization of the candidate
  diagnostics start before `before_mpcc_solve_attempt`; its solve result should
  decide whether this replaces policy-only continuation as the default
  tau-funnel path.
- The Slurm wrappers now pass through `MPCC_IPOPT_PRINT_LEVEL`,
  `MPCC_IPOPT_PRINT_FREQUENCY_ITER`, `MPCC_IPOPT_PRINT_FREQUENCY_TIME`, and
  `MPCC_IPOPT_MAX_WALL_TIME_SECONDS`. Defaults remain quiet, but diagnostic
  reruns can expose Ipopt iteration traces and force a solver return before the
  Slurm time limit. The current comparison artifact is
  `repro/generated/dynamic_control_staged_multistart_20260619/full_candidate_handoff_comparison.md`.
- A short `s7debug` bank case,
  `s7_debug_flat22_fullseed_tau1em3_iter8_h72`, was registered with the same
  full-candidate handoff geometry, using
  `max_iter=8` and a shorter Slurm limit, intended only for a visible rerun
  with `MPCC_IPOPT_PRINT_LEVEL`/`MPCC_IPOPT_MAX_WALL_TIME_SECONDS` if job
  `744226` remains opaque.
- `s7_debug_flat22_fullseed_tau1em3_iter8_h72` completed as Slurm job `744314`
  using the selected `CandidateDiagnostics` from job `744183`. This is the
  first successful full-candidate tau-continuation result: Ipopt reported
  `ALMOST_LOCALLY_SOLVED`/`NEARLY_FEASIBLE_POINT`, the selected post-solve
  candidate was residual-feasible and `selected_candidate_trajectory_ready=true`.
  Initial Ipopt residuals were `inf_pr=9.50e-7` and `inf_du=1.00e2`, so the
  handoff is primal-sane but dual-stiff. The dominant residual remains lower
  complementarity at `r_1902`, `4.53e-4`, below the `tau=1e-3` gate. This
  validates the current strategy: policy-only handoff failed to preserve the
  basin, but full CandidateDiagnostics handoff preserves a promotable 72 h
  trajectory candidate.
- `s8_debug_flat22_fullseed_tau5em4_iter8_h72` was submitted as Slurm job
  `744348`, seeded from the trajectory-ready `744314` candidate, to test
  whether the same basin survives a stricter `tau=5e-4` continuation.
  It was cancelled after 30 min because it remained opaque before any Ipopt
  header or final artifacts, while the `tau=1e-3` handoff had already produced
  the needed trajectory-ready checkpoint. This points the next effort toward
  horizon scaling from the validated checkpoint rather than further tau
  tightening.

## Why Seeding Does Not Have To Bias The Final Optimum

Seeding would be a problem if a single seeded run were promoted as "the"
solution. Here it is a multistart and continuation device:

- compare separate starts under the same objective;
- accept only residual-sane/trajectory-ready candidates;
- anneal reference regularization from positive to zero;
- rerun promising branches on refined meshes;
- promote only if the final answer is reproducible without relying on a defect.

If different starts converge to different feasible local optima, that is useful
information about nonconvexity rather than a methodological failure.
