# Dynamic control scaffold, 2026-06-09

Purpose: introduce a light, solver-independent control layer for the next
dynamic-optimization phase. This does not solve the MPCC and does not change
the current blessed seed. It only defines smooth control trajectories and the
unit conversions needed to wire them into the sequential simulator and later
the simultaneous formulation.

## Controls

- Temperature is represented on a configurable grid, default 12 h, with smooth
  logistic transitions between target values.
- Default temperature bounds are 15 C and 25 C.
- FDA is represented as a smooth pump addition of 10% FDA solution, with doses
  expressed as g solution/L.
- Organic nutrient addition is represented as a separate smooth pump addition
  with a configurable product composition. The default product composition is
  the first SpringFerm Xtrem encoding from the user-provided certificate
  summary.
- The default control penalty is total FDA product dose plus total organic
  product dose. A temperature jump penalty exists, but is disabled by default.
- `sample_dynamic_control_schedule` can be used to inspect the control profile
  on a light time grid before coupling it to ODE/LP/MPCC solves.

## Reference limits and conversions

- FDA solution conversion uses a 10% w/w active product basis and the user
  supplied equivalence that 1 mg active FDA contributes 0.2 mg YAN as ammonium.
  Therefore `1 g solution/L -> 0.02 gN/L`.
- The OIV/DAP active-product reference limit remains `0.3 g/L`, but the default
  smooth-control hard limit is expressed on the 10% solution basis:
  `0.3 / 0.10 = 3.0 g solution/L`.
- Organic nutrient composition defaults to SpringFerm Xtrem with two nitrogen
  bases available:
  `yan_equivalent = 0.10 gN/g product`, and
  `real_yan = 0.9431 * 0.0415 = 0.0391 gN/g product`.
- SpringFerm amino-acid distribution is currently normalized over tracked free
  amino acids present in the provided summary table: phenylalanine, leucine and
  valine. Methionine and tyrosine are recorded as missing from that summary and
  set to zero until the full certificate is encoded.

OIV references:

- https://www.oiv.int/standards/international-code-of-oenological-practices/annexes/maximum-acceptable-limits
- https://www.oiv.int/sites/default/files/publication/2025-04/CPO%202025%20EN.pdf

## Volatilization hook

The scaffold includes `VaporLiquidVolatilizationModel` as a small first-order
aroma loss hook over the six aroma states. It is not a validated L-V
equilibrium model yet. It is present so that a later liquid-vapor equilibrium
formulation can be wired without redesigning the control schedule API.

## Preview script

Use `scripts/main_dynamic_control_schedule_preview.jl` to export schedule CSVs
without solving ODE/LP/MPCC problems. Useful environment variables:

- `DFBA_DYNAMIC_CONTROL_HORIZON_HOURS`, default `168`.
- `DFBA_DYNAMIC_CONTROL_INTERVAL_HOURS`, default `12`.
- `DFBA_DYNAMIC_TEMPERATURE_VALUES_C`, comma-separated target values.
- `DFBA_DYNAMIC_FDA_DOSES_G_L`, comma-separated FDA doses per addition time.
- `DFBA_DYNAMIC_ORG_DOSES_G_L`, comma-separated organic doses per addition
  time.
- `DFBA_DYNAMIC_CONTROL_OUTPUT_DIR`, default
  `outputs/dynamic_control_preview`.

## Sequential dynamic-control export script

Use `scripts/main_export_reduced_dfba_dynamic_controls.jl` for the first local
dynamic-control simulations. It uses the same dynamic-control environment
variables as the preview script, then calls `simulate_reduced_dfba` with
`dynamic_control_schedule=schedule`.

Conservative defaults:

- `DFBA_DYNAMIC_TFINAL_HOURS=24`.
- `DFBA_DYNAMIC_SAVEAT_HOURS=1`.
- `DFBA_DYNAMIC_RECONSTRUCT_FLUXES=false`.
- `DFBA_DYNAMIC_WRITE_PLOTS=true`.
- `DFBA_DYNAMIC_OUTPUT_DIR=results/reduced_dfba_dynamic_controls_latest`.

Suggested workflow:

1. Export and inspect the schedule preview.
2. Run 24 h dynamic sequential export.
3. If stable, run 48 h.
4. If stable and biologically sensible, run 168 h and compare against the
   current static-control sequential reference.

## Next integration steps

1. Done: `simulate_reduced_dfba` and `simulate_full_dfba` accept an optional
   `dynamic_control_schedule`.
2. Done: `dfba_rhs!` evaluates time-dependent temperature through
   `dynamic_zenteno_parameters(schedule, t)`.
3. Done: FDA and organic nutrient pump profiles enter as smooth RHS rates, not
   as discontinuous state jumps.
4. Done: saved-state flux reconstruction uses the saved time to rebuild the
   effective temperature at each point.
5. Done: `scripts/main_dynamic_control_schedule_preview.jl` exports CSV
   previews for candidate temperature and nutrient profiles before running
   optimization.
6. Done: `scripts/main_export_reduced_dfba_dynamic_controls.jl` exports
   dynamic sequential simulations plus schedule CSVs and optional plots.
7. Done: `src/Optimization/dynamic_control_objective.jl` defines the first
   white-wine objective layer: residual sugar, aroma desirability, cooling
   energy proxy, FDA/organic dose, smoothness, and numerical health penalties.
8. Done: `scripts/main_dynamic_control_objective_smoke.jl` evaluates a small
   candidate set for temperature + FDA + SpringFerm schedules.
9. Done: `dynamic_control_candidate_designs` generates a capped first-pass DOE
   over smooth white-wine temperature profiles and FDA/SpringFerm nutrient
   strategies. The objective script can use it with
   `DFBA_DYNAMIC_CONTROL_OPT_CANDIDATE_SET=first_pass`.
10. Done: capped first-pass DOE/Pareto smokes were run through 168 h under
    Slurm and remained numerically healthy.
11. Done: the objective script now writes gate columns, a shortlist CSV, Pareto
    SVG plots, and selected-candidate trajectory/control SVG plots.
12. Done: a 168 h DOE with 24 candidates, gates, shortlist and plots completed
    under Slurm.
13. Done: selected three fixed control policies from the 168 h DOE for MPCC
    replay methodology:
    `cool18_warm22__springferm_early_0p4`,
    `cool18_warm22__springferm_split_0p1_0p1`, and
    `flat20__fda_split_0p5_0p5`.
14. Done: `scripts/main_dynamic_control_policy_selection.jl` writes
    `dynamic_control_policy_selection.csv` and
    `dynamic_control_policy_selection.toml` with explicit
    `control_policy_ready` and `mpcc_fixed_control_replay_ready` flags.
15. Done: `dynamic_control_schedule` is threaded through the reduced MPCC
    collocation RHS and dynamic-bound expressions as a fixed profile.
16. Done: `scripts/main_reduced_mpcc_fixed_control_policy_preflight.jl` builds
    no-solver fixed-control MPCC preflights from the selected policy CSV.
17. Done: a 24 h, `nfe=2` fixed-control MPCC preflight built all three selected
    policies with `mpcc_fixed_control_replay_ready=true` and no structural
    degree-of-freedom warning.
18. Done: guarded fixed-control solve attempts now protect residual-feasible
    `pre_solve_start_values` when small post-solve Ipopt budgets degrade strict
    residual gates. This makes fixed-control promotion/rejection explicit.
19. Done: `DynamicControlDecisionSpec` defines the first auditable scaffold for
    freeing controls: 12 h temperature targets, FDA doses, and organic doses
    with starts, bounds, local trust regions, and locked/free slot masks.
20. Done: `scripts/main_dynamic_control_liberated_spec.jl` exports a no-solver,
    no-simulation decision spec from the selected policy CSV. It is the bridge
    from fixed-control replay to embedded MPCC control variables.
21. Next: wire `DynamicControlDecisionSpec` variables into the reduced MPCC RHS
    and dynamic-bound expressions, starting with a very small 24 h pilot.

## First liberated-control decision spec

Generated under Slurm on 2026-06-12:

- Job: `729421`
- Root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_liberated_spec_20260612_095926`
- Base policy:
  `cool18_warm22__springferm_early_0p4`
- Spec CSV:
  `/home/cltorrealba/mpcc_runs/dynamic_control_liberated_spec_20260612_095926/dynamic_control_liberated_decision_spec.csv`
- Start schedule CSV:
  `/home/cltorrealba/mpcc_runs/dynamic_control_liberated_spec_20260612_095926/dynamic_control_liberated_start_schedule.csv`

Settings:

- Temperature slots freed: `[1, 2]`, corresponding to 0 h and 12 h targets.
- Nutrient addition slot freed: `[1]`, corresponding to 12 h addition.
- Trust regions:
  `temperature +/-0.5 C`, `FDA +/-0.25 g/L`, `organic +/-0.05 g/L`.
- Global hard bounds remain `15 <= T <= 25 C`, FDA solution OIV-equivalent
  limit, and nonnegative nutrient doses.

Interpretation:

- This is not yet a fully simultaneous-control MPCC solve.
- It is the variable/bounds/start contract needed to make the first embedded
  dynamic-control MPCC pilot auditable and reproducible.
- The fixed-control guarded candidate-selection layer remains mandatory before
  promoting any post-solve values.
