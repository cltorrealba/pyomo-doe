# Dynamic-Control Fixed-Control MPCC Homotopy, 2026-06-22

Purpose: validate a post fixed-control homotopy layer that turns residual-feasible
MPCC starts into post-solve candidates closer to strict trajectory readiness,
without using the dynamic-control objective and without moving controls for
scientific optimization.

Cluster policy: all solves below were run through Slurm on `full` with MA86,
limited-memory Hessian, `OPENBLAS_NUM_THREADS=1`, no GPU, and HSL loaded from
`$HOME/opt/hsl/libhsl-2025.7.21/lib/libhsl.so`.

## Method Changes

- Tau continuation now records one row per stage in
  `reduced_mpcc_fixed_control_policy_tau_continuation_stages.csv`.
- Stage advance is gated by:
  - structural residual ratio: `MPCC_TAU_STAGE_ADVANCE_MAX_STRUCTURAL_RATIO`
  - complementarity ratio:
    `max(max_lower_complementarity, max_upper_complementarity) / tau <= MPCC_TAU_STAGE_ADVANCE_MAX_COMPLEMENTARITY_RATIO`
- Recovery-based stage continuation is disabled by default through
  `MPCC_TAU_STAGE_RECOVERY_CONTINUE=0`, so a failed stage cannot silently advance.
- The Slurm wrapper logs the tau schedule, stage iteration budgets, advance
  gates, start JLS, and whether default start initializers/sequential simulation
  were skipped.

## h96 Validation

Checkpoint chain:

1. `s4_compgate` established a post-solve, residual-feasible,
   trajectory-ready candidate at `tau=1.5e-4`.
2. `s5_lowtau` continued from s4 and selected `tau=5e-5`.
3. `s6_strict_tau` continued from s5 and selected `tau=1e-5`.

Final h96 run:

- Job: `747553`
- Node/partition: `n14` / `full`
- Run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_homotopy_h96_s6_strict_tau_20260622_130132`
- Seed:
  `/home/cltorrealba/mpcc_runs/dynamic_control_homotopy_h96_s5_lowtau_20260622_120820/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- Schedule: `4e-5,3e-5,2e-5,1.5e-5,1e-5`
- Stage max iters: `60,80,100,120,160`
- Result: `LOCALLY_SOLVED`, `FEASIBLE_POINT`
- Selected candidate source: `post_solve_values`
- Selected tau: `1.0e-5`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=true`
- `post_solve_candidate_accepted=true`

Final selected residuals:

| metric | value |
| --- | ---: |
| max_rhs_residual | `1.7959680097268116e-10` |
| max_collocation_integration_residual | `1.3499618090051513e-14` |
| max_continuity_residual | `1.2732870313669764e-14` |
| max_mass_balance_residual | `5.955710169491552e-8` |
| max_lower_bound_violation | `4.641829067889646e-9` |
| max_upper_bound_violation | `5.000184305074015e-9` |
| max_stationarity_residual | `2.773993283464035e-9` |
| max_lower_complementarity_residual | `9.960498192762193e-6` |
| max_upper_complementarity_residual | `9.876211687987414e-6` |

Dominant residual remains lower complementarity, as expected for Scholtes tau.
The final complementarity ratio is `0.996`, while strict collocation and
continuity are at machine-scale for this run.

Stage summary:

| tau | status | selected | dominant | max lower comp | comp/tau |
| ---: | --- | --- | --- | ---: | ---: |
| `4.0e-5` | `LOCALLY_SOLVED` | false | lower complementarity | `3.9904309094949725e-5` | `0.997607727373743` |
| `3.0e-5` | `LOCALLY_SOLVED` | false | lower complementarity | `2.9887090982830343e-5` | `0.9962363660943447` |
| `2.0e-5` | `LOCALLY_SOLVED` | false | lower complementarity | `1.9921228014788282e-5` | `0.9960614007394141` |
| `1.5e-5` | `LOCALLY_SOLVED` | false | lower complementarity | `1.4941223178661744e-5` | `0.9960815452441162` |
| `1.0e-5` | `LOCALLY_SOLVED` | true | lower complementarity | `9.960498192762193e-6` | `0.9960498192762193` |

Interpretation: the fixed-control homotopy layer is validated on h96. It can
reduce complementarity by an order of magnitude while preserving primal
feasibility, strict trajectory extraction readiness, and control plumbing.

## h168 Validation

Added wrapper:

`repro/submit_cluster_uc_dynamic_control_homotopy_h168.sh`

Default h168 seed is the best exportable h168 JLS currently available:

`/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s12_fluxdual_flat22_h168_tau1em3_iter6_repair2_20260620_134554/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`

This seed is residual-feasible but not trajectory-ready and has a much larger
structural residual than the h96 seed, so h168 should start conservatively:

- schedule `1e-3,7e-4,5e-4`
- recovery disabled
- complementarity advance ratio limit `1.25`
- 8 CPUs, 64 GB, 8 h default

First h168 run:

- Job: `748619`
- Node/partition: `n14` / `full`
- Run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_homotopy_h168_s1_from_s12_20260622_141300`
- Seed:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s12_fluxdual_flat22_h168_tau1em3_iter6_repair2_20260620_134554/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- Schedule: `1e-3,7e-4,5e-4`
- Stage max iters: `30,45,60`
- Result: `LOCALLY_SOLVED`, `FEASIBLE_POINT`
- Selected candidate source: `post_solve_values`
- Selected tau: `5.0e-4`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=true`
- `post_solve_candidate_accepted=true`

Final selected residuals:

| metric | value |
| --- | ---: |
| max_rhs_residual | `1.2224062563613927e-8` |
| max_collocation_integration_residual | `1.749092307532793e-11` |
| max_continuity_residual | `1.749092307532793e-11` |
| max_mass_balance_residual | `5.980129141555136e-8` |
| max_lower_bound_violation | `5.165876688375022e-9` |
| max_upper_bound_violation | `5.16859216570846e-9` |
| max_stationarity_residual | `1.5117833348803793e-14` |
| max_lower_complementarity_residual | `4.996062086235831e-4` |
| max_upper_complementarity_residual | `4.95571197580028e-4` |

Stage summary:

| tau | status | selected | dominant | max lower comp | comp/tau |
| ---: | --- | --- | --- | ---: | ---: |
| `1.0e-3` | `ITERATION_LIMIT` | false | lower complementarity | `9.999939124859653e-4` | `0.9999939124859653` |
| `7.0e-4` | `ITERATION_LIMIT` | false | lower complementarity | `7.000055359945222e-4` | `1.000007908563603` |
| `5.0e-4` | `LOCALLY_SOLVED` | true | lower complementarity | `4.996062086235831e-4` | `0.9992124172471663` |

Interpretation: the h168 checkpoint moved from an exportable but non-ready seed
to a post-solve, residual-feasible, trajectory-ready candidate. The strict
collocation and continuity defects contracted to `1.75e-11`; the dominant
residual is now the expected Scholtes complementarity product at approximately
tau. This validates the same homotopy/regularization layer at h168.

Next h168 step: continue from the `tau=5e-4` selected candidate with a finer
low-tau schedule, for example `4e-4,3e-4,2e-4`, preserving recovery disabled
and the complementarity advance gate.

Second h168 run:

- Job: `750148`
- Node/partition: `n14` / `full`
- Run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_homotopy_h168_s2_lowtau_20260622_155646`
- Seed:
  `/home/cltorrealba/mpcc_runs/dynamic_control_homotopy_h168_s1_from_s12_20260622_141300/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- Schedule: `4e-4,3e-4,2e-4`
- Stage max iters: `45,70,100`
- Result: `LOCALLY_SOLVED`, `FEASIBLE_POINT`
- Selected candidate source: `post_solve_values`
- Selected tau: `2.0e-4`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=true`
- `post_solve_candidate_accepted=true`

Final selected residuals:

| metric | value |
| --- | ---: |
| max_rhs_residual | `2.0104836925046582e-10` |
| max_collocation_integration_residual | `2.504454894384265e-14` |
| max_continuity_residual | `2.504454894384265e-14` |
| max_mass_balance_residual | `5.999518186839813e-8` |
| max_lower_bound_violation | `5.516689498134667e-9` |
| max_upper_bound_violation | `5.519611237066892e-9` |
| max_stationarity_residual | `1.547689658408019e-14` |
| max_lower_complementarity_residual | `1.9976813941004467e-4` |
| max_upper_complementarity_residual | `1.978975298764644e-4` |

Stage summary:

| tau | status | selected | dominant | max lower comp | comp/tau |
| ---: | --- | --- | --- | ---: | ---: |
| `4.0e-4` | `LOCALLY_SOLVED` | false | lower complementarity | `3.9966104829938293e-4` | `0.9991526207484572` |
| `3.0e-4` | `LOCALLY_SOLVED` | false | lower complementarity | `2.9968255806095645e-4` | `0.9989418602031882` |
| `2.0e-4` | `LOCALLY_SOLVED` | true | lower complementarity | `1.9976813941004467e-4` | `0.9988406970502233` |

Interpretation: h168 low-tau continuation is validated through `tau=2e-4`.
The strict trajectory defects remain at machine scale; complementarity contracts
linearly with tau and remains the dominant residual. The `2e-4` stage showed a
large initial primal jump and dual rebound, but recovered without restoration,
which supports using small guarded continuation rather than one-shot polishing.
