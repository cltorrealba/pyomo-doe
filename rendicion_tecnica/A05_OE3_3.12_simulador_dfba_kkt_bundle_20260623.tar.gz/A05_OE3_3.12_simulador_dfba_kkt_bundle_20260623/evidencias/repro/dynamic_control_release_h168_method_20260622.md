# h168 Dynamic-Control Release Method, 2026-06-22

Purpose: release a small number of thermal/nutrient control variables from the
validated h168 fixed-control MPCC seed without losing the residual-feasible and
trajectory-ready gates. This is a diagnostic stage, not the final dynamic
optimization objective.

## Stable Seed

Use the fixed-control h168 tau homotopy seed:

`$HOME/mpcc_runs/dynamic_control_homotopy_h168_s2_lowtau_20260622_155646/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`

Known seed status:

- selected candidate source: `post_solve_values`
- complementarity tau: `2e-4`
- residual feasible: true
- trajectory ready: true
- dominant residual: Scholtes complementarity at tau scale
- collocation/continuity: near machine precision

The seed is numerically stable but its dynamic control values are not exactly
the nominal `flat22__none` policy. The release wrapper therefore centers start
values and fixed bounds on the seed controls through indexed offsets:

- temperature: slots `1,3,6`
- FDA: slots `1,3,5`
- organic: slots `1,3,5`

This avoids the failure mode where a candidate JLS has valid nonzero controls
but the generated decision spec fixes the corresponding bounds at the nominal
policy values.

## Wrapper

Submit diagnostics with:

`bash repro/submit_cluster_uc_dynamic_control_release_h168.sh temperature`

`bash repro/submit_cluster_uc_dynamic_control_release_h168.sh fda`

`bash repro/submit_cluster_uc_dynamic_control_release_h168.sh organic`

`bash repro/submit_cluster_uc_dynamic_control_release_h168.sh temperature_fda`

`bash repro/submit_cluster_uc_dynamic_control_release_h168.sh temperature_organic`

`bash repro/submit_cluster_uc_dynamic_control_release_h168.sh temperature_then_organic`

`bash repro/submit_cluster_uc_dynamic_control_release_h168.sh organic_then_temperature`

Cluster defaults:

- Slurm only, no solves on login.
- partition: `full`
- `--ntasks=1`
- `--cpus-per-task=$OMP_NUM_THREADS`
- `OMP_NUM_THREADS=8`
- `OPENBLAS_NUM_THREADS=1`
- linear solver: MA86 through cluster HSL
- Hessian: limited-memory
- no tau continuation in these release diagnostics
- no collocation repair during the release solve

## Diagnostic Modes

Temperature mode:

- free temperature slots: `1,3,6`
- fixed nutrient slots: seed-centered FDA/organic offsets, no free additions
- default trust: `0.25 C`
- objective: direct reward on temperature only

FDA mode:

- fixed temperature: seed-centered offsets
- free addition slots: `1,3,5`
- FDA trust: `0.05 g/L`
- organic trust: `0.0 g/L`
- objective: direct reward on FDA only

Organic mode:

- fixed temperature: seed-centered offsets
- free addition slots: `1,3,5`
- FDA trust: `0.0 g/L`
- organic trust: `0.02 g/L`
- objective: direct reward on organic addition only

For FDA and organic, the shared addition indices are unavoidable in the current
decision-spec API; the non-target nutrient is isolated by a zero trust region.

Combined diagnostic modes:

- `temperature_fda` frees temperature slots `1,3,6` and FDA slots `1,3,5`,
  keeping organic fixed. Default trust regions are deliberately narrower than
  the one-family diagnostics: `0.10 C` and `0.0125 g/L` FDA.
- `temperature_organic` frees temperature slots `1,3,6` and organic slots
  `1,3,5`, keeping FDA fixed. Default trust regions are `0.10 C` and
  `0.005 g/L` organic.

These combined modes are prepared for the next stage and should be launched
only after at least one nutrient-family diagnostic reaches both gates:
residual-feasible and trajectory-ready.

Staged combined modes:

- `temperature_then_organic` starts from the promotable temperature-release
  candidate `751615`, centers the temperature offsets on that candidate, fixes
  temperature with a zero trust region, and releases only organic additions
  with a very small default trust region of `0.0025 g/L`. The default direct
  organic reward is `0.02` with reference regularization `0.20`.
- `organic_then_temperature` starts from the promotable organic-release
  candidate `751679`, centers the organic offsets on that candidate, fixes
  organic additions with a zero trust region, and releases temperature with a
  small default trust region of `0.025 C`. The default direct temperature
  reward is `0.05` with reference regularization `0.20`.

These modes test whether the failed two-family release from the fixed-control
seed was mainly a start-quality issue. They are intentionally one-family
second-stage releases: the first family has already moved in the incoming
candidate and is held fixed while the second family is introduced.

## Success Criteria

A release diagnostic is healthy only if:

- Ipopt loads the h168 seed and starts with small primal infeasibility.
- No early restoration phase appears.
- Post-solve source is `post_solve_values`.
- `candidate_residual_feasible=true`.
- `candidate_trajectory_ready=true`.
- Collocation and continuity remain near the fixed-control seed scale.
- The target control family moves in the expected direction.
- Non-target control families remain fixed, or their drift is explicitly
  documented.

## Current Evidence

First temperature pilot:

- job: `751569`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_temperature_20260622_192048`
- solver status: `LOCALLY_SOLVED`
- selected candidate source: `post_solve_values`
- residual feasible: true
- trajectory ready: true
- initial Ipopt infeasibility: `inf_pr=6.00e-08`
- target movement: temperature slots `1,3,6` reached the upper trust bound
  `22.25 C`
- caveat: FDA and organic slots were also free in that first wrapper version,
  so small nutrient drift occurred. The seed-centered wrapper supersedes this
  for subsequent nutrient diagnostics.

FDA seed-centered diagnostic:

- job: `751585`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_fda_seedcentered_20260622_200859`
- solver status: `ITERATION_LIMIT`
- selected candidate source: `post_solve_values`
- residual feasible: true
- trajectory ready: false
- initial Ipopt infeasibility: `inf_pr=6.00e-08`
- final Ipopt constraint violation: `5.59e-08`
- final Ipopt dual infeasibility: `9.91`
- target movement: FDA slots `1,3,5` increased by
  `0.0499996`, `0.0367720`, and `0.0320469 g/L`
- non-target movement: temperature `0.0 C`, organic `0.0 g/L`
- interpretation: the h168 MPCC responds to FDA as a simultaneous control
  without breaking primal residuals, but the direct FDA reward is too sharp for
  promotion at `max_iter=40`. Use as a diagnostic, not a handoff.

Organic seed-centered diagnostic:

- job: `751587`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_organic_seedcentered_20260622_201549`
- solver status: `ITERATION_LIMIT`
- selected candidate source: `post_solve_values`
- residual feasible: true
- trajectory ready: false
- initial Ipopt infeasibility: `inf_pr=6.00e-08`
- final Ipopt constraint violation: `1.01e-07`
- final Ipopt dual infeasibility: `0.958`
- target movement: organic slots `1,3,5` increased by `0.02 g/L` each
- non-target movement: temperature `0.0 C`, FDA `0.0 g/L`
- interpretation: the h168 MPCC responds to organic nutrient additions as a
  simultaneous control without breaking primal residuals, but the direct
  organic reward also remains a diagnostic, not a handoff.

Temperature seed-centered polish:

- job: `751615`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_temperature_seedcentered_polish80_20260622_213417`
- start:
  `$HOME/mpcc_runs/dynamic_control_release_h168_temperature_seedcentered_20260622_205831/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- solver status: `LOCALLY_SOLVED`
- primal status: `FEASIBLE_POINT`
- selected candidate source: `post_solve_values`
- residual feasible: true
- trajectory ready: true
- Ipopt iterations: `79`
- final Ipopt infeasibility:
  - constraint violation: `6.31e-11`
  - dual infeasibility: `9.03e-7`
  - bound violation: `2.22e-7`
  - complementarity: `1.22e-11`
- diagnostic residuals:
  - max RHS: `1.22e-10`
  - max collocation: `2.63e-11`
  - max continuity: `2.63e-11`
  - max mass balance: `6.00e-8`
  - max lower complementarity: `1.999948e-4`
  - max upper complementarity: `1.999688e-4`
- target movement:
  - only temperature slots `1,3,6` were free
  - all three reached the upper trust bound relative to the seed:
    `+0.25 C`
  - optimized temperatures:
    - slot 1, `0 h`: `22.32880318885553 C`
    - slot 3, `24 h`: `22.291538231461743 C`
    - slot 6, `60 h`: `22.289378195714914 C`
- non-target movement:
  - FDA sum delta: `0.0 g/L`
  - organic sum delta: `0.0 g/L`
- terminal diagnostics:
  - glucose: `81.95928102787049 g/L`
  - fructose: `77.13961407411766 g/L`
  - total sugar: `159.09889510198815 g/L`
  - isoamyl alcohol proxy: `0.0028987203785931144 g/L`
- plots:
  `$HOME/mpcc_runs/dynamic_control_release_h168_temperature_seedcentered_polish80_20260622_213417/case/plots/optimized_control_profiles.png`
- interpretation: this is the first seed-centered h168 partially-free
  dynamic-control candidate that is both residual-feasible and
  trajectory-ready after post-solve. It is promotable as a diagnostic
  temperature-release handoff, not as the final thermal-nutrient optimum.

FDA soft-reg diagnostic:

- job: `751637`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_fda_softreg_20260622_223320`
- settings:
  - direct FDA reward: `1.0`
  - FDA trust: `0.05 g/L`
  - reference regularization: `0.05`
  - Ipopt max iterations: `80`
- solver status: `ITERATION_LIMIT`
- primal status: `NEARLY_FEASIBLE_POINT`
- selected candidate source: `pre_solve_start_values`
- post-solve residual feasible: false
- selected residual feasible: true
- selected trajectory ready: false
- final Ipopt infeasibility:
  - constraint violation: `4.80e-6`
  - dual infeasibility: `1.41`
  - complementarity: `3.24e-8`
- target movement in rejected post-solve:
  - FDA sum delta: `+0.07147926512980561 g/L`
  - max FDA slot delta: `+0.02439004201338214 g/L`
- non-target movement:
  - temperature: `0.0 C`
  - organic: `0.0 g/L`
- plots:
  `$HOME/mpcc_runs/dynamic_control_release_h168_fda_softreg_20260622_223320/case/plots/optimized_control_profiles.png`
- interpretation: FDA remains a real coupled control, but this reward/trust
  combination is still too aggressive. The post-solve candidate is rejected as
  not residual-feasible, so no FDA handoff should be promoted from this run.

Organic soft-reg diagnostic:

- job: `751636`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_organic_softreg_20260622_223320`
- settings:
  - direct organic reward: `1.0`
  - organic trust: `0.02 g/L`
  - reference regularization: `0.02`
  - Ipopt max iterations: `80`
- solver status: `ITERATION_LIMIT`
- primal status: `FEASIBLE_POINT`
- selected candidate source: `post_solve_values`
- post-solve residual feasible: true
- selected residual feasible: true
- selected trajectory ready: false
- final Ipopt infeasibility:
  - constraint violation: `8.16e-9`
  - dual infeasibility: `1.29e-4`
  - bound violation: `9.99e-9`
  - complementarity: `1.54e-11`
- diagnostic residuals:
  - max RHS: `1.55e-8`
  - max collocation: `3.48e-14`
  - max continuity: `5.40e-13`
  - max mass balance: `6.02e-8`
  - max lower complementarity: `1.996421e-4`
  - max upper complementarity: `1.974795e-4`
- target movement:
  - organic slots `1,3,5` moved by approximately `+0.01 g/L` each
  - organic sum delta: `+0.029999933950234488 g/L`
- non-target movement:
  - temperature: `0.0 C`
  - FDA: `0.0 g/L`
- terminal diagnostics:
  - glucose: `81.76494787235404 g/L`
  - fructose: `77.07401660345757 g/L`
  - total sugar: `158.83896447581162 g/L`
  - isoamyl alcohol proxy: `0.012761441657484038 g/L`
- plots:
  `$HOME/mpcc_runs/dynamic_control_release_h168_organic_softreg_20260622_223320/case/plots/optimized_control_profiles.png`
- interpretation: this is a near-promotable nutrient release candidate. It is
  post-solve residual-feasible with clean collocation/continuity and isolated
  organic movement, but it is not trajectory-ready because Ipopt stopped at
  `ITERATION_LIMIT`. The proper next step is a polish from this selected
  candidate JLS, without widening the control band.

Follow-up jobs launched:

- organic polish:
  - job: `751679`
  - run root:
    `$HOME/mpcc_runs/dynamic_control_release_h168_organic_softreg_polish160_20260623_005208`
  - start:
    `$HOME/mpcc_runs/dynamic_control_release_h168_organic_softreg_20260622_223320/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
  - purpose: recover a solver status that permits trajectory extraction while
    preserving the same organic release band and regularization.
- FDA damped diagnostic:
  - job: `751680`
  - run root:
    `$HOME/mpcc_runs/dynamic_control_release_h168_fda_damped_reward0p25_reg0p10_trust0p025_20260623_005208`
  - purpose: test whether lower direct reward, stronger reference
    regularization, and a smaller FDA trust region can move FDA without
    rejecting the post-solve candidate.
  - result: cancelled manually before `solve_attempt.csv` was written.
  - cancellation reason:
    - primal residual stayed clean
    - dual infeasibility initially approached `~1e-5`, then became erratic
    - later Ipopt jumped to `inf_du=1.01e3` and entered regularized steps
    - FDA was a secondary diagnostic and no longer a credible promotable run.

Organic polish result:

- job: `751679`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_organic_softreg_polish160_20260623_005208`
- start:
  `$HOME/mpcc_runs/dynamic_control_release_h168_organic_softreg_20260622_223320/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- solver status: `LOCALLY_SOLVED`
- primal status: `FEASIBLE_POINT`
- Ipopt iterations: `5`
- selected candidate source: `post_solve_values`
- residual feasible: true
- trajectory ready: true
- final Ipopt infeasibility:
  - constraint violation: `5.57e-12`
  - dual infeasibility: `4.66e-7`
  - complementarity: `1.05e-11`
- diagnostic residuals:
  - max RHS: `1.55e-8`
  - max collocation: `1.37e-14`
  - max continuity: `1.44e-12`
  - max mass balance: `5.94e-8`
  - max lower complementarity: `1.996418e-4`
  - max upper complementarity: `1.974784e-4`
- target movement:
  - organic slots `1,3,5` moved by approximately `+0.01 g/L` each
  - organic sum delta: `+0.02999997493246407 g/L`
- non-target movement:
  - temperature: `0.0 C`
  - FDA: `0.0 g/L`
- plots:
  `$HOME/mpcc_runs/dynamic_control_release_h168_organic_softreg_polish160_20260623_005208/case/plots/optimized_control_profiles.png`
- interpretation: this is the first h168 nutrient-family release candidate
  that is both residual-feasible and trajectory-ready after post-solve. It is
  promotable as a diagnostic organic-release handoff.

Temperature plus organic combined diagnostic:

- job: `751686`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_temperature_organic_reg0p05_20260623_010906`
- start: fixed-control h168 seed
- settings:
  - free temperature slots: `1,3,6`
  - free organic slots: `1,3,5`
  - FDA fixed
  - temperature trust: `0.10 C`
  - organic trust: `0.005 g/L`
  - direct temperature reward: `0.25`
  - direct organic reward: `0.10`
  - reference regularization: `0.05`
  - CPUs: `4`
- purpose: test whether two control families can move together while
  preserving the same residual-feasible and trajectory-ready gates.
- result: cancelled manually after Ipopt stagnated near iter `20`.
- cancellation reason:
  - primal residual stayed clean (`inf_pr` near `5e-12`)
  - dual infeasibility stalled near `1.21e-3`
  - line search accepted tiny primal steps (`alpha_pr` around `1e-10`) with
    `ls=31`
  - the job was no longer a good candidate for promotion and was consuming
    resources without useful progress.

Temperature plus organic soft combined diagnostic:

- job: `751706`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_temperature_organic_soft_reg0p10_20260623_022320`
- start: fixed-control h168 seed
- settings:
  - free temperature slots: `1,3,6`
  - free organic slots: `1,3,5`
  - FDA fixed
  - temperature trust: `0.05 C`
  - organic trust: `0.0025 g/L`
  - direct temperature reward: `0.10`
  - direct organic reward: `0.02`
  - reference regularization: `0.10`
  - CPUs: `4`
- purpose: repeat the combined-control diagnostic with softer incentives after
  the first combined run stalled in line search.
- result: cancelled manually before `solve_attempt.csv` was written.
- cancellation reason:
  - primal residual stayed clean
  - dual infeasibility briefly reached `2.09e-6` but did not close
  - subsequent iterations drifted back to `O(1e-2)` dual infeasibility with
    small steps and regularization
  - the run was no longer a credible promotable combined-control candidate.

Combined-control interpretation:

- temperature-only and organic-only releases are promotable diagnostic
  candidates;
- FDA release responds but remains numerically less robust than organic under
  direct reward diagnostics;
- temperature plus organic simultaneous release is not yet robust from the
  fixed-control seed, even with narrower bands and stronger regularization;
- the next combined attempt should not simply keep shrinking rewards blindly.
  Better next options are:
  - start from the promotable temperature or organic release candidate and
    center trust regions on that start;
  - release the second family with a one-sided or asymmetric trust band;
  - use a staged solve where temperature is free and organic is softly fixed,
    then organic is released in a second Slurm job;
  - only after a combined diagnostic closes, switch to the reformulated dynamic
    objective.

Comparison table:

- CSV:
  `repro/generated/dynamic_control_release_h168_summary_20260623.csv`
- included rows:
  - fixed-control h168 seed baseline
  - temperature polish `751615`
  - FDA soft-reg `751637`
  - organic soft-reg `751636`
  - organic polish `751679`
- note: control deltas in the fixed-control baseline reflect loading the
  embedded dynamic-control schedule from the seed, not a released-control
  post-solve movement.

## Current Interpretation

The release layer now demonstrates real control response:

- temperature moves to the expected trust-region boundary;
- FDA moves independently while temperature and organic remain fixed;
- organic moves independently while temperature and FDA remain fixed;
- dynamic-control variables are coupled to RHS residuals and dynamic flux bounds;
- primal residual health is preserved in all three diagnostics.

The limiting issue for nutrient diagnostics is not control freezing or
collocation breakage. It is KKT/status closure under direct nutrient rewards.
Temperature can be polished into a promotable partially-free post-solve
candidate with `max_iter=80`. Organic release now has a post-solve
residual-feasible candidate with clean collocation/continuity and isolated
control movement, but still needs an Ipopt status that permits trajectory
extraction. FDA needs a more damped formulation before it should be promoted.

The next dynamic-control stage should promote only candidates that satisfy both
gates: residual-feasible and trajectory-ready. Once one nutrient family closes
with those gates, the correct progression is to combine temperature plus that
nutrient in the same conservative release band before switching from direct
diagnostic rewards to the reformulated dynamic objective.

As of this protocol version, the combined temperature plus organic release has
not yet produced a promotable post-solve candidate. The nearest safe handoffs
remain the temperature-only polish `751615` and organic-only polish `751679`.

## Next Staged Release Plan

The next combined-control goal should proceed in two Slurm branches:

1. Start from temperature polish `751615` and release organic with a very small
   trust region. Success means the resulting candidate remains
   residual-feasible and trajectory-ready while organic slots move away from the
   temperature-only handoff.
2. Start from organic polish `751679` and release temperature with a very small
   trust region. Success means the resulting candidate remains
   residual-feasible and trajectory-ready while temperature slots move away from
   the organic-only handoff.

If either branch closes cleanly, use that selected candidate as the start for a
true two-family polish with both families free in small bands. FDA should remain
fixed until temperature plus organic closes; then FDA can be introduced with a
separate damped branch because FDA has shown response but weaker KKT closure.

## Staged Release Evidence, 2026-06-23

Temperature then organic branch:

- job: `751801`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_temperature_then_organic_20260623_084758`
- start:
  temperature polish `751615`
- settings:
  - temperature offsets centered on `751615` and fixed with zero trust
  - organic trust: `0.0025 g/L`
  - direct organic reward: `0.02`
  - reference regularization: `0.20`
- result: cancelled manually after Ipopt lost KKT progress.
- cancellation reason:
  - primal residual stayed small
  - dual infeasibility improved to `4.17e-5` at iter `8`
  - after iter `15`, dual infeasibility drifted back to `O(1e-2)`
  - by iter `32` to `37`, dual infeasibility was `~5e-2` to `7e-2`
    with regularization and small filter steps
  - the run was no longer a credible promotable handoff.

Organic then temperature branch:

- job: `751802`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_organic_then_temperature_20260623_084758`
- start:
  organic polish `751679`
- settings:
  - organic offsets centered on `751679` and fixed with zero trust
  - temperature trust: `0.025 C`
  - direct temperature reward: `0.05`
  - reference regularization: `0.20`
- solver status: `OTHER_ERROR`
- Ipopt exit: restoration failed
- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: false
- diagnostic residuals:
  - max RHS: `2.82e-8`
  - max collocation: `1.90e-14`
  - max continuity: `8.84e-12`
  - max mass balance: `6.01e-8`
  - max lower complementarity: `1.99636e-4`
  - max upper complementarity: `1.97477e-4`
- control movement:
  - temperature max delta: `0.024930150582857635 C`
  - FDA sum delta: `0.0 g/L`
  - organic sum delta: `0.0 g/L`
- interpretation:
  the MPCC responded to temperature on top of the organic-release candidate
  without breaking primal dynamics, but the direct reward plus regularization
  pushed Ipopt into restoration. This candidate is a useful residual-feasible
  start, not a promotable handoff.

Organic then temperature fixed-control polish:

- job: `751840`
- run root:
  `$HOME/mpcc_runs/dynamic_control_release_h168_organic_then_temperature_polish_fixed_20260623_102118`
- start:
  selected candidate from `751802`
- settings:
  - temperature, FDA, and organic controls fixed at the `751802` post-solve
    values
  - direct rewards: zero
  - reference regularization: zero
  - objective term count: zero
- solver status: `LOCALLY_SOLVED`
- Ipopt iterations: `0`
- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: true
- diagnostic residuals:
  - max RHS: `2.82e-8`
  - max collocation: `1.90e-14`
  - max continuity: `8.84e-12`
  - max mass balance: `6.01e-8`
  - max lower complementarity: `1.99636e-4`
  - max upper complementarity: `1.97477e-4`
- combined controls:
  - temperature slots:
    - slot 1, `0 h`: `22.10373333943839 C`
    - slot 3, `24 h`: `22.066374232029975 C`
    - slot 6, `60 h`: `22.064198603590114 C`
  - organic slots:
    - slot 1, `12 h`: `0.014331737415019315 g/L`
    - slot 3, `36 h`: `0.01706496561270772 g/L`
    - slot 5, `60 h`: `0.018975414795248134 g/L`
  - FDA slots unchanged from the h168 seed
- terminal diagnostics:
  - total sugar: `158.72425432172997 g/L`
  - isoamyl alcohol proxy: `0.013825159191992873 g/L`
- plots:
  `$HOME/mpcc_runs/dynamic_control_release_h168_organic_then_temperature_polish_fixed_20260623_102118/case/plots/optimized_control_profiles.png`
- interpretation:
  this is the first h168 staged combined temperature plus organic handoff that
  is both residual-feasible and trajectory-ready. It is not the final dynamic
  optimum because the final polish neutralized the objective and fixed controls,
  but it is a valid numerical base for introducing the reformulated dynamic
  objective in small bands around a combined-control trajectory.

## Dynamic Objective Introduction Evidence, 2026-06-23

Gate-150 productivity handoff:

- job: `751856`
- run root:
  `$HOME/mpcc_runs/dynamic_control_objective_from_gate150_h168_productivity_gate150_w3em3_trust2em2_20260623_110459`
- start:
  gate-150 objective-active handoff
  `$HOME/mpcc_runs/dynamic_control_objective_from_staged_h168_productivity_gate150_w1em3_20260623_105518/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- settings:
  - integrated sugar excess objective: gate `150 g/L`, weight `0.003`
  - temperature trust: `0.02 C`
  - organic trust: `0.001 g/L`
  - FDA trust: `0.0 g/L`
  - reference regularization: `0.02`
  - terminal sugar, aroma, nutrient, thermal, and smoothness terms: zero
- solver status: `LOCALLY_SOLVED`
- Ipopt iterations: `0`
- Ipopt start:
  - objective: `3.7980242e-04`
  - `inf_pr=6.01e-08`
  - `inf_du=1.28e-07`
- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: true
- diagnostic residuals:
  - max RHS: `2.82e-8`
  - max collocation: `1.90e-14`
  - max continuity: `8.84e-12`
  - max mass balance: `6.01e-8`
  - max lower complementarity: `1.99636e-4`
  - max upper complementarity: `1.97477e-4`
- control movement:
  - temperature max delta: `0.0 C`
  - FDA sum delta: `0.0 g/L`
  - organic sum delta: `0.0 g/L`
- terminal diagnostics:
  - total sugar: `158.72425432172997 g/L`
  - isoamyl alcohol proxy: `0.013825159191992873 g/L`
- plots:
  `$HOME/mpcc_runs/dynamic_control_objective_from_gate150_h168_productivity_gate150_w3em3_trust2em2_20260623_110459/case/plots/optimized_control_profiles.png`
- interpretation:
  the reformulated productivity objective can be introduced without losing the
  residual-feasible and trajectory-ready gates when the sugar gate is set to an
  operational value compatible with the current kinetic calibration. However,
  this objective is locally inactive from the current start: Ipopt accepts the
  start at iteration zero and no released control moves.

Direct temperature reward diagnostic:

- job: `751862`
- run root:
  `$HOME/mpcc_runs/dynamic_control_direct_temperature_from_gate150_h168_reward1_trust2em2_20260623_111348`
- start:
  selected candidate from job `751856`
- settings:
  - direct temperature reward: `1.0`
  - temperature trust: `0.02 C`
  - FDA and organic trusts: `0.0 g/L`
  - reference regularization: `0.0`
  - productivity, terminal sugar, aroma, nutrient, thermal, and smoothness
    terms: zero
- result: cancelled manually.
- cancellation reason:
  - the direct objective was not locally inactive: initial `inf_du=1.43e-02`
  - Ipopt took small accepted steps, confirming that released temperature
    controls can respond to objective pressure
  - dual infeasibility then jumped to `3.86e1` at iter `3` and remained
    `3.85e1` at iter `4`
  - continuing the job was not a credible path to a promotable handoff.
- interpretation:
  the controls are not frozen. The bottleneck is the local simultaneous
  geometry after controls perturb RHS residuals and dynamic flux bounds.

Micro direct temperature reward diagnostic:

- job: `751866`
- run root:
  `$HOME/mpcc_runs/dynamic_control_direct_temperature_from_gate150_h168_reward1em2_trust5em3_reg2em2_20260623_112408`
- start:
  selected candidate from job `751856`
- settings:
  - direct temperature reward: `0.01`
  - temperature trust: `0.005 C`
  - FDA and organic trusts: `0.0 g/L`
  - reference regularization: `0.02`
  - productivity, terminal sugar, aroma, nutrient, thermal, and smoothness
    terms: zero
- result: cancelled manually.
- cancellation reason:
  - initial `inf_du=1.43e-04`, much healthier than the strong direct reward
  - after small control/state steps, dual infeasibility increased to `6.30e1`
    at iter `3` and `1.26e1` at iter `4`
  - primal infeasibility stayed small, but KKT closure was not moving toward a
    promotable post-solve.
- interpretation:
  merely lowering the direct reward and narrowing the temperature trust reduces
  the initial KKT pressure, but does not remove the dual instability caused by
  the control-to-RHS/dynamic-bounds coupling. The next implementation step
  should not be larger objective weights. It should add a controlled
  continuation layer for released controls: start with fixed combined controls,
  introduce very small control perturbation bands, and damp the induced
  RHS/dynamic-bound update through feasibility projection or staged
  re-linearization before optimizing the full dynamic objective.

Operational conclusion:

- The staged combined h168 candidate from job `751840` remains the current
  promotable combined-control handoff.
- The objective-active gate-150 candidate from job `751856` is also promotable,
  but it has zero control movement.
- Direct temperature rewards demonstrate objective-control coupling, but the
  resulting post-solve path is not yet numerically promotable.
- Do not escalate to gate `5 g/L`, larger direct rewards, FDA release, or a
  full weighted aroma/productivity/cost objective until the released-control
  continuation layer can move controls without dual infeasibility spikes.

## Combined-Control Micro-Continuation Evidence, 2026-06-23

Shifted fixed-control projection:

- job: `751882`
- run root:
  `$HOME/mpcc_runs/dynamic_control_projection_shiftT1mK_repairafter_from_gate150_h168_20260623_114928`
- start:
  selected candidate from job `751856`
- settings:
  - candidate dynamic controls disabled during seed load
  - temperature fixed to the staged profile plus `1e-3 C` on slots `1`, `3`,
    and `6`
  - FDA and organic fixed at the staged combined-control values
  - pre-solve only
  - `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START=1`
  - feasibility projection segments: `1:24;24:48;48:72`
- result:
  - solver status: `OPTIMIZE_NOT_CALLED`
  - selected residual feasible: true
  - selected trajectory ready: false
  - feasibility projection enabled/applied: true/true
  - accepted projection segments: `0` of `3`
  - projection trials: `15`
- diagnostic residuals after restoring the guarded start:
  - max RHS: `2.82e-8`
  - max collocation: `1.90e-14`
  - max continuity: `8.84e-12`
  - max mass balance: `6.01e-8`
- interpretation:
  the projection route is now wired correctly after candidate seeding, but the
  current `primal_structural` guard rejects all damped segment trials. The
  profile itself remains residual-feasible, so the safer continuation move is
  fixed-control polishing rather than accepting projected state changes.

Shifted fixed-control polish:

- job: `751889`
- run root:
  `$HOME/mpcc_runs/dynamic_control_projection_shiftT1mK_polish_from751882_h168_20260623_120124`
- start:
  selected candidate from job `751882`
- settings:
  - temperature, FDA, and organic controls fixed at the shifted values
  - objective terms: zero
  - max iterations: `5`
- solver status: `LOCALLY_SOLVED`
- Ipopt iterations: `0`
- Ipopt start:
  - objective: `0`
  - `inf_pr=6.01e-08`
  - `inf_du=1.00e-12`
- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: true
- diagnostic residuals:
  - max RHS: `2.82e-8`
  - max collocation: `1.90e-14`
  - max continuity: `8.84e-12`
  - max mass balance: `6.01e-8`
  - max lower complementarity: `1.99640e-4`
  - max upper complementarity: `1.97487e-4`
- interpretation:
  this confirms that a tiny fixed control displacement can be promoted after a
  zero-objective polish. It is the numerical bridge used for the first
  simultaneous T/FDA/ORG release.

Combined micro-release:

- job: `751892`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_micro_release_from_shiftT1mK_h168_20260623_120900`
- start:
  selected candidate from job `751889`
- settings:
  - free temperature slots: `1`, `3`, `6`
  - free FDA/organic slots: `1`, `3`, `5`
  - temperature trust: `0.001 C`
  - FDA trust: `1e-5 g/L`
  - organic trust: `1e-5 g/L`
  - direct temperature/FDA/organic rewards: `0.001`
  - reference regularization: `0.05`
  - max iterations: `3`
- solver status: `ITERATION_LIMIT`
- primal status: `FEASIBLE_POINT`
- Ipopt trace:
  - iter 0: objective `-3.2494220e-04`, `inf_pr=6.01e-08`,
    `inf_du=1.00e-03`
  - iter 1: `inf_pr=6.01e-08`, `inf_du=4.27e+00`
  - iter 2: `inf_pr=3.46e-08`, `inf_du=2.29e+00`
  - iter 3: `inf_pr=2.07e-08`, `inf_du=6.00e+01`
- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: false
- trajectory gate blocker:
  `candidate_solver_status_blocks_trajectory_extraction`
- control movement:
  - temperature max absolute delta vs pre-solve: `2.66e-10 C`
  - FDA max absolute delta vs pre-solve: `6.00e-8 g/L`
  - organic max absolute delta vs pre-solve: `3.76e-9 g/L`
- diagnostic residuals:
  - max RHS: `9.73e-9`
  - max collocation: `3.62e-14`
  - max continuity: `8.54e-12`
  - max mass balance: `6.64e-8`
  - max lower complementarity: `1.99639e-4`
  - max upper complementarity: `1.97487e-4`
- interpretation:
  the simultaneous-control coupling is active and primal health is preserved,
  but the KKT dual still spikes once Ipopt attempts real movement. This
  candidate should not be promoted directly because the solver status blocks
  trajectory extraction.

Combined micro-release fixed-control polish:

- job: `751903`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_micro_fixed_polish_from751892_h168_20260623_122546`
- start:
  selected candidate from job `751892`
- settings:
  - temperature, FDA, and organic controls fixed at the `751892` post-solve
    values
  - objective terms: zero
  - max iterations: `5`
- solver status: `LOCALLY_SOLVED`
- Ipopt iterations: `0`
- Ipopt start:
  - objective: `0`
  - `inf_pr=6.64e-08`
  - `inf_du=1.00e-12`
- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: true
- promoted combined micro-control handoff:
  `$HOME/mpcc_runs/dynamic_control_combined_micro_fixed_polish_from751892_h168_20260623_122546/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- controls:
  - temperature slots:
    - slot 1, `0 h`: `22.104733339703973 C`
    - slot 3, `24 h`: `22.067374232293066 C`
    - slot 6, `60 h`: `22.06519860385302 C`
  - FDA slots:
    - slot 1, `12 h`: `0.02378175470544393 g/L`
    - slot 3, `36 h`: `0.024978065388082647 g/L`
    - slot 5, `60 h`: `0.024088530239681504 g/L`
  - organic slots:
    - slot 1, `12 h`: `0.014331739557591774 g/L`
    - slot 3, `36 h`: `0.017064964996906202 g/L`
    - slot 5, `60 h`: `0.01897541103553688 g/L`
- terminal diagnostics:
  - total sugar: `158.72425431058696 g/L`
  - isoamyl alcohol proxy: `0.01382516274346112 g/L`
- interpretation:
  this is the first h168 handoff with simultaneous T/FDA/ORG post-solve
  movement folded into a residual-feasible and trajectory-ready candidate. The
  movement is intentionally microscopic; the next continuation stage should
  start from this JLS, keep the same released slots, and either use a
  two-iteration moving solve followed by fixed polish or reduce the direct
  reward/trust another order of magnitude to prevent the iter-3 dual spike.

## Combined-Control Micro-Continuation Stage 2, 2026-06-23

Stage-2 moving solve:

- job: `751910`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_micro_stage2_iter2_from751903_h168_20260623_123501`
- start:
  selected candidate from job `751903`
- settings:
  - free temperature slots: `1`, `3`, `6`
  - free FDA/organic slots: `1`, `3`, `5`
  - temperature trust: `0.001 C`
  - FDA trust: `1e-5 g/L`
  - organic trust: `1e-5 g/L`
  - direct temperature/FDA/organic rewards: `0.001`
  - reference regularization: `0.05`
  - max iterations: `2`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:11:16`
  - allocated CPUs: `8`
  - max RSS: `23057284K`
- solver status: `ITERATION_LIMIT`
- primal status: `FEASIBLE_POINT`
- Ipopt trace:
  - iter 0: objective `-3.2493900e-04`, `inf_pr=6.64e-08`,
    `inf_du=1.00e-03`
  - iter 1: `inf_pr=6.64e-08`, `inf_du=4.56e+00`
  - iter 2: `inf_pr=3.32e-08`, `inf_du=2.15e+00`
- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: false
- trajectory gate blocker:
  `candidate_solver_status_blocks_trajectory_extraction`
- control movement vs pre-solve:
  - temperature max absolute delta: `7.65e-11 C`
  - FDA max absolute delta: `2.15e-9 g/L`
  - FDA sum delta: `6.37e-9 g/L`
  - organic max absolute delta: `3.65e-10 g/L`
  - organic sum delta: `4.92e-10 g/L`
- diagnostic residuals:
  - max RHS: `4.86e-9`
  - max collocation: `5.74e-13`
  - max continuity: `9.57e-12`
  - max mass balance: `7.07e-8`
  - max stationarity: `1.27e-14`
  - max lower complementarity: `1.99639e-4`
  - max upper complementarity: `1.97487e-4`
- terminal diagnostics:
  - glucose: `81.69859207414379 g/L`
  - fructose: `77.02566223369035 g/L`
  - total sugar: `158.72425430783414 g/L`
  - isoamyl alcohol proxy: `0.013825164210797781 g/L`
- post-solve controls:
  - temperature:
    `[22.104733339780452, 22.0, 22.067374232368824, 22.0, 22.0, 22.06519860392873, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0]`
  - FDA:
    `[0.023781756817514196, 0.0, 0.0249780675403397, 0.0, 0.024088532341934626, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
  - organic:
    `[0.0143317394864105, 0.0, 0.017064965194909378, 0.0, 0.018975411400258966, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
- interpretation:
  limiting the moving solve to two iterations avoids the iter-3 dual spike seen
  in job `751892`, keeps primal/collocation/continuity health intact, and
  produces a post-solve residual-feasible candidate. The solver status still
  blocks trajectory extraction, so the candidate is not promoted directly.

Stage-2 fixed-control polish:

- job: `751917`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_micro_stage2_fixed_polish_from751910_h168_20260623_124901`
- start:
  selected candidate from job `751910`
- settings:
  - temperature, FDA, and organic controls fixed at the `751910` post-solve
    values
  - objective mode: `off`
  - direct rewards: zero
  - reference regularization: zero
  - max iterations: `5`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:06:17`
  - allocated CPUs: `8`
  - max RSS: `10431180K`
  - stdout archived at:
    `$HOME/mpcc_runs/dynamic_control_combined_micro_stage2_fixed_polish_from751910_h168_20260623_124901/slurm-751917.out`
- solver status: `LOCALLY_SOLVED`
- Ipopt iterations: `0`
- Ipopt start:
  - objective: `0`
  - `inf_pr=7.07e-08`
  - `inf_du=1.00e-12`
- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: true
- post-solve candidate accepted: true
- diagnostic residuals:
  - max RHS: `4.86e-9`
  - max collocation: `5.74e-13`
  - max continuity: `9.57e-12`
  - max mass balance: `7.07e-8`
  - max lower bound violation: `5.43e-9`
  - max upper bound violation: `5.80e-9`
  - max stationarity: `1.27e-14`
  - max lower complementarity: `1.99639e-4`
  - max upper complementarity: `1.97487e-4`
- promoted stage-2 combined micro-control handoff:
  `$HOME/mpcc_runs/dynamic_control_combined_micro_stage2_fixed_polish_from751910_h168_20260623_124901/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- interpretation:
  this extends the h168 combined T/FDA/ORG continuation ladder by one
  promotable stage. Movement is still microscopic, so the next technical step
  is to attempt a controlled trust/reward relaxation from this handoff and
  measure whether movement grows without losing `residual_feasible=true` and
  `trajectory_ready=true` after fixed-control polish.

## Combined-Control Stage 3 Relaxation Sweep, 2026-06-23

Mini-sweep from the stage-2 handoff:

- start:
  `$HOME/mpcc_runs/dynamic_control_combined_micro_stage2_fixed_polish_from751910_h168_20260623_124901/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- shared release:
  - free temperature slots: `1`, `3`, `6`
  - free FDA/organic slots: `1`, `3`, `5`
  - h168, nfe `168`, MA86, limited-memory Hessian
  - max iterations kept low to preserve primal health before fold-in polish
- jobs:
  - `751924`, `relaxreg`
    - trust: temperature `0.002 C`, FDA/organic `2e-5 g/L`
    - direct rewards: `0.001`
    - reference regularization: `0.005`
    - max iterations: `2`
  - `751925`, `pushdiag`
    - trust: temperature `0.005 C`, FDA/organic `5e-5 g/L`
    - direct rewards: `0.005`
    - reference regularization: `0`
    - max iterations: `1`

Sweep outcome:

- both jobs completed on `full` / `n14`
- `751924`:
  - elapsed: `00:11:42`
  - max RSS: `23733220K`
  - solver status: `ITERATION_LIMIT`
  - selected residual feasible: true
  - selected trajectory ready: false
  - Ipopt iter 0: objective `-3.2491393e-04`, `inf_pr=7.07e-08`,
    `inf_du=1.00e-03`
  - Ipopt iter 1: `inf_pr=7.07e-08`, `inf_du=2.35e-01`
  - Ipopt iter 2: `inf_pr=4.58e-08`, `inf_du=1.81e-01`
  - control movement vs pre-solve:
    - temperature max absolute delta: `3.31e-10 C`
    - FDA max absolute delta: `7.26e-9 g/L`
    - FDA sum delta: `1.75e-8 g/L`
    - organic max absolute delta: `1.77e-9 g/L`
    - organic sum delta: `3.97e-9 g/L`
  - residuals:
    - max RHS: `4.14e-9`
    - max collocation: `3.72e-13`
    - max continuity: `1.01e-11`
    - max mass balance: `7.80e-8`
- `751925`:
  - elapsed: `00:08:37`
  - max RSS: `19496244K`
  - solver status: `ITERATION_LIMIT`
  - selected residual feasible: true
  - selected trajectory ready: false
  - Ipopt iter 0: objective `-1.6245776e-03`, `inf_pr=7.07e-08`,
    `inf_du=5.00e-03`
  - Ipopt iter 1: `inf_pr=7.07e-08`, `inf_du=5.00e-03`
  - control movement vs pre-solve:
    - temperature max absolute delta: `7.29e-11 C`
    - FDA max absolute delta: `9.69e-9 g/L`
    - FDA sum delta: `2.86e-8 g/L`
    - organic max absolute delta: `4.59e-10 g/L`
    - organic sum delta: `1.07e-9 g/L`
  - residuals:
    - max RHS: `4.86e-9`
    - max collocation: `5.74e-13`
    - max continuity: `9.58e-12`
    - max mass balance: `7.21e-8`
- interpretation:
  `pushdiag` proves the direct control signal can remain primal-feasible under
  a stronger diagnostic objective, but it mostly moves FDA. `relaxreg` gives
  better simultaneous movement in temperature and organic addition while
  preserving structural residuals, so it is the preferred fold-in candidate.

Stage-3 fixed-control polish:

- job: `751933`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_stage3_relaxreg_fixed_polish_from751924_h168_20260623_131222`
- start:
  selected candidate from job `751924`
- settings:
  - temperature, FDA, and organic controls fixed at the `751924` post-solve
    values
  - objective mode: `off`
  - max iterations: `5`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:06:18`
  - allocated CPUs: `8`
  - max RSS: `10199664K`
- solver status: `LOCALLY_SOLVED`
- Ipopt iterations: `0`
- Ipopt start:
  - objective: `0`
  - `inf_pr=7.80e-08`
  - `inf_du=1.00e-12`
- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: true
- post-solve candidate accepted: true
- final controls:
  - temperature:
    `[22.10473334011181, 22.0, 22.067374232697066, 22.0, 22.0, 22.06519860425677, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0]`
  - FDA:
    `[0.02378176407766494, 0.0, 0.024978073087371704, 0.0, 0.024088536989462127, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
  - organic:
    `[0.014331740171097288, 0.0, 0.01706496670466875, 0.0, 0.018975413172170146, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
- diagnostic residuals:
  - max RHS: `4.14e-9`
  - max collocation: `3.72e-13`
  - max continuity: `1.01e-11`
  - max mass balance: `7.80e-8`
  - max lower complementarity: `1.99638e-4`
  - max upper complementarity: `1.97487e-4`
- promoted stage-3 combined-control handoff:
  `$HOME/mpcc_runs/dynamic_control_combined_stage3_relaxreg_fixed_polish_from751924_h168_20260623_131222/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- interpretation:
  this is the current best h168 combined T/FDA/ORG handoff. It is still a
  diagnostic micro-continuation, but it demonstrates that lower reference
  regularization increases simultaneous movement without degrading
  collocation, continuity, bounds, stationarity, or the Scholtes tau gate after
  fixed-control polish. The next continuation should start from this JLS and
  relax either trust or objective weights by another small factor, then fold in
  via the same fixed-control polish gate before introducing the reformulated
  dynamic objective.

## Combined-Control Stage 4 Fixed Displacement, 2026-06-23

Purpose:

- test whether the h168 simultaneous MPCC can tolerate a deliberately larger
  combined control displacement than the tiny objective-driven moves from
  stages 2 and 3
- separate local Ipopt line-search reluctance from true infeasibility of the
  control/state/bounds geometry

Run:

- job: `751943`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_stage4_shift10mK_fixed_polish_from751933_h168_20260623_132237`
- start:
  `$HOME/mpcc_runs/dynamic_control_combined_stage3_relaxreg_fixed_polish_from751924_h168_20260623_131222/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- controls:
  - temperature slots `1`, `3`, `6`: stage-3 values plus `0.01 C`
  - FDA slots `1`, `3`, `5`: stage-3 values plus `1e-4 g/L`
  - organic slots `1`, `3`, `5`: stage-3 values plus `1e-4 g/L`
- important seed setting:
  `MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=0`
  so that the candidate JLS does not overwrite the displaced controls
- objective mode: `off`
- trusts: zero, controls fixed
- max iterations: `5`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:14:22`
  - allocated CPUs: `8`
  - max RSS: `22652648K`

Ipopt trace:

- iter 0: objective `0`, `inf_pr=1.55e-04`, `inf_du=1.00e-12`
- iter 1: `inf_pr=1.55e-04`, `inf_du=2.31e-03`
- iter 2: `inf_pr=1.29e-04`, `inf_du=6.95e-03`
- iter 3: `inf_pr=3.22e-05`, `inf_du=3.07e-03`
- iter 4: `inf_pr=6.71e-12`, `inf_du=2.23e-05`
- iter 5: `inf_pr=1.85e-10`, `inf_du=8.95e-09`
- solver status: `LOCALLY_SOLVED`

Diagnostics:

- pre-solve candidate residual feasible: false
- post-solve candidate residual feasible: true
- selected trajectory ready: true
- selected candidate source: `post_solve_values`
- selected terminal glucose: `81.69856152940545 g/L`
- selected terminal fructose: `77.02564039296945 g/L`
- selected terminal total sugar: `158.7242019223749 g/L`
- selected terminal isoamyl alcohol proxy: `0.01382878679560382 g/L`
- residuals:
  - max RHS: `1.49e-9`
  - max collocation: `3.64e-13`
  - max continuity: `3.64e-13`
  - max mass balance: `6.01e-8`
  - max lower bound violation: `5.65e-9`
  - max upper bound violation: `5.65e-9`
  - max stationarity: `1.51e-14`
  - max lower complementarity: `1.99633e-4`
  - max upper complementarity: `1.97479e-4`

Promoted stage-4 combined-control handoff:

`$HOME/mpcc_runs/dynamic_control_combined_stage4_shift10mK_fixed_polish_from751933_h168_20260623_132237/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`

Final controls:

- temperature:
  `[22.11473334011181, 22.0, 22.077374232697068, 22.0, 22.0, 22.07519860425677, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0]`
- FDA:
  `[0.02388176407766494, 0.0, 0.025078073087371703, 0.0, 0.024188536989462127, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
- organic:
  `[0.014431740171097288, 0.0, 0.01716496670466875, 0.0, 0.019075413172170146, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`

Interpretation:

The fixed displacement initially breaks residual feasibility, but Ipopt repairs
the simultaneous MPCC to a promotable candidate within five iterations. This is
a stronger result than the purely objective-driven micro-moves: the local
geometry can accept a larger combined T/FDA/ORG shift when the controls are
seeded and the NLP is allowed to re-equilibrate states and fluxes. The next
step should use this handoff as the start for a moving-control diagnostic with
small trust around the displaced profile, then compare whether objective-driven
movement grows from a better-conditioned point. This also supports a future
continuation ladder with fixed displacement substeps followed by moving-control
diagnostics, before enabling the serious productivity/nutrient/energy/aroma
objective.

## Combined-Control Stage 4 Moving Diagnostic and Fold-In, 2026-06-23

Purpose:

- test whether the stage-4 displaced combined-control handoff improves the
  response of a moving-control diagnostic objective
- fold the resulting objective-driven T/FDA/organic movement back into a
  trajectory-ready fixed-control handoff before using it as a new base

Moving diagnostic:

- job: `751954`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_stage4_moving_relax_from751943_h168_20260623_133859`
- start:
  `$HOME/mpcc_runs/dynamic_control_combined_stage4_shift10mK_fixed_polish_from751933_h168_20260623_132237/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- free controls:
  - temperature slots `1`, `3`, `6`
  - FDA/organic slots `1`, `3`, `5`
- trusts:
  - temperature: `0.005 C`
  - FDA/organic: `5e-5 g/L`
- objective:
  - direct temperature/FDA/organic rewards: `0.001`
  - reference regularization: `0.001`
  - nutrient, thermal, smoothness, sugar, aroma, and tail-residual weights: off
- max iterations: `2`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:10:01`
  - allocated CPUs: `8`
  - max RSS: `22673316K`

Ipopt trace:

- iter 0: objective `-3.2572984e-04`, `inf_pr=6.01e-08`,
  `inf_du=1.00e-03`
- iter 1: `inf_pr=6.01e-08`, `inf_du=5.83e-03`
- iter 2: `inf_pr=4.37e-08`, `inf_du=2.22e-01`
- solver status: `ITERATION_LIMIT`

Moving diagnostic result:

- selected residual feasible: true
- selected trajectory ready: false
- selected candidate source: `post_solve_values`
- post-solve candidate accepted: true
- movement versus stage-4 pre-solve:
  - max temperature delta: `1.29e-8 C`
  - FDA max absolute delta: `2.79e-7 g/L`
  - FDA sum delta: `7.52e-8 g/L`
  - organic max absolute delta: `8.84e-8 g/L`
  - organic sum delta: `2.16e-7 g/L`
- residuals:
  - max RHS: `2.93e-9`
  - max collocation: `2.70e-13`
  - max continuity: `3.29e-12`
  - max mass balance: `7.22e-8`
  - max lower bound violation: `5.33e-9`
  - max upper bound violation: `6.52e-9`
  - max stationarity: `1.65e-14`
  - max lower complementarity: `1.99637e-4`
  - max upper complementarity: `1.97479e-4`

Fold-in polish:

- job: `751965`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_stage4_moving_fixed_polish_from751954_h168_20260623_135403`
- start:
  `$HOME/mpcc_runs/dynamic_control_combined_stage4_moving_relax_from751943_h168_20260623_133859/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- controls:
  - fixed at the `751954` post-solve T/FDA/organic values
  - `MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=1`
- objective mode: `off`
- trusts: zero, controls fixed
- max iterations: `5`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:06:16`
  - allocated CPUs: `8`
  - max RSS: `10180452K`

Ipopt trace:

- iter 0: objective `0`, `inf_pr=7.22e-08`, `inf_du=1.00e-12`
- solver status: `LOCALLY_SOLVED`
- Ipopt exit: `Optimal Solution Found`

Fold-in diagnostics:

- pre-solve candidate residual feasible: true
- post-solve candidate residual feasible: true
- selected residual feasible: true
- selected trajectory ready: true
- selected candidate source: `post_solve_values`
- selected terminal glucose: `81.6985615278279 g/L`
- selected terminal fructose: `77.02564039147433 g/L`
- selected terminal total sugar: `158.72420191930223 g/L`
- selected terminal isoamyl alcohol proxy: `0.013828793676869252 g/L`
- residuals:
  - max RHS: `2.93e-9`
  - max collocation: `2.70e-13`
  - max continuity: `3.29e-12`
  - max mass balance: `7.22e-8`
  - max lower bound violation: `5.33e-9`
  - max upper bound violation: `6.52e-9`
  - max stationarity: `1.65e-14`
  - max lower complementarity: `1.99637e-4`
  - max upper complementarity: `1.97479e-4`

Promoted stage-4 moving fold-in handoff:

`$HOME/mpcc_runs/dynamic_control_combined_stage4_moving_fixed_polish_from751954_h168_20260623_135403/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`

Final controls:

- temperature:
  `[22.114733353020384, 22.0, 22.077374245542174, 22.0, 22.0, 22.07519861709469, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0]`
- FDA:
  `[0.023882042710726647, 0.0, 0.025078046432227694, 0.0, 0.02418836020551887, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
- organic:
  `[0.01443178532899355, 0.0, 0.017165048698444933, 0.0, 0.019075501543263484, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`

Interpretation:

Stage 4 fixed displacement improved conditioning enough that the subsequent
moving-control diagnostic produced larger simultaneous objective-driven motion
than stages 2 and 3, especially in FDA and organic additions, while preserving
healthy primal residuals. As expected, the short moving diagnostic itself is not
promotable because `ITERATION_LIMIT` blocks trajectory extraction. The fold-in
polish validates the moved controls as a new h168 trajectory-ready handoff. The
next continuation can either apply another fixed displacement substep from this
handoff, or introduce the reformulated dynamic objective with very small weights
around this now-conditioned combined-control profile.

## Stage 5 Soft Dynamic-Objective Pilot and Fold-In, 2026-06-23

Purpose:

- introduce the reformulated objective components around the conditioned
  combined-control handoff without making sugar dryness a hard gate yet
- keep the trust region deliberately tiny while checking whether the objective
  moves temperature, FDA, and organic controls through the simultaneous MPCC
- fold the resulting post-solve controls back into a trajectory-ready handoff
  if the objective pilot remains primal-healthy

Soft objective pilot:

- job: `751972`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_stage5_soft_objective_from751965_h168_20260623_140431`
- start:
  `$HOME/mpcc_runs/dynamic_control_combined_stage4_moving_fixed_polish_from751954_h168_20260623_135403/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- free controls:
  - temperature slots `1`, `3`, `6`
  - FDA/organic slots `1`, `3`, `5`
- trusts:
  - temperature: `0.005 C`
  - FDA/organic: `5e-5 g/L`
- objective:
  - mode: `aroma_nutrient_energy`
  - terminal isoamyl reward: `0.001`, scale `0.02 g/L`
  - integrated sugar productivity proxy: `0.001`, scale `100 g/L`
  - terminal sugar excess soft term: weight `0.001`, max `150 g/L`,
    scale `50 g/L`
  - nutrient cost: `0.002`, scale `1 g/L`
  - thermal energy proxy: `0.002`, ambient `20 C`, scale `5 C`
  - temperature smoothness and direct rewards: `0.0`
- max iterations: `3`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:10:47`
  - allocated CPUs: `8`
  - max RSS: `24458824K`

Ipopt trace:

- iter 0: objective `3.2042800e-03`, `inf_pr=7.22e-08`,
  `inf_du=5.00e-02`
- iter 1: objective `3.2042795e-03`, `inf_pr=7.22e-08`,
  `inf_du=5.00e-02`
- iter 2: objective `3.2042053e-03`, `inf_pr=5.16e-08`,
  `inf_du=1.31e-01`
- iter 3: objective `3.2064552e-03`, `inf_pr=3.21e-08`,
  `inf_du=4.58e+00`
- solver status: `ITERATION_LIMIT`

Soft objective result:

- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: false
- post-solve candidate accepted: true
- objective reconstructed value estimate: `3.2031938269422877e-03`
- objective components:
  - integrated sugar value estimate: `3.291381879520914e-03`
  - terminal isoamyl reward value estimate: `-6.925196476211848e-04`
  - terminal sugar excess value estimate: `3.044468022894112e-05`
  - nutrient value estimate: `2.476353406771517e-04`
  - thermal energy value estimate: `3.262515741364658e-04`
- selected terminal glucose: `81.6985618335561 g/L`
- selected terminal fructose: `77.02564050822154 g/L`
- selected terminal total sugar: `158.72420234177764 g/L`
- selected terminal isoamyl alcohol proxy: `0.013850392952423695 g/L`
- control movement versus pre-solve:
  - max temperature delta: `3.81825799422586e-7 C`
  - FDA max absolute delta: `1.4030142230191112e-6 g/L`
  - FDA sum delta: `3.258110423537408e-7 g/L`
  - organic max absolute delta: `1.386415972748356e-6 g/L`
  - organic sum delta: `-3.440391641677809e-6 g/L`
- post-solve controls:
  - temperature:
    `[22.114732971194584, 22.0, 22.077373869450792, 22.0, 22.0, 22.075198241360823, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0]`
  - FDA:
    `[0.023880639696503628, 0.0, 0.02507839942917075, 0.0, 0.024189736033841194, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
  - organic:
    `[0.014431019518508243, 0.0, 0.017163760533261314, 0.0, 0.019074115127290736, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
- residuals:
  - max RHS: `4.13e-9`
  - max collocation: `1.30e-13`
  - max continuity: `7.55e-12`
  - max mass balance: `6.76e-8`
  - max lower bound violation: `5.70e-9`
  - max upper bound violation: `5.54e-9`
  - max stationarity: `1.56e-14`
  - max lower complementarity: `3.58144e-4`
  - max upper complementarity: `3.87159e-4`
- interpretation: the reformulated objective is connected to simultaneous
  controls and improves the isoamyl proxy slightly, but the short pilot is not
  promotable because `ITERATION_LIMIT` blocks trajectory extraction and
  complementarity residuals rise above the stage-4 handoff.

Fold-in polish:

- job: `751983`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_stage5_soft_objective_fixed_polish_from751972_h168_20260623_141950`
- start:
  `$HOME/mpcc_runs/dynamic_control_combined_stage5_soft_objective_from751965_h168_20260623_140431/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- controls:
  - fixed at the `751972` post-solve T/FDA/organic values
  - `MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=1`
- objective mode: `off`
- trusts: zero, controls fixed
- max iterations: `5`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:14:08`
  - allocated CPUs: `8`
  - max RSS: `22306128K`

Ipopt trace:

- iter 0: objective `0`, `inf_pr=1.87e-04`, `inf_du=1.00e-12`
- iter 4: objective `0`, `inf_pr=1.73e-08`, `inf_du=2.28e-03`
- iter 5: objective `0`, `inf_pr=5.57e-12`, `inf_du=5.01e-08`
- solver status: `LOCALLY_SOLVED`
- Ipopt exit: `Optimal Solution Found`

Fold-in diagnostics:

- pre-solve candidate residual feasible: false
- post-solve candidate residual feasible: true
- selected residual feasible: true
- selected trajectory ready: true
- selected candidate source: `post_solve_values`
- selected terminal glucose: `81.69856077041639 g/L`
- selected terminal fructose: `77.02563969438258 g/L`
- selected terminal total sugar: `158.72420046479897 g/L`
- selected terminal isoamyl alcohol proxy: `0.013849447816944705 g/L`
- residuals:
  - max RHS: `8.22e-11`
  - max collocation: `1.40e-14`
  - max continuity: `3.29e-12`
  - max mass balance: `6.00e-8`
  - max lower bound violation: `5.65e-9`
  - max upper bound violation: `5.65e-9`
  - max stationarity: `1.55e-14`
  - max lower complementarity: `1.99637e-4`
  - max upper complementarity: `1.97502e-4`

Promoted stage-5 soft-objective fold-in handoff:

`$HOME/mpcc_runs/dynamic_control_combined_stage5_soft_objective_fixed_polish_from751972_h168_20260623_141950/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`

Final controls:

- temperature:
  `[22.114732971194584, 22.0, 22.077373869450792, 22.0, 22.0, 22.075198241360823, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0]`
- FDA:
  `[0.023880639696503628, 0.0, 0.02507839942917075, 0.0, 0.024189736033841194, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
- organic:
  `[0.014431019518508243, 0.0, 0.017163760533261314, 0.0, 0.019074115127290736, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`

Interpretation:

The first serious objective pilot is directionally valid but too weak/tightly
regularized to create meaningful process movement. The fold-in confirms that
its post-solve profile can nevertheless be promoted to a trajectory-ready h168
handoff. The next objective continuation should start from this handoff, keep
the same control slots, and adjust weights toward productivity/sugar leverage:
reduce terminal aroma dominance, increase integrated sugar or terminal sugar
excess pressure, and keep nutrient/thermal costs small until movement is
measurable without complementarity degradation.

## Stage 6 Productivity-Weighted Objective Pilot and Fold-In, 2026-06-23

Purpose:

- start from the stage-5 soft-objective fold-in handoff
- shift the serious objective toward productivity/sugar leverage while keeping
  aroma, nutrient cost, and thermal energy active but smaller
- test whether the simultaneous MPCC produces larger non-direct control
  movement while preserving primal residual health
- fold the resulting post-solve controls into a promotable handoff if the pilot
  remains residual-feasible

Productivity-weighted pilot:

- job: `751994`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_stage6_productivity_soft_from751983_h168_20260623_143709`
- start:
  `$HOME/mpcc_runs/dynamic_control_combined_stage5_soft_objective_fixed_polish_from751972_h168_20260623_141950/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- free controls:
  - temperature slots `1`, `3`, `6`
  - FDA/organic slots `1`, `3`, `5`
- trusts:
  - temperature: `0.02 C`
  - FDA/organic: `1e-4 g/L`
- objective:
  - mode: `aroma_nutrient_energy`
  - terminal isoamyl reward: `0.0002`, scale `0.02 g/L`
  - integrated sugar productivity proxy: `0.02`, scale `100 g/L`
  - terminal sugar excess soft term: weight `0.01`, max `158 g/L`,
    scale `10 g/L`
  - nutrient cost: `0.0005`, scale `1 g/L`
  - thermal energy proxy: `0.0005`, ambient `20 C`, scale `5 C`
  - temperature smoothness and direct rewards: `0.0`
  - reference regularization: `1e-4`
- max iterations: `5`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:12:04`
  - allocated CPUs: `8`
  - max RSS: `22363268K`

Ipopt trace:

- iter 0: objective `6.5885061e-02`, `inf_pr=6.00e-08`,
  `inf_du=1.00e-02`
- iter 2: objective `6.5885355e-02`, `inf_pr=5.24e-08`,
  `inf_du=8.98e-02`
- iter 4: objective `6.5884914e-02`, `inf_pr=5.03e-08`,
  `inf_du=3.63e+00`
- iter 5: objective `6.5908281e-02`, `inf_pr=4.77e-08`,
  `inf_du=3.50e+00`
- solver status: `ITERATION_LIMIT`

Productivity-weighted result:

- selected candidate source: `post_solve_values`
- selected residual feasible: true
- selected trajectory ready: false
- post-solve candidate accepted: true
- selected terminal glucose: `81.69856152528703 g/L`
- selected terminal fructose: `77.02563386522617 g/L`
- selected terminal total sugar: `158.72419539051322 g/L`
- selected terminal isoamyl alcohol proxy: `0.014372226685772604 g/L`
- objective reconstructed value estimate: `6.587983582935808e-02`
- objective components:
  - integrated sugar value estimate: `6.582763389767578e-02`
  - terminal isoamyl reward value estimate: `-1.4372226685772604e-04`
  - terminal sugar excess value estimate: `5.244642962508375e-05`
  - nutrient value estimate: `6.191505718839232e-05`
  - thermal energy value estimate: `8.156271172655972e-05`
- terminal sugar excess slack: `0.7241990722521242 g/L`
- required terminal sugar excess: `0.7241953905132164 g/L`
- movement versus pre-solve:
  - max temperature delta: `1.1037008906811252e-5 C`
  - temperature sum delta: `-3.0487289166103437e-5 C`
  - FDA max absolute delta: `3.782289686311835e-5 g/L`
  - FDA sum delta: `2.123646337143237e-6 g/L`
  - organic max absolute delta: `7.828930172574036e-6 g/L`
  - organic sum delta: `1.0320391871633527e-5 g/L`
- post-solve controls:
  - temperature:
    `[22.11472431691819, 22.0, 22.0773630734469, 22.0, 22.0, 22.075187204351916, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0]`
  - FDA:
    `[0.02388422695717022, 0.0, 0.02504057653230763, 0.0, 0.024226095316374867, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
  - organic:
    `[0.014438848448680817, 0.0, 0.01716771652516616, 0.0, 0.019072650597084947, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
- residuals:
  - max RHS: `3.80e-10`
  - max collocation: `1.78e-12`
  - max continuity: `1.33e-10`
  - max mass balance: `9.49e-8`
  - max lower bound violation: `5.66e-9`
  - max upper bound violation: `5.44e-9`
  - max stationarity: `3.28e-13`
  - max lower complementarity: `1.99654e-4`
  - max upper complementarity: `1.97517e-4`
- interpretation: increasing productivity/sugar leverage produced clearly
  larger control movement than stage 5 while keeping structural residuals
  healthy. The objective value rose slightly over five iterations and the dual
  residual remained high, so the moving solve remains diagnostic rather than
  promotable directly.

Fold-in polish:

- job: `752006`
- run root:
  `$HOME/mpcc_runs/dynamic_control_combined_stage6_productivity_fixed_polish_from751994_h168_20260623_145038`
- start:
  `$HOME/mpcc_runs/dynamic_control_combined_stage6_productivity_soft_from751983_h168_20260623_143709/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- controls:
  - fixed at the `751994` post-solve T/FDA/organic values
  - `MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=1`
- objective mode: `off`
- trusts: zero, controls fixed
- max iterations: `5`
- Slurm:
  - partition/node: `full` / `n14`
  - elapsed: `00:06:19`
  - allocated CPUs: `8`
  - max RSS: `10439604K`

Ipopt trace:

- iter 0: objective `0`, `inf_pr=9.49e-08`, `inf_du=1.00e-12`
- solver status: `LOCALLY_SOLVED`
- Ipopt exit: `Optimal Solution Found`

Fold-in diagnostics:

- pre-solve candidate residual feasible: true
- post-solve candidate residual feasible: true
- selected residual feasible: true
- selected trajectory ready: true
- selected candidate source: `post_solve_values`
- selected terminal glucose: `81.69856152528703 g/L`
- selected terminal fructose: `77.02563386522617 g/L`
- selected terminal total sugar: `158.72419539051322 g/L`
- selected terminal isoamyl alcohol proxy: `0.014372226685772604 g/L`
- residuals:
  - max RHS: `3.80e-10`
  - max collocation: `1.78e-12`
  - max continuity: `1.33e-10`
  - max mass balance: `9.49e-8`
  - max lower bound violation: `5.66e-9`
  - max upper bound violation: `5.44e-9`
  - max stationarity: `3.28e-13`
  - max lower complementarity: `1.99654e-4`
  - max upper complementarity: `1.97517e-4`

Promoted stage-6 productivity-weighted fold-in handoff:

`$HOME/mpcc_runs/dynamic_control_combined_stage6_productivity_fixed_polish_from751994_h168_20260623_145038/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`

Final controls:

- temperature:
  `[22.11472431691819, 22.0, 22.0773630734469, 22.0, 22.0, 22.075187204351916, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0, 22.0]`
- FDA:
  `[0.02388422695717022, 0.0, 0.02504057653230763, 0.0, 0.024226095316374867, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`
- organic:
  `[0.014438848448680817, 0.0, 0.01716771652516616, 0.0, 0.019072650597084947, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]`

Interpretation:

Stage 6 satisfies the immediate goal milestone: the combined h168 MPCC responds
to a reformulated dynamic objective through temperature, FDA, and organic
controls, and the resulting profile can be converted into a residual-feasible
and trajectory-ready handoff. The actual process movement is still small, so
future objective development should focus on objective scaling/leverage and
more control slots, not on repairing collocation or continuity. The candidate
is promotable as a methodological handoff, not as the final optimized thermal
nutritional policy.

## Promotable Handoff Comparison

All rows below satisfy `selected_candidate_residual_feasible=true` and
`selected_candidate_trajectory_ready=true`. They are therefore valid handoffs
for later continuation. They are not equivalent scientific optima because the
objectives and released controls differ.

| Handoff | Main control change | Terminal sugar g/L | Isoamyl proxy g/L | Structural residual health |
| --- | --- | ---: | ---: | --- |
| h168 fixed-control tau homotopy seed | seed-centered flat policy | `159.09882187099078` | `0.0029105354815509984` | RHS `2.01e-10`, colloc/cont `2.50e-14` |
| temperature individual release `751615` | T slots `1,3,6` to upper trust | `159.09889510198815` | `0.0028987203785931144` | RHS `1.22e-10`, colloc/cont `2.63e-11` |
| organic individual release `751679` | ORG slots `1,3,5` increased | `158.83896445263707` | `0.012761442332669898` | RHS `1.55e-8`, colloc `1.37e-14`, cont `1.44e-12` |
| combined stage 4 fold-in `751965` | fixed T/FDA/ORG displacement plus micro objective motion | `158.72420191930223` | `0.013828793676869252` | RHS `2.93e-9`, colloc `2.70e-13`, cont `3.29e-12` |
| combined stage 5 soft-objective fold-in `751983` | first reformulated objective profile folded in | `158.72420046479897` | `0.013849447816944705` | RHS `8.22e-11`, colloc `1.40e-14`, cont `3.29e-12` |
| combined stage 6 productivity-weighted fold-in `752006` | stronger productivity/sugar objective profile folded in | `158.72419539051322` | `0.014372226685772604` | RHS `3.80e-10`, colloc `1.78e-12`, cont `1.33e-10` |

Comparison:

- Individual temperature release alone is numerically promotable but not useful
  for productivity/aroma under the current model and local trust settings.
- Individual organic release is the first strong aroma/productivity mover, but
  does not include simultaneous thermal/FDA freedom.
- Combined stage 4 proves simultaneous T/FDA/ORG displacement can be repaired
  to a healthy trajectory-ready h168 MPCC.
- Combined stage 5 proves the reformulated objective is wired to simultaneous
  controls and can be folded into a promotable handoff.
- Combined stage 6 is the current best methodological handoff for the dynamic
  objective line: it has the best terminal sugar and isoamyl proxy among the
  promotable combined candidates while preserving collocation/continuity health.
