# Fixed-Control Reduced MPCC Solve Attempt, 2026-06-10

Goal: move the selected dynamic-control fixed policy from a raw MPCC smoke
replay into the guarded `solve_attempt` path, so every run emits the same
residual and candidate diagnostics used by the windowed/global MPCC workflow.
All Julia/Ipopt work was submitted through Slurm on the UC cluster.

Selected policy:

- `cool18_warm22__springferm_early_0p4`
- 24 h horizon
- `nfe = 4`, collocation degree `3`
- sequential reduced dFBA initialization generated inside the Slurm job
- collocation-consistent state starts enabled by the solve-attempt wrapper
- Scholtes complementarity with `tau = 20`
- MA86 through the cluster HSL library:
  `/home/cltorrealba/opt/hsl/libhsl-2025.7.21/lib/libhsl.so`
- limited-memory Hessian
- strict Ipopt warm-start pushes/fracs at `1e-12`
- `OPENBLAS_NUM_THREADS=1`
- no GPU

## Entrypoint

Added:

- `scripts/main_reduced_mpcc_fixed_control_policy_solve_attempt.jl`

The script:

- reads `dynamic_control_policy_selection.csv`,
- selects one fixed-control candidate,
- rebuilds the smooth temperature/FDA/organic nutrient schedule,
- simulates the matching sequential reduced dFBA reference,
- calls `solve_reduced_dcdfba_mpcc_solve_attempt`,
- records pre-solve guard diagnostics, residual thresholds, Ipopt metadata,
  and candidate extraction flags,
- writes:
  - `reduced_mpcc_fixed_control_policy_solve_attempt.csv`
  - `reduced_mpcc_fixed_control_policy_solve_attempt.toml`

This entrypoint is diagnostic only:
`solve_attempt_is_scientific_simulation=false`.

## Slurm Evidence

Contract validation:

- `728473`: initial solve-attempt entrypoint contract passed.
- `728500`: contract re-run after metadata-row cleanup; the fixed-control
  solve-attempt block passed `36/36`.

Solve-attempt validations:

| Job | Setup | Resources | Outcome |
| --- | --- | --- | --- |
| `728482` | 24 h, `nfe=4`, `max_iter=5` | `full`, `--ntasks=1`, `--cpus-per-task=8`, `--mem=24G` | Ipopt/MA86 entered cleanly; no restoration; final `inf_pr=9.65e-2`; candidate rejected |
| `728503` | 24 h, `nfe=4`, `max_iter=0` row-audit replay | `full`, `--ntasks=1`, `--cpus-per-task=8`, `--mem=24G` | metadata fields validated after cleanup; candidate rejected |

Latest row-audit output:

`/home/cltorrealba/mpcc_runs/dynamic_control_fixed_solve_attempt_20260610_185545/attempt_cool18_warm22_springferm_early_0p4_24h_nfe4_iter0_rowfix`

Key results from `728503`:

- solver: Ipopt with MA86
- status: `ITERATION_LIMIT`
- primal status: `INFEASIBLE_POINT`
- NLP size: `67067` variables, `102779` constraints
- `guarded_solve_attempt_allowed=true`
- `guarded_solve_attempt_blocked=false`
- `pre_solve_guard_required=false`
- `linear_solver=ma86`
- `ipopt_profile=acceptable`
- `ipopt_hessian_approximation=limited-memory`
- dominant residual: `max_collocation_integration_residual`
- `max_collocation_integration_residual=9.843720716690557e-2`
- `max_rhs_residual=0`
- `candidate_values_available=true`
- `candidate_residual_feasible=false`
- `candidate_trajectory_extraction_ready=false`

For the `max_iter=5` run (`728482`), the initial Ipopt row was
`inf_pr=9.84e-2`, `inf_du=1.33e0`; after five iterations it remained stable
with no restoration and final `inf_pr=9.65e-2`.

## Interpretation

The fixed-control dynamic MPCC now has a reproducible solve-attempt entrypoint
with the same guard/candidate semantics as the rest of the MPCC methodology.
The solver entry is healthy: HSL/MA86 loads, strict warm-start metadata is
captured, KKT/FBA components are small, and Ipopt does not immediately enter
restoration.

The candidate is correctly rejected because the collocation/continuity defect
is still around `1e-1`. This is not a failed scientific simulation; it is a
numerical staging result that identifies the next bottleneck.

## Next Technical Step

Before freeing temperature or nutrient controls, reduce the fixed-policy
collocation defect while preserving the healthy MA86/limited-memory line:

1. run a small fixed-control mesh/start sweep (`nfe`, collocation-consistent
   start repair, and possibly shorter horizon);
2. require the solve-attempt guard only after the pre-solve residuals are near
   threshold;
3. once fixed controls are trajectory-ready, expose the control variables with
   smoothness/total-dose penalties.

Follow-up mesh/repair diagnostics are documented in
`repro/DYNAMIC_CONTROL_MPCC_FIXED_MESH_REPAIR_20260610.md`.
