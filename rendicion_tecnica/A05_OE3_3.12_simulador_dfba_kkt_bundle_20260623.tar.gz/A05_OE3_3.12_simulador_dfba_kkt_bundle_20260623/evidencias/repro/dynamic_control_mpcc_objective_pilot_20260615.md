# Dynamic-control MPCC objective pilot update - 2026-06-15

## Scope

This update continues the 168 h simultaneous MPCC dynamic-control objective
work under the UC cluster rules. No heavy Julia work was run on the login node.
All MPCC solves ran through Slurm with `--ntasks=1`, 8 CPUs, MA86/HSL,
`OPENBLAS_NUM_THREADS=1`, no GPU, and limited-memory Hessian.

## Wide-trust objective pilot

Job `734561` tested a deliberately wider control trust region and softer costs:

- variant: `blend_integrated_reward20_reg0_wide_iter13`;
- node: `n14`;
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_blend_integrated_reward20_reg0_wide_iter13_20260615_005910`;
- target: `white_wine_aroma_blend`;
- reward policy: `terminal_plus_integrated_flux`;
- reward weight: `20.0`, effective terminal and integrated weights `10.0`;
- costs: nutrient `0.02`, thermal `0.005`, smoothness `0.005`;
- trust: temperature `2 C`, FDA `0.2 g/L`, organic `0.1 g/L`;
- Ipopt: `ITERATION_LIMIT`, primal `NEARLY_FEASIBLE_POINT`.

Result:

- `selected_candidate_residual_feasible=true`;
- `selected_candidate_trajectory_ready=false`;
- `max_rhs_residual=2.1053823615637225e-8`;
- `max_mass_balance_residual=8.209701718442375e-7`;
- `max_lower_complementarity_residual=0.0009903246567156553`;
- `max_collocation_integration_residual=0.07012802463503565`;
- `max_continuity_residual=0.070206435921229`;
- top residual: glucose continuity/collocation near `163 h`.

Control movement stayed microscopic even with the wider trust region:

- max temperature movement `0.0010284423708171175 C`;
- FDA sum movement `7.892946881635402e-8 g/L`;
- organic sum movement `-0.00011603999710474433 g/L`.

Conclusion: the control profile is not primarily pinned by narrow trust regions
or by objective scalarization. The dominant blocker remains the
trajectory/collocation-continuity structure.

## Mesh and repair probes

Job `734562` attempted `168 h` fixed-control mesh probes at `nfe=224,336`,
`max_iter=0`. It was cancelled after `01:11:26` without producing the first
`nfe=224` case CSV. This is too expensive as an interactive diagnostic.

Job `734680` replaced it with a cheaper `nfe=168`, `max_iter=0` repair sweep:

- node: `n8`;
- run root:
  `/home/cltorrealba/mpcc_runs/fixed_control_tail_repair_probe_168h_20260615_021039`;
- cases: repair elements `155:168` and `all`;
- status: completed, no failed cases.

Results:

| case | residual feasible | trajectory ready | max collocation | max continuity | max RHS | max lower comp. | top residual |
| --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| `h168_nfe168_repair155_168_iter0` | true | false | `0.6194530609677997` | `0.6194530609677997` | `0.0` | `1.9211795545347483e-15` | glucose, element 95 |
| `h168_nfe168_repairall_iter0` | false | false | `0.11531716977985512` | `0.11531716977985512` | `0.0035992107208665364` | `0.002083978142314821` | glucose, element 168 |

Conclusion:

- Tail-only repair is not enough; the defect reappears mid-horizon.
- All-element repair reduces collocation/continuity but damages RHS, bounds,
  and complementarity enough to lose residual feasibility.
- The next technical step should be a coupled repair/continuation strategy that
  reduces collocation/continuity without sequentially breaking RHS, bounds, and
  complementarity. Pushing objective weights or trust regions further is not the
  productive path yet.

## Repair guard probes

Jobs `734819` and `734820` tested the all-element `168 h`, `nfe=168`,
`max_iter=0` repair path with the stricter
`candidate_threshold_ratio` guard for the final state-after-RHS overwrite.
Both jobs used the same Slurm envelope as above and ran on the `full`
partition:

- `734819`: node `n8`, run root
  `/home/cltorrealba/mpcc_runs/fixed_control_repair_guard_probe_all_guard_candidate_comp1_20260615_041740`;
- `734820`: node `n14`, run root
  `/home/cltorrealba/mpcc_runs/fixed_control_repair_guard_probe_all_guard_candidate_comp0_20260615_041740`.

Results:

| job | complementarity flux projection | residual feasible | trajectory ready | max RHS | max collocation | max continuity | max lower comp. | top residual |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| `734819` | on | false | false | `0.0034251640581961624` | `0.12153352212573379` | `0.12153352212573379` | `0.002083978142314821` | glucose, `168 h` |
| `734820` | off | true | false | `2.1568092123617303e-8` | `0.07046014661511327` | `0.07046014661511327` | `0.0009899493723722664` | glucose, `164 h` |

In both cases the stricter guard rejected the final state-after-RHS overwrite.
The complementarity flux projection is harmful in this 168 h all-repair path:
it worsens collocation/continuity and loses residual feasibility. The
conservative baseline for the next 168 h fixed-control start work is therefore
`candidate_threshold_ratio` guard with final complementarity flux projection
disabled. This preserves residual feasibility but still leaves the trajectory
defect around `7.0e-2`, so the next useful development step is a coupled
state/collocation repair or horizon-continuation start builder, not another
objective-weight sweep.

Implementation follow-up:

- Cluster dynamic-control sbatch defaults now keep final complementarity flux
  projection disabled.
- If that projection is explicitly enabled later, the core repair path now
  guards it with the `candidate_threshold_ratio` score and restores the previous
  start when the projection worsens candidate feasibility. The fixed-control
  solve-attempt CSV also reports the guard decision and before/after scores.

## Fixed-control horizon continuation

Jobs `735066`, `735213`, `735293`, and `735412` tested the fixed-control
continuation path under the cluster-safe no-cache Julia startup:
`MPCC_JULIA_FLAGS='--compiled-modules=no --pkgimages=no'`, MA86/HSL,
limited-memory Hessian, 8 CPUs, `OPENBLAS_NUM_THREADS=1`, final
complementarity flux projection disabled, and the stricter
`candidate_threshold_ratio` final state-after-RHS guard.

Two submit-script issues were fixed on the way:

- fixed-control sweeps now forward the dynamic flux LP relaxed fallback to
  `MPCC_DYNAMIC_FLUX_LP_RELAXED_FALLBACK`;
- fixed-control sweeps now forward the stationarity-dual fail-fast switch to
  `MPCC_STATIONARITY_DUAL_START_LP_FAIL_FAST`.

Results:

| job | horizon | max_iter | selected source | residual feasible | trajectory ready | max RHS | max collocation | max continuity | max lower comp. |
| --- | ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: |
| `735066` | `120 h` | `0` | post-solve | true | false | `1.36e-8` | `2.77e-2` | `2.77e-2` | `1.11e-3` |
| `735213` | `144 h` | `0` | pre-solve | true | false | `1.36e-8` | `5.57e-2` | `5.57e-2` | `1.72e-3` |
| `735293` | `168 h` | `0` | pre-solve | true | false | `1.52e-8` | `7.05e-2` | `7.05e-2` | `9.90e-4` |
| `735412` | `168 h` | `5` | pre-solve | true | false | `1.27e-8` | `7.03e-2` | `7.02e-2` | `9.90e-4` |

The 168 h defect remains a glucose tail collocation/continuity mismatch around
`163-166 h`. Allowing five Ipopt iterations did not produce a promotable
post-solve and only marginally reduced the defect. This argues against moving
straight to a serious dynamic-control objective: the next technical step should
be a targeted collocation/continuity start repair for the late-sugar tail, then
repeat the fixed-control 168 h promotion gate before releasing the full
temperature/nutrient control profile.

### Guarded post-tail repair

The core reduced MPCC repair path now has an opt-in guarded post-tail stage,
disabled by default:

- `MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ENABLED`;
- `MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS`;
- `MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_GUARD_SCORE`;
- `MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_REFRESH_DYNAMIC_FLUX`.

The fixed-control wrapper forwards the corresponding
`MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_*` aliases, and the cluster
sbatch records them in metadata. The post-tail trial starts from the best
global repair state, applies the usual state/flux/dual/RHS refresh only on the
selected tail elements, and accepts only if the collocation-state residual
improves while the configured structural guard does not worsen.

Job `735591` validated this path at `168 h`, `nfe=168`, `max_iter=0`, with
`POST_TAIL_ELEMENTS=129:168`, MA86/HSL, limited-memory Hessian, 8 CPUs, and
no-cache Julia flags. The main repair and post-tail residual sequence was:

| stage | max collocation/continuity |
| --- | ---: |
| sequential start | `0.6194529085028222` |
| repair iter 1 | `0.12656002637302421` |
| repair iter 2 | `0.0643816521470768` |
| repair iter 3 | `0.0543284132062134` |
| repair iter 4 | `0.048840545128776114` |
| post-tail `129:168` | `0.04650967372985093` |

The post-tail trial was accepted at damping `1.0`; the
`candidate_threshold_ratio` guard stayed unchanged at `0.09996919764419213`.
The selected candidate remained residual-feasible but not trajectory-ready:
`selected_candidate_source=pre_solve_start_values`,
`selected_candidate_residual_feasible=true`,
`selected_candidate_trajectory_ready=false`. The top defect moved from the
late `163-166 h` tail to glucose around `123-128 h`, so the repair is a real
improvement but still not promotable. The next technical path is to test a
small parallel set of post-tail/wide-tail repair ranges or a higher repair
iteration budget before freeing full dynamic controls.

Jobs `735622` and `735623` then tested wider post-tail ranges with
`MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=8` and `max_iter=0`:

| job | post-tail elements | best residual-only trial | guard result |
| --- | --- | ---: | --- |
| `735622` | `96:168` | `0.01207711587667859` | rejected |
| `735623` | `64:168` | `0.015119612341948141` | rejected |

The extra repair budget reduced the pre-solve collocation/continuity defect to
`0.01595863618530302`, a large improvement over the `0.07046` baseline and the
`0.04651` post-tail `129:168` result. However, all wide post-tail trials were
rejected by the `candidate_threshold_ratio` guard: every residual-only
improvement worsened the structural guard. The accepted selected candidate
therefore stayed at the repair-8 pre-solve start:
`selected_candidate_source=pre_solve_start_values`,
`selected_candidate_residual_feasible=true`,
`selected_candidate_trajectory_ready=false`,
`max_collocation=max_continuity=0.015958636185303174`, and
`max_lower_complementarity=0.0004669492543950434`. The remaining top residual
is glucose at the `163-168 h` tail. This confirms that the guard is doing
useful work: it prevents accepting a superficially lower collocation defect
when the MPCC structure becomes less reliable.

Job `735699` tested the opposite extreme: using
`MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SCORE=candidate_threshold_ratio` as the
main monotone repair score, with the same candidate guard and no post-tail
stage. This was too conservative for trajectory construction. The repair
accepted only the initial state, rejected the damped trials, and left the
large sequential glucose defect untouched:
`max_collocation=max_continuity=0.6194529085028222`, with the top residual at
`95-100 h`. The selected candidate was still residual-feasible, because mass
balance/RHS/complementarity were fine, but it was not trajectory-ready. The
methodological implication is to keep `candidate_threshold_ratio` as a guard,
not as the primary score for building a collocation-consistent state start.

Job `735697` then showed that the successful repair-8 line also depends on the
state/flux refresh settings, not only on the score policy. The run was intended
as a no-post-tail `max_iter=5` pulse from repair-8, but the effective TOML had
`collocation_consistent_state_start_final_state_refresh_enabled=false`,
`collocation_consistent_state_start_final_flux_projection_enabled=false`, and
`select_best_damped_state_after_rhs_by_primal_structural_residual`. It froze at
the sequential glucose defect (`max_collocation=0.6189628795658083`) and was
therefore rejected as methodologically incomparable. The follow-up
post-tail-tolerance probe `735703` was canceled early for the same reason. The
correct relaunch must explicitly set both `MPCC_FIXED_CONTROL_*` and
`MPCC_GLOBAL_POLISH_*` aliases for `FINAL_STATE_REFRESH=1`,
`FINAL_FLUX_PROJECTION=1`, `REPAIR_SCORE=collocation_state`, and
`FINAL_STATE_AFTER_RHS_GUARD_SCORE=candidate_threshold_ratio`.

Before the next serious dynamic-control objective submit, the dynamic-control
Slurm entrypoints were aligned with this repair recipe. The liberated-control
and local-pilot sbatches now default to `REPAIR_SCORE=collocation_state`,
`FINAL_STATE_REFRESH=1`, `FINAL_FLUX_PROJECTION=1`,
`FINAL_STATE_AFTER_RHS_REFRESH_RHS=0`, `FINAL_STATE_AFTER_RHS_GUARD_SCORE`
`candidate_threshold_ratio`, and monotone repair enabled. The liberated-control
sbatch also records post-tail repair knobs in metadata, while the objective
leverage submit wrapper forwards the repair recipe and no-cache Julia flags
explicitly. This keeps the next objective experiment from silently falling back
to the older `full_threshold_ratio` / RHS-refresh path.

Job `735726` then reran the no-post-tail `168 h`, `nfe=168`, `max_iter=5`
pulse with the corrected repair8 settings. It reproduced the accepted
repair path and stopped by the monotone guard at
`max_collocation=max_continuity=0.01595863618530302` before Ipopt. Ipopt used
MA86/HSL and limited-memory Hessian, completed the short pulse with
`solver_status=ITERATION_LIMIT` and `primal_status=INFEASIBLE_POINT`, and the
post-solve candidate was rejected as not residual-feasible. The selected
candidate therefore remained the pre-solve start:
`selected_candidate_source=pre_solve_start_values`,
`selected_candidate_residual_feasible=true`, and
`selected_candidate_trajectory_ready=false`.

Final selected residuals from `735726` were
`max_rhs=4.731090519349834e-10`,
`max_collocation=0.015958636562513076`,
`max_continuity=0.01595863906744978`,
`max_mass_balance=5.098000782496111e-7`, and
`max_lower_complementarity=0.00046695906487700457`. The top trajectory defect
remained glucose at the `163-168 h` tail, with the maximum at `167 h`; the top
complementarity residual stayed on `r_2091` near `81 h`. The Ipopt stdout only
printed the banner under this profile, so initial `inf_pr`/`inf_du` were not
available from the Slurm log. Methodologically, this confirms that a short
Ipopt pulse from the corrected repair8 seed does not rescue trajectory
readiness; the next decision should be based on the guarded post-tail tolerance
run, not another no-post-tail pulse.

Jobs `735793` and `735727` then completed the corrected guarded post-tail
tolerance probes with `max_iter=5`, final state/flux refresh enabled,
`REPAIR_SCORE=collocation_state`, `FINAL_STATE_AFTER_RHS_GUARD_SCORE`
`candidate_threshold_ratio`, `POST_TAIL_GUARD_ACCEPT_TOL=0.0015`, and
`POST_TAIL_REFRESH_DYNAMIC_FLUX=1`:

| job | post-tail elements | accepted damping | selected max collocation/continuity | top defect |
| --- | --- | ---: | ---: | --- |
| `735793` | `64:168` | `0.25` | `0.015119612341948141` | fructose at `168 h` |
| `735727` | `96:168` | `0.5` | `0.012077033864954956` | glucose near `95 h` |

Both runs finished normally through Slurm and Ipopt with MA86/HSL and
limited-memory Hessian. In both cases the post-solve candidate was rejected as
not residual-feasible, so the selected candidate remained
`pre_solve_start_values`; it was residual-feasible but not trajectory-ready.
The `96:168` repair is therefore the best fixed-control `168 h` trajectory
residual reached in this family so far, but it is still not promotable. The
practical lesson is that guarded post-tail repair can lower the trajectory
defect when the guard tolerance is relaxed slightly, yet the remaining
glucose/fructose continuity defect is still too large for a blessed handoff.

Job `735849` then reran the fully liberated `168 h` dynamic-control objective
with the corrected repair8 start recipe, no post-tail, `max_iter=13`,
`target_state=isoamyl_acetate` through the `isoamyl_alcohol` proxy, reference
regularization `0.02`, temperature trust `0.25 C`, FDA trust `0.05 g/L`, and
organic trust `0.02 g/L`. It completed on `512x1024/n2` in `00:35:34`
(`MaxRSS=23227372K`) and produced an accepted post-solve candidate:
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`, but
`selected_candidate_trajectory_ready=false`.

The residuals improved relative to the older objective-leverage frontier but
still failed trajectory readiness:
`max_rhs=2.0411542800499407e-7`,
`max_mass_balance=4.7052941278185054e-7`,
`max_collocation=max_continuity=0.04391472496030593`, and
`max_lower_complementarity=0.0019644917695331534`. The dominant trajectory
defect moved to protein at `168 h`. Control movement was still microscopic:
max temperature delta `0.0009296911998255553 C`, FDA sum delta
`1.1827440110745904e-9 g/L`, and organic sum delta
`-1.847506823299261e-5 g/L`.

This is an important positive/negative result: the simultaneous full-control
path is numerically alive and can accept a residual-feasible post-solve, but
the aroma/nutrient/thermal objective by itself still does not create meaningful
leverage. Job `735890` was therefore submitted as the first progress-biased
pilot with `terminal_sugar_weight=0.5` and `terminal_sugar_scale_g_L=100.0`
using the same trust regions and no post-tail.

Job `735861` tested the same objective-leverage setup with the fixed-control
post-tail repair recipe enabled on elements `96:168`
(`guard_accept_tol=0.0015`). It completed on `512x1024/n2` in `00:39:43`
(`MaxRSS=23150572K`) and accepted the post-solve candidate:
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`,
`selected_candidate_trajectory_ready=false`. Relative to `735849`, post-tail
improved the dynamic full-control trajectory residual from
`max_collocation=max_continuity=0.04391472496030593` to
`0.029801142713587025`, with `max_mass_balance=2.839938701981737e-7` and
`max_lower_complementarity=0.00196793405940649`.

The scientific interpretation is useful but not sufficient: post-tail improves
residual health for the liberated-control MPCC, yet control movement remains
microscopic (`max temperature delta=0.0011331180194957824 C`, FDA sum delta
`1.4480529327971394e-9 g/L`, organic sum delta
`-3.599517706254218e-5 g/L`). Therefore post-tail is a stabilizer, not the
main leverage mechanism. After confirming Slurm availability, job `735909` was
submitted as the stronger progress-biased variant with
`terminal_sugar_weight=1.0` and the same trust regions/no post-tail.

Job `735890` completed the first progress-biased pilot
(`terminal_sugar_weight=0.5`, `terminal_sugar_scale_g_L=100.0`) on `full/n14`
in `00:52:26` (`MaxRSS=22838244K`). The sugar term was active
(`dynamic_control_objective_terminal_sugar_terms=1`) and the post-solve
candidate was accepted:
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`,
`selected_candidate_trajectory_ready=false`. Numerically, however, it was
essentially the same negative leverage result as the no-sugar `735849`:
`max_collocation=max_continuity=0.043914720434798465`,
`max_mass_balance=4.705295937180114e-7`, and
`max_lower_complementarity=0.001964550479625147`. Control movement remained
microscopic (`max temperature delta=0.0009281620863710316 C`, FDA sum delta
`1.1824477654339001e-9 g/L`, organic sum delta
`-1.8485914153765215e-5 g/L`).

Interpretation: the terminal sugar term is wired and accepted by the MPCC, but
weight `0.5` is not enough to alter the liberated controls. The next live test
is `735909` (`terminal_sugar_weight=1.0`). If that remains microscopic too,
the next methodological move should not be another tiny weight increment; it
should either rescale/reformulate the progress objective or combine progress
pressure with post-tail only as a numerical stabilizer.

Job `735909` completed the stronger progress-biased pilot
(`terminal_sugar_weight=1.0`, `terminal_sugar_scale_g_L=100.0`) on `full/n14`
in `00:48:20` (`MaxRSS=23961748K`). The sugar term was active and the
post-solve candidate was again accepted:
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`,
`selected_candidate_trajectory_ready=false`. The residual profile stayed
essentially unchanged from the no-sugar and `0.5` sugar-weight cases:
`max_collocation=max_continuity=0.04391471586990281`,
`max_mass_balance=4.70529380125793e-7`, and
`max_lower_complementarity=0.001964464497178993`. The dominant trajectory
defect remained protein at `168 h`, with top complementarity on `r_1914` near
`36.155 h`.

Control movement was still microscopic:
max temperature delta `0.0009270920107802283 C`, FDA sum delta
`1.1827652823070821e-9 g/L`, and organic sum delta
`-1.8494615961317518e-5 g/L`. This rules out small terminal-sugar penalties as
a sufficient leverage mechanism. The next technical step should be objective
instrumentation and a bolder progress-pressure rescaling/reformulation, not a
sequence of small sugar-weight increments.

To avoid another tiny escalation, the next experiment jumped directly to
`terminal_sugar_weight=100.0` while keeping the same `100 g/L` sugar scale,
trust regions, limited-memory Hessian, and `max_iter=13`. Two Slurm jobs were
submitted in parallel: `735967` without post-tail on `full/n8`, and `735968`
with the previously useful post-tail stabilizer on elements `96:168`
(`guard_accept_tol=0.0015`) on `512x1024/n2`.

Job `735968` completed in `00:36:54` (`MaxRSS=27038472K`) and accepted the
post-solve candidate:
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`,
`selected_candidate_trajectory_ready=false`. The stronger sugar pressure did
not materially change the residual picture relative to the weaker post-tail
dynamic objective:
`max_collocation=max_continuity=0.029801136019287047`,
`max_mass_balance=2.839391299858107e-7`, and
`max_lower_complementarity=0.0019696466978728557`. The new terminal-state
instrumentation reported `glucose=30.967482933902183 g/L`,
`fructose=60.88378424325087 g/L`,
`total_sugar=91.85126717715306 g/L`, and
`isoamyl_alcohol=0.001553851776762865 g/L` at `168 h`.

Control movement also remained microscopic despite the 100x sugar term:
max temperature delta `0.0011247825605593675 C`, FDA sum delta
`1.4697057448527081e-9 g/L`, and organic sum delta
`-3.594635176751293e-5 g/L`. Plots and diagnostics were written under
`/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_sugar100_reg0p02_iter13_posttail96_guardtol1p5e3_20260615_220752/plots`
and `.../objective_diagnostics`.

Job `735967`, the no-post-tail comparator, was cancelled after `01:02:06`
(`MaxRSS=4741248K`) because it stayed inside `before_mpcc_solve_attempt`
without reaching the Ipopt banner or producing an attempt artifact. Since
`735968` had already produced the relevant strong-sugar/post-tail result, the
comparison had low remaining value relative to continued node use.

Interpretation: terminal sugar pressure, even made deliberately large, is not
the missing leverage mechanism in the current MPCC setup. The controls are
still effectively pinned. The next useful development step is to reformulate
the dynamic objective/control release itself: expose state/control sensitivity
more directly, or add a process-progress objective over the horizon rather
than only terminal sugar, while preserving post-tail as a numerical
stabilizer.

## Integrated sugar-progress objective

The reduced simultaneous MPCC objective now supports an opt-in integrated
sugar-progress term controlled by
`MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_WEIGHT` and
`MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_SCALE_G_L`. The term is a
Radau time average of squared total sugar, scaled by horizon length, so it
penalizes slow progress throughout the fermentation rather than only terminal
sugar. The submit table was extended with explicit integrated-sugar columns so
future pilots can be reproduced from variant IDs instead of ad hoc environment
overrides.

Job `736067` tested the first integrated-sugar pilot with
`integrated_sugar_weight=100`, `integrated_sugar_scale_g_L=100`,
`terminal_sugar_weight=0`, reference regularization `0.02`, and post-tail
repair on elements `96:168` with `guard_accept_tol=0.0015`. It completed on
`512x1024/n2` in `00:35:55` (`MaxRSS=25960880K`). The integrated sugar term was
active (`dynamic_control_objective_integrated_sugar_terms=1`) and the
post-solve candidate was accepted:
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`,
`selected_candidate_trajectory_ready=false`. Residual health stayed comparable
to the strong terminal-sugar post-tail pilot:
`max_rhs=2.3960159770833283e-8`,
`max_mass_balance=2.839653916453244e-7`,
`max_collocation=max_continuity=0.029801516550367484`, and
`max_lower_complementarity=0.001962604442304551`.

The terminal state remained essentially unchanged:
`glucose=30.968487588468637 g/L`,
`fructose=60.8847805074678 g/L`,
`total_sugar=91.85326809593644 g/L`, and
`isoamyl_alcohol=0.001552512285517651 g/L`. Control movement also remained
microscopic: max temperature delta `0.0010173993653594948 C`, FDA sum delta
`1.4707454793009445e-9 g/L`, and organic sum delta
`-2.1048830754599734e-5 g/L`. Plots and diagnostics were written under
`/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_integratedsugar100_reg0p02_iter13_posttail96_guardtol1p5e3_20260615_233438/plots`
and `.../objective_diagnostics`.

Job `736080` tested the same integrated-sugar/post-tail setup with reference
regularization removed (`reference_regularization_weight=0.0`) on `full/n8`.
It was cancelled at `2026-06-16 00:44 CLT` after `00:59:32`
(`MaxRSS=4504124K`) because it produced only the decision spec and start
schedule, stayed in `before_mpcc_solve_attempt`, and did not reach the
high-memory Ipopt/MA86 phase or write an attempt CSV. This makes the zero-anchor
comparison inconclusive, not a failed numerical candidate.

Interpretation: the lack of control movement is not solved by replacing the
terminal sugar penalty with an integrated sugar-progress penalty, at least not
at the current scaling/trust/repair recipe. The next technical direction should
not be a larger scalar weight alone. More defensible next steps are to diagnose
control-state sensitivities directly, simplify or stage the objective so the
optimizer sees a stronger local gradient, or temporarily release a smaller
control subset with a cheaper horizon before returning to full 168 h.

## Sequential control sensitivity diagnostic

A new Slurm-only diagnostic script was added to evaluate local
control-to-state sensitivity using the sequential simulator before launching
more simultaneous MPCC objective pilots. It starts from a selected dynamic
control policy, perturbs selected 12 h slots one at a time, runs
`simulate_reduced_dfba`, and writes both a full CSV and a ranked table by
absolute impact on final total sugar. The default run is still 168 h, but the
cluster sbatch allows cheap 24 h and 72 h smokes through environment
overrides.

Job `736199` validated the diagnostic with a 24 h, 4-case smoke on `full/n8`,
using 4 CPUs, 16 GB, no Julia cache images, and `OPENBLAS_NUM_THREADS=1`.
It completed in `00:14:35` with `MaxRSS=1244516K`; all four cases succeeded.
The run root was
`/home/cltorrealba/mpcc_runs/dynamic_control_sequential_sensitivity_24h_4cases_20260616_011925`.

Results:

| case | perturbation | final sugar | delta final sugar | sugar consumed delta | final isoamyl alcohol delta |
| --- | ---: | ---: | ---: | ---: | ---: |
| `baseline` | none | `205.68872569587535` | `0.0` | `0.0` | `0.0` |
| `temperature_1_plus` | `+0.25 C` | `205.66856660714225` | `-0.020159088733095132` | `0.020159088733095132` | `6.696467818037772e-7` |
| `temperature_1_minus` | `-0.25 C` | `205.70921748023866` | `0.020491784363315446` | `-0.020491784363315446` | `-6.675957203903474e-7` |
| `fda_1_plus` | `+0.05 g/L` | `205.60207736449166` | `-0.08664833138368522` | `0.08664833138368522` | `1.9847657896314278e-7` |

Interpretation: this small smoke confirms that the sequential simulator has
detectable local gradients in the released controls. Early FDA moved sugar
progress more than the first-slot temperature perturbation over 24 h, while
temperature had a clearer local sign on isoamyl alcohol. This supports the
next staged move: expand the sensitivity sweep to a longer horizon and more
slots, then use the ranked slots to build a smaller simultaneous MPCC pilot
with only the most responsive controls released.

Job `736219` expanded the same diagnostic to `72 h` with 13 cases on
`full/n14`, using 4 CPUs, 16 GB, and no Julia cache images. It completed in
`00:15:42` with `MaxRSS=1345928K`; all cases succeeded. The run root was
`/home/cltorrealba/mpcc_runs/dynamic_control_sequential_sensitivity_72h_13cases_20260616_013623`.

Baseline at `72 h` had final total sugar `163.4350838070587 g/L`, sugar
consumed `56.5649161929413 g/L`, final isoamyl alcohol
`0.00034265445929423753 g/L`, and ethanol `27.61027633929135 g/L`.

Top local progress and aroma signals:

| case | perturbation | delta sugar consumed | sensitivity sugar/unit | delta isoamyl alcohol |
| --- | ---: | ---: | ---: | ---: |
| `organic_1_plus` | `+0.02 g/L` | `0.441436634` | `22.0718317` | `5.42733789e-6` |
| `organic_3_plus` | `+0.02 g/L` | `0.215571154` | `10.7785577` | `1.57286406e-5` |
| `fda_1_plus` | `+0.05 g/L` | `0.20380908` | `4.07618161` | `1.07874555e-6` |
| `temperature_6_plus` | `+0.25 C` | `0.111340717` | `0.445362869` | `2.04614686e-7` |
| `temperature_1_plus` | `+0.25 C` | `0.0972926789` | `0.389170716` | `6.34146902e-7` |

The strongest isoamyl gains came from organic additions at slots 5 and 3:
`organic_5_plus` increased isoamyl by `1.7652926e-5 g/L`, and
`organic_3_plus` by `1.57286406e-5 g/L`. Mid/late FDA was mixed:
`fda_3_plus` increased isoamyl by `9.33298888e-6 g/L` but reduced sugar
consumed by `8.63897602 g/L`; `fda_5_plus` showed the same unfavorable sugar
tradeoff. This argues for a partial-control MPCC pilot that frees a small
organic-centered subset first, rather than freeing all nutrient slots or
pushing FDA late.

The liberated-spec tooling now supports explicit control indices and resizes
base policies to shorter horizons before building trust-region bounds. Slurm
smoke `736255` validated a 72 h explicit-index spec with
`temperature_indices=1,3,6` and `addition_indices=1,3,5`. It completed on
`full/n14` in `00:03:53` and produced a spec with free controls
`temperature_C[1,3,6]`, `fda_g_L[1,3,5]`, and `organic_g_L[1,3,5]`.
The fixed-control solve entrypoint now applies the same resize rule when
building shorter-horizon schedules from the 168 h policy-selection CSV.

Job `736228` is running the corresponding wider `168 h`, 21-case sequential
sensitivity map on `full/n8`. Its purpose is to choose the first 168 h
partial-control MPCC subset from measured local sensitivities rather than from
manual intuition.

## Partial-control 72 h MPCC pilot

Job `736263` launched the first simultaneous MPCC objective pilot with a
small explicit-control subset, using the 72 h sensitivity signal rather than
freeing the full profile:

- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_partial72_T136_N135_integratedsugar100_20260616_021511`;
- partition/node: `512x1024/n11`;
- resources: 8 CPUs, 32 GB, no GPU, `OPENBLAS_NUM_THREADS=1`;
- elapsed: `00:23:56`, `MaxRSS=10446112K`;
- horizon/NFE: `72 h`, `nfe=72`;
- free controls: temperature slots `1,3,6`, FDA slots `1,3,5`, organic slots
  `1,3,5`;
- objective: terminal isoamyl target requested as `isoamyl_acetate`, resolved
  through `isoamyl_alcohol`, with integrated sugar-progress weight `100`.

The job reached Ipopt/MA86 cleanly and accepted the post-solve candidate:
`solver_status=ITERATION_LIMIT`, `primal_status=NEARLY_FEASIBLE_POINT`,
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`, and
`selected_candidate_trajectory_ready=false`.

Residuals improved substantially relative to the previous 168 h full-control
pilots:

| metric | value |
| --- | ---: |
| max RHS residual | `1.2960566370123772e-8` |
| max mass balance residual | `2.2690513815440405e-7` |
| max collocation/continuity residual | `0.007648743926640551` |
| max lower complementarity residual | `2.749095568095716e-5` |

Terminal selected-candidate values at `72 h` were:
`glucose=100.71294365785714 g/L`,
`fructose=93.91182580615937 g/L`,
`total_sugar=194.6247694640165 g/L`, and
`isoamyl_alcohol=0.0006693348775599231 g/L`.

The central limitation remains control leverage. The post-solve candidate
captured dynamic controls but moved them only microscopically:
max temperature delta `0.0008613081650814536 C`, FDA sum delta
`1.4957458549245467e-11 g/L`, and organic sum delta
`-0.00010543062364581912 g/L`. Plots and leverage diagnostics were written to
`case/plots/optimized_control_profiles.png` and
`case/objective_diagnostics/dynamic_control_objective_leverage_diagnostics.md`.

Interpretation: explicit partial-control release is numerically viable and
much cheaper than full 168 h control release, but the current objective/cost
scaling still does not create meaningful control movement. The next MPCC
pilot should use the same partial-control scaffold but reduce or temporarily
remove nutrient/reference penalties, or directly seed an organic-positive
perturbation before solving, instead of only increasing scalar aroma/sugar
weights.

### Soft-cost and seeded-start follow-up

Job `736295` repeated the same 72 h explicit-control subset with reference
regularization removed and softer nutrient/thermal/smoothness costs:

- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_partial72_T136_N135_integratedsugar100_softcost_20260616_024418`;
- partition/node: `512x1024/n11`;
- resources: 8 CPUs, 32 GB, no GPU, `OPENBLAS_NUM_THREADS=1`;
- elapsed: `00:23:49`, `MaxRSS=10476004K`;
- objective: terminal isoamyl target requested as `isoamyl_acetate`, resolved
  through `isoamyl_alcohol`, integrated sugar-progress weight `100`, nutrient
  cost `0.02`, thermal cost `0.005`, smoothness cost `0.005`, and reference
  regularization `0.0`.

The run again reached Ipopt/MA86 cleanly and accepted the post-solve
candidate:
`solver_status=ITERATION_LIMIT`, `primal_status=NEARLY_FEASIBLE_POINT`,
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`, and
`selected_candidate_trajectory_ready=false`.

Key residuals were essentially unchanged from the previous partial 72 h
pilot:

| metric | value |
| --- | ---: |
| max RHS residual | `1.3979778695771827e-8` |
| max mass balance residual | `2.269132711599578e-7` |
| max collocation/continuity residual | `0.007649059783343696` |
| max lower complementarity residual | `2.7488807555758838e-5` |

Terminal selected-candidate values were:
`total_sugar=194.62479221949013 g/L` and
`isoamyl_alcohol=0.0006766764393477918 g/L`. The isoamyl endpoint improved
slightly relative to job `736263`, but control movement remained tiny:
temperature max delta `0.0006852525709710733 C`, FDA sum delta
`6.659625361508961e-11 g/L`, and organic sum delta
`-0.00011312841117200323 g/L`.

Interpretation: softer objective costs are not enough to move controls from a
zero/near-reference start. The next diagnostic is therefore a deliberately
seeded start, not another scalar weight increase.

To make that reproducible, the liberated-control tooling now supports indexed
start offsets:

- `MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_START_OFFSETS_C`;
- `MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_START_OFFSETS_G_L`;
- `MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_START_OFFSETS_G_L`.

Tokens use `slot=value`, for example `1=0.02,3=0.02,5=0.02`. Offsets are
applied before the `DynamicControlDecisionSpec` is built, so the start
schedule, variable starts, trust-region bounds, metadata, and plots stay
consistent. Defaults are empty, so existing jobs remain unchanged.

Job `736324` launched the first seeded follow-up on `512x1024/n2` with the
same 72 h subset and soft-cost objective, but with organic start offsets
`1=0.02,3=0.02,5=0.02`. The generated spec confirms:
`organic_g_L[1]=0.42` with bounds `[0.4, 0.44]`,
`organic_g_L[3]=0.02` with bounds `[0.0, 0.04]`, and
`organic_g_L[5]=0.02` with bounds `[0.0, 0.04]`.

Job `736324` completed in `00:15:49` on `512x1024/n2` with
`MaxRSS=11867496K`. It again accepted the post-solve candidate:
`solver_status=ITERATION_LIMIT`, `primal_status=NEARLY_FEASIBLE_POINT`,
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`, and
`selected_candidate_trajectory_ready=false`.

The seed had strong biological leverage but worsened trajectory/complementarity
residuals:

| metric | unseeded soft-cost `736295` | organic seed `736324` |
| --- | ---: | ---: |
| terminal total sugar | `194.62479221949013` | `158.60765733112999` |
| terminal isoamyl alcohol | `0.0006766764393477918` | `0.001350166966378984` |
| max RHS residual | `1.3979778695771827e-8` | `2.9437530191245287e-9` |
| max collocation/continuity residual | `0.007649059783343696` | `0.01851749242737908` |
| max lower complementarity residual | `2.7488807555758838e-5` | `0.0010877030622489991` |

The post-solve controls stayed near the seeded profile: organic total changed
by only `7.299710648799029e-6 g/L` from the seeded start, FDA remained at
effectively zero, and max temperature movement was `0.0006700795805585358 C`.
Interpretation: the biological control leverage is real, but the simultaneous
NLP does not discover it from a zero/near-reference start. The next useful
step is a small seed-amplitude continuation rather than another pure objective
weight sweep.

Job `736350` was submitted as the first continuation point with organic start
offsets `1=0.01,3=0.01,5=0.01`, again on the same 72 h subset and soft-cost
objective.

Job `736350` completed in `00:15:50` on `512x1024/n2` with
`MaxRSS=9466200K`. It also accepted the post-solve candidate and stayed
residual-feasible but not trajectory-ready:
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`,
`selected_candidate_trajectory_ready=false`.

Compared with the `0.02 g/L` organic seed, halving the seed did not recover
the trajectory defect:

| metric | organic seed `0.02` | organic seed `0.01` |
| --- | ---: | ---: |
| terminal total sugar | `158.60765733112999` | `158.94331972256157` |
| terminal isoamyl alcohol | `0.001350166966378984` | `0.0011993577179949414` |
| max RHS residual | `2.9437530191245287e-9` | `3.329316045075359e-9` |
| max collocation/continuity residual | `0.01851749242737908` | `0.018229316800964367` |
| max lower complementarity residual | `0.0010877030622489991` | `0.0010825102538609933` |

The half-seed keeps most of the sugar-progress benefit and a substantial
aroma gain, but the residual profile remains in the same numerical regime.
This suggests the hard part is activating the organic-nutrient branch inside
the simultaneous MPCC, not just using too large a seed. Job `736375` therefore
tests the `0.02 g/L` organic seed again with `COLLOCATION_REPAIR_MAX_ITER=12`
to see whether the mid-horizon ethanol/collocation defect can be repaired
without giving up the biological leverage.

Job `736375` completed in `00:15:55` on `512x1024/n2` with
`MaxRSS=9824500K`. Increasing the all-element collocation repair budget from
8 to 12 did not change the result in any meaningful way:

| metric | organic seed `0.02`, repair8 | organic seed `0.02`, repair12 |
| --- | ---: | ---: |
| terminal total sugar | `158.60765733112999` | `158.60765733113055` |
| terminal isoamyl alcohol | `0.001350166966378984` | `0.001350166966004684` |
| max RHS residual | `2.9437530191245287e-9` | `2.9437529081022262e-9` |
| max collocation/continuity residual | `0.01851749242737908` | `0.01851749242738028` |
| max lower complementarity residual | `0.0010877030622489991` | `0.0010877030617768566` |

Interpretation: simply allowing more global repair iterations is not the
missing ingredient. The remaining defect is tied to the organic-seeded branch
itself. Job `736392` was submitted with only the first organic slot seeded
(`1=0.02`) to isolate whether the early organic addition alone creates the
same mid-horizon trajectory/complementarity defect.

The sequential sensitivity script now also writes checkpoint outputs after
each completed case:
`dynamic_control_sequential_sensitivity_partial.csv` and
`dynamic_control_sequential_sensitivity_ranked_partial.csv`. This prevents a
long/stiff 168 h perturbation from hiding all earlier completed cases until
the full sweep exits.

Job `736392` completed the early-slot isolation test: only the first organic
slot was seeded (`1=0.02`, giving `organic_g_L[1]=0.42` with trust
`[0.40,0.44]`). It reproduced both the biological improvement and the
numerical defect:

| metric | unseeded soft-cost `736295` | organic slot-1 seed `736392` |
| --- | ---: | ---: |
| terminal total sugar | `194.62479221949013` | `158.86692307323187` |
| terminal isoamyl alcohol | `0.0006766764393477918` | `0.0013184423047529947` |
| max RHS residual | `1.3979778695771827e-8` | `2.6327851010421455e-9` |
| max collocation/continuity residual | `0.007649059783343696` | `0.018517427686112913` |
| max lower complementarity residual | `2.7488807555758838e-5` | `0.0010881125089638112` |

The new lightweight comparer
`scripts/main_compare_dynamic_control_mpcc_cases.py` wrote the side-by-side
report to
`repro/generated/dynamic_control_branch_comparison_unseeded_vs_slot1/`.
It makes the branch switch explicit:

- unseeded top trajectory residual: glucose near `28 h`;
- unseeded top complementarity residual: `r_0203` near `22.64 h`;
- organic slot-1 seed top trajectory residual: ethanol near `31 h`;
- organic slot-1 seed top complementarity residual: `r_2091` near `30 h`.

Reaction lookup against `Antecedentes/yeast-GEM.xlsx` gives the biological
interpretation of the active complementarity hotspots:

- `r_0203`: anthranilate synthase;
- `r_1914`: L-valine exchange;
- `r_2091`: urea exchange.

Interpretation: the early organic addition is not merely adding objective
pressure. It activates a nitrogen/amino-acid branch that is biologically useful
for sugar progress and aroma, but the simultaneous MPCC start does not yet
land on a trajectory-ready collocation representation of that branch.
Therefore the next probes should target branch-consistent initialization,
localized repair, or mesh/discretization around the 29--44 h defect, rather
than another global objective-weight sweep.

Two targeted Slurm diagnostics were submitted from this conclusion:

- `736420`: 72 h slot-1 organic seed with `COLLOCATION_REPAIR_ELEMENTS=29:44`
  and `COLLOCATION_REPAIR_FLUX_REFRESH_MAX_ITER=2`;
- `736421`: 72 h slot-1 organic seed with all-element base repair,
  post-tail repair on `29:44`, final complementarity flux projection enabled,
  and `COLLOCATION_REPAIR_FLUX_REFRESH_MAX_ITER=2`.

Job `736420` completed in `00:15:47` on `512x1024/n11`
(`MaxRSS=9598456K`). It is not a viable repair path. Localized repair
improved lower complementarity but displaced a much larger trajectory defect
to the right edge of the repair window:

| metric | organic slot-1 seed `736392` | repair `29:44` + flux refresh `736420` |
| --- | ---: | ---: |
| terminal total sugar | `158.86692307323187` | `163.00104669355454` |
| terminal isoamyl alcohol | `0.0013184423047529947` | `0.00037401693041518063` |
| max collocation/continuity residual | `0.018517427686112913` | `0.08677755206094555` |
| max lower complementarity residual | `0.0010881125089638112` | `4.2186412949763693e-7` |
| top trajectory residual | ethanol near `31 h` | glucose near `44.16 h` |
| top complementarity residual | `r_2091` near `30 h` | `r_1588` near `9.16 h` |

Interpretation: the repair can force complementarity down, but it does so by
breaking trajectory consistency and losing the aroma gain. This supports a
mesh/discretization test rather than further local repair tuning. Job `736440`
was submitted on idle node `n2` with the same slot-1 organic seed and
`nfe=144` over `72 h`, all-element standard repair, no final complementarity
flux projection, and `48G` memory. This tests whether halving the element size
can reduce the 29--44 h collocation defect while preserving the useful
organic-nutrient branch.

Job `736421` completed in `00:25:02` on `512x1024/n11`
(`MaxRSS=10399824K`). It also does not fix the branch. Relative to the
slot-1 seed baseline, post-tail repair plus final complementarity flux
projection is essentially neutral:

| metric | organic slot-1 seed `736392` | post-tail + compflux `736421` |
| --- | ---: | ---: |
| terminal total sugar | `158.86692307323187` | `158.86692465363134` |
| terminal isoamyl alcohol | `0.0013184423047529947` | `0.0013185118500490922` |
| max collocation/continuity residual | `0.018517427686112913` | `0.018517427621811293` |
| max lower complementarity residual | `0.0010881125089638112` | `0.0010881151277118569` |
| top trajectory residual | ethanol near `31 h` | ethanol near `31 h` |
| top complementarity residual | `r_2091` near `30 h` | `r_2091` near `30 h` |

The attempted final complementarity projection triggered on `162` points, but
the guard rejected it (`active_complementarity_flux_projection_applied=false`).
Post-tail repair on `29:44` was also rejected by the guard after all damping
trials. Interpretation: the current guarded projection/repair machinery is
protecting against worse candidates, but it cannot rescue this branch. The
active next diagnostic remains the `nfe=144` mesh test (`736440`).

Job `736440` completed in `00:25:29` on `512x1024/n2`
(`MaxRSS=22064568K`). It reduced the trajectory defect substantially, but it
is not a clean comparison with the 72 h control-grid tests because
`schedule_hours=168` was still active. That produced 14 temperature slots and
13 addition slots, instead of the 6 temperature slots and 5 addition slots
used by the 72 h NFE72 branch tests.

| metric | organic slot-1 seed NFE72 `736392` | NFE144, schedule 168 `736440` |
| --- | ---: | ---: |
| terminal total sugar | `158.86692307323187` | `194.7656939931337` |
| terminal isoamyl alcohol | `0.0013184423047529947` | `0.0005812707752082741` |
| max collocation/continuity residual | `0.018517427686112913` | `0.00018226599474520616` |
| max lower complementarity residual | `0.0010881125089638112` | `0.00047668667142285214` |
| top trajectory residual | ethanol near `31 h` | protein near `25 h` |
| top complementarity residual | `r_2091` near `30 h` | `r_1862` near `16.32 h` |

Interpretation: mesh refinement may help numerically, but the `736440`
biology cannot be interpreted as preserving the same branch because the
control schedule changed. The submit helper now passes and prints
`MPCC_FIXED_CONTROL_SCHEDULE_HOURS` explicitly so shorter-horizon tests do not
silently inherit a 168 h control grid.

Job `736475` was submitted as the corrected comparison:
`solve_hours=72`, `nfe=144`, `schedule_hours=72`, slot-1 organic seed
`1=0.02`, all-element standard repair, no final complementarity flux
projection, and `48G` memory on `512x1024/n2`. Its decision spec confirms the
intended 72 h topology: 6 temperature slots, 5 addition slots, and
`organic_g_L[1]=0.42` with bounds `[0.40, 0.44]`.

Job `736475` completed in `00:24:45` on `512x1024/n2`
(`MaxRSS=19407976K`). It reached Ipopt/MA86 cleanly and accepted the
post-solve candidate:
`solver_status=ITERATION_LIMIT`, `primal_status=NEARLY_FEASIBLE_POINT`,
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`, and
`selected_candidate_trajectory_ready=false`.

The corrected schedule result is nearly identical to the earlier NFE144
schedule-168 run:

| metric | organic slot-1 seed NFE72 `736392` | NFE144 schedule 72 `736475` |
| --- | ---: | ---: |
| terminal total sugar | `158.86692307323187` | `194.76569854236476` |
| terminal isoamyl alcohol | `0.0013184423047529947` | `0.00058171039106048` |
| max RHS residual | `2.6327851010421455e-9` | `1.8157183645506336e-8` |
| max collocation/continuity residual | `0.018517427686112913` | `0.00018226595920548612` |
| max lower complementarity residual | `0.0010881125089638112` | `0.00047758535446462946` |
| top trajectory residual | ethanol near `31 h` | protein near `25 h` |
| top complementarity residual | `r_2091` near `30 h` | `r_1862` near `16.32 h` |

Interpretation: the large sugar-progress/aroma gain from the NFE72 organic
slot-1 seed does not survive mesh refinement. It should be treated as a
trajectory-defect artefact, not as a branch to preserve. The robust path is to
advance on mesh-consistent starts and use the sequential 168 h sensitivity to
seed nutrients gently, rather than trying to rescue the NFE72 artefact.

Job `736504` was submitted as the first full-profile 168 h pilot after this
decision: `solve_hours=168`, `nfe=168`, `schedule_hours=168`,
`MPCC_DYNAMIC_CONTROL_LIBERATION_MODE=full`, organic start offsets
`1=0.02,4=0.02`, all-element standard repair, no final complementarity flux
projection, `8` CPUs, and `48G` memory on `512x1024/n2`.

The long 168 h sequential sensitivity sweep (`736358`) was cancelled after it
stalled on the late `organic_12_plus` case with no checkpoint update for more
than one hour. The completed partial sweep was kept. The useful directional
signal is early-nutrient dominated: `organic_1_plus` and `organic_4_plus`
both improved sugar consumption and isoamyl alcohol in the sequential model,
whereas temperature perturbations were much smaller. This is why `736504`
uses gentle early organic offsets in slots 1 and 4 instead of trying to
preserve the defective NFE72 branch.

To separate dimensionality from nutrient leverage, job `736516` was submitted
as a companion 168 h pilot: `solve_hours=168`, `nfe=168`,
`schedule_hours=168`, `MPCC_DYNAMIC_CONTROL_LIBERATION_MODE=explicit`,
`MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_INDICES=none`,
`MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_INDICES=all`, and the same organic
start offsets `1=0.02,4=0.02`. It excludes node `n2`, uses `8` CPUs and
`48G` memory on `512x1024`, and is intended as a nutrient-only comparison
against the full-profile job `736504`.

Job `736504` completed in `00:36:08` on `512x1024/n2`
(`MaxRSS=23702884K`). Ipopt/MA86 ran successfully and selected the post-solve
candidate:
`solver_status=ITERATION_LIMIT`, `primal_status=NEARLY_FEASIBLE_POINT`,
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`, and
`selected_candidate_trajectory_ready=false`.

The biological result is materially better than the earlier non-seeded
full-horizon starts, but it is not due to optimized control movement. The
post-solve deltas versus the pre-solve seeded schedule are essentially zero:
max temperature delta `7.055446360482165e-8 C`, FDA sum delta
`1.4981286394151892e-7 g/L`, and organic sum delta
`9.873502099244647e-8 g/L`.

| metric | full-profile 168 h `736504` |
| --- | ---: |
| terminal total sugar | `90.29805621473963` |
| terminal glucose | `29.672837275864318` |
| terminal fructose | `60.62521893887531` |
| terminal isoamyl alcohol | `0.00042413985656954633` |
| max RHS residual | `1.8044767003874466e-7` |
| max collocation/continuity residual | `0.05007421921956561` |
| max lower complementarity residual | `0.001656950829393707` |
| top trajectory residual | protein at `168 h` |
| top complementarity residual | `r_1914` near `52.64 h` |

Interpretation: the early organic offsets are a useful biological seed, but
the current simultaneous objective is still not creating meaningful control
movement. The remaining trajectory defect is a tail protein
collocation/continuity mismatch, not a temperature or nutrient-bound failure.
The candidate is useful for diagnosis and continuation design, but not yet a
blessed trajectory for optimization handoff.

Job `736516`, the nutrient-only companion, completed in `01:00:37` on
`512x1024/n1` (`MaxRSS=23606160K`). It also ran Ipopt/MA86 successfully and
selected the post-solve candidate:
`solver_status=ITERATION_LIMIT`, `primal_status=NEARLY_FEASIBLE_POINT`,
`selected_candidate_source=post_solve_values`,
`selected_candidate_residual_feasible=true`, and
`selected_candidate_trajectory_ready=false`.

The direct comparison against `736504` shows that freeing temperature did not
change the accepted candidate in any meaningful way:

| metric | full profile `736504` | nutrient only `736516` |
| --- | ---: | ---: |
| terminal total sugar | `90.29805621473963` | `90.2980562147185` |
| terminal isoamyl alcohol | `0.00042413985656954633` | `0.0004241398150731621` |
| max collocation/continuity residual | `0.05007421921956561` | `0.05007421921956583` |
| max lower complementarity residual | `0.001656950829393707` | `0.00165695082933871` |
| max temperature movement | `7.055446360482165e-8 C` | `0.0 C` |
| FDA sum movement | `1.4981286394151892e-7 g/L` | `1.4981300616924617e-7 g/L` |
| organic sum movement | `9.873502099244647e-8 g/L` | `9.874271295062798e-8 g/L` |

The generated comparison report is
`repro/generated/dynamic_control_full_vs_nutrient_only_168_seedorg1_4/dynamic_control_branch_comparison.md`.
Interpretation: the current objective and start make the simultaneous solve
accept the seeded trajectory but do not make the optimizer use the free
controls. The next technical step should target objective/control activation
or tail repair of the protein collocation defect, rather than liberating more
temperature degrees of freedom.

## Normalized objective diagnostics, 2026-06-16

The serious-objective scaffold was revised so sugar is no longer treated as a
reward term. Instead, the reduced MPCC can add explicit nonnegative slacks for:

- terminal aroma deficit relative to a provisional target;
- terminal sugar excess above a dryness target.

For the first provisional normalization:

- `MPCC_REDUCED_DCDFBA_BASE_OBJECTIVE_MODE=zero`;
- aroma proxy target `isoamyl_alcohol >= 0.00050 g/L`, scale `0.00005 g/L`;
- terminal dryness target `glucose + fructose <= 5 g/L`, slack scale `5 g/L`;
- nutrient scale `0.44 g/L`, matching the current organic-product seed scale;
- temperature energy scale `5 C` around `20 C`;
- temperature smoothness scale `2 C`.

Jobs `736989`, `736990`, and `736992` tested narrow-trust normalized variants:

| variant | sugar g/L | isoamyl alcohol g/L | objective | sugar share | max T move | FDA sum move | organic sum move | colloc/continuity |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| balance | `91.6405532012` | `0.000399517091` | `3187.28419991` | `0.998635649316` | `0.00308554341179 C` | `3.28304749978e-08 g/L` | `-2.93201598018e-05 g/L` | `0.0437208129867` |
| aroma3 | `91.640096701` | `0.000399733199` | `3181.52338283` | `0.996623402565` | `0.00496586884863 C` | `2.68998738802e-08 g/L` | `-3.32259217515e-05 g/L` | `0.0436324343444` |
| cost3 | `91.6402761106` | `0.000399694935` | `3177.91050719` | `0.997933438113` | `0.00383114179535 C` | `2.42187741878e-08 g/L` | `-6.91085499653e-05 g/L` | `0.0436410596952` |

All three selected the post-solve candidate and were residual-feasible but not
trajectory-ready. The base objective reconstruction is now correctly zero.
The comparison report is:
`repro/generated/dynamic_control_normalized_objective_narrow_20260616/dynamic_control_branch_comparison.md`.

Interpretation: with narrow trust, changing normalized weights does not create
meaningful control movement. The objective is dominated by terminal sugar
excess, yet the terminal sugar and aroma proxy barely change. The active
blocker remains the structural trajectory defect, with the top residual again
in late-horizon `protein` continuity/collocation.

Three follow-up Slurm diagnostics were submitted with wide trust and
`max_iter=25` to separate objective scalarization from actual control leverage:

| job | variant | purpose |
| --- | --- | --- |
| `737068` | `normalized_balance_wide_sugar5_aroma0p5mg_basezero_iter25` | sugar slack + aroma deficit + costs, wide trust |
| `737069` | `normalized_sugaronly_wide_sugar5_basezero_iter25` | terminal sugar excess only, no aroma/cost terms |
| `737070` | `normalized_aromaonly_wide_aroma0p5mg_basezero_iter25` | aroma deficit only, no sugar/cost terms |

These jobs are diagnostic only. If even sugar-only and aroma-only wide-trust
runs keep microscopic control movement, the next methodological step should be
tail/collocation repair or continuation design, not another weight sweep.

All three wide-trust diagnostics completed successfully through Slurm:

| job | variant | elapsed | MaxRSS | solver | residual feasible | trajectory ready |
| --- | --- | ---: | ---: | --- | --- | --- |
| `737068` | balance wide | `01:01:46` | `26799124K` | `ITERATION_LIMIT` / `NEARLY_FEASIBLE_POINT` | true | false |
| `737069` | sugar-only wide | `00:55:36` | `26952980K` | `ITERATION_LIMIT` / `NEARLY_FEASIBLE_POINT` | true | false |
| `737070` | aroma-only wide | `00:56:56` | `26864040K` | `ITERATION_LIMIT` / `NEARLY_FEASIBLE_POINT` | true | false |

The six-case comparison report is
`repro/generated/dynamic_control_normalized_objective_sweep_20260616/dynamic_control_branch_comparison.md`.

Key results:

| case | terminal sugar | terminal isoamyl alcohol | max T movement | FDA sum movement | organic sum movement | max continuity |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| narrow balance | `91.6405532012` | `0.000399517091` | `0.0030855434 C` | `3.28e-08 g/L` | `-2.93e-05 g/L` | `0.04372081299` |
| wide balance | `91.6398914545` | `0.000489256624` | `0.0061855083 C` | `6.09e-08 g/L` | `-5.99e-05 g/L` | `0.04353026876` |
| wide sugar-only | `91.6382964513` | `0.000494109618` | `0.0136743162 C` | `3.14e-05 g/L` | `-1.11e-04 g/L` | `0.04289211168` |
| wide aroma-only | `91.6401667165` | `0.000401533708` | `0.0086185698 C` | `5.54e-08 g/L` | `-5.47e-05 g/L` | `0.04353396175` |

Interpretation:

- Wide trust and `max_iter=25` produce slightly lower objective/continuity
  residuals, but control movement remains tiny compared with the allowed trust
  region.
- The strongest trajectory change came from the sugar-only run, yet it reduced
  final sugar by only `0.00226 g/L` relative to narrow balance.
- A large part of the sugar-objective improvement is slack tightening rather
  than actual fermentation progress: sugar slacks remain above the terminal
  excess implied by final sugar.
- Aroma-deficit slacks show a small but systematic inequality violation around
  `1.07e-5 g/L` in the `ITERATION_LIMIT` post-solves. Future TOML metadata now
  records required slack, slack-minus-required, and violation estimates
  directly from the NLP variables.

Conclusion: objective scaling alone is not the current blocker. The
simultaneous MPCC responds numerically to the added terms, but it does not yet
use the temperature/nutrient controls at a meaningful scale. The dominant
technical blocker remains the late-horizon `protein`
collocation/continuity defect and the imperfect slack feasibility of
iteration-limited post-solves. The next productive branch is therefore a
trajectory/continuity repair or continuation strategy before another serious
weight sweep.
