# Dynamic Sequential DFBA Smoke Runs - 2026-06-09

Purpose: validate the first dynamic-control sequential DFBA path before using it
as the forward simulator inside dynamic optimization. All Julia execution below
was submitted through Slurm on the UC cluster; the login node was used only for
inspection, submit, and monitoring.

## Code State

- Branch: `workstation_cii`
- Relevant commits:
  - `47eaa13` Wire dynamic controls into sequential DFBA
  - `20f3fc3` Add dynamic control preview script
  - `7875912` Add dynamic sequential export entrypoint
  - `3603b03` Handle empty dynamic control event schedules
  - `a22b1ec` Handle empty dynamic control rate events

## Common Configuration

- Entrypoint: `scripts/main_export_reduced_dfba_dynamic_controls.jl`
- Model scope: reduced sequential DFBA
- Solver label: HiGHS
- ODE algorithm: Tsit5
- Save interval: 1 h
- Flux reconstruction: disabled
- Dynamic controls enabled:
  - Temperature profile: smooth logistic transitions on a 12 h grid
  - FDA additions: none in these smokes
  - Organic additions: none in these smokes
- Threading: `JULIA_NUM_THREADS=1`, `OMP_NUM_THREADS=1`,
  `OPENBLAS_NUM_THREADS=1`
- Slurm resources for successful dynamic smokes: 1 task, 1 CPU, 8 GB, no GPU

## Successful Runs

| Run | Job | Profile | Output | Status | Final sugar g/L | Sugar consumed g/L | Final ethanol g/L | Final N gN/L | RHS/LP solves |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| 24 h flat control | `725686` | 20 C flat | `/home/cltorrealba/mpcc_runs/dynamic_24h_plumbing_smoke_retry2_20260609_180832/export` | Success | 207.815080 | 12.184920 | 5.311259 | 6.528839e-5 | 537 |
| 24 h thermal step | `727439` | 20 -> 22 C at 12 h, width 1 h | `/home/cltorrealba/mpcc_runs/dynamic_24h_temp20to22_smoke_20260609_182127/export` | Success | 207.793999 | 12.206001 | 5.303558 | 2.721243e-5 | 465 |
| 48 h thermal step | `727500` | 20 -> 22 C at 12 h, width 1 h | `/home/cltorrealba/mpcc_runs/dynamic_48h_temp20to22_smoke_20260609_182902/export` | Success | 191.173571 | 28.826429 | 13.779646 | 5.754529e-14 | 975 |
| 168 h thermal step | `727505` | 20 -> 22 C at 12 h, width 1 h | `/home/cltorrealba/mpcc_runs/dynamic_168h_temp20to22_smoke_20260609_184851/export` | Success | 112.998196 | 107.001804 | 51.510179 | -7.832486e-22 | 1641 |

The 168 h job completed on `n14` in 00:04:22 with batch MaxRSS 988316K.

## Artifacts

Each output directory contains:

- `summary.csv`
- `states.csv`
- `diagnostics.csv`
- `metadata.toml`
- `dynamic_control/dynamic_control_schedule.csv`
- `dynamic_control/dynamic_control_summary.csv`
- `plots/sugars.svg`
- `plots/nitrogen_reserves.svg`
- `plots/biomass_ethanol.svg`
- `plots/aroma_products.svg`

## Notes

- The initial dynamic-control plumbing exposed two empty-event bugs. Both were
  fixed before the successful runs:
  - Empty FDA/organic event totals in schedule construction and metadata.
  - Empty FDA/organic event totals in cumulative/rate evaluation during RHS
    calls.
- The 168 h run reports `has_negative_saved_states=true`, but the minimum saved
  state value is `-1.082506e-21`, consistent with numerical zero. This should
  not be interpreted as a biologically meaningful negative concentration.
- With no nutrient additions and the 20 -> 22 C thermal profile, the simulator
  remains stable over 168 h but does not deplete sugars. This is expected to be
  revisited when optimizing temperature and FDA/organic addition schedules.

## Next Methodological Step

Use these successful smokes as the baseline for the first dynamic optimization
prototype:

1. Add a forward-simulation objective wrapper that accepts 12 h grid controls.
2. Start with temperature-only optimization using smooth logistic interpolation.
3. Add smooth FDA/organic additions with an OIV/Chile-inspired total-dose
   penalty after temperature-only optimization is stable.
4. Re-enable flux reconstruction only for selected candidate schedules, not for
   every optimization evaluation.
