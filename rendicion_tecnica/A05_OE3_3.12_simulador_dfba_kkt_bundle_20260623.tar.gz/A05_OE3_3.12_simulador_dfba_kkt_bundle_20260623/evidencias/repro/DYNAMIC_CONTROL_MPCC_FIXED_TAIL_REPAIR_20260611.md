# Dynamic-control fixed MPCC tail repair diagnostics - 2026-06-11

## Scope

Goal: advance toward the dynamic temperature/nutrient optimization MVP by first
sanitizing the fixed-control 24 h reduced MPCC replay. Controls must not be
freed until the fixed-control start is residual-feasible under the guarded
solve-attempt diagnostics.

Cluster rules followed:

- No solves or heavy Julia runs were executed on the login node.
- All Julia contracts and MPCC diagnostics were launched with Slurm.
- Jobs used `--ntasks=1`, `OPENBLAS_NUM_THREADS=1`, no GPU, and 8 CPUs for
  MPCC sweeps.
- Run root: `/home/cltorrealba/mpcc_runs/dynamic_control_fixed_tail_repair_20260611_014952`.
- Storage used after this stage: about 2.1 MB.

## Implementation changes

Implemented reproducible fixed-control repair controls:

- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_ELEMENTS`
  forwards a contiguous element range to
  `collocation_consistent_state_start_element_indices`.
- `MPCC_FIXED_SWEEP_REPAIR_ELEMENTS`
  lets the Slurm sweep compare multiple repair ranges in one job.
- Fixed-control aliases for collocation repair options:
  `FINAL_STATE_REFRESH`, `FINAL_FLUX_PROJECTION`, `FINAL_DUAL_FIT`,
  `FINAL_STATE_AFTER_RHS`, `MONOTONE`, and related trace/stagnation knobs.
- Optional fixed-control bound-dual clipping:
  `MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP`,
  `MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP_ELEMENTS`, and
  `MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP_BUDGET_FRACTION`.

The new options are off by default except for the existing default monotone
collocation repair behavior.

Contract coverage was extended so the entrypoint, Slurm sweep, and core
solve-attempt clipping pathway are guarded textually. Latest contract job:
`728795`, all contract testsets passed.

## Evidence

Policy replay input:

- Selection CSV:
  `/home/cltorrealba/mpcc_runs/dynamic_control_mpcc_fixed_replay_20260610_131549/selection/dynamic_control_policy_selection.csv`
- Candidate:
  `cool18_warm22__springferm_early_0p4`
- Horizon: 24 h
- Complementarity: Scholtes, `tau = 20`
- Linear solver: MA86 through licensed cluster HSL
- Hessian: limited-memory

### Tail-only repair, default mode

Job: `728745`

Mode: `max_iter=0`, `nfe=16`, no final state/flux special handling.

| Repair elements | Max collocation | Max continuity | Max lower comp. | Candidate feasible | Dominant location |
| --- | ---: | ---: | ---: | --- | --- |
| `13:16` | `9.408e-3` | `2.433e-3` | `0` | false | leucine, element 9 |
| `12:16` | `9.408e-3` | `2.433e-3` | `0` | false | leucine, element 9 |
| `10:16` | `9.408e-3` | `2.433e-3` | `0` | false | leucine, element 9 |
| `all` | `4.125e-4` | `4.125e-4` | `0` | false | glucose, final tail |

Conclusion: the defect is not just 18-24 h. Tail-only repair leaves a mid-horizon
amino-acid defect around elements 8-9.

### Final state refresh + mass-balanced flux projection

Job: `728752`

Mode: `max_iter=0`, `nfe=16`,
`FINAL_STATE_REFRESH=1`, `FINAL_FLUX_PROJECTION=1`.

| Repair elements | Max collocation | Max continuity | Max lower comp. | Candidate feasible | Dominant location |
| --- | ---: | ---: | ---: | --- | --- |
| `8:16` | `1.283e-3` | `1.080e-4` | `6.597e-5` | false | leucine, element 7 |
| `7:16` | `1.053e-4` | `1.053e-4` | `6.701e-5` | false | leucine, final tail |
| `6:16` | `1.056e-4` | `1.056e-4` | `3.655e-5` | false | leucine, final tail |
| `all` | `1.034e-4` | `1.034e-4` | `2.611e-5` | false | leucine, final tail |

Conclusion: this is the best primal repair so far, but still above the strict
`1e-6` residual gates and complementarity remains above `1e-5`.

### Bound-dual complementarity clipping

Job: `728793`

Mode: same as above, plus bound-dual clipping with budget fraction `2.5e-7`
so the effective lower-complementarity budget is `5e-6`.

| Repair elements | Max collocation | Max stationarity | Max lower comp. | Candidate feasible |
| --- | ---: | ---: | ---: | --- |
| `7:16` | `1.053e-4` | `7.703e-1` | `5.000e-6` | false |
| `all` | `1.034e-4` | `7.808e-1` | `5.000e-6` | false |

Conclusion: clipping fixes complementarity by construction, but destroys
stationarity. Do not use as a default fixed-control repair.

### Ipopt polish from repaired starts

Job: `728794`

Mode: `max_iter=25`, `nfe=16`, final state refresh + flux projection, no clipping.

| Repair elements | Max collocation | Max mass balance | Max lower comp. | Candidate feasible |
| --- | ---: | ---: | ---: | --- |
| `7:16` | `1.051e-4` | `1.104e-5` | `8.623e-4` | false |
| `all` | `1.033e-4` | `5.260e-6` | `8.397e-5` | false |

Conclusion: short Ipopt polish does not reduce the dominant collocation defect
and worsens complementarity. Do not move to free controls on this basis.

### Final state-after-RHS diagnostic

Job: `728796`

Mode: `max_iter=0`, final state refresh + flux projection +
`FINAL_STATE_AFTER_RHS=1`.

| Repair elements | Max collocation | Max RHS | Max lower bound viol. | Max lower comp. | Candidate feasible |
| --- | ---: | ---: | ---: | ---: | --- |
| `7:16` | `9.465e-5` | `2.879e-6` | `1.047e-5` | `3.044e-5` | false |
| `all` | `7.088e-15` | `3.522e-6` | `7.851e-4` | `4.650e-5` | false |

Conclusion: a final state refresh can eliminate collocation algebraically, but
then dynamic bounds/RHS/complementarity are no longer healthy. This confirms the
issue is coupled state-flux-bound consistency, not just a missing final state
assignment.

### Mesh refinement diagnostic

Job: `728797`

Mode: `max_iter=0`, repair `all`, final state refresh + flux projection.

| NFE | Element length | Max collocation | Max lower comp. | Candidate feasible |
| ---: | ---: | ---: | ---: | --- |
| 24 | 1.00 h | `3.207e-4` | `4.945e-4` | false |
| 32 | 0.75 h | `3.972e-5` | `7.817e-5` | false |

Conclusion: finer mesh can reduce the tail collocation defect at `nfe=32`, but
not enough for residual-feasible status, and complementarity remains too high.

## Decision

Do not free dynamic controls yet.

The fixed-control MPCC is not residual-feasible at 24 h under the strict guarded
diagnostics. The best stable starts still have a coupled terminal
state/flux/bound defect around sugar or leucine. Ipopt polish and dual clipping
do not repair it safely.

## Recommended next technical step

Implement a coupled local repair for selected tail elements that solves the
state, derivative, and flux projection consistency together instead of applying
them as sequential overwrites.

Concrete starting point:

1. Build a small element-local least-squares/projection diagnostic for the final
   1-3 elements, targeting state collocation/continuity, RHS derivative
   consistency, mass balance, and dynamic flux bounds.
2. Keep stationarity duals refreshed after the primal local repair, but do not
   clip duals blindly.
3. Test first on `24h/nfe=16/all` and `24h/nfe=32/all` with `max_iter=0`.
4. Only after fixed-control passes strict residual gates should controls be
   released for the first optimization pilot.

## Superseding update: fixed-control sane start and local control pilot

Later on 2026-06-11 the fixed-control line was advanced from tail repair to a
residual-feasible start-value construction at `24 h / nfe=24`.

Implementation additions:

- Sequential initialization can now sample exactly on the collocation grid via
  `MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_POLICY=collocation_grid`.
- Solve-attempt output now includes complementarity-location diagnostics through
  `reduced_mpcc_fixed_control_policy_complementarity_locations.csv`.
- Active-bound complementarity flux projection was added as an optional final
  start repair:
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION`.
- The successful fixed-control start used nonmonotone collocation repair:
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MONOTONE=0`, max repair iterations `8`,
  final state refresh, mass-balanced flux projection, active complementarity
  flux projection, and final state-after-RHS refresh/guard.

Key evidence:

| Job | Purpose | Result |
| --- | --- | --- |
| `728881` | Baseline `nfe=24`, collocation-grid start | Primal residuals near feasible but lower complementarity `2.047e-4`, top location nitrogen-source fluxes at 24 h. |
| `728962` | Active complementarity flux projection with monotone repair | Projection ran but worsened collocation to `1.256e-4`; not promoted. |
| `728978` | Active projection with nonmonotone repair, `max_iter=0` | Selected fixed-control start: residual thresholds satisfied, `candidate_residual_feasible=true`, `max_collocation=2.747e-7`, `max_mass=2.209e-7`, `max_lower_complementarity=1.117e-6`. |
| `728990` | Same start but Ipopt `max_iter=5` | Post-solve degraded mass to `1.785e-6`; do not promote post-solve yet. |
| `729014` | Contracts after final code edits | Passed entrypoint, sbatch, smoke, and solve-attempt contracts. |

Selected fixed-control methodology:

- Use the `728978` style as the fixed-control sane line.
- Treat it as a pre-solve/start-values artifact, not as a post-Ipopt optimized
  trajectory.
- Keep `max_iter=0` for the first control pilot unless deliberately testing
  post-solve sensitivity.
- Do not use dual clipping as a default repair.

First control-liberation bridge:

- Added `scripts/main_dynamic_control_local_pilot_design.jl`.
- Added `repro/cluster_uc_dynamic_control_local_pilot_fixed_mpcc.sbatch`.
- This is an outer-loop local policy trust-region pilot: it frees smooth
  temperature/nutrient policy values around the sane fixed policy, then evaluates
  each candidate with the same fixed-control MPCC start construction.
- It is explicitly not yet a fully simultaneous JuMP-control formulation.

Design validation job `729024` generated 9 candidates around
`cool18_warm22__springferm_early_0p4`:

- base replay,
- early temperature slots `T1`/`T2` at `+/-0.5 C`,
- first organic dose at `+/-0.05 g/L`,
- first FDA dose at `+0.25 g/L`,
- organic-to-FDA YAN-equivalent swap.

Default pilot run settings:

- `MPCC_FIXED_CONTROL_SOLVE_HOURS=24`
- `MPCC_FIXED_CONTROL_NFE=24`
- `MPCC_FIXED_CONTROL_MAX_ITER=0`
- `MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_POLICY=collocation_grid`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=8`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MONOTONE=0`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_REFRESH=1`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_FLUX_PROJECTION=1`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION=1`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS=1`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_REFRESH_RHS=1`
- `MPCC_FIXED_CONTROL_LINEAR_SOLVER=ma86`
- `MPCC_IPOPT_HESSIAN_APPROXIMATION=limited-memory`

The next action is to launch the Slurm pilot with a small `MAX_EVALS` value
(base plus one or two control perturbations), inspect residual feasibility and
complementarity locations, and only then expand to the remaining local moves.

## Local control pilot results

Two pilot jobs were run through Slurm:

- Job `729035`: `MAX_EVALS=3`, base plus `T1 +/-0.5 C`.
- Job `729042`: `MAX_EVALS=9`, full local pilot including temperature and
  nutrient moves.

Full-pilot root:

`/home/cltorrealba/mpcc_runs/dynamic_control_local_pilot9_fixed_mpcc_20260611_203321`

Summary CSV:

`/home/cltorrealba/mpcc_runs/dynamic_control_local_pilot9_fixed_mpcc_20260611_203321/dynamic_control_local_pilot_fixed_mpcc_attempts.csv`

All 9 candidates completed with `residual_thresholds_satisfied=true`,
`candidate_residual_feasible=true`, `primal_status=FEASIBLE_POINT`, and
`solver_status=ITERATION_LIMIT` because the pilot deliberately used
`MPCC_FIXED_CONTROL_MAX_ITER=0`.

| Candidate move | FDA g/L | Organic g/L | Max collocation | Max mass | Max lower comp. |
| --- | ---: | ---: | ---: | ---: | ---: |
| base | 0.00 | 0.40 | `2.747e-7` | `2.209e-7` | `1.117e-6` |
| `T1 +0.5 C` | 0.00 | 0.40 | `5.376e-7` | `1.497e-7` | `2.141e-6` |
| `T1 -0.5 C` | 0.00 | 0.40 | `1.597e-7` | `8.421e-8` | `6.969e-7` |
| `T2 +0.5 C` | 0.00 | 0.40 | `5.606e-7` | `1.659e-7` | `2.175e-6` |
| `T2 -0.5 C` | 0.00 | 0.40 | `1.281e-7` | `2.759e-7` | `5.616e-7` |
| `ORG +0.05 g/L` | 0.00 | 0.45 | `1.534e-7` | `1.533e-7` | `6.716e-7` |
| `ORG -0.05 g/L` | 0.00 | 0.35 | `3.088e-7` | `1.747e-7` | `1.234e-6` |
| `FDA +0.25 g/L` | 0.25 | 0.40 | `8.364e-8` | `2.477e-7` | `3.688e-7` |
| `ORG -> FDA YAN-equivalent` | 0.25 | 0.35 | `6.579e-8` | `1.382e-7` | `2.983e-7` |

Interpretation:

- The fixed-control MPCC start construction is now robust to a small local
  trust region in both temperature and nutrient controls at 24 h.
- Nutrient perturbations did not break residual feasibility; FDA addition and
  the organic-to-FDA YAN-equivalent swap improved complementarity in this 24 h
  start diagnostic.
- `candidate_trajectory_extraction_ready=false` remains expected for this
  pilot because `max_iter=0` gives an Ipopt `ITERATION_LIMIT` status. These are
  feasible starts for the next method stage, not optimized MPCC trajectories.
- The next methodological step is a conservative post-solve sensitivity:
  run the best few local moves with a small `max_iter` budget and reject any
  post-solve candidate that degrades mass/complementarity, as happened earlier
  for the fixed base with `max_iter=5`.

## Post-solve sensitivity: `max_iter=5`

On 2026-06-12 a conservative post-solve sensitivity was run for the base and the
best local-pilot starts:

- Job: `729099`
- Root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_postsolve5_fixed_mpcc_20260612_002138`
- Summary CSV:
  `/home/cltorrealba/mpcc_runs/dynamic_control_postsolve5_fixed_mpcc_20260612_002138/dynamic_control_postsolve5_attempts.csv`
- Settings: same sane fixed-control start construction as the local pilot,
  but `MPCC_FIXED_CONTROL_MAX_ITER=5`.

| Candidate | Residual feasible | Max collocation | Max mass | Max lower comp. |
| --- | --- | ---: | ---: | ---: |
| base | false | `2.746e-7` | `1.785e-6` | `5.055e-6` |
| `T1 -0.5 C` | false | `1.597e-7` | `3.760e-6` | `4.763e-6` |
| `T2 -0.5 C` | false | `1.280e-7` | `2.148e-6` | `2.838e-6` |
| `FDA +0.25 g/L` | false | `8.361e-8` | `1.865e-6` | `1.795e-6` |
| `ORG -> FDA YAN-equivalent` | false | `6.577e-8` | `1.738e-6` | `1.348e-6` |

Decision:

- Do not promote any `max_iter=5` post-solve candidate.
- Ipopt improves or preserves collocation but drifts outside the strict mass and
  complementarity gates.
- The `ORG -> FDA YAN-equivalent` and `FDA +0.25 g/L` starts remain the best
  local pilot starts, but as `max_iter=0` residual-feasible starts only.

Next technical implication:

- Before asking Ipopt for more iterations, add an acceptance/restoration layer
  around solve-attempt outputs: keep the pre-solve residual-feasible candidate
  when post-solve degrades strict gates, and record post-solve diagnostics as
  rejected.
- For a true optimization pilot, the next solve should either use this guarded
  promotion logic or test an even smaller post-solve step budget/options, not
  blindly scale `max_iter`.

## Guarded candidate selection layer

Implemented on 2026-06-12 for the fixed-control solve-attempt path.

The solve-attempt wrapper now captures complete pre-solve start values before
calling Ipopt, extracts the post-solve values when available, and selects the
accepted candidate with the policy:

`prefer_post_solve_residual_feasible_else_pre_solve_residual_feasible`

This makes the previously manual promotion rule explicit in code:

- If the post-solve candidate is residual-feasible, keep post-solve values.
- If post-solve degrades strict residual gates but the pre-solve start remains
  residual-feasible, select `pre_solve_start_values`.
- Keep post-solve residuals and rejection metadata in the report so the failed
  solve step is still auditable.

New fixed-control solve-attempt CSV/log fields include
`candidate_values_source`, `candidate_selection_reason`,
`selected_candidate_source`, `selected_candidate_is_pre_solve_start`,
`post_solve_candidate_accepted`, `post_solve_candidate_rejected`, and
`post_solve_candidate_rejection_reason`.

Verification:

- Unit/contract Slurm job `729134` completed on `n14` with exit code `0:0`.
- Focused real pilot Slurm job `729141` completed on `n14` with exit code
  `0:0`.
- Pilot root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_postsolve1_selection_fallback_20260612_021703`
- Settings: base local-control candidate, 24 h, `nfe=24`, `max_iter=5`,
  `MA86`, limited-memory Hessian, `OPENBLAS_NUM_THREADS=1`.

Observed verification row:

- Post-solve status: `ITERATION_LIMIT`, primal status `NEARLY_FEASIBLE_POINT`.
- Post-solve strict residual gate failed:
  `residual_thresholds_satisfied=false`,
  `max_mass_balance_residual=1.785e-6`.
- Selected candidate:
  `candidate_values_source=pre_solve_start_values`,
  `candidate_residual_feasible=true`,
  `selected_candidate_is_pre_solve_start=true`.
- Rejection reason:
  `post_solve_candidate_not_residual_feasible_fallback_to_pre_solve_start`
  with `post_solve_candidate_rejection_reason=not_residual_feasible`.

Decision:

- The fixed-control MPCC path now has explicit restoration/acceptance semantics
  suitable for the first dynamic-control optimization pilot.
- `max_iter=5` post-solve values are still not promoted for this line; they are
  diagnostic evidence that Ipopt currently drifts mass outside the strict gate.
