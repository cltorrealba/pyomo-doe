# Dynamic-control relaxed broad-seed protocol

Date: 2026-06-20

This protocol turns the current dynamic-control MPCC work into a reproducible
horizon ladder. The aim is not to force a single preselected temperature or
nutrient profile, but to use several biologically plausible starts while keeping
Ipopt close enough to a residual-sane basin that it can move controls.

## Principle

Use two handoff modes, with cross-horizon flux/dual copying disabled by
default after the 2026-06-20 96 h diagnostics:

1. Same-grid full candidate handoff.
   - Environment: `MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS`.
   - Use only when the target grid/horizon matches the seed grid.
   - Preserves state, derivative, flux, dual, and dynamic-control starts.

2. Cross-horizon flux/dual handoff.
   - Environment: `MPCC_FIXED_CONTROL_FLUX_DUAL_START_JLS`.
   - Use when extending horizon, e.g. 72 -> 96 -> 120 -> 144 -> 168 h.
   - Default mode: `MPCC_FIXED_CONTROL_FLUX_DUAL_START_MODE=none`.
   - Optional diagnostic modes: `flux_duals`, `duals_only`, `flux_only`.
   - The default keeps the validated seed available for audit metadata, but
     does not copy terminal fluxes or duals into the longer horizon. The target
     horizon instead uses sequential/local flux and dual starts plus collocation
     repair.
   - The explicit diagnostic modes apply terminal collocation flux and/or dual
     structure from the seed candidate across the target grid after sequential
     initialization. Use these only to test basin dependence or start damage.

These modes are mutually exclusive by design.

## Relaxation controls

The current relaxed funnel is based on:

- `MPCC_JULIA_COMPILED_MODULES=no` and `MPCC_JULIA_PKGIMAGES=no` as the
  default horizon-ladder runtime on the UC cluster. A dedicated Slurm warmup
  job can precompile the project, but `pkgimages=yes` made package loading
  slower in the 2026-06-20 smoke attempts and should only be used as an
  explicit experiment.
- `MPCC_DYNAMIC_FLUX_LP_RELAXED_FALLBACK=1`
- `MPCC_DYNAMIC_FLUX_LP_RELAXED_MASS_WEIGHT=1000.0`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=2` for throughput
  diagnostics after the 96 h repair2 evidence. Keep `8` only as an explicit
  polishing experiment, not as the default ladder path.
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD=1`
- `MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU=1e-3` for the horizon ladder
- `MPCC_DYNAMIC_CONTROL_REFERENCE_REGULARIZATION_WEIGHT=0.05`
- tight but nonzero control trust regions:
  - temperature: `1.5 C`
  - FDA: `0.025 g/L`
  - organic: `0.01 g/L`

This is intentionally softer than exact dynamic optimization. The point is to
recover residual-feasible and trajectory-ready candidates at longer horizons
before tightening tau or increasing objective pressure.

## Broad starts

For 96 h, the staged bank includes three rungs using the same selected 72 h
trajectory-ready seed:

- `s9_fluxdual_flat22_h96_tau1em3_iter6`
- `s9_fluxdual_warm_fda_h96_tau1em3_iter6`
- `s9_fluxdual_coolwarm_fdaearly_h96_tau1em3_iter6`

The `fluxdual` case-name prefix is historical. As of this protocol update, the
default cross-horizon mode is `none`; set
`MPCC_FIXED_CONTROL_FLUX_DUAL_START_MODE=flux_duals`, `duals_only`, or
`flux_only` only for explicit diagnostics.

For later horizons, continue from the best residual-sane selected candidate:

- 96 -> 120 h:
  - `s10_fluxdual_flat22_h120_tau1em3_iter6_repair2`
  - `s10_fluxdual_flat22_h120_tau1em3_iter6`
  - `s10_fluxdual_warm_fda_h120_tau1em3_iter6`
- 120 -> 144 h:
  - `s11_fluxdual_flat22_h144_tau1em3_iter6_repair2`
  - `s11_fluxdual_flat22_h144_tau1em3_iter6`
- 144 -> 168 h:
  - `s12_fluxdual_flat22_h168_tau1em3_iter6_repair2`
  - `s12_fluxdual_flat22_h168_tau1em3_iter6`

The broad-start variants exist to test basin dependence. A candidate is not
promoted merely because its objective is lower.

## Submission pattern

Always run through Slurm. Example from a selected candidate:

```bash
export MPCC_FIXED_CONTROL_FLUX_DUAL_START_JLS="$HOME/mpcc_runs/<seed>/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls"
export MPCC_FIXED_CONTROL_FLUX_DUAL_START_MODE=none
export MPCC_IPOPT_PRINT_LEVEL=5
export MPCC_IPOPT_PRINT_FREQUENCY_ITER=1
export MPCC_IPOPT_MAX_WALL_TIME_SECONDS=2400
export MPCC_REDUCED_MPCC_SOLVE_ATTEMPT_TRACE_PHASES=1
bash repro/submit_cluster_uc_dynamic_control_staged_multistart.sh --case s10_fluxdual_flat22_h120_tau1em3_iter6
```

Submit only a small number of concurrent cases. Favor one baseline plus one
broad-start variant when nodes are available.

## Acceptance gates

Keep a candidate only if:

- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=true` when possible
- no early restoration or HSL/MA86 failure
- `cross_window_flux_dual_start_mode=none` for default cross-horizon rungs
- objective improvement is not explained only by slack/repair metadata
- dominant residual is documented, especially if it remains tied to `protein`

Reject or diagnose if:

- initial `inf_pr` is huge,
- Ipopt enters restoration early,
- candidate is selected only from a rejected restoration post-solve,
- complementarity damage grows while controls move,
- continuity/collocation defects dominate the final tail.

## Before serious objective tightening

Do not tighten tau below `1e-3` or add exact Hessian until the horizon ladder
has a reproducible residual-sane candidate. Full 12 h profile liberation remains
the final target, but a shorter control-motion funnel is now required before
waiting for a promotable 168 h seed.

The reason is methodological: the 168 h ladder is residual-feasible but still
blocked by a tail `protein` collocation/continuity defect, while the objective
pilots show almost no optimized control motion. A 72/96 h diagnostic funnel with
wide trusts, zero reference regularization, broad starts, and excess-slack
productivity tests whether Ipopt can move controls at all under the simultaneous
formulation. This is not a promotion path. It is a falsification step:

- if controls move under direct rewards, then the variables are free and the
  remaining issue is mediated control-state-objective leverage;
- if controls move only with direct rewards but not with productivity slacks,
  then the RHS/bounds/flux projection sensitivity is weak or locally masked;
- if controls do not move even under direct rewards, then bounds, trusts,
  starts, or objective wiring are still freezing the controls.

Only after this funnel shows meaningful movement should the best broad-start
basins be extended back through 120/144/168 h.

## 2026-06-20 96 h handoff diagnostic

Using the same 72 h residual-feasible and trajectory-ready seed, the 96 h
`repair2` flat22 diagnostic showed:

- `flux_duals` default copy:
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s9_fluxdual_flat22_h96_tau1em3_iter6_repair2_20260620_033952`
  - selected candidate: post-solve diagnostics only
  - `selected_candidate_residual_feasible=false`
  - dominant residual: continuity/collocation around `0.63`
- `duals_only`:
  - job `744718`
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s9_fluxdual_flat22_h96_tau1em3_iter6_repair2_20260620_050048`
  - Ipopt iter 0: `inf_pr=4.41e-02`
  - dominant residual: lower complementarity around `4.5e-2`
- `none`:
  - job `744755`
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s9_fluxdual_flat22_h96_tau1em3_iter6_repair2_20260620_052614`
  - Ipopt iter 0: `inf_pr=2.62e-05`
  - selected candidate: `pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - dominant residual: `protein` collocation/continuity around `2.62e-5`

Interpretation: copying terminal fluxes/duals from 72 h into 96 h damages the
longer-horizon start. Cross-horizon extension should therefore preserve the
sequential/local start and use repair/regularization first. Flux/dual copying is
now a diagnostic lever, not the default development path.

Follow-up repair diagnostics:

- `repair8 all`, job `745259`, was cancelled after about 25 min while still in
  `collocation_consistent_state_starts`; it did not reach Ipopt and is too slow
  as a development default.
- `repair8` on tail elements `85:96`, job `745295`, reached Ipopt faster but
  started with `inf_pr=5.76e-01`, much worse than `repair2 none`. It was
  cancelled early. Selective tail repair with the current score can damage
  global consistency.

Operational rule: use `repair2 all + mode=none` as the current horizon-ladder
baseline. Treat non-trajectory-ready 96 h starts as diagnostic warm starts only,
and submit longer rungs with `--allow-not-ready` until the dominant
`protein` collocation/continuity defect is eliminated by a better repair method.

## 2026-06-20 120 h ladder diagnostic

The first 96 -> 120 h rung used the 96 h `repair2 none` selected candidate as a
residual-feasible but not trajectory-ready diagnostic seed:

- job `745320`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s10_fluxdual_flat22_h120_tau1em3_iter6_repair2_20260620_121713`
- command path:
  `s10_fluxdual_flat22_h120_tau1em3_iter6_repair2`
- cross-horizon mode: `none`
- Ipopt iter 0: `inf_pr=4.24e-04`
- selected candidate: `post_solve_values`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=false`
- dominant residual: terminal `protein` collocation/continuity around
  `4.24e-4` at 120 h

Interpretation: the sequential/local start and short repair ladder scales to
120 h without restoration and remains residual-feasible, but the tail
`protein` collocation defect grows with horizon. Continue 144/168 h as
diagnostics, while separately developing a better tail/protein repair rather
than relying on brute-force global repair.

## 2026-06-20 s25 relaxed broad-seed extension

After the s23/s24 48 h budget diagnostics, the next development branch starts a
new 48 -> 72 h ladder from the best warm-temperature residual-feasible basin:

- seed audit root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s23_broadrelax_budget0p2_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2_20260620_184520`
- cross-horizon start mode: `MPCC_FIXED_CONTROL_FLUX_DUAL_START_MODE=none`
- horizon: 72 h, `nfe=72`
- repair: `repair2 all`, flux refresh guard enabled
- relaxation: `MPCC_DYNAMIC_FLUX_LP_RELAXED_MASS_WEIGHT=1000.0`
- complementarity: `tau=1e-3`
- final selective dual fit: enabled with complementarity budget fraction `0.2`
- controls:
  - temperature slots: `1,2,3,4,5,6`
  - nutrient-addition slots: `1,2,3,4,5`

The `s25extend` staged rows deliberately include three basins:

- `s25_extend_warmtemp_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2`
- `s25_extend_coolwarm_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2`
- `s25_extend_mixedsplit_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2`

This is the concrete implementation of the relaxed broad-seed strategy. The
starts are not assumptions about the optimum; they are probes of different
feasible basins. The promotion criterion remains numerical and biological
quality, not the seeded profile itself.

Operational note: a first warm submission with nutrient slots `1..6` failed
before NLP construction because the 72 h nutrient-addition grid accepts only
`1:5`. The table was corrected to `1..5` before relaunching.

Warm 72 h first result:

- job: `746154`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s25_extend_warmtemp_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2_20260620_194222`
- Ipopt iter 0: `inf_pr=2.08e-1`, `inf_du=1.00e2`
- Ipopt exit: maximum iterations at 20, no restoration observed
- post-solve candidate: rejected, `not_residual_feasible`
- selected candidate: `pre_solve_start_values`
- selected candidate residual-feasible: `true`
- selected candidate trajectory-ready: `false`
- terminal sugar at 72 h: `174.43 g/L`
- dominant residual: terminal `protein` collocation/continuity around
  `1.65e-6`
- top complementarity: lower complementarity on `r_1654` around `8.6e-6`

Interpretation: the relaxed broad-seed branch can build a residual-feasible
72 h pre-solve start, but the current Ipopt step mostly worsens feasibility
instead of improving the trajectory. Treat this as a warm-start artifact for
diagnosis, not as an optimized dynamic-control solution.

Broad-start comparison:

- `s25_extend_coolwarm_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2`
  - job: `746195`
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s25_extend_coolwarm_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2_20260620_200701`
  - Ipopt iter 0: `inf_pr=1.48e-1`, `inf_du=1.00e2`
  - entered restoration at iter `1r`; cancelled under the early-restoration
    rule before output diagnostics were written
- `s25_extend_mixedsplit_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2`
  - job: `746196`
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s25_extend_mixedsplit_h72_nfe72_tau1em3_iter20_reg0p05_repair2_budget0p2_20260620_200701`
  - Ipopt iter 0: `inf_pr=5.99e-2`, `inf_du=1.00e2`
  - Ipopt exit: maximum iterations at 20, no restoration observed
  - post-solve candidate: rejected, `not_residual_feasible`
  - selected candidate: `pre_solve_start_values`
  - selected candidate residual-feasible: `true`
  - selected candidate trajectory-ready: `false`
  - terminal sugar at 72 h: `174.71 g/L`
  - dominant residual: complementarity, with lower/upper complementarity
    around `4.1e-4` / `4.2e-4`

Interpretation of the comparison: the mixed basin gives the best initial
Ipopt primal infeasibility, but it damages complementarity relative to warm.
The warm basin remains the best s25 72 h residual-sane handoff candidate. None
of the s25 solves is an optimized dynamic-control solution yet; the optimizer
mostly preserves the pre-solve start and moves controls only marginally.

## 2026-06-20 144 h ladder diagnostic

The 120 -> 144 h rung continued the same diagnostic ladder:

- job `745355`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s11_fluxdual_flat22_h144_tau1em3_iter6_repair2_20260620_124337`
- command path:
  `s11_fluxdual_flat22_h144_tau1em3_iter6_repair2`
- cross-horizon mode: `none`
- Ipopt iter 0: `inf_pr=3.73e-03`
- selected candidate: `post_solve_values`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=false`
- dominant residual: terminal `protein` collocation/continuity around
  `3.73e-3` at 144 h
- terminal sugar: `G + F = 163.34 g/L`

Interpretation: residual feasibility still holds at 144 h, but the terminal
`protein` collocation defect is growing roughly by horizon extension. The 168 h
rung can be run as a diagnostic, but a promotable extended seed needs a targeted
fix for terminal protein/collocation rather than more objective pressure.

## 2026-06-20 168 h post-tail diagnostic

The 144 -> 168 h rung was repeated with guarded post-tail repair on elements
`145:168`:

- job `745453`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s12_fluxdual_flat22_h168_tau1em3_iter6_repair2_20260620_134554`
- cross-horizon mode: `none`
- post-tail repair: accepted
- accepted damping factor: `1.0`
- post-tail before max residual: `1.465e-2`
- post-tail after max residual: `3.731e-3`
- Ipopt status: `ITERATION_LIMIT`
- primal status: `NEARLY_FEASIBLE_POINT`
- selected candidate: `post_solve_values`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=false`
- dominant residual: collocation/continuity, `protein`, around `3.731e-3`
  near `144 h`
- terminal sugar: `G + F = 159.14 g/L`

Interpretation: post-tail repair materially improves the 168 h residual versus
the previous `1.40e-2` 168 h run, and it recovers residual feasibility. It is
still not promotable because trajectory extraction remains blocked by the
protein continuity/collocation defect. This confirms that the next numerical
fix should target terminal/tail protein consistency, while objective/control
development can proceed on shorter residual-sane funnel pilots.

## 2026-06-20 relaxed broad-seed funnel implementation

The dynamic-control optimization path now starts implementing the planned
relaxation plus broad seeding strategy instead of waiting for a perfectly clean
168 h fixed-control rung.

Objective change:

- The simultaneous objective keeps terminal sugar out of the main objective by
  default.
- The productivity term can now use
  `MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_POLICY=excess_slack`.
- In this mode the MPCC creates nonnegative collocation-point slacks for
  `G + F - sugar_max <= slack` and minimizes the time-averaged squared slack.
- The default submitter threshold is
  `MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_MAX_G_L=5.0`, matching the
  dry-wine gate.
- The legacy `squared_total` policy remains available for back-compatibility,
  but optimization pilots submitted through
  `submit_cluster_uc_dynamic_control_objective_leverage.sh` default to
  `excess_slack`.

Broad-start change:

- Added `s13funnel` 96 h staged cases for:
  - warm + FDA split,
  - cool-early/warm-late + early FDA,
  - warm-early/cool-late + organic split,
  - mixed FDA/organic split.
- These cases use the current safe cross-horizon policy:
  `MPCC_FIXED_CONTROL_FLUX_DUAL_START_MODE=none`, `repair2 all`, tau `1e-3`,
  reference regularization `0.05`, and limited-memory Hessian.
- The purpose is to test multiple basins and verify real control movement under
  a relaxed, interpretable productivity objective before promoting longer
  horizons.

Validation performed on login:

- staged TSV width: 38 columns
- staged rows: 64
- duplicate case IDs: none
- `bash -n` passed for the staged and leverage submitters
- Python summary/diagnostic scripts compile
- `git diff --check` passed

Operational next step:

Submit at most two `s13funnel` 96 h jobs initially. Keep the running 168 h
post-tail diagnostic alive unless restoration or useless resource consumption
appears. If the 96 h broad-start pilots show residual-sane movement, extend the
best basin to 120/144/168 h; if they do not move, diagnose trusts/slacks before
adding more objective pressure.

## 2026-06-20 s14 control-motion funnel

The first two `s13funnel` broad starts confirmed that the excess-slack
productivity objective is constructed and solves to residual-feasible
candidates, but optimized control movement is still microscopic:

- warm + FDA split: maximum temperature movement about `2.35e-4 C`;
- cool-early/warm-late + early FDA: maximum temperature movement about
  `2.94e-5 C`;
- both retained nonzero productivity pressure through 288 integrated sugar
  slacks on the 96 h grid.

This triggered a deliberately stronger motion diagnostic stage, `s14motion`.
All cases use:

- 72 h horizon, 72 finite elements;
- tau `1e-3`;
- `repair2 all`;
- `MPCC_FIXED_CONTROL_FLUX_DUAL_START_MODE=none`;
- zero reference regularization;
- wide trusts: `4 C` temperature, `0.10 g/L` FDA, `0.03 g/L` organic.

The cases are:

- `s14_direct_temp_motion_h72_tau1em3_iter8_repair2`: no productivity slack and
  direct temperature reward only. This should push temperature upward if the
  control variables and objective are wired correctly.
- `s14_slack_temp_motion_h72_tau1em3_iter8_repair2`: excess-slack productivity
  plus a mild direct temperature nudge from a warm broad start.
- `s14_slack_nutrient_motion_h72_tau1em3_iter8_repair2`: excess-slack
  productivity plus direct FDA/organic nudges from a nutrient broad start.

Acceptance is diagnostic rather than promotive. The key output is not final
objective value; it is whether controls move without destroying residual
feasibility, and whether movement comes from direct terms only or also through
state-mediated productivity.

Initial `s14motion` results:

- `s14_direct_temp_motion_h72_tau1em3_iter8_repair2`, job `745632`:
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s14_direct_temp_motion_h72_tau1em3_iter8_repair2_20260620_144002`
  - Ipopt status: `ITERATION_LIMIT`
  - initial `inf_pr = 1.57e-5`, final constraint violation `1.56e-5`
  - post-solve maximum temperature movement from start: `0.6847 C`
  - selected candidate source: `pre_solve_start_values`
  - selected candidate residual-feasible: `true`
  - selected candidate trajectory-ready: `false`
  - interpretation: controls are not structurally frozen; a direct
    temperature reward can move them. However, steps remain very small,
    dual infeasibility stays high, and the moved post-solve point is not the
    selected candidate.
- `s14_slack_temp_motion_h72_tau1em3_iter8_repair2`, job `745633`:
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s14_slack_temp_motion_h72_tau1em3_iter8_repair2_20260620_144002`
  - Ipopt status: `ITERATION_LIMIT`
  - initial `inf_pr = 1.24e-1`, final constraint violation `1.23e-1`
    in the Ipopt summary, but the selected candidate is residual-feasible
  - post-solve maximum temperature movement from start: `0.00294 C`
  - selected candidate source: `post_solve_values`
  - selected candidate residual-feasible: `true`
  - selected candidate trajectory-ready: `false`
  - interpretation: excess-slack productivity plus a mild temperature nudge
    remains almost pinned. This separates variable liberation from
    state-mediated objective leverage: controls can move, but the
    productivity/slack formulation is still not providing a useful local path.
- `s14_slack_nutrient_motion_h72_tau1em3_iter8_repair2`, job `745672`:
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s14_slack_nutrient_motion_h72_tau1em3_iter8_repair2_20260620_150015`
  - Ipopt status: `ITERATION_LIMIT`
  - initial `inf_pr = 2.98e-2`, final constraint violation `2.97e-2`
  - post-solve FDA total movement from start: `0.00141 g/L`
  - post-solve organic total movement from start: `-3.52e-5 g/L`
  - selected candidate source: `post_solve_values`
  - selected candidate residual-feasible: `true`
  - selected candidate trajectory-ready: `false`
  - dominant residual: terminal `protein` collocation/continuity around
    `1.39e-4`
  - interpretation: FDA/organic variables are connected and technically free,
    but direct nutrient rewards still produce only small accepted moves. This
    points to step acceptance/scaling/MPCC feasibility geometry rather than a
    missing objective term.

The generated comparison lives in
`repro/generated/dynamic_control_s14motion_20260620/summary.md`.

Decision after the three-case funnel: do not keep escalating objective weights
on the full 72/96 h NLP. Build a cheaper motion diagnostic first, preferably
24/48 h with fewer finite elements and optional repair skipping, to inspect
control derivative signs, line-search step acceptance, bound activity, and
objective component scaling before returning to 72/96/168 h.

## 2026-06-20 s15 micro-motion diagnostics

The staged bank now includes `s15micro` cases to make the control-motion
diagnosis cheaper than the 72 h, 1.2M-variable jobs. These cases use:

- 24 h horizon, 24 finite elements;
- valid 12 h control-grid indices for that horizon: temperature `1,2`,
  additions `1`;
- tau `1e-3`;
- zero reference regularization;
- wide trusts: `4 C`, `0.10 g/L` FDA, `0.03 g/L` organic;
- `repair_iter=1`;
- `max_iter=3`;
- no cross-horizon seed and no flux/dual copying.

The first two diagnostics isolate direct control mobility:

- `s15_micro_direct_temp_h24_nfe24_tau1em3_iter3_repair1`;
- `s15_micro_direct_nutrient_h24_nfe24_tau1em3_iter3_repair1`.

The third reintroduces the mediated productivity term:

- `s15_micro_slack_temp_h24_nfe24_tau1em3_iter3_repair1`.

Success is not promotion. Success is evidence about step acceptance:
post-solve control deltas, initial/final `inf_pr`, `inf_du`, selected candidate
source, and whether the moved post-solve point remains residual-feasible.

Initial `s15micro` direct diagnostics showed that the micro horizon improves
numerical health but does not by itself unlock movement:

- both direct cases solved to `ALMOST_LOCALLY_SOLVED`;
- both selected post-solve candidates were residual-feasible and
  trajectory-ready;
- the direct temperature case moved only `0.00136 C`;
- the direct nutrient case moved FDA only `9.94e-5 g/L`;
- Ipopt exited at acceptable level with scaled dual infeasibility near `100`.

The cause is partly operational: the submitter forced
`MPCC_FIXED_CONTROL_IPOPT_PROFILE=feasibility_handoff`, whose acceptable dual
threshold is intentionally loose for feasibility handoff. The submitter now
allows overriding this profile from the environment, and the staged bank
includes `s16strict` cases:

- `s16_strict_direct_temp_h24_nfe24_tau1em3_iter20_repair1`;
- `s16_strict_direct_nutrient_h24_nfe24_tau1em3_iter20_repair1`.

Submit these with `MPCC_FIXED_CONTROL_IPOPT_PROFILE=strict`. If strict-profile
micro jobs still barely move controls, the next fix should be objective/control
scaling or a continuation on direct reward magnitude, not simply more Ipopt
iterations.

Final `s15micro` summary:

- `s15_micro_direct_temp_h24_nfe24_tau1em3_iter3_repair1`, job `745707`:
  - solver status: `ALMOST_LOCALLY_SOLVED`
  - selected candidate: post-solve
  - residual-feasible: `true`
  - trajectory-ready: `true`
  - maximum temperature movement: `0.00136 C`
- `s15_micro_direct_nutrient_h24_nfe24_tau1em3_iter3_repair1`, job `745708`:
  - solver status: `ALMOST_LOCALLY_SOLVED`
  - selected candidate: post-solve
  - residual-feasible: `true`
  - trajectory-ready: `true`
  - FDA movement: `9.94e-5 g/L`
  - organic movement: `-1.38e-5 g/L`
- `s15_micro_slack_temp_h24_nfe24_tau1em3_iter3_repair1`, job `745729`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: post-solve
  - residual-feasible: `true`
  - trajectory-ready: `false`
  - maximum temperature movement: `0.0116 C`
  - Ipopt initial `inf_pr = 1.39e-3`, final `inf_du` about `1008`

Interpretation: adding excess-slack productivity gives a slightly larger
temperature move, but it makes the local NLP much harder and does not produce
a trajectory-ready candidate at the cheap 24 h scale.

Final `s16strict` summary:

- `s16_strict_direct_temp_h24_nfe24_tau1em3_iter20_repair1`, job `745740`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - maximum post-solve temperature movement: `0.0905 C`
  - final Ipopt `inf_pr = 1.97e-5`, `inf_du = 99.9`
- `s16_strict_direct_nutrient_h24_nfe24_tau1em3_iter20_repair1`, job `745741`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - post-solve FDA movement: `8.05e-4 g/L`
  - post-solve organic movement: `-2.54e-4 g/L`
  - final Ipopt `inf_pr = 2.55e-5`, `inf_du = 100.0`

Interpretation: strict Ipopt prevents early acceptable exit and creates more
control motion, but the moved point is not accepted as residual-feasible. This
is the concrete reason to move to `s17seedrelax`: keep broad starts and direct
continuation, but add low reference regularization so the accepted point can
move without being rejected by residual gates.

## 2026-06-20 s17 seed-relax implementation

The first explicit implementation of the combined strategy is now staged as
`s17seedrelax`. This is the development rung that mixes:

- broad starts, so no single temperature or nutrient profile is treated as the
  answer;
- low reference regularization, `0.02`, to keep Ipopt inside a residual-sane
  basin without pinning controls completely;
- excess-slack productivity, so sugar dryness remains a gate and productivity
  pressure acts through `G + F > 5 g/L` over time;
- mild direct-control continuation, so the optimizer has a visible descent
  direction while the state-mediated objective is still being debugged;
- strict Ipopt profile, to avoid the `feasibility_handoff` acceptable-dual
  cutoff observed in `s15micro`.

The staged cases are:

- `s17_seedrelax_warmtemp_h48_nfe48_tau1em3_iter30_reg0p02_repair1`
- `s17_seedrelax_coolwarm_h48_nfe48_tau1em3_iter30_reg0p02_repair1`
- `s17_seedrelax_fdaearly_h48_nfe48_tau1em3_iter30_reg0p02_repair1`
- `s17_seedrelax_mixedsplit_h48_nfe48_tau1em3_iter30_reg0p02_repair1`

All are 48 h / 48 finite-element cases with temperature slots `1:4` and
addition slots `1:3`. They remain cheap enough for diagnosis, but long enough
to expose early nitrogen and thermal effects that are invisible in very short
24 h runs.

Interpretation rule:

- If multiple broad starts move toward similar controls under strict Ipopt,
  the result is less likely to be a start artifact.
- If starts remain separated but residual-sane, keep them as competing basins
  for the 72/96/120 h ladder.
- If all starts stay pinned despite direct continuation, repair control scaling
  or objective scaling before extending horizon.
- If only the direct terms move controls but productivity does not, keep the
  direct continuation as a homotopy term and reduce it gradually after the
  state-mediated objective starts responding.

Initial `s17seedrelax` results:

- `s17_seedrelax_warmtemp_h48_nfe48_tau1em3_iter30_reg0p02_repair1`, job
  `745767`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - initial Ipopt `inf_pr = 2.98e-2`, final dominant residual:
    collocation/continuity around `7.54e-4`
  - post-solve temperature movement: `0.0553 C`
  - terminal selected sugar: `G + F = 188.64 g/L`
- `s17_seedrelax_coolwarm_h48_nfe48_tau1em3_iter30_reg0p02_repair1`, job
  `745768`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - initial and final Ipopt `inf_pr` stayed near `1.46e-1`
  - post-solve temperature movement: `0.0764 C`
  - post-solve FDA movement: `5.90e-4 g/L`
  - terminal selected sugar: `G + F = 190.66 g/L`

Interpretation: the combined strategy is implemented and does produce control
motion, but the broad offsets and wide trusts are still too aggressive for an
accepted post-solve candidate at 48 h. The next rung is therefore
`s18gentle`: smaller offsets, tighter trust regions, stronger reference
regularization, and `repair_iter=2`. Its purpose is to get accepted post-solve
motion first, then widen the basin again.

## 2026-06-20 s18 gentle seed-relax implementation

The staged bank now includes four `s18gentle` cases:

- `s18_gentle_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2`
- `s18_gentle_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`
- `s18_gentle_fdaearly_h48_nfe48_tau1em3_iter25_reg0p05_repair2`
- `s18_gentle_mixedsplit_h48_nfe48_tau1em3_iter25_reg0p05_repair2`

Common settings:

- 48 h / 48 finite elements;
- temperature slots `1:4`, addition slots `1:3`;
- tau `1e-3`;
- `repair_iter=2`;
- reference regularization `0.05`;
- temperature trust `1.5 C`;
- FDA trust `0.025 g/L`;
- organic trust `0.01 g/L`;
- strict Ipopt profile.

Submit the first two cases first. Continue with FDA-only and mixed only if the
first two produce accepted post-solve candidates or clearly better residual
behavior than `s17seedrelax`.

Initial `s18gentle` results:

- `s18_gentle_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2`, job
  `745807`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - post-solve temperature movement: `0.0318 C`
  - max collocation/continuity residual: `3.33e-7`
  - max lower-complementarity residual: `1.13e-5`
  - dominant post-solve residual: lower complementarity
- `s18_gentle_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`, job
  `745808`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - post-solve temperature movement: `0.00885 C`
  - post-solve FDA movement: `1.66e-5 g/L`
  - max collocation/continuity residual: `2.67e-5`
  - max lower-complementarity residual: `9.999e-4`
  - dominant post-solve residual: lower complementarity

Interpretation: `repair2` plus gentle starts does improve the structural
residual pattern, especially in the warm case, but post-solve rejection now
comes mainly from complementarity rather than collocation. The next rung is
therefore not another broad-start change; it is the same gentle pair with
`final_complementarity_flux_projection=1`.

## 2026-06-20 s19 complementarity projection implementation

The staged bank now includes two `s19compflux` cases:

- `s19_compflux_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2`
- `s19_compflux_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`

They are identical to the first two `s18gentle` cases except that
`final_complementarity_flux_projection=1`. Success means the post-solve point
is accepted as residual-feasible, or at least that the maximum
lower-complementarity residual falls without damaging collocation/continuity.

Final `s19compflux` results:

- `s19_compflux_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2`, job
  `745861`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - final complementarity flux projection applied: `false`
  - triggered points: `0`
  - post-solve temperature movement: `0.0319 C`
  - max collocation/continuity residual: `3.33e-7`
  - max lower-complementarity residual: `1.79e-5`
- `s19_compflux_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`, job
  `745862`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - final complementarity flux projection applied: `false`
  - triggered points: `92`
  - projection guard accepted: `false`
  - post-solve temperature movement: `0.00865 C`
  - max collocation/continuity residual: `2.67e-5`
  - max lower-complementarity residual: `9.70e-4`

Interpretation: final active-flux complementarity projection is not the rescue
step. In the warm case there is almost nothing for the projection to change; in
the cool-warm case it triggers many points but the guard restores the baseline.
The useful signal is that structural collocation can be made small while
post-solve acceptance remains blocked by complementarity/dual consistency. The
next rung is therefore `s20dualfits`: keep the same gentle starts, leave fluxes
fixed, and run the guarded selective stationarity dual fit. This is not dual
zeroing. The method only adjusts mass-balance and bound dual starts on
complementarity-triggered elements, preserves flux starts, and restores the
baseline duals if the stationarity guard would be violated.

## 2026-06-20 s20 selective-dual-fit implementation

The staged bank now includes two `s20dualfits` cases:

- `s20_dualfit_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2`
- `s20_dualfit_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`

Run these with:

```bash
export MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT=1
export MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT_TRIGGER_THRESHOLD=1e-5
```

Decision rule:

- if selective dual fit is accepted and the selected post-solve candidate
  becomes residual-feasible with nonzero control movement, extend the same
  method to 72 h;
- if selective dual fit is accepted but control motion remains tiny, reduce
  direct-control homotopy and inspect objective scaling;
- if selective dual fit is rejected by the stationarity guard, do not relax the
  guard blindly; inspect the triggered reactions and stationarity residuals
  before trying any bound-dual clipping.

Final `s20dualfits` results:

- `s20_dualfit_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2`, job
  `745914`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - selective dual fit enabled: `true`
  - selective dual fit applied: `false`
  - selective dual fit accepted: `true`
  - triggered element count: `0`
  - max collocation/continuity residual: `3.33e-7`
  - max lower-complementarity residual: `2.40e-5`
  - post-solve temperature movement: `0.0319 C`
- `s20_dualfit_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`, job
  `745915`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - selective dual fit enabled: `true`
  - selective dual fit applied: `true`
  - selective dual fit accepted: `true`
  - triggered element count: `31`
  - triggered collocation points: `93`
  - max stationarity residual after dual fit: `7.13e-9`
  - max lower-complementarity residual: `5.83e-4`
  - max collocation/continuity residual: `2.68e-5`
  - post-solve temperature movement: `6.02e-6 C`

Interpretation: selective dual fit is the first repair that materially reduces
the cool-warm lower-complementarity residual without violating stationarity,
from about `1.00e-3` in `s18` and `9.70e-4` in `s19` down to `5.83e-4` in
`s20`. It is still far above the residual gate `1e-5`, and it nearly freezes
post-solve control movement in the cool-warm case. The result is therefore
diagnostic, not promotable.

The next focused rung is `s21dualtight`, initially only for cool-warm. It keeps
the same start and enables:

```bash
export MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT=1
export MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT_TRIGGER_THRESHOLD=1e-5
export MPCC_FIXED_FLUX_DUAL_FIT_COMPLEMENTARITY_BUDGET_FRACTION=0.01
```

Rationale: the default dual-fit complementarity budget is `tau * 0.5`, which
for tau `1e-3` naturally leaves residuals around `5e-4`. A budget fraction of
`0.01` targets `1e-5`, the current lower-complementarity residual gate. This is
still a guarded fixed-flux dual fit, not bound-dual clipping and not blind dual
zeroing.

Final `s21dualtight` result:

- `s21_dualfit_tightbudget_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`,
  job `745968`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - selective dual fit enabled: `true`
  - selective dual fit accepted: `false`
  - selective dual fit applied: `false`
  - rejection reason:
    `stationarity_residual_would_exceed_guard_threshold`
  - restored baseline duals: `true`
  - triggered element count: `31`
  - effective complementarity budget: `1.0e-5`
  - selected max lower-complementarity residual: `9.999e-4`
  - selected max collocation/continuity residual: `2.67e-5`
  - post-solve temperature movement: `0.00877 C`

Interpretation: simply tightening the fixed-flux dual-fit budget to the
residual gate is too aggressive for the current start. The stationarity guard
does its job and restores the baseline, leaving the selected candidate
essentially at the `s18`/`s19` cool-warm residual pattern. Therefore the next
methodological step should not be unguarded dual clipping or dual zeroing.
Better options are:

- a budget continuation, e.g. `0.5 -> 0.2 -> 0.1 -> 0.05 -> 0.02 -> 0.01`,
  only advancing when the guard accepts and residuals improve;
- a trigger-threshold sweep, to see whether a different set of complementarity
  elements is causing the guard conflict;
- a small post-solve repair/diagnostic that reports which reactions/elements
  drive the stationarity-guard rejection before any further relaxation is used.

## 2026-06-20 s22/s23 relaxation-plus-broad-seed implementation

The relaxation strategy is now encoded in the staged TSV instead of relying on
manual environment overrides. The bank columns added after
`final_compflux_projection` are:

- `final_selective_dual_fit`
- `final_selective_dual_fit_trigger_threshold`
- `fixed_flux_dual_fit_budget_fraction`

This makes each rung reproducible from the row itself. Environment variables
can still override these values deliberately, but the normal path is now
row-driven.

The immediate budget-continuation stage is `s22dualbudget`, keeping the same
gentle cool-warm start as `s18/s20/s21` but replacing the abrupt `0.5 -> 0.01`
budget jump with intermediate guarded values:

- `s22_dualfit_budget0p2_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`
- `s22_dualfit_budget0p1_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`

Follow-up rows are already present but should wait for the first bracket:

- `s22_dualfit_budget0p05_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`
- `s22_dualfit_budget0p02_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`

The broad-seed relaxation stage is `s23broadrelax`. It uses the gentler `s18`
basins and the first intermediate budget `0.2`, so we can check whether the
relaxation is tied to the cool-warm basin or improves other starts too:

- warm temperature basin
- FDA-early basin
- mixed thermal-nutrient basin

The intended execution order is:

1. Submit only `s22dualbudget` first, max two jobs.
2. If budget `0.2` is accepted and improves complementarity without exploding
   stationarity, evaluate whether `0.1` is accepted.
3. If the bracket is sane, run `s23broadrelax` to avoid conditioning the method
   on one seeded profile.
4. Only then continue toward `0.05`, `0.02`, and eventually `0.01`.

Promotion remains disabled for these rungs. A result is useful if it identifies
an accepted relaxation corridor or clearly shows which budget/seed combination
trips the stationarity guard.

Final `s22dualbudget` results:

- `s22_dualfit_budget0p2_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`,
  job `746011`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - selective dual fit accepted/applied: `true`
  - budget fraction/effective tau: `0.2` / `2e-4`
  - max lower-complementarity residual after fit: `4.00e-4`
  - selected max lower-complementarity residual: `4.04e-4`
  - max collocation/continuity residual: `2.68e-5`
  - post-solve temperature movement: `4.93e-6 C`
- `s22_dualfit_budget0p1_coolwarm_h48_nfe48_tau1em3_iter25_reg0p05_repair2`,
  job `746012`:
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - selective dual fit accepted/applied: `false`
  - budget fraction/effective tau: `0.1` / `1e-4`
  - rejected fit trial lower-complementarity residual: `1.17e-4`
  - selected max lower-complementarity residual after baseline restore:
    `9.57e-4`
  - max collocation/continuity residual: `2.67e-5`

Interpretation: budget continuation found the first accepted corridor at
fraction `0.2`, improving the cool-warm line from the `s20` accepted residual
around `5.83e-4` to about `4.0e-4`. Fraction `0.1` is still too aggressive:
the local dual-fit attempt can reduce complementarity further, but the
stationarity guard rejects it and restores baseline duals. The next branch is
therefore `s23broadrelax` at budget `0.2`, not immediate tightening to `0.05`.

Final `s23broadrelax` results at budget fraction `0.2`:

- `s23_broadrelax_budget0p2_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2`,
  job `746055`:
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - max collocation/continuity residual: `3.33e-7`
  - selected max lower-complementarity residual: `1.19e-5`
  - complementarity locations file top residual: `5.56e-6` on `r_1654`
  - selective dual fit accepted: `true`, element count `0`
  - terminal sugar: `189.95 g/L`
  - post-solve temperature movement: `0.0319 C`
- `s23_broadrelax_budget0p2_fdaearly_h48_nfe48_tau1em3_iter25_reg0p05_repair2`,
  job `746056`:
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - max collocation/continuity residual: `1.17e-5`
  - selected max lower-complementarity residual: `4.09e-4`
  - selective dual fit accepted/applied: `true`
  - terminal sugar: `190.34 g/L`
- `s23_broadrelax_budget0p2_mixedsplit_h48_nfe48_tau1em3_iter25_reg0p05_repair2`,
  job `746057`:
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - max collocation/continuity residual: `4.64e-7`
  - selected max lower-complementarity residual: `4.08e-4`
  - selective dual fit accepted/applied: `true`
  - terminal sugar: `192.61 g/L`

Interpretation: the warm-temperature broad basin is now the best 48 h
development line. It is much closer to the trajectory gate than cool-warm,
FDA-only, or mixedsplit, and it avoids the large `~4e-4` complementarity plateau
seen when selective dual fit actually has to modify many triggered elements.
The next narrow refinement is `s24warmrepair`: keep warm/budget `0.2`, but
increase collocation repair from `2` to `4` iterations to see whether the
remaining trajectory extraction failure is repair-depth rather than a control
or dual-fit issue.

Final `s24warmrepair` result:

- `s24_warmrepair_budget0p2_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair4`,
  job `746099`:
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - max collocation/continuity residual: `7.75e-8`
  - selected max lower-complementarity residual: `1.24e-4`
  - selective dual fit accepted: `true`, element count `0`
  - post-solve rejected: `not_residual_feasible`
  - terminal sugar: `189.95 g/L`
  - post-solve temperature movement: `0.0177 C`

Interpretation: deeper repair is not monotonically better. It improves
collocation/continuity below `1e-7`, but worsens the selected
lower-complementarity residual relative to `s23` warm repair2. The current best
48 h development point remains `s23` warm repair2: it is residual-feasible,
has very small collocation residual, and is closest to the trajectory gate
without entering the `~4e-4` complementarity plateau seen in the other basins.
Do not escalate repair depth blindly; the next refinement should target the
specific residual/gate mismatch of the `s23` warm candidate.

Final `s25extend` / `s26samegrid` status:

- The 72 h warm-temperature extension from the best 48 h broad basin produced a
  residual-feasible selected candidate, but it is still not
  trajectory-ready. It is the current same-grid handoff seed for 72 h
  dynamic-control diagnostics.
- `s26_samegrid_directtemp_h72_nfe72_tau1em3_iter12_reg0_repair1_budget0p2`
  applied the full candidate start, including dynamic controls, and verified
  that direct temperature reward can move the simultaneous control variables:
  post-solve max temperature displacement was about `0.615 C`. The point was
  rejected because lower-complementarity rose to about `7.05e-4`; selected
  fallback remains the residual-feasible pre-solve start.
- `s26_samegrid_directnutrient_h72_nfe72_tau1em3_iter12_reg0_repair1_budget0p2`
  also applied the full candidate start, but FDA/organic motion was essentially
  pinned near zero. Post-solve nutrient displacement was only about
  `1.6e-7 g/L` FDA-sum and `5.5e-8 g/L` organic-sum.

Interpretation: the same-grid candidate handoff is technically working, but
copying candidate dynamic controls as well as states/fluxes can over-anchor the
control profile. This is useful when preserving a blessed profile, but it is not
ideal for broad-start optimization diagnostics where we want the state/flux
warm start without committing to one control basin.

Implementation adjustment for `s27stateflux`:

- Added `MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS`.
- Default is `1`, preserving previous behavior.
- When set to `0`, the serialized candidate still seeds states/fluxes/duals,
  but dynamic-control start values are left as generated from the target problem
  schedule and TSV offsets.
- This lets us test "state/flux warm start plus broad control start" without
  conditioning the solution on the candidate's copied temperature/nutrient
  profile.

Planned `s27stateflux` diagnostics:

- `s27_stateflux_controlbroad_directtemp_h72_nfe72_tau1em3_iter12_reg0p02_repair2_budget0p2`
  uses the `s25` warm selected candidate for states/fluxes, skips candidate
  dynamic-control copying, initializes warm TSV temperature offsets, lowers the
  direct temperature reward from `50` to `10`, and adds `reg0p02`/repair2 to
  seek accepted motion rather than a large rejected displacement.
- `s27_stateflux_controlbroad_directnutrient_h72_nfe72_tau1em3_iter12_reg0p02_repair2_budget0p2`
  uses the same state/flux handoff, skips copied controls, and starts from mild
  interior FDA/organic offsets to test whether the previous nutrient immobility
  was lower-bound/control-start pinning.

Submit `s27stateflux` with:

```bash
MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=0
```

Promotion remains disabled. A useful result is either accepted small control
motion, or a clear diagnosis that changing controls while keeping the same
state/flux candidate immediately breaks the local MPCC geometry.

Final `s27stateflux` results:

- `s27_stateflux_controlbroad_directtemp_h72_nfe72_tau1em3_iter12_reg0p02_repair2_budget0p2`,
  job `746300`:
  - `MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=0` worked as
    intended: candidate states/fluxes were applied, but dynamic controls were
    left from the target problem starts.
  - solver status: `ITERATION_LIMIT`
  - selected candidate: pre-solve start
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve rejected: `not_residual_feasible`
  - post-solve temperature movement: `0.0268 C`
  - max lower-complementarity residual: `9.36e-6`
  - top complementarity locations file: about `8.6e-6` on `r_1654`
  - max collocation/continuity residual: `1.65e-6`, dominated by terminal
    `protein`

  Interpretation: this is a real improvement over the `s26` direct-temperature
  diagnostic. Skipping candidate dynamic-control copying avoided over-anchoring
  and preserved a small but real control movement while keeping
  complementarity near the residual-feasible gate. The remaining blocker is not
  temperature-control connectivity; it is the `protein` tail
  continuity/collocation residual.

- `s27_stateflux_controlbroad_directnutrient_h72_nfe72_tau1em3_iter12_reg0p02_repair2_budget0p2`,
  job `746309`:
  - candidate states/fluxes were applied and dynamic controls were left from
    mild interior FDA/organic TSV starts.
  - solver status: `ITERATION_LIMIT`
  - selected candidate: post-solve diagnostics only
  - selected residual-feasible: `false`
  - post-solve rejected: `not_residual_feasible`
  - initial Ipopt `inf_pr`: about `1.16e-1`
  - max RHS residual: `1.55e-3`, top RHS residual on `leucine`
  - max upper/lower bound violation: about `1.16e-1` / `5.78e-2`
  - max lower/upper complementarity residual: about `9.17e-4` / `7.81e-4`
  - nutrient movement was nonzero but tiny: FDA sum delta `2.39e-4 g/L`;
    organic sum delta `-1.45e-5 g/L`

  Interpretation: nutrient controls are much more tightly coupled to dynamic
  bounds/RHS than temperature controls. Mild interior nutrient starts from the
  same state/flux candidate are not a safe same-grid warm start: they create
  RHS/bound inconsistency before Ipopt can make useful progress. Future
  nutrient release should use sequentially consistent nutrient starts, or a
  staged nutrient assimilation repair, rather than simply skipping copied
  zero-dose controls.

Next methodological rung:

1. For temperature: keep `candidate_start_apply_dynamic_controls=0`, keep the
   damped direct reward/regularization, and target the terminal `protein`
   continuity/collocation defect. Do not increase temperature reward first.
2. For nutrients: do not reuse the `s27` interior nutrient strategy directly.
   Build a sequential nutrient-consistent candidate or add a nutrient-control
   assimilation repair before attempting another simultaneous nutrient release.
3. Only after the temperature branch yields accepted post-solve motion should
   we combine it with productivity pressure.

Planned `s28tailrepair` diagnostic:

- Case:
  `s28_stateflux_controlbroad_directtemp_tailrepair_h72_nfe72_tau1em3_iter12_reg0p02_repair2_budget0p2`
- Reuse the `s25` warm 72 h residual-feasible candidate as state/flux/dual
  seed, but keep `MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=0`
  so the temperature profile starts from the broad warm TSV offsets rather
  than copied controls.
- Keep the `s27` direct-temperature pressure and regularization unchanged:
  direct temperature reward `10.0`, reference regularization `0.02`,
  `max_iter=12`, `tau=1e-3`.
- Enable post-tail collocation repair on the terminal elements where `s27`
  reported the dominant `protein` residual:
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ENABLED=1`,
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS=64:72`.
- Success criterion for this rung is not a larger control move; it is an
  accepted post-solve candidate with the tail `protein` collocation/continuity
  defect reduced or no worse, while preserving residual feasibility and keeping
  complementarity near the `s27` temperature level.

Final `s28tailrepair` result:

- `s28_stateflux_controlbroad_directtemp_tailrepair_h72_nfe72_tau1em3_iter12_reg0p02_repair2_budget0p2`,
  job `746356`:
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s28_stateflux_controlbroad_directtemp_tailrepair_h72_nfe72_tau1em3_iter12_reg0p02_repair2_budget0p2_20260620_214635`
  - `MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=0`
  - post-tail repair enabled on elements `64:72`
  - Ipopt: MA86, limited-memory Hessian, `max_iter=12`
  - Ipopt iter 0: objective `-2.7036687`, `inf_pr=1.65e-6`,
    `inf_du=1.00e2`
  - Ipopt exit: `ITERATION_LIMIT`, no restoration observed
  - final Ipopt objective: `-3.0332797`
  - final Ipopt constraint violation: `1.648e-6`
  - final Ipopt complementarity: `2.205e-7`
  - post-solve candidate: rejected, `not_residual_feasible`
  - selected candidate source: `pre_solve_start_values`
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve temperature movement vs pre-solve: `0.026805 C`
  - post-solve FDA/organic movement: effectively zero
  - selected terminal total sugar at 72 h: `174.426 g/L`
  - selected terminal isoamyl alcohol: `2.040e-4 g/L`
  - top residual remains terminal `protein` collocation/continuity at 72 h,
    about `1.65e-6`
  - top complementarity location remains lower complementarity on `r_1654`,
    about `8.61e-6`

The post-tail repair itself was accepted and useful at the start-construction
level:

- main repair iteration 1: score `0.155 -> 3.57e-6`
- main repair iteration 2: score `3.57e-6 -> 1.65e-6`
- post-tail repair on elements `64:72`: `1.65e-6 -> 9.63e-7`

Interpretation: s28 validates the mixed strategy only halfway. Broad thermal
starts plus state/flux candidate handoff preserve a small primal residual and
let Ipopt improve the objective without restoration, but the solved point is
still not promotable because post-solve residual feasibility is lost. The
tail-repair mechanism works before the solve, yet Ipopt can move back onto the
terminal `protein` defect during optimization. The next rung should therefore
protect the tail defect during the solve or reduce the allowed movement around
the terminal protein manifold, rather than simply increasing direct temperature
reward.

Recommended next rung:

1. Keep `candidate_start_apply_dynamic_controls=0`.
2. Keep the broad warm temperature starts.
3. Lower reference regularization only mildly, if at all; do not jump to a free
   full-profile objective yet.
4. Add a residual guard/penalty around terminal `protein`
   collocation/continuity, or run a two-step Slurm path: tail-repaired start
   generation followed by a guarded Ipopt solve that uses the repaired start as
   the candidate handoff.
5. Keep nutrients fixed until a nutrient-consistent sequential start or
   nutrient assimilation repair is available.

Planned `s29tailguard` diagnostic:

- Case:
  `s29_stateflux_controlbroad_directtemp_tailguard_h72_nfe72_tau1em3_iter16_reg0p02_repair2_budget0p2`
- Same state/flux candidate handoff, broad warm temperature starts, direct
  temperature reward `10.0`, `reg0p02`, `tau=1e-3`, and post-tail repair as
  s28.
- New optional objective regularization:
  - `MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_WEIGHT`
  - `MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_STATE=protein`
  - `MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_ELEMENTS=64:72`
  - `MPCC_DYNAMIC_CONTROL_OBJECTIVE_TAIL_RESIDUAL_SCALE_G_L=1e-6`
- This term duplicates existing collocation/continuity residual expressions, so
  it should be zero at a feasible point and should not change the feasible
  optimum. Its purpose is algorithmic: discourage Ipopt iterates from buying
  objective improvement by drifting back onto the terminal `protein` defect.
- Success criterion: post-solve residual feasibility improves versus s28, or at
  minimum post-solve residual damage is reduced while preserving small
  temperature motion and no restoration.

Final `s29tailguard` result:

- `s29_stateflux_controlbroad_directtemp_tailguard_h72_nfe72_tau1em3_iter16_reg0p02_repair2_budget0p2`,
  job `746401`:
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s29_stateflux_controlbroad_directtemp_tailguard_h72_nfe72_tau1em3_iter16_reg0p02_repair2_budget0p2_20260620_221240`
  - tail residual objective guard: enabled, weight `0.2`, state `protein`,
    elements `64:72`, scale `1e-6`
  - Ipopt iter 0: objective `-2.4861472`, `inf_pr=1.65e-6`,
    `inf_du=1.00e2`
  - Ipopt exit: `ITERATION_LIMIT`, no restoration observed
  - final Ipopt objective: `-3.1834592`
  - final Ipopt constraint violation: `1.561e-6`
  - final Ipopt scaled dual infeasibility: `90.51`
  - post-solve candidate: rejected, `not_residual_feasible`
  - selected candidate source: `pre_solve_start_values`
  - selected residual-feasible: `true`
  - selected trajectory-ready: `false`
  - post-solve temperature movement vs pre-solve: `0.00422 C`
  - post-solve lower complementarity residual: `1.98e-5`
  - post-solve dominant residual: lower complementarity, not collocation

Interpretation: the tail-residual objective guard is algorithmically helpful:
relative to s28, Ipopt lowered collocation/continuity residual
(`1.65e-6 -> 1.56e-6`) and reduced scaled dual infeasibility
(`99.9 -> 90.5`) without restoration. However, the post-solve candidate still
failed residual feasibility because complementarity worsened. The selected
candidate remains the pre-solve start.

Important order-of-operations finding: the repair trace reports post-tail
repair acceptance down to `9.63e-7`, but the selected residual-location table
still shows terminal `protein` at `1.65e-6`. The solve-attempt phase order is:

1. build problem and apply collocation repair/post-tail repair,
2. apply serialized candidate start seed,
3. run pre-solve diagnostics and capture pre-solve candidate values.

Therefore the serialized candidate handoff can overwrite the repaired state
starts before Ipopt. The next correction is to re-apply tail repair after
candidate seeding and before pre-solve diagnostics.

Planned `s30repairafter` diagnostic:

- Case:
  `s30_stateflux_controlbroad_directtemp_tailguard_repairafter_h72_nfe72_tau1em3_iter16_reg0p02_repair2_budget0p2`
- Same s29 tail-residual objective guard.
- New solve-order option:
  - `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START=1`
  - `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START_ELEMENTS=64:72`
  - `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START_MAX_ITER=2`
  - `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START_TOL=1e-10`
- Success criterion: pre-solve candidate residual locations should reflect the
  repaired tail instead of the overwritten candidate tail, and post-solve should
  preserve or improve the s29 collocation/dual gains without introducing a
  larger complementarity failure.

Final `s30repairafter` result:

- `s30_stateflux_controlbroad_directtemp_tailguard_repairafter_h72_nfe72_tau1em3_iter16_reg0p02_repair2_budget0p2`,
  job `746442`:
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s30_stateflux_controlbroad_directtemp_tailguard_repairafter_h72_nfe72_tau1em3_iter16_reg0p02_repair2_budget0p2_20260620_223830`
  - repair-after-candidate-start: enabled, elements `64:72`, `max_iter=2`,
    tolerance `1e-10`
  - tail residual objective guard: enabled, weight `0.2`, state `protein`,
    elements `64:72`, scale `1e-6`, `36` objective terms
  - Ipopt iter 0: objective `-2.7035732`, `inf_pr=9.63e-7`,
    `inf_du=1.00e2`
  - Ipopt exit: `ITERATION_LIMIT`, no restoration observed
  - final Ipopt objective: `-3.4236446`
  - final Ipopt constraint violation: `9.264e-7`
  - final Ipopt scaled dual infeasibility: `1.768e3`
  - post-solve candidate: accepted, residual-feasible
  - selected candidate source: `post_solve_values`
  - selected trajectory-ready: `false`
  - dominant residual: continuity of `protein` at `t=63 h`, element `63`,
    `9.264e-7`
  - dominant complementarity residual: lower complementarity of `r_1654`,
    `9.132e-6`

Interpretation: this validates the relaxed/broad-start methodology enough to
keep building on it. The repaired tail now survives candidate seeding and is
visible directly in Ipopt iter 0 (`inf_pr=9.63e-7`, versus `1.65e-6` in s28/s29
after the serialized candidate overwrote the repair). The post-solve candidate
is now selected and residual-feasible, which is an important step beyond s28/s29.

The remaining blocker is no longer the same primal tail overwrite. It is the
dual/complementarity side: after Ipopt moves the broad temperature controls, the
largest complementarity product is still close to the residual-feasible limit
and `trajectory_ready=false`. The next diagnostic should keep the s30 repair
order, but lower the selective dual-fit trigger or otherwise refit KKT/bound
duals after repair so the repaired primal start is paired with a compatible
dual start before Ipopt.

Final `s31dualtightafter` result:

- `s31_stateflux_controlbroad_directtemp_tailguard_repairafter_dualtight_h72_nfe72_tau1em3_iter16_reg0p02_repair2_budget0p005`,
  job `746487`:
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s31_stateflux_controlbroad_directtemp_tailguard_repairafter_dualtight_h72_nfe72_tau1em3_iter16_reg0p02_repair2_budget0p005_20260620_230811`
  - same repair-after-candidate and terminal `protein` tail-residual objective
    guard as s30
  - changed dual-fit settings: selective dual-fit trigger `1e-6`, fixed-flux
    dual-fit complementarity budget fraction `0.005`
  - initial all-grid repair cost increased from roughly `297 s` in s30 to
    `490 s`
  - repair-after-candidate-start cost increased from roughly `356 s` in s30 to
    `499 s`
  - Ipopt iter 0: objective `-2.7035732`, `inf_pr=9.63e-7`,
    `inf_du=1.00e2`
  - Ipopt exit: `ITERATION_LIMIT`, no restoration observed
  - final Ipopt objective: `-3.4234050`
  - final Ipopt constraint violation: `9.264e-7`
  - final Ipopt scaled dual infeasibility: `1.768e3`
  - post-solve candidate: accepted, residual-feasible
  - selected candidate source: `post_solve_values`
  - selected trajectory-ready: `false`
  - dominant residual: continuity of `protein` at `t=63 h`, element `63`,
    `9.264e-7`
  - dominant complementarity residual: lower complementarity of `r_1654`,
    `9.135e-6`
  - selective dual-fit selected `9` elements but was not accepted by the guard;
    `collocation_consistent_state_start_last_final_selective_dual_fit_applied=false`

Interpretation: s31 is a useful negative control. Tightening the selective
dual-fit trigger/budget made the start generation significantly more expensive
but did not improve the final Ipopt geometry versus s30. The decisive
methodological fix remains the s30 order correction: broad control starts plus
tail regularization plus repair after candidate seeding. The next useful branch
should not spend more effort on this selective dual-fit knob. It should either
try a guarded complementarity flux projection after the repaired start, or use
s30 directly as the base for the next horizon/control-release diagnostic.

## 2026-06-21 relaxed funnel implementation

The next implementation step formalizes the mixed strategy instead of launching
single hand-written experiments:

- New wrapper:
  `repro/submit_cluster_uc_dynamic_control_relaxed_funnel.sh`
- New bank stage:
  `s33relaxedfunnel`
- Default target for the first funnel:
  96 h, `nfe=96`, tau `1e-3`, repair2, limited-memory Hessian, MA86/HSL,
  4 threads, no GPU.

The wrapper encodes three seed modes:

1. `none`: no handoff; the target horizon uses sequential/local starts plus the
   broad TSV control offsets.
2. `cross-horizon-audit`: pass the selected candidate artifact only as audited
   context, while forcing `MPCC_FIXED_CONTROL_FLUX_DUAL_START_MODE=none`.
   This avoids the damaging 72 -> 96 h terminal flux/dual copy seen in s32.
3. `same-grid-stateflux`: same-grid full candidate handoff for state/flux/dual
   starts, but with
   `MPCC_FIXED_CONTROL_CANDIDATE_START_APPLY_DYNAMIC_CONTROLS=0` so dynamic
   controls come from the broad TSV row. It also enables
   `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START=1` so serialized candidate
   starts cannot overwrite the repaired tail before pre-solve diagnostics.

The wrapper also applies the current relaxation recipe consistently:

- post-tail repair enabled over the last 9 finite elements by default;
- tail residual objective guard on terminal `protein`, default weight `0.2`,
  scale `1e-6`;
- relaxed dynamic-flux LP fallback enabled;
- guarded selective dual-fit disabled by default;
- strict Ipopt profile, MA86, limited-memory Hessian, `OPENBLAS_NUM_THREADS=1`;
- Slurm availability checked before any submit.

The `s33relaxedfunnel` 96 h bank covers four starts:

- warm-temperature basin;
- cool-early/warm-late plus early FDA;
- FDA interior start, to avoid lower-bound dose pinning;
- mixed thermal/FDA/organic split.

This addresses the start-conditioning concern directly: a promoted branch must
survive comparison against multiple broad basins, and the controls must move
without creating dominant collocation/complementarity damage. We are not
declaring the seeded profile to be the answer; we are using several seeds to
learn which basin lets Ipopt move while preserving residual sanity.

Updated 96 h diagnostic evidence:

- `s32_compflux_warm_fda_h96_tau1em3_iter8_repair2`, job `746548`, was
  cancelled before Ipopt after spending the development budget in start/repair
  generation.
- `s32_compflux_coolwarm_fdaearly_h96_tau1em3_iter8_repair2`, job `746549`,
  reached Ipopt but started with `inf_pr=8.86`, entered restoration from the
  first iteration, and ended infeasible. The guarded complementarity flux
  projection did not apply.

Interpretation: cross-horizon `flux_duals` plus guarded compflux projection is
not the baseline for 72 -> 96 h. It is a diagnostic mode. The corrected funnel
uses broad sequential/local starts at 96 h, or same-grid state/flux handoff with
dynamic controls deliberately re-seeded from the TSV.

## 2026-06-21 s33 pre-solve diagnostics

The first two `s33relaxedfunnel` 96 h runs were launched through the new
wrapper:

- `s33_funnel_warmtemp_h96_nfe96_tau1em3_iter12_reg0p02_repair2`, job
  `746617`
- `s33_funnel_coolwarm_fdaearly_h96_nfe96_tau1em3_iter12_reg0p02_repair2`,
  job `746618`

Both reached Ipopt with MA86/HSL but started with huge primal infeasibility:

- warm-temperature: Ipopt iter 0 `inf_pr=8.82`
- cool-warm plus FDA: Ipopt iter 0 `inf_pr=8.90`

Both were cancelled immediately according to the UC cluster rule for jobs that
start with a clearly bad primal point. This was not a failure of Slurm or HSL;
it was a start-consistency failure.

A pre-solve-only mode was then added:

- env: `MPCC_FIXED_CONTROL_PRE_SOLVE_ONLY=1`
- wrapper flag: `--pre-solve-only`
- behavior: build the MPCC start, run pre-solve diagnostics, capture the
  pre-solve candidate and write CSV/JLS artifacts, but do not call Ipopt.

Validation run:

- job `746655`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s33_funnel_warmtemp_h96_nfe96_tau1em3_iter12_reg0p02_repair2_20260621_005036`
- status: completed in `00:16:31`, 4 CPUs, max RSS about `3.36 GB`
- `solver_call_performed=false`
- `solver_status=OPTIMIZE_NOT_CALLED`
- selected candidate source: `pre_solve_start_values`
- selected candidate residual-feasible: `true`
- selected candidate trajectory-ready: `false`
- dominant residual: `max_collocation_integration_residual`
- max collocation/continuity: `1.4457e-5`
- max lower complementarity: `3.1730e-5`
- top residual location: `protein`, element `87`, collocation `3`, `t=87 h`

Important interpretation: the pre-solve candidate is residual-feasible by the
existing MPCC residual gates, yet the previous Ipopt call saw `inf_pr≈8.8`.
The gap is that the existing residual diagnostics did not audit all dynamic
objective slack constraints. The integrated sugar objective creates 288
constraints and slack variables. Those slack starts are initialized when the
objective is built, but subsequent collocation/state repair can change
`glucose/fructose` starts without refreshing the associated slack starts.

Implementation correction:

- Added a post-repair refresh of dynamic objective slack starts before
  pre-solve diagnostics and before Ipopt:
  `dynamic_control_integrated_sugar_excess_slack[e,j] =
  max(0, glucose_start[e,j] + fructose_start[e,j] - sugar_max)`.
- Also refreshes terminal sugar excess slack when present.
- Adds metadata:
  - `dynamic_control_objective_slack_start_refresh_applied`
  - `dynamic_control_objective_slack_start_refresh_integrated_sugar_count`
  - `dynamic_control_objective_slack_start_refresh_integrated_sugar_max_delta_g_L`
  - `dynamic_control_objective_slack_start_refresh_integrated_sugar_max_violation_before_g_L`

The next validation is another pre-solve-only `s33` run. Success criterion:
the refresh metadata should show a nonzero correction, and the next real Ipopt
smoke should no longer start with `inf_pr≈8.8`. If primal infeasibility remains
large after slack refresh, the next missing audit is an NLP block violation
report for objective constraints.

## 2026-06-21 s34 slack-refresh smoke

The slack-refresh correction was validated with a deliberately short real
Ipopt smoke:

- case:
  `s34_funnel_warmtemp_h96_nfe96_tau1em3_iter2_reg0p02_repair2`
- job: `746721`
- partition/node: `512x1024`, `n11`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s34_funnel_warmtemp_h96_nfe96_tau1em3_iter2_reg0p02_repair2_20260621_013239`
- resources: 4 CPUs, 20 GB, `OPENBLAS_NUM_THREADS=1`
- solver: Ipopt 3.14.19, MA86, limited-memory Hessian
- NLP size: `1,609,481` variables and `2,466,547` constraints

The key validation is the Ipopt starting point:

- iter 0 before the fix, from `s33`: `inf_pr=8.82` to `8.90`
- iter 0 after slack refresh, from `s34`: `inf_pr=1.45e-5`,
  `inf_du=1.00e2`

The run ended by design at `max_iter=2`:

- solver status: `ITERATION_LIMIT`
- final Ipopt constraint violation: `1.349e-5`
- final complementarity: `1.031e-3`
- no restoration
- no HSL/MA86 failure

Post-solve was rejected as not residual-feasible, so this is not a promotable
candidate. The selected candidate is again the pre-solve start:

- `selected_candidate_source=pre_solve_start_values`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=false`
- dominant residual: `max_continuity_residual`
- top residual: `protein`, element `87`, collocation `3`, residual
  `1.4457e-5`
- top complementarity: `r_1903`, lower complementarity, `3.17e-5`

Dynamic controls were correctly liberated and wired:

- `control_variable_count=22`
- `control_free_variable_count=12`
- free controls: 4 temperature, 4 FDA, 4 organic
- controls coupled to RHS and dynamic flux bounds
- post-solve control deltas were tiny because the smoke allowed only two Ipopt
  iterations, e.g. max temperature delta `1.23e-5 C`

Interpretation: the huge initial primal infeasibility was caused by stale
dynamic objective slack starts, not by Slurm, HSL, or a fundamental inability to
build the 96 h simultaneous NLP. The next step is to rerun the `s33` funnel
cases with the slack refresh active and enough iterations to observe real
control motion. Promotion remains blocked until a post-solve candidate is
residual-feasible and preferably trajectory-ready.

## 2026-06-21 s33 warm funnel after slack refresh

The corrected long warm-temperature case was then rerun:

- case:
  `s33_funnel_warmtemp_h96_nfe96_tau1em3_iter12_reg0p02_repair2`
- job: `746754`
- partition/node: `512x1024`, `n11`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s33_funnel_warmtemp_h96_nfe96_tau1em3_iter12_reg0p02_repair2_20260621_015223`
- resources: 4 CPUs, 20 GB, `OPENBLAS_NUM_THREADS=1`
- solver: Ipopt 3.14.19, MA86, limited-memory Hessian

The run confirms that the slack refresh also fixes the full `s33` case:

- Ipopt iter 0: objective `8.7024432e1`, `inf_pr=1.45e-5`,
  `inf_du=1.00e2`
- no restoration
- no HSL/MA86 failure
- objective at iter 12: `8.6327326e1`
- final Ipopt constraint violation: `1.3338e-5`
- final Ipopt complementarity: `1.0212e-3`
- solver status: `ITERATION_LIMIT`

The post-solve candidate is still rejected:

- `post_solve_candidate_residual_feasible=false`
- `post_solve_candidate_rejection_reason=not_residual_feasible`
- selected candidate source: `pre_solve_start_values`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=false`
- selected terminal sugar remains the pre-solve value:
  `G+F=170.6115 g/L` at 96 h

Post-solve control motion exists but is still small:

- max temperature delta vs pre-solve: `0.02394 C`
- temperature post-solve values:
  `[23.0072, 22.0, 22.9997, 22.0, 22.5000, 22.0, 22.2261, 22.0] C`
- FDA and organic deltas are effectively numerical noise, around `1e-8 g/L`

The active blocker moved from initial objective slack infeasibility to the
dual/complementarity side:

- dominant post-solve residual: `max_lower_complementarity_residual`
- max lower complementarity residual: `9.9895e-4`
- max upper complementarity residual: `1.8428e-5`
- max continuity/collocation residual remains about `1.3338e-5`, still tied to
  `protein` around `78-87 h`
- top complementarity remains late-horizon reactions near `r_1903`/neighbors

Interpretation: the simultaneous NLP is now entering Ipopt from a residual-sane
primal point and can move controls, but 12 limited-memory iterations are not
enough to obtain an acceptable post-solve candidate. The next technical branch
should compare whether this is basin-specific or structural: run one nutrient
or mixed broad start with the same slack refresh, and in parallel prepare a
tighter complementarity/dual-start variant for the warm case. Do not promote
the `s33` warm post-solve result.

Follow-up implementation:

- Submitted the mixed thermal/FDA/organic basin
  `s33_funnel_mixedsplit_h96_nfe96_tau1em3_iter12_reg0p02_repair2` as job
  `746791`.
- Added a prepared but not-yet-submitted dual-tight warm case:
  `s35_funnel_warmtemp_h96_nfe96_tau1em3_iter20_reg0p02_repair2_dualtight`.
  This keeps the validated warm basin but enables final selective fixed-flux
  dual fitting with trigger `1e-6`, complementarity budget fraction `0.005`,
  and `max_iter=20`.
- Fixed `submit_cluster_uc_dynamic_control_relaxed_funnel.sh` so it no longer
  unconditionally overrides TSV rows with
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT=0`. After the
  fix, dry-run confirms `s35` has effective
  `final_selective_dual_fit=1`.

Decision rule: wait for the mixedsplit result before submitting `s35`. If
mixedsplit shows the same lower-complementarity blocker, submit `s35`; if
mixedsplit produces substantially better post-solve residuals or meaningful
nutrient motion, compare that basin before changing the warm dual strategy.

## 2026-06-21 s33 mixedsplit basin after slack refresh

The mixed thermal/FDA/organic basin was run as:

- case:
  `s33_funnel_mixedsplit_h96_nfe96_tau1em3_iter12_reg0p02_repair2`
- job: `746791`
- partition/node: `512x1024`, `n11`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s33_funnel_mixedsplit_h96_nfe96_tau1em3_iter12_reg0p02_repair2_20260621_021504`
- solver: Ipopt 3.14.19, MA86, limited-memory Hessian

The slack-refresh correction also works for this basin:

- Ipopt iter 0: objective `1.0163055e2`, `inf_pr=4.75e-5`,
  `inf_du=1.00e2`
- no restoration
- objective at iter 12: `9.7443384e1`
- final Ipopt constraint violation: `3.7028e-5`
- final Ipopt complementarity: `2.0766e-2`
- solver status: `ITERATION_LIMIT`

The post-solve candidate is still rejected:

- `post_solve_candidate_residual_feasible=false`
- `post_solve_candidate_rejection_reason=not_residual_feasible`
- selected candidate source: `pre_solve_start_values`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=false`
- selected terminal sugar: `G+F=174.9942 g/L` at 96 h

Compared with the warm basin, mixedsplit shows materially larger control
motion:

- max temperature delta vs pre-solve: `0.2162 C`
- post-solve temperature values:
  `[22.3959, 22.0, 22.7162, 22.0, 22.6672, 22.0, 22.8745, 22.0] C`
- max FDA delta vs pre-solve: `0.02095 g/L`
- post-solve FDA values:
  `[0.04095, 0.0, 0.01829, 0.0, 0.0, 0.0, 0.0] g/L`
- max organic delta vs pre-solve: `0.000826 g/L`

The active blocker remains residual quality rather than control wiring:

- dominant post-solve residual: `max_lower_complementarity_residual`
- max lower complementarity residual: `6.6540e-4`, better than warm
  `9.9895e-4`
- max continuity/collocation residual: `3.7028e-5`, worse than warm
  `1.3338e-5`
- max RHS residual: `2.6543e-6`, above threshold
- top residual remains `protein` near `87 h`

Interpretation: broad seeding is not merely conditioning the answer; different
basins produce different control motion, and the MPCC does respond to nutrient
controls when started away from lower-bound zero. However, both basins still
fail post-solve promotion through complementarity and `protein`
collocation/continuity. The next controlled experiment is therefore `s35`:
same warm basin, but with the now-effective selective dual fit enabled, to test
whether complementarity can be reduced without adding new basin effects.

## 2026-06-21 s35 dual-tight warm funnel

The dual-tight warm case was submitted after confirming that the relaxed-funnel
wrapper no longer overwrites TSV-level
`MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT=1`:

- case:
  `s35_funnel_warmtemp_h96_nfe96_tau1em3_iter20_reg0p02_repair2_dualtight`
- job: `746833`
- partition/node: `512x1024`, `n11`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s35_funnel_warmtemp_h96_nfe96_tau1em3_iter20_reg0p02_repair2_dualtight_20260621_024213`
- solver: Ipopt 3.14.19, MA86, limited-memory Hessian

The run remained operationally healthy:

- Ipopt iter 0: `inf_pr=1.45e-5`
- no restoration
- no HSL/MA86 failure
- solver status: `ITERATION_LIMIT`
- final objective: `85.5920`

It was not promotable:

- `post_solve_candidate_residual_feasible=false`
- selected candidate source: `pre_solve_start_values`
- `selected_candidate_residual_feasible=true`
- `selected_candidate_trajectory_ready=false`
- selected terminal sugar: `G+F=170.6115 g/L` at 96 h

The final selective dual fit was enabled but rejected:

- `selective_fixed_flux_stationarity_dual_fit_accepted=false`
- rejection reason: stationarity residual guard would be exceeded
- post-solve dominant residual:
  `max_lower_complementarity_residual=9.999985e-4`
- `max_upper_complementarity_residual=3.7117e-5`
- `max_collocation_integration_residual=1.3238e-5`
- `max_continuity_residual=1.3238e-5`
- top residual remains `protein` near `87 h`

Interpretation: the slack-start refresh is validated, but dual tightening on
the 96 h warm basin does not solve the active promotion blocker. The next
methodological step is to stop over-tuning the 96 h basin and build an
extended-horizon sequential frontier, because the model kinetics do not justify
forcing dry wine at 168 h.

## 2026-06-21 extended sequential frontier h336

Submitted a sequential extended atlas to locate physically coherent starts for
the next MPCC near-dry/extended-horizon pilots:

- job: `746891`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_sequential_extended_atlas_h336_extended_frontier_12c_20260621_031922`
- horizon: `336 h`
- control interval: `12 h`
- candidate set: `extended_horizon_frontier`
- max candidates: `12`
- terminal sugar feasibility mode: `numeric_health`
- selection final sugar max: `Inf`
- stop on sugar depletion: `false`
- resources: 4 CPUs, 16 GB, no GPU, `OPENBLAS_NUM_THREADS=1`

This atlas intentionally treats dryness as a reported gate rather than a hard
failure criterion during horizon discovery. The follow-up MPCC should use a
strict near-dry reference if the atlas finds one; otherwise, the policy
selection wrapper now has an explicit opt-in
`MPCC_EXTENDED_NEARDRY_DEVELOPMENT_READY_IGNORE_GATES=1` mode to mark the
candidate as a development reference rather than a promotable dry handoff.

Early monitoring showed that the first run spent about 12 minutes precompiling
the Julia environment on a compute node, then began candidate evaluation. The
first candidate, `flat25__springferm_early_1p0_stress`, failed with a
sequential RHS FBA infeasibility near `70.8 h`, so it should not be used as a
start. The second candidate advanced very slowly near `160 h` with thousands
of RHS calls and no per-candidate guardrails configured. Jobs `746891` and the
unstarted complementary FDA run `746929` were therefore canceled rather than
allowing one stiff/infeasible trajectory to consume the atlas budget.

The guarded replacement frontier runs are:

- job: `746931`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_sequential_extended_atlas_h336_extended_frontier_12c_guard8k_8m_20260621_034521`
- candidate set: `extended_horizon_frontier`
- max candidates: `12`
- per-candidate guards: `DFBA_DYNAMIC_CONTROL_OPT_MAX_RHS_CALLS=8000`,
  `DFBA_DYNAMIC_CONTROL_OPT_MAX_WALLTIME_SECONDS=480`

This broad guarded replacement was later canceled during Julia startup because
running it concurrently with the FDA-focused atlas produced repeated
compile-cache warnings on the shared Julia depot. The FDA-focused run was kept
alive to obtain a clean first extended-horizon frontier.

To avoid depending only on SpringFerm/mixed starts, a complementary FDA-focused
sequential atlas was submitted with the same horizon and guards:

- job: `746932`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_sequential_extended_atlas_h336_fda_frontier_8c_guard8k_8m_20260621_034527`
- candidate set: `extended_horizon_fda_frontier`
- max candidates: `8`
- per-candidate guards: `DFBA_DYNAMIC_CONTROL_OPT_MAX_RHS_CALLS=8000`,
  `DFBA_DYNAMIC_CONTROL_OPT_MAX_WALLTIME_SECONDS=480`
- resources: 4 CPUs, 16 GB, no GPU, `OPENBLAS_NUM_THREADS=1`

Job `746932` also remained in Julia startup with repeated compile-cache
warnings and no partial CSV. It was canceled and replaced by a single FDA-only
run with compiled modules and pkgimages disabled:

- job: `746958`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_sequential_extended_atlas_h336_fda_frontier_8c_guard8k_8m_nocache_20260621_040103`
- candidate set: `extended_horizon_fda_frontier`
- max candidates: `8`
- per-candidate guards: `DFBA_DYNAMIC_CONTROL_OPT_MAX_RHS_CALLS=8000`,
  `DFBA_DYNAMIC_CONTROL_OPT_MAX_WALLTIME_SECONDS=480`
- Julia flags: `MPCC_JULIA_COMPILED_MODULES=no`,
  `MPCC_JULIA_PKGIMAGES=no`, `JULIA_PKG_PRECOMPILE_AUTO=0`

Early soft v2 results:

- `flat22__none`: completed `336 h`, `retcode=Success`,
  final sugar `29.7521 g/L`, numerically healthy but not dry.
- `ramp20_to25__none`: completed `336 h`, `retcode=Success`,
  final sugar `26.7061 g/L`, numerically healthy but not dry.
- `ramp20_to25__fda_split_1p0_1p0_mid`: hit
  `DFBA_DYNAMIC_CONTROL_OPT_MAX_RHS_CALLS=8000` near `162.87 h`.
- `flat22__fda_quarter_split_0p5`: hit
  `DFBA_DYNAMIC_CONTROL_OPT_MAX_RHS_CALLS=8000` near `87.87 h`.
- `flat22__fda_early_1p0`: completed `336 h`, `retcode=Success`,
  final sugar `19.8442 g/L`, numerically healthy but not dry.
- `flat22__fda_three_pulse_0p75`: hit
  `DFBA_DYNAMIC_CONTROL_OPT_MAX_RHS_CALLS=8000` near `88.51 h`.

Interpretation: the extended sequential simulator can traverse `336 h` from
conservative controls, so the earlier stalls are not merely a horizon-length
failure. However, the model kinetics still do not reach the `G+F <= 5 g/L`
dryness gate by `336 h` without a more effective control/parameter change. The
first extended MPCC should therefore be framed as a development/productivity
pilot from a completed sequential start, not as a strict near-dry promotion.
`flat22__fda_early_1p0` is currently the best nutrient-assisted development
candidate by final sugar, while `ramp20_to25__none` is the cleanest
temperature-only baseline. The nutrient-control branch should be diagnosed
carefully because split or multipulse FDA additions are currently pushing the
sequential RHS/LP into very stiff or infeasible regions.

## 2026-06-21 h336 development MPCC pre-solve

Prepared a development policy selection from the soft h336 atlas:

- selection CSV:
  `/home/cltorrealba/mpcc_runs/dynamic_control_sequential_extended_atlas_h336_fda_soft_frontier_v2_10c_guard8k_8m_nocache_20260621_043210/selection_development_h336/dynamic_control_policy_selection.csv`
- selected candidates:
  `flat22__fda_early_1p0`, `ramp20_to25__none`
- selection mode: `--development-ready-ignore-gates`

Added variant:

- `extended_h336_development_gate20_productivity_nfe168_iter0`
- fixed-control/locked diagnostic, `max_iter=0`
- h336, nfe168, operational terminal sugar gate `20 g/L`

Submitted the first MPCC pre-solve smoke:

- job: `747090`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_extended_h336_development_gate20_productivity_nfe168_iter0_20260621_052341`
- candidate: `flat22__fda_early_1p0`
- case id: `extended_h336_development_gate20_flat22_fda1_nfe168_presolve_locked`
- mode: `pre_solve_only=1`, `dynamic_control_liberation_mode=locked`
- resources: 8 CPUs, 48 GB, no GPU, `OPENBLAS_NUM_THREADS=1`
- Julia flags: `MPCC_JULIA_COMPILED_MODULES=no`,
  `MPCC_JULIA_PKGIMAGES=no`, `JULIA_PKG_PRECOMPILE_AUTO=0`

Early monitoring:

- header confirmed HSL path
  `/home/cltorrealba/opt/hsl/libhsl-2025.7.21/lib/libhsl.so`
- internal sequential simulation completed before MPCC construction
- by about 30 minutes walltime, the job was still inside
  `before_mpcc_solve_attempt`, with CPU active and about `4.7 GB` RSS, so it
  was not canceled.

Early FDA-only monitoring showed the `flat25` high-FDA candidates were too
aggressive: `flat25__fda_early_3p0_limit` failed with FBA infeasibility, and
`flat25__fda_early_2p5_late0p5` hit the per-candidate walltime guard near
`246.8 h`. To avoid spending the whole atlas on hot extremes, a new candidate
set `extended_horizon_fda_soft_frontier` was added. It prioritizes moderate
temperatures and split FDA dosing:

- examples: `flat22__fda_split_1p0_1p0_mid`,
  `ramp22_to25__fda_split_1p0_1p0_mid`,
  `flat24__fda_three_pulse_0p75`,
  `warm25_until168_cool22__fda_quarter_split_0p5`
- job: `746993`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_sequential_extended_atlas_h336_fda_soft_frontier_9c_guard8k_8m_nocache_20260621_042247`
- candidate set: `extended_horizon_fda_soft_frontier`
- max candidates: `9`
- per-candidate guards: `DFBA_DYNAMIC_CONTROL_OPT_MAX_RHS_CALLS=8000`,
  `DFBA_DYNAMIC_CONTROL_OPT_MAX_WALLTIME_SECONDS=480`
- Julia flags: `MPCC_JULIA_COMPILED_MODULES=no`,
  `MPCC_JULIA_PKGIMAGES=no`, `JULIA_PKG_PRECOMPILE_AUTO=0`

Monitoring then showed the first soft candidate,
`flat22__fda_split_1p0_1p0_mid`, also slowed near `162 h`. This indicated the
soft set was valid but still ordered too aggressively for finding a complete
baseline quickly. Jobs `746958` and `746993` were canceled after collecting
that diagnostic signal. The soft set order was changed to begin with
`flat22__none` and `ramp20_to25__none`, then move into low/split FDA.

The valid soft v2 run is:

- job: `747009`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_sequential_extended_atlas_h336_fda_soft_frontier_v2_10c_guard8k_8m_nocache_20260621_043210`
- candidate set: `extended_horizon_fda_soft_frontier`
- first candidates: `flat22__none`, `ramp20_to25__none`,
  `ramp20_to25__fda_split_1p0_1p0_mid`,
  `flat22__fda_quarter_split_0p5`
- per-candidate guards: `DFBA_DYNAMIC_CONTROL_OPT_MAX_RHS_CALLS=8000`,
  `DFBA_DYNAMIC_CONTROL_OPT_MAX_WALLTIME_SECONDS=480`
- Julia flags: `MPCC_JULIA_COMPILED_MODULES=no`,
  `MPCC_JULIA_PKGIMAGES=no`, `JULIA_PKG_PRECOMPILE_AUTO=0`

Completed h336 MPCC pre-solve result for job `747090`:

- solver call: not performed (`pre_solve_only=1`, `solver_status=OPTIMIZE_NOT_CALLED`)
- selected candidate source: `pre_solve_start_values`
- selected candidate residual-feasible: `true`
- selected candidate trajectory-ready: `false`
- solve horizon: `336 h`, `nfe=168`, degree `3`, uniform `2 h` elements
- dynamic controls: locked, `control_free_variable_count=0`
- sequential replay inside the MPCC job completed with `retcode=Success`
- dominant MPCC start defect:
  - `max_collocation_integration_residual=0.22268793965753275`
  - `max_continuity_residual=0.22268793965753275`
  - top location: glucose, element `32`, collocation `3`, `t=64 h`
- complementarity remained secondary:
  `max_lower_complementarity_residual=0.0023421387114437135`
- schedule check: flat `22 C`, smooth early FDA pulse reaching `1 g/L`

The important mismatch is scientific/numerical, not a failed control import:
the sequential atlas reports `G+F=19.8442334219 g/L` at `336 h` for
`flat22__fda_early_1p0`, while the selected MPCC pre-solve start reports
`G+F=115.49396287 g/L`. The generated comparison report is:

- `repro/generated/dynamic_control_atlas_mpcc_start_quality_h336_20260621/atlas_mpcc_start_quality.md`
- `repro/generated/dynamic_control_atlas_mpcc_start_quality_h336_20260621/atlas_mpcc_start_quality.csv`

Interpretation: do not call Ipopt on h336 yet. The start is residual-feasible
by the relaxed gate but is not a valid trajectory handoff. The next useful
test is a horizon ladder with the same `2 h` element length to identify whether
the defect is caused by early collocation/replay or by the long h336 tail.

Submitted horizon-ladder pre-solves:

- job `747176`: h168/nfe84, same h336 policy truncated/replayed through the
  fixed-control MPCC path, locked controls, pre-solve only.
- job `747177`: h240/nfe120, same settings.

Reading rule:

- If h168 already shows the glucose defect around `56-64 h`, focus on the
  sequential-to-collocation replay/repair map and mesh/interpolation details.
- If h168 is sane and h240/h336 degrade, focus on horizon extension, tail
  repair, and state-specific residual guards.
- Do not liberate controls or attempt a post-solve promotion from this h336
  branch until fixed-control replay gives a trajectory-ready or much lower
  collocation/continuity defect.

Results for jobs `747176` and `747177`:

- both completed without calling Ipopt (`solver_status=OPTIMIZE_NOT_CALLED`)
- both selected `pre_solve_start_values`
- both were worse than h336 in fixed-control replay:
  - h168/nfe84: `selected_candidate_residual_feasible=false`,
    `G+F=150.051196026 g/L`,
    `max_collocation_integration_residual=0.441318249151`
  - h240/nfe120: `selected_candidate_residual_feasible=false`,
    `G+F=134.410304974 g/L`,
    `max_collocation_integration_residual=0.441318249151`
- both share the same top residual:
  `glucose`, element `21`, collocation `3`, `t=42 h`
- both also show large non-collocation damage:
  `max_mass_balance_residual=0.167422164538` and
  `max_lower_bound_violation=0.0328443017294`
- combined comparison report:
  `repro/generated/dynamic_control_atlas_mpcc_start_quality_h168_h240_h336_20260621/atlas_mpcc_start_quality.md`

These two jobs used `solve_horizon_h` shorter than h336 but kept
`schedule_horizon_h=336`, so they are useful as failure evidence but not yet a
clean horizon-ladder comparison. Because the hotspot is already inside `48 h`,
the cleaner next diagnostic is a much smaller matched-horizon run:

- job `747223`
- h48/nfe24, `schedule_horizon_h=48`, same `2 h` element length
- same candidate `flat22__fda_early_1p0`
- locked controls, pre-solve only, no Ipopt call
- 4 CPUs, 16 GB, node `n8`

If h48 reproduces the `t=42 h` glucose/fructose defect, the blocker is the
early sequential-to-collocation replay/repair map, not long-horizon extension.

Result for job `747223`:

- h48/nfe24 with matched `schedule_horizon_h=48`
- solver call: not performed
- selected candidate source: `pre_solve_start_values`
- selected candidate residual-feasible: `true`
- selected candidate trajectory-ready: `false`
- terminal sugar at 48 h: `G+F=201.167449141 g/L`
- top residual: `protein`, element `12`, collocation `3`, `t=24 h`,
  residual `0.00465404408221`
- the previous `glucose/fructose` defect at `t=42 h` did not reproduce

Interpretation: the h168/h240 `t=42 h` glucose defect was caused by the
short-solve/long-schedule mismatch, not by an intrinsic early replay failure.
The next clean ladder is matched schedule at h96 and h168:

- job `747234`: h96/nfe48, `schedule_horizon_h=96`, pre-solve only
- job `747235`: h168/nfe84, `schedule_horizon_h=168`, pre-solve only

If these matched runs stay residual-feasible, the next branch should work on
the `protein` trajectory-ready defect rather than glucose replay. If h168
degrades while h96 is sane, horizon extension remains the limiter.

Results:

- job `747234`, h96/nfe48:
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - terminal sugar `G+F=177.057981925 g/L`
  - top residual: glucose, element `47`, collocation `3`, `t=94 h`,
    `0.140208486691`
- job `747235`, h168/nfe84:
  - `selected_candidate_residual_feasible=false`
  - `selected_candidate_trajectory_ready=false`
  - terminal sugar `G+F=150.051196026 g/L`
  - top residual: glucose, element `21`, collocation `3`, `t=42 h`,
    `0.441318249151`

Interpretation: h48 is residual-feasible with a protein defect, h96 is still
residual-feasible but accumulates a tail glucose/fructose defect, and h168
crosses into a non-residual-feasible basin with the large glucose defect
appearing early at `42 h`. The next diagnostic pair narrows the threshold:

- job `747238`: h120/nfe60, matched schedule, pre-solve only
- job `747239`: h144/nfe72, matched schedule, pre-solve only

Combined report after h96/h168:
`repro/generated/dynamic_control_atlas_mpcc_start_quality_matched_ladder_20260621/atlas_mpcc_start_quality.md`

Results for the h120/h144 matched ladder:

- job `747238`, h120/nfe60, node `n8`, elapsed `00:37:14`,
  MaxRSS `2458944K`
  - `solver_status=OPTIMIZE_NOT_CALLED`, `pre_solve_only=1`
  - `selected_candidate_source=pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - terminal sugar `G+F=156.507025982 g/L`
  - top residual: fructose, element `60`, collocation `3`, `t=120 h`,
    `0.234931110669`
- job `747239`, h144/nfe72, node `n14`, elapsed `00:23:42`,
  MaxRSS `2969980K`
  - `solver_status=OPTIMIZE_NOT_CALLED`, `pre_solve_only=1`
  - `selected_candidate_source=pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - terminal sugar `G+F=167.918791757 g/L`
  - top residual: glucose, element `72`, collocation `3`, `t=144 h`,
    `0.117786083727`

Generated comparison report:

- `repro/generated/dynamic_control_atlas_mpcc_start_quality_matched_ladder_h48_h168_20260621/atlas_mpcc_start_quality.md`
- `repro/generated/dynamic_control_atlas_mpcc_start_quality_matched_ladder_h48_h168_20260621/atlas_mpcc_start_quality.csv`

Repair-substep analysis:

- h120:
  `repro/generated/dynamic_control_repair_substep_analysis_h120_20260621/h120_matched.txt`
  - `substep_row_count=112`
  - `trial_count=7`
  - dominant category: `state_refresh`
  - recommendation: damp or segment terminal state refresh before adding more
    mesh or objective pressure
- h144:
  `repro/generated/dynamic_control_repair_substep_analysis_h144_20260621/h144_matched.txt`
  - `substep_row_count=208`
  - `trial_count=13`
  - dominant category: `state_after_rhs_refresh`
  - recommendation: guard or disable terminal state-after-RHS refresh and
    prioritize derivative-consistent terminal states

Matched-ladder interpretation:

- h48, h96, h120, and h144 are residual-feasible but not
  trajectory-ready.
- h168 is the first matched-schedule rung that becomes non-residual-feasible.
- The dominant defect is still collocation/continuity, not Ipopt, HSL, or a
  failed control import.
- The defect migrates with horizon/tail:
  - h48: protein at `24 h`, `0.00465404408221`
  - h96: glucose at `94 h`, `0.140208486691`
  - h120: fructose at `120 h`, `0.234931110669`
  - h144: glucose at `144 h`, `0.117786083727`
  - h168: glucose at `42 h`, `0.441318249151`
- The substep traces show the same mechanism repeatedly: state refresh can
  reduce RHS, flux projection restores dynamic bounds, then RHS derivative
  refresh reintroduces continuity/collocation damage; state-after-RHS guard
  often rejects the attractive residual-only move because it worsens other
  structural scores.

Next technical step:

- Do not liberate controls or call Ipopt on h168/h336 yet.
- Submit targeted fixed-control repair jobs first:
  - h144/h168 with `TRACE_SUBSTEPS=0` for speed
  - segment/post-tail repair around the failing tail or transition window
  - compare final-state-after-RHS disabled vs guarded, and only then decide
    whether to increase mesh density or attempt a short Ipopt feasibility
    polish.
- Treat h144 as the current upper residual-feasible development rung, but not
  as a promotable seed because `selected_candidate_trajectory_ready=false`.

## 2026-06-21 targeted repair follow-up

The first h144/h168 follow-up submissions, jobs `747240` and `747241`, were
canceled early after the logs showed a configuration mismatch:
`stationarity_dual_start_lp_fail_fast=true`. No result from those jobs should
be used as evidence.

Clean h144 retest:

- job `747242`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_extended_h144_matched_schedule_gate20_productivity_nfe72_iter0_finalrhs0_20260621_084154`
- settings: h144/nfe72, locked controls, pre-solve only, no Ipopt call,
  `collocation_repair_final_state_after_rhs=0`
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - `selected_candidate_source=pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - terminal sugar `G+F=167.918791757 g/L`
  - top residual: glucose, element `72`, collocation `3`, `t=144 h`,
    `0.117786083727`

Interpretation: disabling the terminal state-after-RHS refresh alone does not
improve h144; it reproduces the same dominant residual as the matched h144
baseline. The new substep analysis is:

- `repro/generated/dynamic_control_repair_substep_analysis_h144_finalrhs0_20260621/h144_finalrhs0.txt`
  - `substep_row_count=104`
  - `trial_count=13`
  - dominant category: `rhs_derivative_refresh`
  - recommendation: target terminal RHS derivative consistency before freeing
    controls

Default tau correction:

- The fixed-control entrypoint, UC sbatch, and objective-leverage submit wrapper
  now default `MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU` to `1.0e-3`.
- Older runs in this section logged `complementarity_tau=20.0` unless the
  value was explicitly exported. Their dominant defect is collocation/
  continuity, so they remain useful for localization, but future comparable
  jobs must either rely on the corrected default or set `MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU=1.0e-3`
  explicitly.

Clean h168 nfe168 post-tail retest:

- job `747243`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_extended_h168_matched_schedule_gate20_productivity_nfe168_iter0_posttail96_168_20260621_084154`
- settings: h168/nfe168, locked controls, pre-solve only, no Ipopt call,
  post-tail repair on elements `96:168`
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - `selected_candidate_source=pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - terminal sugar `G+F=93.2491986233 g/L`
  - top residual: glucose, element `84`, collocation `3`, `t=84 h`,
    `0.0284514446582`
  - MaxRSS `4944228K`, elapsed `00:53:09` on node `n14`

This is the best h168 fixed-control replay so far: the previous h168/nfe84
matched run was non-residual-feasible with top collocation residual
`0.441318249151` at `t=42 h`. Refining to 1 h elements plus post-tail repair
recovered residual-feasible status and moved the remaining defect to a much
smaller mid-horizon glucose continuity/collocation residual. It is still not a
promotable seed because `selected_candidate_trajectory_ready=false`.

Generated follow-up reports:

- `repro/generated/dynamic_control_repair_followup_h144_h168_20260621/atlas_mpcc_start_quality.md`
- `repro/generated/dynamic_control_repair_followup_h144_h168_20260621/atlas_mpcc_start_quality.csv`
- `repro/generated/dynamic_control_repair_followup_h144_h168_tau_confirm_20260621/atlas_mpcc_start_quality.md`
- `repro/generated/dynamic_control_repair_followup_h144_h168_tau_confirm_20260621/atlas_mpcc_start_quality.csv`
- `repro/generated/dynamic_control_repair_substep_analysis_h168_nfe168_posttail_20260621/h168_nfe168_posttail.txt`

The h168 substep trace has `288` rows and `18` trials. It still classifies the
dominant diagnostic category as `rhs_derivative_refresh`, but the largest
trial-level jumps are tied to `dynamic_flux_lp`/flux-bound projection. The
post-tail trials cannot improve beyond `0.0284514446582`; the guard restores the
same candidate after damped state-after-RHS attempts. The next repair step
should therefore target segmented consistency between state updates, RHS
derivatives, and dynamic flux-bound projection, not simply disable one terminal
refresh.

Tau-correct h168 confirmation:

- job `747245`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_extended_h168_matched_schedule_gate20_productivity_nfe168_iter0_posttail96_168_tau1em3_20260621_094104`
- settings: same h168/nfe168 post-tail `96:168` replay, but with
  `MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU=1.0e-3` explicitly set and phase
  tracing enabled
- result reproduced job `747243` exactly:
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - terminal sugar `G+F=93.2491986233 g/L`
  - top residual: glucose, element `84`, collocation `3`, `t=84 h`,
    `0.0284514446582`
  - MaxRSS `6513344K`, elapsed `00:51:53` on node `n14`

Timing breakdown:

- KKT row construction: `30.196 s`
- dynamic-flux LP starts: `23.273 s`
- stationarity dual starts: `33.654 s`
- collocation-consistent state starts: `2523.059 s`
- pre-solve-only result assembly/candidate extraction: `45.450 s`

Conclusion: the h168 residual-feasible recovery is not an artifact of the old
`tau=20.0` default. The operational bottleneck is now unambiguously
`collocation_consistent_state_starts`.

Canceled focal h168 post-tail `72:96` diagnostic:

- job `747246`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_extended_h168_matched_schedule_gate20_productivity_nfe168_iter0_posttail72_96_tau1em3_20260621_095731`
- intent: test whether post-tail repair directly over the observed h168
  hotspot window around element `84` improves on the validated `96:168`
  post-tail result
- cancellation: `scancel` at `02:00:24` wall on node `n8`
- reason: no final pre-solve markers after two hours, MaxRSS about `5.24 GB`;
  the job remained active but the marginal signal/cost was poor for a
  secondary variant on the slower node

No numerical conclusion should be drawn from job `747246`. The hypothesis
remains open, but future tests of a focal `72:96` repair should run on a faster
node or after implementing a cheaper segmented repair path.

Trace h96 tau1e-3 diagnostic:

- job `747244`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_h96_trace_tau1em3_locked_presolve_20260621_091716`
- settings: h96/nfe48, locked controls, pre-solve only, no Ipopt call,
  `MPCC_REDUCED_MPCC_SOLVE_ATTEMPT_TRACE_PHASES=1`,
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TRACE_SUBSTEPS=1`,
  `MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU=1.0e-3`
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - terminal sugar `G+F=177.057981925 g/L`
  - top residual: glucose, element `47`, collocation `3`, `t=94 h`,
    `0.140208486691`
  - MaxRSS `2334636K`, elapsed `00:33:33` on node `n8`

Timing breakdown from the h96 trace:

- collocation NLP build: `6.583 s`
- KKT row construction: `23.818 s`
- dynamic-flux LP starts: `18.005 s`
- stationarity dual starts: `30.553 s`
- RHS derivative starts: `10.263 s`
- collocation-consistent state starts: `786.943 s`
- pre-solve-only result assembly/candidate extraction: `94.760 s`

Thus, the main runtime bottleneck after package loading is
`collocation_consistent_state_starts`, not Ipopt. The h96 substep analysis is:

- `repro/generated/dynamic_control_repair_substep_analysis_h96_trace_tau1em3_20260621/h96_trace_tau1em3.txt`
  - `substep_row_count=112`
  - `trial_count=7`
  - dominant category: `state_refresh`
  - recommendation: damp or segment terminal state refresh before adding more
    mesh or objective pressure

## Segmented Collocation Repair Hook - 2026-06-21

Implemented an optional segmented repair pass inside
`_reduced_dcdfba_apply_collocation_consistent_state_starts!`. This is designed
to test the current leading hypothesis: fixed-control replay is not mainly
blocked by Ipopt, but by local inconsistency among state refresh, RHS derivative
refresh, and dynamic flux-bound projection over specific horizon regions.

New controls:

- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_ENABLED`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS`
  - format: semicolon-delimited contiguous ranges, e.g. `72:96;96:120`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_ACCEPT_TOL`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_GUARD_ACCEPT_TOL`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_DAMPING_FACTORS`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_REFRESH_DYNAMIC_FLUX`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_GUARD_SCORE`

The fixed-control entrypoint forwards these aliases to the existing
`MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_*` namespace. Both
`repro/cluster_uc_dynamic_control_liberated_mpcc_pilot.sbatch` and
`repro/submit_cluster_uc_dynamic_control_objective_leverage.sh` now print and
propagate the segment settings.

Validation submitted:

- job `747255`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_segment_repair_smoke_h48_20260621_120713`
- settings: h48/nfe48, locked controls, pre-solve only, no Ipopt call,
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=2`,
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS=24:36;36:48`,
  trace substeps enabled, `MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU=1.0e-3`
- purpose: runtime smoke for the new segmented repair metadata and acceptance
  path before h96/h144/h168 escalation

Promotion status: completed as a runtime validation only. Follow-up h48
smokes showed that segment-local refresh with dynamic-flux refresh enabled was
too aggressive: all segment trials were rejected and the selected candidate
remained residual-feasible but not trajectory-ready, with top residual
`0.007518996943929324` at glucose element `28`.

## Fixed-Control Feasibility Projection - 2026-06-21

Implemented a separate opt-in feasibility projection pass after the global
monotone repair and before segmented repair. This pass is meant to preserve
the useful local state/RHS consistency update without forcing a full dynamic
flux refresh or final state refresh that can undo the improvement.

New controls:

- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_ENABLED`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_SEGMENTS`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_ACCEPT_TOL`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_GUARD_ACCEPT_TOL`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_DAMPING_FACTORS`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_REFRESH_DYNAMIC_FLUX`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_STATE_REFRESH`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_FLUX_PROJECTION`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_STATE_AFTER_RHS`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_STATE_AFTER_RHS_REFRESH_RHS`
- `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_GUARD_SCORE`

h48 smoke with final refresh enabled:

- job `747259`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_feasibility_projection_smoke_h48_20260621_132602`
- settings: h48/nfe48, locked controls, pre-solve only,
  `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_SEGMENTS=24:36;36:48`,
  `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_REFRESH_DYNAMIC_FLUX=0`,
  final state refresh/projection enabled
- result: residual-feasible, not trajectory-ready, but no final improvement
  because the final state refresh raised the segment `24:36` trial residual to
  about `0.031`. Substep traces showed an intermediate improvement to
  `0.006762558252162876` after RHS derivative refresh, but the final refresh
  erased it.

h48 smoke with final refresh disabled:

- job `747262`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_feasibility_projection_no_final_refresh_smoke_h48_20260621_140314`
- resources: `full`, node `n8`, `8` CPUs, MaxRSS `2230388K`, elapsed
  `00:29:46`
- settings: h48/nfe48, locked controls, pre-solve only, no Ipopt call,
  `MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU=1.0e-3`,
  `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_SEGMENTS=24:36;36:48`,
  `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_REFRESH_DYNAMIC_FLUX=0`,
  `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_STATE_REFRESH=0`,
  `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_FLUX_PROJECTION=0`,
  `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_STATE_AFTER_RHS=0`,
  `MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_GUARD_SCORE=primal_structural`
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - selected candidate: `pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - feasibility projection accepted `1` of `10` trials
  - final max residual improved from `0.007518996943929324` to
    `0.006762558252162876`
  - accepted trial: segment `24:36`, damping `0.1`
  - dominant residual remains glucose collocation/continuity at element `28`,
    `t=28 h`

Conclusion: the useful fixed-control projection is not a full local state
refresh. It is a damped state update plus frozen-flux mass-balanced projection
plus RHS derivative refresh, guarded by `primal_structural`, with final refresh
disabled. This is the current method to escalate to h96 and h168 before adding
homotopy.

h96/nfe48 escalation with final refresh disabled:

- job `747264`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_feasibility_projection_no_final_refresh_h96_nfe48_20260621_143656`
- resources: `full`, node `n8`, `8` CPUs, MaxRSS `2216804K`, elapsed
  `00:27:21`
- settings: h96/nfe48, locked controls, pre-solve only, no Ipopt call,
  same feasibility projection policy as h48, segments `24:36;36:48`
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - selected candidate: `pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - feasibility projection accepted `1` of `7` trials
  - final max residual improved from `0.0948996870425276` to
    `0.017019853879644165`
  - accepted trial: segment `36:48`, damping `1.0`
  - dominant residual shifted to terminal `protein` collocation/continuity at
    element `48`, `t=96 h`
  - terminal sugar `G+F=189.6765396259376 g/L`

Compared with the prior h96/nfe48 trace residual of about `0.140208486691`,
this is a substantial fixed-control initialization improvement, but still not
trajectory-ready. The remaining failure mode is now concentrated at terminal
`protein`, which is consistent with the earlier h120/h168 ladder bottleneck.

h168/nfe168 escalation with final refresh disabled:

- job `747266`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_feasibility_projection_no_final_refresh_h168_nfe168_20260621_151204`
- resources: `full`, node `n8`, `8` CPUs, MaxRSS `5164948K`, elapsed
  `00:59:35`
- settings: h168/nfe168, locked controls, pre-solve only, no Ipopt call,
  same frozen-flux feasibility projection policy as h48/h96, segments
  `72:96;96:120;120:144;144:168`
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - selected candidate: `pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - feasibility projection accepted `1` of `19` trials
  - final max residual improved from `0.07046051063313996` to
    `0.06045557511319544`
  - accepted trial: segment `144:168`, damping `1.0`
  - rejected segments `72:96`, `96:120`, and `120:144` because every
    nontrivial damping factor worsened the guarded residual
  - dominant residual shifted to glucose collocation/continuity at element
    `143`, `t=143 h`
  - terminal sugar `G+F=93.1115379870957 g/L`

This confirms that the feasibility projection generalizes to h168 and remains
residual-feasible, but it does not yet beat the earlier h168/nfe168 post-tail
`96:168` replay from job `747243`, which reached max residual
`0.0284514446582`. The current methodological conclusion is therefore:
use feasibility projection as a guarded, local fixed-control projection tool,
not as a whole-horizon sweep. The next h168 follow-up should focus directly on
the active tail window and/or combine the now-stable feasibility projection
with the previously stronger post-tail recipe.

h168/nfe168 focal feasibility projection plus post-tail, low main-iteration
diagnostic:

- job `747270`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_feasibility_projection_tail_plus_posttail_h168_nfe168_20260621_161433`
- resources: `full`, node `n8`, `8` CPUs, MaxRSS `5560800K`, elapsed
  `00:51:18`
- settings: h168/nfe168, locked controls, pre-solve only, no Ipopt call,
  main collocation repair capped at `2` iterations, feasibility projection
  segment `144:168` with frozen-flux/final-refresh-disabled policy, followed
  by post-tail repair on elements `96:168`
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - selected candidate: `pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - main repair: `0.6194530609677997 -> 0.1215335221257341 -> 0.07046051063313996`
  - feasibility projection accepted segment `144:168`, damping `1.0`,
    improving `0.07046051063313996 -> 0.06045557511319544`
  - post-tail repair accepted damping `0.5`, improving
    `0.06045557511319544 -> 0.0415279842016929`
  - dominant residual: glucose collocation/continuity at element `95`,
    `t=95 h`
  - terminal sugar `G+F=91.61496701707922 g/L`

Interpretation: this run improves over the h168 feasibility-projection-only
result from job `747266` (`0.06045557511319544 -> 0.0415279842016929`), but
does not beat the clean post-tail replay `747243`/`747245`
(`0.0284514446582`). The important diagnosis is that `747243` reached its best
residual during the main collocation repair at iterations `3-4`, before
post-tail. Therefore the next h168 hybrid must not cap
`MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER` at `2`; it should reproduce
the full main-repair budget and then apply the guarded focal feasibility and
post-tail steps.

h168/nfe168 full-main hybrid cancellation:

- job `747273`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_feasibility_projection_tail_plus_posttail_h168_nfe168_iter8_20260621_170926`
- settings: h168/nfe168, locked controls, pre-solve only, full main repair
  budget `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=8`, focal feasibility
  projection `144:168`, then post-tail `96:168`
- result: cancelled manually after `01:29:37`, MaxRSS `4843708K`, node `n8`
- last log phase:
  `smoke_problem_before_collocation_consistent_state_starts`

Interpretation: composing the full main repair, focal feasibility projection,
and post-tail in one fresh sequential-start run is not an efficient diagnostic.
It can spend longer than the previous complete h168 best run before reaching the
new phases. The method should instead reuse serialized residual-feasible
candidate diagnostics when testing local projection/polish behavior.

Candidate-seed feasibility projection infrastructure:

- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=0` is now accepted as an
  explicit diagnostics mode: build the problem, evaluate starts, but skip main
  fixed-point repair iterations.
- `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START_MAX_ITER=0` is also accepted,
  so a serialized same-grid candidate can be loaded first and then tested with
  focal feasibility projection without replaying the full main repair path.

h168/nfe168 candidate-seed focal projection over inactive tail:

- job `747276`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_h168_nfe168_from747243_20260621_184334`
- resources: `full`, node `n8`, `8` CPUs, MaxRSS `6897148K`, elapsed
  `00:37:56`
- seed:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_extended_h168_matched_schedule_gate20_productivity_nfe168_iter0_posttail96_168_20260621_084154/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- settings: h168/nfe168, locked controls, pre-solve only, no Ipopt call,
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=0`,
  `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START=1`,
  `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START_MAX_ITER=0`,
  focal feasibility projection `144:168`, frozen flux/final-refresh-disabled
  policy
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - selected candidate: `pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - full candidate seed loaded and dynamic controls applied with zero bound
    adjustment
  - feasibility projection trials over `144:168`: `6`, accepted `0`
  - max residual preserved at `0.028451444658244895`
  - terminal sugar `G+F=93.24919862334704 g/L`
  - dominant residual remains glucose collocation/continuity at element `84`,
    `t=84 h`

Interpretation: the candidate-seed route is valid and preserves the previous
best h168 fixed-control candidate. The `144:168` projection is harmless but
inactive for this seed because the dominant defect is not in the tail; the next
candidate-seed feasibility projection should target the active band around
`72:96`.

h168/nfe168 candidate-seed focal projection over active glucose band:

- job `747277`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_h168_nfe168_from747243_active72_96_20260621_192342`
- resources: `full`, node `n8`, `8` CPUs, MaxRSS `5674484K`, elapsed
  `00:36:56`
- seed: same serialized candidate from job `747243`
- settings: same candidate-seed pre-solve-only policy as job `747276`, but
  focal feasibility projection `72:96`
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - selected candidate: `pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - feasibility projection trials over `72:96`: `6`, accepted `1`
  - damping `0.01` accepted after larger dampings worsened the guarded residual
  - max residual improved from `0.028451444658244895` to
    `0.028052539698009582`
  - terminal sugar unchanged: `G+F=93.24919862334704 g/L`
  - dominant residual remains glucose collocation/continuity at element `84`,
    `t=84 h`, but reduced consistently

Interpretation: fixed-control feasibility projection is useful when aimed at
the active defect band. The effect is small but real and guarded. The next
diagnostic should start from the improved `747277` candidate and repeat the
active `72:96` projection with finer damping to determine whether the residual
continues to descend or quickly saturates.

h168/nfe168 candidate-seed active-band projection, iteration 2:

- job `747280`
- run root:
  `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_h168_nfe168_from747277_active72_96_iter2_20260621_200130`
- resources: `full`, node `n8`, `8` CPUs, MaxRSS `5512408K`, elapsed
  `00:33:01`
- seed: selected candidate diagnostics from job `747277`
- settings: same pre-solve-only candidate-seed policy, focal feasibility
  projection `72:96`, damping factors
  `0.05,0.025,0.01,0.005,0.0025,0.001`
- result:
  - `solver_status=OPTIMIZE_NOT_CALLED`
  - selected candidate: `pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - damping `0.01` accepted; `0.05` and `0.025` worsened/rejected
  - max residual improved from `0.028052539698009582` to
    `0.027658767127647366`
  - terminal sugar unchanged: `G+F=93.24919862334704 g/L`
  - dominant residual remains glucose collocation/continuity at element `84`,
    `t=84 h`; element `97` is now the second-largest glucose defect

Interpretation: repeated active-band feasibility projection continues to lower
the h168 fixed-control residual while preserving residual feasibility, but the
rate is slow. The next engineering improvement is to avoid rebuilding default
sequential starts before applying a complete same-grid candidate seed.

Candidate-seed speedup:

- added opt-in `MPCC_FIXED_CONTROL_APPLY_DEFAULT_START_INITIALIZERS=0`
- safety rule: this mode requires
  `MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS`, because flux-only seeds
  do not provide complete state/derivative/flux/dual starts
- purpose: skip default dynamic-flux, stationarity-dual, RHS-derivative, and
  pre-seed collocation repair work when a complete serialized same-grid
  candidate will overwrite those starts before diagnostics

h168/nfe168 candidate-seed projection speedup and active-band continuation:

- summary CSV:
  `repro/generated/dynamic_control_candidate_seed_projection_summary_20260621.csv`
- job `747281`
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_h168_nfe168_from747280_active72_96_iter3_skipdefault_20260621_203954`
  - settings: seed from `747280`, projection `72:96`,
    `MPCC_FIXED_CONTROL_APPLY_DEFAULT_START_INITIALIZERS=0`, sequential replay
    still enabled
  - resources: `full`, node `n8`, `8` CPUs, MaxRSS `5457872K`, elapsed
    `00:29:23`
  - result: `selected_candidate_residual_feasible=true`,
    `selected_candidate_trajectory_ready=false`
  - max residual stayed at `0.027658767127647366`; projection trials
    `6`, accepted `0`
  - interpretation: same-window `72:96` was saturated after job `747280`.
    Even with `max_iter=0`, the after-candidate repair/projection path still
    spent several minutes evaluating diagnostics, so skipping default starts
    alone is not enough for fast candidate-seed iteration.

- candidate-seed-only infrastructure:
  - added opt-in
    `MPCC_FIXED_CONTROL_SKIP_SEQUENTIAL_SIMULATION_FOR_CANDIDATE_SEED=1`
  - guarded so it requires both
    `MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS` and
    `MPCC_FIXED_CONTROL_APPLY_DEFAULT_START_INITIALIZERS=0`
  - allows same-grid serialized candidate diagnostics to drive the pre-solve
    projection without replaying the sequential simulation

- job `747283`
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_h168_nfe168_from747281_active84_108_skipseq_20260621_211123`
  - settings: seed from `747281`, projection `84:108`, skip sequential replay
  - resources: `full`, node `n8`, `8` CPUs, MaxRSS `4777540K`, elapsed
    `00:18:18`
  - result: residual-feasible, not trajectory-ready
  - accepted damping `0.01`
  - max residual improved from `0.027658767127647366` to
    `0.02737697810387374`

- job `747284`
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_h168_nfe168_from747283_active82_98_skipseq_20260621_213346`
  - settings: seed from `747283`, projection `82:98`, skip sequential replay
  - resources: `full`, node `n8`, `8` CPUs, MaxRSS `5219680K`, elapsed
    `00:13:17`
  - result: residual-feasible, not trajectory-ready
  - accepted damping `0.01`
  - max residual improved from `0.02737697810387374` to
    `0.027077251339576947`

- job `747285`
  - run root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_h168_nfe168_from747284_active82_98_iter2_skipseq_20260621_215459`
  - settings: seed from `747284`, repeated projection `82:98`, skip
    sequential replay
  - resources: `full`, node `n8`, `8` CPUs, MaxRSS `5180684K`, elapsed
    `00:13:11`
  - result: residual-feasible, not trajectory-ready
  - accepted damping `0.01`
  - max residual improved from `0.027077251339576947` to
    `0.026780781412654164`

Interpretation: the fixed-control feasibility projection is now validated as a
guarded, monotone, same-grid candidate refinement loop. It preserves
`residual_feasible=true` and can continue lowering the active glucose
collocation/continuity defect around `83-97 h`, but the improvement rate is
slow and the candidate remains `trajectory_ready=false`. The next methodological
decision is whether to continue this local projection loop, broaden/adapt the
active band automatically, or move to a homotopy layer on top of the best
fixed-control projected seed.

h168/nfe168 automatic active-band candidate-seed projection:

- selector script:
  `scripts/main_select_dynamic_control_projection_bands.py`
- submit helper:
  `repro/submit_cluster_uc_dynamic_control_candidate_seed_projection.sh`
- summary CSV:
  `repro/generated/dynamic_control_candidate_seed_projection_active_band_summary_20260622.csv`
- starting seed:
  `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_h168_nfe168_from747284_active82_98_iter2_skipseq_20260621_215459/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- settings shared by accepted active-band runs:
  - h168/nfe168, locked controls, pre-solve only, no Ipopt optimize call
  - same-grid serialized candidate seed
  - `MPCC_FIXED_CONTROL_APPLY_DEFAULT_START_INITIALIZERS=0`
  - `MPCC_FIXED_CONTROL_SKIP_SEQUENTIAL_SIMULATION_FOR_CANDIDATE_SEED=1`
  - `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=0`
  - `MPCC_FIXED_CONTROL_REPAIR_AFTER_CANDIDATE_START_MAX_ITER=0`
  - feasibility projection enabled on one automatically selected band
  - damping grid `0.01,0.005,0.0025,0.001,0.0005,0.00025`
  - no final state refresh, no final flux projection, no final state-after-RHS
    refresh inside this projection diagnostic
  - Slurm on `full`, node `n8`, `8` CPUs, `24G`, `OPENBLAS_NUM_THREADS=1`

Run sequence:

| job | active band | elapsed | accepted damping | max residual after | residual feasible | trajectory ready |
| --- | --- | ---: | ---: | ---: | --- | --- |
| `747285` | `82:98` | `00:13:11` | `0.01` | `0.026780781412654164` | true | false |
| `747297` | `80:91` | `00:25:57` | `0.01` | `0.02646676077362997` | true | false |
| `747300` | `80:94` | `00:13:07` | `0.01` | `0.026156342469249694` | true | false |
| `747301` | `80:90` | `00:13:08` | `0.01` | `0.02603534737801283` | true | false |
| `747302` | `95:101` | `00:12:49` | `0.01` | `0.02584948585487723` | true | false |
| `747306` | `80:93` | `00:13:11` | `0.01` | `0.025746163038711245` | true | false |

Operational notes:

- Initial attempts to run several active bands in parallel caused heavy Julia
  loading/precompilation contention, especially on `n14`. Jobs `747287`,
  `747288`, `747289`, `747293`, `747294`, and `747295` were cancelled rather
  than allowing them to consume resources without useful progress.
- A single clean `n8` run triggered/finished the relevant Julia precompilation;
  subsequent serialized runs returned to the expected `~13 min` elapsed time.
- The active-band selector behaves as intended: it alternates between the
  glucose defect near elements `82-88` and the glucose defect near `97-99`,
  depending on the current dominant residual.

Interpretation: automatic active-band candidate-seed projection is now a
replicable fixed-control feasibility refinement stage. It is guarded,
monotone, and preserves `selected_candidate_residual_feasible=true`, improving
the best h168/nfe168 max collocation/continuity residual from
`0.026780781412654164` to `0.025746163038711245` after five serialized active
steps. However, it remains far from `trajectory_ready=true` and the improvement
rate is slow. This is sufficient to validate the projection stage as a stable
pre-homotopy smoother, but not sufficient as the final promotion mechanism.
Next methodological block: apply homotopy/regularization on top of this
fixed-control projected seed rather than continuing indefinite microprojection.

Fixed-control projection ladder audit, h48/h96/h168:

- generated audit script:
  `scripts/main_summarize_fixed_control_projection_ladder.py`
- generated audit artifacts:
  - `repro/generated/fixed_control_projection_ladder_audit_20260622.csv`
  - `repro/generated/fixed_control_projection_ladder_audit_20260622.md`
- scope: scanned existing `$HOME/mpcc_runs` artifacts for
  `reduced_mpcc_fixed_control_policy_solve_attempt.csv` at h48, h96, and h168
  and selected the best residual-feasible candidate plus the best
  trajectory-ready candidate, when present.

Current best residual-feasible fixed-control candidates:

| horizon | case | source | solver status | max residual | dominant metric | top state/time | trajectory ready |
| ---: | --- | --- | --- | ---: | --- | --- | --- |
| 48 h | `s18_gentle_warmtemp_h48_nfe48_tau1em3_iter25_reg0p05_repair2` | pre-solve | `ITERATION_LIMIT` | `1.125305531939201e-05` | lower complementarity | `protein` at 48 h | false |
| 96 h | `s33_funnel_warmtemp_h96_nfe96_tau1em3_iter12_reg0p02_repair2` | pre-solve | `OPTIMIZE_NOT_CALLED` | `3.173028233122001e-05` | lower complementarity | `protein` at 87 h | false |
| 168 h | `h168_serious_flat22none_fullmove_posttail74_84_iter13` | pre-solve | `ALMOST_LOCALLY_SOLVED` | `2.097674001313283e-05` | collocation/continuity | `protein` at 168 h | false |

Current trajectory-ready evidence:

- h48: no existing fixed-control artifact with
  `selected_candidate_trajectory_ready=true`.
- h96: no existing fixed-control artifact with
  `selected_candidate_trajectory_ready=true`.
- h168: best existing trajectory-ready fixed-control artifact is
  `h168_direct_fda_posttail74_84_iter40`, selected from post-solve values,
  `ALMOST_LOCALLY_SOLVED`, residual-feasible, with max residual
  `0.0004846478141325501`.

Interpretation:

- `trajectory_ready=false` for a pre-solve candidate is a status gate, not by
  itself evidence that the trajectory is unusable as a warm start. Pre-solve
  starts are explicitly marked `candidate_status_allows_trajectory_candidate=false`
  even when they are residual-feasible.
- The fixed-control projection layer has produced low-residual h48/h96/h168
  starts. The missing piece for h48/h96 is a post-solve status accepted by the
  trajectory gate.
- The next focal Slurm experiment is therefore not another broad projection
  pass, but a locked-control post-solve conversion attempt from the best h96
  residual-feasible seed.

h96 locked-control post-solve conversion attempt:

- job: `747310`
- root:
  `/home/cltorrealba/mpcc_runs/fixed_control_projection_h96_s33_locked_postsolve_20260622_002541`
- seed:
  `/home/cltorrealba/mpcc_runs/dynamic_control_staged_multistart_s33_funnel_warmtemp_h96_nfe96_tau1em3_iter12_reg0p02_repair2_20260621_005036/case/reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls`
- settings:
  - h96/nfe96, schedule h96
  - locked controls, objective off, base objective zero
  - candidate diagnostics start loaded
  - `MPCC_FIXED_CONTROL_APPLY_DEFAULT_START_INITIALIZERS=0`
  - `MPCC_FIXED_CONTROL_SKIP_SEQUENTIAL_SIMULATION_FOR_CANDIDATE_SEED=1`
  - `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=0`
  - no final state refresh, no final flux projection, no final state-after-RHS
  - `max_iter=40`, `feasibility_handoff`, MA86, limited-memory Hessian
  - Slurm `full`, node `n8`, `8` CPUs, `OPENBLAS_NUM_THREADS=1`
- purpose: test whether an already residual-feasible fixed-control h96 start can
  be converted into a post-solve residual-feasible/trajectory-ready candidate
  without allowing the solve to improve only through broad repair heuristics.

Result: this first attempt failed before Ipopt because it intentionally locked
controls to the flat22 baseline, while the h96 s33 seed carries a warm
temperature profile. The candidate start had `temperature_C[1]=23.0`, outside
the target locked-control bound `[22.0, 22.0]`. This is a configuration
diagnostic, not a numerical failure of the seed.

h96 explicit-control post-solve conversion attempt:

- job: `747311`
- root:
  `/home/cltorrealba/mpcc_runs/fixed_control_projection_h96_s33_explicit_postsolve_20260622_004140`
- correction relative to `747310`:
  - `MPCC_DYNAMIC_CONTROL_LIBERATION_MODE=explicit`
  - temperature indices `1,3,5,7`
  - temperature offsets `1=1.0,3=1.0,5=0.5,7=0.25`
  - addition indices `1,3,5,7`
  - dynamic flux LP fail-fast disabled and relaxed fallback enabled, matching
    the successful h96 seed lineage
  - Julia compiled modules/pkgimages enabled inside Slurm, reducing startup
    time to reach `before_mpcc_solve_attempt` from about 506 s to about 84 s
- Ipopt:
  - version 3.14.19, MA86, limited-memory Hessian
  - problem size: 1,609,193 variables, 752,083 equality constraints,
    1,714,176 inequality constraints
  - initial `inf_pr=1.45e-05`, `inf_du=1.00e-12`
  - exited after 3 iterations with `Solved To Acceptable Level`
  - final Ipopt report: `inf_pr=1.3991e-05`, complementarity
    `3.9076e-07`, but dual infeasibility `9.2908e+01`
- selected candidate:
  - `selected_candidate_source=pre_solve_start_values`
  - `selected_candidate_residual_feasible=true`
  - `selected_candidate_trajectory_ready=false`
  - `post_solve_candidate_residual_feasible=false`
  - `post_solve_candidate_rejection_reason=not_residual_feasible`
  - max selected-candidate residual `3.169717494422291e-05`
  - dominant metric: lower complementarity
  - top primal defect remains protein collocation/continuity near element 87
    (`t=87 h`)

Interpretation: the h96 seed injection and control-bounds compatibility are now
validated. The solve can start from low primal infeasibility and return an
acceptable Ipopt status without moving controls materially, but the post-solve
candidate is not promotable because residual diagnostics reject it. The
remaining barrier is therefore not the state/RHS/bounds handoff itself; it is a
post-solve residual/dual quality issue. The next technical step should be a
homotopy or regularized post-solve layer that preserves the good pre-solve
candidate while reducing the post-solve residual gap, rather than more
same-grid projection microsteps.

h96 active-band projection and selective-dual-fit follow-up:

- summary:
  `repro/generated/fixed_control_projection_h96_followup_20260622.md`
- helper update:
  `repro/submit_cluster_uc_dynamic_control_candidate_seed_projection.sh` now
  allows overriding `MPCC_DYNAMIC_CONTROL_LIBERATION_MODE` and trust radii. This
  preserves the previous default (`off`, zero trust) but permits same-grid
  projection for seeds whose dynamic-control starts are not the flat baseline.
- job `747315`:
  - root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_active_band_20260622_010555/rank1_71_89`
  - segment `71:89`, accepted damping `0.02`
  - protein collocation/continuity improved from `1.4457409759971451e-05` to
    `1.4025215044954908e-05`
  - lower complementarity remained `3.173028233122001e-05`
- job `747316`:
  - root:
    `/home/cltorrealba/mpcc_runs/dynamic_control_candidate_seed_projection_active_band_20260622_011943/rank1_71_89`
  - same segment, selective dual fit enabled,
    `MPCC_FIXED_FLUX_DUAL_FIT_COMPLEMENTARITY_BUDGET_FRACTION=0.01`
  - protein collocation/continuity improved further to
    `1.3607110814495282e-05`
  - selective dual fit was not applied/accepted
  - lower complementarity remained `3.173028233122001e-05`

Conclusion: fixed-control projection is reproducible and monotone on the h96
protein primal defect, but the strict post-solve gate remains blocked by both
collocation/continuity above `1e-6` and tail lower-complementarity around
`3.17e-5`. Local projection plus tight selective dual fit is therefore not
sufficient for trajectory-ready promotion. The next method layer should be
homotopy/regularization over the validated fixed-control seed.
