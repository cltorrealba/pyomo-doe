# Dynamic control policy selection, 2026-06-10

Purpose: freeze a small, reproducible set of fixed control policies from the
168 h first-pass dynamic-control DOE before wiring them into the reduced MPCC.
This is a methodology artifact only. It does not solve the MPCC, does not
claim simultaneous feasibility, and does not change any blessed MPCC seed.

## Source DOE

- Candidate table:
  `/home/cltorrealba/mpcc_runs/dynamic_control_first_pass_168h_gates_plots_20260610_094856/objective/dynamic_control_objective_candidates.csv`
- Metadata:
  `/home/cltorrealba/mpcc_runs/dynamic_control_first_pass_168h_gates_plots_20260610_094856/objective/dynamic_control_objective_metadata.toml`
- Horizon: 168 h.
- Candidates: 24.
- Gate-passing candidates: 20.
- Shortlisted candidates in DOE metadata: 5.

## Selected fixed policies

The selected replay set intentionally mixes Pareto-shortlisted SpringFerm
profiles with one scalar-objective FDA comparator:

1. `cool18_warm22__springferm_early_0p4`
   - Role: Pareto SpringFerm early high sugar reduction.
   - Temperature values: `18, 22, 22, ...` C on the 12 h grid.
   - FDA doses: none.
   - Organic doses: `0.4 g/L` at the first addition point.
   - 168 h sequential DOE result: final sugar `94.579 g/L`, aroma score
     `0.0873`, total nutrient `0.4 g/L`.

2. `cool18_warm22__springferm_split_0p1_0p1`
   - Role: Pareto SpringFerm split, aroma/low-nutrient contrast.
   - Temperature values: `18, 22, 22, ...` C on the 12 h grid.
   - FDA doses: none.
   - Organic doses: `0.1 g/L` at addition points 1 and 3.
   - 168 h sequential DOE result: final sugar `103.281 g/L`, aroma score
     `0.1279`, total nutrient `0.2 g/L`.

3. `flat20__fda_split_0p5_0p5`
   - Role: scalar-objective FDA comparator.
   - Temperature values: flat `20 C`.
   - FDA doses: `0.5 g/L` at addition points 1 and 3.
   - Organic doses: none.
   - 168 h sequential DOE result: final sugar `119.013 g/L`, aroma score
     `0.0704`, total nutrient `1.0 g/L`.

All three policies pass the current sequential DOE gates and are marked
`control_policy_ready=true`.

## Generated artifacts

Script:

- `scripts/main_dynamic_control_policy_selection.jl`

Output:

- `/home/cltorrealba/mpcc_runs/dynamic_control_policy_selection_20260610_111937/selection/dynamic_control_policy_selection.csv`
- `/home/cltorrealba/mpcc_runs/dynamic_control_policy_selection_20260610_111937/selection/dynamic_control_policy_selection.toml`

Command shape:

```bash
DFBA_DYNAMIC_CONTROL_POLICY_CANDIDATES_CSV=/path/to/dynamic_control_objective_candidates.csv \
DFBA_DYNAMIC_CONTROL_POLICY_METADATA_TOML=/path/to/dynamic_control_objective_metadata.toml \
DFBA_DYNAMIC_CONTROL_POLICY_OUTPUT_DIR=/home/cltorrealba/mpcc_runs/dynamic_control_policy_selection_YYYYMMDD_HHMMSS/selection \
DFBA_DYNAMIC_CONTROL_POLICY_SELECTED_IDS=cool18_warm22__springferm_early_0p4,cool18_warm22__springferm_split_0p1_0p1,flat20__fda_split_0p5_0p5 \
julia --project=. scripts/main_dynamic_control_policy_selection.jl
```

On the UC cluster, run this through Slurm, not on the login node.

## MPCC readiness status

Updated status after the fixed-control MPCC wiring:

- Policy selection status:
  `selection_ready_for_reduced_mpcc_fixed_control_preflight`.
- `dynamic_control_schedule` is now threaded through reduced MPCC RHS
  constraints and dynamic-bound expressions.
- A 24 h, `nfe=2`, no-solver preflight built all three fixed-policy MPCC
  scaffolds with `mpcc_fixed_control_replay_ready=true`.

Current fixed-control preflight artifacts:

- `/home/cltorrealba/mpcc_runs/dynamic_control_mpcc_fixed_replay_20260610_131549/selection/dynamic_control_policy_selection.csv`
- `/home/cltorrealba/mpcc_runs/dynamic_control_mpcc_fixed_replay_20260610_131549/selection/dynamic_control_policy_selection.toml`
- `/home/cltorrealba/mpcc_runs/dynamic_control_mpcc_fixed_replay_20260610_131549/preflight/reduced_mpcc_fixed_control_policy_preflight.csv`
- `/home/cltorrealba/mpcc_runs/dynamic_control_mpcc_fixed_replay_20260610_131549/preflight/reduced_mpcc_fixed_control_policy_preflight.toml`

Next required step: promote one healthy fixed-policy preflight to a guarded
small smoke solve before freeing temperature or nutrient variables.

## Validation

- `728239`: script-entrypoint contract with `using FermentationDFBA`; completed
  on `full/n14`, exit `0:0`.
- `728248`: policy-selection artifact generation; completed on `full/n14`,
  exit `0:0`.
- `728334`: regenerated policy selection after reduced MPCC fixed-control
  support; completed on `full/n14`, exit `0:0`.
- `728341`: 24 h, `nfe=2` fixed-control MPCC preflight for all three policies;
  completed on `full/n14`, exit `0:0`.
