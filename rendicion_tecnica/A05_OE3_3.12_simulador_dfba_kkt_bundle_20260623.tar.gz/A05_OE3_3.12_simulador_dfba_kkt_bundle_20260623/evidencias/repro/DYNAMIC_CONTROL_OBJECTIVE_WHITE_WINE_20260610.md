# Dynamic Control Objective for White-Wine Optimization - 2026-06-10

Purpose: start the temperature + nutrient dynamic-optimization layer with a
white-wine objective informed by aroma/energy trade-offs, while keeping the
implementation lightweight enough for sequential DFBA smokes before any MPCC
promotion.

All Julia execution was submitted through Slurm on the UC cluster. The login
node was used only for editing, inspection, `sbatch`, and monitoring.

## Literature-Informed Design

- Rodman/Gerogiorgis motivates smooth dynamic temperature profiles, bounded
  moves, objective trade-offs, and validation of heuristic optima against
  candidate envelopes.
- The Yabo/Casenave/Mouret white-wine paper motivates treating temperature as
  a quality/energy control, not merely as a fermentation accelerator.
- The first objective therefore reports both a scalar score and Pareto-relevant
  metrics: residual sugar, aroma desirability, cooling-energy proxy, and total
  nutrient dose.
- Nitrogen additions are included now because the white-wine paper identifies
  nitrogen addition as a natural next step for aroma and process-duration
  optimization.

## Nutrient Units

FDA:

- Decision variable: 10% FDA solution, g solution/L.
- User-provided conversion: 1 mg active FDA contributes 0.2 mg YAN as ammonium.
- Implemented conversion: `1 g solution/L -> 0.02 gN/L`.
- OIV/DAP active-product reference limit: `0.3 g/L`.
- Implemented default solution limit: `3.0 g solution/L`.

SpringFerm Xtrem:

- Decision variable: dry product dose, g product/L.
- Default nitrogen basis: YAN equivalent, `0.10 gN/g product`.
- Alternate available basis: real YAN, `0.9431 * 0.0415 = 0.0391 gN/g product`.
- First amino-acid split is normalized over tracked free amino acids present in
  the user-provided summary: phenylalanine, leucine and valine.
- Methionine and tyrosine are explicit missing values in this first pass and
  set to zero until the full certificate is encoded.

## Implementation

- Updated `src/Optimization/dynamic_controls.jl`.
  - Added FDA solution constants and conversion helpers.
  - Added `springferm_xtrem_organic_composition`.
  - Switched reference schedules to FDA solution and SpringFerm defaults.
  - Hardened `SmoothDoseEvent` with an inner constructor so positional calls
    cannot bypass validation.
- Added `src/Optimization/dynamic_control_objective.jl`.
  - `AromaDesirabilityWindow`
  - `DynamicControlObjectiveWeights`
  - `DynamicControlObjectiveResult`
  - `DynamicControlCandidateDesign`
  - `dynamic_control_schedule_from_values`
  - `dynamic_control_candidate_designs`
  - `aroma_desirability_score`
  - `dynamic_control_energy_proxy`
  - `dynamic_control_objective_terms`
  - `evaluate_dynamic_control_objective`
- Added `scripts/main_dynamic_control_objective_smoke.jl`.
  - Evaluates five built-in temperature/FDA/SpringFerm candidates.
  - Can also evaluate the generated first-pass DOE with
    `DFBA_DYNAMIC_CONTROL_OPT_CANDIDATE_SET=first_pass` and
    `DFBA_DYNAMIC_CONTROL_OPT_MAX_CANDIDATES`.
  - Exports candidate CSV and metadata TOML.
  - Adds Pareto flags over final sugar, aroma desirability, energy proxy, and
    total nutrient dose.
- Added `test/test_dynamic_control_objective.jl`.
- Updated script-entrypoint contracts and dynamic-control unit tests.

## Objective

The scalar objective is minimized:

```text
J =
  residual_sugar_weight * max(0, final_total_sugar - residual_sugar_target)^2
  + fermentation_time_weight * final_time
  - ethanol_reward_weight * ethanol_produced
  + aroma_desirability_weight * (1 - aroma_score)^2
  + cooling_energy_weight * cooling_energy_proxy
  + FDA/organic dose penalties
  + nutrient pulse penalty
  + temperature smoothness/move penalties
  + numerical health penalties
```

The default aroma windows are preliminary white-wine placeholders. They are
useful for software development and relative candidate ranking, but must be
recalibrated before sensory or product claims.

The cooling-energy term is a proxy, not a calibrated thermal model. It combines
fermentation sugar consumption, low-temperature setpoint effort relative to
ambient, and downward temperature moves.

## Slurm Validation

Focal tests:

- Job `727822`: initial focal rerun after unit fixes, passed `1759/1759`.
- Job `727839`: final focal rerun after constructor-default alignment, passed
  `1759/1759`.
- Output: `/home/cltorrealba/mpcc_runs/dynamic_control_objective_tests_20260610_005552`

## Sequential Smokes

### 24 h Smoke

- Job: `727849`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_control_objective_24h_smoke_20260610_010646/objective`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `1037384K`
- Best scalar candidate: `cool18_warm22_fda_early`
- Best final total sugar: `206.134826 g/L`
- Best sugar consumed: `13.865174 g/L`
- Best aroma desirability score: `0.092729`
- Best unweighted cooling-energy proxy: `14.290569`

Interpretation: at 24 h, the scalar objective is still dominated by residual
sugar. This is useful as a script smoke, but not a scientific optimization
horizon.

### 48 h Smoke

- Job: `727856`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_control_objective_48h_smoke_20260610_011745/objective`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `1038076K`
- Best scalar candidate: `cool18_warm22_springferm_early`
- Best final total sugar: `188.638379 g/L`
- Best sugar consumed: `31.361621 g/L`
- Best aroma desirability score: `0.123727`
- Best unweighted cooling-energy proxy: `31.787016`

Interpretation: 48 h gives a clearer objective signal. SpringFerm early is
favored over FDA early under the current preliminary aroma/energy/dose weights.

### 48 h Pareto Smoke

- Job: `727872`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_control_objective_48h_pareto_smoke_20260610_013212/objective`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `1048416K`
- Candidate count: `5`
- Best scalar candidate: `cool18_warm22_springferm_early`
- Best final total sugar: `188.638379 g/L`
- Best sugar consumed: `31.361621 g/L`
- Best aroma desirability score: `0.123727`
- Best unweighted cooling-energy proxy: `31.787016`
- Pareto flags: all five smoke candidates are non-dominated under the current
  four metrics because each trades residual sugar, aroma score, energy proxy,
  and total product dose differently.

### DOE Candidate Generator

- Added reusable generated designs over smooth 12 h-grid temperature profiles
  and pump-like nutrient strategies.
- Seeded first-pass pairs start with interpretable baselines:
  `flat20__none`, `cool18_warm22__none`,
  `cool18_warm22__fda_early_1p0`,
  `cool18_warm22__springferm_early_0p2`, and
  `cool18x2_warm22__mixed_early_fda0p5_org0p1`.
- Extended temperature profiles include cool isothermal, warm isothermal,
  early-cool/warm, smooth ramp, and a late warm completion push.
- Extended nutrient strategies include FDA-only, SpringFerm-only, mixed early,
  and split early/mid additions.
- This is a DOE/frontier layer, not an optimizer claim. Its role is to find
  stable, interpretable candidates before embedding controls into MPCC.

### 24 h First-Pass DOE Smoke

- Job: `727923`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_control_first_pass_24h_20260610_022755/objective`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `1048464K`
- Candidate set: `first_pass`, capped at `8`
- Best scalar candidate: `cool18_warm22__fda_early_1p0`
- Best final total sugar: `206.134826 g/L`
- Best sugar consumed: `13.865174 g/L`
- Best aroma desirability score: `0.092729`
- Best unweighted cooling-energy proxy: `14.290569`

Interpretation: this confirms the generated DOE path works end-to-end. As with
the original 24 h smoke, residual sugar dominates and the horizon is too short
for scientific ranking.

### 48 h First-Pass DOE Smoke

- Job: `727934`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_control_first_pass_48h_20260610_023611/objective`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `1053444K`
- Candidate set: `first_pass`, capped at `8`
- Best scalar candidate: `cool18_warm22__springferm_early_0p2`
- Best final total sugar: `188.638379 g/L`
- Best sugar consumed: `31.361621 g/L`
- Best aroma desirability score: `0.123727`
- Best unweighted cooling-energy proxy: `31.787016`

Interpretation: the generated DOE reproduces the hand-written 48 h result and
starts to rank nutrient strategies coherently. SpringFerm early is favored by
the scalar objective under the current preliminary weights.

### 72 h First-Pass DOE Smoke

- Job: `727940`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_control_first_pass_72h_20260610_025002/objective`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `1045932K`
- Candidate set: `first_pass`, capped at `8`
- Best scalar candidate: `cool18_warm22__springferm_early_0p2`
- Best final total sugar: `167.967921 g/L`
- Best sugar consumed: `52.032079 g/L`
- Best aroma desirability score: `0.123727`
- Best unweighted cooling-energy proxy: `52.457474`

Interpretation: the 72 h DOE remains numerically healthy. The current scalar
ranking still favors early SpringFerm with an early cool/warm profile.

### 168 h First-Pass DOE Smoke

- Job: `727955`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_control_first_pass_168h_20260610_030532/objective`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `1090184K`
- Candidate set: `first_pass`, capped at `8`
- Best scalar candidate: `cool18_warm22__springferm_early_0p2`
- Best final total sugar: `103.555166 g/L`
- Best sugar consumed: `116.444834 g/L`
- Best aroma desirability score: `0.123727`
- Best unweighted cooling-energy proxy: `116.870229`

Interpretation: the full-horizon sequential DOE is numerically stable under the
current simulator and objective code. However, this model/condition is still
far from dry at 168 h, so the scalar objective remains dominated by residual
sugar. The result is useful for methodology and MPCC-control wiring, but not
yet a final operating recommendation.

## Current Interpretation

- The new objective layer is technically integrated and backward-compatible
  with the temperature-only prototype.
- The scalar objective remains strongly driven by residual sugar while the
  model is far from dryness. For optimization decisions, use 48 h or 168 h
  evaluations and inspect Pareto columns rather than only the scalar rank.
- Nutrient effects are visible in short smokes, but the amino-acid split needs
  the full SpringFerm certificate before interpreting methionol/tyrosol effects.
- The first-pass DOE was stable through 168 h with 8 candidates.
- Next development step: either broaden the sequential DOE at 168 h or promote
  the same control variables into the reduced MPCC once the model formulation
  changes settle.

## Extended DOE, Gates, and Plots - 2026-06-10

Motivation: turn the sequential dynamic-control layer from a scalar smoke into
a reproducible decision stage before MPCC embedding.

Implementation additions:

- Added `DynamicControlSelectionCriteria`.
- Added `dynamic_control_apply_selection_gates!`.
- Added `src/Visualization/dynamic_control_plots.jl`.
- `scripts/main_dynamic_control_objective_smoke.jl` now writes:
  - `dynamic_control_objective_candidates.csv`
  - `dynamic_control_objective_shortlist.csv`
  - `dynamic_control_objective_metadata.toml`
  - Pareto SVG plots.
  - Candidate trajectory/control SVG plots for selected candidates.

Selection gates:

- `DFBA_DYNAMIC_CONTROL_OPT_SELECTION_FINAL_SUGAR_MAX_G_L`
- `DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MIN_AROMA_SCORE`
- `DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MAX_ENERGY_PROXY`
- `DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MAX_NUTRIENT_G_L`
- `DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MAX_NEGATIVE_STATE_DEFICIT`
- `DFBA_DYNAMIC_CONTROL_OPT_SELECTION_COUNT`
- `DFBA_DYNAMIC_CONTROL_OPT_SELECTION_PREFER_PARETO`
- `DFBA_DYNAMIC_CONTROL_OPT_SELECTION_REQUIRE_FEASIBLE`

Plot controls:

- `DFBA_DYNAMIC_CONTROL_OPT_WRITE_PLOTS`
- `DFBA_DYNAMIC_CONTROL_OPT_PLOT_CANDIDATE_COUNT`

Validation:

- Focal tests job `728161`: `1797/1797`, `COMPLETED`, exit `0:0`.
- 24 h first-pass DOE with 12 candidates and plots job `728166`:
  `COMPLETED`, exit `0:0`.
  - Output:
    `/home/cltorrealba/mpcc_runs/dynamic_control_first_pass_24h_gates_plots_20260610_093628/objective`
  - `gate_pass_count = 11`
  - `selected_for_review_count = 5`
  - Shortlist:
    `flat20__fda_early_1p0`,
    `cool18_warm22__fda_early_1p0`,
    `flat20__mixed_early_fda0p5_org0p1`,
    `cool18x2_warm22__mixed_early_fda0p5_org0p1`,
    `flat20__springferm_early_0p2`
  - Scalar best candidate was `flat20__fda_early_2p0`, but it was excluded
    from the shortlist by the `max_nutrient_g_L = 1.0` gate.

Extended 168 h DOE:

- Job `728173`
- Candidate set: `first_pass`
- Candidate cap: `24`
- Gates:
  - final sugar <= `120 g/L`
  - aroma score >= `0.07`
  - total nutrient product <= `1.0 g/L`
  - selection count `5`
- Output:
  `/home/cltorrealba/mpcc_runs/dynamic_control_first_pass_168h_gates_plots_20260610_094856/objective`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `1093564K`
- Elapsed: `00:36:38`
- `gate_pass_count = 20`
- `selected_for_review_count = 5`
- Shortlist:
  - `cool18_warm22__springferm_early_0p4`
  - `flat20__springferm_early_0p4`
  - `cool18_warm22__springferm_split_0p1_0p1`
  - `cool18_warm22__springferm_early_0p2`
  - `cool18_warm22__mixed_early_fda0p5_org0p1`
- Scalar best candidate:
  - `flat20__fda_split_0p5_0p5`
  - final sugar `119.012778 g/L`
  - aroma score `0.070370`
  - total nutrient product `1.0 g/L`

Interpretation:

- The expanded 168 h DOE is numerically stable.
- The scalar objective picked `flat20__fda_split_0p5_0p5`, mainly because it
  minimizes residual sugar within the gate.
- The Pareto/gated shortlist favors SpringFerm-heavy candidates because they
  offer better aroma score/dose trade-offs under the current preliminary
  desirability windows.
- This reinforces the methodological decision: inspect shortlist plots and
  Pareto fronts before promoting a single profile to MPCC.
