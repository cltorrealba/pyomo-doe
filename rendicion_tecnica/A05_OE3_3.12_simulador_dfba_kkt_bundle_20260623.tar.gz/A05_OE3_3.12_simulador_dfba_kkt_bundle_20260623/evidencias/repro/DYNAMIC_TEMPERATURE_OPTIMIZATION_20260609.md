# Dynamic Temperature Optimization Prototype - 2026-06-09

Purpose: establish the first dynamic-optimization layer on top of the reduced
sequential DFBA simulator. This is temperature-only; FDA/organic additions remain
available in the control scaffold but are not optimized here.

All Julia execution was submitted through Slurm on the UC cluster. The login
node was used only for editing, inspection, `sbatch`, and monitoring.

## Implementation

- Added `src/Optimization/dynamic_temperature_objective.jl`.
- Exported:
  - `DynamicTemperatureObjectiveWeights`
  - `DynamicTemperatureObjectiveResult`
  - `DynamicTemperaturePatternSearchResult`
  - `dynamic_temperature_control_value_count`
  - `expand_temperature_decision_values`
  - `temperature_control_schedule_from_values`
  - `dynamic_temperature_objective_terms`
  - `dynamic_temperature_objective_value`
  - `evaluate_dynamic_temperature_objective`
  - `optimize_dynamic_temperature_pattern_search`
- Added scripts:
  - `scripts/main_dynamic_temperature_objective_smoke.jl`
  - `scripts/main_dynamic_temperature_pattern_search.jl`
- Added tests:
  - `test/test_dynamic_temperature_objective.jl`
  - script-entrypoint contracts for both new scripts.

## Objective

The current objective is a minimization objective:

```text
J =
  final_total_sugar_weight * final_total_sugar
  - ethanol_reward_weight * ethanol_produced
  + temperature_smoothness_weight * sum(diff(T_grid)^2)
  + temperature_move_weight * sum((T_grid - T_ref)^2)
  + numerical health penalties
```

Default primary term is final total sugar. Ethanol reward and temperature
regularization are explicit weights, not hidden behavior. Numerical health
penalties cover non-success retcodes, incomplete horizons, and negative saved
states below tolerance.

Accepted simulator terminations:

- `completed_tspan`
- `sugar_depletion_at_saved_time`
- `sugar_depletion_at_initial_time`

## Slurm Tests

Focal test job:

- Job: `727645`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_temp_search_tests_20260609_212518`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `634944K`
- Result: dynamic objective tests and script contracts passed.

Earlier objective-only test job:

- Job: `727588`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_temp_objective_tests_20260609_202108`
- State: `COMPLETED`, exit `0:0`
- Node: `n14`
- MaxRSS: `637000K`

## Objective Smoke Runs

All smokes used reduced sequential DFBA, HiGHS, Tsit5, 1 CPU, 8 GB, no flux
reconstruction, default initial state, and 12 h temperature grid.

### 24 h, Smoothness Weight 0.05

- Job: `727591`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_temp_objective_24h_smoke_20260609_203201/objective`
- State: `COMPLETED`, exit `0:0`
- Best: `flat20`
- Interpretation: at 24 h, sugar differences are small enough that the
  smoothness penalty dominates.

Ranking:

| Candidate | Objective | Final sugar g/L | Sugar consumed g/L | Smoothness term |
| --- | ---: | ---: | ---: | ---: |
| `flat20` | 207.815080 | 207.815080 | 12.184920 | 0.0 |
| `warm22_after_first_interval` | 207.993999 | 207.793999 | 12.206001 | 0.2 |
| `cool18_after_first_interval` | 208.043716 | 207.843716 | 12.156284 | 0.2 |
| `warm24_after_first_interval` | 208.575523 | 207.775523 | 12.224477 | 0.8 |

### 24 h, No Smoothness Penalty

- Job: `727597`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_temp_objective_24h_noreg_smoke_20260609_204332/objective`
- State: `COMPLETED`, exit `0:0`
- Best: `warm24_after_first_interval`
- Interpretation: with only final sugar in the objective, warmer profiles are
  ranked as expected.

Ranking:

| Candidate | Objective | Final sugar g/L | Sugar consumed g/L |
| --- | ---: | ---: | ---: |
| `warm24_after_first_interval` | 207.775523 | 207.775523 | 12.224477 |
| `warm22_after_first_interval` | 207.793999 | 207.793999 | 12.206001 |
| `flat20` | 207.815080 | 207.815080 | 12.184920 |
| `cool18_after_first_interval` | 207.843716 | 207.843716 | 12.156284 |

### 48 h, Smoothness Weight 0.05

- Job: `727612`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_temp_objective_48h_smoke_20260609_205239/objective`
- State: `COMPLETED`, exit `0:0`
- Best: `warm24_after_first_interval`
- Interpretation: by 48 h the sugar signal is large enough to overcome the
  smoothness penalty.

Ranking:

| Candidate | Objective | Final sugar g/L | Sugar consumed g/L | Smoothness term |
| --- | ---: | ---: | ---: | ---: |
| `warm24_after_first_interval` | 190.370085 | 189.570085 | 30.429915 | 0.8 |
| `warm22_after_first_interval` | 191.373571 | 191.173571 | 28.826429 | 0.2 |
| `flat20` | 192.764973 | 192.764973 | 27.235027 | 0.0 |
| `cool18_after_first_interval` | 194.536520 | 194.336520 | 25.663480 | 0.2 |

## Pattern Search Smoke

Temperature-only coordinate/pattern search, 24 h, initial temperature fixed at
20 C, no smoothness penalty.

- Job: `727652`
- Output: `/home/cltorrealba/mpcc_runs/dynamic_temp_pattern_search_24h_noreg_20260609_213435/search`
- State: `COMPLETED`, exit `0:0`
- Unique evaluations: `7`
- Candidate rows: `10`
- Best candidate: `eval_0007_iter3_i2_plus`
- Best temperature grid: `[20.0, 25.0]` C
- Best objective: `207.766025`
- Best final sugar: `207.766025` g/L
- Best sugar consumed: `12.233975` g/L
- Best final ethanol: `5.284321` g/L

The search path accepted:

```text
[20, 20] -> [20, 22] -> [20, 24] -> [20, 25]
```

This confirms the prototype optimizer can move controls in the expected
direction under the current objective and bounds.

## Methodological Notes

- The 24 h signal is small. For objective-tuning, use at least 48 h, and for
  scientific optimization use 168 h once evaluations are budgeted.
- Smooth logistic interpolation makes the applied temperature trajectory smooth,
  but `temperature_smoothness_weight` still controls how aggressively the target
  grid may move.
- The current objective is intentionally simple and transparent. Before adding
  FDA/organic additions, choose whether the temperature-only target should be:
  final sugar minimization, ethanol-aware, aroma-aware, or multi-term with a
  fermentation-time target.
- FDA/organic additions should enter after temperature-only search is stable,
  using total-dose penalties and smooth pump events already present in
  `DynamicControlSchedule`.
