# Dynamic-control MPCC objective pilot, 2026-06-14

Context:
- Goal: first simultaneous 168 h MPCC pilot with free 12 h temperature/nutrient controls and objective `aroma_nutrient_energy`.
- Objective terms: reward terminal `isoamyl_acetate` request resolved to reduced state `isoamyl_alcohol`; penalize FDA/organic nutrient use; penalize thermal energy and temperature smoothness.
- Solver line: Ipopt + MA86 + limited-memory Hessian, `OPENBLAS_NUM_THREADS=1`.

Best current start recipe:
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SCORE=full_threshold_ratio`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_FLUX_PROJECTION=1`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION=0`
- `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD_SCORE=candidate_threshold_ratio`

Why:
- `candidate_threshold_ratio` alone preserves bounds/RHS but restores the non-collocation-consistent sequential start.
- `collocation_state` alone makes collocation/continuity exact but can create tail protein/RHS and ethanol-bound failures.
- The mixed recipe keeps bounds/RHS small and reduces the dominant collocation/continuity start residual from about `0.61945` to about `0.12153`.

Key Slurm runs:
- `732728`: 168 h, max_iter=0, `candidate_threshold_ratio`, final flux projection off.
  - Result: bounds/RHS clean, but collocation/continuity stayed `0.61945`; `trajectory_ready=false`.
- `732745`: same start, max_iter=20, cancelled early.
  - Ipopt stayed at `inf_pr=6.19e-01` through iter 4 with tiny steps.
- `732768`: 168 h, max_iter=0, candidate score with final flux projection on.
  - Trace exposed useful intermediate repair, but outer candidate score restored the original start.
- `732786`: 168 h, max_iter=0, mixed recipe above.
  - Result: `max_collocation_integration_residual=0.1215348553`, `max_continuity_residual=0.1215348553`, `max_rhs_residual=2.4e-7`, bound violations about `1e-7`, `candidate_residual_feasible=true`, `trajectory_ready=false`.
- `732804`: mixed recipe, max_iter=20, 8 CPUs, cancelled at iter 0 because first KKT step did not progress in a reasonable time.
- `732828`: mixed recipe, max_iter=5, 24 CPUs, completed.
  - Ipopt entered restoration at iter 1 and ended with `max_continuity_residual=0.1214296108`, dual infeasibility about `1.0e3`, `trajectory_ready=false`.

Conclusion:
- The dynamic objective and control coupling are implemented and exercised.
- The current 168 h fully simultaneous NLP is not promotable yet. The blocking issue is start/formulation feasibility around collocation-continuity vs dynamic flux-bound consistency, not objective weights.
- More MA86 threads help finish the pilot but do not fix restoration.

Recommended next technical step:
- Do not escalate this exact 168 h full-control solve.
- Add a smaller staged feasibility path before the dynamic objective:
  1. fixed controls, mixed repair, 168 h, feasibility-only objective;
  2. free only temperature controls;
  3. free only nutrient controls;
  4. then free both with objective.
- In parallel, add an opt-in state nonnegativity / bounded-state repair experiment, because the repair conflict is driven by state-dependent dynamic bounds in the tail.

State nonnegativity experiment:
- Added opt-in state lower bounds via `MPCC_REDUCED_DCDFBA_STATE_NONNEGATIVE_BOUNDS=1`.
- The bounds apply only to `state_boundary` and `state_collocation`; state derivatives remain free.
- Focused Slurm validation `732890` passed `215/215` tests for the scaffold/smoke contract.
- First 168 h fixed/off pilot with state bounds, `732892`, failed before Ipopt:
  - failure point: mass-balanced dynamic flux-start projection;
  - element `52`, collocation `3`, ordinal `156`;
  - HiGHS status: `INFEASIBLE`.
- Interpretation: hard nonnegative state bounds are not enough by themselves. The start repair can produce state-dependent flux bounds where exact `S*v=0` projection is locally infeasible.

New repair option:
- Added opt-in relaxed fallback for dynamic flux-start projection:
  - `MPCC_DYNAMIC_FLUX_LP_RELAXED_FALLBACK=1`;
  - `MPCC_DYNAMIC_FLUX_LP_RELAXED_MASS_WEIGHT=1000.0`;
  - recommended with `MPCC_DYNAMIC_FLUX_LP_FAIL_FAST=0` for diagnostic pilots.
- The fallback preserves flux bounds and minimizes flux adjustment plus mass-balance slack. It does not change MPCC equations; it only avoids aborting start construction and records how much mass-balance slack was needed.

Next run to execute when Slurm access is available:
- Repeat the 168 h fixed/off max_iter=0 pilot with:
  - `MPCC_REDUCED_DCDFBA_STATE_NONNEGATIVE_BOUNDS=1`;
  - `MPCC_DYNAMIC_FLUX_LP_FAIL_FAST=0`;
  - `MPCC_DYNAMIC_FLUX_LP_RELAXED_FALLBACK=1`;
  - `MPCC_DYNAMIC_FLUX_LP_RELAXED_MASS_WEIGHT=1000.0`.
- Compare against `732856` and `732892`:
  - state negative counts;
  - `max_lower_bound_violation`;
  - `max_collocation_integration_residual`;
  - `max_continuity_residual`;
  - relaxed fallback attempt/optimal counts;
  - maximum relaxed mass-balance residual after fallback.

Follow-up result:
- `732955` used the relaxed dynamic flux fallback and passed the previous
  `element=52, collocation=3` projection crash.
- It then failed later in stationarity dual-start LP at `element=74`,
  `collocation=3`, ordinal `222`, with HiGHS `INFEASIBLE`.
- The stationarity dual-start path already has a diagnostic nonfatal mode.
  Next fixed/off pilot should add:
  - `MPCC_STATIONARITY_DUAL_START_LP_FAIL_FAST=0`.

State clamp results:
- Added opt-in state-start clamp:
  - `MPCC_REDUCED_DCDFBA_STATE_NONNEGATIVE_START_CLAMP=1`.
- Focused Slurm validation `733039` passed `224/224` tests.
- `733048`, fixed/off 168 h, max_iter=0, state bounds + relaxed flux fallback
  + stationarity dual soft-fail + state-start clamp:
  - completed, `candidate_residual_feasible=true`;
  - `candidate_state_boundary_min=0.0`;
  - `candidate_state_collocation_min=0.0`;
  - `candidate_state_boundary_negative_count=0`;
  - `candidate_state_collocation_negative_count=0`;
  - dominant residual remains glucose tail collocation/continuity;
  - `max_collocation_integration_residual=0.0704601466`;
  - `max_continuity_residual=0.0704601466`;
  - `candidate_trajectory_ready=false`.
- `733088`, same recipe with max_iter=5:
  - completed, but post-solve remained rejected;
  - `max_collocation_integration_residual=0.0703861615`;
  - `max_continuity_residual=0.0704208277`;
  - `post_solve_candidate_residual_feasible=false`;
  - selected candidate remains pre-solve start.

Interpretation:
- The base is now state-nonnegative and residual-feasible, but not trajectory-ready.
- Ipopt limited-memory with five iterations barely improves the tail glucose
  collocation/continuity residual. The next best fixed-control step is a
  deeper start repair before releasing controls.

Repair-depth follow-up:
- `733143`, fixed/off 168 h, max_iter=0, same state bounds + relaxed flux
  fallback + stationarity dual soft-fail + state-start clamp, but with
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=20`:
  - completed in Slurm on `n14`;
  - selected candidate remained `pre_solve_start_values`;
  - `candidate_residual_feasible=true`;
  - `candidate_trajectory_extraction_ready=false`;
  - `candidate_state_boundary_negative_count=0`;
  - `candidate_state_collocation_negative_count=0`;
  - `max_collocation_integration_residual=0.0704601466`;
  - `max_continuity_residual=0.0704601466`;
  - dominant residual remained the tail glucose collocation/continuity block
    around 164 h.

Interpretation:
- Increasing repair iterations from 8 to 20 did not improve the dominant
  structural residual. The next technical move is therefore not deeper
  fixed-control repair, but a guarded full-control dynamic-objective diagnostic
  using the current best state-nonnegative 168 h start.

First full-control dynamic-objective pilot:
- `733248`, full 168 h temperature/FDA/organic controls, max_iter=20,
  state bounds + state-start clamp + relaxed flux fallback + stationarity
  dual soft-fail, objective `aroma_nutrient_energy` and reference
  regularization weight `0.25`:
  - completed on `n14`;
  - `mpcc_dynamic_control_decision_spec_provided=true`;
  - `fully_simultaneous_controls=true`;
  - `control_variable_count=40`;
  - `free_temperature_count=14`;
  - `free_fda_count=13`;
  - `free_organic_count=13`;
  - objective target request `isoamyl_acetate` resolved to reduced-state proxy
    `isoamyl_alcohol`;
  - `dynamic_control_objective_term_count=4`;
  - solver status `ITERATION_LIMIT`, primal status `INFEASIBLE_POINT`;
  - `candidate_residual_feasible=false`;
  - `post_solve_candidate_rejected=true`;
  - `max_rhs_residual=0.0034246362`;
  - `max_collocation_integration_residual=0.1215167694`;
  - `max_continuity_residual=0.1215167694`;
  - `max_mass_balance_residual=5.4648727e-6`;
  - `max_lower_complementarity_residual=0.0029097837`.

Diagnosis:
- The failure is not control/objective scaffolding absence: the controls are
  coupled to RHS and dynamic bounds, and the objective is active.
- The suspicious difference from the sane fixed/off state-nonnegative base is
  `collocation_consistent_state_start_final_complementarity_flux_projection`.
  In `733248` it was enabled and applied:
  - `active_complementarity_flux_projection_triggered_points=245`;
  - first nonoptimal projection status `INFEASIBLE`;
  - `active_complementarity_flux_projection_changed_count=78779`;
  - `active_complementarity_flux_projection_max_adjustment=4.4768998374`;
  - `candidate_max_rhs_residual_from_arrays=0.0034246362`.
- Next run should repeat the full-control objective pilot with
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION=0`
  to preserve the RHS-consistent dynamic-control start.

No-final-complementarity-projection follow-up:
- `733324`, full 168 h objective, max_iter=20, same state-nonnegative guarded
  recipe but with
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION=0`:
  - completed on `n14`;
  - solver status `ITERATION_LIMIT`, primal status `INFEASIBLE_POINT`;
  - post-solve candidate was rejected;
  - selected candidate fell back to residual-feasible pre-solve start;
  - post-solve residuals were much saner than `733248`:
    `max_rhs_residual=2.1063e-8`, `max_mass_balance_residual=1.6590e-5`;
  - still not acceptable because post-solve residual feasibility failed and
    `trajectory_ready=false`.
- `733383`, same recipe with max_iter=5:
  - completed on `n14`;
  - solver status `ITERATION_LIMIT`, primal status `INFEASIBLE_POINT`;
  - post-solve candidate was rejected;
  - `max_mass_balance_residual=9.2737e-7`;
  - `max_upper_complementarity_residual=1.2855e-5`, just above threshold.
- `733438`, same recipe with max_iter=1:
  - completed on `n14`;
  - post-solve residuals were close, with
    `max_mass_balance_residual=5.1154e-7` and
    `max_upper_complementarity_residual=4.4805e-8`;
  - but primal status remained `INFEASIBLE_POINT`, so the candidate selector
    correctly rejected the post-solve candidate.

First residual-feasible optimized post-solve:
- `733504`, full 168 h objective, max_iter=5, no final complementarity flux
  projection, state bounds + clamp, relaxed dynamic flux fallback, stationarity
  dual soft-fail, and `MPCC_FIXED_CONTROL_IPOPT_PROFILE=feasibility_handoff`:
  - completed on `n14` in `00:40:35`, exit code `0:0`;
  - solver status `ITERATION_LIMIT`, primal status `NEARLY_FEASIBLE_POINT`;
  - selected candidate source: `post_solve_values`;
  - `post_solve_candidate_residual_feasible=true`;
  - `selected_candidate_residual_feasible=true`;
  - `selected_candidate_trajectory_ready=false`;
  - dynamic objective was active with target request `isoamyl_acetate`
    resolved to reduced-state proxy `isoamyl_alcohol`;
  - control scaffold remained fully simultaneous:
    `control_variable_count=40`, with 14 temperature slots, 13 FDA slots and
    13 organic nutrient slots free.

`733504` residuals:
- `max_rhs_residual=2.1045983978e-8`;
- `max_mass_balance_residual=5.0609830362e-7`;
- `max_lower_bound_violation=7.3590210266e-8`;
- `max_upper_bound_violation=4.7024965668e-9`;
- `max_stationarity_residual=2.8474450972e-12`;
- `max_upper_complementarity_residual=1.2753274627e-5`;
- `max_lower_complementarity_residual=9.9031565847e-4`;
- `max_collocation_integration_residual=0.0703179065`;
- `max_continuity_residual=0.0702965052`.

Interpretation of `733504`:
- This is the first optimized dynamic-control MPCC post-solve that the current
  candidate gate accepts as residual-feasible.
- It is not trajectory-ready: the dominant residual is still the tail glucose
  collocation/continuity block near the end of the 168 h horizon.
- The optimized control move is numerically tiny:
  - maximum temperature movement: `7.8858464456e-4` degC;
  - FDA total: `1.0115340075e-7` g/L;
  - organic total reduced from `0.4` to `0.3999237972` g/L.
- Therefore, this run is a methodological foothold, not yet a scientifically
  meaningful optimum.

Generated diagnostics for `733504`:
- Plot:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_full168_iter5_20260614_100459/plots/optimized_control_profiles.png`
- Vector plot:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_full168_iter5_20260614_100459/plots/optimized_control_profiles.svg`
- Control table:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_full168_iter5_20260614_100459/plots/optimized_control_values.csv`
- Summary:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_full168_iter5_20260614_100459/plots/optimized_control_summary.csv`

Next optimization step:
- Keep the `feasibility_handoff` profile and
  `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION=0`.
- Relax objective regularization in stages, because `733504` is accepted but
  over-regularized around the reference:
  1. reference regularization `0.10`, trust unchanged;
  2. reference regularization `0.05`, trust unchanged;
  3. only if accepted, expand temperature/nutrient trust modestly.
- Do not treat `733504` as a blessed trajectory seed until the
  collocation/continuity tail residual is explicitly addressed.

Regularization relaxation follow-up:
- `733590`, intended repeat with reference regularization `0.05`, failed in
  one second because the Slurm template expanded empty `JULIA_FLAGS` under
  `set -u`.
  - This was a batch-template bug, not a scheduler failure.
  - The template now branches explicitly between Julia with flags and Julia
    without flags.
- `733591`, same scientific configuration after the template fix:
  - completed on `n14` in `00:42:42`, exit code `0:0`;
  - max RSS about `20.5 GB`;
  - `MPCC_DYNAMIC_CONTROL_REFERENCE_REGULARIZATION_WEIGHT=0.05`;
  - solver status `ITERATION_LIMIT`, primal status `NEARLY_FEASIBLE_POINT`;
  - selected candidate source: `post_solve_values`;
  - `post_solve_candidate_residual_feasible=true`;
  - `selected_candidate_residual_feasible=true`;
  - `selected_candidate_trajectory_ready=false`.

`733591` residuals:
- `max_rhs_residual=2.1045983978e-8`;
- `max_mass_balance_residual=5.0609841730e-7`;
- `max_lower_bound_violation=7.3590210269e-8`;
- `max_upper_bound_violation=4.7024965668e-9`;
- `max_stationarity_residual=2.8474450923e-12`;
- `max_upper_complementarity_residual=1.2753274627e-5`;
- `max_lower_complementarity_residual=9.9031565847e-4`;
- `max_collocation_integration_residual=0.0703179065`;
- `max_continuity_residual=0.0702965052`.

`733591` control movement:
- maximum temperature movement: `7.8858464440e-4` degC;
- FDA total: `1.0115340075e-7` g/L;
- organic total: `0.3999237972` g/L.

Comparison with `733504`:
- Reducing reference regularization from `0.25` to `0.05` did not materially
  change the solution.
- The maximum optimized-control difference between the two runs was about
  `2.9e-12`.
- Therefore, the current bottleneck is not simply the reference-regularization
  weight. With max_iter=5 and `feasibility_handoff`, Ipopt stays in the same
  residual-feasible neighborhood before the dynamic objective can meaningfully
  reshape the profile.

Generated diagnostics for `733591`:
- Plot:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter5_20260614_110944/plots/optimized_control_profiles.png`
- Vector plot:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter5_20260614_110944/plots/optimized_control_profiles.svg`
- Control table:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter5_20260614_110944/plots/optimized_control_values.csv`
- Summary:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter5_20260614_110944/plots/optimized_control_summary.csv`

Next optimization step after `733591`:
- Preserve the accepted recipe and raise the allowed number of Ipopt
  iterations before expanding trust regions:
  - `MPCC_FIXED_CONTROL_IPOPT_PROFILE=feasibility_handoff`;
  - no final complementarity flux projection;
  - state bounds + state-start clamp;
  - relaxed dynamic flux fallback and stationarity dual soft-fail;
  - reference regularization `0.05`;
  - max_iter `10`.
- If max_iter `10` keeps post-solve residual-feasible, then expand trust
  regions or increase the terminal aroma reward. If it loses residual
  feasibility, keep max_iter `5` as the accepted base and work on the
  trajectory-ready tail residual.

Iteration-budget follow-up:
- `733643`, same accepted recipe as `733591`, but with
  `MPCC_FIXED_CONTROL_MAX_ITER=10`:
  - completed on `n14` in `00:40:12`, exit code `0:0`;
  - max RSS about `20.2 GB`;
  - solver status `ITERATION_LIMIT`, primal status `NEARLY_FEASIBLE_POINT`;
  - selected candidate source: `post_solve_values`;
  - `post_solve_candidate_residual_feasible=true`;
  - `selected_candidate_residual_feasible=true`;
  - `selected_candidate_trajectory_ready=false`;
  - objective value improved from about `271.27789` to `271.25646`.

`733643` residuals:
- `max_rhs_residual=2.1049918668e-8`;
- `max_mass_balance_residual=5.0634200817e-7`;
- `max_lower_bound_violation=7.3643224848e-8`;
- `max_upper_bound_violation=4.7179002563e-9`;
- `max_stationarity_residual=2.8760609183e-12`;
- `max_upper_complementarity_residual=1.2888557506e-5`;
- `max_lower_complementarity_residual=9.9038016835e-4`;
- `max_collocation_integration_residual=0.0701974371`;
- `max_continuity_residual=0.0702248762`.

`733643` control movement:
- maximum temperature movement: `1.0221072501e-3` degC;
- FDA total: `8.5729475344e-8` g/L;
- organic total: `0.3998907446` g/L.

Interpretation:
- Raising max_iter from 5 to 10 preserved post-solve residual feasibility and
  started to improve the objective and dominant structural residual.
- The movement is still far too small for a scientifically meaningful dynamic
  optimum, but this is the first monotone sign that additional Ipopt iterations
  are useful under `feasibility_handoff`.
- Next step: repeat with max_iter `20` before changing objective weights or
  expanding trust regions.

Generated diagnostics for `733643`:
- Plot:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter10_20260614_115423/plots/optimized_control_profiles.png`
- Vector plot:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter10_20260614_115423/plots/optimized_control_profiles.svg`
- Control table:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter10_20260614_115423/plots/optimized_control_values.csv`
- Summary:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter10_20260614_115423/plots/optimized_control_summary.csv`

Iteration-frontier follow-up:
- The accepted recipe was scanned over max_iter `12`, `13`, `14`, `15`, and
  `20` using the same `feasibility_handoff`, no final complementarity flux
  projection, state bounds + clamp, relaxed dynamic flux fallback, stationarity
  dual soft-fail, reference regularization `0.05`, and unchanged trust regions.
- The frontier is controlled by the post-solve mass-balance gate:
  max_iter `13` remains accepted; max_iter `14` already exceeds the
  `1.0e-6` mass-balance residual threshold.

| job | iter | reg | objective | primal | post_feas | selected | mass | colloc | continuity | rhs | traj |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 733504 | 5 | reg0p25 | 271.277899 | NEARLY_FEASIBLE_POINT | true | post_solve_values | 5.06098e-07 | 0.0703179 | 0.0702965 | 2.1046e-08 | false |
| 733591 | 5 | reg0p05 | 271.277891 | NEARLY_FEASIBLE_POINT | true | post_solve_values | 5.06098e-07 | 0.0703179 | 0.0702965 | 2.1046e-08 | false |
| 733643 | 10 | reg0p05 | 271.256456 | NEARLY_FEASIBLE_POINT | true | post_solve_values | 5.06342e-07 | 0.0701974 | 0.0702249 | 2.10499e-08 | false |
| 733814 | 12 | reg0p05 | 271.251453 | NEARLY_FEASIBLE_POINT | true | post_solve_values | 7.00884e-07 | 0.0701521 | 0.070212 | 2.10517e-08 | false |
| 733880 | 13 | reg0p05 | 271.248971 | NEARLY_FEASIBLE_POINT | true | post_solve_values | 8.2097e-07 | 0.070128 | 0.0702064 | 2.10538e-08 | false |
| 733949 | 14 | reg0p05 | 271.245579 | NEARLY_FEASIBLE_POINT | false | pre_solve_start_values | 1.06914e-06 | 0.0700952 | 0.0701989 | 2.10568e-08 | false |
| 733757 | 15 | reg0p05 | 271.243759 | NEARLY_FEASIBLE_POINT | false | pre_solve_start_values | 1.12298e-06 | 0.0700825 | 0.070195 | 2.1055e-08 | false |
| 733690 | 20 | reg0p05 | 271.235452 | NEARLY_FEASIBLE_POINT | false | pre_solve_start_values | 1.36043e-06 | 0.0700108 | 0.0701767 | 2.10602e-08 | false |

Best current accepted candidate:
- `733880` is the best current post-solve residual-feasible optimized
  168 h dynamic-control MPCC candidate in this series.
- It is still not trajectory-ready, because the tail glucose
  collocation/continuity residual remains about `0.0702`.
- It is better than `733504`/`733591`/`733643` on objective while still passing
  the post-solve residual-feasible gate.
- It should be treated as an optimized residual-feasible pilot, not a blessed
  trajectory seed.

`733880` residuals:
- `max_rhs_residual=2.1053823616e-8`;
- `max_mass_balance_residual=8.2097017184e-7`;
- `max_lower_bound_violation=7.3674393197e-8`;
- `max_upper_bound_violation=4.7288681054e-9`;
- `max_stationarity_residual=2.8928452246e-12`;
- `max_upper_complementarity_residual=1.2967942575e-5`;
- `max_lower_complementarity_residual=9.9032465675e-4`;
- `max_collocation_integration_residual=0.0701280246`;
- `max_continuity_residual=0.0702064359`.

`733880` control movement:
- maximum temperature movement: `1.0284423948e-3` degC;
- FDA total: `7.8929459289e-8` g/L;
- organic total: `0.3998839600` g/L.

Generated diagnostics for `733880`:
- Plot:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter13_20260614_151836/plots/optimized_control_profiles.png`
- Vector plot:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter13_20260614_151836/plots/optimized_control_profiles.svg`
- Control table:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter13_20260614_151836/plots/optimized_control_values.csv`
- Summary:
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter13_20260614_151836/plots/optimized_control_summary.csv`

Next technical step:
- Do not relax residual thresholds merely to accept `733949`/`733757`/`733690`.
- Either work on the structural trajectory-ready blocker around tail glucose
  collocation/continuity, or run a new series that changes objective leverage
  while keeping max_iter at the accepted frontier (`13`) and watching the same
  mass-balance gate.
- A sensible next optimization pilot is to keep max_iter `13` and increase
  terminal aroma reward or reduce thermal/nutrient penalties, because simply
  adding more iterations improves objective but crosses the mass residual gate.

Prepared objective-leverage submit helper:
- Variant table:
  `repro/cluster_uc_dynamic_control_objective_leverage_variants.tsv`
- Submit helper:
  `repro/submit_cluster_uc_dynamic_control_objective_leverage.sh`
- The helper lists variants without contacting Slurm:
  `bash repro/submit_cluster_uc_dynamic_control_objective_leverage.sh --list`
- The helper submits exactly one variant at a time through Slurm, after light
  `sinfo` and `squeue -u "$USER"` checks, preserving:
  - 168 h horizon;
  - `max_iter=13`;
  - `feasibility_handoff`;
  - MA86 + limited-memory Hessian;
  - no final complementarity flux projection;
  - state nonnegative bounds + start clamp;
  - relaxed dynamic flux fallback;
  - stationarity dual soft-fail;
  - 8 CPUs, `OPENBLAS_NUM_THREADS=1`, no GPU.

Recommended first leverage pilot:
- Run:
  `bash repro/submit_cluster_uc_dynamic_control_objective_leverage.sh reward2_reg0p05_iter13`
- Rationale:
  - doubles the aroma terminal reward while leaving penalties, trust regions,
    and the accepted `iter13` feasibility recipe unchanged;
  - should reveal whether objective leverage can produce more meaningful
    control movement before mass-balance residual crosses the post-solve gate.
- If accepted, continue with `reward5_reg0p05_iter13`.
- If rejected, keep `733880` as the best accepted optimization pilot and shift
  effort back to the trajectory-ready tail glucose collocation/continuity
  blocker.

Objective-leverage result:
- `734006`, variant `reward2_reg0p05_iter13`, doubled terminal aroma reward
  while preserving the accepted `iter13` feasibility recipe.
- The job completed through Slurm and selected post-solve values:
  - solver status `ITERATION_LIMIT`;
  - primal status `NEARLY_FEASIBLE_POINT`;
  - `selected_candidate_source=post_solve_values`;
  - `post_solve_candidate_residual_feasible=true`;
  - `selected_candidate_residual_feasible=true`;
  - `selected_candidate_trajectory_ready=false`.

`734006` residuals:
- `max_rhs_residual=2.1053823616e-8`;
- `max_mass_balance_residual=8.2097017184e-7`;
- `max_lower_bound_violation=7.3674393190e-8`;
- `max_upper_bound_violation=4.7288681053e-9`;
- `max_stationarity_residual=2.8928306935e-12`;
- `max_upper_complementarity_residual=1.2967942571e-5`;
- `max_lower_complementarity_residual=9.9032465673e-4`;
- `max_collocation_integration_residual=0.0701280246`;
- `max_continuity_residual=0.0702064359`.

`734006` interpretation:
- Doubling terminal aroma reward improved the reported objective from
  `271.2489705050` to `271.2438385506`, while keeping the post-solve
  residual-feasible gate.
- However, the optimized controls are materially identical to `733880`:
  maximum absolute optimized-control difference versus `733880` was about
  `3.1e-11`.
- Therefore, simple reward doubling is not enough to move the solution under
  the current reference regularization and trust recipe.

Generated diagnostics for `734006`:
- Workspace plot:
  `repro/generated/dynamic_control_objective_leverage_reward2_reg0p05_iter13_734006/optimized_control_profiles.png`
- Workspace vector plot:
  `repro/generated/dynamic_control_objective_leverage_reward2_reg0p05_iter13_734006/optimized_control_profiles.svg`
- Workspace control table:
  `repro/generated/dynamic_control_objective_leverage_reward2_reg0p05_iter13_734006/optimized_control_values.csv`
- Workspace summary:
  `repro/generated/dynamic_control_objective_leverage_reward2_reg0p05_iter13_734006/optimized_control_summary.csv`
- Aggregate pilot summary:
  `repro/generated/dynamic_control_objective_pilot_summary.csv`
  - Use `post_solve_candidate_residual_feasible` and
    `selected_candidate_source` when comparing runs.
  - For rejected runs such as `733949`, `733757`, and `733690`, selected
    controls can be the pre-solve fallback, so control deltas should not be
    interpreted as accepted post-solve movement.

Updated next leverage pilot:
- Prefer `reward5_reg0p02_iter13` over `reward5_reg0p05_iter13`.
- Rationale: `reward2_reg0p05_iter13` passed but did not move controls, so the
  next attempt should combine stronger terminal reward with weaker reference
  regularization while preserving the accepted max_iter `13` feasibility
  recipe.
- Keep monitoring the mass-balance gate; do not accept variants that only
  improve objective by falling back to pre-solve starts or by exceeding
  `max_mass_balance_residual=1.0e-6`.

Parallel leverage wave:
- Active Slurm status checked at `2026-06-14 18:10` Chile time.
- `734064`, variant `reward5_reg0p02_iter13`, was running on `n14` with
  `8` CPUs and run root
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward5_reg0p02_iter13_20260614_175351`.
- `734087`, variant `reward5_lownutrientthermal_reg0p05_iter13`, was running
  on `n8` with `8` CPUs and run root
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward5_lownutrientthermal_reg0p05_iter13_20260614_180840`.
- `734088`, variant `reward5_reg0p05_iter13`, was running on `n8` with `8`
  CPUs and run root
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward5_reg0p05_iter13_20260614_180840`.
- Initial active load for this wave was `24` CPUs, matching the conservative
  parallelization target without using GPU resources.
- Earlier duplicate submissions `734080` and `734081` were cancelled before
  Ipopt output; do not use their run roots for scientific comparison.
- All active headers confirmed MA86, `MPCC_IPOPT_HSLLIB` under the cluster HSL
  install, limited-memory Hessian, `OPENBLAS_NUM_THREADS=1`,
  `MPCC_FIXED_CONTROL_IPOPT_PROFILE=feasibility_handoff`, state nonnegative
  bounds/start clamp, relaxed dynamic flux fallback, and stationarity dual
  soft-fail.

Prepared mg/L-scale aroma leverage variants:
- The first leverage runs kept
  `MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_STATE_SCALE_G_L=0.1`, inherited
  from the generic objective default.
- That scale is large for aroma metabolites, where relevant concentrations are
  closer to mg/L. With the current proxy target, the observed objective change
  from reward `1` to `2` was consistent with a final proxy concentration around
  `5e-4 g/L`, so the terminal reward gradient can be too weak relative to the
  feasibility handoff objective and reference regularization.
- `repro/cluster_uc_dynamic_control_objective_leverage_variants.tsv` now
  includes an explicit `terminal_state_scale_g_L` column.
- The submit helper now exports
  `MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_STATE_SCALE_G_L`.
- New prepared variants:
  - `reward1_scale1mg_reg0p05_iter13`;
  - `reward2_scale1mg_reg0p05_iter13`;
  - `reward1_scale1mg_reg0p02_iter13`.
- `734100`, variant `reward1_scale1mg_reg0p02_iter13`, was submitted to `n8`
  at `2026-06-14 18:20` Chile time with `8` CPUs and run root
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter13_20260614_182020`.
- This brings the active wave to `32` allocated CPUs total across `n14` and
  `n8`; the submission was made only after confirming `n8` had substantial
  spare CPU capacity.
- The `cluster_uc_dynamic_control_liberated_mpcc_pilot.sbatch` template now
  records `dynamic_control_objective_terminal_state_scale_g_L` in future
  headers/metadata so mg/L-scale variants are auditable from the run log.

Parallel wave correction:
- `734087` and `734100` were cancelled at about `2026-06-14 18:30` Chile time.
  Both were reserving `8` CPUs on `n8` but showed very low accumulated CPU and
  no `decision_spec` artifact, consistent with unproductive setup/cache
  blocking rather than useful solve progress.
- `734064` was kept running; it reached the Ipopt banner in
  `slurm-734064.out`, confirming that MA86/HSL initialization passed and the
  solver was starting.
- `734088` was kept running because it had meaningful CPU accumulation despite
  not yet writing final artifacts.
- `734115`, variant `reward1_scale1mg_reg0p05_iter13`, was observed running on
  `n8` with run root
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p05_iter13_20260614_183135`.
- After the correction, active useful load was back to `24` allocated CPUs:
  `734064` on `n14`, plus `734088` and `734115` on `n8`.
- After `734064` completed and freed `n14`, `reward1_scale1mg_reg0p02_iter13`
  was relaunched as job `734122` on `n14` with run root
  `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter13_20260614_183744`.
  This recovers the high-value mg/L-scale, weaker-regularization test without
  keeping the unproductive `734100` allocation alive.
- `734088` later ended as `CANCELLED` before writing an attempt artifact, so it
  should not be used for scientific comparison or control interpretation.

`734064` result:
- Variant: `reward5_reg0p02_iter13`.
- Slurm state: `COMPLETED`.
- Solver status: `ITERATION_LIMIT`.
- Primal status: `NEARLY_FEASIBLE_POINT`.
- `selected_candidate_source=post_solve_values`.
- `post_solve_candidate_residual_feasible=true`.
- `selected_candidate_residual_feasible=true`.
- `selected_candidate_trajectory_ready=false`.
- Objective improved to `271.2284403599`, compared with `271.2489705050`
  for `733880` and `271.2438385506` for `734006`.
- Residuals stayed on the same accepted frontier:
  - `max_mass_balance_residual=8.2097017184e-7`;
  - `max_collocation_integration_residual=0.0701280246`;
  - `max_continuity_residual=0.0702064359`.
- Control movement was still materially unchanged:
  - maximum temperature movement `1.0284423978e-3` degC;
  - FDA total `7.8929459308e-8` g/L;
  - organic total `0.3998839600` g/L;
  - organic maximum movement `1.1609614994e-4` g/L.
- Interpretation: stronger reward plus weaker reference regularization changes
  the scalar objective but still does not unlock meaningful accepted control
  movement. The mg/L-scale terminal-aroma variants are therefore the more
  informative next tests.

Generated diagnostics for `734064`:
- Workspace plot:
  `repro/generated/dynamic_control_objective_leverage_reward5_reg0p02_iter13_734064/optimized_control_profiles.png`
- Workspace vector plot:
  `repro/generated/dynamic_control_objective_leverage_reward5_reg0p02_iter13_734064/optimized_control_profiles.svg`
- Workspace control table:
  `repro/generated/dynamic_control_objective_leverage_reward5_reg0p02_iter13_734064/optimized_control_values.csv`
- Workspace summary:
  `repro/generated/dynamic_control_objective_leverage_reward5_reg0p02_iter13_734064/optimized_control_summary.csv`

`734122` result:
- Variant: `reward1_scale1mg_reg0p02_iter13`, relaunched on `n14`.
- Slurm state: `COMPLETED`.
- Solver status: `ITERATION_LIMIT`.
- Primal status: `NEARLY_FEASIBLE_POINT`.
- `selected_candidate_source=post_solve_values`.
- `post_solve_candidate_residual_feasible=true`.
- `selected_candidate_residual_feasible=true`.
- `selected_candidate_trajectory_ready=false`.
- Objective improved to `270.7409045410` with
  `dynamic_control_objective_terminal_state_scale_g_L=0.001`.
- Residuals stayed on the accepted frontier:
  - `max_rhs_residual=2.1053823616e-8`;
  - `max_mass_balance_residual=8.2097005816e-7`;
  - `max_collocation_integration_residual=0.0701280246`;
  - `max_continuity_residual=0.0702064359`.
- Control movement was still materially unchanged:
  - maximum temperature movement `1.0284423912e-3` degC;
  - FDA total `7.8929459248e-8` g/L;
  - organic total `0.3998839600` g/L;
  - organic maximum movement `1.1609614928e-4` g/L.
- Interpretation: scaling the terminal aroma proxy to mg/L changes objective
  magnitude substantially while preserving residual feasibility, but it still
  does not unlock meaningful accepted control movement under `max_iter=13` and
  the current feasibility-handoff recipe.

Generated diagnostics for `734122`:
- Workspace plot:
  `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter13_734122/optimized_control_profiles.png`
- Workspace vector plot:
  `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter13_734122/optimized_control_profiles.svg`
- Workspace control table:
  `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter13_734122/optimized_control_values.csv`
- Workspace summary:
  `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter13_734122/optimized_control_summary.csv`

Parallel wave close:
- `734115`, variant `reward1_scale1mg_reg0p05_iter13`, was cancelled at about
  `2026-06-14 20:03` Chile time after `734122` completed.
- Rationale: `734122` used the same mg/L terminal scale with weaker reference
  regularization (`0.02`) and still did not produce meaningful accepted control
  movement. The stronger-regularization `734115` case was therefore unlikely
  to add decision value and was consuming resources without a final artifact.
- After cancelling `734115`, `squeue -u "$USER"` was empty.
- Scientific conclusion for this wave: changing aroma reward magnitude,
  lowering reference regularization from `0.05` to `0.02`, and scaling the
  terminal aroma proxy from `0.1` g/L to `0.001` g/L all preserve the accepted
  residual-feasible post-solve frontier, but they still leave optimized
  controls effectively pinned to the reference trajectory at `max_iter=13`.
- Next technical direction should not be another pure weight sweep. The next
  useful experiment should change the optimizer search recipe while keeping
  residual gates: for example, a guarded higher-iteration mg/L run, weaker or
  staged reference regularization, or a diagnostic of objective/control
  sensitivities under the simultaneous constraints.

Next methodology wave:
- `734219`, variant `reward1_scale1mg_reg0_iter13`, was submitted to `n14`.
  Purpose: test whether reference regularization itself is pinning controls by
  removing it while keeping the accepted `max_iter=13` frontier.
- `734220`, variant `reward1_scale1mg_reg0p02_iter14`, was submitted to `n14`.
  Purpose: test whether one guarded extra Ipopt iteration is needed before
  controls can move under the mg/L-scale objective.
- Both jobs use `8` CPUs, `OPENBLAS_NUM_THREADS=1`, MA86, limited-memory
  Hessian, no GPU, and the same residual-gated feasibility-handoff recipe.

`734219` result:
- Variant: `reward1_scale1mg_reg0_iter13`.
- Slurm state: `COMPLETED`.
- Solver status: `ITERATION_LIMIT`.
- `post_solve_candidate_residual_feasible=true`.
- `selected_candidate_source=post_solve_values`.
- `selected_candidate_residual_feasible=true`.
- `selected_candidate_trajectory_ready=false`.
- Objective `270.7409029928`.
- `max_mass_balance_residual=8.2097017184e-7`.
- Removing reference regularization still left controls materially pinned:
  maximum temperature movement `1.0284424072e-3` degC, FDA total
  `7.8929459441e-8` g/L, and organic total `0.3998839600` g/L.

`734220` result:
- Variant: `reward1_scale1mg_reg0p02_iter14`.
- Slurm state: `COMPLETED`.
- Solver status: `ITERATION_LIMIT`.
- `post_solve_candidate_residual_feasible=false`.
- `selected_candidate_source=pre_solve_start_values`.
- `selected_candidate_residual_feasible=true`.
- `selected_candidate_trajectory_ready=false`.
- Objective `270.7374904870`.
- `max_mass_balance_residual=1.0691392536e-6`, above the
  `1.0e-6` post-solve gate.
- Because the selected candidate fell back to pre-solve starts, the generated
  selected-control plots for `734220` show zero movement and should not be
  interpreted as an accepted optimized control profile.
- Interpretation: one extra Ipopt iteration improves objective but crosses the
  mass-balance gate, matching the earlier non-scaled iter14 frontier behavior.
  The next useful question is whether the rejected post-solve point contains
  meaningful control movement that can be repaired, or whether movement remains
  negligible even beyond iter13.

Generated diagnostics:
- `734219` plot:
  `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0_iter13_734219/optimized_control_profiles.png`
- `734219` summary:
  `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0_iter13_734219/optimized_control_summary.csv`
- `734220` plot:
  `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_734220/optimized_control_profiles.png`
- `734220` summary:
  `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_734220/optimized_control_summary.csv`

Post-solve rejected-control instrumentation:
- The solve-attempt metadata now preserves dynamic-control values for both
  pre-solve and post-solve candidates using prefixed keys, even when the
  post-solve candidate is rejected and selected values fall back to pre-solve.
- The attempt CSV now includes scalar deltas:
  - `post_solve_candidate_dynamic_control_delta_vs_pre_solve_available`;
  - `post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve`;
  - `post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve`;
  - `post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve`.
- `734285` repeats `reward1_scale1mg_reg0p02_iter14` on `n14` with the new
  instrumentation. Purpose: determine whether rejected iter14 post-solve values
  actually move controls before failing the mass-balance gate.

Parallel wave pruning:
- `734087` was cancelled at `2026-06-14 18:30` Chile time before producing
  case artifacts or an attempt CSV. It should not be used for scientific
  comparison.
- `734100` was also cancelled before producing case artifacts or an attempt
  CSV. It should not be used for scientific comparison.
- Rationale: `n8` had three Julia jobs in startup at once. To avoid inefficient
  resource reservation and a possible memory pile-up if several 168 h NLPs
  entered Ipopt simultaneously, the wave was reduced to one old-scale run on
  `n8` plus one mg/L-scale run.
- Relaunched conservative mg/L-scale run:
  - job `734115`;
  - variant `reward1_scale1mg_reg0p05_iter13`;
  - node `n8`;
  - `8` CPUs, `24G`, no GPU;
  - run root
    `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p05_iter13_20260614_183135`;
  - header confirmed
    `dynamic_control_objective_terminal_state_scale_g_L=0.001`,
    MA86, cluster HSL path, limited-memory Hessian,
    `OPENBLAS_NUM_THREADS=1`, and `feasibility_handoff`.
- `734088`, variant `reward5_reg0p05_iter13`, was later cancelled before
  producing an attempt CSV. Rationale: after `734064`, this old-scale run was
  lower-value than the mg/L-scale tests, and `n8` memory headroom was shrinking
  while two NLPs were approaching the heavy solve phase. Do not use `734088`
  for scientific comparison.

Completed leverage result, weak-regularization old-scale:
- `734064`, variant `reward5_reg0p02_iter13`, completed on `n14`.
- Result:
  - solver status `ITERATION_LIMIT`;
  - primal status `NEARLY_FEASIBLE_POINT`;
  - objective `271.2284403599471`;
  - `selected_candidate_source=post_solve_values`;
  - `post_solve_candidate_residual_feasible=true`;
  - `selected_candidate_residual_feasible=true`;
  - `selected_candidate_trajectory_ready=false`.
- Residuals:
  - `max_rhs_residual=2.1053823616e-8`;
  - `max_mass_balance_residual=8.2097017184e-7`;
  - `max_lower_bound_violation=7.3674393197e-8`;
  - `max_upper_bound_violation=4.7288681055e-9`;
  - `max_stationarity_residual=2.8928443355e-12`;
  - `max_lower_complementarity_residual=9.9032465675e-4`;
  - `max_upper_complementarity_residual=1.2967942576e-5`;
  - `max_collocation_integration_residual=0.0701280246`;
  - `max_continuity_residual=0.0702064359`.
- Control movement:
  - max temperature delta `0.0010284424 C`;
  - FDA sum `7.8929459308e-8 g/L`;
  - organic sum `0.3998839599958 g/L`;
  - max organic delta `0.00011609615 g/L`.
- Interpretation:
  - Increasing reward to `5` and lowering reference regularization to `0.02`
    improved the reported objective while preserving the residual-feasible
    post-solve gate.
  - It still did not produce meaningful accepted control movement, and it
    remains non-promotable as a trajectory seed because
    `selected_candidate_trajectory_ready=false`.
  - This supports the mg/L terminal-state scaling hypothesis more strongly than
    more old-scale reward escalation.
- Generated diagnostics:
  - `repro/generated/dynamic_control_objective_leverage_reward5_reg0p02_iter13_734064/optimized_control_profiles.png`
  - `repro/generated/dynamic_control_objective_leverage_reward5_reg0p02_iter13_734064/optimized_control_profiles.svg`
  - `repro/generated/dynamic_control_objective_leverage_reward5_reg0p02_iter13_734064/optimized_control_values.csv`
  - `repro/generated/dynamic_control_objective_leverage_reward5_reg0p02_iter13_734064/optimized_control_summary.csv`
  - aggregate:
    `repro/generated/dynamic_control_objective_pilot_summary.csv`

Additional active mg/L run:
- `734122`, variant `reward1_scale1mg_reg0p02_iter13`, started on `n14`
  after `734064` completed.
- Header confirmed `dynamic_control_objective_terminal_state_scale_g_L=0.001`,
  reference regularization `0.02`, MA86, cluster HSL, limited-memory Hessian,
  `OPENBLAS_NUM_THREADS=1`, and `feasibility_handoff`.

Reconnect and parallel residual-rescue wave:
- Slurm was reachable again at `2026-06-14 21:24` Chile time.
- Active instrumented repeat:
  - job `734285`;
  - variant `reward1_scale1mg_reg0p02_iter14`;
  - node `n14`;
  - purpose: capture rejected post-solve dynamic-control deltas after the
    non-promotable `734220` result.
- New conservative parallel job:
  - job `734311`;
  - variant `reward1_scale1mg_reg0p02_iter14_repair12_compflux1`;
  - node `n8`;
  - `8` CPUs, `24G`, no GPU;
  - run root
    `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_repair12_compflux1_20260614_212605`;
  - same mg/L-scale objective as `734285`, with
    `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER=12` and
    `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION=1`;
  - purpose: test whether the `iter14` mass/residual rejection can be rescued
    without changing objective weights.
- Tooling update:
  - `scripts/main_plot_dynamic_control_mpcc_pilot.py` now writes and plots
    `post_solve_value` / `post_solve_delta` when rejected post-solve control
    metadata exist.
  - `scripts/main_summarize_dynamic_control_mpcc_pilots.py` includes `734311`
    and exposes post-solve control movement summaries.

Instrumented iter14 post-solve delta result:
- `734285`, variant `reward1_scale1mg_reg0p02_iter14`, completed on `n14`.
- Result:
  - solver status `ITERATION_LIMIT`;
  - primal status `NEARLY_FEASIBLE_POINT`;
  - objective `270.7374904862815`;
  - `selected_candidate_source=pre_solve_start_values`;
  - `selected_candidate_residual_feasible=true`;
  - `selected_candidate_trajectory_ready=false`;
  - `post_solve_candidate_residual_feasible=false`;
  - `post_solve_candidate_rejection_reason=not_residual_feasible`.
- Residuals:
  - `max_mass_balance_residual=1.069138798566632e-6`;
  - `max_collocation_integration_residual=0.07009520233639652`;
  - `max_continuity_residual=0.07019885798317763`;
  - dominant residual `max_continuity_residual`.
- Rejected post-solve control movement vs pre-solve:
  - max temperature movement `0.0010280384958107902 C`;
  - FDA sum delta `7.684206750828475e-8 g/L`;
  - organic sum delta `-0.00011914849009708739 g/L`;
  - max organic movement `0.00011920268603676787 g/L`.
- Interpretation:
  - The rejected post-solve point did move controls, but only at microscopic
    scale.
  - More reward/regularization scalar sweeps are unlikely to unlock meaningful
    profile optimization by themselves.
  - The active `734311` residual-rescue run remains useful: if it accepts the
    post-solve point, we will know whether repair can make `iter14` promotable;
    if not, the next technical step should be objective/control sensitivity
    diagnostics rather than simply increasing Ipopt iterations.
- Generated diagnostics:
  - `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_20260614_210120/plots/optimized_control_profiles.png`
  - `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_734285/optimized_control_profiles.png`

Objective leverage diagnostic:
- Added `scripts/main_diagnose_dynamic_control_objective_leverage.py`.
- Diagnostic output for `734285`:
  - `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_734285/objective_diagnostics/dynamic_control_objective_leverage_diagnostics.csv`
  - `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_734285/objective_diagnostics/dynamic_control_objective_leverage_diagnostics.md`
- Key scale calculations:
  - terminal reward coefficient is `1000 objective/(g/L target)`;
  - representative full-trust target gain needed:
    - temperature: `1.9966517857142857e-05 g/L`;
    - FDA: `3.0e-05 g/L`;
    - organic: `2.4e-05 g/L`.
- Interpretation:
  - These offsets are only about `0.02-0.03 mg/L` of the current
    `isoamyl_alcohol` proxy.
  - Since post-solve movement is still microscopic, the current objective is
    probably not seeing useful control sensitivity through the simultaneous
    dynamics, or the search is being dominated by feasibility/regularization.
  - This reinforces that the next development step after `734311` should be a
    controlled sensitivity/proxy redesign, not simply larger scalar weights.

Target-state caveat for the dynamic objective:
- Repo search confirms that the reduced state vector exposes
  `isoamyl_alcohol` and `ethyl_acetate`, but not an explicit
  `isoamyl_acetate` state.
- `Antecedentes/Files_Cristobal/main_simulation.m` maps `aroma_isoamyl` to
  `r_1862` and assigns `MW_aroma_isoamyl = 0.08815`, consistent with isoamyl
  alcohol rather than isoamyl acetate.
- `Antecedentes/Files_Cristobal/Functions/ode_dfvb_zenteno.m` contains a
  comment saying `isoamyl_acetate`, but the active reduced exports and
  molecular weight evidence support treating the current target as an isoamyl
  alcohol proxy.
- Implication: a serious isoamyl acetate optimization objective should either
  introduce/derive an explicit acetate proxy from available fluxes/states or
  switch to a defensible aroma blend objective over the currently exported
  aroma states.

White-wine aroma blend implementation:
- Added simultaneous objective target `white_wine_aroma_blend`.
- The blend rewards the available reduced aroma states with smooth linear
  terminal terms normalized by first-pass white-wine windows:
  `phenylethanol`, `isoamyl_alcohol`, `isobutanol`, `methionol`, `tyrosol`,
  and `ethyl_acetate`.
- Existing single-target behavior is preserved; `isoamyl_acetate` still maps
  to the previous `isoamyl_alcohol` proxy unless the target is explicitly set
  to `white_wine_aroma_blend`.
- Added CSV/stdout metadata for target component count/names/weights/scales.
- New pilot:
  - job `734383`;
  - variant `blend_reg0p02_iter13`;
  - node `n14`;
  - `8` CPUs, `32G`, no GPU;
  - run root
    `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_blend_reg0p02_iter13_20260614_223100`;
  - target override
    `MPCC_DYNAMIC_CONTROL_OBJECTIVE_TARGET_STATE=white_wine_aroma_blend`;
  - purpose: test the blend target at the accepted `iter13` feasibility
    frontier while `734311` continues testing residual rescue.

Active job snapshot at `2026-06-14 23:19 -04`:
- `734311` remains running on `n8`, elapsed about `1:53`, no attempt CSV yet.
  Julia is active at about `131%` CPU with RSS about `4.37 GB`; keep running
  unless it errors, OOMs, or reaches a clearly unproductive state.
- `734383` remains running on `n14`, elapsed about `48 min`, no attempt CSV
  yet. Julia is active at about `116%` CPU with RSS about `9.24 GB` under a
  `32G` reservation; keep running.

Reconnect and integrated aroma-production objective, `2026-06-15 00:02 -04`:
- Reconnected to Slurm after an unstable client connection.
- Active jobs at reconnect:
  - `734311`, `reward1_scale1mg_reg0p02_iter14_repair12_compflux1`, running on
    `n8`;
  - `734472`, `blend_reward10_reg0_iter13`, running on `n14`.
- Added optional simultaneous objective policy
  `MPCC_DYNAMIC_CONTROL_OBJECTIVE_AROMA_REWARD_POLICY`.
  - Default is `terminal`, preserving previous behavior.
  - New policy `terminal_plus_integrated_flux` splits the aroma reward 50/50
    between terminal aroma state concentration and a Radau quadrature integral
    of gross aroma production, `MW_aroma * flux_aroma * biomass`.
  - The integrated term is only activated when explicitly requested and is
    recorded through metadata fields
    `dynamic_control_objective_aroma_reward_policy`,
    `dynamic_control_objective_terminal_reward_effective_weight`,
    `dynamic_control_objective_integrated_aroma_reward_effective_weight`, and
    `dynamic_control_objective_integrated_aroma_reward_terms`.
- Rationale:
  - The previous terminal-only runs moved controls only microscopically even
    with stronger reward weights.
  - The reduced model already exposes aroma fluxes and the RHS computes aroma
    accumulation as `MW * flux * biomass - volatilization_loss`; rewarding
    integrated gross production gives Ipopt a more direct local objective
    signal while keeping nutrient and thermal penalties unchanged.
- Added variant:
  - `blend_integrated_reward2_reg0_iter13`;
  - target `white_wine_aroma_blend`;
  - reward weight `2.0`, terminal scale `1.0`, no reference regularization;
  - policy `terminal_plus_integrated_flux`;
  - `max_iter=13`, MA86, limited-memory Hessian, `OMP_NUM_THREADS=8`,
    `OPENBLAS_NUM_THREADS=1`.
- Submitted pilot:
  - job `734484`;
  - node `n14`;
  - `8` CPUs, `32G`, no GPU;
  - run root
    `/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_blend_integrated_reward2_reg0_iter13_20260615_000124`.
- Light validation before submit:
  - `git diff --check`;
  - `bash -n` on submit/sbatch/monitor scripts;
  - `python3 -m py_compile` on plot/summary/diagnostic Python scripts;
  - no forbidden workstation-local paths in touched cluster scripts/tooling.
- Julia tests were not run on the login node, by cluster policy.

Completed objective-leverage wave, `2026-06-15 00:50 -04`:
- Slurm status:
  - `734311` completed on `n8`, elapsed `03:11:21`, MaxRSS
    `25146284K`;
  - `734472` completed on `n14`, elapsed `00:47:45`, MaxRSS
    `20184084K`;
  - `734484` completed on `n14`, elapsed `00:46:18`, MaxRSS
    `19923944K`;
  - `squeue -u "$USER"` was empty after postprocessing.
- `734311`, iter14 repair/rescue:
  - `solver_status=ITERATION_LIMIT`,
    `primal_status=NEARLY_FEASIBLE_POINT`;
  - `candidate_selection_reason=post_solve_candidate_retained_for_diagnostics_no_residual_feasible_fallback`;
  - `selected_candidate_residual_feasible=false`;
  - `selected_candidate_trajectory_ready=false`;
  - dominant residual remained structural trajectory continuity:
    `max_collocation_integration_residual=0.12153022594427049`,
    `max_continuity_residual=0.12153022594427049`;
  - conclusion: repair_max_iter=12 plus final complementarity flux projection
    did not rescue the guarded iter14 branch into a promotable point.
- `734472`, stronger terminal blend reward:
  - target `white_wine_aroma_blend`;
  - `terminal_reward_weight=10.0`, reference regularization `0.0`;
  - `solver_status=ITERATION_LIMIT`,
    `primal_status=NEARLY_FEASIBLE_POINT`;
  - `selected_candidate_source=post_solve_values`;
  - `selected_candidate_residual_feasible=true`;
  - `selected_candidate_trajectory_ready=false`;
  - residuals matched the accepted iter13 frontier:
    `max_rhs_residual=2.1053823615872257e-8`,
    `max_mass_balance_residual=8.209700581573998e-7`,
    `max_lower_complementarity_residual=0.0009903246567589381`,
    `max_collocation_integration_residual=0.0701280246224693`,
    `max_continuity_residual=0.07020643590329433`;
  - post-solve control movement remained microscopic:
    max temperature delta `0.001028442409214847 C`,
    FDA sum delta `7.892945944057212e-8 g/L`,
    organic sum delta `-0.00011604000519899182 g/L`.
- `734484`, terminal plus integrated gross aroma-production reward:
  - target `white_wine_aroma_blend`;
  - `dynamic_control_objective_aroma_reward_policy=terminal_plus_integrated_flux`;
  - `dynamic_control_objective_integrated_aroma_reward_terms=1`;
  - effective terminal reward weight `1.0`;
  - effective integrated aroma reward weight `1.0`;
  - `solver_status=ITERATION_LIMIT`,
    `primal_status=NEARLY_FEASIBLE_POINT`;
  - `selected_candidate_source=post_solve_values`;
  - `selected_candidate_residual_feasible=true`;
  - `selected_candidate_trajectory_ready=false`;
  - residuals again matched the accepted iter13 frontier:
    `max_rhs_residual=2.1053823615756164e-8`,
    `max_mass_balance_residual=8.209701718442375e-7`,
    `max_lower_complementarity_residual=0.0009903246567447045`,
    `max_collocation_integration_residual=0.0701280246268006`,
    `max_continuity_residual=0.07020643590885878`;
  - post-solve control movement was essentially identical to `734472`:
    max temperature delta `0.0010284423824558075 C`,
    FDA sum delta `7.892945918070882e-8 g/L`,
    organic sum delta `-0.00011604000275422521 g/L`.
- Generated plots and summaries:
  - `repro/generated/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_repair12_compflux1_734311/optimized_control_profiles.png`
  - `repro/generated/dynamic_control_objective_leverage_blend_reward10_reg0_iter13_734472/optimized_control_profiles.png`
  - `repro/generated/dynamic_control_objective_leverage_blend_integrated_reward2_reg0_iter13_734484/optimized_control_profiles.png`
  - `repro/generated/dynamic_control_objective_pilot_summary.csv`
- Methodological conclusion:
  - The stable residual-feasible frontier remains the iter13 limited-memory
    recipe, but none of the terminal or integrated reward variants produced
    meaningful control movement.
  - The bottleneck is no longer just objective scalarization; the current
    simultaneous MPCC path is still pinned near the fixed-control reference by
    feasibility/trajectory residual structure.
  - Next technical step should be a promotable fixed-control/trajectory-ready
    repair or a continuation formulation that reduces the
    `max_collocation_integration_residual` and `max_continuity_residual`
    before trying more aggressive dynamic-control objectives.
