# Fixed-Control MPCC Mesh/Repair Diagnostics, 2026-06-10

Goal: reduce and explain the fixed-control MPCC collocation defect before
freeing temperature or nutrient controls. All Julia/Ipopt work was run through
Slurm on the UC cluster.

Baseline policy:

- `cool18_warm22__springferm_early_0p4`
- MA86 with cluster HSL:
  `/home/cltorrealba/opt/hsl/libhsl-2025.7.21/lib/libhsl.so`
- limited-memory Hessian
- Scholtes `tau = 20`
- strict Ipopt warm-start pushes/fracs at `1e-12`
- `OPENBLAS_NUM_THREADS=1`
- no GPU

## Implementation

Added a Slurm sweep driver:

- `repro/cluster_uc_fixed_control_solve_attempt_sweep.sbatch`

Extended the fixed-control solve-attempt entrypoint:

- case-aware summary columns (`case_id`, horizon, `nfe`, `max_iter`, grid
  element length);
- collocation repair controls:
  - `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER`
  - `MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TOL`
- residual localization output:
  - `reduced_mpcc_fixed_control_policy_residual_locations.csv`

The reduced MPCC solve-attempt builder now forwards
`collocation_consistent_state_start_max_iterations` and
`collocation_consistent_state_start_tolerance` into the collocation-consistent
start repair. Defaults remain unchanged: `4` iterations and `1e-10`.

## Slurm Evidence

Run root:

`/home/cltorrealba/mpcc_runs/dynamic_control_fixed_mesh_sweep_20260610_200831`

Contract checks:

- `728541`: entrypoint plus sweep sbatch contract passed.
- `728572`: contract passed after residual-localization extension.

Mesh/start smoke:

| Job | Case | Result |
| --- | --- | --- |
| `728542` | `12h/nfe=4/max_iter=0` | residual-feasible; collocation `6.83e-7` |
| `728542` | `12h/nfe=8/max_iter=0` | residual-feasible; collocation `2.88e-7` |
| `728542` | `24h/nfe=4/max_iter=0` | not feasible; collocation `9.84e-2` |
| `728542` | `24h/nfe=8/max_iter=0` | not feasible; collocation `2.30e-3` |
| `728558` | `24h/nfe=12/max_iter=0` | not feasible; collocation `2.46e-3` |
| `728558` | `24h/nfe=16/max_iter=0` | not feasible; collocation `4.82e-4` |

Localization:

- `728576`: `24h/nfe=16/max_iter=0` with residual-location CSV.
- largest residual: glucose at `t = 21 h`, element `14`, collocation `3`,
  residual `4.82e-4`.
- top residuals are mainly glucose/ethanol between `18 h` and `24 h`.

Repair experiments on `24h/nfe=16`:

| Job | Repair setup | Result |
| --- | --- | --- |
| `728589` | `max_iter=12`, no final refresh | collocation `4.12e-4`; marginal improvement |
| `728603` | final state refresh | collocation `~7e-15`, but RHS `6.04e-5` and bound/complementarity `~4e-5` |
| `728622` | final state refresh + flux projection | RHS `0`, collocation `1.03e-4`, lower comp `2.61e-5` |
| `728611` | final state refresh + flux projection + dual fit | rejected; complementarity explodes to `~10` |
| `728629` | same as `728622`, repair max `30`, trace enabled | monotone guard stops after iteration 2; no improvement beyond `1.03e-4` |
| `728637` | final state refresh, Ipopt `max_iter=25` | rejected; RHS remains `6.04e-5`, complementarity worsens to `~4e-4` |

Short-horizon control:

- `728644`: `12h/nfe=8`, pre-solve guard enabled, Ipopt `max_iter=25`.
- It starts from a residual-feasible pre-solve point but Ipopt worsens
  complementarity (`5.93e-3`), so post-solve candidate is rejected.

## Interpretation

The 24 h defect is not solved by blindly increasing uniform `nfe`. It is
localized in the sugar/ethanol transition region, especially `18 h` to `24 h`.

The collocation-consistent repair has two useful but incomplete modes:

- default monotone repair preserves KKT/FBA starts but leaves a tail
  collocation defect;
- final state refresh eliminates collocation/continuity but breaks RHS/bound
  consistency enough that the candidate still fails residual thresholds.

Letting Ipopt polish these starts is not yet reliable. In both the 12 h
positive-control and 24 h refresh case, solver iterations can worsen
complementarity even when the pre-solve point is structurally close.

## Methodological Decision

Do not free dynamic controls yet, and do not push exact Hessian or lower tau
from this line. The next useful development is structural start repair, not
more brute-force solver iterations.

Recommended next step:

1. implement a sugar/ethanol-aware tail repair that applies final state refresh
   only on selected tail elements and immediately refreshes RHS derivatives and
   flux starts without dual fitting;
2. compare tail-only repairs on elements covering `18 h` to `24 h`;
3. accept a fixed-control candidate only when residual-feasible and
   trajectory-ready semantics are restored.
