# Sequential 168 h YAN 200 experiment

Date: 2026-06-07
Branch: `workstation_cii`

## Purpose

Run a reduced sequential DFBA 168 h experiment with an initial YAN equivalent of
200 mgN/L while preserving the default amino-acid initial states and assigning
the remaining nitrogen to the free/ammonium nitrogen state.

This is a condition-initialization diagnostic. It is not yet a promoted MPCC
handoff seed.

## Code change

Added an environment-driven initial-state option for reduced sequential scripts:

- `DFBA_INITIAL_YAN_MGN_L`
- `DFBA_INITIAL_YAN_POLICY=ammonium_balance`

The `ammonium_balance` policy keeps the default amino-acid states unchanged,
estimates their nitrogen equivalent as `sum(amino_acids) * MW_N`, and sets the
free nitrogen state to:

```text
target_YAN_gN_L - amino_acid_nitrogen_equivalent_gN_L
```

For `DFBA_INITIAL_YAN_MGN_L=200`, the exported run used:

```text
initial_free_nitrogen_gN_L = 0.1300000175
initial_amino_acid_nitrogen_equivalent_mgN_L = 69.9999825
initial_total_yan_equivalent_mgN_L = 200.0
```

## Slurm run

Job:

```text
724385
```

Command environment:

```text
DFBA_RUN_TARGET_TAG=sequential_reduced_168h_YAN200_ammonium_freeN_thr1e4
DFBA_INITIAL_YAN_MGN_L=200
DFBA_INITIAL_YAN_POLICY=ammonium_balance
DFBA_PHASE_PROXY_MODE=free_nitrogen
DFBA_TURNOVER_THRESHOLD=1e-4
OMP_NUM_THREADS=4
OPENBLAS_NUM_THREADS=1
JULIA_NUM_THREADS=1
```

Output:

```text
/home/cltorrealba/mpcc_runs/sequential_reduced_168h_YAN200_ammonium_freeN_thr1e4_highs_724385_20260607_230944
```

Plots:

```text
/home/cltorrealba/mpcc_runs/sequential_reduced_168h_YAN200_ammonium_freeN_thr1e4_highs_724385_20260607_230944/plots
```

## Results

Run status:

```text
retcode = Success
termination_reason = completed_tspan
final_time = 168.0 h
max_mass_balance_residual = 2.658318010162475e-12
max_lower_bound_violation = 1.7032187292487233e-13
max_upper_bound_violation = 1.1368683772161603e-13
```

Phase transition:

```text
growth -> turnover at 28.0 h
nitrogen <= 1e-4 at 28.0 h
```

Comparison against the previous corrected free-nitrogen reference:

| run | initial free N gN/L | transition h | final biomass | final total sugar | sugar consumed | final ethanol |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| default freeN 168 h | 0.0700000000 | 24.0 | 1.7789942124 | 116.4228908645 | 103.5771091355 | 48.6829511660 |
| YAN 200 ammonium balance | 0.1300000175 | 28.0 | 2.4625428047 | 89.3876381139 | 130.6123618861 | 61.1046692962 |

Selected time points:

| run | time h | biomass | free N | total sugar | ethanol |
| --- | ---: | ---: | ---: | ---: | ---: |
| default | 0.0 | 0.500000 | 0.070000000 | 220.000000 | 0.000000 |
| default | 24.0 | 1.778994 | 9.99987398e-5 | 207.507746 | 5.456956 |
| default | 28.0 | 1.778994 | 9.99987398e-5 | 204.029813 | 7.122099 |
| default | 72.0 | 1.778994 | 9.99987398e-5 | 171.156733 | 22.800425 |
| default | 168.0 | 1.778994 | 9.99987398e-5 | 116.422891 | 48.682951 |
| YAN 200 | 0.0 | 0.500000 | 0.130000018 | 220.000000 | 0.000000 |
| YAN 200 | 24.0 | 2.338530 | 0.007316813 | 203.219600 | 7.222518 |
| YAN 200 | 28.0 | 2.462543 | 9.99983989e-5 | 201.596372 | 8.013999 |
| YAN 200 | 72.0 | 2.462543 | 9.99983989e-5 | 158.369021 | 28.600895 |
| YAN 200 | 168.0 | 2.462543 | 9.99983989e-5 | 89.387638 | 61.104669 |

## Interpretation

Increasing initial YAN equivalent to 200 mgN/L by adding ammonium/free nitrogen
extends growth by 4 h, increases biomass, and makes the later sugar consumption
faster. At 168 h the YAN 200 run consumes about 27.0 g/L more sugar and produces
about 12.4 g/L more ethanol than the previous corrected freeN run.

This supports using explicit initial YAN configuration for future sequential
references before building MPCC seeds from them.
