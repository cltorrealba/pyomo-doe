using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")

model = load_full_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Full reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

tfinal = _script_env_float("DFBA_FULL_TFINAL_HOURS", 0.25)
saveat = _script_env_float("DFBA_FULL_SAVEAT_HOURS", 0.25)
reconstruct_fluxes = _script_env_bool("DFBA_FULL_RECONSTRUCT_FLUXES", false)

result = simulate_full_dfba(
    model,
    reaction_map;
    tspan = (0.0, tfinal),
    saveat = saveat,
    reconstruct_fluxes = reconstruct_fluxes,
)
summary = summarize_simulation(result)

println("Sequential full DFBA short simulation report")
println("This is a short full ODE smoke path. Long full simulations are not default.")
println("model_id: $(model.model_id)")
println("model_scope: $(summary["model_scope"])")
println("algorithm: $(summary["algorithm"])")
println("smoke_tspan: $(summary["initial_time"]) to $(summary["final_time"]) h")
println("saved_time_points: $(summary["n_saved_points"])")
println("retcode: $(summary["retcode"])")
println("termination_reason: $(summary["termination_reason"])")
println("final_time: $(summary["final_time"])")
println("final_biomass: $(summary["final_biomass"])")
println("final_glucose: $(summary["final_glucose"])")
println("final_fructose: $(summary["final_fructose"])")
println("final_total_sugar: $(summary["final_total_sugar"])")
println("final_ethanol: $(summary["final_ethanol"])")
println("final_oxygen: $(summary["final_oxygen"])")
println("reconstruct_fluxes: $(summary["reconstruct_fluxes"])")
println("simulation_elapsed_seconds: $(summary["simulation_elapsed_seconds"])")
println("ode_solve_elapsed_seconds: $(summary["ode_solve_elapsed_seconds"])")
println("rhs_elapsed_seconds: $(summary["rhs_elapsed_seconds"])")
println("history_reconstruction_elapsed_seconds: $(summary["history_reconstruction_elapsed_seconds"])")
println("rhs_call_count: $(summary["rhs_call_count"])")
println("rhs_lp_solve_count: $(summary["rhs_lp_solve_count"])")
println("flux_reconstruction_solve_count: $(summary["flux_reconstruction_solve_count"])")
println("total_lp_solve_count: $(summary["total_lp_solve_count"])")
println("oxygen_derivative_policy: $(summary["oxygen_derivative_policy"])")
println("oxygen_exchange_present: $(result.metadata["oxygen_exchange_present"])")
println("oxygen_exchange_closed: $(result.metadata["oxygen_exchange_closed"])")
println("r0001_used_as_oxygen: $(result.metadata["r0001_used_as_oxygen"])")
println("indices_reacciones_used: $(result.metadata["indices_reacciones_used"])")
println("carbohydrate_derivative_policy: $(summary["carbohydrate_derivative_policy"])")
