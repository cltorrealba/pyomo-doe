using FermentationDFBA
import MathOptInterface as MOI

const FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE = 1.0e-6

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")

model = load_full_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Full reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

state = default_zenteno_initial_state()
y = zenteno_state_to_vector(state)
result = compute_dfba_rhs(model, reaction_map, y; atol = 1.0e-8)

result.fba.status == MOI.OPTIMAL || error("Full sequential DFBA RHS solve did not terminate as optimal. Status: $(result.fba.status)")
result.fba.mass_balance_residual <= FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE || error(
    "Mass-balance residual $(result.fba.mass_balance_residual) exceeds tolerance $FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE",
)
result.fba.max_lower_bound_violation <= FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE || error(
    "Lower-bound violation $(result.fba.max_lower_bound_violation) exceeds tolerance $FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE",
)
result.fba.max_upper_bound_violation <= FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE || error(
    "Upper-bound violation $(result.fba.max_upper_bound_violation) exceeds tolerance $FULL_DFBA_RHS_DIAGNOSTIC_TOLERANCE",
)

get(result.metadata, "oxygen_exchange_closed", false) == true || error(
    "Full sequential DFBA RHS expected r_1992 to be present and closed by bounds.",
)

function _full_rhs_flux_value(model, result::DFBARHSResult, rxn_id::AbstractString)
    cleaned_id = strip(String(rxn_id))
    has_reaction(model, cleaned_id) || return "missing"
    isempty(result.fba.fluxes) && return "missing"
    return string(result.fba.fluxes[reaction_index(model, cleaned_id)])
end

biomass_flux = result.fluxes_by_rxn["r_2111"]

println("Sequential full DFBA RHS smoke report")
println("This is a single RHS smoke evaluation; use scripts/main_simulate_full_dfba.jl for the short full ODE smoke path.")
println("model_scope: full")
println("model_id: $(model.model_id)")
println("metabolites: $(length(model.met_ids))")
println("reactions: $(length(model.rxn_ids))")
println("mode: $(result.mode)")
println("solver_status: $(result.fba.status)")
println("weighted_objective_value: $(result.fba.objective_value)")
println("objective_type: $(result.metadata["objective_type"])")
println("n_objective_terms: $(result.metadata["n_objective_terms"])")
println("solved_biomass_flux_r_2111: $biomass_flux")
println("dy[1] biomass: $(result.dy[1])")
println("dy[6] oxygen: $(result.dy[6])")
println("dy[8] carbohydrate: $(result.dy[8])")
println("mass_balance_residual: $(result.fba.mass_balance_residual)")
println("max_lower_bound_violation: $(result.fba.max_lower_bound_violation)")
println("max_upper_bound_violation: $(result.fba.max_upper_bound_violation)")

println("selected_fluxes:")
for rxn_id in ("r_2111", "r_1714", "r_1709", "r_1761", "r_1992", "r_4046", "r_4047", "r_4048")
    println("  $rxn_id = $(_full_rhs_flux_value(model, result, rxn_id))")
end

println("oxygen_derivative_policy: $(result.metadata["oxygen_derivative_policy"])")
println("oxygen_exchange_reaction_id: $(result.metadata["oxygen_exchange_reaction_id"])")
println("oxygen_exchange_present: $(result.metadata["oxygen_exchange_present"])")
println("oxygen_exchange_closed: $(result.metadata["oxygen_exchange_closed"])")
println("oxygen_exchange_lb: $(result.metadata["oxygen_exchange_lb"])")
println("oxygen_exchange_ub: $(result.metadata["oxygen_exchange_ub"])")
println("r0001_used_as_oxygen: $(result.metadata["r0001_used_as_oxygen"])")
println("carbohydrate_derivative_policy: $(result.metadata["carbohydrate_derivative_policy"])")
println("indices_reacciones_used: $(result.metadata["indices_reacciones_used"])")
println("carbohydrate_note: r_4048 may be reported as a flux, but dy[8] remains empirical and not r_4048 flux-driven.")
