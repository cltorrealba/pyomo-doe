using FermentationDFBA

include("ode_script_helpers.jl")

project_root = normpath(joinpath(@__DIR__, ".."))

function _replacement_env_dirs(name::AbstractString)::Vector{String}
    raw = strip(get(ENV, String(name), get(ARGS, 2, "")))
    isempty(raw) && error("Set $name or pass selective refinement directories as the second argument.")
    normalized = replace(raw, ';' => ',')
    dirs = [strip(item) for item in split(normalized, ",") if !isempty(strip(item))]
    return [
        isabspath(dir) ? normpath(dir) : normpath(joinpath(project_root, dir)) for dir in dirs
    ]
end

artifact_dir_raw = strip(get(ENV, "MPCC_REPLACEMENT_ARTIFACT_DIR", get(ARGS, 1, "")))
isempty(artifact_dir_raw) && error(
    "Set MPCC_REPLACEMENT_ARTIFACT_DIR or pass the artifact directory as the first argument.",
)
artifact_dir = isabspath(artifact_dir_raw) ?
    normpath(artifact_dir_raw) :
    normpath(joinpath(project_root, artifact_dir_raw))

selective_refinement_dirs = _replacement_env_dirs("MPCC_REPLACEMENT_SELECTIVE_DIRS")
output_dir = _script_output_dir(
    project_root,
    "MPCC_REPLACEMENT_OUTPUT_DIR",
    joinpath(artifact_dir, "selective_replacement"),
)
overwrite = _script_env_bool("MPCC_REPLACEMENT_OUTPUT_OVERWRITE", true)
replacement_policy = strip(get(ENV, "MPCC_REPLACEMENT_POLICY", "trajectory_ready"))
include_left_boundary = _script_env_bool("MPCC_REPLACEMENT_INCLUDE_LEFT_BOUNDARY", false)

result = apply_reduced_dcdfba_mpcc_windowed_selective_replacement_artifacts(
    artifact_dir,
    selective_refinement_dirs;
    replacement_policy = replacement_policy,
    include_left_boundary = include_left_boundary,
)

paths = write_reduced_dcdfba_mpcc_windowed_selective_replacement_report(
    result,
    output_dir;
    overwrite = overwrite,
)

println("Reduced MPCC windowed selective replacement")
println("artifact_dir: $(artifact_dir)")
println("selective_refinement_dirs: $(join(selective_refinement_dirs, ","))")
println("output_dir: $(output_dir)")
println("replacement_policy: $(result.metadata["replacement_policy"])")
println("include_left_boundary: $(result.metadata["include_left_boundary"])")
println("n_candidate_replacements: $(result.metadata["n_candidate_replacements"])")
println("n_applied_replacements: $(result.metadata["n_applied_replacements"])")
println("n_updated_timepoints: $(result.metadata["n_updated_timepoints"])")
println("source_global_max_state_abs_difference: $(result.metadata["source_global_max_state_abs_difference"])")
println("replaced_global_max_state_abs_difference: $(result.metadata["replaced_global_max_state_abs_difference"])")
println("source_global_max_state_relative_rmse: $(result.metadata["source_global_max_state_relative_rmse"])")
println("replaced_global_max_state_relative_rmse: $(result.metadata["replaced_global_max_state_relative_rmse"])")
println("outputs_written: true")
for key in sort(collect(keys(paths)))
    println("output_$(key): $(paths[key])")
end
haskey(paths, "plot_core_states") && println("plot_core_states: $(paths["plot_core_states"])")

println("replacement_table:")
for row in eachrow(result.replacement_table)
    println(
        "  $(row["window_id"]) | applied=$(row["replacement_applied"]) | " *
        "reason=$(row["replacement_reason"]) | updated_points=$(row["updated_timepoint_count"]) | " *
        "original_tau=$(row["original_tau"]) | refined_tau=$(row["refined_tau"]) | " *
        "original_abs=$(row["original_max_state_abs_difference"]) | " *
        "refined_abs=$(row["refined_max_state_abs_difference"])",
    )
end
