const FIXED_CONTROL_ENTRYPOINT_T0 = time()

function _fixed_control_entrypoint_phase(label::AbstractString)::Nothing
    elapsed = round(time() - FIXED_CONTROL_ENTRYPOINT_T0; digits = 3)
    println("fixed_control_entrypoint_phase: $(String(label)) elapsed_seconds=$elapsed")
    flush(stdout)
    return nothing
end

_fixed_control_entrypoint_phase("start")
_fixed_control_entrypoint_phase("before_using_CSV")
using CSV
_fixed_control_entrypoint_phase("after_using_CSV")
_fixed_control_entrypoint_phase("before_using_DataFrames")
using DataFrames
_fixed_control_entrypoint_phase("after_using_DataFrames")
_fixed_control_entrypoint_phase("before_using_Dates")
using Dates
_fixed_control_entrypoint_phase("after_using_Dates")
_fixed_control_entrypoint_phase("before_using_FermentationDFBA")
using FermentationDFBA
_fixed_control_entrypoint_phase("after_using_FermentationDFBA")
_fixed_control_entrypoint_phase("before_using_TOML")
using TOML
_fixed_control_entrypoint_phase("after_using_TOML")
_fixed_control_entrypoint_phase("before_using_Serialization")
using Serialization
_fixed_control_entrypoint_phase("after_using_Serialization")

_fixed_control_entrypoint_phase("before_include_solver_backend_helpers")
include(joinpath(@__DIR__, "solver_backend_helpers.jl"))
_fixed_control_entrypoint_phase("after_include_solver_backend_helpers")
_fixed_control_entrypoint_phase("before_include_ode_script_helpers")
include(joinpath(@__DIR__, "ode_script_helpers.jl"))
_fixed_control_entrypoint_phase("after_include_ode_script_helpers")

const FIXED_CONTROL_SOLVE_ATTEMPT_SCRIPT =
    "main_reduced_mpcc_fixed_control_policy_solve_attempt.jl"
const FIXED_CONTROL_DYNAMIC_OBJECTIVE_ENV_KEYS = (
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_MODE",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TARGET_STATE",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_REWARD_WEIGHT",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_STATE_SCALE_G_L",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_WEIGHT",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TERMINAL_SUGAR_SCALE_G_L",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_WEIGHT",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_SCALE_G_L",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_POLICY",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_INTEGRATED_SUGAR_MAX_G_L",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_WEIGHT",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_FDA_WEIGHT",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_ORGANIC_WEIGHT",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_NUTRIENT_SCALE_G_L",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_THERMAL_ENERGY_WEIGHT",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_AMBIENT_TEMPERATURE_C",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SCALE_C",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_WEIGHT",
    "MPCC_DYNAMIC_CONTROL_OBJECTIVE_TEMPERATURE_SMOOTHNESS_SCALE_C",
)

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _fixed_control_env_bool(name::AbstractString, default::Bool)::Bool
    raw_value = lowercase(strip(get(ENV, String(name), string(default))))
    if raw_value in ("1", "true", "yes", "y", "on")
        return true
    elseif raw_value in ("0", "false", "no", "n", "off")
        return false
    end
    error("Environment variable $name must be boolean, got: $raw_value")
end

function _fixed_control_env_nonnegative_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value >= 0 || error("Environment variable $name must be nonnegative, got: $value")
    return value
end

function _fixed_control_env_positive_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _fixed_control_env_positive_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _fixed_control_env_nonnegative_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _fixed_control_env_positive_unit_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && 0.0 < value <= 1.0 ||
        error("Environment variable $name must be finite and in (0, 1], got: $raw_value")
    return value
end

function _fixed_control_env_path(name::AbstractString, default_relative::AbstractString)::String
    raw_value = strip(get(ENV, String(name), default_relative))
    isempty(raw_value) && error("Environment variable $name must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _fixed_control_env_optional_path(name::AbstractString)::String
    raw_value = strip(get(ENV, String(name), ""))
    isempty(raw_value) && return ""
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _fixed_control_parse_float_vector(raw_value)::Vector{Float64}
    raw_value isa Missing && return Float64[]
    values = Float64[]
    for token in split(replace(string(raw_value), ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Could not parse Float64 token '$cleaned' from '$raw_value'.")
        isfinite(value) || error("Non-finite Float64 token '$cleaned' from '$raw_value'.")
        push!(values, value)
    end
    return values
end

function _fixed_control_parse_mesh_breakpoints(raw_value)::Vector{Float64}
    values = _fixed_control_parse_float_vector(raw_value)
    isempty(values) && return Float64[]
    length(values) >= 2 || error(
        "MPCC_FIXED_CONTROL_MESH_BREAKPOINTS_HOURS must contain at least start and end times.",
    )
    all(isfinite, values) || error("MPCC_FIXED_CONTROL_MESH_BREAKPOINTS_HOURS must be finite.")
    for index in 2:length(values)
        values[index] > values[index - 1] || error(
            "MPCC_FIXED_CONTROL_MESH_BREAKPOINTS_HOURS must be strictly increasing; " *
            "got $(values[index - 1]) then $(values[index]).",
        )
    end
    return values
end

function _fixed_control_element_bounds_from_breakpoints(
    breakpoints::AbstractVector{<:Real},
)::Vector{Tuple{Float64, Float64}}
    length(breakpoints) >= 2 ||
        error("At least two mesh breakpoints are required to build element bounds.")
    return [
        (Float64(breakpoints[index]), Float64(breakpoints[index + 1])) for
        index in 1:(length(breakpoints) - 1)
    ]
end

function _fixed_control_parse_indexed_float_offsets(
    raw_value;
    max_count::Int,
    label::AbstractString,
)::Vector{Float64}
    max_count >= 0 || error("$label offset slot count must be nonnegative.")
    offsets = zeros(Float64, max_count)
    cleaned = strip(replace(string(raw_value), ';' => ','))
    normalized = lowercase(cleaned)
    (isempty(cleaned) || normalized in ("none", "0", "zero", "zeros", "off")) && return offsets

    seen = Set{Int}()
    for token in split(cleaned, ',')
        stripped = strip(token)
        isempty(stripped) && continue
        separator = occursin("=", stripped) ? "=" : occursin(":", stripped) ? ":" : ""
        isempty(separator) && error(
            "$label start offset token must look like slot=value, got '$stripped' from '$cleaned'.",
        )
        parts = split(stripped, separator; limit = 2)
        length(parts) == 2 || error(
            "$label start offset token must look like slot=value, got '$stripped' from '$cleaned'.",
        )
        index = _fixed_control_parse_positive_int_token(parts[1], cleaned)
        1 <= index <= max_count || error(
            "$label start offset slot $index is outside 1:$max_count.",
        )
        index in seen && error("$label start offset slot $index is duplicated in '$cleaned'.")
        value = tryparse(Float64, strip(parts[2]))
        value === nothing && error(
            "Could not parse $label start offset value '$(strip(parts[2]))' from '$cleaned'.",
        )
        isfinite(value) || error("$label start offset at slot $index must be finite.")
        offsets[index] = value
        push!(seen, index)
    end
    return offsets
end

function _fixed_control_apply_start_offsets(
    values::Vector{Float64},
    offsets::Vector{Float64};
    lower::Real,
    upper::Real,
    label::AbstractString,
)::Vector{Float64}
    length(values) == length(offsets) || error("$label value/offset lengths do not match.")
    lower_value = Float64(lower)
    upper_value = Float64(upper)
    lower_value <= upper_value || error("$label offset bounds must satisfy lower <= upper.")
    output = copy(values)
    for index in eachindex(output)
        proposed = output[index] + offsets[index]
        isfinite(proposed) || error("$label start offset at slot $index produced non-finite value.")
        output[index] = clamp(proposed, lower_value, upper_value)
    end
    return output
end

function _fixed_control_resized(
    values::Vector{Float64},
    length_required::Int;
    fill_value::Float64,
)::Vector{Float64}
    length_required >= 0 || error("Required vector length must be nonnegative.")
    if length(values) >= length_required
        return copy(values[1:length_required])
    end
    output = copy(values)
    append!(output, fill(fill_value, length_required - length(values)))
    return output
end

function _fixed_control_collocation_grid_saveat(
    solve_horizon_h::Real,
    nfe::Integer,
    degree::Integer,
    mesh_element_bounds = nothing,
)::Vector{Float64}
    grid =
        mesh_element_bounds === nothing ?
        build_finite_element_grid(
            (0.0, Float64(solve_horizon_h));
            nfe = Int(nfe),
            degree = Int(degree),
        ) :
        build_finite_element_grid(mesh_element_bounds; degree = Int(degree))
    times = Float64[0.0]
    for e in 1:grid.nfe
        push!(times, Float64(element_bounds(grid, e)[1]))
        for j in 1:grid.scheme.degree
            push!(times, Float64(collocation_time(grid, e, j)))
        end
        push!(times, Float64(element_bounds(grid, e)[2]))
    end
    sort!(times)
    tolerance = 100.0 * eps(Float64) * max(1.0, abs(Float64(solve_horizon_h)))
    unique_times = Float64[]
    for time_value in times
        if isempty(unique_times) || abs(time_value - unique_times[end]) > tolerance
            push!(unique_times, time_value)
        else
            unique_times[end] = max(unique_times[end], time_value)
        end
    end
    return unique_times
end

function _fixed_control_saveat_min_step(saveat)::Float64
    saveat isa AbstractVector || return Float64(saveat)
    length(saveat) <= 1 && return NaN
    return minimum(diff(Float64.(saveat)))
end

function _fixed_control_parse_positive_int_token(token::AbstractString, raw_value::AbstractString)::Int
    value = tryparse(Int, strip(token))
    value === nothing && error("Could not parse Int token '$token' from '$raw_value'.")
    value > 0 || error("Element index token '$token' from '$raw_value' must be positive.")
    return value
end

function _fixed_control_parse_liberation_indices(
    raw_value;
    max_count::Int,
    label::AbstractString,
)::Union{Nothing, Vector{Int}}
    cleaned = strip(replace(string(raw_value), ';' => ','))
    normalized = lowercase(cleaned)
    isempty(cleaned) && return nothing
    normalized in ("none", "locked", "0") && return Int[]
    normalized in ("all", "*", "full") && return collect(1:max_count)

    indices = Int[]
    for token in split(cleaned, ',')
        stripped = strip(token)
        isempty(stripped) && continue
        range_separator = occursin(":", stripped) ? ":" : occursin("-", stripped) ? "-" : ""
        if !isempty(range_separator)
            bounds = split(stripped, range_separator)
            length(bounds) == 2 || error(
                "$label liberation index range must look like 2:5 or 2-5; got: $raw_value",
            )
            first_index = _fixed_control_parse_positive_int_token(bounds[1], cleaned)
            last_index = _fixed_control_parse_positive_int_token(bounds[2], cleaned)
            first_index <= last_index || error(
                "$label liberation index range must be increasing; got: $raw_value",
            )
            append!(indices, first_index:last_index)
        else
            push!(indices, _fixed_control_parse_positive_int_token(stripped, cleaned))
        end
    end
    unique_indices = sort!(unique!(indices))
    all(index -> 1 <= index <= max_count, unique_indices) || error(
        "$label liberation indices must be in 1:$max_count, got: $raw_value",
    )
    return unique_indices
end

function _fixed_control_first_indices(count::Int, requested_count::Int)::Vector{Int}
    count <= 0 && return Int[]
    requested_count <= 0 && return Int[]
    return collect(1:min(count, requested_count))
end

function _fixed_control_liberation_indices(
    mode::AbstractString,
    explicit_raw_value;
    max_count::Int,
    requested_count::Int,
    label::AbstractString,
)::Vector{Int}
    explicit_indices = _fixed_control_parse_liberation_indices(
        explicit_raw_value;
        max_count = max_count,
        label = label,
    )
    explicit_indices !== nothing && return explicit_indices

    normalized = lowercase(strip(mode))
    normalized in ("off", "locked", "none", "fixed") && return Int[]
    normalized in ("full", "all") && return collect(1:max_count)
    normalized in ("local", "first") &&
        return _fixed_control_first_indices(max_count, requested_count)
    normalized == "explicit" && requested_count <= 0 && return Int[]
    normalized == "explicit" && error(
        "$label liberation mode is explicit, but no explicit indices were provided.",
    )
    error(
        "MPCC_DYNAMIC_CONTROL_LIBERATION_MODE must be off, locked, local, explicit, or full; got: $mode",
    )
end

function _fixed_control_index_label(indices::AbstractVector{<:Integer})::String
    isempty(indices) && return "none"
    return join(Int.(indices), ",")
end

function _fixed_control_parse_element_indices(raw_value)
    cleaned = strip(replace(string(raw_value), ';' => ','))
    normalized = lowercase(cleaned)
    isempty(cleaned) && return nothing
    normalized in ("all", "*") && return nothing

    range_separator = occursin(":", cleaned) ? ":" : occursin("-", cleaned) ? "-" : ""
    if !isempty(range_separator) && !occursin(",", cleaned)
        tokens = split(cleaned, range_separator)
        length(tokens) == 2 || error(
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_ELEMENTS must be a contiguous range like 13:16 or a comma list; got: $raw_value",
        )
        first_element = _fixed_control_parse_positive_int_token(tokens[1], cleaned)
        last_element = _fixed_control_parse_positive_int_token(tokens[2], cleaned)
        first_element <= last_element || error(
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_ELEMENTS range must be increasing; got: $raw_value",
        )
        return first_element:last_element
    end

    indices = sort!(
        unique!(
            [
                _fixed_control_parse_positive_int_token(token, cleaned) for
                token in split(cleaned, ',') if !isempty(strip(token))
            ],
        ),
    )
    isempty(indices) && return nothing
    if length(indices) > 1 && any(diff(indices) .!= 1)
        error(
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_ELEMENTS must be contiguous; got: $raw_value",
        )
    end
    return indices
end

function _fixed_control_element_indices_label(indices)::String
    indices === nothing && return "all"
    values = collect(indices)
    isempty(values) && return "all"
    length(values) == 1 && return string(first(values))
    return all(diff(values) .== 1) ? "$(first(values)):$(last(values))" : join(values, ",")
end

function _fixed_control_forward_collocation_repair_env_aliases!()
    aliases = (
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TRACE",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_RESTORE_BEST",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_RESTORE_BEST",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MONOTONE",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MONOTONE",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SCORE",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SCORE",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TRACE_SUBSTEPS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE_SUBSTEPS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_REFRESH",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_REFRESH",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_FLUX_PROJECTION",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_FLUX_PROJECTION",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION_TRIGGER_THRESHOLD",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_COMPLEMENTARITY_FLUX_PROJECTION_TRIGGER_THRESHOLD",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_DUAL_FIT",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_DUAL_FIT",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT_TRIGGER_THRESHOLD",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_SELECTIVE_DUAL_FIT_TRIGGER_THRESHOLD",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_ACCEPT_TOL",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_ACCEPT_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_DAMPING_FACTORS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_DAMPING_FACTORS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_REFRESH_RHS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_REFRESH_RHS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD_SCORE",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_AFTER_RHS_GUARD_SCORE",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_SCORE",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_SCORE",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_ACCEPT_TOL",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_GUARD_ACCEPT_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_FLUX_REFRESH_MAX_ITER",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_MAX_ITER",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TRACE_EVERY",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE_EVERY",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_STAGNATION_ITERATIONS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_STAGNATION_ITERATIONS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_STAGNATION_TOL",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_STAGNATION_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MONOTONE_ACCEPT_TOL",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MONOTONE_ACCEPT_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_DAMPING_FACTORS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_DAMPING_FACTORS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ENABLED",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ENABLED",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_ACCEPT_TOL",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ACCEPT_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_GUARD_ACCEPT_TOL",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_GUARD_ACCEPT_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_DAMPING_FACTORS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_DAMPING_FACTORS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_REFRESH_DYNAMIC_FLUX",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_REFRESH_DYNAMIC_FLUX",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_POST_TAIL_GUARD_SCORE",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_GUARD_SCORE",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_ENABLED",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_ENABLED",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_SEGMENTS",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_SEGMENTS",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_ACCEPT_TOL",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_ACCEPT_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_GUARD_ACCEPT_TOL",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_GUARD_ACCEPT_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_DAMPING_FACTORS",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_DAMPING_FACTORS",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_REFRESH_DYNAMIC_FLUX",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_REFRESH_DYNAMIC_FLUX",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_STATE_REFRESH",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_FINAL_STATE_REFRESH",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_FLUX_PROJECTION",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_FINAL_FLUX_PROJECTION",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_STATE_AFTER_RHS",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_FINAL_STATE_AFTER_RHS",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_FINAL_STATE_AFTER_RHS_REFRESH_RHS",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_FINAL_STATE_AFTER_RHS_REFRESH_RHS",
        ),
        (
            "MPCC_FIXED_CONTROL_FEASIBILITY_PROJECTION_GUARD_SCORE",
            "MPCC_GLOBAL_POLISH_FEASIBILITY_PROJECTION_GUARD_SCORE",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_ENABLED",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_ENABLED",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_ACCEPT_TOL",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_ACCEPT_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_GUARD_ACCEPT_TOL",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_GUARD_ACCEPT_TOL",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_DAMPING_FACTORS",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_DAMPING_FACTORS",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_REFRESH_DYNAMIC_FLUX",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_REFRESH_DYNAMIC_FLUX",
        ),
        (
            "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_SEGMENTS_GUARD_SCORE",
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_SEGMENTS_GUARD_SCORE",
        ),
    )
    for (fixed_name, global_name) in aliases
        haskey(ENV, fixed_name) && (ENV[global_name] = ENV[fixed_name])
    end
    return nothing
end

function _fixed_control_toml_normalize(value)
    if value isa Missing || value === nothing
        return "missing"
    elseif value isa Bool
        return value
    elseif value isa Integer
        return Int(value)
    elseif value isa Real
        return _fixed_control_toml_real(value)
    elseif value isa AbstractString
        return value
    elseif value isa AbstractVector || value isa Tuple
        return [_fixed_control_toml_normalize(item) for item in value]
    elseif value isa AbstractDict
        normalized = Dict{String, Any}()
        for key in sort!(collect(keys(value)); by = string)
            normalized[string(key)] = _fixed_control_toml_normalize(value[key])
        end
        return normalized
    end
    return string(value)
end

function _fixed_control_toml_real(value::Real)
    float_value = Float64(value)
    isfinite(float_value) && return float_value
    isnan(float_value) && return "NaN"
    float_value == Inf && return "Inf"
    float_value == -Inf && return "-Inf"
    return string(value)
end

function _fixed_control_required_columns(table::DataFrame)
    required = [
        :candidate_id,
        :temperature_values_C,
        :fda_doses_g_L,
        :organic_doses_g_L,
        :control_policy_ready,
    ]
    names_set = Set(Symbol.(names(table)))
    missing_columns = [String(column) for column in required if !(column in names_set)]
    isempty(missing_columns) || error(
        "Fixed-control policy selection CSV is missing column(s): " *
        join(missing_columns, ", "),
    )
    return nothing
end

function _fixed_control_bool(value)::Bool
    value isa Bool && return value
    value isa Missing && return false
    raw = lowercase(strip(string(value)))
    raw in ("1", "true", "yes", "y") && return true
    raw in ("0", "false", "no", "n") && return false
    return false
end

function _fixed_control_float(value)::Float64
    value isa Missing && return NaN
    parsed = tryparse(Float64, string(value))
    parsed === nothing && return NaN
    return parsed
end

function _fixed_control_int(value; default::Int = 0)::Int
    value isa Missing && return default
    parsed = tryparse(Int, string(value))
    parsed === nothing && return default
    return parsed
end

function _fixed_control_string(value; default::AbstractString = "missing")::String
    value isa Missing && return String(default)
    value === nothing && return String(default)
    return string(value)
end

function _fixed_control_join_values(value; default::AbstractString = "missing")::String
    value isa Missing && return String(default)
    value === nothing && return String(default)
    value isa AbstractVector && return join(string.(value), ";")
    return string(value)
end

function _fixed_control_candidate_state_names(candidate)::Vector{String}
    n_states = size(candidate.state_boundary, 1)
    raw_names = get(candidate.metadata, "candidate_state_names", String[])
    names = String.(raw_names)
    length(names) == n_states && return names
    return ["state_$index" for index in 1:n_states]
end

function _fixed_control_state_index(state_names::Vector{String}, state_name::AbstractString)::Int
    index = findfirst(==(String(state_name)), state_names)
    return index === nothing ? 0 : index
end

function _fixed_control_candidate_terminal_state_metadata(
    candidate;
    prefix::AbstractString,
)::Dict{String, Any}
    metadata = Dict{String, Any}(
        "$(prefix)_terminal_state_values_available" => false,
        "$(prefix)_terminal_state_boundary_index" => 0,
        "$(prefix)_terminal_glucose_g_L" => NaN,
        "$(prefix)_terminal_fructose_g_L" => NaN,
        "$(prefix)_terminal_total_sugar_g_L" => NaN,
        "$(prefix)_terminal_isoamyl_alcohol_g_L" => NaN,
    )
    candidate === nothing && return metadata
    state_boundary = candidate.state_boundary
    isempty(state_boundary) && return metadata

    state_names = _fixed_control_candidate_state_names(candidate)
    terminal_index = size(state_boundary, 2)
    glucose_index = _fixed_control_state_index(state_names, "glucose")
    fructose_index = _fixed_control_state_index(state_names, "fructose")
    isoamyl_index = _fixed_control_state_index(state_names, "isoamyl_alcohol")
    glucose = glucose_index == 0 ? NaN : Float64(state_boundary[glucose_index, terminal_index])
    fructose = fructose_index == 0 ? NaN : Float64(state_boundary[fructose_index, terminal_index])
    isoamyl =
        isoamyl_index == 0 ? NaN : Float64(state_boundary[isoamyl_index, terminal_index])

    metadata["$(prefix)_terminal_state_values_available"] = true
    metadata["$(prefix)_terminal_state_boundary_index"] = terminal_index
    metadata["$(prefix)_terminal_glucose_g_L"] = glucose
    metadata["$(prefix)_terminal_fructose_g_L"] = fructose
    metadata["$(prefix)_terminal_total_sugar_g_L"] = glucose + fructose
    metadata["$(prefix)_terminal_isoamyl_alcohol_g_L"] = isoamyl
    return metadata
end

function _fixed_control_residual_location_table(
    candidate;
    solve_horizon_h::Real,
    nfe::Int,
    degree::Int,
    top_n::Int,
    mesh_element_bounds = nothing,
)::DataFrame
    columns = [
        :residual_type,
        :element_index,
        :collocation_index,
        :time_h,
        :element_left_h,
        :element_right_h,
        :state_index,
        :state_name,
        :residual,
        :abs_residual,
        :state_value,
        :derivative_value,
    ]
    candidate === nothing && return DataFrame([column => Any[] for column in columns])

    grid =
        mesh_element_bounds === nothing ?
        build_finite_element_grid((0.0, Float64(solve_horizon_h)); nfe = nfe, degree = degree) :
        build_finite_element_grid(mesh_element_bounds; degree = degree)
    integration_matrix = grid.scheme.integration_matrix
    continuity_weights = grid.scheme.continuity_weights
    state_names = _fixed_control_candidate_state_names(candidate)
    rows = NamedTuple[]
    for element_index in 1:grid.nfe
        left_h, right_h = element_bounds(grid, element_index)
        element_h = element_length(grid, element_index)
        for state_index in axes(candidate.state_boundary, 1)
            state_name = state_names[state_index]
            for collocation_index in 1:grid.scheme.degree
                residual =
                    candidate.state_collocation[state_index, element_index, collocation_index] -
                    (
                        candidate.state_boundary[state_index, element_index] +
                        element_h * sum(
                            integration_matrix[collocation_index, derivative_index] *
                            candidate.state_derivative[state_index, element_index, derivative_index]
                            for derivative_index in 1:grid.scheme.degree
                        )
                    )
                push!(
                    rows,
                    (
                        residual_type = "collocation_integration",
                        element_index = element_index,
                        collocation_index = collocation_index,
                        time_h = collocation_time(grid, element_index, collocation_index),
                        element_left_h = left_h,
                        element_right_h = right_h,
                        state_index = state_index,
                        state_name = state_name,
                        residual = residual,
                        abs_residual = abs(residual),
                        state_value =
                            candidate.state_collocation[state_index, element_index, collocation_index],
                        derivative_value =
                            candidate.state_derivative[state_index, element_index, collocation_index],
                    ),
                )
            end

            continuity_residual =
                candidate.state_boundary[state_index, element_index + 1] -
                (
                    candidate.state_boundary[state_index, element_index] +
                    element_h * sum(
                        continuity_weights[derivative_index] *
                        candidate.state_derivative[state_index, element_index, derivative_index]
                        for derivative_index in 1:grid.scheme.degree
                    )
                )
            push!(
                rows,
                (
                    residual_type = "continuity",
                    element_index = element_index,
                    collocation_index = 0,
                    time_h = right_h,
                    element_left_h = left_h,
                    element_right_h = right_h,
                    state_index = state_index,
                    state_name = state_name,
                    residual = continuity_residual,
                    abs_residual = abs(continuity_residual),
                    state_value = candidate.state_boundary[state_index, element_index + 1],
                    derivative_value = NaN,
                ),
            )
        end
    end
    table = DataFrame(rows)
    sort!(table, :abs_residual; rev = true)
    return first(table, min(top_n, nrow(table)))
end

function _fixed_control_complementarity_location_table(result; top_n::Int)::DataFrame
    columns = [
        :residual_type,
        :element_index,
        :collocation_index,
        :time_h,
        :element_left_h,
        :element_right_h,
        :reaction_index,
        :reaction_id,
        :flux_value,
        :bound_value,
        :dual_value,
        :distance_to_bound,
        :bound_violation,
        :product,
        :abs_product,
    ]
    top_n <= 0 && return DataFrame([column => Any[] for column in columns])
    rows = get(result.metadata, "complementarity_location_rows", Any[])
    rows isa AbstractVector || return DataFrame([column => Any[] for column in columns])
    limited_rows = first(collect(rows), min(top_n, length(rows)))
    isempty(limited_rows) && return DataFrame([column => Any[] for column in columns])
    normalized_rows = [
        Dict(Symbol(key) => value for (key, value) in row) for row in limited_rows
    ]
    table = DataFrame(normalized_rows)
    for column in columns
        column in propertynames(table) || (table[!, column] = fill(missing, nrow(table)))
    end
    select!(table, columns)
    sort!(table, :abs_product; rev = true)
    return table
end

function _fixed_control_bound_violation_location_table(result; top_n::Int)::DataFrame
    columns = [
        :residual_type,
        :element_index,
        :collocation_index,
        :time_h,
        :element_left_h,
        :element_right_h,
        :reaction_index,
        :reaction_id,
        :flux_value,
        :bound_value,
        :distance_to_bound,
        :violation,
    ]
    top_n <= 0 && return DataFrame([column => Any[] for column in columns])
    rows = get(result.metadata, "bound_violation_location_rows", Any[])
    rows isa AbstractVector || return DataFrame([column => Any[] for column in columns])
    limited_rows = first(collect(rows), min(top_n, length(rows)))
    isempty(limited_rows) && return DataFrame([column => Any[] for column in columns])
    normalized_rows = [
        Dict(Symbol(key) => value for (key, value) in row) for row in limited_rows
    ]
    table = DataFrame(normalized_rows)
    for column in columns
        column in propertynames(table) || (table[!, column] = fill(missing, nrow(table)))
    end
    select!(table, columns)
    sort!(table, :violation; rev = true)
    return table
end

function _fixed_control_rhs_residual_location_table(result; top_n::Int)::DataFrame
    columns = [
        :residual_type,
        :element_index,
        :collocation_index,
        :time_h,
        :element_left_h,
        :element_right_h,
        :state_index,
        :state_name,
        :state_value,
        :derivative_value,
        :expected_derivative_value,
        :residual,
        :abs_residual,
    ]
    top_n <= 0 && return DataFrame([column => Any[] for column in columns])
    rows = get(result.metadata, "rhs_residual_location_rows", Any[])
    rows isa AbstractVector || return DataFrame([column => Any[] for column in columns])
    limited_rows = first(collect(rows), min(top_n, length(rows)))
    isempty(limited_rows) && return DataFrame([column => Any[] for column in columns])
    normalized_rows = [
        Dict(Symbol(key) => value for (key, value) in row) for row in limited_rows
    ]
    table = DataFrame(normalized_rows)
    for column in columns
        column in propertynames(table) || (table[!, column] = fill(missing, nrow(table)))
    end
    select!(table, columns)
    sort!(table, :abs_residual; rev = true)
    return table
end

function _fixed_control_repair_trace_table(metadata::AbstractDict)::DataFrame
    columns = [
        :phase,
        :iteration,
        :trial_index,
        :first_element,
        :last_element,
        :finite_element_count,
        :damping_factor,
        :score_policy,
        :previous_score,
        :score,
        :score_improvement,
        :previous_max_residual,
        :max_residual,
        :residual_improvement,
        :collocation_residual,
        :continuity_residual,
        :rhs_residual,
        :accepted,
        :residual_accepted,
        :guard_accepted,
        :guard_score_policy,
        :before_guard_score,
        :guard_score,
        :dynamic_flux_refresh_applied,
        :final_state_refresh_applied,
        :final_flux_projection_applied,
        :final_state_after_rhs_applied,
        :final_state_after_rhs_guard_accepted,
    ]
    rows = get(metadata, "collocation_consistent_state_start_repair_trace", Any[])
    rows isa AbstractVector || return DataFrame([column => Any[] for column in columns])
    isempty(rows) && return DataFrame([column => Any[] for column in columns])

    normalized_rows = Dict{Symbol, Any}[]
    for row in rows
        row isa AbstractDict || continue
        normalized = Dict{Symbol, Any}()
        for column in columns
            normalized[column] = get(row, String(column), get(row, column, missing))
        end
        push!(normalized_rows, normalized)
    end
    isempty(normalized_rows) && return DataFrame([column => Any[] for column in columns])

    table = DataFrame(normalized_rows)
    for column in columns
        column in propertynames(table) || (table[!, column] = fill(missing, nrow(table)))
    end
    select!(table, columns)
    return table
end

function _fixed_control_repair_substep_trace_table(metadata::AbstractDict)::DataFrame
    columns = [
        :phase,
        :iteration,
        :trial_index,
        :substep_index,
        :substep_label,
        :first_element,
        :last_element,
        :finite_element_count,
        :damping_factor,
        :accepted,
        :max_residual,
        :collocation_residual,
        :continuity_residual,
        :rhs_residual,
        :mass_balance_residual,
        :lower_bound_violation,
        :upper_bound_violation,
        :stationarity_residual,
        :lower_complementarity_residual,
        :upper_complementarity_residual,
        :primal_structural_residual,
        :dynamic_flux_refresh_applied,
        :final_state_refresh_applied,
        :final_flux_projection_applied,
        :final_state_after_rhs_applied,
    ]
    rows = get(
        metadata,
        "collocation_consistent_state_start_repair_substep_trace",
        Any[],
    )
    rows isa AbstractVector || return DataFrame([column => Any[] for column in columns])
    isempty(rows) && return DataFrame([column => Any[] for column in columns])

    normalized_rows = Dict{Symbol, Any}[]
    for row in rows
        row isa AbstractDict || continue
        normalized = Dict{Symbol, Any}()
        for column in columns
            normalized[column] = get(row, String(column), get(row, column, missing))
        end
        push!(normalized_rows, normalized)
    end
    isempty(normalized_rows) && return DataFrame([column => Any[] for column in columns])

    table = DataFrame(normalized_rows)
    for column in columns
        column in propertynames(table) || (table[!, column] = fill(missing, nrow(table)))
    end
    select!(table, columns)
    return table
end

function _fixed_control_schedule_from_row(
    row::DataFrameRow;
    schedule_horizon_h::Real,
    control_interval_h::Real,
    temperature_width_h::Real,
    addition_width_h::Real,
    temperature_start_offsets_raw = "",
    fda_start_offsets_raw = "",
    organic_start_offsets_raw = "",
)
    temperature_count = max(1, ceil(Int, Float64(schedule_horizon_h) / Float64(control_interval_h)))
    addition_count = max(0, temperature_count - 1)
    temperature_values_C = _fixed_control_resized(
        _fixed_control_parse_float_vector(row.temperature_values_C),
        temperature_count;
        fill_value = 20.0,
    )
    fda_doses_g_L = _fixed_control_resized(
        _fixed_control_parse_float_vector(row.fda_doses_g_L),
        addition_count;
        fill_value = 0.0,
    )
    organic_doses_g_L = _fixed_control_resized(
        _fixed_control_parse_float_vector(row.organic_doses_g_L),
        addition_count;
        fill_value = 0.0,
    )
    temperature_offsets_C = _fixed_control_parse_indexed_float_offsets(
        temperature_start_offsets_raw;
        max_count = temperature_count,
        label = "temperature",
    )
    fda_offsets_g_L = _fixed_control_parse_indexed_float_offsets(
        fda_start_offsets_raw;
        max_count = addition_count,
        label = "FDA",
    )
    organic_offsets_g_L = _fixed_control_parse_indexed_float_offsets(
        organic_start_offsets_raw;
        max_count = addition_count,
        label = "organic",
    )
    return reference_dynamic_control_schedule(
        horizon_h = schedule_horizon_h,
        control_interval_h = control_interval_h,
        temperature_values_C = _fixed_control_apply_start_offsets(
            temperature_values_C,
            temperature_offsets_C;
            lower = 15.0,
            upper = 25.0,
            label = "temperature",
        ),
        temperature_transition_width_h = temperature_width_h,
        fda_doses_g_L = _fixed_control_apply_start_offsets(
            fda_doses_g_L,
            fda_offsets_g_L;
            lower = 0.0,
            upper = FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L,
            label = "FDA",
        ),
        organic_doses_g_L = _fixed_control_apply_start_offsets(
            organic_doses_g_L,
            organic_offsets_g_L;
            lower = 0.0,
            upper = Inf,
            label = "organic",
        ),
        addition_transition_width_h = addition_width_h,
    )
end

function _fixed_control_selected_policy(table::DataFrame, candidate_id::AbstractString)
    ready_table = table[_fixed_control_bool.(table.control_policy_ready), :]
    nrow(ready_table) > 0 || error("No control_policy_ready=true policies in selection CSV.")
    selected_id = strip(String(candidate_id))
    if isempty(selected_id)
        return ready_table[1, :]
    end
    matches = findall(==(selected_id), String.(ready_table.candidate_id))
    isempty(matches) && error(
        "Requested MPCC_FIXED_CONTROL_CANDIDATE_ID is not control_policy_ready=true: " *
        selected_id,
    )
    return ready_table[first(matches), :]
end

function _fixed_control_residual_thresholds()
    defaults = default_reduced_dcdfba_mpcc_residual_thresholds()
    return default_reduced_dcdfba_mpcc_residual_thresholds(
        max_rhs_residual = _fixed_control_env_nonnegative_float(
            "MPCC_FIXED_CONTROL_THRESHOLD_MAX_RHS_RESIDUAL",
            defaults.max_rhs_residual,
        ),
        max_mass_balance_residual = _fixed_control_env_nonnegative_float(
            "MPCC_FIXED_CONTROL_THRESHOLD_MAX_MASS_BALANCE_RESIDUAL",
            defaults.max_mass_balance_residual,
        ),
        max_lower_bound_violation = _fixed_control_env_nonnegative_float(
            "MPCC_FIXED_CONTROL_THRESHOLD_MAX_LOWER_BOUND_VIOLATION",
            defaults.max_lower_bound_violation,
        ),
        max_upper_bound_violation = _fixed_control_env_nonnegative_float(
            "MPCC_FIXED_CONTROL_THRESHOLD_MAX_UPPER_BOUND_VIOLATION",
            defaults.max_upper_bound_violation,
        ),
        max_stationarity_residual = _fixed_control_env_nonnegative_float(
            "MPCC_FIXED_CONTROL_THRESHOLD_MAX_STATIONARITY_RESIDUAL",
            defaults.max_stationarity_residual,
        ),
        max_lower_complementarity_residual = _fixed_control_env_nonnegative_float(
            "MPCC_FIXED_CONTROL_THRESHOLD_MAX_LOWER_COMPLEMENTARITY_RESIDUAL",
            defaults.max_lower_complementarity_residual,
        ),
        max_upper_complementarity_residual = _fixed_control_env_nonnegative_float(
            "MPCC_FIXED_CONTROL_THRESHOLD_MAX_UPPER_COMPLEMENTARITY_RESIDUAL",
            defaults.max_upper_complementarity_residual,
        ),
    )
end

function _fixed_control_solve_attempt_row(
    candidate_id::AbstractString,
    result;
    case_id::AbstractString = "",
    solve_horizon_h::Real = NaN,
    ipopt_max_iter = missing,
    collocation_repair_elements::AbstractString = "all",
    bound_dual_clip_elements::AbstractString = "all",
    mesh_policy::AbstractString = "uniform",
    mesh_breakpoints_h::AbstractVector{<:Real} = Float64[],
    mesh_min_element_length_h::Real = NaN,
    mesh_max_element_length_h::Real = NaN,
)
    metadata = result.metadata
    smoke = result.smoke_result
    row_case_id = isempty(strip(String(case_id))) ? String(candidate_id) : String(case_id)
    row_grid_nfe = _fixed_control_int(
        get(metadata, "grid_nfe", get(metadata, "nfe", 0)),
    )
    row_solve_horizon_h = Float64(solve_horizon_h)
    row_grid_element_length_h =
        isfinite(row_solve_horizon_h) && row_grid_nfe > 0 ?
        row_solve_horizon_h / row_grid_nfe : NaN
    return (
        case_id = row_case_id,
        candidate_id = String(candidate_id),
        solve_horizon_h = row_solve_horizon_h,
        ipopt_max_iter = _fixed_control_int(ipopt_max_iter; default = -1),
        solve_attempt_status = "attempted",
        solver_call_performed = Bool(get(metadata, "solver_call_performed", false)),
        solver_status = string(smoke.status),
        primal_status = string(smoke.primal_status),
        solver_name = smoke.solver_name,
        solver_result_count = _fixed_control_int(get(metadata, "solver_result_count", 0)),
        objective_value = Float64(smoke.objective_value),
        solve_elapsed_seconds = Float64(smoke.solve_elapsed_seconds),
        solver_reported_solve_time_seconds =
            _fixed_control_float(get(metadata, "solver_reported_solve_time_seconds", NaN)),
        residuals_available = Bool(result.residuals_available),
        residual_thresholds_satisfied = Bool(result.residual_thresholds_satisfied),
        dominant_residual = _fixed_control_string(get(metadata, "dominant_residual", missing)),
        max_rhs_residual = _fixed_control_float(get(metadata, "max_rhs_residual", NaN)),
        max_collocation_integration_residual =
            _fixed_control_float(get(metadata, "max_collocation_integration_residual", NaN)),
        max_continuity_residual =
            _fixed_control_float(get(metadata, "max_continuity_residual", NaN)),
        max_initial_condition_residual =
            _fixed_control_float(get(metadata, "max_initial_condition_residual", NaN)),
        max_mass_balance_residual = Float64(smoke.max_mass_balance_residual),
        max_lower_bound_violation = Float64(smoke.max_lower_bound_violation),
        max_upper_bound_violation = Float64(smoke.max_upper_bound_violation),
        max_stationarity_residual = Float64(smoke.max_stationarity_residual),
        max_lower_complementarity_residual =
            Float64(smoke.max_lower_complementarity_residual),
        max_upper_complementarity_residual =
            Float64(smoke.max_upper_complementarity_residual),
        max_complementarity_tau_violation =
            _fixed_control_float(get(metadata, "max_complementarity_tau_violation", NaN)),
        complementarity_tau_gate_pass =
            Bool(get(metadata, "complementarity_tau_gate_pass", false)),
        complementarity_mode = _fixed_control_string(get(metadata, "complementarity_mode", missing)),
        complementarity_tau = _fixed_control_string(get(metadata, "complementarity_tau", missing)),
        tau_continuation_entrypoint_enabled =
            Bool(get(metadata, "tau_continuation_entrypoint_enabled", false)),
        tau_continuation_performed =
            Bool(get(metadata, "tau_continuation_performed", false)),
        tau_continuation_stage_count =
            _fixed_control_int(get(metadata, "tau_continuation_stage_count", 0)),
        tau_continuation_stage_count_requested = _fixed_control_int(
            get(metadata, "tau_continuation_stage_count_requested", 0),
        ),
        tau_continuation_completed =
            Bool(get(metadata, "tau_continuation_completed", false)),
        tau_continuation_selected_stage_index = _fixed_control_int(
            get(metadata, "tau_continuation_selected_stage_index", 0),
        ),
        tau_continuation_selected_tau =
            _fixed_control_float(get(metadata, "tau_continuation_selected_tau", NaN)),
        tau_continuation_attempted_final_tau = _fixed_control_float(
            get(metadata, "tau_continuation_attempted_final_tau", NaN),
        ),
        tau_continuation_selected_reason =
            _fixed_control_string(get(metadata, "tau_continuation_selected_reason", missing)),
        tau_continuation_blocking_reason =
            _fixed_control_string(get(metadata, "tau_continuation_blocking_reason", missing)),
        tau_continuation_polish_failed =
            Bool(get(metadata, "tau_continuation_polish_failed", false)),
        tau_continuation_final_retry_performed =
            Bool(get(metadata, "tau_continuation_final_retry_performed", false)),
        tau_continuation_coarse_tau_fallback_applied =
            Bool(get(metadata, "tau_continuation_coarse_tau_fallback_applied", false)),
        pre_solve_guard_required = Bool(get(metadata, "pre_solve_guard_required", false)),
        guarded_solve_attempt_blocked =
            Bool(get(metadata, "guarded_solve_attempt_blocked", false)),
        guarded_solve_attempt_allowed =
            Bool(get(metadata, "guarded_solve_attempt_allowed", false)),
        candidate_values_available =
            Bool(get(metadata, "candidate_values_available", result.candidate_diagnostics !== nothing)),
        apply_default_start_initializers =
            Bool(get(metadata, "apply_default_start_initializers", true)),
        default_start_initializers_applied =
            Bool(get(metadata, "default_start_initializers_applied", true)),
        default_start_initializers_skip_reason =
            _fixed_control_string(get(metadata, "default_start_initializers_skip_reason", missing)),
        skip_sequential_simulation_for_candidate_seed =
            Bool(get(metadata, "skip_sequential_simulation_for_candidate_seed", false)),
        candidate_diagnostics_start_jls_requested =
            Bool(get(metadata, "candidate_diagnostics_start_jls_requested", false)),
        candidate_diagnostics_start_jls_loaded =
            Bool(get(metadata, "candidate_diagnostics_start_jls_loaded", false)),
        flux_dual_start_jls_requested =
            Bool(get(metadata, "flux_dual_start_jls_requested", false)),
        flux_dual_start_jls_loaded =
            Bool(get(metadata, "flux_dual_start_jls_loaded", false)),
        cross_window_flux_dual_start_applied =
            Bool(get(metadata, "cross_window_flux_dual_start_applied", false)),
        full_candidate_start_seed_applied =
            Bool(get(metadata, "full_candidate_start_seed_applied", false)),
        full_candidate_start_seed_apply_dynamic_controls = Bool(
            get(metadata, "full_candidate_start_seed_apply_dynamic_controls", true),
        ),
        full_candidate_start_seed_dynamic_controls_policy = _fixed_control_string(
            get(metadata, "full_candidate_start_seed_dynamic_controls_policy", missing),
        ),
        full_candidate_start_seed_dynamic_controls_applied = Bool(
            get(metadata, "full_candidate_start_seed_dynamic_controls_applied", false),
        ),
        full_candidate_start_seed_dynamic_controls_skip_reason = _fixed_control_string(
            get(metadata, "full_candidate_start_seed_dynamic_controls_skip_reason", missing),
        ),
        candidate_residual_feasible =
            Bool(get(metadata, "candidate_residual_feasible", false)),
        candidate_iteration_limit_residual_feasible =
            Bool(get(metadata, "candidate_iteration_limit_residual_feasible", false)),
        candidate_trajectory_extraction_ready =
            Bool(get(metadata, "candidate_trajectory_extraction_ready", false)),
        candidate_dominant_residual =
            _fixed_control_string(get(metadata, "candidate_dominant_residual", missing)),
        candidate_values_source =
            _fixed_control_string(get(metadata, "candidate_values_source", missing)),
        candidate_selection_policy =
            _fixed_control_string(get(metadata, "candidate_selection_policy", missing)),
        candidate_selection_reason =
            _fixed_control_string(get(metadata, "candidate_selection_reason", missing)),
        selected_candidate_source =
            _fixed_control_string(get(metadata, "selected_candidate_source", missing)),
        selected_candidate_is_post_solve =
            Bool(get(metadata, "selected_candidate_is_post_solve", false)),
        selected_candidate_is_pre_solve_start =
            Bool(get(metadata, "selected_candidate_is_pre_solve_start", false)),
        selected_candidate_residual_feasible =
            Bool(get(metadata, "selected_candidate_residual_feasible", false)),
        selected_candidate_trajectory_ready =
            Bool(get(metadata, "selected_candidate_trajectory_ready", false)),
        selected_candidate_terminal_state_values_available =
            Bool(get(metadata, "selected_candidate_terminal_state_values_available", false)),
        selected_candidate_terminal_state_boundary_index =
            _fixed_control_int(get(metadata, "selected_candidate_terminal_state_boundary_index", 0)),
        selected_candidate_terminal_glucose_g_L =
            _fixed_control_float(get(metadata, "selected_candidate_terminal_glucose_g_L", NaN)),
        selected_candidate_terminal_fructose_g_L =
            _fixed_control_float(get(metadata, "selected_candidate_terminal_fructose_g_L", NaN)),
        selected_candidate_terminal_total_sugar_g_L =
            _fixed_control_float(get(metadata, "selected_candidate_terminal_total_sugar_g_L", NaN)),
        selected_candidate_terminal_isoamyl_alcohol_g_L = _fixed_control_float(
            get(metadata, "selected_candidate_terminal_isoamyl_alcohol_g_L", NaN),
        ),
        pre_solve_candidate_available =
            Bool(get(metadata, "pre_solve_candidate_available", false)),
        pre_solve_candidate_residual_feasible =
            Bool(get(metadata, "pre_solve_candidate_residual_feasible", false)),
        post_solve_candidate_available =
            Bool(get(metadata, "post_solve_candidate_available", false)),
        post_solve_candidate_residual_feasible =
            Bool(get(metadata, "post_solve_candidate_residual_feasible", false)),
        post_solve_candidate_accepted =
            Bool(get(metadata, "post_solve_candidate_accepted", false)),
        post_solve_candidate_rejected =
            Bool(get(metadata, "post_solve_candidate_rejected", false)),
        post_solve_candidate_rejection_reason =
            _fixed_control_string(get(metadata, "post_solve_candidate_rejection_reason", missing)),
        pre_solve_candidate_dynamic_control_values_captured =
            Bool(get(metadata, "pre_solve_candidate_dynamic_control_values_captured", false)),
        post_solve_candidate_dynamic_control_values_captured =
            Bool(get(metadata, "post_solve_candidate_dynamic_control_values_captured", false)),
        post_solve_candidate_dynamic_control_delta_vs_pre_solve_available = Bool(
            get(
                metadata,
                "post_solve_candidate_dynamic_control_delta_vs_pre_solve_available",
                false,
            ),
        ),
        post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve =
            _fixed_control_float(
                get(
                    metadata,
                    "post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve",
                    NaN,
                ),
            ),
        post_solve_candidate_dynamic_control_fda_g_L_max_abs_delta_vs_pre_solve =
            _fixed_control_float(
                get(
                    metadata,
                    "post_solve_candidate_dynamic_control_fda_g_L_max_abs_delta_vs_pre_solve",
                    NaN,
                ),
            ),
        post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve =
            _fixed_control_float(
                get(
                    metadata,
                    "post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve",
                    NaN,
                ),
            ),
        post_solve_candidate_dynamic_control_organic_g_L_max_abs_delta_vs_pre_solve =
            _fixed_control_float(
                get(
                    metadata,
                    "post_solve_candidate_dynamic_control_organic_g_L_max_abs_delta_vs_pre_solve",
                    NaN,
                ),
            ),
        post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve =
            _fixed_control_float(
                get(
                    metadata,
                    "post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve",
                    NaN,
                ),
            ),
        dynamic_control_schedule_enabled =
            Bool(get(metadata, "dynamic_control_schedule_enabled", false)),
        dynamic_control_fda_total_product_g_L =
            _fixed_control_float(get(metadata, "dynamic_control_fda_total_product_g_L", NaN)),
        dynamic_control_organic_total_product_g_L = _fixed_control_float(
            get(metadata, "dynamic_control_organic_total_product_g_L", NaN),
        ),
        dynamic_control_decision_spec_requested =
            Bool(get(metadata, "dynamic_control_decision_spec_requested", false)),
        dynamic_control_liberation_mode =
            _fixed_control_string(get(metadata, "dynamic_control_liberation_mode", missing)),
        dynamic_control_temperature_free_indices =
            _fixed_control_string(get(metadata, "dynamic_control_temperature_free_indices_label", missing)),
        dynamic_control_addition_free_indices =
            _fixed_control_string(get(metadata, "dynamic_control_addition_free_indices_label", missing)),
        dynamic_control_temperature_trust_C =
            _fixed_control_float(get(metadata, "dynamic_control_temperature_trust_C", NaN)),
        dynamic_control_fda_trust_g_L =
            _fixed_control_float(get(metadata, "dynamic_control_fda_trust_g_L", NaN)),
        dynamic_control_organic_trust_g_L =
            _fixed_control_float(get(metadata, "dynamic_control_organic_trust_g_L", NaN)),
        mpcc_dynamic_control_decision_spec_provided =
            Bool(get(metadata, "mpcc_dynamic_control_decision_spec_provided", false)),
        mpcc_dynamic_control_decision_scaffold_built =
            Bool(get(metadata, "mpcc_dynamic_control_decision_scaffold_built", false)),
        mpcc_dynamic_control_variable_policy = _fixed_control_string(
            get(metadata, "mpcc_dynamic_control_variable_policy", missing),
        ),
        mpcc_dynamic_control_variables_coupled_to_rhs =
            Bool(get(metadata, "mpcc_dynamic_control_variables_coupled_to_rhs", false)),
        mpcc_dynamic_control_variables_coupled_to_dynamic_bounds = Bool(
            get(metadata, "mpcc_dynamic_control_variables_coupled_to_dynamic_bounds", false),
        ),
        rhs_residual_uses_control_decision_variables =
            Bool(get(metadata, "rhs_residual_uses_control_decision_variables", false)),
        dynamic_flux_bounds_use_control_decision_variables =
            Bool(get(metadata, "dynamic_flux_bounds_use_control_decision_variables", false)),
        fully_simultaneous_controls =
            Bool(get(metadata, "fully_simultaneous_controls", false)),
        control_variable_count = _fixed_control_int(get(metadata, "control_variable_count", 0)),
        control_free_variable_count =
            _fixed_control_int(get(metadata, "control_free_variable_count", 0)),
        control_fixed_variable_count =
            _fixed_control_int(get(metadata, "control_fixed_variable_count", 0)),
        free_temperature_count =
            _fixed_control_int(get(metadata, "free_temperature_count", 0)),
        free_fda_count = _fixed_control_int(get(metadata, "free_fda_count", 0)),
        free_organic_count = _fixed_control_int(get(metadata, "free_organic_count", 0)),
        control_bounds_ok = Bool(get(metadata, "control_bounds_ok", false)),
        control_starts_ok = Bool(get(metadata, "control_starts_ok", false)),
        dynamic_control_reference_regularization_enabled =
            Bool(get(metadata, "dynamic_control_reference_regularization_enabled", false)),
        dynamic_control_reference_regularization_weight = _fixed_control_float(
            get(metadata, "dynamic_control_reference_regularization_weight", NaN),
        ),
        dynamic_control_reference_regularization_term_count =
            _fixed_control_int(get(metadata, "dynamic_control_reference_regularization_term_count", 0)),
        dynamic_control_objective_enabled =
            Bool(get(metadata, "dynamic_control_objective_enabled", false)),
        dynamic_control_objective_mode =
            _fixed_control_string(get(metadata, "dynamic_control_objective_mode", missing)),
        dynamic_control_objective_policy =
            _fixed_control_string(get(metadata, "dynamic_control_objective_policy", missing)),
        dynamic_control_objective_requested_target_state = _fixed_control_string(
            get(metadata, "dynamic_control_objective_requested_target_state", missing),
        ),
        dynamic_control_objective_resolved_target_state = _fixed_control_string(
            get(metadata, "dynamic_control_objective_resolved_target_state", missing),
        ),
        dynamic_control_objective_target_state_alias_policy = _fixed_control_string(
            get(metadata, "dynamic_control_objective_target_state_alias_policy", missing),
        ),
        dynamic_control_objective_target_component_count = _fixed_control_int(
            get(metadata, "dynamic_control_objective_target_component_count", 0),
        ),
        dynamic_control_objective_target_component_names = _fixed_control_join_values(
            get(metadata, "dynamic_control_objective_target_component_names", missing),
        ),
        dynamic_control_objective_target_component_weights = _fixed_control_join_values(
            get(metadata, "dynamic_control_objective_target_component_weights", missing),
        ),
        dynamic_control_objective_target_component_scales_g_L = _fixed_control_join_values(
            get(metadata, "dynamic_control_objective_target_component_scales_g_L", missing),
        ),
        dynamic_control_objective_terminal_reward_weight = _fixed_control_float(
            get(metadata, "dynamic_control_objective_terminal_reward_weight", NaN),
        ),
        dynamic_control_objective_terminal_state_scale_g_L = _fixed_control_float(
            get(metadata, "dynamic_control_objective_terminal_state_scale_g_L", NaN),
        ),
        dynamic_control_objective_terminal_sugar_weight = _fixed_control_float(
            get(metadata, "dynamic_control_objective_terminal_sugar_weight", NaN),
        ),
        dynamic_control_objective_terminal_sugar_scale_g_L = _fixed_control_float(
            get(metadata, "dynamic_control_objective_terminal_sugar_scale_g_L", NaN),
        ),
        dynamic_control_objective_integrated_sugar_weight = _fixed_control_float(
            get(metadata, "dynamic_control_objective_integrated_sugar_weight", NaN),
        ),
        dynamic_control_objective_integrated_sugar_scale_g_L = _fixed_control_float(
            get(metadata, "dynamic_control_objective_integrated_sugar_scale_g_L", NaN),
        ),
        dynamic_control_objective_aroma_reward_policy = _fixed_control_string(
            get(metadata, "dynamic_control_objective_aroma_reward_policy", missing),
        ),
        dynamic_control_objective_terminal_reward_effective_weight = _fixed_control_float(
            get(
                metadata,
                "dynamic_control_objective_terminal_reward_effective_weight",
                NaN,
            ),
        ),
        dynamic_control_objective_integrated_aroma_reward_effective_weight =
            _fixed_control_float(
                get(
                    metadata,
                    "dynamic_control_objective_integrated_aroma_reward_effective_weight",
                    NaN,
                ),
            ),
        dynamic_control_objective_integrated_aroma_reward_terms = _fixed_control_int(
            get(metadata, "dynamic_control_objective_integrated_aroma_reward_terms", 0),
        ),
        dynamic_control_objective_terminal_sugar_terms = _fixed_control_int(
            get(metadata, "dynamic_control_objective_terminal_sugar_terms", 0),
        ),
        dynamic_control_objective_integrated_sugar_terms = _fixed_control_int(
            get(metadata, "dynamic_control_objective_integrated_sugar_terms", 0),
        ),
        dynamic_control_objective_integrated_sugar_policy = _fixed_control_string(
            get(metadata, "dynamic_control_objective_integrated_sugar_policy", missing),
        ),
        dynamic_control_objective_integrated_aroma_reward_policy =
            _fixed_control_string(
                get(
                    metadata,
                    "dynamic_control_objective_integrated_aroma_reward_policy",
                    missing,
                ),
            ),
        dynamic_control_objective_nutrient_weight =
            _fixed_control_float(get(metadata, "dynamic_control_objective_nutrient_weight", NaN)),
        dynamic_control_objective_thermal_energy_weight = _fixed_control_float(
            get(metadata, "dynamic_control_objective_thermal_energy_weight", NaN),
        ),
        dynamic_control_objective_temperature_smoothness_weight = _fixed_control_float(
            get(metadata, "dynamic_control_objective_temperature_smoothness_weight", NaN),
        ),
        dynamic_control_objective_tail_residual_weight = _fixed_control_float(
            get(metadata, "dynamic_control_objective_tail_residual_weight", NaN),
        ),
        dynamic_control_objective_tail_residual_state = _fixed_control_string(
            get(metadata, "dynamic_control_objective_tail_residual_state", missing),
        ),
        dynamic_control_objective_tail_residual_elements = _fixed_control_string(
            get(metadata, "dynamic_control_objective_tail_residual_elements", missing),
        ),
        dynamic_control_objective_tail_residual_scale_g_L = _fixed_control_float(
            get(metadata, "dynamic_control_objective_tail_residual_scale_g_L", NaN),
        ),
        dynamic_control_objective_tail_residual_terms = _fixed_control_int(
            get(metadata, "dynamic_control_objective_tail_residual_terms", 0),
        ),
        dynamic_control_objective_tail_residual_first_element = _fixed_control_int(
            get(metadata, "dynamic_control_objective_tail_residual_first_element", 0),
        ),
        dynamic_control_objective_tail_residual_last_element = _fixed_control_int(
            get(metadata, "dynamic_control_objective_tail_residual_last_element", 0),
        ),
        dynamic_control_objective_term_count =
            _fixed_control_int(get(metadata, "dynamic_control_objective_term_count", 0)),
        rhs_residuals_included = Bool(get(metadata, "rhs_residuals_included", false)),
        dynamic_flux_bounds_applied =
            Bool(get(metadata, "dynamic_flux_bounds_applied", false)),
        sequential_saveat_policy =
            _fixed_control_string(get(metadata, "sequential_saveat_policy", missing)),
        sequential_saveat_h = _fixed_control_float(get(metadata, "sequential_saveat_h", NaN)),
        sequential_saveat_point_count =
            _fixed_control_int(get(metadata, "sequential_saveat_point_count", 0)),
        sequential_saveat_min_step_h =
            _fixed_control_float(get(metadata, "sequential_saveat_min_step_h", NaN)),
        sequential_initialization_built =
            Bool(get(metadata, "sequential_initialization_built", false)),
        collocation_consistent_state_start_applied =
            Bool(get(metadata, "collocation_consistent_state_start_applied", false)),
        collocation_consistent_state_start_converged =
            Bool(get(metadata, "collocation_consistent_state_start_converged", false)),
        collocation_consistent_state_start_iterations =
            _fixed_control_int(get(metadata, "collocation_consistent_state_start_iterations", 0)),
        collocation_consistent_state_start_max_iterations =
            _fixed_control_int(get(metadata, "collocation_consistent_state_start_max_iterations", 0)),
        collocation_consistent_state_start_tolerance = _fixed_control_float(
            get(metadata, "collocation_consistent_state_start_tolerance", NaN),
        ),
        collocation_repair_elements = String(collocation_repair_elements),
        collocation_consistent_state_start_policy =
            _fixed_control_string(get(metadata, "collocation_consistent_state_start_policy", missing)),
        collocation_consistent_state_start_score_policy =
            _fixed_control_string(get(metadata, "collocation_consistent_state_start_score_policy", missing)),
        collocation_consistent_state_start_initial_score =
            _fixed_control_float(
                get(metadata, "collocation_consistent_state_start_initial_score", NaN),
            ),
        collocation_consistent_state_start_final_score =
            _fixed_control_float(
                get(metadata, "collocation_consistent_state_start_final_score", NaN),
            ),
        collocation_consistent_state_start_repair_after_candidate_seed_enabled = Bool(
            get(
                metadata,
                "collocation_consistent_state_start_repair_after_candidate_seed_enabled",
                false,
            ),
        ),
        collocation_consistent_state_start_repair_after_candidate_seed_applied = Bool(
            get(
                metadata,
                "collocation_consistent_state_start_repair_after_candidate_seed_applied",
                false,
            ),
        ),
        collocation_consistent_state_start_repair_after_candidate_seed_policy =
            _fixed_control_string(
                get(
                    metadata,
                    "collocation_consistent_state_start_repair_after_candidate_seed_policy",
                    missing,
                ),
            ),
        collocation_consistent_state_start_repair_after_candidate_seed_elements =
            _fixed_control_string(
                get(
                    metadata,
                    "collocation_consistent_state_start_repair_after_candidate_seed_elements",
                    missing,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_enabled = Bool(
            get(metadata, "collocation_consistent_state_start_feasibility_projection_enabled", false),
        ),
        collocation_consistent_state_start_feasibility_projection_applied = Bool(
            get(metadata, "collocation_consistent_state_start_feasibility_projection_applied", false),
        ),
        collocation_consistent_state_start_feasibility_projection_segments_raw =
            _fixed_control_string(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_segments_raw",
                    missing,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_ranges =
            _fixed_control_join_values(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_ranges",
                    missing,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_segment_count =
            _fixed_control_int(
                get(metadata, "collocation_consistent_state_start_feasibility_projection_segment_count", 0),
            ),
        collocation_consistent_state_start_feasibility_projection_accepted_count =
            _fixed_control_int(
                get(metadata, "collocation_consistent_state_start_feasibility_projection_accepted_count", 0),
            ),
        collocation_consistent_state_start_feasibility_projection_trial_count =
            _fixed_control_int(
                get(metadata, "collocation_consistent_state_start_feasibility_projection_trial_count", 0),
            ),
        collocation_consistent_state_start_feasibility_projection_rejected_trial_count =
            _fixed_control_int(
                get(metadata, "collocation_consistent_state_start_feasibility_projection_rejected_trial_count", 0),
            ),
        collocation_consistent_state_start_feasibility_projection_guard_score_policy =
            _fixed_control_string(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_guard_score_policy",
                    missing,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_damping_factors =
            _fixed_control_join_values(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_damping_factors",
                    missing,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_refresh_dynamic_flux =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_refresh_dynamic_flux",
                    false,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_final_state_refresh =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_final_state_refresh",
                    false,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_final_flux_projection =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_final_flux_projection",
                    false,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_final_state_after_rhs =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_final_state_after_rhs",
                    false,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_before_max_residual =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_before_max_residual",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_after_max_residual =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_after_max_residual",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_before_collocation_residual =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_before_collocation_residual",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_after_collocation_residual =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_after_collocation_residual",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_before_continuity_residual =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_before_continuity_residual",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_feasibility_projection_after_continuity_residual =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_feasibility_projection_after_continuity_residual",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_best_score =
            _fixed_control_float(
                get(metadata, "collocation_consistent_state_start_best_score", NaN),
            ),
        collocation_consistent_state_start_finite_element_count =
            _fixed_control_int(get(metadata, "collocation_consistent_state_start_finite_element_count", 0)),
        collocation_consistent_state_start_first_element =
            _fixed_control_int(get(metadata, "collocation_consistent_state_start_first_element", 0)),
        collocation_consistent_state_start_last_element =
            _fixed_control_int(get(metadata, "collocation_consistent_state_start_last_element", 0)),
        collocation_consistent_state_start_final_collocation_residual =
            _fixed_control_float(
                get(metadata, "collocation_consistent_state_start_final_collocation_residual", NaN),
            ),
        collocation_consistent_state_start_final_continuity_residual =
            _fixed_control_float(
                get(metadata, "collocation_consistent_state_start_final_continuity_residual", NaN),
            ),
        collocation_consistent_state_start_final_rhs_residual =
            _fixed_control_float(
                get(metadata, "collocation_consistent_state_start_final_rhs_residual", NaN),
            ),
        collocation_consistent_state_start_final_max_residual =
            _fixed_control_float(
                get(metadata, "collocation_consistent_state_start_final_max_residual", NaN),
            ),
        collocation_consistent_state_start_final_state_refresh_enabled =
            Bool(get(metadata, "collocation_consistent_state_start_final_state_refresh_enabled", false)),
        collocation_consistent_state_start_final_flux_projection_enabled =
            Bool(get(metadata, "collocation_consistent_state_start_final_flux_projection_enabled", false)),
        collocation_consistent_state_start_final_complementarity_flux_projection_enabled =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_complementarity_flux_projection_enabled",
                    false,
                ),
            ),
        collocation_consistent_state_start_last_final_complementarity_flux_projection_applied =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_last_final_complementarity_flux_projection_applied",
                    false,
                ),
            ),
        active_complementarity_flux_projection_triggered_points =
            _fixed_control_int(
                get(metadata, "active_complementarity_flux_projection_triggered_points", 0),
            ),
        active_complementarity_flux_projection_max_lower_complementarity_after =
            _fixed_control_float(
                get(
                    metadata,
                    "active_complementarity_flux_projection_max_lower_complementarity_after",
                    NaN,
                ),
            ),
        active_complementarity_flux_projection_max_adjustment =
            _fixed_control_float(
                get(metadata, "active_complementarity_flux_projection_max_adjustment", NaN),
            ),
        active_complementarity_flux_projection_guard_enabled =
            Bool(get(metadata, "active_complementarity_flux_projection_guard_enabled", false)),
        active_complementarity_flux_projection_guard_accepted =
            Bool(get(metadata, "active_complementarity_flux_projection_guard_accepted", false)),
        active_complementarity_flux_projection_guard_before_score =
            _fixed_control_float(
                get(metadata, "active_complementarity_flux_projection_guard_before_score", NaN),
            ),
        active_complementarity_flux_projection_guard_after_score =
            _fixed_control_float(
                get(metadata, "active_complementarity_flux_projection_guard_after_score", NaN),
            ),
        collocation_consistent_state_start_final_dual_fit_enabled =
            Bool(get(metadata, "collocation_consistent_state_start_final_dual_fit_enabled", false)),
        collocation_consistent_state_start_final_selective_dual_fit_enabled =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_selective_dual_fit_enabled",
                    false,
                ),
            ),
        collocation_consistent_state_start_last_final_selective_dual_fit_applied =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_last_final_selective_dual_fit_applied",
                    false,
                ),
            ),
        selective_fixed_flux_stationarity_dual_fit_accepted =
            Bool(get(metadata, "selective_fixed_flux_stationarity_dual_fit_accepted", false)),
        selective_fixed_flux_stationarity_dual_fit_element_count =
            _fixed_control_int(
                get(metadata, "selective_fixed_flux_stationarity_dual_fit_element_count", 0),
            ),
        selective_fixed_flux_stationarity_dual_fit_max_stationarity_residual_after =
            _fixed_control_float(
                get(
                    metadata,
                    "selective_fixed_flux_stationarity_dual_fit_max_stationarity_residual_after",
                    NaN,
                ),
            ),
        selective_fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after =
            _fixed_control_float(
                get(
                    metadata,
                    "selective_fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_final_state_after_rhs_enabled =
            Bool(get(metadata, "collocation_consistent_state_start_final_state_after_rhs_enabled", false)),
        collocation_consistent_state_start_last_final_state_after_rhs_applied =
            Bool(get(metadata, "collocation_consistent_state_start_last_final_state_after_rhs_applied", false)),
        collocation_consistent_state_start_final_state_after_rhs_guard_enabled =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_state_after_rhs_guard_enabled",
                    false,
                ),
            ),
        collocation_consistent_state_start_final_state_after_rhs_guard_accepted =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_state_after_rhs_guard_accepted",
                    false,
                ),
            ),
        collocation_consistent_state_start_final_state_after_rhs_guard_accepted_damping_factor =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_state_after_rhs_guard_accepted_damping_factor",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_enabled =
            Bool(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_enabled",
                    false,
                ),
            ),
        collocation_consistent_state_start_final_state_after_rhs_guard_before_primal_structural_residual =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_state_after_rhs_guard_before_primal_structural_residual",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_final_state_after_rhs_guard_after_primal_structural_residual =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_state_after_rhs_guard_after_primal_structural_residual",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_final_state_after_rhs_guard_after_lower_bound_violation =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_state_after_rhs_guard_after_lower_bound_violation",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_final_state_after_rhs_guard_after_upper_bound_violation =
            _fixed_control_float(
                get(
                    metadata,
                    "collocation_consistent_state_start_final_state_after_rhs_guard_after_upper_bound_violation",
                    NaN,
                ),
            ),
        collocation_consistent_state_start_stopped_by_monotone_guard =
            Bool(get(metadata, "collocation_consistent_state_start_stopped_by_monotone_guard", false)),
        collocation_consistent_state_start_trial_count =
            _fixed_control_int(get(metadata, "collocation_consistent_state_start_trial_count", 0)),
        collocation_consistent_state_start_rejected_trial_count =
            _fixed_control_int(get(metadata, "collocation_consistent_state_start_rejected_trial_count", 0)),
        bound_dual_complementarity_clip_enabled =
            Bool(get(metadata, "bound_dual_complementarity_clip_enabled", false)),
        bound_dual_complementarity_clip_applied =
            Bool(get(metadata, "bound_dual_complementarity_clip_applied", false)),
        bound_dual_complementarity_clip_elements = String(bound_dual_clip_elements),
        bound_dual_complementarity_clip_effective_complementarity_budget_tau =
            _fixed_control_float(
                get(
                    metadata,
                    "bound_dual_complementarity_clip_effective_complementarity_budget_tau",
                    NaN,
                ),
            ),
        bound_dual_complementarity_clip_max_stationarity_residual_after =
            _fixed_control_float(
                get(metadata, "bound_dual_complementarity_clip_max_stationarity_residual_after", NaN),
            ),
        bound_dual_complementarity_clip_max_lower_complementarity_residual_after =
            _fixed_control_float(
                get(
                    metadata,
                    "bound_dual_complementarity_clip_max_lower_complementarity_residual_after",
                    NaN,
                ),
            ),
        bound_dual_complementarity_clip_max_upper_complementarity_residual_after =
            _fixed_control_float(
                get(
                    metadata,
                    "bound_dual_complementarity_clip_max_upper_complementarity_residual_after",
                    NaN,
                ),
            ),
        grid_tspan = string(get(metadata, "grid_tspan", "missing")),
        grid_nfe = row_grid_nfe,
        grid_element_length_h = row_grid_element_length_h,
        mesh_policy = String(mesh_policy),
        mesh_breakpoints_h = join(string.(Float64.(mesh_breakpoints_h)), ","),
        mesh_min_element_length_h = Float64(mesh_min_element_length_h),
        mesh_max_element_length_h = Float64(mesh_max_element_length_h),
        collocation_degree = _fixed_control_int(
            get(metadata, "collocation_degree", get(metadata, "degree", 0)),
        ),
        nlp_structure_total_variables =
            _fixed_control_int(get(metadata, "nlp_structure_total_variables", 0)),
        nlp_structure_total_constraints =
            _fixed_control_int(get(metadata, "nlp_structure_total_constraints", 0)),
        linear_solver = _fixed_control_string(get(metadata, "solve_attempt_linear_solver", missing)),
        ipopt_profile = _fixed_control_string(get(metadata, "solve_attempt_ipopt_profile", missing)),
        ipopt_hessian_approximation = _fixed_control_string(
            get(metadata, "solve_attempt_ipopt_hessian_approximation", missing),
        ),
        solve_attempt_is_scientific_simulation =
            Bool(get(metadata, "solve_attempt_is_scientific_simulation", true)),
    )
end

_fixed_control_entrypoint_phase("begin_runtime_configuration")
policy_selection_csv = _fixed_control_env_path(
    "MPCC_FIXED_CONTROL_POLICY_SELECTION_CSV",
    joinpath("results", "dynamic_control_policy_selection_latest", "dynamic_control_policy_selection.csv"),
)
isfile(policy_selection_csv) || error("Policy selection CSV does not exist: $policy_selection_csv")

output_dir = _fixed_control_env_path(
    "MPCC_FIXED_CONTROL_OUTPUT_DIR",
    joinpath("results", "reduced_mpcc_fixed_control_policy_solve_attempt_latest"),
)
overwrite = _fixed_control_env_bool("MPCC_FIXED_CONTROL_OVERWRITE", true)
candidate_diagnostics_start_jls =
    _fixed_control_env_optional_path("MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS")
if !isempty(candidate_diagnostics_start_jls)
    isfile(candidate_diagnostics_start_jls) || error(
        "MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS does not exist: " *
        candidate_diagnostics_start_jls,
    )
end
flux_dual_start_jls =
    _fixed_control_env_optional_path("MPCC_FIXED_CONTROL_FLUX_DUAL_START_JLS")
if !isempty(flux_dual_start_jls)
    isfile(flux_dual_start_jls) || error(
        "MPCC_FIXED_CONTROL_FLUX_DUAL_START_JLS does not exist: " *
        flux_dual_start_jls,
    )
end
isempty(candidate_diagnostics_start_jls) || isempty(flux_dual_start_jls) || error(
    "Use either MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS for same-grid " *
    "complete starts or MPCC_FIXED_CONTROL_FLUX_DUAL_START_JLS for cross-horizon " *
    "flux/dual starts, not both.",
)
apply_default_start_initializers =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_APPLY_DEFAULT_START_INITIALIZERS", true)
if !apply_default_start_initializers && isempty(candidate_diagnostics_start_jls)
    error(
        "MPCC_FIXED_CONTROL_APPLY_DEFAULT_START_INITIALIZERS=0 requires " *
        "MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS with complete same-grid starts.",
    )
end
skip_sequential_simulation_for_candidate_seed = _fixed_control_env_bool(
    "MPCC_FIXED_CONTROL_SKIP_SEQUENTIAL_SIMULATION_FOR_CANDIDATE_SEED",
    false,
)
if skip_sequential_simulation_for_candidate_seed
    isempty(candidate_diagnostics_start_jls) && error(
        "MPCC_FIXED_CONTROL_SKIP_SEQUENTIAL_SIMULATION_FOR_CANDIDATE_SEED=1 requires " *
        "MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS with complete same-grid starts.",
    )
    apply_default_start_initializers && error(
        "MPCC_FIXED_CONTROL_SKIP_SEQUENTIAL_SIMULATION_FOR_CANDIDATE_SEED=1 requires " *
        "MPCC_FIXED_CONTROL_APPLY_DEFAULT_START_INITIALIZERS=0 so the serialized " *
        "candidate seed is the only start initializer.",
    )
end
candidate_id = strip(get(ENV, "MPCC_FIXED_CONTROL_CANDIDATE_ID", ""))
case_id = strip(get(ENV, "MPCC_FIXED_CONTROL_CASE_ID", ""))
solve_horizon_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_SOLVE_HOURS", 24.0)
nfe = _fixed_control_env_positive_int("MPCC_FIXED_CONTROL_NFE", 4)
degree = _fixed_control_env_positive_int("MPCC_FIXED_CONTROL_DEGREE", 3)
mesh_breakpoints_h =
    _fixed_control_parse_mesh_breakpoints(get(ENV, "MPCC_FIXED_CONTROL_MESH_BREAKPOINTS_HOURS", ""))
mesh_element_bounds =
    isempty(mesh_breakpoints_h) ? nothing : _fixed_control_element_bounds_from_breakpoints(mesh_breakpoints_h)
mesh_policy = mesh_element_bounds === nothing ? "uniform" : "explicit_breakpoints"
if mesh_element_bounds !== nothing
    nfe == length(mesh_element_bounds) || error(
        "MPCC_FIXED_CONTROL_NFE=$nfe does not match explicit mesh element count " *
        "$(length(mesh_element_bounds)) from MPCC_FIXED_CONTROL_MESH_BREAKPOINTS_HOURS.",
    )
    isapprox(mesh_breakpoints_h[1], 0.0; atol = 100.0 * eps(Float64), rtol = 0.0) ||
        error("Explicit mesh breakpoints must start at 0.0 h; got $(mesh_breakpoints_h[1]).")
    isapprox(mesh_breakpoints_h[end], solve_horizon_h; atol = 100.0 * eps(Float64), rtol = 0.0) ||
        error(
            "Explicit mesh breakpoints must end at solve_horizon_h=$solve_horizon_h; got $(mesh_breakpoints_h[end]).",
        )
end
mesh_element_lengths_h =
    mesh_element_bounds === nothing ?
    fill(solve_horizon_h / nfe, nfe) :
    [right - left for (left, right) in mesh_element_bounds]
ipopt_max_iter = _fixed_control_env_nonnegative_int("MPCC_FIXED_CONTROL_MAX_ITER", 5)
schedule_horizon_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_SCHEDULE_HOURS", 168.0)
control_interval_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_INTERVAL_HOURS", 12.0)
temperature_width_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_TEMPERATURE_WIDTH_HOURS", 1.0)
addition_width_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_ADDITION_WIDTH_HOURS", 0.5)
dynamic_control_decisions_env = _fixed_control_env_bool(
    "MPCC_FIXED_CONTROL_DYNAMIC_CONTROL_DECISIONS",
    _fixed_control_env_bool("MPCC_DYNAMIC_CONTROL_LIBERATION_ENABLED", false),
)
dynamic_control_liberation_mode = lowercase(
    strip(
        get(
            ENV,
            "MPCC_DYNAMIC_CONTROL_LIBERATION_MODE",
            dynamic_control_decisions_env ? "locked" : "off",
        ),
    ),
)
dynamic_control_decision_spec_requested =
    dynamic_control_decisions_env || !(dynamic_control_liberation_mode in ("off", "none"))
dynamic_control_temperature_slot_count = _fixed_control_env_nonnegative_int(
    "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_SLOT_COUNT",
    0,
)
dynamic_control_addition_slot_count = _fixed_control_env_nonnegative_int(
    "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_SLOT_COUNT",
    0,
)
dynamic_control_temperature_indices_raw =
    get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_INDICES", "")
dynamic_control_addition_indices_raw =
    get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_INDICES", "")
dynamic_control_temperature_start_offsets_raw =
    get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_START_OFFSETS_C", "")
dynamic_control_fda_start_offsets_raw =
    get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_START_OFFSETS_G_L", "")
dynamic_control_organic_start_offsets_raw =
    get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_START_OFFSETS_G_L", "")
dynamic_control_temperature_trust_C = _fixed_control_env_nonnegative_float(
    "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_TRUST_C",
    0.5,
)
dynamic_control_fda_trust_g_L = _fixed_control_env_nonnegative_float(
    "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_TRUST_G_L",
    0.25,
)
dynamic_control_organic_trust_g_L = _fixed_control_env_nonnegative_float(
    "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_TRUST_G_L",
    0.05,
)
dynamic_control_sample_dt_h = _fixed_control_env_positive_float(
    "MPCC_DYNAMIC_CONTROL_LIBERATION_SAMPLE_DT_HOURS",
    1.0,
)
dynamic_control_objective_config = reduced_mpcc_dynamic_control_objective_config_from_env()
sequential_saveat_h =
    _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_HOURS", 0.25)
sequential_saveat_policy =
    lowercase(strip(get(ENV, "MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_POLICY", "uniform")))
sequential_saveat_policy in ("uniform", "collocation_grid") || error(
    "MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_POLICY must be 'uniform' or 'collocation_grid', got: $sequential_saveat_policy",
)
sequential_saveat =
    sequential_saveat_policy == "collocation_grid" ?
    _fixed_control_collocation_grid_saveat(solve_horizon_h, nfe, degree, mesh_element_bounds) :
    sequential_saveat_h
sequential_saveat_point_count =
    sequential_saveat isa AbstractVector ? length(sequential_saveat) : 0
sequential_saveat_min_step_h = _fixed_control_saveat_min_step(sequential_saveat)
collocation_repair_max_iterations =
    _fixed_control_env_nonnegative_int("MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_MAX_ITER", 4)
collocation_repair_tolerance =
    _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_TOL", 1.0e-10)
collocation_repair_element_indices =
    _fixed_control_parse_element_indices(get(ENV, "MPCC_FIXED_CONTROL_COLLOCATION_REPAIR_ELEMENTS", ""))
collocation_repair_elements_label =
    _fixed_control_element_indices_label(collocation_repair_element_indices)
_fixed_control_forward_collocation_repair_env_aliases!()
bound_dual_complementarity_clip =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP", false)
bound_dual_clip_element_indices = begin
    raw_clip_elements = strip(get(ENV, "MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP_ELEMENTS", ""))
    isempty(raw_clip_elements) ?
    collocation_repair_element_indices :
    _fixed_control_parse_element_indices(raw_clip_elements)
end
bound_dual_clip_elements_label = _fixed_control_element_indices_label(bound_dual_clip_element_indices)
bound_dual_clip_budget_fraction = _fixed_control_env_positive_unit_float(
    "MPCC_FIXED_CONTROL_BOUND_DUAL_COMPLEMENTARITY_CLIP_BUDGET_FRACTION",
    0.5,
)
sequential_reconstruct_fluxes =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_SEQUENTIAL_RECONSTRUCT_FLUXES", true)
sequential_stop_on_sugar_depletion =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_SEQUENTIAL_STOP_ON_SUGAR_DEPLETION", false)
sequential_sugar_depletion_tol = _fixed_control_env_nonnegative_float(
    "MPCC_FIXED_CONTROL_SEQUENTIAL_SUGAR_DEPLETION_TOL",
    1.0e-6,
)
complementarity_mode = strip(get(ENV, "MPCC_FIXED_CONTROL_COMPLEMENTARITY_MODE", "scholtes"))
complementarity_tau =
    _fixed_control_env_nonnegative_float("MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU", 1.0e-3)
tau_continuation_enabled =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_TAU_CONTINUATION_ENABLED", false)
tau_continuation_allow_coarse_tau_fallback = _fixed_control_env_bool(
    "MPCC_FIXED_CONTROL_TAU_CONTINUATION_ALLOW_COARSE_FALLBACK",
    false,
)
linear_solver = strip(get(ENV, "MPCC_FIXED_CONTROL_LINEAR_SOLVER", ipopt_linear_solver_from_env()))
ipopt_profile = strip(get(ENV, "MPCC_FIXED_CONTROL_IPOPT_PROFILE", reduced_mpcc_ipopt_profile_name_from_env()))
require_pre_solve_ready =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_REQUIRE_PRE_SOLVE_READY", false)
pre_solve_only = _fixed_control_env_bool("MPCC_FIXED_CONTROL_PRE_SOLVE_ONLY", false)
silent = _fixed_control_env_bool("MPCC_FIXED_CONTROL_SILENT", false)
residual_location_top_n =
    _fixed_control_env_nonnegative_int("MPCC_FIXED_CONTROL_RESIDUAL_LOCATION_TOP_N", 30)
complementarity_location_top_n = _fixed_control_env_nonnegative_int(
    "MPCC_FIXED_CONTROL_COMPLEMENTARITY_LOCATION_TOP_N",
    residual_location_top_n,
)
residual_thresholds = _fixed_control_residual_thresholds()

mkpath(output_dir)
attempt_path = joinpath(output_dir, "reduced_mpcc_fixed_control_policy_solve_attempt.csv")
metadata_path = joinpath(output_dir, "reduced_mpcc_fixed_control_policy_solve_attempt.toml")
residual_location_path =
    joinpath(output_dir, "reduced_mpcc_fixed_control_policy_residual_locations.csv")
complementarity_location_path = joinpath(
    output_dir,
    "reduced_mpcc_fixed_control_policy_complementarity_locations.csv",
)
tau_continuation_stage_path =
    joinpath(output_dir, "reduced_mpcc_fixed_control_policy_tau_continuation_stages.csv")
bound_violation_location_path = joinpath(
    output_dir,
    "reduced_mpcc_fixed_control_policy_bound_violation_locations.csv",
)
rhs_residual_location_path = joinpath(
    output_dir,
    "reduced_mpcc_fixed_control_policy_rhs_residual_locations.csv",
)
repair_trace_path =
    joinpath(output_dir, "reduced_mpcc_fixed_control_policy_repair_trace.csv")
repair_substep_trace_path =
    joinpath(output_dir, "reduced_mpcc_fixed_control_policy_repair_substeps.csv")
dynamic_control_decision_spec_path =
    joinpath(output_dir, "reduced_mpcc_dynamic_control_decision_spec.csv")
dynamic_control_start_schedule_path =
    joinpath(output_dir, "reduced_mpcc_dynamic_control_start_schedule.csv")
candidate_diagnostics_path =
    joinpath(output_dir, "reduced_mpcc_fixed_control_policy_selected_candidate_diagnostics.jls")
if !overwrite
    output_targets = Any[
        attempt_path,
        metadata_path,
        residual_location_path,
        complementarity_location_path,
        tau_continuation_stage_path,
        bound_violation_location_path,
        rhs_residual_location_path,
        repair_trace_path,
        repair_substep_trace_path,
        candidate_diagnostics_path,
    ]
    if dynamic_control_decision_spec_requested
        append!(output_targets, (dynamic_control_decision_spec_path, dynamic_control_start_schedule_path))
    end
    existing_targets = [path for path in output_targets if isfile(path)]
    isempty(existing_targets) || error(
        "Fixed-control solve-attempt output file(s) already exist and overwrite=false: " *
        join(existing_targets, ", "),
    )
end

_fixed_control_entrypoint_phase("before_policy_csv_read")
policy_table = DataFrame(CSV.File(policy_selection_csv))
_fixed_control_entrypoint_phase("after_policy_csv_read")
_fixed_control_required_columns(policy_table)
selected_row = _fixed_control_selected_policy(policy_table, candidate_id)
selected_candidate_id = String(selected_row.candidate_id)
_fixed_control_entrypoint_phase("before_schedule_build")
schedule = _fixed_control_schedule_from_row(
    selected_row;
    schedule_horizon_h = schedule_horizon_h,
    control_interval_h = control_interval_h,
    temperature_width_h = temperature_width_h,
    addition_width_h = addition_width_h,
    temperature_start_offsets_raw = dynamic_control_temperature_start_offsets_raw,
    fda_start_offsets_raw = dynamic_control_fda_start_offsets_raw,
    organic_start_offsets_raw = dynamic_control_organic_start_offsets_raw,
)
dynamic_control_temperature_free_indices = Int[]
dynamic_control_addition_free_indices = Int[]
dynamic_control_temperature_start_offsets_C = _fixed_control_parse_indexed_float_offsets(
    dynamic_control_temperature_start_offsets_raw;
    max_count = length(schedule.temperature_values_C),
    label = "temperature",
)
dynamic_control_fda_start_offsets_g_L = _fixed_control_parse_indexed_float_offsets(
    dynamic_control_fda_start_offsets_raw;
    max_count = length(schedule.temperature_transition_times_h),
    label = "FDA",
)
dynamic_control_organic_start_offsets_g_L = _fixed_control_parse_indexed_float_offsets(
    dynamic_control_organic_start_offsets_raw;
    max_count = length(schedule.temperature_transition_times_h),
    label = "organic",
)
dynamic_control_decision_spec_value = nothing
if dynamic_control_decision_spec_requested
    dynamic_control_temperature_free_indices = _fixed_control_liberation_indices(
        dynamic_control_liberation_mode,
        dynamic_control_temperature_indices_raw;
        max_count = length(schedule.temperature_values_C),
        requested_count = dynamic_control_temperature_slot_count,
        label = "temperature",
    )
    dynamic_control_addition_free_indices = _fixed_control_liberation_indices(
        dynamic_control_liberation_mode,
        dynamic_control_addition_indices_raw;
        max_count = length(schedule.temperature_transition_times_h),
        requested_count = dynamic_control_addition_slot_count,
        label = "nutrient addition",
    )
    dynamic_control_decision_spec_value = dynamic_control_decision_spec(
        schedule;
        horizon_h = schedule_horizon_h,
        control_interval_h = control_interval_h,
        temperature_free_indices = dynamic_control_temperature_free_indices,
        addition_free_indices = dynamic_control_addition_free_indices,
        temperature_trust_region_C = dynamic_control_temperature_trust_C,
        fda_trust_region_g_L = dynamic_control_fda_trust_g_L,
        organic_trust_region_g_L = dynamic_control_organic_trust_g_L,
        metadata = Dict{String, Any}(
            "base_candidate_id" => selected_candidate_id,
            "control_liberation_mode" => dynamic_control_liberation_mode,
            "fully_simultaneous_controls" => true,
            "mpcc_embedding_ready" => true,
            "mpcc_fixed_control_sane_required" => true,
        ),
    )
    CSV.write(
        dynamic_control_decision_spec_path,
        dynamic_control_decision_table(dynamic_control_decision_spec_value),
    )
    dynamic_control_start_schedule =
        dynamic_control_schedule_from_decision_spec(dynamic_control_decision_spec_value)
    CSV.write(
        dynamic_control_start_schedule_path,
        DataFrame(
            sample_dynamic_control_schedule(
                dynamic_control_start_schedule;
                start_h = 0.0,
                stop_h = schedule_horizon_h,
                dt_h = dynamic_control_sample_dt_h,
            ),
        ),
    )
end
_fixed_control_entrypoint_phase("after_dynamic_control_setup")

_fixed_control_entrypoint_phase("before_model_load")
model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)
_fixed_control_entrypoint_phase("after_model_load")

params = default_zenteno_parameters()
initial_state_config = _script_initial_state_config(params)
algorithm_config = _script_ode_algorithm_config("MPCC_FIXED_CONTROL_SEQUENTIAL_ALGORITHM")
sequential_result = nothing
sequential_elapsed_seconds = 0.0
sequential_retcode = "skipped_candidate_seed"
sequential_time_points = 0
sequential_time_start = NaN
sequential_time_end = NaN
sequential_metadata = Dict{String, Any}(
    "retcode" => sequential_retcode,
    "sequential_simulation_skipped" => skip_sequential_simulation_for_candidate_seed,
    "sequential_simulation_skip_reason" =>
        skip_sequential_simulation_for_candidate_seed ?
        "complete_candidate_seed_requested_without_default_start_initializers" :
        "not_skipped",
)
if skip_sequential_simulation_for_candidate_seed
    _fixed_control_entrypoint_phase("sequential_simulation_skipped_candidate_seed")
else
    _fixed_control_entrypoint_phase("before_sequential_simulation")
    sequential_start_time = time()
    sequential_result = simulate_reduced_dfba(
        model,
        reaction_map;
        y0 = initial_state_config.y0,
        tspan = (0.0, solve_horizon_h),
        params = params,
        dynamic_control_schedule = schedule,
        silent = true,
        saveat = sequential_saveat,
        algorithm = algorithm_config.algorithm,
        reconstruct_fluxes = sequential_reconstruct_fluxes,
        stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
        sugar_depletion_tol = sequential_sugar_depletion_tol,
        model_scope = "reduced",
    )
    sequential_elapsed_seconds = time() - sequential_start_time
    sequential_retcode = string(get(sequential_result.metadata, "retcode", missing))
    sequential_time_points = length(sequential_result.time)
    sequential_time_start = first(sequential_result.time)
    sequential_time_end = last(sequential_result.time)
    sequential_metadata = sequential_result.metadata
    _fixed_control_entrypoint_phase("after_sequential_simulation")
end

candidate_diagnostics_start_seed = nothing
if !isempty(candidate_diagnostics_start_jls)
    _fixed_control_entrypoint_phase("before_candidate_diagnostics_start_deserialize")
    candidate_diagnostics_start_seed = open(candidate_diagnostics_start_jls, "r") do io
        deserialize(io)
    end
    if !(candidate_diagnostics_start_seed isa FermentationDFBA.ReducedDCDFBAMPCCCandidateDiagnostics)
        error(
            "MPCC_FIXED_CONTROL_CANDIDATE_DIAGNOSTICS_START_JLS must contain " *
            "ReducedDCDFBAMPCCCandidateDiagnostics, got " *
            string(typeof(candidate_diagnostics_start_seed)),
        )
    end
    _fixed_control_entrypoint_phase("after_candidate_diagnostics_start_deserialize")
end

flux_dual_start_seed = nothing
if !isempty(flux_dual_start_jls)
    _fixed_control_entrypoint_phase("before_flux_dual_start_deserialize")
    flux_dual_start_seed = open(flux_dual_start_jls, "r") do io
        deserialize(io)
    end
    if !(flux_dual_start_seed isa FermentationDFBA.ReducedDCDFBAMPCCCandidateDiagnostics)
        error(
            "MPCC_FIXED_CONTROL_FLUX_DUAL_START_JLS must contain " *
            "ReducedDCDFBAMPCCCandidateDiagnostics, got " *
            string(typeof(flux_dual_start_seed)),
        )
    end
    _fixed_control_entrypoint_phase("after_flux_dual_start_deserialize")
end

_fixed_control_entrypoint_phase("before_mpcc_solve_attempt")
tau_continuation_result = nothing
result = if tau_continuation_enabled
    tau_continuation_result = solve_reduced_dcdfba_mpcc_tau_continuation(
        model,
        reaction_map;
        sequential_initialization = sequential_result,
        tspan = (0.0, solve_horizon_h),
        nfe = nfe,
        degree = degree,
        element_bounds = mesh_element_bounds,
        params = params,
        residual_thresholds = residual_thresholds,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        tau_schedule = reduced_mpcc_tau_schedule_from_env([complementarity_tau]),
        tau_stage_max_iters = reduced_mpcc_tau_stage_max_iters_from_env(),
        tau_final_retry_max_iter = reduced_mpcc_tau_final_retry_max_iter_from_env(),
        allow_coarse_tau_fallback = tau_continuation_allow_coarse_tau_fallback,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = dynamic_control_decision_spec_value,
        dynamic_control_objective_config = dynamic_control_objective_config,
        collocation_consistent_state_start_max_iterations = collocation_repair_max_iterations,
        collocation_consistent_state_start_tolerance = collocation_repair_tolerance,
        collocation_consistent_state_start_element_indices = collocation_repair_element_indices,
        bound_dual_complementarity_clip = bound_dual_complementarity_clip,
        bound_dual_complementarity_clip_element_indices = bound_dual_clip_element_indices,
        bound_dual_complementarity_clip_budget_fraction = bound_dual_clip_budget_fraction,
        apply_default_start_initializers = apply_default_start_initializers,
        candidate_start_seed = candidate_diagnostics_start_seed,
        flux_dual_start_seed = flux_dual_start_seed,
        require_pre_solve_ready = require_pre_solve_ready,
        pre_solve_only = pre_solve_only,
        silent = silent,
    )
    tau_continuation_result.final_result === nothing && error(
        "Tau-continuation solve did not produce a final result.",
    )
    tau_continuation_result.final_result
else
    solve_reduced_dcdfba_mpcc_solve_attempt(
        model,
        reaction_map;
        sequential_initialization = sequential_result,
        tspan = (0.0, solve_horizon_h),
        nfe = nfe,
        degree = degree,
        element_bounds = mesh_element_bounds,
        params = params,
        residual_thresholds = residual_thresholds,
        ipopt_max_iter = ipopt_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        dynamic_control_schedule = schedule,
        dynamic_control_decision_spec = dynamic_control_decision_spec_value,
        dynamic_control_objective_config = dynamic_control_objective_config,
        collocation_consistent_state_start_max_iterations = collocation_repair_max_iterations,
        collocation_consistent_state_start_tolerance = collocation_repair_tolerance,
        collocation_consistent_state_start_element_indices = collocation_repair_element_indices,
        bound_dual_complementarity_clip = bound_dual_complementarity_clip,
        bound_dual_complementarity_clip_element_indices = bound_dual_clip_element_indices,
        bound_dual_complementarity_clip_budget_fraction = bound_dual_clip_budget_fraction,
        apply_default_start_initializers = apply_default_start_initializers,
        candidate_start_seed = candidate_diagnostics_start_seed,
        flux_dual_start_seed = flux_dual_start_seed,
        require_pre_solve_ready = require_pre_solve_ready,
        pre_solve_only = pre_solve_only,
        silent = silent,
    )
end
_fixed_control_entrypoint_phase("after_mpcc_solve_attempt")
merge!(
    result.metadata,
    Dict{String, Any}(
        "tau_continuation_entrypoint_enabled" => tau_continuation_enabled,
        "tau_continuation_allow_coarse_tau_fallback_requested" =>
            tau_continuation_allow_coarse_tau_fallback,
        "tau_continuation_stage_csv" =>
            tau_continuation_enabled ? tau_continuation_stage_path : "",
        "sequential_saveat_h" => sequential_saveat_h,
        "sequential_saveat_policy" => sequential_saveat_policy,
        "sequential_saveat_point_count" => sequential_saveat_point_count,
        "sequential_saveat_min_step_h" => sequential_saveat_min_step_h,
        "candidate_diagnostics_start_jls" => candidate_diagnostics_start_jls,
        "candidate_diagnostics_start_jls_requested" => !isempty(candidate_diagnostics_start_jls),
        "candidate_diagnostics_start_jls_loaded" => candidate_diagnostics_start_seed !== nothing,
        "apply_default_start_initializers" => apply_default_start_initializers,
        "default_start_initializers_applied" => apply_default_start_initializers,
        "default_start_initializers_skip_reason" =>
            apply_default_start_initializers ? "not_skipped" : "disabled_by_entrypoint",
        "skip_sequential_simulation_for_candidate_seed" =>
            skip_sequential_simulation_for_candidate_seed,
        "flux_dual_start_jls" => flux_dual_start_jls,
        "flux_dual_start_jls_requested" => !isempty(flux_dual_start_jls),
        "flux_dual_start_jls_loaded" => flux_dual_start_seed !== nothing,
        "dynamic_control_decision_spec_requested" => dynamic_control_decision_spec_requested,
        "dynamic_control_liberation_mode" => dynamic_control_liberation_mode,
        "dynamic_control_objective_env_keys" =>
            join(FIXED_CONTROL_DYNAMIC_OBJECTIVE_ENV_KEYS, ","),
        "dynamic_control_temperature_free_indices" => dynamic_control_temperature_free_indices,
        "dynamic_control_addition_free_indices" => dynamic_control_addition_free_indices,
        "dynamic_control_temperature_free_indices_label" =>
            _fixed_control_index_label(dynamic_control_temperature_free_indices),
        "dynamic_control_addition_free_indices_label" =>
            _fixed_control_index_label(dynamic_control_addition_free_indices),
        "dynamic_control_temperature_trust_C" => dynamic_control_temperature_trust_C,
        "dynamic_control_fda_trust_g_L" => dynamic_control_fda_trust_g_L,
        "dynamic_control_organic_trust_g_L" => dynamic_control_organic_trust_g_L,
        "dynamic_control_temperature_start_offsets_raw" =>
            dynamic_control_temperature_start_offsets_raw,
        "dynamic_control_fda_start_offsets_raw" => dynamic_control_fda_start_offsets_raw,
        "dynamic_control_organic_start_offsets_raw" =>
            dynamic_control_organic_start_offsets_raw,
        "dynamic_control_temperature_start_offsets_C" =>
            dynamic_control_temperature_start_offsets_C,
        "dynamic_control_fda_start_offsets_g_L" => dynamic_control_fda_start_offsets_g_L,
        "dynamic_control_organic_start_offsets_g_L" =>
            dynamic_control_organic_start_offsets_g_L,
        "dynamic_control_decision_spec_csv" =>
            dynamic_control_decision_spec_requested ? dynamic_control_decision_spec_path : "",
        "dynamic_control_start_schedule_csv" =>
            dynamic_control_decision_spec_requested ? dynamic_control_start_schedule_path : "",
    ),
)
merge!(
    result.metadata,
    _fixed_control_candidate_terminal_state_metadata(
        result.candidate_diagnostics;
        prefix = "selected_candidate",
    ),
)

_fixed_control_entrypoint_phase("before_output_writes")
attempt_table = DataFrame([
    _fixed_control_solve_attempt_row(
        selected_candidate_id,
        result;
        case_id = case_id,
        solve_horizon_h = solve_horizon_h,
        ipopt_max_iter = ipopt_max_iter,
        collocation_repair_elements = collocation_repair_elements_label,
        bound_dual_clip_elements = bound_dual_clip_elements_label,
        mesh_policy = mesh_policy,
        mesh_breakpoints_h = mesh_breakpoints_h,
        mesh_min_element_length_h = minimum(mesh_element_lengths_h),
        mesh_max_element_length_h = maximum(mesh_element_lengths_h),
    ),
])
CSV.write(attempt_path, attempt_table)

residual_location_table = _fixed_control_residual_location_table(
    result.candidate_diagnostics;
    solve_horizon_h = solve_horizon_h,
    nfe = nfe,
    degree = degree,
    top_n = residual_location_top_n,
    mesh_element_bounds = mesh_element_bounds,
)
CSV.write(residual_location_path, residual_location_table)

complementarity_location_table = _fixed_control_complementarity_location_table(
    result;
    top_n = complementarity_location_top_n,
)
CSV.write(complementarity_location_path, complementarity_location_table)
tau_continuation_stage_table =
    tau_continuation_result === nothing ? DataFrame() : tau_continuation_result.stage_table
CSV.write(tau_continuation_stage_path, tau_continuation_stage_table)

bound_violation_location_table = _fixed_control_bound_violation_location_table(
    result;
    top_n = residual_location_top_n,
)
CSV.write(bound_violation_location_path, bound_violation_location_table)

rhs_residual_location_table = _fixed_control_rhs_residual_location_table(
    result;
    top_n = residual_location_top_n,
)
CSV.write(rhs_residual_location_path, rhs_residual_location_table)

repair_trace_table = _fixed_control_repair_trace_table(result.metadata)
CSV.write(repair_trace_path, repair_trace_table)
repair_substep_trace_table = _fixed_control_repair_substep_trace_table(result.metadata)
CSV.write(repair_substep_trace_path, repair_substep_trace_table)

candidate_metadata =
    result.candidate_diagnostics === nothing ? Dict{String, Any}() : result.candidate_diagnostics.metadata
candidate_diagnostics_written = result.candidate_diagnostics !== nothing
if candidate_diagnostics_written
    open(candidate_diagnostics_path, "w") do io
        serialize(io, result.candidate_diagnostics)
    end
end
top_residual_location =
    nrow(residual_location_table) == 0 ? Dict{String, Any}() :
    Dict{String, Any}(
        String(name) => residual_location_table[1, name] for name in names(residual_location_table)
    )
top_complementarity_location =
    nrow(complementarity_location_table) == 0 ? Dict{String, Any}() :
    Dict{String, Any}(
        String(name) => complementarity_location_table[1, name] for
        name in names(complementarity_location_table)
    )
top_bound_violation_location =
    nrow(bound_violation_location_table) == 0 ? Dict{String, Any}() :
    Dict{String, Any}(
        String(name) => bound_violation_location_table[1, name] for
        name in names(bound_violation_location_table)
    )
top_rhs_residual_location =
    nrow(rhs_residual_location_table) == 0 ? Dict{String, Any}() :
    Dict{String, Any}(
        String(name) => rhs_residual_location_table[1, name] for
        name in names(rhs_residual_location_table)
    )
metadata = Dict{String, Any}(
    "script" => FIXED_CONTROL_SOLVE_ATTEMPT_SCRIPT,
    "created_at" => Dates.format(Dates.now(), dateformat"yyyy-mm-ddTHH:MM:SS"),
    "policy_selection_csv" => policy_selection_csv,
    "output_dir" => output_dir,
    "attempt_csv" => attempt_path,
    "metadata_toml" => metadata_path,
    "residual_location_csv" => residual_location_path,
    "residual_location_top_n" => residual_location_top_n,
    "top_residual_location" => top_residual_location,
    "complementarity_location_csv" => complementarity_location_path,
    "complementarity_location_top_n" => complementarity_location_top_n,
    "top_complementarity_location" => top_complementarity_location,
    "tau_continuation_enabled" => tau_continuation_enabled,
    "tau_continuation_stage_csv" => tau_continuation_stage_path,
    "tau_continuation_stage_row_count" => nrow(tau_continuation_stage_table),
    "tau_continuation_metadata" =>
        tau_continuation_result === nothing ? Dict{String, Any}() : tau_continuation_result.metadata,
    "bound_violation_location_csv" => bound_violation_location_path,
    "bound_violation_location_top_n" => residual_location_top_n,
    "top_bound_violation_location" => top_bound_violation_location,
    "rhs_residual_location_csv" => rhs_residual_location_path,
    "rhs_residual_location_top_n" => residual_location_top_n,
    "top_rhs_residual_location" => top_rhs_residual_location,
    "repair_trace_csv" => repair_trace_path,
    "repair_trace_row_count" => nrow(repair_trace_table),
    "repair_substep_trace_csv" => repair_substep_trace_path,
    "repair_substep_trace_row_count" => nrow(repair_substep_trace_table),
    "candidate_diagnostics_jls" =>
        candidate_diagnostics_written ? candidate_diagnostics_path : "",
    "candidate_diagnostics_jls_written" => candidate_diagnostics_written,
    "case_id" => isempty(case_id) ? selected_candidate_id : case_id,
    "selected_candidate_id" => selected_candidate_id,
    "solve_horizon_h" => solve_horizon_h,
    "nfe" => nfe,
    "degree" => degree,
    "mesh_policy" => mesh_policy,
    "mesh_breakpoints_h" => mesh_breakpoints_h,
    "mesh_element_lengths_h" => mesh_element_lengths_h,
    "mesh_min_element_length_h" => minimum(mesh_element_lengths_h),
    "mesh_max_element_length_h" => maximum(mesh_element_lengths_h),
    "ipopt_max_iter" => ipopt_max_iter,
    "schedule_horizon_h" => schedule_horizon_h,
    "control_interval_h" => control_interval_h,
    "temperature_width_h" => temperature_width_h,
    "addition_width_h" => addition_width_h,
    "dynamic_control_decision_spec_requested" => dynamic_control_decision_spec_requested,
    "dynamic_control_decision_spec_csv" =>
        dynamic_control_decision_spec_requested ? dynamic_control_decision_spec_path : "",
    "dynamic_control_start_schedule_csv" =>
        dynamic_control_decision_spec_requested ? dynamic_control_start_schedule_path : "",
    "dynamic_control_liberation_mode" => dynamic_control_liberation_mode,
    "dynamic_control_temperature_slot_count" => dynamic_control_temperature_slot_count,
    "dynamic_control_addition_slot_count" => dynamic_control_addition_slot_count,
    "dynamic_control_temperature_free_indices" => dynamic_control_temperature_free_indices,
    "dynamic_control_addition_free_indices" => dynamic_control_addition_free_indices,
    "dynamic_control_temperature_trust_C" => dynamic_control_temperature_trust_C,
    "dynamic_control_fda_trust_g_L" => dynamic_control_fda_trust_g_L,
    "dynamic_control_organic_trust_g_L" => dynamic_control_organic_trust_g_L,
    "dynamic_control_temperature_start_offsets_raw" =>
        dynamic_control_temperature_start_offsets_raw,
    "dynamic_control_fda_start_offsets_raw" => dynamic_control_fda_start_offsets_raw,
    "dynamic_control_organic_start_offsets_raw" => dynamic_control_organic_start_offsets_raw,
    "dynamic_control_temperature_start_offsets_C" => dynamic_control_temperature_start_offsets_C,
    "dynamic_control_fda_start_offsets_g_L" => dynamic_control_fda_start_offsets_g_L,
    "dynamic_control_organic_start_offsets_g_L" => dynamic_control_organic_start_offsets_g_L,
    "dynamic_control_sample_dt_h" => dynamic_control_sample_dt_h,
    "collocation_repair_max_iterations" => collocation_repair_max_iterations,
    "collocation_repair_tolerance" => collocation_repair_tolerance,
    "collocation_repair_elements" => collocation_repair_elements_label,
    "collocation_repair_element_indices" =>
        collocation_repair_element_indices === nothing ?
        "all" :
        collect(collocation_repair_element_indices),
    "bound_dual_complementarity_clip" => bound_dual_complementarity_clip,
    "bound_dual_complementarity_clip_elements" => bound_dual_clip_elements_label,
    "bound_dual_complementarity_clip_element_indices" =>
        bound_dual_clip_element_indices === nothing ? "all" : collect(bound_dual_clip_element_indices),
    "bound_dual_complementarity_clip_budget_fraction" => bound_dual_clip_budget_fraction,
    "sequential_saveat_h" => sequential_saveat_h,
    "sequential_saveat_policy" => sequential_saveat_policy,
    "sequential_saveat_point_count" => sequential_saveat_point_count,
    "sequential_saveat_min_step_h" => sequential_saveat_min_step_h,
    "sequential_saveat_values" =>
        sequential_saveat isa AbstractVector ? Float64.(sequential_saveat) : Float64[],
    "sequential_reconstruct_fluxes" => sequential_reconstruct_fluxes,
    "sequential_stop_on_sugar_depletion" => sequential_stop_on_sugar_depletion,
    "sequential_sugar_depletion_tol" => sequential_sugar_depletion_tol,
    "sequential_algorithm_label" => algorithm_config.algorithm_label,
    "sequential_elapsed_seconds" => sequential_elapsed_seconds,
    "sequential_time_points" => sequential_time_points,
    "sequential_time_start" => sequential_time_start,
    "sequential_time_end" => sequential_time_end,
    "sequential_retcode" => sequential_retcode,
    "sequential_metadata" => sequential_metadata,
    "skip_sequential_simulation_for_candidate_seed" =>
        skip_sequential_simulation_for_candidate_seed,
    "initial_state_metadata" => initial_state_config.metadata,
    "linear_solver" => linear_solver,
    "ipopt_profile" => ipopt_profile,
    "complementarity_mode" => complementarity_mode,
    "complementarity_tau" => complementarity_tau,
    "tau_continuation_entrypoint_enabled" => tau_continuation_enabled,
    "tau_continuation_allow_coarse_tau_fallback_requested" =>
        tau_continuation_allow_coarse_tau_fallback,
    "require_pre_solve_ready" => require_pre_solve_ready,
    "pre_solve_only" => pre_solve_only,
    "residual_thresholds" => Dict{String, Any}(
        "max_rhs_residual" => residual_thresholds.max_rhs_residual,
        "max_mass_balance_residual" => residual_thresholds.max_mass_balance_residual,
        "max_lower_bound_violation" => residual_thresholds.max_lower_bound_violation,
        "max_upper_bound_violation" => residual_thresholds.max_upper_bound_violation,
        "max_stationarity_residual" => residual_thresholds.max_stationarity_residual,
        "max_lower_complementarity_residual" =>
            residual_thresholds.max_lower_complementarity_residual,
        "max_upper_complementarity_residual" =>
            residual_thresholds.max_upper_complementarity_residual,
    ),
    "silent" => silent,
    "solver_call_performed" => Bool(get(result.metadata, "solver_call_performed", false)),
    "solver_status" => string(result.smoke_result.status),
    "primal_status" => string(result.smoke_result.primal_status),
    "solver_name" => result.smoke_result.solver_name,
    "residual_report" => result.residual_report,
    "result_metadata" => result.metadata,
    "candidate_metadata" => candidate_metadata,
    "solve_attempt_is_scientific_simulation" => false,
)
open(metadata_path, "w") do io
    TOML.print(io, _fixed_control_toml_normalize(metadata))
end
_fixed_control_entrypoint_phase("after_output_writes")

println("Reduced MPCC fixed-control policy solve attempt")
println("policy_selection_csv: $policy_selection_csv")
println("output_dir: $output_dir")
println("attempt_csv: $attempt_path")
println("metadata_toml: $metadata_path")
println("residual_location_csv: $residual_location_path")
println("complementarity_location_csv: $complementarity_location_path")
println("tau_continuation_stage_csv: $tau_continuation_stage_path")
println("bound_violation_location_csv: $bound_violation_location_path")
println("rhs_residual_location_csv: $rhs_residual_location_path")
println("repair_trace_csv: $repair_trace_path")
println("repair_substep_trace_csv: $repair_substep_trace_path")
println("candidate_diagnostics_jls: $(candidate_diagnostics_written ? candidate_diagnostics_path : "missing")")
println("candidate_diagnostics_start_jls: $(isempty(candidate_diagnostics_start_jls) ? "missing" : candidate_diagnostics_start_jls)")
println("candidate_diagnostics_start_jls_loaded: $(candidate_diagnostics_start_seed !== nothing)")
println("apply_default_start_initializers: $apply_default_start_initializers")
println("skip_sequential_simulation_for_candidate_seed: $skip_sequential_simulation_for_candidate_seed")
println("flux_dual_start_jls: $(isempty(flux_dual_start_jls) ? "missing" : flux_dual_start_jls)")
println("flux_dual_start_jls_loaded: $(flux_dual_start_seed !== nothing)")
println("case_id: $(isempty(case_id) ? selected_candidate_id : case_id)")
println("selected_candidate_id: $selected_candidate_id")
println("solve_horizon_h: $solve_horizon_h")
println("nfe: $nfe")
println("degree: $degree")
println("mesh_policy: $mesh_policy")
println("mesh_min_element_length_h: $(minimum(mesh_element_lengths_h))")
println("mesh_max_element_length_h: $(maximum(mesh_element_lengths_h))")
println("ipopt_max_iter: $ipopt_max_iter")
println("dynamic_control_decision_spec_requested: $dynamic_control_decision_spec_requested")
println("dynamic_control_liberation_mode: $dynamic_control_liberation_mode")
println(
    "dynamic_control_temperature_free_indices: " *
    _fixed_control_index_label(dynamic_control_temperature_free_indices),
)
println(
    "dynamic_control_addition_free_indices: " *
    _fixed_control_index_label(dynamic_control_addition_free_indices),
)
println("dynamic_control_temperature_trust_C: $dynamic_control_temperature_trust_C")
println("dynamic_control_fda_trust_g_L: $dynamic_control_fda_trust_g_L")
println("dynamic_control_organic_trust_g_L: $dynamic_control_organic_trust_g_L")
println(
    "dynamic_control_temperature_start_offsets_C: " *
    join(dynamic_control_temperature_start_offsets_C, ","),
)
println("dynamic_control_fda_start_offsets_g_L: " * join(dynamic_control_fda_start_offsets_g_L, ","))
println(
    "dynamic_control_organic_start_offsets_g_L: " *
    join(dynamic_control_organic_start_offsets_g_L, ","),
)
if dynamic_control_decision_spec_requested
    println("dynamic_control_decision_spec_csv: $dynamic_control_decision_spec_path")
    println("dynamic_control_start_schedule_csv: $dynamic_control_start_schedule_path")
end
println("collocation_repair_max_iterations: $collocation_repair_max_iterations")
println("collocation_repair_tolerance: $collocation_repair_tolerance")
println("collocation_repair_elements: $collocation_repair_elements_label")
println("bound_dual_complementarity_clip: $bound_dual_complementarity_clip")
println("bound_dual_complementarity_clip_elements: $bound_dual_clip_elements_label")
println("bound_dual_complementarity_clip_budget_fraction: $bound_dual_clip_budget_fraction")
println("sequential_saveat_h: $sequential_saveat_h")
println("sequential_saveat_policy: $sequential_saveat_policy")
println("sequential_saveat_point_count: $sequential_saveat_point_count")
println("sequential_saveat_min_step_h: $sequential_saveat_min_step_h")
println("sequential_algorithm_label: $(algorithm_config.algorithm_label)")
println("sequential_reconstruct_fluxes: $sequential_reconstruct_fluxes")
println("sequential_stop_on_sugar_depletion: $sequential_stop_on_sugar_depletion")
println("sequential_sugar_depletion_tol: $sequential_sugar_depletion_tol")
println("sequential_elapsed_seconds: $sequential_elapsed_seconds")
println("sequential_time_points: $sequential_time_points")
println("sequential_time_end: $sequential_time_end")
println("sequential_retcode: $sequential_retcode")
println("linear_solver: $linear_solver")
println("ipopt_profile: $ipopt_profile")
println("complementarity_mode: $complementarity_mode")
println("complementarity_tau: $complementarity_tau")
println("tau_continuation_entrypoint_enabled: $tau_continuation_enabled")
println("tau_continuation_allow_coarse_tau_fallback_requested: $tau_continuation_allow_coarse_tau_fallback")
println("tau_continuation_stage_count: $(get(result.metadata, "tau_continuation_stage_count", missing))")
println("tau_continuation_selected_tau: $(get(result.metadata, "tau_continuation_selected_tau", missing))")
println("tau_continuation_selected_reason: $(get(result.metadata, "tau_continuation_selected_reason", missing))")
println("tau_continuation_blocking_reason: $(get(result.metadata, "tau_continuation_blocking_reason", missing))")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("pre_solve_only: $pre_solve_only")
println("silent: $silent")
println("solver_call_performed: $(get(result.metadata, "solver_call_performed", false))")
println("solver_status: $(result.smoke_result.status)")
println("primal_status: $(result.smoke_result.primal_status)")
println("solver_name: $(result.smoke_result.solver_name)")
println("objective_value: $(result.smoke_result.objective_value)")
println("solve_elapsed_seconds: $(result.smoke_result.solve_elapsed_seconds)")
println("residuals_available: $(result.residuals_available)")
println("residual_thresholds_satisfied: $(result.residual_thresholds_satisfied)")
println("dominant_residual: $(get(result.metadata, "dominant_residual", missing))")
println("top_complementarity_location_reaction_id: $(get(result.metadata, "top_complementarity_location_reaction_id", missing))")
println("top_complementarity_location_residual_type: $(get(result.metadata, "top_complementarity_location_residual_type", missing))")
println("top_complementarity_location_abs_product: $(get(result.metadata, "top_complementarity_location_abs_product", missing))")
println("max_rhs_residual: $(get(result.metadata, "max_rhs_residual", missing))")
println("max_collocation_integration_residual: $(get(result.metadata, "max_collocation_integration_residual", missing))")
println("max_continuity_residual: $(get(result.metadata, "max_continuity_residual", missing))")
println("max_mass_balance_residual: $(result.smoke_result.max_mass_balance_residual)")
println("max_lower_bound_violation: $(result.smoke_result.max_lower_bound_violation)")
println("max_upper_bound_violation: $(result.smoke_result.max_upper_bound_violation)")
println("max_stationarity_residual: $(result.smoke_result.max_stationarity_residual)")
println("max_lower_complementarity_residual: $(result.smoke_result.max_lower_complementarity_residual)")
println("max_upper_complementarity_residual: $(result.smoke_result.max_upper_complementarity_residual)")
println("candidate_values_available: $(get(result.metadata, "candidate_values_available", false))")
println("candidate_residual_feasible: $(get(result.metadata, "candidate_residual_feasible", false))")
println("candidate_trajectory_extraction_ready: $(get(result.metadata, "candidate_trajectory_extraction_ready", false))")
println("candidate_values_source: $(get(result.metadata, "candidate_values_source", missing))")
println("candidate_selection_policy: $(get(result.metadata, "candidate_selection_policy", missing))")
println("candidate_selection_reason: $(get(result.metadata, "candidate_selection_reason", missing))")
println("selected_candidate_source: $(get(result.metadata, "selected_candidate_source", missing))")
println("selected_candidate_is_post_solve: $(get(result.metadata, "selected_candidate_is_post_solve", false))")
println("selected_candidate_is_pre_solve_start: $(get(result.metadata, "selected_candidate_is_pre_solve_start", false))")
println("selected_candidate_residual_feasible: $(get(result.metadata, "selected_candidate_residual_feasible", false))")
println("selected_candidate_trajectory_ready: $(get(result.metadata, "selected_candidate_trajectory_ready", false))")
println("selected_candidate_terminal_state_values_available: $(get(result.metadata, "selected_candidate_terminal_state_values_available", false))")
println("selected_candidate_terminal_glucose_g_L: $(get(result.metadata, "selected_candidate_terminal_glucose_g_L", missing))")
println("selected_candidate_terminal_fructose_g_L: $(get(result.metadata, "selected_candidate_terminal_fructose_g_L", missing))")
println("selected_candidate_terminal_total_sugar_g_L: $(get(result.metadata, "selected_candidate_terminal_total_sugar_g_L", missing))")
println("selected_candidate_terminal_isoamyl_alcohol_g_L: $(get(result.metadata, "selected_candidate_terminal_isoamyl_alcohol_g_L", missing))")
println("pre_solve_candidate_residual_feasible: $(get(result.metadata, "pre_solve_candidate_residual_feasible", false))")
println("post_solve_candidate_residual_feasible: $(get(result.metadata, "post_solve_candidate_residual_feasible", false))")
println("post_solve_candidate_accepted: $(get(result.metadata, "post_solve_candidate_accepted", false))")
println("post_solve_candidate_rejected: $(get(result.metadata, "post_solve_candidate_rejected", false))")
println("post_solve_candidate_rejection_reason: $(get(result.metadata, "post_solve_candidate_rejection_reason", missing))")
println("mpcc_dynamic_control_decision_spec_provided: $(get(result.metadata, "mpcc_dynamic_control_decision_spec_provided", missing))")
println("mpcc_dynamic_control_variable_policy: $(get(result.metadata, "mpcc_dynamic_control_variable_policy", missing))")
println("mpcc_dynamic_control_variables_coupled_to_rhs: $(get(result.metadata, "mpcc_dynamic_control_variables_coupled_to_rhs", missing))")
println("mpcc_dynamic_control_variables_coupled_to_dynamic_bounds: $(get(result.metadata, "mpcc_dynamic_control_variables_coupled_to_dynamic_bounds", missing))")
println("rhs_residual_uses_control_decision_variables: $(get(result.metadata, "rhs_residual_uses_control_decision_variables", missing))")
println("dynamic_flux_bounds_use_control_decision_variables: $(get(result.metadata, "dynamic_flux_bounds_use_control_decision_variables", missing))")
println("fully_simultaneous_controls: $(get(result.metadata, "fully_simultaneous_controls", missing))")
println("control_variable_count: $(get(result.metadata, "control_variable_count", missing))")
println("control_free_variable_count: $(get(result.metadata, "control_free_variable_count", missing))")
println("free_temperature_count: $(get(result.metadata, "free_temperature_count", missing))")
println("free_fda_count: $(get(result.metadata, "free_fda_count", missing))")
println("free_organic_count: $(get(result.metadata, "free_organic_count", missing))")
println("dynamic_control_reference_regularization_enabled: $(get(result.metadata, "dynamic_control_reference_regularization_enabled", missing))")
println("dynamic_control_reference_regularization_weight: $(get(result.metadata, "dynamic_control_reference_regularization_weight", missing))")
println("dynamic_control_reference_regularization_term_count: $(get(result.metadata, "dynamic_control_reference_regularization_term_count", missing))")
println("dynamic_control_objective_enabled: $(get(result.metadata, "dynamic_control_objective_enabled", missing))")
println("dynamic_control_objective_mode: $(get(result.metadata, "dynamic_control_objective_mode", missing))")
println("dynamic_control_objective_policy: $(get(result.metadata, "dynamic_control_objective_policy", missing))")
println("dynamic_control_objective_requested_target_state: $(get(result.metadata, "dynamic_control_objective_requested_target_state", missing))")
println("dynamic_control_objective_resolved_target_state: $(get(result.metadata, "dynamic_control_objective_resolved_target_state", missing))")
println("dynamic_control_objective_target_state_alias_policy: $(get(result.metadata, "dynamic_control_objective_target_state_alias_policy", missing))")
println("dynamic_control_objective_target_component_count: $(get(result.metadata, "dynamic_control_objective_target_component_count", missing))")
println("dynamic_control_objective_target_component_names: $(get(result.metadata, "dynamic_control_objective_target_component_names", missing))")
println("dynamic_control_objective_terminal_reward_weight: $(get(result.metadata, "dynamic_control_objective_terminal_reward_weight", missing))")
println("dynamic_control_objective_terminal_state_scale_g_L: $(get(result.metadata, "dynamic_control_objective_terminal_state_scale_g_L", missing))")
println("dynamic_control_objective_terminal_sugar_weight: $(get(result.metadata, "dynamic_control_objective_terminal_sugar_weight", missing))")
println("dynamic_control_objective_terminal_sugar_scale_g_L: $(get(result.metadata, "dynamic_control_objective_terminal_sugar_scale_g_L", missing))")
println("dynamic_control_objective_integrated_sugar_weight: $(get(result.metadata, "dynamic_control_objective_integrated_sugar_weight", missing))")
println("dynamic_control_objective_integrated_sugar_scale_g_L: $(get(result.metadata, "dynamic_control_objective_integrated_sugar_scale_g_L", missing))")
println("dynamic_control_objective_aroma_reward_policy: $(get(result.metadata, "dynamic_control_objective_aroma_reward_policy", missing))")
println("dynamic_control_objective_integrated_aroma_reward_terms: $(get(result.metadata, "dynamic_control_objective_integrated_aroma_reward_terms", missing))")
println("dynamic_control_objective_terminal_sugar_terms: $(get(result.metadata, "dynamic_control_objective_terminal_sugar_terms", missing))")
println("dynamic_control_objective_integrated_sugar_terms: $(get(result.metadata, "dynamic_control_objective_integrated_sugar_terms", missing))")
println("dynamic_control_objective_nutrient_weight: $(get(result.metadata, "dynamic_control_objective_nutrient_weight", missing))")
println("dynamic_control_objective_thermal_energy_weight: $(get(result.metadata, "dynamic_control_objective_thermal_energy_weight", missing))")
println("dynamic_control_objective_temperature_smoothness_weight: $(get(result.metadata, "dynamic_control_objective_temperature_smoothness_weight", missing))")
println("dynamic_control_objective_term_count: $(get(result.metadata, "dynamic_control_objective_term_count", missing))")
println("collocation_consistent_state_start_final_selective_dual_fit_enabled: $(get(result.metadata, "collocation_consistent_state_start_final_selective_dual_fit_enabled", missing))")
println("collocation_consistent_state_start_last_final_selective_dual_fit_applied: $(get(result.metadata, "collocation_consistent_state_start_last_final_selective_dual_fit_applied", missing))")
println("collocation_consistent_state_start_final_complementarity_flux_projection_enabled: $(get(result.metadata, "collocation_consistent_state_start_final_complementarity_flux_projection_enabled", missing))")
println("collocation_consistent_state_start_last_final_complementarity_flux_projection_applied: $(get(result.metadata, "collocation_consistent_state_start_last_final_complementarity_flux_projection_applied", missing))")
println("active_complementarity_flux_projection_triggered_points: $(get(result.metadata, "active_complementarity_flux_projection_triggered_points", missing))")
println("active_complementarity_flux_projection_max_lower_complementarity_after: $(get(result.metadata, "active_complementarity_flux_projection_max_lower_complementarity_after", missing))")
println("active_complementarity_flux_projection_guard_enabled: $(get(result.metadata, "active_complementarity_flux_projection_guard_enabled", missing))")
println("active_complementarity_flux_projection_guard_accepted: $(get(result.metadata, "active_complementarity_flux_projection_guard_accepted", missing))")
println("active_complementarity_flux_projection_guard_before_score: $(get(result.metadata, "active_complementarity_flux_projection_guard_before_score", missing))")
println("active_complementarity_flux_projection_guard_after_score: $(get(result.metadata, "active_complementarity_flux_projection_guard_after_score", missing))")
println("selective_fixed_flux_stationarity_dual_fit_accepted: $(get(result.metadata, "selective_fixed_flux_stationarity_dual_fit_accepted", missing))")
println("selective_fixed_flux_stationarity_dual_fit_element_count: $(get(result.metadata, "selective_fixed_flux_stationarity_dual_fit_element_count", missing))")
println("selective_fixed_flux_stationarity_dual_fit_max_stationarity_residual_after: $(get(result.metadata, "selective_fixed_flux_stationarity_dual_fit_max_stationarity_residual_after", missing))")
println("selective_fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after: $(get(result.metadata, "selective_fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after", missing))")
println("collocation_consistent_state_start_final_state_after_rhs_guard_enabled: $(get(result.metadata, "collocation_consistent_state_start_final_state_after_rhs_guard_enabled", missing))")
println("collocation_consistent_state_start_final_state_after_rhs_guard_accepted: $(get(result.metadata, "collocation_consistent_state_start_final_state_after_rhs_guard_accepted", missing))")
println("collocation_consistent_state_start_final_state_after_rhs_guard_accepted_damping_factor: $(get(result.metadata, "collocation_consistent_state_start_final_state_after_rhs_guard_accepted_damping_factor", missing))")
println("collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_enabled: $(get(result.metadata, "collocation_consistent_state_start_final_state_after_rhs_guard_rhs_refresh_enabled", missing))")
println("collocation_consistent_state_start_final_state_after_rhs_guard_before_primal_structural_residual: $(get(result.metadata, "collocation_consistent_state_start_final_state_after_rhs_guard_before_primal_structural_residual", missing))")
println("collocation_consistent_state_start_final_state_after_rhs_guard_after_primal_structural_residual: $(get(result.metadata, "collocation_consistent_state_start_final_state_after_rhs_guard_after_primal_structural_residual", missing))")
if nrow(residual_location_table) > 0
    top = residual_location_table[1, :]
    println(
        "top_residual_location: type=$(top.residual_type) time_h=$(top.time_h) " *
        "element=$(top.element_index) collocation=$(top.collocation_index) " *
        "state=$(top.state_name) residual=$(top.residual) abs=$(top.abs_residual)",
    )
end
if nrow(complementarity_location_table) > 0
    top = complementarity_location_table[1, :]
    println(
        "top_complementarity_location: type=$(top.residual_type) time_h=$(top.time_h) " *
        "element=$(top.element_index) collocation=$(top.collocation_index) " *
        "reaction=$(top.reaction_id) product=$(top.product) abs=$(top.abs_product)",
    )
end
if nrow(bound_violation_location_table) > 0
    top = bound_violation_location_table[1, :]
    println(
        "top_bound_violation_location: type=$(top.residual_type) time_h=$(top.time_h) " *
        "element=$(top.element_index) collocation=$(top.collocation_index) " *
        "reaction=$(top.reaction_id) violation=$(top.violation)",
    )
end
if nrow(rhs_residual_location_table) > 0
    top = rhs_residual_location_table[1, :]
    println(
        "top_rhs_residual_location: time_h=$(top.time_h) " *
        "element=$(top.element_index) collocation=$(top.collocation_index) " *
        "state=$(top.state_name) residual=$(top.residual) abs=$(top.abs_residual)",
    )
end
