using CSV
using DataFrames
using FermentationDFBA

include(joinpath(@__DIR__, "solver_backend_helpers.jl"))
include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _dynamic_export_env_nonnegative_float(name::AbstractString, default::Real)
    key = String(name)
    raw = haskey(ENV, key) ? strip(ENV[key]) : string(Float64(default))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $key must parse as Float64, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $key must be finite and nonnegative, got: $value")
    return value
end

function _dynamic_export_env_optional_float(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw = strip(ENV[key])
    isempty(raw) && return nothing
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $key must parse as Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $key must be finite and positive, got: $value")
    return value
end

function _dynamic_export_env_optional_int(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw = strip(ENV[key])
    isempty(raw) && return nothing
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $key must parse as Int, got: $raw")
    value > 0 || error("Environment variable $key must be positive, got: $value")
    return value
end

function _write_dynamic_labeled_summary!(
    summary_path::AbstractString,
    solver_label::AbstractString,
    algorithm_label::AbstractString,
)
    summary_table = DataFrame(CSV.File(summary_path))
    summary_table[!, "solver_label"] = fill(String(solver_label), nrow(summary_table))
    summary_table[!, "algorithm_label"] = fill(String(algorithm_label), nrow(summary_table))
    CSV.write(summary_path, summary_table)
    return summary_path
end

function _write_dynamic_control_schedule_artifacts(
    schedule::DynamicControlSchedule,
    output_dir::AbstractString,
    horizon_h::Real,
    sample_dt_h::Real,
    overwrite::Bool,
)
    control_dir = joinpath(String(output_dir), "dynamic_control")
    mkpath(control_dir)
    samples = sample_dynamic_control_schedule(
        schedule;
        start_h = 0.0,
        stop_h = Float64(horizon_h),
        dt_h = Float64(sample_dt_h),
    )
    schedule_path = joinpath(control_dir, "dynamic_control_schedule.csv")
    summary_path = joinpath(control_dir, "dynamic_control_summary.csv")
    if !overwrite
        existing_targets = [path for path in (schedule_path, summary_path) if isfile(path)]
        isempty(existing_targets) || error(
            "Dynamic control export target file(s) already exist and overwrite=false: " *
            join(sort(existing_targets), ", "),
        )
    end
    CSV.write(schedule_path, DataFrame(samples))
    CSV.write(
        summary_path,
        DataFrame(
            key = [
                "horizon_h",
                "sample_dt_h",
                "temperature_transition_count",
                "fda_event_count",
                "organic_event_count",
                "fda_total_product_g_L",
                "organic_total_product_g_L",
                "dynamic_control_penalty",
            ],
            value = [
                Float64(horizon_h),
                Float64(sample_dt_h),
                length(schedule.temperature_transition_times_h),
                length(schedule.fda_events),
                length(schedule.organic_events),
                sum((event.total_product_g_L for event in schedule.fda_events); init = 0.0),
                sum((event.total_product_g_L for event in schedule.organic_events); init = 0.0),
                dynamic_control_penalty(schedule),
            ],
        ),
    )
    return Dict("dynamic_control_schedule" => schedule_path, "dynamic_control_summary" => summary_path)
end

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

dynamic_control_config = _script_dynamic_control_schedule_config()
schedule = dynamic_control_config.schedule
tfinal = _script_env_float("DFBA_DYNAMIC_TFINAL_HOURS", 24.0)
saveat = _script_env_float("DFBA_DYNAMIC_SAVEAT_HOURS", 1.0)
reconstruct_fluxes = _script_env_bool("DFBA_DYNAMIC_RECONSTRUCT_FLUXES", false)
write_plots = _script_env_bool("DFBA_DYNAMIC_WRITE_PLOTS", true)
lp_reuse = _script_env_bool("DFBA_DYNAMIC_LP_REUSE", false)
lp_primal_start = _script_env_bool("DFBA_DYNAMIC_LP_PRIMAL_START", false)
lp_basis_warm_start = _script_env_bool("DFBA_DYNAMIC_LP_BASIS_WARM_START", false)
allow_experimental_lp_reuse = _script_env_bool("DFBA_DYNAMIC_ALLOW_EXPERIMENTAL_LP_REUSE", false)
lp_reuse_highs_solver = strip(get(ENV, "DFBA_DYNAMIC_LP_REUSE_HIGHS_SOLVER", "simplex"))
lp_simplex_strategy =
    strip(get(ENV, "DFBA_DYNAMIC_LP_SIMPLEX_STRATEGY", lp_basis_warm_start ? "primal" : "default"))
overwrite = _script_env_bool("DFBA_DYNAMIC_EXPORT_OVERWRITE", true)
output_dir = _script_output_dir(
    project_root,
    "DFBA_DYNAMIC_OUTPUT_DIR",
    joinpath("results", "reduced_dfba_dynamic_controls_latest"),
)
phase_proxy_mode = strip(get(ENV, "DFBA_DYNAMIC_PHASE_PROXY_MODE", "total_molecular_weight"))
turnover_threshold = _script_env_float("DFBA_DYNAMIC_TURNOVER_THRESHOLD", 0.001)
algorithm_config = _script_ode_algorithm_config("DFBA_DYNAMIC_ALGORITHM")
tolerance_config = (
    ode_abstol = _script_env_float("DFBA_DYNAMIC_ODE_ABSTOL", DEFAULT_SCRIPT_ODE_ABSTOL),
    ode_reltol = _script_env_float("DFBA_DYNAMIC_ODE_RELTOL", DEFAULT_SCRIPT_ODE_RELTOL),
    lp_atol = _script_env_float("DFBA_DYNAMIC_LP_ATOL", DEFAULT_SCRIPT_LP_ATOL),
)
progress_interval_seconds =
    _dynamic_export_env_nonnegative_float("DFBA_DYNAMIC_PROGRESS_INTERVAL_SECONDS", 0.0)
max_rhs_calls = _dynamic_export_env_optional_int("DFBA_DYNAMIC_MAX_RHS_CALLS")
max_walltime_seconds = _dynamic_export_env_optional_float("DFBA_DYNAMIC_MAX_WALLTIME_SECONDS")
optimizer_backend, solver_label = _resolve_solver_backend(get(ENV, "DFBA_DYNAMIC_SOLVER_BACKEND", "HiGHS"))
if lp_reuse && solver_label != "HiGHS"
    error("DFBA_DYNAMIC_LP_REUSE currently supports HiGHS only; use DFBA_DYNAMIC_SOLVER_BACKEND=HiGHS.")
end

params = default_zenteno_parameters(
    phase_proxy_mode = phase_proxy_mode,
    TURNOVER_THRESHOLD = turnover_threshold,
)
initial_state_config = _script_initial_state_config(params)
start_time = time()
simulation_kwargs = (
    y0 = initial_state_config.y0,
    tspan = (0.0, tfinal),
    params = params,
    dynamic_control_schedule = schedule,
    saveat = saveat,
    reconstruct_fluxes = reconstruct_fluxes,
    lp_reuse = lp_reuse,
    lp_primal_start = lp_primal_start,
    lp_reuse_highs_solver = lp_reuse_highs_solver,
    lp_basis_warm_start = lp_basis_warm_start,
    lp_simplex_strategy = lp_simplex_strategy,
    allow_experimental_lp_reuse = allow_experimental_lp_reuse,
    algorithm = algorithm_config.algorithm,
    ode_abstol = tolerance_config.ode_abstol,
    ode_reltol = tolerance_config.ode_reltol,
    lp_atol = tolerance_config.lp_atol,
    progress_interval_seconds = progress_interval_seconds,
    max_rhs_calls = max_rhs_calls,
    max_walltime_seconds = max_walltime_seconds,
)
result = optimizer_backend === nothing ?
    simulate_reduced_dfba(model, reaction_map; simulation_kwargs...) :
    simulate_reduced_dfba(model, reaction_map; optimizer = optimizer_backend, simulation_kwargs...)
elapsed_seconds = time() - start_time

result.metadata["solver_label"] = solver_label
result.metadata["script_algorithm_label"] = algorithm_config.algorithm_label
result.metadata["phase_proxy_mode"] = String(params.phase_proxy_mode)
result.metadata["turnover_threshold"] = params.TURNOVER_THRESHOLD
result.metadata["dynamic_control_script"] = "main_export_reduced_dfba_dynamic_controls.jl"
merge!(result.metadata, initial_state_config.metadata)
merge!(result.metadata, dynamic_control_config.metadata)

paths = export_simulation_result(
    result,
    output_dir;
    model_id = model.model_id,
    elapsed_seconds = elapsed_seconds,
    overwrite = overwrite,
)
_write_dynamic_labeled_summary!(paths["summary"], solver_label, algorithm_config.algorithm_label)
control_paths = _write_dynamic_control_schedule_artifacts(
    schedule,
    output_dir,
    dynamic_control_config.horizon_h,
    dynamic_control_config.sample_dt_h,
    overwrite,
)
merge!(paths, control_paths)
if write_plots
    plot_paths = write_default_trajectory_plots(
        result,
        joinpath(output_dir, "plots");
        overwrite = overwrite,
    )
    merge!(paths, Dict("plot_$key" => path for (key, path) in plot_paths))
end

summary = summarize_simulation(result)
println("Sequential reduced DFBA dynamic-control export report")
println("output_dir: $output_dir")
println("solver_label: $solver_label")
println("algorithm_label: $(algorithm_config.algorithm_label)")
println("phase_proxy_mode: $(params.phase_proxy_mode)")
println("turnover_threshold: $(params.TURNOVER_THRESHOLD)")
println("dynamic_control_schedule_enabled: $(summary["dynamic_control_schedule_enabled"])")
println("dynamic_control_policy: $(summary["dynamic_control_policy"])")
println("dynamic_control_fda_total_product_g_L: $(summary["dynamic_control_fda_total_product_g_L"])")
println("dynamic_control_organic_total_product_g_L: $(summary["dynamic_control_organic_total_product_g_L"])")
println("dynamic_control_penalty: $(summary["dynamic_control_penalty"])")
println("dynamic_control_horizon_h: $(dynamic_control_config.horizon_h)")
println("dynamic_control_interval_h: $(dynamic_control_config.control_interval_h)")
println("dynamic_control_sample_dt_h: $(dynamic_control_config.sample_dt_h)")
println("initial_condition_policy: $(result.metadata["initial_condition_policy"])")
println("initial_sugar_policy: $(result.metadata["initial_sugar_policy"])")
println("initial_glucose_g_L: $(result.metadata["initial_glucose_g_L"])")
println("initial_fructose_g_L: $(result.metadata["initial_fructose_g_L"])")
println("initial_total_sugar_g_L: $(result.metadata["initial_total_sugar_g_L"])")
println("initial_yan_policy: $(result.metadata["initial_yan_policy"])")
println("initial_yan_target_mgN_L: $(result.metadata["initial_yan_target_mgN_L"])")
println("initial_free_nitrogen_gN_L: $(result.metadata["initial_free_nitrogen_gN_L"])")
println("initial_total_yan_equivalent_mgN_L: $(result.metadata["initial_total_yan_equivalent_mgN_L"])")
println("ode_abstol: $(tolerance_config.ode_abstol)")
println("ode_reltol: $(tolerance_config.ode_reltol)")
println("lp_atol: $(tolerance_config.lp_atol)")
println("progress_interval_seconds: $progress_interval_seconds")
println("max_rhs_calls: $(max_rhs_calls === nothing ? "missing" : string(max_rhs_calls))")
println("max_walltime_seconds: $(max_walltime_seconds === nothing ? "missing" : string(max_walltime_seconds))")
println("tspan: 0.0 to $tfinal h")
println("saveat: $saveat h")
println("reconstruct_fluxes: $(summary["reconstruct_fluxes"])")
println("write_plots: $write_plots")
println("overwrite: $overwrite")
println("elapsed_seconds: $elapsed_seconds")
println("saved_time_points: $(summary["n_saved_points"])")
println("retcode: $(summary["retcode"])")
println("termination_reason: $(summary["termination_reason"])")
println("final_time: $(summary["final_time"])")
println("final_biomass: $(summary["final_biomass"])")
println("final_total_sugar: $(summary["final_total_sugar"])")
println("sugar_consumed: $(summary["sugar_consumed"])")
println("final_ethanol: $(summary["final_ethanol"])")
println("ethanol_produced: $(summary["ethanol_produced"])")
println("time_to_sugar_depletion: $(summary["time_to_sugar_depletion"])")
println("mode_counts: $(summary["mode_counts"])")
println("max_mass_balance_residual: $(summary["max_mass_balance_residual"])")
println("max_lower_bound_violation: $(summary["max_lower_bound_violation"])")
println("max_upper_bound_violation: $(summary["max_upper_bound_violation"])")
println("min_state_value: $(summary["min_state_value"])")
println("has_negative_saved_states: $(summary["has_negative_saved_states"])")
println("rhs_call_count: $(summary["rhs_call_count"])")
println("rhs_lp_solve_count: $(summary["rhs_lp_solve_count"])")
println("flux_reconstruction_solve_count: $(summary["flux_reconstruction_solve_count"])")
println("total_lp_solve_count: $(summary["total_lp_solve_count"])")
println("written_files:")
for key in sort(collect(keys(paths)))
    println("  $key = $(paths[key])")
end
