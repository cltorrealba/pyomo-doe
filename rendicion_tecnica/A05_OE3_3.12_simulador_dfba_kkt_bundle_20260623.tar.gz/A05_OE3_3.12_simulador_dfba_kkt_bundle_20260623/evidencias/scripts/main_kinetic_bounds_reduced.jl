using FermentationDFBA

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

state = default_zenteno_initial_state()
params = default_zenteno_parameters()
bounds = zenteno_dynamic_bounds(model, reaction_map, state, params)
updated_model = apply_dynamic_bounds(model, bounds)
dimension_report = validate_reduced_model_dimensions(updated_model)

amino_acid_ids = [
    reaction_map.amino_acids["phenylalanine"],
    reaction_map.amino_acids["leucine"],
    reaction_map.amino_acids["valine"],
    reaction_map.amino_acids["methionine"],
    reaction_map.amino_acids["tyrosine"],
]
aroma_ids = [
    reaction_map.aromas["phenylethanol"],
    reaction_map.aromas["isoamyl_alcohol"],
    reaction_map.aromas["isobutanol"],
    reaction_map.aromas["methionol"],
    reaction_map.aromas["tyrosol"],
    reaction_map.aromas["ethyl_acetate"],
]

nitrogen_update_count = count(rxn_id -> haskey(bounds.lb_updates, rxn_id), params.nitrogen_source_ids)
amino_acid_update_count = count(rxn_id -> haskey(bounds.lb_updates, rxn_id), amino_acid_ids)
aroma_update_count = count(rxn_id -> haskey(bounds.lb_updates, rxn_id), aroma_ids)
oxygen_update_absent =
    !haskey(bounds.lb_updates, "r_1992") &&
    !haskey(bounds.ub_updates, "r_1992") &&
    !haskey(bounds.lb_updates, "r_0001") &&
    !haskey(bounds.ub_updates, "r_0001")
carbohydrate_update_absent =
    !haskey(bounds.lb_updates, "r_4048") && !haskey(bounds.ub_updates, "r_4048")
updated_bounds_ok = dimension_report.ok && all(updated_model.lb .<= updated_model.ub)

println("Reduced Zenteno kinetic bound report")
println("model_id: $(model.model_id)")
println("mode: $(bounds.mode)")
println("mu: $(bounds.rates.mu)")
println("betaG: $(bounds.rates.betaG)")
println("betaF: $(bounds.rates.betaF)")
println("vg: $(bounds.rates.vg)")
println("vf: $(bounds.rates.vf)")
println("vn: $(bounds.rates.vn)")
println("ve: $(bounds.rates.ve)")
println("glucose_lb_update: $(bounds.lb_updates[reaction_map.core["glucose_exchange"]])")
println("fructose_lb_update: $(bounds.lb_updates[reaction_map.core["fructose_exchange"]])")
println("ethanol_ub_update: $(bounds.ub_updates[reaction_map.core["ethanol_exchange"]])")
println("nitrogen_lb_update_count: $nitrogen_update_count")
println("amino_acid_lb_update_count: $amino_acid_update_count")
println("aroma_lb_update_count: $aroma_update_count")
println("oxygen_update_absent: $oxygen_update_absent")
println("carbohydrate_update_absent: $carbohydrate_update_absent")
println("updated_model_bounds_ok: $updated_bounds_ok")
println("indices_reacciones_used: $(bounds.metadata["indices_reacciones_used"])")
