using CSV
using DataFrames
using FermentationDFBA
using TOML

include(joinpath(@__DIR__, "solver_backend_helpers.jl"))
include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _dynamic_opt_env_nonnegative_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _dynamic_opt_env_optional_int(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _dynamic_opt_env_optional_positive_float(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _dynamic_opt_candidate_profiles(n_values::Integer)::Vector{Pair{String, Vector{Float64}}}
    profile_spec = strip(get(ENV, "DFBA_DYNAMIC_OPT_TEMPERATURE_PROFILES_C", ""))
    if !isempty(profile_spec)
        raw_profiles = split(profile_spec, '|')
        profiles = Pair{String, Vector{Float64}}[]
        raw_labels = split(strip(get(ENV, "DFBA_DYNAMIC_OPT_TEMPERATURE_PROFILE_LABELS", "")), ',')
        labels = isempty(strip(get(ENV, "DFBA_DYNAMIC_OPT_TEMPERATURE_PROFILE_LABELS", ""))) ?
            ["candidate_$index" for index in eachindex(raw_profiles)] :
            [strip(label) for label in raw_labels]
        length(labels) == length(raw_profiles) || error(
            "DFBA_DYNAMIC_OPT_TEMPERATURE_PROFILE_LABELS length must match " *
            "DFBA_DYNAMIC_OPT_TEMPERATURE_PROFILES_C profile count.",
        )
        for (label, raw_profile) in zip(labels, raw_profiles)
            values = _dynamic_opt_parse_float_vector(raw_profile)
            length(values) == n_values || error(
                "Temperature profile $label must contain $n_values values; got $(length(values)).",
            )
            push!(profiles, strip(label) => values)
        end
        return profiles
    end

    count = Int(n_values)
    count > 0 || error("Temperature profile value count must be positive.")
    return Pair{String, Vector{Float64}}[
        "flat20" => fill(20.0, count),
        "warm22_after_first_interval" => vcat([20.0], fill(22.0, count - 1)),
        "warm24_after_first_interval" => vcat([20.0], fill(24.0, count - 1)),
        "cool18_after_first_interval" => vcat([20.0], fill(18.0, count - 1)),
    ]
end

function _dynamic_opt_parse_float_vector(raw::AbstractString)::Vector{Float64}
    values = Float64[]
    for token in split(replace(String(raw), ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Could not parse Float64 token in temperature profile: $cleaned")
        isfinite(value) || error("Temperature profile value must be finite, got: $cleaned")
        push!(values, value)
    end
    isempty(values) && error("Temperature profile must contain at least one value.")
    return values
end

function _dynamic_opt_row(candidate_id::AbstractString, evaluation::DynamicTemperatureObjectiveResult)
    summary = evaluation.summary
    terms = evaluation.terms
    return (
        candidate_id = String(candidate_id),
        objective_value = evaluation.objective_value,
        feasible = evaluation.feasible,
        status = evaluation.status,
        retcode = string(get(summary, "retcode", missing)),
        termination_reason = string(get(summary, "termination_reason", missing)),
        final_time = Float64(get(summary, "final_time", NaN)),
        final_total_sugar = Float64(get(summary, "final_total_sugar", NaN)),
        sugar_consumed = Float64(get(summary, "sugar_consumed", NaN)),
        final_ethanol = Float64(get(summary, "final_ethanol", NaN)),
        ethanol_produced = Float64(get(summary, "ethanol_produced", NaN)),
        min_state_value = Float64(get(summary, "min_state_value", NaN)),
        has_negative_saved_states = Bool(get(summary, "has_negative_saved_states", false)),
        rhs_call_count = Int(get(summary, "rhs_call_count", 0)),
        total_lp_solve_count = Int(get(summary, "total_lp_solve_count", 0)),
        terminal_sugar_term = terms["terminal_sugar"],
        ethanol_reward_term = terms["ethanol_reward"],
        temperature_smoothness_term = terms["temperature_smoothness"],
        temperature_move_term = terms["temperature_move"],
        negative_state_penalty = terms["negative_state_penalty"],
        incomplete_horizon_penalty = terms["incomplete_horizon_penalty"],
        failure_penalty = terms["failure_penalty"],
        temperature_values_C = join(string.(evaluation.schedule.temperature_values_C), ","),
    )
end

function _dynamic_opt_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _dynamic_opt_toml_normalize_real(value)
    elseif value isa Tuple
        return _dynamic_opt_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _dynamic_opt_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _dynamic_opt_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _dynamic_opt_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _dynamic_opt_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _dynamic_opt_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

horizon_h = _script_env_float("DFBA_DYNAMIC_OPT_HORIZON_HOURS", 24.0)
control_interval_h = _script_env_float("DFBA_DYNAMIC_OPT_CONTROL_INTERVAL_HOURS", 12.0)
temperature_transition_width_h = _script_env_float("DFBA_DYNAMIC_OPT_TEMPERATURE_WIDTH_HOURS", 1.0)
temperature_min_C = _script_env_float("DFBA_DYNAMIC_OPT_T_MIN_C", 15.0)
temperature_max_C = _script_env_float("DFBA_DYNAMIC_OPT_T_MAX_C", 25.0)
saveat = _script_env_float("DFBA_DYNAMIC_OPT_SAVEAT_HOURS", 1.0)
reconstruct_fluxes = _script_env_bool("DFBA_DYNAMIC_OPT_RECONSTRUCT_FLUXES", false)
overwrite = _script_env_bool("DFBA_DYNAMIC_OPT_EXPORT_OVERWRITE", true)
stop_on_sugar_depletion = _script_env_bool("DFBA_DYNAMIC_OPT_STOP_ON_SUGAR_DEPLETION", true)
sugar_depletion_tol = _dynamic_opt_env_nonnegative_float(
    "DFBA_DYNAMIC_OPT_SUGAR_DEPLETION_TOL",
    1.0e-6,
)
phase_proxy_mode = strip(get(ENV, "DFBA_DYNAMIC_OPT_PHASE_PROXY_MODE", "total_molecular_weight"))
turnover_threshold = _script_env_float("DFBA_DYNAMIC_OPT_TURNOVER_THRESHOLD", 0.001)
progress_interval_seconds = _dynamic_opt_env_nonnegative_float(
    "DFBA_DYNAMIC_OPT_PROGRESS_INTERVAL_SECONDS",
    0.0,
)
max_rhs_calls = _dynamic_opt_env_optional_int("DFBA_DYNAMIC_OPT_MAX_RHS_CALLS")
max_walltime_seconds =
    _dynamic_opt_env_optional_positive_float("DFBA_DYNAMIC_OPT_MAX_WALLTIME_SECONDS")
algorithm_config = _script_ode_algorithm_config("DFBA_DYNAMIC_OPT_ALGORITHM")
optimizer_backend, solver_label =
    _resolve_solver_backend(get(ENV, "DFBA_DYNAMIC_OPT_SOLVER_BACKEND", "HiGHS"))
tolerance_config = (
    ode_abstol = _script_env_float("DFBA_DYNAMIC_OPT_ODE_ABSTOL", DEFAULT_SCRIPT_ODE_ABSTOL),
    ode_reltol = _script_env_float("DFBA_DYNAMIC_OPT_ODE_RELTOL", DEFAULT_SCRIPT_ODE_RELTOL),
    lp_atol = _script_env_float("DFBA_DYNAMIC_OPT_LP_ATOL", DEFAULT_SCRIPT_LP_ATOL),
)
weights = DynamicTemperatureObjectiveWeights(
    final_total_sugar_weight = _dynamic_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_OPT_FINAL_SUGAR_WEIGHT",
        1.0,
    ),
    ethanol_reward_weight = _dynamic_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_OPT_ETHANOL_REWARD_WEIGHT",
        0.0,
    ),
    temperature_smoothness_weight = _dynamic_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_OPT_TEMPERATURE_SMOOTHNESS_WEIGHT",
        0.0,
    ),
    temperature_move_weight = _dynamic_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_OPT_TEMPERATURE_MOVE_WEIGHT",
        0.0,
    ),
    reference_temperature_C = _script_env_float("DFBA_DYNAMIC_OPT_REFERENCE_TEMPERATURE_C", 20.0),
    negative_state_tolerance = _dynamic_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_OPT_NEGATIVE_STATE_TOL",
        1.0e-9,
    ),
    negative_state_penalty_weight = _dynamic_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_OPT_NEGATIVE_STATE_PENALTY_WEIGHT",
        1.0e8,
    ),
    incomplete_horizon_penalty_weight = _dynamic_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_OPT_INCOMPLETE_HORIZON_PENALTY_WEIGHT",
        1.0e6,
    ),
    failure_penalty = _dynamic_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_OPT_FAILURE_PENALTY",
        1.0e9,
    ),
)

params = default_zenteno_parameters(
    phase_proxy_mode = phase_proxy_mode,
    TURNOVER_THRESHOLD = turnover_threshold,
)
initial_state_config = _script_initial_state_config(params)
temperature_value_count = dynamic_temperature_control_value_count(
    horizon_h = horizon_h,
    control_interval_h = control_interval_h,
)
profiles = _dynamic_opt_candidate_profiles(temperature_value_count)
output_dir = _script_output_dir(
    project_root,
    "DFBA_DYNAMIC_OPT_OUTPUT_DIR",
    joinpath("results", "dynamic_temperature_objective_smoke_latest"),
)
mkpath(output_dir)
candidate_path = joinpath(output_dir, "dynamic_temperature_objective_candidates.csv")
metadata_path = joinpath(output_dir, "dynamic_temperature_objective_metadata.toml")
if !overwrite
    existing_targets = [path for path in (candidate_path, metadata_path) if isfile(path)]
    isempty(existing_targets) || error(
        "Dynamic temperature objective target file(s) already exist and overwrite=false: " *
        join(sort(existing_targets), ", "),
    )
end

rows = NamedTuple[]
evaluations = DynamicTemperatureObjectiveResult[]
start_time = time()
for (candidate_id, temperature_values_C) in profiles
    common_kwargs = (
        weights = weights,
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        y0 = initial_state_config.y0,
        params = params,
        lp_atol = tolerance_config.lp_atol,
        ode_abstol = tolerance_config.ode_abstol,
        ode_reltol = tolerance_config.ode_reltol,
        saveat = saveat,
        algorithm = algorithm_config.algorithm,
        reconstruct_fluxes = reconstruct_fluxes,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
    )
    evaluation = optimizer_backend === nothing ?
        evaluate_dynamic_temperature_objective(
            model,
            reaction_map,
            temperature_values_C;
            common_kwargs...,
        ) :
        evaluate_dynamic_temperature_objective(
            model,
            reaction_map,
            temperature_values_C;
            optimizer = optimizer_backend,
            common_kwargs...,
        )
    push!(evaluations, evaluation)
    push!(rows, _dynamic_opt_row(candidate_id, evaluation))
end
elapsed_seconds = time() - start_time

candidate_table = DataFrame(rows)
sort!(candidate_table, [:feasible, :objective_value], rev = [true, false])
CSV.write(candidate_path, candidate_table)

best_row = nrow(candidate_table) > 0 ? candidate_table[1, :] : nothing
metadata = Dict{String, Any}(
    "script" => "main_dynamic_temperature_objective_smoke.jl",
    "objective_type" => "dynamic_temperature_sequential_objective",
    "solver_label" => solver_label,
    "algorithm_label" => algorithm_config.algorithm_label,
    "horizon_h" => horizon_h,
    "control_interval_h" => control_interval_h,
    "temperature_value_count" => temperature_value_count,
    "temperature_transition_width_h" => temperature_transition_width_h,
    "temperature_min_C" => temperature_min_C,
    "temperature_max_C" => temperature_max_C,
    "candidate_count" => length(profiles),
    "candidate_ids" => [first(profile) for profile in profiles],
    "output_dir" => output_dir,
    "candidate_table" => candidate_path,
    "elapsed_seconds" => elapsed_seconds,
    "saveat" => saveat,
    "reconstruct_fluxes" => reconstruct_fluxes,
    "stop_on_sugar_depletion" => stop_on_sugar_depletion,
    "sugar_depletion_tol" => sugar_depletion_tol,
    "phase_proxy_mode" => phase_proxy_mode,
    "turnover_threshold" => turnover_threshold,
    "ode_abstol" => tolerance_config.ode_abstol,
    "ode_reltol" => tolerance_config.ode_reltol,
    "lp_atol" => tolerance_config.lp_atol,
    "progress_interval_seconds" => progress_interval_seconds,
    "max_rhs_calls" => max_rhs_calls,
    "max_walltime_seconds" => max_walltime_seconds,
    "weights" => Dict{String, Any}(
        "final_total_sugar_weight" => weights.final_total_sugar_weight,
        "ethanol_reward_weight" => weights.ethanol_reward_weight,
        "temperature_smoothness_weight" => weights.temperature_smoothness_weight,
        "temperature_move_weight" => weights.temperature_move_weight,
        "reference_temperature_C" => weights.reference_temperature_C,
        "negative_state_tolerance" => weights.negative_state_tolerance,
        "negative_state_penalty_weight" => weights.negative_state_penalty_weight,
        "incomplete_horizon_penalty_weight" => weights.incomplete_horizon_penalty_weight,
        "failure_penalty" => weights.failure_penalty,
    ),
    "initial_conditions" => initial_state_config.metadata,
)
if best_row !== nothing
    metadata["best_candidate_id"] = best_row.candidate_id
    metadata["best_objective_value"] = best_row.objective_value
    metadata["best_feasible"] = best_row.feasible
    metadata["best_temperature_values_C"] = best_row.temperature_values_C
end
open(metadata_path, "w") do io
    TOML.print(io, _dynamic_opt_toml_normalize(metadata))
end

println("Dynamic temperature objective smoke")
println("output_dir: $output_dir")
println("candidate_csv: $candidate_path")
println("metadata_toml: $metadata_path")
println("solver_label: $solver_label")
println("algorithm_label: $(algorithm_config.algorithm_label)")
println("horizon_h: $horizon_h")
println("control_interval_h: $control_interval_h")
println("candidate_count: $(length(profiles))")
println("elapsed_seconds: $elapsed_seconds")
if best_row !== nothing
    println("best_candidate_id: $(best_row.candidate_id)")
    println("best_objective_value: $(best_row.objective_value)")
    println("best_feasible: $(best_row.feasible)")
    println("best_final_total_sugar: $(best_row.final_total_sugar)")
    println("best_sugar_consumed: $(best_row.sugar_consumed)")
    println("best_final_ethanol: $(best_row.final_ethanol)")
    println("best_temperature_values_C: $(best_row.temperature_values_C)")
end
