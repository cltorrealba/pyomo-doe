using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_FRONTIER_PROFILE = "smoke"
const DEFAULT_MPCC_FRONTIER_IPOPT_MAX_ITER = 100

function _mpcc_frontier_profile()
    raw = strip(get(ENV, "MPCC_FRONTIER_PROFILE", DEFAULT_MPCC_FRONTIER_PROFILE))
    normalized = lowercase(raw)
    normalized in ("smoke", "focused", "custom") ||
        error("Environment variable MPCC_FRONTIER_PROFILE must be one of: smoke, focused, custom. Got: $raw")
    return normalized
end

function _mpcc_frontier_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (horizons = "0.5", max_cases = 1)
    elseif profile == "focused"
        return (horizons = "0.5,0.75,1.0", max_cases = 3)
    else
        return (horizons = "0.5", max_cases = 1)
    end
end

function _mpcc_frontier_env_float_list(name::AbstractString, default_value::AbstractString)::Vector{Float64}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && error("Environment variable $name contains a non-Float64 value: $stripped")
        isfinite(value) && value > 0.0 ||
            error("Environment variable $name values must be finite and positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    issorted(values) || error("Environment variable $name values must be sorted ascending.")
    return values
end

function _mpcc_frontier_env_optional_int_list(name::AbstractString)::Union{Nothing, Vector{Int}}
    raw = strip(get(ENV, String(name), ""))
    isempty(raw) && return nothing
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Int, stripped)
        value === nothing && error("Environment variable $name contains a non-Int value: $stripped")
        value > 0 || error("Environment variable $name values must be positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value when set.")
    return values
end

function _mpcc_frontier_env_positive_float(name::AbstractString, default_value::Real)::Float64
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_frontier_env_positive_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_frontier_script_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_frontier_validate_case_count!(
    horizons::Vector{Float64},
    max_cases::Int,
    allow_large_frontier::Bool,
)
    n_cases = length(horizons)
    if n_cases > max_cases && !allow_large_frontier
        error(
            "Requested MPCC viability frontier has $n_cases cases, above " *
            "MPCC_FRONTIER_MAX_CASES=$max_cases. Set MPCC_FRONTIER_ALLOW_LARGE=1 " *
            "only for deliberate longer local diagnostics.",
        )
    end
    return nothing
end

profile = _mpcc_frontier_profile()
defaults = _mpcc_frontier_profile_defaults(profile)
horizons = _mpcc_frontier_env_float_list("MPCC_FRONTIER_HORIZONS_HOURS", defaults.horizons)
boundary_dt = _mpcc_frontier_env_positive_float("MPCC_FRONTIER_BOUNDARY_DT_HOURS", 0.25)
nfe_values = _mpcc_frontier_env_optional_int_list("MPCC_FRONTIER_NFE_VALUES")
max_cases = _mpcc_frontier_env_positive_int("MPCC_FRONTIER_MAX_CASES", defaults.max_cases)
allow_large_frontier = _script_env_bool("MPCC_FRONTIER_ALLOW_LARGE", false)
stop_after_first_non_green = _script_env_bool("MPCC_FRONTIER_STOP_AFTER_FIRST_NON_GREEN", false)
continue_on_error = _script_env_bool("MPCC_FRONTIER_CONTINUE_ON_ERROR", true)
require_pre_solve_ready = _script_env_bool("MPCC_FRONTIER_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_FRONTIER_SILENT", true)
ipopt_max_iter =
    _mpcc_frontier_env_positive_int("MPCC_FRONTIER_IPOPT_MAX_ITER", DEFAULT_MPCC_FRONTIER_IPOPT_MAX_ITER)

_mpcc_frontier_validate_case_count!(horizons, max_cases, allow_large_frontier)

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

frontier = sweep_reduced_dcdfba_mpcc_simulation_viability_frontier(
    model,
    reaction_map;
    horizons = horizons,
    boundary_dt = boundary_dt,
    nfe_values = nfe_values,
    degree = 3,
    ipopt_max_iter = ipopt_max_iter,
    require_pre_solve_ready = require_pre_solve_ready,
    silent = silent,
    continue_on_error = continue_on_error,
    stop_after_first_non_green = stop_after_first_non_green,
)
nfe_values_label = nfe_values === nothing ? missing : join(nfe_values, ",")

println("Reduced MPCC simulation viability frontier")
println("profile: $profile")
println("horizons_hours: $(join(horizons, ","))")
println("boundary_dt_hours: $boundary_dt")
println("nfe_values: $(_mpcc_frontier_script_value(nfe_values_label))")
println("ipopt_max_iter: $ipopt_max_iter")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("stop_after_first_non_green: $stop_after_first_non_green")
println("outputs_written: $(frontier.metadata["outputs_written"])")
println("frontier_is_scientific_simulation: $(frontier.metadata["frontier_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(frontier.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(frontier.metadata["scientific_baseline"])")
println("first_mpcc_target: $(frontier.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(frontier.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(frontier.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(frontier.metadata["hsl_required"])")
println("ma57_required: $(frontier.metadata["ma57_required"])")
println("indices_reacciones_used: $(frontier.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(frontier.metadata["r0001_used_as_oxygen"])")
println("n_requested_cases: $(frontier.metadata["n_requested_cases"])")
println("n_cases: $(frontier.metadata["n_cases"])")
println("n_completed_cases: $(frontier.metadata["n_completed_cases"])")
println("n_failed_cases: $(frontier.metadata["n_failed_cases"])")
println("green_count: $(frontier.metadata["green_count"])")
println("yellow_count: $(frontier.metadata["yellow_count"])")
println("red_count: $(frontier.metadata["red_count"])")
println("simulation_viable_case_count: $(frontier.metadata["simulation_viable_case_count"])")
println("frontier_reached_green: $(frontier.metadata["frontier_reached_green"])")
println("frontier_blocked: $(frontier.metadata["frontier_blocked"])")
println("all_requested_cases_green: $(frontier.metadata["all_requested_cases_green"])")
println("last_green_case_id: $(_mpcc_frontier_script_value(frontier.metadata["last_green_case_id"]))")
println("last_green_horizon: $(_mpcc_frontier_script_value(frontier.metadata["last_green_horizon"]))")
println("last_green_nfe: $(_mpcc_frontier_script_value(frontier.metadata["last_green_nfe"]))")
println("last_green_max_state_relative_rmse: $(_mpcc_frontier_script_value(frontier.metadata["last_green_max_state_relative_rmse"]))")
println("first_non_green_case_id: $(_mpcc_frontier_script_value(frontier.metadata["first_non_green_case_id"]))")
println("first_non_green_horizon: $(_mpcc_frontier_script_value(frontier.metadata["first_non_green_horizon"]))")
println("first_non_green_nfe: $(_mpcc_frontier_script_value(frontier.metadata["first_non_green_nfe"]))")
println("first_non_green_traffic_light: $(_mpcc_frontier_script_value(frontier.metadata["first_non_green_traffic_light"]))")
println("first_non_green_viability_class: $(_mpcc_frontier_script_value(frontier.metadata["first_non_green_viability_class"]))")
println("first_non_green_blocking_reasons: $(_mpcc_frontier_script_value(frontier.metadata["first_non_green_blocking_reasons"]))")
println("total_solve_elapsed_seconds: $(frontier.metadata["total_solve_elapsed_seconds"])")
println("recommended_next_action: $(frontier.metadata["recommended_next_action"])")

println("frontier_table:")
for row in eachrow(frontier.frontier_table)
    println(
        "  $(row["frontier_case_id"]) | horizon=$(_mpcc_frontier_script_value(row["horizon"])) | " *
        "nfe=$(_mpcc_frontier_script_value(row["nfe"])) | light=$(_mpcc_frontier_script_value(row["traffic_light"])) | " *
        "class=$(_mpcc_frontier_script_value(row["viability_class"])) | viable=$(_mpcc_frontier_script_value(row["simulation_viable"])) | " *
        "solver=$(_mpcc_frontier_script_value(row["solver_status"])) | solve_s=$(_mpcc_frontier_script_value(row["solve_elapsed_seconds"])) | " *
        "state_rel_rmse=$(_mpcc_frontier_script_value(row["max_state_relative_rmse"])) | " *
        "last_green=$(_mpcc_frontier_script_value(row["is_last_green"])) | " *
        "first_non_green=$(_mpcc_frontier_script_value(row["is_first_non_green_after_green"])) | " *
        "blocking=$(_mpcc_frontier_script_value(row["blocking_reasons"]))",
    )
end

println("interpretation_note: $(frontier.metadata["interpretation_note"])")
