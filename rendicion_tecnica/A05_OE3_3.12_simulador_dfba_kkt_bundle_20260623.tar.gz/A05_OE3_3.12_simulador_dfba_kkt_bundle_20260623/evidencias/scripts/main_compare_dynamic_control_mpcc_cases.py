#!/usr/bin/env python3
"""Compare reduced MPCC dynamic-control pilot case diagnostics."""

from __future__ import annotations

import argparse
import ast
import csv
import math
import re
from pathlib import Path


SUMMARY_KEYS = [
    "case_id",
    "solver_status",
    "primal_status",
    "selected_candidate_source",
    "selected_candidate_residual_feasible",
    "selected_candidate_trajectory_ready",
    "selected_candidate_terminal_total_sugar_g_L",
    "selected_candidate_terminal_isoamyl_alcohol_g_L",
    "post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve",
    "post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve",
    "post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_collocation_integration_residual",
    "max_continuity_residual",
    "candidate_max_rhs_residual_from_arrays",
    "candidate_max_mass_balance_residual",
    "candidate_max_lower_complementarity_residual",
    "candidate_max_upper_complementarity_residual",
    "candidate_max_collocation_integration_residual",
    "candidate_max_continuity_residual",
]

OBJECTIVE_COMPONENT_KEYS = [
    "objective_value",
    "base_objective_mode",
    "dynamic_control_objective_component_values_available",
    "dynamic_control_objective_base_value_estimate",
    "dynamic_control_objective_dynamic_value_estimate",
    "dynamic_control_objective_reconstructed_total_value_estimate",
    "dynamic_control_objective_terminal_reward_value_estimate",
    "dynamic_control_objective_terminal_sugar_value_estimate",
    "dynamic_control_objective_integrated_sugar_value_estimate",
    "dynamic_control_objective_integrated_sugar_config_policy",
    "dynamic_control_objective_integrated_sugar_max_g_L",
    "dynamic_control_objective_integrated_sugar_slack_count",
    "dynamic_control_objective_integrated_sugar_constraint_count",
    "dynamic_control_objective_integrated_sugar_max_slack_start_g_L",
    "dynamic_control_objective_aroma_deficit_weight",
    "dynamic_control_objective_aroma_deficit_target_g_L",
    "dynamic_control_objective_aroma_deficit_scale_g_L",
    "dynamic_control_objective_aroma_deficit_slack_value_g_L",
    "dynamic_control_objective_final_target_state_value_g_L",
    "dynamic_control_objective_aroma_deficit_required_g_L",
    "dynamic_control_objective_aroma_deficit_slack_minus_required_g_L",
    "dynamic_control_objective_aroma_deficit_constraint_violation_g_L",
    "dynamic_control_objective_aroma_deficit_value_estimate",
    "dynamic_control_objective_terminal_sugar_excess_weight",
    "dynamic_control_objective_terminal_sugar_max_g_L",
    "dynamic_control_objective_terminal_sugar_excess_scale_g_L",
    "dynamic_control_objective_terminal_sugar_excess_slack_value_g_L",
    "dynamic_control_objective_final_total_sugar_value_g_L",
    "dynamic_control_objective_terminal_sugar_excess_required_g_L",
    "dynamic_control_objective_terminal_sugar_excess_slack_minus_required_g_L",
    "dynamic_control_objective_terminal_sugar_excess_constraint_violation_g_L",
    "dynamic_control_objective_terminal_sugar_excess_value_estimate",
    "dynamic_control_objective_nutrient_value_estimate",
    "dynamic_control_objective_thermal_energy_value_estimate",
    "dynamic_control_objective_temperature_smoothness_value_estimate",
]

CONTROL_FAMILIES = ["temperature", "fda", "organic"]


def _literal_value(raw: str):
    text = raw.strip()
    if text.startswith('"') and text.endswith('"'):
        return text[1:-1]
    if text in {"true", "false"}:
        return text == "true"
    if text == "missing":
        return ""
    if text == "NaN":
        return math.nan
    if text in {"Inf", "+Inf"}:
        return math.inf
    if text == "-Inf":
        return -math.inf
    try:
        return ast.literal_eval(text)
    except (SyntaxError, ValueError):
        try:
            return float(text)
        except ValueError:
            return text


def _as_float(value: object, default: float = math.nan) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return default
    return parsed


def _format_value(value: object) -> str:
    if isinstance(value, float):
        if not math.isfinite(value):
            return str(value)
        return f"{value:.12g}"
    return str(value)


def read_metadata_toml(path: Path, wanted_keys: set[str]) -> dict[str, object]:
    values: dict[str, object] = {}
    current_table = ""
    assignment = re.compile(r"^([A-Za-z0-9_]+)\s*=\s*(.*)$")
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("["):
            current_table = stripped.strip("[]")
            continue
        if current_table not in {"", "candidate_metadata", "result_metadata"}:
            continue
        match = assignment.match(stripped)
        if match and match.group(1) in wanted_keys:
            values[match.group(1)] = _literal_value(match.group(2))
    return values


def read_one_row_csv(path: Path) -> dict[str, object]:
    if not path.is_file():
        return {}
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        try:
            row = next(reader)
        except StopIteration:
            return {}
    return {key: _literal_value(value) for key, value in row.items() if value != ""}


def read_rows_csv(path: Path, limit: int | None = None) -> list[dict[str, object]]:
    if not path.is_file():
        return []
    rows: list[dict[str, object]] = []
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for index, row in enumerate(reader):
            if limit is not None and index >= limit:
                break
            rows.append({key: _literal_value(value) for key, value in row.items()})
    return rows


def resolve_case_dir(path: Path) -> Path:
    if (path / "reduced_mpcc_fixed_control_policy_solve_attempt.toml").is_file():
        return path
    if (path / "case" / "reduced_mpcc_fixed_control_policy_solve_attempt.toml").is_file():
        return path / "case"
    raise FileNotFoundError(f"Cannot find MPCC case diagnostics under {path}")


def parse_case_spec(text: str) -> tuple[str, Path]:
    if "=" in text:
        label, raw_path = text.split("=", 1)
        return label.strip(), Path(raw_path.strip())
    path = Path(text)
    return path.name, path


def read_decision_spec(path: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    if not path.is_file():
        return rows
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            parsed: dict[str, object] = dict(row)
            parsed["slot_index"] = int(float(str(row["slot_index"])))
            for key in ("time_h", "start_value", "lower_bound", "upper_bound", "trust_region"):
                parsed[key] = float(str(row[key]))
            parsed["free"] = str(row.get("free", "")).lower() == "true"
            rows.append(parsed)
    return rows


def summarize_decision_spec(rows: list[dict[str, object]]) -> dict[str, object]:
    summary: dict[str, object] = {}
    for family in CONTROL_FAMILIES:
        family_rows = [row for row in rows if row.get("family") == family]
        starts = [_as_float(row.get("start_value"), 0.0) for row in family_rows]
        free_rows = [row for row in family_rows if row.get("free") is True]
        positive_rows = [row for row in family_rows if _as_float(row.get("start_value"), 0.0) > 0.0]
        summary[f"{family}_slot_count"] = len(family_rows)
        summary[f"{family}_free_count"] = len(free_rows)
        summary[f"{family}_positive_start_count"] = len(positive_rows)
        summary[f"{family}_start_sum"] = sum(starts)
        summary[f"{family}_max_start"] = max(starts) if starts else 0.0
    return summary


def _first(rows: list[dict[str, object]]) -> dict[str, object]:
    return rows[0] if rows else {}


def _metric(metadata: dict[str, object], base: str) -> object:
    return metadata.get(base, metadata.get(f"candidate_{base}", ""))


def _component_share(metadata: dict[str, object], component_key: str) -> object:
    dynamic_value = _as_float(metadata.get("dynamic_control_objective_dynamic_value_estimate"))
    component_value = _as_float(metadata.get(component_key))
    if not math.isfinite(dynamic_value) or dynamic_value == 0.0:
        return ""
    if not math.isfinite(component_value):
        return ""
    return component_value / dynamic_value


def _positive_part(value: float) -> float:
    if not math.isfinite(value):
        return math.nan
    return max(0.0, value)


def _slack_gap(slack: object, required: object) -> object:
    slack_value = _as_float(slack)
    required_value = _as_float(required)
    if not math.isfinite(slack_value) or not math.isfinite(required_value):
        return ""
    return slack_value - required_value


def _slack_violation(slack: object, required: object) -> object:
    gap = _slack_gap(slack, required)
    if gap == "":
        return ""
    return max(0.0, -float(gap))


def load_case(label: str, raw_path: Path, top_n: int) -> tuple[dict[str, object], list[dict[str, object]]]:
    case_dir = resolve_case_dir(raw_path).resolve()
    attempt_csv = read_one_row_csv(case_dir / "reduced_mpcc_fixed_control_policy_solve_attempt.csv")
    plot_summary = read_one_row_csv(case_dir / "plots" / "optimized_control_summary.csv")
    wanted_keys = set(SUMMARY_KEYS) | set(OBJECTIVE_COMPONENT_KEYS) | set(plot_summary) | set(attempt_csv)
    metadata = read_metadata_toml(
        case_dir / "reduced_mpcc_fixed_control_policy_solve_attempt.toml",
        wanted_keys,
    )
    metadata = {**attempt_csv, **plot_summary, **metadata}
    spec_summary = summarize_decision_spec(
        read_decision_spec(case_dir / "reduced_mpcc_dynamic_control_decision_spec.csv")
    )
    residual_rows = read_rows_csv(
        case_dir / "reduced_mpcc_fixed_control_policy_residual_locations.csv",
        limit=top_n,
    )
    complementarity_rows = read_rows_csv(
        case_dir / "reduced_mpcc_fixed_control_policy_complementarity_locations.csv",
        limit=top_n,
    )
    top_residual = _first(residual_rows)
    top_complementarity = _first(complementarity_rows)
    terminal_total_sugar = metadata.get("selected_candidate_terminal_total_sugar_g_L", "")
    terminal_isoamyl = metadata.get("selected_candidate_terminal_isoamyl_alcohol_g_L", "")
    terminal_sugar_max = metadata.get("dynamic_control_objective_terminal_sugar_excess_max_g_L", "")
    if terminal_sugar_max == "":
        terminal_sugar_max = metadata.get("dynamic_control_objective_terminal_sugar_max_g_L", "")
    aroma_target = metadata.get("dynamic_control_objective_aroma_deficit_target_g_L", "")
    terminal_sugar_excess_required = _positive_part(
        _as_float(terminal_total_sugar) - _as_float(terminal_sugar_max)
    )
    aroma_deficit_required = _positive_part(_as_float(aroma_target) - _as_float(terminal_isoamyl))
    sugar_excess_slack = metadata.get(
        "dynamic_control_objective_terminal_sugar_excess_slack_value_g_L", ""
    )
    aroma_deficit_slack = metadata.get(
        "dynamic_control_objective_aroma_deficit_slack_value_g_L", ""
    )

    summary = {
        "label": label,
        "case_dir": str(case_dir),
        "case_id": metadata.get("case_id", ""),
        "solver_status": metadata.get("solver_status", ""),
        "primal_status": metadata.get("primal_status", ""),
        "selected_candidate_source": metadata.get("selected_candidate_source", ""),
        "selected_candidate_residual_feasible": metadata.get(
            "selected_candidate_residual_feasible", ""
        ),
        "selected_candidate_trajectory_ready": metadata.get(
            "selected_candidate_trajectory_ready", ""
        ),
        "terminal_total_sugar_g_L": metadata.get(
            "selected_candidate_terminal_total_sugar_g_L", ""
        ),
        "terminal_isoamyl_alcohol_g_L": metadata.get(
            "selected_candidate_terminal_isoamyl_alcohol_g_L", ""
        ),
        "objective_value": metadata.get("objective_value", ""),
        "base_objective_mode": metadata.get("base_objective_mode", ""),
        "objective_base_value_estimate": metadata.get(
            "dynamic_control_objective_base_value_estimate", ""
        ),
        "objective_dynamic_value_estimate": metadata.get(
            "dynamic_control_objective_dynamic_value_estimate", ""
        ),
        "objective_reconstructed_total_value_estimate": metadata.get(
            "dynamic_control_objective_reconstructed_total_value_estimate", ""
        ),
        "objective_integrated_sugar_policy": metadata.get(
            "dynamic_control_objective_integrated_sugar_policy", ""
        ),
        "objective_integrated_sugar_config_policy": metadata.get(
            "dynamic_control_objective_integrated_sugar_config_policy", ""
        ),
        "objective_integrated_sugar_max_g_L": metadata.get(
            "dynamic_control_objective_integrated_sugar_max_g_L", ""
        ),
        "objective_integrated_sugar_slack_count": metadata.get(
            "dynamic_control_objective_integrated_sugar_slack_count", ""
        ),
        "objective_integrated_sugar_value": metadata.get(
            "dynamic_control_objective_integrated_sugar_value_estimate", ""
        ),
        "objective_integrated_sugar_share": _component_share(
            metadata, "dynamic_control_objective_integrated_sugar_value_estimate"
        ),
        "objective_terminal_sugar_excess_slack_g_L": metadata.get(
            "dynamic_control_objective_terminal_sugar_excess_slack_value_g_L", ""
        ),
        "objective_terminal_sugar_excess_required_g_L": terminal_sugar_excess_required,
        "objective_terminal_sugar_excess_slack_minus_required_g_L": _slack_gap(
            sugar_excess_slack,
            terminal_sugar_excess_required,
        ),
        "objective_terminal_sugar_excess_slack_violation_g_L": _slack_violation(
            sugar_excess_slack,
            terminal_sugar_excess_required,
        ),
        "objective_terminal_sugar_excess_value": metadata.get(
            "dynamic_control_objective_terminal_sugar_excess_value_estimate", ""
        ),
        "objective_terminal_sugar_excess_share": _component_share(
            metadata, "dynamic_control_objective_terminal_sugar_excess_value_estimate"
        ),
        "objective_aroma_deficit_slack_g_L": metadata.get(
            "dynamic_control_objective_aroma_deficit_slack_value_g_L", ""
        ),
        "objective_aroma_deficit_required_g_L": aroma_deficit_required,
        "objective_aroma_deficit_slack_minus_required_g_L": _slack_gap(
            aroma_deficit_slack,
            aroma_deficit_required,
        ),
        "objective_aroma_deficit_slack_violation_g_L": _slack_violation(
            aroma_deficit_slack,
            aroma_deficit_required,
        ),
        "objective_aroma_deficit_value": metadata.get(
            "dynamic_control_objective_aroma_deficit_value_estimate", ""
        ),
        "objective_aroma_deficit_share": _component_share(
            metadata, "dynamic_control_objective_aroma_deficit_value_estimate"
        ),
        "objective_nutrient_value": metadata.get(
            "dynamic_control_objective_nutrient_value_estimate", ""
        ),
        "objective_nutrient_share": _component_share(
            metadata, "dynamic_control_objective_nutrient_value_estimate"
        ),
        "objective_thermal_energy_value": metadata.get(
            "dynamic_control_objective_thermal_energy_value_estimate", ""
        ),
        "objective_thermal_energy_share": _component_share(
            metadata, "dynamic_control_objective_thermal_energy_value_estimate"
        ),
        "objective_temperature_smoothness_value": metadata.get(
            "dynamic_control_objective_temperature_smoothness_value_estimate", ""
        ),
        "objective_temperature_smoothness_share": _component_share(
            metadata, "dynamic_control_objective_temperature_smoothness_value_estimate"
        ),
        "max_rhs_residual": _metric(metadata, "max_rhs_residual"),
        "max_mass_balance_residual": _metric(metadata, "max_mass_balance_residual"),
        "max_lower_complementarity_residual": _metric(
            metadata, "max_lower_complementarity_residual"
        ),
        "max_upper_complementarity_residual": _metric(
            metadata, "max_upper_complementarity_residual"
        ),
        "max_collocation_integration_residual": _metric(
            metadata, "max_collocation_integration_residual"
        ),
        "max_continuity_residual": _metric(metadata, "max_continuity_residual"),
        "post_solve_temperature_C_max_abs_delta_vs_pre_solve": metadata.get(
            "post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve",
            "",
        ),
        "post_solve_fda_g_L_sum_delta_vs_pre_solve": metadata.get(
            "post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve",
            "",
        ),
        "post_solve_organic_g_L_sum_delta_vs_pre_solve": metadata.get(
            "post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve",
            "",
        ),
        "top_residual_type": top_residual.get("residual_type", ""),
        "top_residual_time_h": top_residual.get("time_h", ""),
        "top_residual_state_name": top_residual.get("state_name", ""),
        "top_residual_abs": top_residual.get("abs_residual", ""),
        "top_complementarity_type": top_complementarity.get("residual_type", ""),
        "top_complementarity_time_h": top_complementarity.get("time_h", ""),
        "top_complementarity_reaction_id": top_complementarity.get("reaction_id", ""),
        "top_complementarity_abs_product": top_complementarity.get("abs_product", ""),
        **spec_summary,
    }

    hotspots: list[dict[str, object]] = []
    for source, rows in (
        ("residual", residual_rows),
        ("complementarity", complementarity_rows),
    ):
        for rank, row in enumerate(rows, start=1):
            hotspots.append(
                {
                    "label": label,
                    "source": source,
                    "rank": rank,
                    "residual_type": row.get("residual_type", ""),
                    "time_h": row.get("time_h", ""),
                    "element_index": row.get("element_index", ""),
                    "collocation_index": row.get("collocation_index", ""),
                    "state_name": row.get("state_name", ""),
                    "reaction_id": row.get("reaction_id", ""),
                    "abs_residual": row.get("abs_residual", ""),
                    "abs_product": row.get("abs_product", ""),
                    "value": row.get("residual", row.get("product", "")),
                }
            )
    return summary, hotspots


def add_baseline_deltas(summaries: list[dict[str, object]]) -> None:
    if not summaries:
        return
    baseline = summaries[0]
    baseline_sugar = _as_float(baseline.get("terminal_total_sugar_g_L"))
    baseline_isoamyl = _as_float(baseline.get("terminal_isoamyl_alcohol_g_L"))
    for summary in summaries:
        sugar = _as_float(summary.get("terminal_total_sugar_g_L"))
        isoamyl = _as_float(summary.get("terminal_isoamyl_alcohol_g_L"))
        summary["delta_terminal_total_sugar_g_L_vs_baseline"] = (
            sugar - baseline_sugar if math.isfinite(sugar) and math.isfinite(baseline_sugar) else ""
        )
        summary["delta_terminal_isoamyl_alcohol_g_L_vs_baseline"] = (
            isoamyl - baseline_isoamyl
            if math.isfinite(isoamyl) and math.isfinite(baseline_isoamyl)
            else ""
        )


def write_csv(path: Path, rows: list[dict[str, object]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path: Path, summaries: list[dict[str, object]], hotspots: list[dict[str, object]]) -> None:
    lines = [
        "# Dynamic-Control MPCC Branch Comparison",
        "",
        "## Trajectory And Residuals",
        "",
        "| case | sugar g/L | d sugar | isoamyl g/L | d isoamyl | T delta C | FDA delta | ORG delta | colloc | lower comp | top residual | top comp |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |",
    ]
    for row in summaries:
        residual = (
            f"{row.get('top_residual_state_name', '')} "
            f"@ {row.get('top_residual_time_h', '')} h"
        ).strip()
        comp = (
            f"{row.get('top_complementarity_reaction_id', '')} "
            f"@ {row.get('top_complementarity_time_h', '')} h"
        ).strip()
        lines.append(
            "| "
            + " | ".join(
                [
                    str(row.get("label", "")),
                    _format_value(row.get("terminal_total_sugar_g_L", "")),
                    _format_value(row.get("delta_terminal_total_sugar_g_L_vs_baseline", "")),
                    _format_value(row.get("terminal_isoamyl_alcohol_g_L", "")),
                    _format_value(row.get("delta_terminal_isoamyl_alcohol_g_L_vs_baseline", "")),
                    _format_value(row.get("post_solve_temperature_C_max_abs_delta_vs_pre_solve", "")),
                    _format_value(row.get("post_solve_fda_g_L_sum_delta_vs_pre_solve", "")),
                    _format_value(row.get("post_solve_organic_g_L_sum_delta_vs_pre_solve", "")),
                    _format_value(row.get("max_collocation_integration_residual", "")),
                    _format_value(row.get("max_lower_complementarity_residual", "")),
                    residual,
                    comp,
                ]
            )
            + " |"
        )
    lines.extend(
        [
            "",
            "## Objective Components",
            "",
            "| case | objective | base | dynamic | productivity | prod share | sugar excess | sugar share | aroma deficit | aroma share | nutrient | thermal | smooth |",
            "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for row in summaries:
        lines.append(
            "| "
            + " | ".join(
                [
                    str(row.get("label", "")),
                    _format_value(row.get("objective_value", "")),
                    _format_value(row.get("objective_base_value_estimate", "")),
                    _format_value(row.get("objective_dynamic_value_estimate", "")),
                    _format_value(row.get("objective_integrated_sugar_value", "")),
                    _format_value(row.get("objective_integrated_sugar_share", "")),
                    _format_value(row.get("objective_terminal_sugar_excess_value", "")),
                    _format_value(row.get("objective_terminal_sugar_excess_share", "")),
                    _format_value(row.get("objective_aroma_deficit_value", "")),
                    _format_value(row.get("objective_aroma_deficit_share", "")),
                    _format_value(row.get("objective_nutrient_value", "")),
                    _format_value(row.get("objective_thermal_energy_value", "")),
                    _format_value(row.get("objective_temperature_smoothness_value", "")),
                ]
            )
            + " |"
        )
    lines.extend(
        [
            "",
            "## Slack Consistency",
            "",
            "| case | sugar required | sugar slack | sugar violation | aroma required | aroma slack | aroma violation |",
            "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for row in summaries:
        lines.append(
            "| "
            + " | ".join(
                [
                    str(row.get("label", "")),
                    _format_value(row.get("objective_terminal_sugar_excess_required_g_L", "")),
                    _format_value(row.get("objective_terminal_sugar_excess_slack_g_L", "")),
                    _format_value(row.get("objective_terminal_sugar_excess_slack_violation_g_L", "")),
                    _format_value(row.get("objective_aroma_deficit_required_g_L", "")),
                    _format_value(row.get("objective_aroma_deficit_slack_g_L", "")),
                    _format_value(row.get("objective_aroma_deficit_slack_violation_g_L", "")),
                ]
            )
            + " |"
        )
    lines.extend(["", "## Hotspots", ""])
    for row in hotspots[: min(len(hotspots), 20)]:
        marker = row.get("state_name") or row.get("reaction_id") or ""
        magnitude = row.get("abs_residual") or row.get("abs_product") or ""
        lines.append(
            "- "
            f"{row.get('label')} {row.get('source')} #{row.get('rank')}: "
            f"{row.get('residual_type')} {marker} at {row.get('time_h')} h "
            f"magnitude {_format_value(magnitude)}"
        )
    lines.append("")
    lines.append("Detailed rows are in the sibling CSV files.")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cases", nargs="+", help="Case paths, optionally label=/path/to/case.")
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("repro/generated/dynamic_control_branch_comparison"),
    )
    parser.add_argument("--top-n", type=int, default=10)
    args = parser.parse_args()

    summaries: list[dict[str, object]] = []
    hotspots: list[dict[str, object]] = []
    for text in args.cases:
        label, raw_path = parse_case_spec(text)
        summary, case_hotspots = load_case(label, raw_path, args.top_n)
        summaries.append(summary)
        hotspots.extend(case_hotspots)
    add_baseline_deltas(summaries)

    summary_fields = list(summaries[0].keys()) if summaries else []
    hotspot_fields = [
        "label",
        "source",
        "rank",
        "residual_type",
        "time_h",
        "element_index",
        "collocation_index",
        "state_name",
        "reaction_id",
        "abs_residual",
        "abs_product",
        "value",
    ]
    out_dir = args.out_dir.resolve()
    summary_path = out_dir / "dynamic_control_branch_comparison_summary.csv"
    hotspot_path = out_dir / "dynamic_control_branch_comparison_hotspots.csv"
    md_path = out_dir / "dynamic_control_branch_comparison.md"
    write_csv(summary_path, summaries, summary_fields)
    write_csv(hotspot_path, hotspots, hotspot_fields)
    write_markdown(md_path, summaries, hotspots)
    print(f"summary_csv={summary_path}")
    print(f"hotspots_csv={hotspot_path}")
    print(f"summary_md={md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
