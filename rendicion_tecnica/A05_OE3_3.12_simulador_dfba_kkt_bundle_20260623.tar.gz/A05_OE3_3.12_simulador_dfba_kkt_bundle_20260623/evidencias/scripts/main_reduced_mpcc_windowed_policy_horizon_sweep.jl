using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_WINDOWED_POLICY_SWEEP_PROFILE = "smoke"
const DEFAULT_MPCC_WINDOWED_POLICY_SWEEP_IPOPT_MAX_ITER = 100

function _mpcc_windowed_policy_sweep_profile()
    raw = strip(
        get(
            ENV,
            "MPCC_WINDOWED_POLICY_SWEEP_PROFILE",
            DEFAULT_MPCC_WINDOWED_POLICY_SWEEP_PROFILE,
        ),
    )
    normalized = lowercase(raw)
    normalized = normalized == "twomh_four_nfe" ? "2h4nfe" : normalized
    normalized in ("smoke", "focused", "72h", "2h4nfe", "custom") ||
        error("Environment variable MPCC_WINDOWED_POLICY_SWEEP_PROFILE must be one of: smoke, focused, 72h, 2h4nfe, twomh_four_nfe, custom. Got: $raw")
    return normalized
end

function _mpcc_windowed_policy_sweep_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizons = "0.5",
            window_hours_values = "0.5",
            nfe_values = "2",
            policies = "residual_feasible",
            state_rmse_thresholds = "0.02",
            max_cases = 1,
            max_windows = 1,
        )
    elseif profile == "focused"
        return (
            target_horizons = "0.5,1.0",
            window_hours_values = "0.5",
            nfe_values = "2",
            policies = "residual_feasible,iteration_limit_residual_feasible_state_drift",
            state_rmse_thresholds = "0.02",
            max_cases = 4,
            max_windows = 2,
        )
    elseif profile == "72h"
        return (
            target_horizons = "0.5,1.0,2.0,4.0,8.0,16.0,32.0,72.0",
            window_hours_values = "0.5",
            nfe_values = "2",
            policies = "iteration_limit_residual_feasible_state_drift",
            state_rmse_thresholds = "0.02",
            max_cases = 8,
            max_windows = 144,
        )
    elseif profile == "2h4nfe"
        return (
            target_horizons = "2.0,4.0,8.0,16.0,32.0,72.0",
            window_hours_values = "2.0",
            nfe_values = "4",
            policies = "iteration_limit_residual_feasible_state_drift",
            state_rmse_thresholds = "0.02",
            max_cases = 12,
            max_windows = 36,
        )
    else
        return (
            target_horizons = "0.5",
            window_hours_values = "0.5",
            nfe_values = "2",
            policies = "residual_feasible",
            state_rmse_thresholds = "0.02",
            max_cases = 1,
            max_windows = 1,
        )
    end
end

function _mpcc_windowed_policy_sweep_env_float_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Float64}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && error("Environment variable $name contains a non-Float64 value: $stripped")
        isfinite(value) && value > 0.0 ||
            error("Environment variable $name values must be finite and positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_windowed_policy_sweep_env_nonnegative_float_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Float64}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && error("Environment variable $name contains a non-Float64 value: $stripped")
        isfinite(value) && value >= 0.0 ||
            error("Environment variable $name values must be finite and nonnegative, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_windowed_policy_sweep_env_int_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Int, stripped)
        value === nothing && error("Environment variable $name contains a non-Int value: $stripped")
        value > 0 || error("Environment variable $name values must be positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_windowed_policy_sweep_env_policy_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{String}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = String[]
    for token in split(raw, [',', ';'])
        stripped = lowercase(strip(token))
        isempty(stripped) && continue
        stripped in (
            "residual_feasible",
            "trajectory_ready",
            "iteration_limit_residual_feasible_state_drift",
        ) || error("Environment variable $name contains an invalid policy: $stripped")
        push!(values, stripped)
    end
    isempty(values) && error("Environment variable $name must contain at least one policy.")
    return values
end

function _mpcc_windowed_policy_sweep_env_string_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{String}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = String[]
    for token in split(raw, [',', ';'])
        stripped = lowercase(strip(token))
        isempty(stripped) && continue
        push!(values, stripped)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_windowed_policy_sweep_env_positive_float(
    name::AbstractString,
    default_value::Real,
)::Float64
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_windowed_policy_sweep_env_positive_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_windowed_policy_sweep_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_windowed_policy_sweep_case_count(
    target_horizons::Vector{Float64},
    window_hours_values::Vector{Float64},
    nfe_values::Vector{Int},
    policies::Vector{String},
    state_thresholds::Vector{Float64},
    linear_solvers::Vector{String},
    complementarity_taus::Vector{Float64},
)::Int
    return length(target_horizons) * length(window_hours_values) * length(nfe_values) *
           length(policies) * length(state_thresholds) * length(linear_solvers) *
           length(complementarity_taus)
end

function _mpcc_windowed_policy_sweep_max_windows(
    target_horizons::Vector{Float64},
    window_hours_values::Vector{Float64},
)::Int
    maximum_windows = 0
    for target in target_horizons
        for duration in window_hours_values
            raw = target / duration
            windows = round(Int, raw)
            isapprox(raw, windows; atol = 1.0e-10, rtol = 1.0e-10) ||
                error("Each target horizon must be an integer multiple of each window duration. Got target=$target, window=$duration.")
            maximum_windows = max(maximum_windows, windows)
        end
    end
    return maximum_windows
end

function _mpcc_windowed_policy_sweep_validate_size!(
    target_horizons::Vector{Float64},
    window_hours_values::Vector{Float64},
    nfe_values::Vector{Int},
    policies::Vector{String},
    state_thresholds::Vector{Float64},
    linear_solvers::Vector{String},
    complementarity_taus::Vector{Float64},
    max_cases::Int,
    allow_large_sweep::Bool,
    max_windows::Int,
    allow_long_horizon::Bool,
)
    n_cases = _mpcc_windowed_policy_sweep_case_count(
        target_horizons,
        window_hours_values,
        nfe_values,
        policies,
        state_thresholds,
        linear_solvers,
        complementarity_taus,
    )
    if n_cases > max_cases && !allow_large_sweep
        error(
            "Requested MPCC windowed policy/horizon sweep has $n_cases cases, above " *
            "MPCC_WINDOWED_POLICY_SWEEP_MAX_CASES=$max_cases. Set " *
            "MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LARGE=1 only for deliberate local diagnostics.",
        )
    end
    requested_windows =
        _mpcc_windowed_policy_sweep_max_windows(target_horizons, window_hours_values)
    if requested_windows > max_windows && !allow_long_horizon
        error(
            "Requested MPCC windowed policy/horizon sweep has up to $requested_windows " *
            "windows, above MPCC_WINDOWED_POLICY_SWEEP_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LONG=1 only for deliberate long diagnostics.",
        )
    end
    return nothing
end

profile = _mpcc_windowed_policy_sweep_profile()
defaults = _mpcc_windowed_policy_sweep_profile_defaults(profile)
target_horizons = _mpcc_windowed_policy_sweep_env_float_list(
    "MPCC_WINDOWED_POLICY_SWEEP_TARGET_HOURS",
    defaults.target_horizons,
)
window_hours_values = _mpcc_windowed_policy_sweep_env_float_list(
    "MPCC_WINDOWED_POLICY_SWEEP_WINDOW_HOURS",
    defaults.window_hours_values,
)
nfe_values = _mpcc_windowed_policy_sweep_env_int_list(
    "MPCC_WINDOWED_POLICY_SWEEP_NFE",
    defaults.nfe_values,
)
policies = _mpcc_windowed_policy_sweep_env_policy_list(
    "MPCC_WINDOWED_POLICY_SWEEP_CONTINUATION_POLICIES",
    defaults.policies,
)
state_thresholds = _mpcc_windowed_policy_sweep_env_nonnegative_float_list(
    "MPCC_WINDOWED_POLICY_SWEEP_STATE_REL_RMSE_THRESHOLDS",
    defaults.state_rmse_thresholds,
)
linear_solvers = _mpcc_windowed_policy_sweep_env_string_list(
    "MPCC_WINDOWED_POLICY_SWEEP_LINEAR_SOLVERS",
    profile == "2h4nfe" ? "mumps,spral" : "mumps",
)
complementarity_mode = reduced_mpcc_complementarity_mode_from_env("scholtes")
complementarity_taus = _mpcc_windowed_policy_sweep_env_float_list(
    "MPCC_WINDOWED_POLICY_SWEEP_COMPLEMENTARITY_TAUS",
    string(reduced_mpcc_complementarity_tau_from_env()),
)
complementarity_tau_gate_tol = reduced_mpcc_complementarity_tau_gate_tol_from_env()
tau_schedule =
    _script_env_bool("MPCC_WINDOWED_POLICY_SWEEP_USE_TAU_CONTINUATION", profile == "2h4nfe") ?
    reduced_mpcc_tau_schedule_from_env() : nothing
tau_schedule_label = tau_schedule === nothing ? "disabled" : join(tau_schedule, ",")
max_cases = _mpcc_windowed_policy_sweep_env_positive_int(
    "MPCC_WINDOWED_POLICY_SWEEP_MAX_CASES",
    defaults.max_cases,
)
max_windows = _mpcc_windowed_policy_sweep_env_positive_int(
    "MPCC_WINDOWED_POLICY_SWEEP_MAX_WINDOWS",
    defaults.max_windows,
)
allow_large_sweep = _script_env_bool("MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LARGE", false)
allow_long_horizon = _script_env_bool("MPCC_WINDOWED_POLICY_SWEEP_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_WINDOWED_POLICY_SWEEP_CONTINUE_ON_ERROR", true)
require_pre_solve_ready =
    _script_env_bool("MPCC_WINDOWED_POLICY_SWEEP_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_WINDOWED_POLICY_SWEEP_SILENT", true)
progress = _script_env_bool("MPCC_WINDOWED_POLICY_SWEEP_PROGRESS", false)
stop_after_first_non_green =
    _script_env_bool("MPCC_WINDOWED_POLICY_SWEEP_STOP_AFTER_FIRST_NON_GREEN", false)
mass_threshold = _mpcc_windowed_policy_sweep_env_positive_float(
    "MPCC_WINDOWED_POLICY_SWEEP_MASS_THRESHOLD",
    1.0e-6,
)
ipopt_max_iter = _mpcc_windowed_policy_sweep_env_positive_int(
    "MPCC_WINDOWED_POLICY_SWEEP_IPOPT_MAX_ITER",
    DEFAULT_MPCC_WINDOWED_POLICY_SWEEP_IPOPT_MAX_ITER,
)

_mpcc_windowed_policy_sweep_validate_size!(
    target_horizons,
    window_hours_values,
    nfe_values,
    policies,
    state_thresholds,
    linear_solvers,
    complementarity_taus,
    max_cases,
    allow_large_sweep,
    max_windows,
    allow_long_horizon,
)

residual_thresholds =
    default_reduced_dcdfba_mpcc_residual_thresholds(
        max_mass_balance_residual = mass_threshold,
    )
viability_thresholds =
    default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
        residual_thresholds = residual_thresholds,
    )

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

case_callback = progress ?
    (row, index, total) -> println(
        "progress: case $index/$total | id=$(row["policy_case_id"]) | " *
        "target=$(_mpcc_windowed_policy_sweep_value(row["target_horizon"])) | " *
        "window=$(_mpcc_windowed_policy_sweep_value(row["window_hours"])) | " *
        "nfe=$(_mpcc_windowed_policy_sweep_value(row["nfe_per_window"])) | " *
        "solver=$(_mpcc_windowed_policy_sweep_value(row["linear_solver"])) | " *
        "tau=$(_mpcc_windowed_policy_sweep_value(row["complementarity_tau"])) | " *
        "policy=$(_mpcc_windowed_policy_sweep_value(row["continuation_acceptance_policy"])) | " *
        "light=$(_mpcc_windowed_policy_sweep_value(row["attempt_traffic_light"])) | " *
        "reached=$(_mpcc_windowed_policy_sweep_value(row["horizon_reached"]))",
    ) :
    nothing

sweep = sweep_reduced_dcdfba_mpcc_windowed_policy_horizons(
    model,
    reaction_map;
    target_horizons = target_horizons,
    window_hours_values = window_hours_values,
    nfe_per_window_values = nfe_values,
    continuation_acceptance_policies = policies,
    continuation_state_relative_rmse_threshold_values = state_thresholds,
    linear_solver_values = linear_solvers,
    complementarity_mode = complementarity_mode,
    complementarity_tau_values = complementarity_taus,
    complementarity_tau_gate_tol = complementarity_tau_gate_tol,
    tau_schedule = tau_schedule,
    degree = 3,
    ipopt_max_iter = ipopt_max_iter,
    require_pre_solve_ready = require_pre_solve_ready,
    residual_thresholds = residual_thresholds,
    viability_thresholds = viability_thresholds,
    silent = silent,
    continue_on_error = continue_on_error,
    stop_after_first_non_green = stop_after_first_non_green,
    case_callback = case_callback,
)

println("Reduced MPCC windowed policy/horizon sweep")
println("profile: $profile")
println("target_horizons_hours: $(join(target_horizons, ","))")
println("window_hours_values: $(join(window_hours_values, ","))")
println("nfe_values: $(join(nfe_values, ","))")
println("boundary_dt_values: $(join([w / n for w in window_hours_values for n in nfe_values], ","))")
println("linear_solvers: $(join(linear_solvers, ","))")
println("complementarity_mode: $complementarity_mode")
println("complementarity_taus: $(join(complementarity_taus, ","))")
println("complementarity_tau_gate_tol: $complementarity_tau_gate_tol")
println("tau_schedule: $tau_schedule_label")
println("continuation_policies: $(join(policies, ","))")
println("state_rel_rmse_thresholds: $(join(state_thresholds, ","))")
println("mass_threshold: $mass_threshold")
println("ipopt_max_iter: $ipopt_max_iter")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("stop_after_first_non_green: $stop_after_first_non_green")
println("outputs_written: $(sweep.metadata["outputs_written"])")
println("sweep_is_scientific_simulation: $(sweep.metadata["sweep_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(sweep.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(sweep.metadata["scientific_baseline"])")
println("first_mpcc_target: $(sweep.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(sweep.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(sweep.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(sweep.metadata["hsl_required"])")
println("ma57_required: $(sweep.metadata["ma57_required"])")
println("indices_reacciones_used: $(sweep.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(sweep.metadata["r0001_used_as_oxygen"])")
println("n_requested_cases: $(sweep.metadata["n_requested_cases"])")
println("n_cases: $(sweep.metadata["n_cases"])")
println("n_completed_cases: $(sweep.metadata["n_completed_cases"])")
println("n_failed_cases: $(sweep.metadata["n_failed_cases"])")
println("green_count: $(sweep.metadata["green_count"])")
println("yellow_count: $(sweep.metadata["yellow_count"])")
println("red_count: $(sweep.metadata["red_count"])")
println("target_completed_count: $(sweep.metadata["target_completed_count"])")
println("attempt_viable_count: $(sweep.metadata["attempt_viable_count"])")
println("scale_candidate_count: $(sweep.metadata["scale_candidate_count"])")
println("review_before_scaling_count: $(sweep.metadata["review_before_scaling_count"])")
println("blocked_case_count: $(sweep.metadata["blocked_case_count"])")
println("best_green_case_id: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_green_case_id"]))")
println("best_green_target_horizon: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_green_target_horizon"]))")
println("best_green_horizon_reached: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_green_horizon_reached"]))")
println("best_green_policy: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_green_policy"]))")
println("best_green_window_hours: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_green_window_hours"]))")
println("best_green_nfe_per_window: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_green_nfe_per_window"]))")
println("best_green_global_state_relative_rmse: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_green_global_state_relative_rmse"]))")
println("best_scale_candidate_case_id: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_scale_candidate_case_id"]))")
println("best_scale_candidate_next_target_horizon_hint: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_scale_candidate_next_target_horizon_hint"]))")
println("best_scale_candidate_recommended_next_action: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["best_scale_candidate_recommended_next_action"]))")
println("max_horizon_reached: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["max_horizon_reached"]))")
println("max_horizon_policy: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["max_horizon_policy"]))")
println("first_non_green_case_id: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["first_non_green_case_id"]))")
println("first_non_green_target_horizon: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["first_non_green_target_horizon"]))")
println("first_non_green_policy: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["first_non_green_policy"]))")
println("first_non_green_traffic_light: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["first_non_green_traffic_light"]))")
println("first_non_green_viability_class: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["first_non_green_viability_class"]))")
println("first_non_green_blocking_reasons: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["first_non_green_blocking_reasons"]))")
println("first_blocked_case_id: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["first_blocked_case_id"]))")
println("first_blocked_primary_blocker: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["first_blocked_primary_blocker"]))")
println("first_blocked_scale_recommended_next_action: $(_mpcc_windowed_policy_sweep_value(sweep.metadata["first_blocked_scale_recommended_next_action"]))")
println("total_solve_elapsed_seconds: $(sweep.metadata["total_solve_elapsed_seconds"])")
println("recommended_next_action: $(sweep.metadata["recommended_next_action"])")

println("policy_horizon_table:")
for row in eachrow(sweep.policy_horizon_table)
    println(
        "  $(row["policy_case_id"]) | target=$(_mpcc_windowed_policy_sweep_value(row["target_horizon"])) | " *
        "window=$(_mpcc_windowed_policy_sweep_value(row["window_hours"])) | " *
        "nfe=$(_mpcc_windowed_policy_sweep_value(row["nfe_per_window"])) | " *
        "solver=$(_mpcc_windowed_policy_sweep_value(row["linear_solver"])) | " *
        "tau=$(_mpcc_windowed_policy_sweep_value(row["complementarity_tau"])) | " *
        "policy=$(_mpcc_windowed_policy_sweep_value(row["continuation_acceptance_policy"])) | " *
        "threshold=$(_mpcc_windowed_policy_sweep_value(row["continuation_state_relative_rmse_threshold"])) | " *
        "light=$(_mpcc_windowed_policy_sweep_value(row["attempt_traffic_light"])) | " *
        "class=$(_mpcc_windowed_policy_sweep_value(row["global_viability_class"])) | " *
        "scale=$(_mpcc_windowed_policy_sweep_value(row["scale_readiness"])) | " *
        "blocker=$(_mpcc_windowed_policy_sweep_value(row["primary_blocker"])) | " *
        "scale_action=$(_mpcc_windowed_policy_sweep_value(row["scale_recommended_next_action"])) | " *
        "next_target=$(_mpcc_windowed_policy_sweep_value(row["next_target_horizon_hint"])) | " *
        "target_done=$(_mpcc_windowed_policy_sweep_value(row["target_completed"])) | " *
        "reached=$(_mpcc_windowed_policy_sweep_value(row["horizon_reached"])) | " *
        "completed_windows=$(_mpcc_windowed_policy_sweep_value(row["n_completed_windows"])) | " *
        "policy_rejects=$(_mpcc_windowed_policy_sweep_value(row["continuation_policy_rejected_window_count"])) | " *
        "iter_limit_accepts=$(_mpcc_windowed_policy_sweep_value(row["iteration_limit_policy_accepted_window_count"])) | " *
        "global_state_rel_rmse=$(_mpcc_windowed_policy_sweep_value(row["global_max_state_relative_rmse"])) | " *
        "solve_s=$(_mpcc_windowed_policy_sweep_value(row["total_solve_elapsed_seconds"])) | " *
        "last_green=$(_mpcc_windowed_policy_sweep_value(row["is_last_green"])) | " *
        "first_non_green=$(_mpcc_windowed_policy_sweep_value(row["is_first_non_green_after_green"])) | " *
        "blocking=$(_mpcc_windowed_policy_sweep_value(row["blocking_reasons"]))",
    )
end

println("interpretation_note: $(sweep.metadata["interpretation_note"])")
