using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_GLOBAL_POLISH_PROFILE = "smoke"
const DEFAULT_MPCC_GLOBAL_POLISH_SOURCE_MAX_ITER = 100
const DEFAULT_MPCC_GLOBAL_POLISH_MAX_ITER = 300
const MPCC_GLOBAL_POLISH_RESIDUAL_MAX_RHS_ENV = "MPCC_RESIDUAL_MAX_RHS"
const MPCC_GLOBAL_POLISH_RESIDUAL_MAX_MASS_ENV = "MPCC_RESIDUAL_MAX_MASS"
const MPCC_GLOBAL_POLISH_RESIDUAL_MAX_BOUND_ENV = "MPCC_RESIDUAL_MAX_BOUND"
const MPCC_GLOBAL_POLISH_RESIDUAL_MAX_LOWER_BOUND_ENV = "MPCC_RESIDUAL_MAX_LOWER_BOUND"
const MPCC_GLOBAL_POLISH_RESIDUAL_MAX_UPPER_BOUND_ENV = "MPCC_RESIDUAL_MAX_UPPER_BOUND"
const MPCC_GLOBAL_POLISH_RESIDUAL_MAX_STATIONARITY_ENV = "MPCC_RESIDUAL_MAX_STATIONARITY"
const MPCC_GLOBAL_POLISH_RESIDUAL_MAX_COMPLEMENTARITY_ENV =
    "MPCC_RESIDUAL_MAX_COMPLEMENTARITY"
const MPCC_GLOBAL_POLISH_RESIDUAL_MAX_LOWER_COMPLEMENTARITY_ENV =
    "MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY"
const MPCC_GLOBAL_POLISH_RESIDUAL_MAX_UPPER_COMPLEMENTARITY_ENV =
    "MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY"

function _mpcc_global_polish_profile()
    raw = strip(get(ENV, "MPCC_GLOBAL_POLISH_PROFILE", DEFAULT_MPCC_GLOBAL_POLISH_PROFILE))
    normalized = lowercase(raw)
    normalized in ("smoke", "focused", "custom") ||
        error("Environment variable MPCC_GLOBAL_POLISH_PROFILE must be one of: smoke, focused, custom. Got: $raw")
    return normalized
end

function _mpcc_global_polish_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizon = "0.5",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 1,
            source_mode = "cascade",
            source_max_iter = 100,
            retry_max_windows = 1,
            retry_max_iters = "200,300",
            cascade_max_iter = 300,
            global_max_iter = 300,
            mass_threshold = "5e-6",
        )
    elseif profile == "focused"
        return (
            target_horizon = "1.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 2,
            source_mode = "cascade",
            source_max_iter = 100,
            retry_max_windows = 2,
            retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            global_max_iter = 500,
            mass_threshold = "5e-6",
        )
    else
        return (
            target_horizon = "1.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 2,
            source_mode = "cascade",
            source_max_iter = 100,
            retry_max_windows = 2,
            retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            global_max_iter = 500,
            mass_threshold = "5e-6",
        )
    end
end

function _mpcc_global_polish_env_positive_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_global_polish_env_positive_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_global_polish_env_nonnegative_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value >= 0 || error("Environment variable $name must be nonnegative, got: $value")
    return value
end

function _mpcc_global_polish_env_optional_bool(name::AbstractString)
    raw = get(ENV, String(name), nothing)
    raw === nothing && return nothing
    raw_value = lowercase(strip(raw))
    isempty(raw_value) && return nothing
    raw_value in ("1", "true", "yes", "y", "on") && return true
    raw_value in ("0", "false", "no", "n", "off") && return false
    error("Environment variable $name must be a boolean value, got: $raw_value")
end

function _mpcc_global_polish_env_optional_nonnegative_float(
    name::AbstractString,
    default_value::Real,
)::Float64
    raw = get(ENV, String(name), nothing)
    raw === nothing && return Float64(default_value)
    stripped = strip(raw)
    isempty(stripped) && return Float64(default_value)
    value = tryparse(Float64, stripped)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $value")
    return value
end

function _mpcc_global_polish_residual_thresholds_from_env(mass_threshold::Real)
    defaults = default_reduced_dcdfba_mpcc_residual_thresholds()
    max_bound = _mpcc_global_polish_env_optional_nonnegative_float(
        MPCC_GLOBAL_POLISH_RESIDUAL_MAX_BOUND_ENV,
        defaults.max_lower_bound_violation,
    )
    max_complementarity = _mpcc_global_polish_env_optional_nonnegative_float(
        MPCC_GLOBAL_POLISH_RESIDUAL_MAX_COMPLEMENTARITY_ENV,
        defaults.max_lower_complementarity_residual,
    )

    return default_reduced_dcdfba_mpcc_residual_thresholds(
        max_rhs_residual = _mpcc_global_polish_env_optional_nonnegative_float(
            MPCC_GLOBAL_POLISH_RESIDUAL_MAX_RHS_ENV,
            defaults.max_rhs_residual,
        ),
        max_mass_balance_residual = _mpcc_global_polish_env_optional_nonnegative_float(
            MPCC_GLOBAL_POLISH_RESIDUAL_MAX_MASS_ENV,
            mass_threshold,
        ),
        max_lower_bound_violation = _mpcc_global_polish_env_optional_nonnegative_float(
            MPCC_GLOBAL_POLISH_RESIDUAL_MAX_LOWER_BOUND_ENV,
            max_bound,
        ),
        max_upper_bound_violation = _mpcc_global_polish_env_optional_nonnegative_float(
            MPCC_GLOBAL_POLISH_RESIDUAL_MAX_UPPER_BOUND_ENV,
            max_bound,
        ),
        max_stationarity_residual = _mpcc_global_polish_env_optional_nonnegative_float(
            MPCC_GLOBAL_POLISH_RESIDUAL_MAX_STATIONARITY_ENV,
            defaults.max_stationarity_residual,
        ),
        max_lower_complementarity_residual =
            _mpcc_global_polish_env_optional_nonnegative_float(
                MPCC_GLOBAL_POLISH_RESIDUAL_MAX_LOWER_COMPLEMENTARITY_ENV,
                max_complementarity,
            ),
        max_upper_complementarity_residual =
            _mpcc_global_polish_env_optional_nonnegative_float(
                MPCC_GLOBAL_POLISH_RESIDUAL_MAX_UPPER_COMPLEMENTARITY_ENV,
                max_complementarity,
            ),
    )
end

function _mpcc_global_polish_parse_int_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        parsed = tryparse(Int, stripped)
        parsed === nothing && error("Environment variable $name has invalid Int token: $stripped")
        parsed > 0 || error("Environment variable $name values must be positive, got: $parsed")
        push!(values, parsed)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_global_polish_source_mode(default_value::AbstractString)::String
    raw = strip(get(ENV, "MPCC_GLOBAL_POLISH_SOURCE", String(default_value)))
    normalized = lowercase(raw)
    normalized in ("cascade", "windowed", "artifacts") ||
        error("Environment variable MPCC_GLOBAL_POLISH_SOURCE must be cascade, windowed, or artifacts. Got: $raw")
    return normalized
end

function _mpcc_global_polish_validate_size!(
    target_horizon::Float64,
    window_hours::Float64,
    max_windows::Int,
    allow_long::Bool,
)
    raw = target_horizon / window_hours
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) ||
        error("MPCC_GLOBAL_POLISH_TARGET_HOURS must be an integer multiple of MPCC_GLOBAL_POLISH_WINDOW_HOURS.")
    if n_windows > max_windows && !allow_long
        error(
            "Requested MPCC global polish has $n_windows source windows, above " *
            "MPCC_GLOBAL_POLISH_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_GLOBAL_POLISH_ALLOW_LONG=1 only for deliberate longer diagnostics.",
        )
    end
    return n_windows
end

function _mpcc_global_polish_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_global_polish_progress_callback(progress::Bool)
    progress || return nothing
    return function (row, row_index, total)
        println(
            "source_progress: $row_index/$total | target=$(_mpcc_global_polish_value(row["target_horizon"])) | " *
            "base=$(_mpcc_global_polish_value(row["base_attempt_traffic_light"])) | " *
            "rebuilt=$(_mpcc_global_polish_value(row["rebuilt_attempt_traffic_light"])) | " *
            "cascade=$(_mpcc_global_polish_value(row["cascade_rebuild_applied"]))",
        )
    end
end

profile = _mpcc_global_polish_profile()
defaults = _mpcc_global_polish_profile_defaults(profile)
target_horizon = _mpcc_global_polish_env_positive_float(
    "MPCC_GLOBAL_POLISH_TARGET_HOURS",
    defaults.target_horizon,
)
window_hours = _mpcc_global_polish_env_positive_float(
    "MPCC_GLOBAL_POLISH_WINDOW_HOURS",
    defaults.window_hours,
)
nfe_per_window = _mpcc_global_polish_env_positive_int(
    "MPCC_GLOBAL_POLISH_NFE",
    defaults.nfe_per_window,
)
max_windows = _mpcc_global_polish_env_positive_int(
    "MPCC_GLOBAL_POLISH_MAX_WINDOWS",
    defaults.max_windows,
)
source_mode = _mpcc_global_polish_source_mode(defaults.source_mode)
source_max_iter = _mpcc_global_polish_env_positive_int(
    "MPCC_GLOBAL_POLISH_SOURCE_MAX_ITER",
    defaults.source_max_iter,
)
retry_max_windows = _mpcc_global_polish_env_nonnegative_int(
    "MPCC_GLOBAL_POLISH_MAX_RETRY_WINDOWS",
    defaults.retry_max_windows,
)
retry_max_iters = _mpcc_global_polish_parse_int_list(
    "MPCC_GLOBAL_POLISH_RETRY_MAX_ITERS",
    defaults.retry_max_iters,
)
cascade_max_iter = _mpcc_global_polish_env_positive_int(
    "MPCC_GLOBAL_POLISH_CASCADE_MAX_ITER",
    defaults.cascade_max_iter,
)
global_max_iter = _mpcc_global_polish_env_nonnegative_int(
    "MPCC_GLOBAL_POLISH_MAX_ITER",
    defaults.global_max_iter,
)
objective_mode = strip(
    get(
        ENV,
        "MPCC_GLOBAL_POLISH_OBJECTIVE_MODE",
        "legacy_zero_derivative",
    ),
)
objective_state_reference = strip(
    get(
        ENV,
        "MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE",
        "seed",
    ),
)
objective_rho = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_OBJECTIVE_RHO",
    1.0,
)
objective_state_tracking_weight = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_WEIGHT",
    1.0,
)
objective_biomass_tracking_weight = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_OBJECTIVE_BIOMASS_WEIGHT",
    0.0,
)
objective_biomass_terminal_weight = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_OBJECTIVE_BIOMASS_TERMINAL_WEIGHT",
    0.0,
)
objective_sugar_tracking_weight = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_OBJECTIVE_SUGAR_WEIGHT",
    0.0,
)
objective_total_sugar_tracking_weight =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_OBJECTIVE_TOTAL_SUGAR_WEIGHT",
        0.0,
    )
objective_total_sugar_terminal_weight =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_OBJECTIVE_TOTAL_SUGAR_TERMINAL_WEIGHT",
        0.0,
    )
objective_flux_tracking_weight = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_OBJECTIVE_FLUX_WEIGHT",
    0.0,
)
objective_derivative_regularization_weight =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_OBJECTIVE_DERIVATIVE_WEIGHT",
        0.0,
    )
dynamic_bounds_mode = strip(get(ENV, "MPCC_REDUCED_DCDFBA_DYNAMIC_BOUNDS_MODE", "growth"))
dynamic_phase_smoothing_width =
    strip(get(ENV, "MPCC_REDUCED_DCDFBA_PHASE_SMOOTHING_WIDTH", "2e-4"))
dynamic_phase_proxy_mode =
    strip(get(ENV, "MPCC_REDUCED_DCDFBA_PHASE_PROXY_MODE", "total_molecular_weight"))
phase_proxy_mode = strip(get(ENV, "DFBA_PHASE_PROXY_MODE", dynamic_phase_proxy_mode))
turnover_threshold = _script_env_float("DFBA_TURNOVER_THRESHOLD", 0.001)
params = default_zenteno_parameters(
    phase_proxy_mode = phase_proxy_mode,
    TURNOVER_THRESHOLD = turnover_threshold,
)
initial_state_config = _script_initial_state_config(params)
trust_region_enabled =
    _script_env_bool("MPCC_GLOBAL_POLISH_TRUST_REGION_ENABLED", false)
trust_region_state_reference = strip(
    get(
        ENV,
        "MPCC_GLOBAL_POLISH_TRUST_REGION_STATE_REFERENCE",
        objective_state_reference,
    ),
)
trust_region_states = strip(
    get(
        ENV,
        "MPCC_GLOBAL_POLISH_TRUST_REGION_STATES",
        "biomass,glucose,fructose,ethanol,total_sugar",
    ),
)
trust_region_abs_delta = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_TRUST_REGION_ABS_DELTA",
    0.0,
)
trust_region_rel_delta = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_TRUST_REGION_REL_DELTA",
    0.02,
)
trust_region_weight = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_TRUST_REGION_WEIGHT",
    100.0,
)
trace_trust_region_enabled =
    _script_env_bool("MPCC_GLOBAL_POLISH_TRACE_TRUST_REGION_ENABLED", false)
trace_trust_region_state_reference = strip(
    get(
        ENV,
        "MPCC_GLOBAL_POLISH_TRACE_TRUST_REGION_STATE_REFERENCE",
        "sequential_reference",
    ),
)
trace_trust_region_states = strip(
    get(ENV, "MPCC_GLOBAL_POLISH_TRACE_TRUST_REGION_STATES", "aromas"),
)
trace_trust_region_abs_delta = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_TRACE_TRUST_REGION_ABS_DELTA",
    0.0,
)
trace_trust_region_rel_delta = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_TRACE_TRUST_REGION_REL_DELTA",
    0.02,
)
trace_trust_region_weight = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_TRACE_TRUST_REGION_WEIGHT",
    100.0,
)
terminal_trust_region_enabled =
    _script_env_bool("MPCC_GLOBAL_POLISH_TERMINAL_TRUST_REGION_ENABLED", false)
terminal_trust_region_state_reference = strip(
    get(
        ENV,
        "MPCC_GLOBAL_POLISH_TERMINAL_TRUST_REGION_STATE_REFERENCE",
        trust_region_state_reference,
    ),
)
terminal_trust_region_states = strip(
    get(
        ENV,
        "MPCC_GLOBAL_POLISH_TERMINAL_TRUST_REGION_STATES",
        "total_sugar",
    ),
)
terminal_trust_region_abs_delta = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_TERMINAL_TRUST_REGION_ABS_DELTA",
    0.0,
)
terminal_trust_region_rel_delta = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_TERMINAL_TRUST_REGION_REL_DELTA",
    0.001,
)
terminal_trust_region_weight = _mpcc_global_polish_env_optional_nonnegative_float(
    "MPCC_GLOBAL_POLISH_TERMINAL_TRUST_REGION_WEIGHT",
    100.0,
)
biological_acceptance_enabled =
    _script_env_bool("MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_ENABLED", false)
biological_acceptance_states = strip(
    get(ENV, "MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_STATES", "core"),
)
biological_acceptance_relative_tolerance =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_REL_TOL",
        0.01,
    )
biological_acceptance_absolute_tolerance =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_ABS_TOL",
        1.0e-9,
    )
biological_acceptance_final_states = strip(
    get(
        ENV,
        "MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_FINAL_STATES",
        "biomass,total_sugar",
    ),
)
biological_acceptance_final_absolute_tolerance =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_BIOLOGICAL_ACCEPTANCE_FINAL_ABS_TOL",
        1.0e-4,
    )
structural_acceptance_relative_tolerance =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_STRUCTURAL_ACCEPTANCE_REL_TOL",
        0.05,
    )
accept_post_solve_requires_trajectory_ready =
    _script_env_bool("MPCC_GLOBAL_POLISH_ACCEPT_POST_SOLVE_REQUIRES_TRAJECTORY_READY", false)
ipopt_profile = reduced_mpcc_ipopt_profile_name_from_env()
linear_solver = ipopt_linear_solver_from_env()
complementarity_mode = reduced_mpcc_complementarity_mode_from_env("scholtes")
complementarity_tau = reduced_mpcc_complementarity_tau_from_env()
mass_threshold = _mpcc_global_polish_env_positive_float(
    "MPCC_GLOBAL_POLISH_MASS_THRESHOLD",
    defaults.mass_threshold,
)
selection_policy =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_SELECTION_POLICY", "iteration_limit_or_not_ready"))
replacement_policy =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_REPLACEMENT_POLICY", "green_or_trajectory_ready"))
allow_long = _script_env_bool("MPCC_GLOBAL_POLISH_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_GLOBAL_POLISH_CONTINUE_ON_ERROR", true)
source_require_pre_solve_ready =
    _script_env_bool("MPCC_GLOBAL_POLISH_SOURCE_REQUIRE_PREFLIGHT", true)
global_require_pre_solve_ready =
    _script_env_bool("MPCC_GLOBAL_POLISH_REQUIRE_PREFLIGHT", false)
source_complete_required =
    _script_env_bool("MPCC_GLOBAL_POLISH_SOURCE_COMPLETE_REQUIRED", true)
silent = _script_env_bool("MPCC_GLOBAL_POLISH_SILENT", true)
progress = _script_env_bool("MPCC_GLOBAL_POLISH_PROGRESS", profile != "smoke")
output_dir = _script_output_dir(
    project_root,
    "MPCC_GLOBAL_POLISH_OUTPUT_DIR",
    joinpath(project_root, "outputs", "reduced_mpcc_global_polish"),
)
output_overwrite = _script_env_bool("MPCC_GLOBAL_POLISH_OUTPUT_OVERWRITE", true)
export_pre_solve_start =
    _script_env_bool("MPCC_GLOBAL_POLISH_EXPORT_PRE_SOLVE_START", true)
pre_solve_start_dir_raw = strip(
    get(
        ENV,
        "MPCC_GLOBAL_POLISH_PRE_SOLVE_START_DIR",
        joinpath(output_dir, "pre_solve_start_values"),
    ),
)
pre_solve_start_output_dir =
    export_pre_solve_start ?
    (
        isabspath(pre_solve_start_dir_raw) ?
        normpath(pre_solve_start_dir_raw) :
        normpath(joinpath(project_root, pre_solve_start_dir_raw))
    ) :
    nothing
artifact_dir_raw = strip(get(ENV, "MPCC_GLOBAL_POLISH_ARTIFACT_DIR", ""))
artifact_dir = isempty(artifact_dir_raw) ? "" :
    (isabspath(artifact_dir_raw) ? normpath(artifact_dir_raw) : normpath(joinpath(project_root, artifact_dir_raw)))
artifact_extension_policy =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_ARTIFACT_EXTENSION_POLICY", "error"))
prefer_dense_start_artifact =
    _script_env_bool("MPCC_GLOBAL_POLISH_PREFER_DENSE_START_ARTIFACT", false)
dense_start_values_path_raw =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_DENSE_START_VALUES_PATH", ""))
dense_start_values_path =
    isempty(dense_start_values_path_raw) ? nothing :
    (
        isabspath(dense_start_values_path_raw) ?
        normpath(dense_start_values_path_raw) :
        normpath(joinpath(project_root, dense_start_values_path_raw))
    )
dense_start_sanitize_duals =
    _script_env_bool("MPCC_GLOBAL_POLISH_SANITIZE_DENSE_START_DUALS", true)
dense_start_kkt_refresh_policy =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_DENSE_START_KKT_REFRESH_POLICY", "fixed_flux_dual_fit"))
dense_start_kkt_refresh_elements =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_DENSE_START_KKT_REFRESH_ELEMENTS", ""))
start_kkt_refresh_force =
    _script_env_bool("MPCC_GLOBAL_POLISH_START_KKT_REFRESH_FORCE", false)
apply_default_start_initializers =
    _mpcc_global_polish_env_optional_bool("MPCC_GLOBAL_POLISH_APPLY_DEFAULT_START_INITIALIZERS")
collocation_repair_enabled =
    _script_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_ENABLED", true)
collocation_repair_elements =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_ELEMENTS", ""))
collocation_repair_max_iterations = _mpcc_global_polish_env_positive_int(
    "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MAX_ITER",
    8,
)
collocation_repair_tolerance = _mpcc_global_polish_env_positive_float(
    "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TOL",
    "1e-7",
)
collocation_repair_trace =
    _script_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE", false)
collocation_repair_restore_best =
    _script_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_RESTORE_BEST", true)
collocation_repair_monotone =
    _script_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MONOTONE", true)
collocation_repair_trace_substeps =
    _script_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE_SUBSTEPS", false)
collocation_repair_final_state_refresh =
    _script_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_STATE_REFRESH", false)
collocation_repair_final_flux_projection =
    _script_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_FLUX_PROJECTION", false)
collocation_repair_final_dual_fit =
    _script_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FINAL_DUAL_FIT", false)
post_repair_fixed_flux_dual_fit =
    _script_env_bool("MPCC_GLOBAL_POLISH_POST_REPAIR_FIXED_FLUX_DUAL_FIT", false)
post_objective_fixed_flux_dual_fit =
    _script_env_bool("MPCC_GLOBAL_POLISH_POST_OBJECTIVE_FIXED_FLUX_DUAL_FIT", false)
post_objective_fixed_flux_dual_fit_elements =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_FIXED_FLUX_DUAL_FIT_ELEMENTS", ""))
post_objective_kkt_refresh =
    _script_env_bool("MPCC_GLOBAL_POLISH_POST_OBJECTIVE_KKT_REFRESH", false)
post_objective_kkt_refresh_elements =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_POST_OBJECTIVE_KKT_REFRESH_ELEMENTS", ""))
post_objective_collocation_repair =
    _script_env_bool("MPCC_GLOBAL_POLISH_POST_OBJECTIVE_COLLOCATION_REPAIR", false)
selective_fixed_flux_dual_fit =
    _script_env_bool("MPCC_GLOBAL_POLISH_SELECTIVE_FIXED_FLUX_DUAL_FIT", false)
bound_dual_complementarity_clip =
    _script_env_bool("MPCC_GLOBAL_POLISH_BOUND_DUAL_COMPLEMENTARITY_CLIP", false)
post_solve_flux_bound_projection_repair =
    _script_env_bool("MPCC_GLOBAL_POLISH_POST_SOLVE_FLUX_BOUND_PROJECTION_REPAIR", false)
skip_nlp_block_violation_rows =
    _script_env_bool("MPCC_GLOBAL_POLISH_SKIP_NLP_BLOCK_VIOLATION_ROWS", false)
stationarity_top_residuals =
    _mpcc_global_polish_env_nonnegative_int(
        "MPCC_GLOBAL_POLISH_STATIONARITY_TOP_RESIDUALS",
        0,
    )
collocation_repair_flux_refresh_max_iterations =
    _mpcc_global_polish_env_nonnegative_int(
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_FLUX_REFRESH_MAX_ITER",
        0,
    )
collocation_repair_damping_factors =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_DAMPING_FACTORS", "1.0,0.5,0.25,0.1,0.05,0.01"))
collocation_repair_monotone_acceptance_tolerance =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_MONOTONE_ACCEPT_TOL",
        0.0,
    )
collocation_repair_trace_every = _mpcc_global_polish_env_positive_int(
    "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_TRACE_EVERY",
    1,
)
collocation_repair_stagnation_iterations = _mpcc_global_polish_env_nonnegative_int(
    "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_STAGNATION_ITERATIONS",
    0,
)
collocation_repair_stagnation_tolerance =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_STAGNATION_TOL",
        0.0,
    )
collocation_repair_post_tail_enabled =
    _script_env_bool("MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ENABLED", false)
collocation_repair_post_tail_elements =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ELEMENTS", ""))
collocation_repair_post_tail_acceptance_tolerance =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_ACCEPT_TOL",
        0.0,
    )
collocation_repair_post_tail_guard_acceptance_tolerance =
    _mpcc_global_polish_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_GUARD_ACCEPT_TOL",
        0.0,
    )
collocation_repair_post_tail_damping_factors =
    strip(
        get(
            ENV,
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_DAMPING_FACTORS",
            "1.0,0.5,0.25,0.1,0.05,0.01",
        ),
    )
collocation_repair_post_tail_refresh_dynamic_flux =
    _script_env_bool(
        "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_REFRESH_DYNAMIC_FLUX",
        true,
    )
collocation_repair_post_tail_guard_score =
    strip(
        get(
            ENV,
            "MPCC_GLOBAL_POLISH_COLLOCATION_REPAIR_POST_TAIL_GUARD_SCORE",
            "candidate_threshold_ratio",
        ),
    )
prefix_candidate_path_raw =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_PREFIX_CANDIDATE_PATH", ""))
prefix_candidate_path =
    isempty(prefix_candidate_path_raw) ? nothing :
    (
        isabspath(prefix_candidate_path_raw) ?
        normpath(prefix_candidate_path_raw) :
        normpath(joinpath(project_root, prefix_candidate_path_raw))
    )
allow_unsafe_prefix_candidate =
    _script_env_bool("MPCC_GLOBAL_POLISH_ALLOW_UNSAFE_PREFIX_CANDIDATE", false)

n_windows = _mpcc_global_polish_validate_size!(
    target_horizon,
    window_hours,
    max_windows,
    allow_long,
)

println("Reduced MPCC global polish smoke")
println("profile: $profile")
println("source_mode: $source_mode")
println("target_horizon: $target_horizon")
println("window_hours: $window_hours")
println("n_windows: $n_windows")
println("nfe_per_window: $nfe_per_window")
println("dynamic_bounds_mode: $dynamic_bounds_mode")
println("dynamic_phase_smoothing_width: $dynamic_phase_smoothing_width")
println("dynamic_phase_proxy_mode: $dynamic_phase_proxy_mode")
println("phase_proxy_mode: $phase_proxy_mode")
println("turnover_threshold: $(params.TURNOVER_THRESHOLD)")
println("initial_condition_policy: $(initial_state_config.metadata["initial_condition_policy"])")
println("initial_yan_policy: $(initial_state_config.metadata["initial_yan_policy"])")
println("initial_yan_target_mgN_L: $(_mpcc_global_polish_value(get(initial_state_config.metadata, "initial_yan_target_mgN_L", missing)))")
println("initial_glucose_g_L: $(initial_state_config.metadata["initial_glucose_g_L"])")
println("initial_fructose_g_L: $(initial_state_config.metadata["initial_fructose_g_L"])")
println("initial_total_sugar_g_L: $(initial_state_config.metadata["initial_total_sugar_g_L"])")
println("initial_free_nitrogen_gN_L: $(initial_state_config.metadata["initial_free_nitrogen_gN_L"])")
println("initial_total_yan_equivalent_mgN_L: $(initial_state_config.metadata["initial_total_yan_equivalent_mgN_L"])")
println("mass_threshold: $mass_threshold")
println("source_ipopt_max_iter: $source_max_iter")
println("retry_max_windows: $retry_max_windows")
println("retry_max_iters: $(join(retry_max_iters, ","))")
println("cascade_max_iter: $cascade_max_iter")
println("global_ipopt_max_iter: $global_max_iter")
println("objective_mode: $objective_mode")
println("objective_state_reference: $objective_state_reference")
println("objective_rho: $objective_rho")
println("objective_state_tracking_weight: $objective_state_tracking_weight")
println("objective_biomass_tracking_weight: $objective_biomass_tracking_weight")
println("objective_biomass_terminal_weight: $objective_biomass_terminal_weight")
println("objective_sugar_tracking_weight: $objective_sugar_tracking_weight")
println("objective_total_sugar_tracking_weight: $objective_total_sugar_tracking_weight")
println("objective_total_sugar_terminal_weight: $objective_total_sugar_terminal_weight")
println("objective_flux_tracking_weight: $objective_flux_tracking_weight")
println("objective_derivative_regularization_weight: $objective_derivative_regularization_weight")
println("trust_region_enabled: $trust_region_enabled")
println("trust_region_state_reference: $trust_region_state_reference")
println("trust_region_states: $trust_region_states")
println("trust_region_abs_delta: $trust_region_abs_delta")
println("trust_region_rel_delta: $trust_region_rel_delta")
println("trust_region_weight: $trust_region_weight")
println("trace_trust_region_enabled: $trace_trust_region_enabled")
println("trace_trust_region_state_reference: $trace_trust_region_state_reference")
println("trace_trust_region_states: $trace_trust_region_states")
println("trace_trust_region_abs_delta: $trace_trust_region_abs_delta")
println("trace_trust_region_rel_delta: $trace_trust_region_rel_delta")
println("trace_trust_region_weight: $trace_trust_region_weight")
println("terminal_trust_region_enabled: $terminal_trust_region_enabled")
println("terminal_trust_region_state_reference: $terminal_trust_region_state_reference")
println("terminal_trust_region_states: $terminal_trust_region_states")
println("terminal_trust_region_abs_delta: $terminal_trust_region_abs_delta")
println("terminal_trust_region_rel_delta: $terminal_trust_region_rel_delta")
println("terminal_trust_region_weight: $terminal_trust_region_weight")
println("biological_acceptance_enabled: $biological_acceptance_enabled")
println("biological_acceptance_states: $biological_acceptance_states")
println("biological_acceptance_relative_tolerance: $biological_acceptance_relative_tolerance")
println("biological_acceptance_absolute_tolerance: $biological_acceptance_absolute_tolerance")
println("biological_acceptance_final_states: $biological_acceptance_final_states")
println("biological_acceptance_final_absolute_tolerance: $biological_acceptance_final_absolute_tolerance")
println("structural_acceptance_relative_tolerance: $structural_acceptance_relative_tolerance")
println("accept_post_solve_requires_trajectory_ready: $accept_post_solve_requires_trajectory_ready")
println("ipopt_profile: $ipopt_profile")
println("linear_solver: $linear_solver")
println("complementarity_mode: $complementarity_mode")
println("complementarity_tau: $complementarity_tau")
println("selection_policy: $selection_policy")
println("replacement_policy: $replacement_policy")
println("artifact_dir: $(isempty(artifact_dir) ? "missing" : artifact_dir)")
println("artifact_extension_policy: $artifact_extension_policy")
println("prefer_dense_start_artifact: $prefer_dense_start_artifact")
println("dense_start_values_path: $(dense_start_values_path === nothing ? "missing" : dense_start_values_path)")
println("dense_start_sanitize_duals: $dense_start_sanitize_duals")
println("dense_start_kkt_refresh_policy: $dense_start_kkt_refresh_policy")
println("dense_start_kkt_refresh_elements: $(isempty(dense_start_kkt_refresh_elements) ? "all" : dense_start_kkt_refresh_elements)")
println("start_kkt_refresh_force: $start_kkt_refresh_force")
println("apply_default_start_initializers: $(apply_default_start_initializers === nothing ? "auto" : apply_default_start_initializers)")
println("collocation_repair_enabled: $collocation_repair_enabled")
println("collocation_repair_elements: $(isempty(collocation_repair_elements) ? "all" : collocation_repair_elements)")
println("collocation_repair_max_iterations: $collocation_repair_max_iterations")
println("collocation_repair_tolerance: $collocation_repair_tolerance")
println("collocation_repair_trace: $collocation_repair_trace")
println("collocation_repair_restore_best: $collocation_repair_restore_best")
println("collocation_repair_monotone: $collocation_repair_monotone")
println("collocation_repair_trace_substeps: $collocation_repair_trace_substeps")
println("collocation_repair_final_state_refresh: $collocation_repair_final_state_refresh")
println("collocation_repair_final_flux_projection: $collocation_repair_final_flux_projection")
println("collocation_repair_final_dual_fit: $collocation_repair_final_dual_fit")
println("post_repair_fixed_flux_dual_fit: $post_repair_fixed_flux_dual_fit")
println("post_objective_fixed_flux_dual_fit: $post_objective_fixed_flux_dual_fit")
println("post_objective_fixed_flux_dual_fit_elements: $(isempty(post_objective_fixed_flux_dual_fit_elements) ? "all" : post_objective_fixed_flux_dual_fit_elements)")
println("post_objective_kkt_refresh: $post_objective_kkt_refresh")
println("post_objective_kkt_refresh_elements: $(isempty(post_objective_kkt_refresh_elements) ? "all" : post_objective_kkt_refresh_elements)")
println("post_objective_collocation_repair: $post_objective_collocation_repair")
println("selective_fixed_flux_dual_fit: $selective_fixed_flux_dual_fit")
println("bound_dual_complementarity_clip: $bound_dual_complementarity_clip")
println("post_solve_flux_bound_projection_repair: $post_solve_flux_bound_projection_repair")
println("skip_nlp_block_violation_rows: $skip_nlp_block_violation_rows")
println("stationarity_top_residuals: $stationarity_top_residuals")
println("collocation_repair_flux_refresh_max_iterations: $collocation_repair_flux_refresh_max_iterations")
println("collocation_repair_damping_factors: $collocation_repair_damping_factors")
println("collocation_repair_monotone_acceptance_tolerance: $collocation_repair_monotone_acceptance_tolerance")
println("collocation_repair_trace_every: $collocation_repair_trace_every")
println("collocation_repair_stagnation_iterations: $collocation_repair_stagnation_iterations")
println("collocation_repair_stagnation_tolerance: $collocation_repair_stagnation_tolerance")
println("collocation_repair_post_tail_enabled: $collocation_repair_post_tail_enabled")
println("collocation_repair_post_tail_elements: $(isempty(collocation_repair_post_tail_elements) ? "all" : collocation_repair_post_tail_elements)")
println("collocation_repair_post_tail_acceptance_tolerance: $collocation_repair_post_tail_acceptance_tolerance")
println("collocation_repair_post_tail_guard_acceptance_tolerance: $collocation_repair_post_tail_guard_acceptance_tolerance")
println("collocation_repair_post_tail_damping_factors: $collocation_repair_post_tail_damping_factors")
println("collocation_repair_post_tail_refresh_dynamic_flux: $collocation_repair_post_tail_refresh_dynamic_flux")
println("collocation_repair_post_tail_guard_score: $collocation_repair_post_tail_guard_score")
println("export_pre_solve_start: $export_pre_solve_start")
println("pre_solve_start_output_dir: $(pre_solve_start_output_dir === nothing ? "missing" : pre_solve_start_output_dir)")
println("prefix_candidate_path: $(prefix_candidate_path === nothing ? "missing" : prefix_candidate_path)")
println("allow_unsafe_prefix_candidate: $allow_unsafe_prefix_candidate")
println("source_require_pre_solve_ready: $source_require_pre_solve_ready")
println("global_require_pre_solve_ready: $global_require_pre_solve_ready")
println("source_complete_required: $source_complete_required")
println("continue_on_error: $continue_on_error")
println("progress: $progress")
println("output_dir: $output_dir")

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

residual_thresholds = _mpcc_global_polish_residual_thresholds_from_env(mass_threshold)
viability_thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
    residual_thresholds = residual_thresholds,
)

println("residual_max_rhs: $(residual_thresholds.max_rhs_residual)")
println("residual_max_mass: $(residual_thresholds.max_mass_balance_residual)")
println("residual_max_lower_bound: $(residual_thresholds.max_lower_bound_violation)")
println("residual_max_upper_bound: $(residual_thresholds.max_upper_bound_violation)")
println("residual_max_stationarity: $(residual_thresholds.max_stationarity_residual)")
println("residual_max_lower_complementarity: $(residual_thresholds.max_lower_complementarity_residual)")
println("residual_max_upper_complementarity: $(residual_thresholds.max_upper_complementarity_residual)")
flush(stdout)

source = if source_mode == "cascade"
    smoke = smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(
        model,
        reaction_map;
        target_horizons = [target_horizon],
        window_hours = window_hours,
        nfe_per_window = nfe_per_window,
        degree = 3,
        y0 = initial_state_config.y0,
        params = params,
        source_ipopt_max_iter = source_max_iter,
        retry_ipopt_max_iter_values = retry_max_iters,
        cascade_ipopt_max_iter = cascade_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        retry_selection_policy = selection_policy,
        retry_max_windows = retry_max_windows,
        replacement_acceptance_policy = replacement_policy,
        require_pre_solve_ready = source_require_pre_solve_ready,
        residual_thresholds = residual_thresholds,
        viability_thresholds = viability_thresholds,
        silent = silent,
        continue_on_error = continue_on_error,
        case_callback = _mpcc_global_polish_progress_callback(progress),
    )
    isempty(smoke.cascade_results) &&
        error("MPCC global polish cascade source produced no completed cascade result.")
    first(smoke.cascade_results)
elseif source_mode == "windowed"
    run_reduced_dcdfba_mpcc_windowed_continuation(
        model,
        reaction_map;
        window_hours = window_hours,
        n_windows = n_windows,
        nfe_per_window = nfe_per_window,
        degree = 3,
        y0 = initial_state_config.y0,
        params = params,
        ipopt_max_iter = source_max_iter,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        require_pre_solve_ready = source_require_pre_solve_ready,
        residual_thresholds = residual_thresholds,
        silent = silent,
        continue_on_error = continue_on_error,
    )
else
    nothing
end

polish =
    if source_mode == "artifacts"
        isempty(artifact_dir) && error("Set MPCC_GLOBAL_POLISH_ARTIFACT_DIR when MPCC_GLOBAL_POLISH_SOURCE=artifacts.")
        println("global_polish_stage: calling_artifact_polish")
        flush(stdout)
        polish_reduced_dcdfba_mpcc_windowed_artifacts(
            model,
            reaction_map,
            artifact_dir;
            target_horizon = target_horizon,
            window_hours = window_hours,
            nfe_per_window = nfe_per_window,
            degree = 3,
            residual_thresholds = residual_thresholds,
            params = params,
            ipopt_max_iter = global_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            objective_mode = objective_mode,
            objective_state_reference = objective_state_reference,
            objective_rho = objective_rho,
            objective_state_tracking_weight = objective_state_tracking_weight,
            objective_biomass_tracking_weight = objective_biomass_tracking_weight,
            objective_biomass_terminal_weight = objective_biomass_terminal_weight,
            objective_sugar_tracking_weight = objective_sugar_tracking_weight,
            objective_total_sugar_tracking_weight = objective_total_sugar_tracking_weight,
            objective_total_sugar_terminal_weight = objective_total_sugar_terminal_weight,
            objective_flux_tracking_weight = objective_flux_tracking_weight,
            objective_derivative_regularization_weight =
                objective_derivative_regularization_weight,
            trust_region_enabled = trust_region_enabled,
            trust_region_state_reference = trust_region_state_reference,
            trust_region_states = trust_region_states,
            trust_region_abs_delta = trust_region_abs_delta,
            trust_region_rel_delta = trust_region_rel_delta,
            trust_region_weight = trust_region_weight,
            trace_trust_region_enabled = trace_trust_region_enabled,
            trace_trust_region_state_reference = trace_trust_region_state_reference,
            trace_trust_region_states = trace_trust_region_states,
            trace_trust_region_abs_delta = trace_trust_region_abs_delta,
            trace_trust_region_rel_delta = trace_trust_region_rel_delta,
            trace_trust_region_weight = trace_trust_region_weight,
            terminal_trust_region_enabled = terminal_trust_region_enabled,
            terminal_trust_region_state_reference = terminal_trust_region_state_reference,
            terminal_trust_region_states = terminal_trust_region_states,
            terminal_trust_region_abs_delta = terminal_trust_region_abs_delta,
            terminal_trust_region_rel_delta = terminal_trust_region_rel_delta,
            terminal_trust_region_weight = terminal_trust_region_weight,
            biological_acceptance_enabled = biological_acceptance_enabled,
            biological_acceptance_states = biological_acceptance_states,
            biological_acceptance_relative_tolerance =
                biological_acceptance_relative_tolerance,
            biological_acceptance_absolute_tolerance =
                biological_acceptance_absolute_tolerance,
            biological_acceptance_final_states = biological_acceptance_final_states,
            biological_acceptance_final_absolute_tolerance =
                biological_acceptance_final_absolute_tolerance,
            structural_acceptance_relative_tolerance =
                structural_acceptance_relative_tolerance,
            accept_post_solve_requires_trajectory_ready =
                accept_post_solve_requires_trajectory_ready,
            require_pre_solve_ready = global_require_pre_solve_ready,
            require_complete = source_complete_required,
            artifact_extension_policy = artifact_extension_policy,
            prefer_dense_start_artifact = prefer_dense_start_artifact,
            dense_start_values_path = dense_start_values_path,
            sanitize_dense_start_duals = dense_start_sanitize_duals,
            dense_start_kkt_refresh_policy = dense_start_kkt_refresh_policy,
            prefix_candidate_path = prefix_candidate_path,
            allow_unsafe_prefix_candidate = allow_unsafe_prefix_candidate,
            apply_default_start_initializers = apply_default_start_initializers,
            collocation_repair_enabled = collocation_repair_enabled,
            collocation_repair_max_iterations = collocation_repair_max_iterations,
            collocation_repair_tolerance = collocation_repair_tolerance,
            pre_solve_start_output_dir = pre_solve_start_output_dir,
            pre_solve_start_output_overwrite = output_overwrite,
            silent = silent,
        )
    else
        polish_reduced_dcdfba_mpcc_windowed_candidate(
            model,
            reaction_map,
            source;
            residual_thresholds = residual_thresholds,
            params = params,
            ipopt_max_iter = global_max_iter,
            linear_solver = linear_solver,
            ipopt_profile = ipopt_profile,
            complementarity_mode = complementarity_mode,
            complementarity_tau = complementarity_tau,
            objective_mode = objective_mode,
            objective_state_reference = objective_state_reference,
            objective_rho = objective_rho,
            objective_state_tracking_weight = objective_state_tracking_weight,
            objective_biomass_tracking_weight = objective_biomass_tracking_weight,
            objective_biomass_terminal_weight = objective_biomass_terminal_weight,
            objective_sugar_tracking_weight = objective_sugar_tracking_weight,
            objective_total_sugar_tracking_weight = objective_total_sugar_tracking_weight,
            objective_total_sugar_terminal_weight = objective_total_sugar_terminal_weight,
            objective_flux_tracking_weight = objective_flux_tracking_weight,
            objective_derivative_regularization_weight =
                objective_derivative_regularization_weight,
            trust_region_enabled = trust_region_enabled,
            trust_region_state_reference = trust_region_state_reference,
            trust_region_states = trust_region_states,
            trust_region_abs_delta = trust_region_abs_delta,
            trust_region_rel_delta = trust_region_rel_delta,
            trust_region_weight = trust_region_weight,
            trace_trust_region_enabled = trace_trust_region_enabled,
            trace_trust_region_state_reference = trace_trust_region_state_reference,
            trace_trust_region_states = trace_trust_region_states,
            trace_trust_region_abs_delta = trace_trust_region_abs_delta,
            trace_trust_region_rel_delta = trace_trust_region_rel_delta,
            trace_trust_region_weight = trace_trust_region_weight,
            terminal_trust_region_enabled = terminal_trust_region_enabled,
            terminal_trust_region_state_reference = terminal_trust_region_state_reference,
            terminal_trust_region_states = terminal_trust_region_states,
            terminal_trust_region_abs_delta = terminal_trust_region_abs_delta,
            terminal_trust_region_rel_delta = terminal_trust_region_rel_delta,
            terminal_trust_region_weight = terminal_trust_region_weight,
            biological_acceptance_enabled = biological_acceptance_enabled,
            biological_acceptance_states = biological_acceptance_states,
            biological_acceptance_relative_tolerance =
                biological_acceptance_relative_tolerance,
            biological_acceptance_absolute_tolerance =
                biological_acceptance_absolute_tolerance,
            biological_acceptance_final_states = biological_acceptance_final_states,
            biological_acceptance_final_absolute_tolerance =
                biological_acceptance_final_absolute_tolerance,
            structural_acceptance_relative_tolerance =
                structural_acceptance_relative_tolerance,
            accept_post_solve_requires_trajectory_ready =
                accept_post_solve_requires_trajectory_ready,
            require_pre_solve_ready = global_require_pre_solve_ready,
            require_complete = source_complete_required,
            collocation_repair_enabled = collocation_repair_enabled,
            collocation_repair_max_iterations = collocation_repair_max_iterations,
            collocation_repair_tolerance = collocation_repair_tolerance,
            pre_solve_start_output_dir = pre_solve_start_output_dir,
            pre_solve_start_output_overwrite = output_overwrite,
            silent = silent,
        )
    end

paths = safe_write_reduced_dcdfba_mpcc_global_polish_report(
    polish,
    output_dir;
    overwrite = output_overwrite,
)

println("outputs_written: $(polish.metadata["outputs_written"])")
println("recovery_written: $(get(polish.metadata, "recovery_written", false))")
println("report_export_failed: $(get(polish.metadata, "report_export_failed", false))")
println("pre_export_recovery_dir: $(get(polish.metadata, "pre_export_recovery_dir", "missing"))")
println("pre_solve_start_export_requested: $(get(polish.metadata, "global_polish_pre_solve_start_export_requested", "missing"))")
println("pre_solve_start_exported: $(get(polish.metadata, "global_polish_pre_solve_start_exported", "missing"))")
println("pre_solve_start_values_path: $(get(polish.metadata, "global_polish_pre_solve_start_values_path", "missing"))")
println("pre_solve_start_metadata_path: $(get(polish.metadata, "global_polish_pre_solve_start_metadata_path", "missing"))")
println("pre_solve_start_array_manifest_path: $(get(polish.metadata, "global_polish_pre_solve_start_array_manifest_path", "missing"))")
for key in sort(collect(keys(paths)))
    println("output_$(key): $(paths[key])")
end
haskey(paths, "diagnostics_metadata") &&
    println("output_diagnostics_metadata: $(paths["diagnostics_metadata"])")
haskey(paths, "plot_core_states") &&
    println("output_plot_core_states: $(paths["plot_core_states"])")
println("global_polish_is_scientific_simulation: $(polish.metadata["global_polish_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(polish.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(polish.metadata["scientific_baseline"])")
println("first_mpcc_target: $(polish.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(polish.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(polish.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(polish.metadata["hsl_required"])")
println("ma57_required: $(polish.metadata["ma57_required"])")
println("indices_reacciones_used: $(polish.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(polish.metadata["r0001_used_as_oxygen"])")
println("global_polish_source_kind: $(polish.metadata["global_polish_source_kind"])")
println("global_polish_objective_mode: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_mode", missing)))")
println("global_polish_objective_replaced: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_replaced", missing)))")
println("global_polish_objective_description: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_description", missing)))")
println("global_polish_objective_state_reference: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_state_reference", missing)))")
println("global_polish_objective_rho: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_rho", missing)))")
println("global_polish_objective_state_tracking_weight: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_state_tracking_weight", missing)))")
println("global_polish_objective_biomass_tracking_weight: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_biomass_tracking_weight", missing)))")
println("global_polish_objective_biomass_terminal_weight: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_biomass_terminal_weight", missing)))")
println("global_polish_objective_sugar_tracking_weight: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_sugar_tracking_weight", missing)))")
println("global_polish_objective_total_sugar_tracking_weight: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_total_sugar_tracking_weight", missing)))")
println("global_polish_objective_total_sugar_terminal_weight: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_objective_total_sugar_terminal_weight", missing)))")
println("dynamic_flux_bound_mode: $(_mpcc_global_polish_value(get(polish.metadata, "dynamic_flux_bound_mode", missing)))")
println("dynamic_phase_smoothing_width: $(_mpcc_global_polish_value(get(polish.metadata, "dynamic_phase_smoothing_width", missing)))")
println("dynamic_phase_proxy_mode: $(_mpcc_global_polish_value(get(polish.metadata, "dynamic_phase_proxy_mode", missing)))")
println("dynamic_phase_proxy_definition: $(_mpcc_global_polish_value(get(polish.metadata, "dynamic_phase_proxy_definition", missing)))")
println("smooth_turnover_mode_embedded: $(_mpcc_global_polish_value(get(polish.metadata, "smooth_turnover_mode_embedded", missing)))")
println("turnover_mode_deferred: $(_mpcc_global_polish_value(get(polish.metadata, "turnover_mode_deferred", missing)))")
println("global_polish_trust_region_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_enabled", missing)))")
println("global_polish_trust_region_state_reference: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_state_reference", missing)))")
println("global_polish_trust_region_resolved_states: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_resolved_states", missing)))")
println("global_polish_trust_region_abs_delta: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_abs_delta", missing)))")
println("global_polish_trust_region_rel_delta: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_rel_delta", missing)))")
println("global_polish_trust_region_weight: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_weight", missing)))")
println("global_polish_trust_region_mode: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_mode", missing)))")
println("global_polish_trust_region_hard_constraint_center: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_hard_constraint_center", missing)))")
println("global_polish_trust_region_slack_terms: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_slack_terms", missing)))")
println("global_polish_trust_region_constraint_terms: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trust_region_constraint_terms", missing)))")
println("global_polish_trace_trust_region_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_enabled", missing)))")
println("global_polish_trace_trust_region_state_reference: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_state_reference", missing)))")
println("global_polish_trace_trust_region_resolved_states: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_resolved_states", missing)))")
println("global_polish_trace_trust_region_abs_delta: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_abs_delta", missing)))")
println("global_polish_trace_trust_region_rel_delta: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_rel_delta", missing)))")
println("global_polish_trace_trust_region_weight: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_weight", missing)))")
println("global_polish_trace_trust_region_mode: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_mode", missing)))")
println("global_polish_trace_trust_region_hard_constraint_center: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_hard_constraint_center", missing)))")
println("global_polish_trace_trust_region_slack_terms: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_slack_terms", missing)))")
println("global_polish_trace_trust_region_constraint_terms: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_trace_trust_region_constraint_terms", missing)))")
println("global_polish_terminal_trust_region_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_enabled", missing)))")
println("global_polish_terminal_trust_region_state_reference: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_state_reference", missing)))")
println("global_polish_terminal_trust_region_resolved_states: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_resolved_states", missing)))")
println("global_polish_terminal_trust_region_abs_delta: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_abs_delta", missing)))")
println("global_polish_terminal_trust_region_rel_delta: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_rel_delta", missing)))")
println("global_polish_terminal_trust_region_weight: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_weight", missing)))")
println("global_polish_terminal_trust_region_mode: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_mode", missing)))")
println("global_polish_terminal_trust_region_hard_constraint_center: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_hard_constraint_center", missing)))")
println("global_polish_terminal_trust_region_slack_terms: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_slack_terms", missing)))")
println("global_polish_terminal_trust_region_constraint_terms: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_constraint_terms", missing)))")
println("global_polish_terminal_trust_region_total_sugar_band: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_terminal_trust_region_total_sugar_band", missing)))")
println("global_polish_incremental_prefix_candidate_used: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_incremental_prefix_candidate_used", missing)))")
println("global_polish_incremental_prefix_candidate_path: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_incremental_prefix_candidate_path", missing)))")
println("global_polish_incremental_prefix_candidate_handoff_ready: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_incremental_prefix_candidate_handoff_ready", missing)))")
println("global_polish_incremental_prefix_candidate_handoff_reason: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_incremental_prefix_candidate_handoff_reason", missing)))")
println("global_polish_incremental_prefix_candidate_unsafe_allowed: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_incremental_prefix_candidate_unsafe_allowed", missing)))")
println("global_polish_artifact_dense_start_duals_sanitized: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_artifact_dense_start_duals_sanitized", missing)))")
println("global_polish_artifact_dense_start_dual_policy: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_artifact_dense_start_dual_policy", missing)))")
println("global_polish_artifact_dense_start_kkt_refresh_policy: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_artifact_dense_start_kkt_refresh_policy", missing)))")
println("global_polish_artifact_extension_policy: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_artifact_extension_policy", missing)))")
println("global_polish_artifact_extension_applied: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_artifact_extension_applied", missing)))")
println("global_polish_artifact_extension_tail_hours: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_artifact_extension_tail_hours", missing)))")
println("global_polish_artifact_extension_source_final_time: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_artifact_extension_source_final_time", missing)))")
println("global_polish_artifact_extension_target_final_time: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_artifact_extension_target_final_time", missing)))")
println("global_polish_artifact_extension_reference_is_scientific: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_artifact_extension_reference_is_scientific", missing)))")
println("global_polish_dense_start_kkt_refresh_applied: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_dense_start_kkt_refresh_applied", missing)))")
println("global_polish_dense_start_kkt_refresh_policy: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_dense_start_kkt_refresh_policy", missing)))")
println("global_polish_collocation_repair_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_collocation_repair_enabled", missing)))")
println("global_polish_collocation_repair_applied: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_collocation_repair_applied", missing)))")
println("global_polish_collocation_repair_policy: $(_mpcc_global_polish_value(get(polish.metadata, "global_polish_collocation_repair_policy", missing)))")
println("collocation_consistent_state_start_iterations: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_iterations", missing)))")
println("collocation_consistent_state_start_converged: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_converged", missing)))")
println("collocation_consistent_state_start_final_collocation_residual: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_final_collocation_residual", missing)))")
println("collocation_consistent_state_start_final_continuity_residual: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_final_continuity_residual", missing)))")
println("collocation_consistent_state_start_final_rhs_residual: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_final_rhs_residual", missing)))")
println("collocation_consistent_state_start_initial_max_residual: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_initial_max_residual", missing)))")
println("collocation_consistent_state_start_final_max_residual: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_final_max_residual", missing)))")
println("collocation_consistent_state_start_last_residual_improvement: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_residual_improvement", missing)))")
println("collocation_consistent_state_start_restore_best_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_restore_best_enabled", missing)))")
println("collocation_consistent_state_start_monotone_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_monotone_enabled", missing)))")
println("collocation_consistent_state_start_trace_substeps_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_trace_substeps_enabled", missing)))")
println("collocation_consistent_state_start_final_state_refresh_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_final_state_refresh_enabled", missing)))")
println("collocation_consistent_state_start_final_flux_projection_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_final_flux_projection_enabled", missing)))")
println("collocation_consistent_state_start_final_dual_fit_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_final_dual_fit_enabled", missing)))")
println("collocation_consistent_state_start_flux_refresh_max_iterations: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_flux_refresh_max_iterations", missing)))")
println("collocation_consistent_state_start_damping_factors: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_damping_factors", missing)))")
println("collocation_consistent_state_start_monotone_acceptance_tolerance: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_monotone_acceptance_tolerance", missing)))")
println("collocation_consistent_state_start_trial_count: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_trial_count", missing)))")
println("collocation_consistent_state_start_rejected_trial_count: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_rejected_trial_count", missing)))")
println("collocation_consistent_state_start_last_accepted_damping_factor: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_accepted_damping_factor", missing)))")
println("collocation_consistent_state_start_min_accepted_damping_factor: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_min_accepted_damping_factor", missing)))")
println("collocation_consistent_state_start_last_rejected_damping_factor: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_rejected_damping_factor", missing)))")
println("collocation_consistent_state_start_last_rejected_max_residual: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_rejected_max_residual", missing)))")
println("collocation_consistent_state_start_stopped_by_monotone_guard: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_stopped_by_monotone_guard", missing)))")
println("collocation_consistent_state_start_last_final_state_refresh_applied: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_final_state_refresh_applied", missing)))")
println("collocation_consistent_state_start_last_final_flux_projection_applied: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_final_flux_projection_applied", missing)))")
println("collocation_consistent_state_start_last_final_dual_fit_applied: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_final_dual_fit_applied", missing)))")
println("collocation_consistent_state_start_last_dynamic_flux_refresh_applied: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_dynamic_flux_refresh_applied", missing)))")
println("collocation_consistent_state_start_best_iteration: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_best_iteration", missing)))")
println("collocation_consistent_state_start_best_max_residual: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_best_max_residual", missing)))")
println("collocation_consistent_state_start_restored_best_iteration: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_restored_best_iteration", missing)))")
println("collocation_consistent_state_start_restore_best_improvement: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_restore_best_improvement", missing)))")
println("collocation_consistent_state_start_stopped_by_stagnation: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_stopped_by_stagnation", missing)))")
println("collocation_consistent_state_start_stagnation_counter: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_stagnation_counter", missing)))")
println("collocation_consistent_state_start_last_dynamic_flux_lp_attempt_count: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_dynamic_flux_lp_attempt_count", missing)))")
println("collocation_consistent_state_start_last_dynamic_flux_lp_total_solve_elapsed_seconds: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_dynamic_flux_lp_total_solve_elapsed_seconds", missing)))")
println("collocation_consistent_state_start_last_dynamic_flux_lp_max_solve_elapsed_seconds: $(_mpcc_global_polish_value(get(polish.metadata, "collocation_consistent_state_start_last_dynamic_flux_lp_max_solve_elapsed_seconds", missing)))")
println("fixed_flux_stationarity_dual_fit_max_stationarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "fixed_flux_stationarity_dual_fit_max_stationarity_residual_after", missing)))")
println("fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after", missing)))")
println("fixed_flux_stationarity_dual_fit_max_upper_complementarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "fixed_flux_stationarity_dual_fit_max_upper_complementarity_residual_after", missing)))")
println("post_repair_fixed_flux_stationarity_dual_fit_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "post_repair_fixed_flux_stationarity_dual_fit_enabled", missing)))")
println("post_repair_fixed_flux_stationarity_dual_fit_applied: $(_mpcc_global_polish_value(get(polish.metadata, "post_repair_fixed_flux_stationarity_dual_fit_applied", missing)))")
println("post_objective_fixed_flux_stationarity_dual_fit_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "post_objective_fixed_flux_stationarity_dual_fit_enabled", missing)))")
println("post_objective_fixed_flux_stationarity_dual_fit_applied: $(_mpcc_global_polish_value(get(polish.metadata, "post_objective_fixed_flux_stationarity_dual_fit_applied", missing)))")
println("post_objective_fixed_flux_stationarity_dual_fit_elements: $(_mpcc_global_polish_value(get(polish.metadata, "post_objective_fixed_flux_stationarity_dual_fit_elements", missing)))")
println("post_objective_kkt_refresh_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "post_objective_kkt_refresh_enabled", missing)))")
println("post_objective_kkt_refresh_applied: $(_mpcc_global_polish_value(get(polish.metadata, "post_objective_kkt_refresh_applied", missing)))")
println("post_objective_kkt_refresh_elements: $(_mpcc_global_polish_value(get(polish.metadata, "post_objective_kkt_refresh_elements", missing)))")
println("post_objective_collocation_repair_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "post_objective_collocation_repair_enabled", missing)))")
println("post_objective_collocation_repair_applied: $(_mpcc_global_polish_value(get(polish.metadata, "post_objective_collocation_repair_applied", missing)))")
println("post_objective_collocation_repair_elements: $(_mpcc_global_polish_value(get(polish.metadata, "post_objective_collocation_repair_elements", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_enabled", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_applied: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_applied", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_accepted: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_accepted", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_rejected: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_rejected", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_rejection_reason: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_rejection_reason", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_element_count: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_element_count", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_trigger_threshold: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_trigger_threshold", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_effective_complementarity_budget_tau: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_effective_complementarity_budget_tau", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_stationarity_acceptance_threshold: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_stationarity_acceptance_threshold", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_max_stationarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_max_stationarity_residual_after", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after", missing)))")
println("selective_fixed_flux_stationarity_dual_fit_max_upper_complementarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "selective_fixed_flux_stationarity_dual_fit_max_upper_complementarity_residual_after", missing)))")
println("bound_dual_complementarity_clip_applied: $(_mpcc_global_polish_value(get(polish.metadata, "bound_dual_complementarity_clip_applied", missing)))")
println("bound_dual_complementarity_clip_effective_complementarity_budget_tau: $(_mpcc_global_polish_value(get(polish.metadata, "bound_dual_complementarity_clip_effective_complementarity_budget_tau", missing)))")
println("bound_dual_complementarity_clip_max_stationarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "bound_dual_complementarity_clip_max_stationarity_residual_after", missing)))")
println("bound_dual_complementarity_clip_max_lower_complementarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "bound_dual_complementarity_clip_max_lower_complementarity_residual_after", missing)))")
println("bound_dual_complementarity_clip_max_upper_complementarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "bound_dual_complementarity_clip_max_upper_complementarity_residual_after", missing)))")
println("post_solve_flux_bound_projection_repair_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_enabled", missing)))")
println("post_solve_flux_bound_projection_repair_applied: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_applied", missing)))")
println("post_solve_flux_bound_projection_repair_adjusted_count: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_adjusted_count", missing)))")
println("post_solve_flux_bound_projection_repair_max_adjustment: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_max_adjustment", missing)))")
println("post_solve_flux_bound_projection_repair_max_adjustment_reaction_id: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_max_adjustment_reaction_id", missing)))")
println("post_solve_flux_bound_projection_repair_max_lower_bound_violation_after: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_max_lower_bound_violation_after", missing)))")
println("post_solve_flux_bound_projection_repair_max_upper_bound_violation_after: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_max_upper_bound_violation_after", missing)))")
println("post_solve_flux_bound_projection_repair_max_mass_balance_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_max_mass_balance_residual_after", missing)))")
println("post_solve_flux_bound_projection_repair_max_rhs_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_max_rhs_residual_after", missing)))")
println("post_solve_flux_bound_projection_repair_max_lower_complementarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_max_lower_complementarity_residual_after", missing)))")
println("post_solve_flux_bound_projection_repair_max_upper_complementarity_residual_after: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_flux_bound_projection_repair_max_upper_complementarity_residual_after", missing)))")
println("source_window_count: $(polish.metadata["source_window_count"])")
println("global_nfe: $(polish.metadata["global_nfe"])")
println("global_horizon: $(polish.metadata["global_horizon"])")
println("nlp_structure_total_variables: $(_mpcc_global_polish_value(polish.metadata["nlp_structure_total_variables"]))")
println("nlp_structure_equality_constraints: $(_mpcc_global_polish_value(polish.metadata["nlp_structure_equality_constraints"]))")
println("nlp_structure_inequality_constraints: $(_mpcc_global_polish_value(polish.metadata["nlp_structure_inequality_constraints"]))")
println("nlp_structure_fixed_variable_count: $(_mpcc_global_polish_value(polish.metadata["nlp_structure_fixed_variable_count"]))")
println("nlp_structure_effective_variable_count: $(_mpcc_global_polish_value(polish.metadata["nlp_structure_effective_variable_count"]))")
println("nlp_structure_dof_balance: $(_mpcc_global_polish_value(polish.metadata["nlp_structure_dof_balance"]))")
println("nlp_structure_too_few_degrees_of_freedom_risk: $(_mpcc_global_polish_value(polish.metadata["nlp_structure_too_few_degrees_of_freedom_risk"]))")
println("nlp_structure_fixed_variable_treatment_hint: $(_mpcc_global_polish_value(polish.metadata["nlp_structure_fixed_variable_treatment_hint"]))")
println("source_max_boundary_join_mismatch: $(polish.metadata["source_max_boundary_join_mismatch"])")
println("pre_solve_guard_passed: $(_mpcc_global_polish_value(polish.metadata["pre_solve_guard_passed"]))")
println("pre_solve_blocked: $(_mpcc_global_polish_value(polish.metadata["pre_solve_blocked"]))")
println("solver_status: $(_mpcc_global_polish_value(polish.metadata["solver_status"]))")
println("primal_status: $(_mpcc_global_polish_value(polish.metadata["primal_status"]))")
println("ipopt_profile: $(_mpcc_global_polish_value(polish.metadata["ipopt_profile"]))")
println("acceptable_solver_status: $(_mpcc_global_polish_value(polish.metadata["acceptable_solver_status"]))")
println("almost_locally_solved_accepted: $(_mpcc_global_polish_value(polish.metadata["almost_locally_solved_accepted"]))")
println("solve_elapsed_seconds: $(_mpcc_global_polish_value(polish.metadata["solve_elapsed_seconds"]))")
println("candidate_values_available: $(polish.metadata["candidate_values_available"])")
println("candidate_residual_feasible: $(polish.metadata["candidate_residual_feasible"])")
println("candidate_trajectory_ready: $(polish.metadata["candidate_trajectory_ready"])")
println("candidate_iteration_limit_residual_feasible: $(polish.metadata["candidate_iteration_limit_residual_feasible"])")
println("candidate_dominant_residual: $(_mpcc_global_polish_value(polish.metadata["candidate_dominant_residual"]))")
println("candidate_selection_policy: $(_mpcc_global_polish_value(get(polish.metadata, "candidate_selection_policy", missing)))")
println("candidate_selection_reason: $(_mpcc_global_polish_value(get(polish.metadata, "candidate_selection_reason", missing)))")
println("selected_candidate_source: $(_mpcc_global_polish_value(get(polish.metadata, "selected_candidate_source", missing)))")
println("selected_candidate_residual_feasible: $(_mpcc_global_polish_value(get(polish.metadata, "selected_candidate_residual_feasible", missing)))")
println("selected_candidate_trajectory_ready: $(_mpcc_global_polish_value(get(polish.metadata, "selected_candidate_trajectory_ready", missing)))")
println("post_solve_candidate_accepted: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_candidate_accepted", missing)))")
println("post_solve_candidate_rejected: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_candidate_rejected", missing)))")
println("pre_solve_start_structural_residual_score: $(_mpcc_global_polish_value(get(polish.metadata, "pre_solve_start_structural_residual_score", missing)))")
println("post_solve_structural_residual_score: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_structural_residual_score", missing)))")
println("post_solve_structural_acceptance_relative_tolerance: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_structural_acceptance_relative_tolerance", missing)))")
println("post_solve_candidate_structural_acceptance_passed: $(_mpcc_global_polish_value(get(polish.metadata, "post_solve_candidate_structural_acceptance_passed", missing)))")
println("biological_acceptance_enabled: $(_mpcc_global_polish_value(get(polish.metadata, "biological_acceptance_enabled", missing)))")
println("biological_acceptance_passed: $(_mpcc_global_polish_value(get(polish.metadata, "biological_acceptance_passed", missing)))")
println("biological_acceptance_reason: $(_mpcc_global_polish_value(get(polish.metadata, "biological_acceptance_reason", missing)))")
println("biological_acceptance_states: $(_mpcc_global_polish_value(get(polish.metadata, "biological_acceptance_states", missing)))")
println("biological_acceptance_trace_states_excluded: $(_mpcc_global_polish_value(get(polish.metadata, "biological_acceptance_trace_states_excluded", missing)))")
println("biological_acceptance_start_core_relative_rmse: $(_mpcc_global_polish_value(get(polish.metadata, "biological_acceptance_start_core_relative_rmse", missing)))")
println("biological_acceptance_post_solve_core_relative_rmse: $(_mpcc_global_polish_value(get(polish.metadata, "biological_acceptance_post_solve_core_relative_rmse", missing)))")
println("biological_acceptance_start_core_final_abs_difference: $(_mpcc_global_polish_value(get(polish.metadata, "biological_acceptance_start_core_final_abs_difference", missing)))")
println("biological_acceptance_post_solve_core_final_abs_difference: $(_mpcc_global_polish_value(get(polish.metadata, "biological_acceptance_post_solve_core_final_abs_difference", missing)))")
println("max_rhs_residual: $(_mpcc_global_polish_value(polish.metadata["max_rhs_residual"]))")
println("max_collocation_integration_residual: $(_mpcc_global_polish_value(get(polish.metadata, "max_collocation_integration_residual", missing)))")
println("max_continuity_residual: $(_mpcc_global_polish_value(get(polish.metadata, "max_continuity_residual", missing)))")
println("max_initial_condition_residual: $(_mpcc_global_polish_value(get(polish.metadata, "max_initial_condition_residual", missing)))")
println("max_mass_balance_residual: $(_mpcc_global_polish_value(polish.metadata["max_mass_balance_residual"]))")
println("max_stationarity_residual: $(_mpcc_global_polish_value(polish.metadata["max_stationarity_residual"]))")
println("max_lower_complementarity_residual: $(_mpcc_global_polish_value(polish.metadata["max_lower_complementarity_residual"]))")
println("max_upper_complementarity_residual: $(_mpcc_global_polish_value(polish.metadata["max_upper_complementarity_residual"]))")
println("comparison_available: $(polish.metadata["comparison_available"])")
println("max_state_relative_rmse: $(_mpcc_global_polish_value(polish.metadata["max_state_relative_rmse"]))")
println("final_total_sugar_difference: $(_mpcc_global_polish_value(polish.metadata["final_total_sugar_difference"]))")
println("selected_candidate_max_state_relative_rmse: $(_mpcc_global_polish_value(get(polish.metadata, "selected_candidate_max_state_relative_rmse", missing)))")
println("selected_candidate_final_biomass_difference: $(_mpcc_global_polish_value(get(polish.metadata, "selected_candidate_final_biomass_difference", missing)))")
println("selected_candidate_final_total_sugar_difference: $(_mpcc_global_polish_value(get(polish.metadata, "selected_candidate_final_total_sugar_difference", missing)))")
println("recommended_next_action: $(polish.metadata["recommended_next_action"])")

println("start_summary_table:")
for row in eachrow(polish.start_summary_table)
    println(
        "  $(row["block"]) | source=$(row["source_size"]) | target=$(row["target_size"]) | " *
        "applied=$(row["applied"]) | finite=$(row["finite_value_count"])/$(row["total_value_count"]) | " *
        "max_abs=$(_mpcc_global_polish_value(row["max_abs_start"]))",
    )
end

println("interpretation_note: $(polish.metadata["interpretation_note"])")
