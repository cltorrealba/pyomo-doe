println("cluster_uc_julia_warmup_start")
flush(stdout)

using Dates
using Pkg

println("cluster_uc_julia_warmup_phase: pkg_precompile_start timestamp=$(Dates.now())")
flush(stdout)
Pkg.precompile()
println("cluster_uc_julia_warmup_phase: pkg_precompile_done timestamp=$(Dates.now())")
flush(stdout)

println("cluster_uc_julia_warmup_phase: import_csv_start timestamp=$(Dates.now())")
flush(stdout)
using CSV
println("cluster_uc_julia_warmup_phase: import_csv_done timestamp=$(Dates.now())")
flush(stdout)

println("cluster_uc_julia_warmup_phase: import_dataframes_start timestamp=$(Dates.now())")
flush(stdout)
using DataFrames
println("cluster_uc_julia_warmup_phase: import_dataframes_done timestamp=$(Dates.now())")
flush(stdout)

println("cluster_uc_julia_warmup_phase: import_highs_start timestamp=$(Dates.now())")
flush(stdout)
using HiGHS
println("cluster_uc_julia_warmup_phase: import_highs_done timestamp=$(Dates.now())")
flush(stdout)

println("cluster_uc_julia_warmup_phase: import_ordinarydiffeq_start timestamp=$(Dates.now())")
flush(stdout)
using OrdinaryDiffEq
println("cluster_uc_julia_warmup_phase: import_ordinarydiffeq_done timestamp=$(Dates.now())")
flush(stdout)

println("cluster_uc_julia_warmup_phase: import_fermentationdfba_start timestamp=$(Dates.now())")
flush(stdout)
using FermentationDFBA
println("cluster_uc_julia_warmup_phase: import_fermentationdfba_done timestamp=$(Dates.now())")
flush(stdout)

println("cluster_uc_julia_warmup_done: true timestamp=$(Dates.now())")
flush(stdout)
