#!/usr/bin/env python3
"""Plot optimized dynamic-control values from a reduced MPCC pilot output."""

from __future__ import annotations

import argparse
import ast
import csv
import math
import os
import re
from pathlib import Path
from typing import Iterable


CONTROL_KEYS = {
    "temperature": "candidate_dynamic_control_temperature_C_values",
    "fda": "candidate_dynamic_control_fda_g_L_values",
    "organic": "candidate_dynamic_control_organic_g_L_values",
}

POST_SOLVE_CONTROL_KEYS = {
    "temperature": "post_solve_candidate_dynamic_control_temperature_C_values",
    "fda": "post_solve_candidate_dynamic_control_fda_g_L_values",
    "organic": "post_solve_candidate_dynamic_control_organic_g_L_values",
}


SUMMARY_KEYS = [
    "case_id",
    "solver_status",
    "primal_status",
    "selected_candidate_source",
    "selected_candidate_residual_feasible",
    "selected_candidate_trajectory_ready",
    "selected_candidate_terminal_state_values_available",
    "selected_candidate_terminal_glucose_g_L",
    "selected_candidate_terminal_fructose_g_L",
    "selected_candidate_terminal_total_sugar_g_L",
    "selected_candidate_terminal_isoamyl_alcohol_g_L",
    "post_solve_candidate_residual_feasible",
    "pre_solve_candidate_dynamic_control_values_captured",
    "post_solve_candidate_dynamic_control_values_captured",
    "post_solve_candidate_dynamic_control_delta_vs_pre_solve_available",
    "post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve",
    "post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve",
    "post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve",
    "candidate_residual_feasible",
    "dynamic_control_objective_enabled",
    "dynamic_control_objective_mode",
    "dynamic_control_objective_resolved_target_state",
    "dynamic_control_objective_target_state_alias_policy",
    "dynamic_control_objective_target_component_count",
    "dynamic_control_objective_target_component_names",
    "dynamic_control_objective_terminal_state_scale_g_L",
    "dynamic_control_objective_terminal_sugar_weight",
    "dynamic_control_objective_terminal_sugar_scale_g_L",
    "dynamic_control_objective_integrated_sugar_weight",
    "dynamic_control_objective_integrated_sugar_scale_g_L",
    "dynamic_control_objective_integrated_sugar_config_policy",
    "dynamic_control_objective_integrated_sugar_max_g_L",
    "dynamic_control_objective_aroma_reward_policy",
    "dynamic_control_objective_integrated_aroma_reward_terms",
    "dynamic_control_objective_integrated_aroma_reward_policy",
    "dynamic_control_objective_terminal_sugar_terms",
    "dynamic_control_objective_integrated_sugar_terms",
    "dynamic_control_objective_integrated_sugar_policy",
    "dynamic_control_objective_integrated_sugar_slack_count",
    "objective_value",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_collocation_integration_residual",
    "max_continuity_residual",
]


def _literal_value(raw: str):
    text = raw.strip()
    if text.startswith('"') and text.endswith('"'):
        return text[1:-1]
    if text in {"true", "false"}:
        return text == "true"
    if text == "NaN":
        return math.nan
    if text in {"Inf", "+Inf"}:
        return math.inf
    if text == "-Inf":
        return -math.inf
    try:
        return ast.literal_eval(text)
    except (SyntaxError, ValueError):
        try:
            return float(text)
        except ValueError:
            return text


def read_metadata_toml(path: Path, wanted_keys: set[str]) -> dict[str, object]:
    values: dict[str, object] = {}
    current_table = ""
    assignment = re.compile(r"^([A-Za-z0-9_]+)\s*=\s*(.*)$")
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("["):
            current_table = stripped.strip("[]")
            continue
        if current_table not in {"", "candidate_metadata", "result_metadata"}:
            continue
        match = assignment.match(stripped)
        if match and match.group(1) in wanted_keys:
            values[match.group(1)] = _literal_value(match.group(2))
    return values


def read_attempt_csv(path: Path) -> dict[str, object]:
    if not path.is_file():
        return {}
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        try:
            row = next(reader)
        except StopIteration:
            return {}
    return {key: _literal_value(value) for key, value in row.items() if value != ""}


def read_decision_spec(path: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            parsed: dict[str, object] = dict(row)
            for key in ("slot_index",):
                parsed[key] = int(float(str(row[key])))
            for key in ("time_h", "start_value", "lower_bound", "upper_bound", "trust_region"):
                parsed[key] = float(str(row[key]))
            parsed["free"] = str(row.get("free", "")).lower() == "true"
            rows.append(parsed)
    return rows


def build_control_rows(
    spec_rows: Iterable[dict[str, object]], metadata: dict[str, object]
) -> list[dict[str, object]]:
    by_family = {family: list(metadata.get(key, [])) for family, key in CONTROL_KEYS.items()}
    post_solve_by_family = {
        family: list(metadata.get(key, [])) for family, key in POST_SOLVE_CONTROL_KEYS.items()
    }
    counters = {family: 0 for family in CONTROL_KEYS}
    output: list[dict[str, object]] = []
    for row in spec_rows:
        family = str(row["family"])
        if family not in by_family:
            continue
        idx = counters[family]
        values = by_family[family]
        optimized = float(values[idx]) if idx < len(values) else float(row["start_value"])
        post_solve_values = post_solve_by_family.get(family, [])
        post_solve_available = idx < len(post_solve_values)
        post_solve_value = (
            float(post_solve_values[idx]) if post_solve_available else ""
        )
        start = float(row["start_value"])
        counters[family] += 1
        output.append(
            {
                "variable_name": row["variable_name"],
                "family": family,
                "slot_index": row["slot_index"],
                "time_h": row["time_h"],
                "start_value": start,
                "optimized_value": optimized,
                "delta": optimized - start,
                "post_solve_value": post_solve_value,
                "post_solve_delta": (
                    post_solve_value - start if post_solve_available else ""
                ),
                "post_solve_available": post_solve_available,
                "lower_bound": row["lower_bound"],
                "upper_bound": row["upper_bound"],
                "free": row["free"],
                "trust_region": row["trust_region"],
                "unit": row["unit"],
            }
        )
    return output


def write_control_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "variable_name",
        "family",
        "slot_index",
        "time_h",
        "start_value",
        "optimized_value",
        "delta",
        "post_solve_value",
        "post_solve_delta",
        "post_solve_available",
        "lower_bound",
        "upper_bound",
        "free",
        "trust_region",
        "unit",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def write_summary_csv(path: Path, metadata: dict[str, object], rows: list[dict[str, object]]) -> None:
    by_family = {
        family: [row for row in rows if row["family"] == family] for family in CONTROL_KEYS
    }
    summary = {key: metadata.get(key, "") for key in SUMMARY_KEYS}
    for family, family_rows in by_family.items():
        values = [abs(float(row["delta"])) for row in family_rows]
        opt_values = [float(row["optimized_value"]) for row in family_rows]
        post_rows = [row for row in family_rows if row["post_solve_value"] != ""]
        post_values = [float(row["post_solve_value"]) for row in post_rows]
        post_deltas = [float(row["post_solve_delta"]) for row in post_rows]
        summary[f"{family}_slot_count"] = len(family_rows)
        summary[f"{family}_max_abs_delta"] = max(values) if values else 0.0
        summary[f"{family}_optimized_sum"] = sum(opt_values)
        summary[f"{family}_post_solve_available"] = str(bool(post_rows)).lower()
        summary[f"{family}_post_solve_max_abs_delta"] = (
            max(abs(value) for value in post_deltas) if post_deltas else ""
        )
        summary[f"{family}_post_solve_sum_delta"] = (
            sum(post_deltas) if post_deltas else ""
        )
        summary[f"{family}_post_solve_sum"] = sum(post_values) if post_values else ""
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary.keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerow(summary)


def _family_series(rows: list[dict[str, object]], family: str, value_key: str) -> tuple[list[float], list[float]]:
    family_rows = [row for row in rows if row["family"] == family]
    return (
        [float(row["time_h"]) for row in family_rows],
        [float(row[value_key]) for row in family_rows],
    )


def _optional_family_series(
    rows: list[dict[str, object]], family: str, value_key: str
) -> tuple[list[float], list[float]]:
    family_rows = [
        row for row in rows if row["family"] == family and row.get(value_key, "") != ""
    ]
    return (
        [float(row["time_h"]) for row in family_rows],
        [float(row[value_key]) for row in family_rows],
    )


def plot_controls(path: Path, rows: list[dict[str, object]], metadata: dict[str, object]) -> None:
    import matplotlib.pyplot as plt

    path.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(4, 1, figsize=(10.5, 10.0), sharex=True)
    fig.suptitle(
        "Dynamic MPCC optimized controls - "
        f"{metadata.get('case_id', 'unknown case')}",
        fontsize=12,
    )

    t, temp_start = _family_series(rows, "temperature", "start_value")
    _, temp_opt = _family_series(rows, "temperature", "optimized_value")
    _, temp_low = _family_series(rows, "temperature", "lower_bound")
    _, temp_high = _family_series(rows, "temperature", "upper_bound")
    axes[0].plot(t, temp_start, "--", color="#808080", label="reference")
    axes[0].plot(t, temp_opt, "-o", color="#0072B2", label="optimized", markersize=3)
    post_t, temp_post = _optional_family_series(rows, "temperature", "post_solve_value")
    if post_t:
        axes[0].plot(
            post_t,
            temp_post,
            ":s",
            color="#CC79A7",
            label="post-solve candidate",
            markersize=3,
        )
    axes[0].fill_between(t, temp_low, temp_high, color="#0072B2", alpha=0.12, label="trust bounds")
    axes[0].set_ylabel("Temperature (C)")
    axes[0].legend(loc="best", fontsize=8)

    temp_delta_mc = [(opt - ref) * 1000.0 for opt, ref in zip(temp_opt, temp_start)]
    axes[1].axhline(0.0, color="#808080", linewidth=0.8)
    axes[1].bar(t, temp_delta_mc, width=7.0, color="#56B4E9")
    post_t, temp_post_delta = _optional_family_series(rows, "temperature", "post_solve_delta")
    if post_t:
        axes[1].plot(
            post_t,
            [value * 1000.0 for value in temp_post_delta],
            ":s",
            color="#CC79A7",
            label="post-solve candidate",
            markersize=3,
        )
        axes[1].legend(loc="best", fontsize=8)
    axes[1].set_ylabel("Temp delta (mC)")

    for family, color, label in (
        ("fda", "#D55E00", "FDA"),
        ("organic", "#009E73", "Organic"),
    ):
        tt, start = _family_series(rows, family, "start_value")
        _, opt = _family_series(rows, family, "optimized_value")
        post_t, post = _optional_family_series(rows, family, "post_solve_value")
        axes[2].plot(tt, start, "--", color=color, alpha=0.45, label=f"{label} reference")
        axes[2].plot(tt, opt, "-o", color=color, label=f"{label} optimized", markersize=3)
        if post_t:
            axes[2].plot(
                post_t,
                post,
                ":s",
                color=color,
                alpha=0.85,
                label=f"{label} post-solve",
                markersize=3,
            )
    axes[2].set_ylabel("Dose (g/L)")
    axes[2].legend(loc="best", fontsize=8)

    for family, color, label in (
        ("fda", "#D55E00", "FDA"),
        ("organic", "#009E73", "Organic"),
    ):
        tt, start = _family_series(rows, family, "start_value")
        _, opt = _family_series(rows, family, "optimized_value")
        post_t, post_delta = _optional_family_series(rows, family, "post_solve_delta")
        delta_mg_l = [(o - s) * 1000.0 for o, s in zip(opt, start)]
        axes[3].bar(tt, delta_mg_l, width=5.0, alpha=0.7, color=color, label=label)
        if post_t:
            axes[3].plot(
                post_t,
                [value * 1000.0 for value in post_delta],
                ":s",
                color=color,
                alpha=0.95,
                label=f"{label} post-solve",
                markersize=3,
            )
    axes[3].axhline(0.0, color="#808080", linewidth=0.8)
    axes[3].set_ylabel("Dose delta (mg/L)")
    axes[3].set_xlabel("Time (h)")
    axes[3].legend(loc="best", fontsize=8)

    for axis in axes:
        axis.grid(True, alpha=0.25)
    fig.tight_layout(rect=(0.0, 0.0, 1.0, 0.97))
    fig.savefig(path)
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "case_dir",
        type=Path,
        help="Directory containing reduced_mpcc_fixed_control_policy_solve_attempt.toml",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=None,
        help="Output directory for plot and CSV files. Defaults to case_dir/plots.",
    )
    args = parser.parse_args()

    case_dir = args.case_dir.resolve()
    metadata_path = case_dir / "reduced_mpcc_fixed_control_policy_solve_attempt.toml"
    attempt_csv_path = case_dir / "reduced_mpcc_fixed_control_policy_solve_attempt.csv"
    spec_path = case_dir / "reduced_mpcc_dynamic_control_decision_spec.csv"
    if not metadata_path.is_file():
        raise FileNotFoundError(metadata_path)
    if not spec_path.is_file():
        raise FileNotFoundError(spec_path)

    out_dir = (args.out_dir or (case_dir / "plots")).resolve()
    wanted_keys = set(SUMMARY_KEYS) | set(CONTROL_KEYS.values()) | set(POST_SOLVE_CONTROL_KEYS.values())
    metadata = read_metadata_toml(metadata_path, wanted_keys)
    for key, value in read_attempt_csv(attempt_csv_path).items():
        metadata.setdefault(key, value)
    rows = build_control_rows(read_decision_spec(spec_path), metadata)

    control_csv = out_dir / "optimized_control_values.csv"
    summary_csv = out_dir / "optimized_control_summary.csv"
    plot_svg = out_dir / "optimized_control_profiles.svg"
    plot_png = out_dir / "optimized_control_profiles.png"

    write_control_csv(control_csv, rows)
    write_summary_csv(summary_csv, metadata, rows)
    if not os.environ.get("MPLCONFIGDIR"):
        os.environ["MPLCONFIGDIR"] = str(out_dir / ".matplotlib")
    plot_controls(plot_svg, rows, metadata)
    plot_controls(plot_png, rows, metadata)

    print(f"control_csv={control_csv}")
    print(f"summary_csv={summary_csv}")
    print(f"plot_svg={plot_svg}")
    print(f"plot_png={plot_png}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
