using FermentationDFBA
using DataFrames
using SparseArrays

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")

paths = load_dfvb_artifact_paths(paths_config)
file_report = validate_dfvb_artifact_files(paths)
artifacts = load_dfvb_artifacts(paths)
validation = validate_dfvb_artifacts(artifacts)

function _dfvb_script_status_value(status::AbstractDict, key::AbstractString)
    return haskey(status, key) ? string(status[key]) : "missing"
end

function _dfvb_script_time_range(table)
    table === nothing && return "not_loaded"
    return "$(table[1, "time"]) to $(table[end, "time"])"
end

println("DFVB MATLAB artifact loader report")
println("artifact_id: $(paths.artifact_id)")
println("all_files_present: $(file_report.ok)")
println("manifest_n_reactions: $(artifacts.manifest.n_reactions)")
println("manifest_n_metabolites: $(artifacts.manifest.n_metabolites)")
println("manifest_n_null_basis_columns: $(artifacts.manifest.n_null_basis_columns)")
println("manifest_n_exchange_reactions: $(artifacts.manifest.n_exchange_reactions)")
println("manifest_n_internal_reactions: $(artifacts.manifest.n_internal_reactions)")
println("manifest_n_dfvb_time_points: $(artifacts.manifest.n_dfvb_time_points)")
println("manifest_has_active_alpha_subset: $(artifacts.manifest.has_active_alpha_subset)")
println("manifest_n_active_alpha_columns: $(artifacts.manifest.n_active_alpha_columns)")
println("N_size: $(size(artifacts.N))")
println("N_nnz: $(nnz(artifacts.N))")
println("N_active_size: $(size(artifacts.N_active))")
println("N_active_nnz: $(nnz(artifacts.N_active))")
println("alpha_trajectories_size: $(artifacts.alpha_trajectories === nothing ? "not_loaded" : string(size(artifacts.alpha_trajectories)))")
println("alpha_trajectories_time_range: $(_dfvb_script_time_range(artifacts.alpha_trajectories))")
println("alpha_trajectories_active_size: $(artifacts.alpha_trajectories_active === nothing ? "not_loaded" : string(size(artifacts.alpha_trajectories_active)))")
println("alpha_trajectories_active_time_range: $(_dfvb_script_time_range(artifacts.alpha_trajectories_active))")
println("state_trajectories_size: $(artifacts.state_trajectories === nothing ? "not_loaded" : string(size(artifacts.state_trajectories)))")
println("state_trajectories_time_range: $(_dfvb_script_time_range(artifacts.state_trajectories))")
println("exchange_partition_rows: $(nrow(artifacts.exchange_partition))")
println("reaction_order_rows: $(nrow(artifacts.reaction_order))")
println("reduced_dfba_reaction_order_rows: $(nrow(artifacts.reduced_dfba_reaction_order))")
println("indices_are_matlab_1_based: $(artifacts.metadata["indices_are_matlab_1_based"])")
println("indices_reacciones_used: $(artifacts.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(artifacts.metadata["r0001_used_as_oxygen"])")

println("critical_reaction_status:")
critical = validation.summary["critical_reactions"]
for reaction_id in ("r_0001", "r_1992", "r_2111", "r_4048")
    status = critical[reaction_id]
    println(
        "  $reaction_id | found=$(_dfvb_script_status_value(status, "found")) | " *
        "reaction_index=$(_dfvb_script_status_value(status, "reaction_index")) | " *
        "partition=$(_dfvb_script_status_value(status, "partition")) | " *
        "is_exchange=$(_dfvb_script_status_value(status, "is_exchange")) | " *
        "is_internal=$(_dfvb_script_status_value(status, "is_internal"))",
    )
end

println("validation_ok: $(validation.ok)")
println("validation_error_count: $(length(validation.errors))")
for error_message in validation.errors
    println("  error: $error_message")
end
println("validation_warning_count: $(length(validation.warnings))")
for warning_message in validation.warnings
    println("  warning: $warning_message")
end
println("oxygen_mapping_note: $(artifacts.metadata["oxygen_mapping_note"])")
println("exchange_partition_note: $(artifacts.metadata["exchange_partition_note"])")
println("reduced_dfba_reaction_order_note: $(artifacts.metadata["reduced_dfba_reaction_order_note"])")
println("static_dfvb_lp_implemented: true")
println("dfvb_rhs_implemented: false")
println("kkt_mpcc_collocation_implemented: false")
