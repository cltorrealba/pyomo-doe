println("dynamic_control_objective_init: script_start")
flush(stdout)

using CSV
using DataFrames
using FermentationDFBA
using TOML

println("dynamic_control_objective_init: imports_ok")
flush(stdout)

println("dynamic_control_objective_init: loading_solver_helpers")
flush(stdout)
include(joinpath(@__DIR__, "solver_backend_helpers.jl"))
println("dynamic_control_objective_init: loading_ode_helpers")
flush(stdout)
include(joinpath(@__DIR__, "ode_script_helpers.jl"))
println("dynamic_control_objective_init: helper_includes_ok")
flush(stdout)

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _dynamic_control_opt_env_nonnegative_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _dynamic_control_opt_env_nonnegative_or_inf_float(
    name::AbstractString,
    default::Real,
)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    ((isfinite(value) && value >= 0.0) || value == Inf) ||
        error("Environment variable $name must be nonnegative or Inf, got: $raw_value")
    return value
end

function _dynamic_control_opt_env_unit_interval_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && 0.0 <= value <= 1.0 ||
        error("Environment variable $name must be in [0, 1], got: $raw_value")
    return value
end

function _dynamic_control_opt_env_optional_int(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _dynamic_control_opt_env_optional_positive_float(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _dynamic_control_opt_parse_float_vector(raw_value::AbstractString)::Vector{Float64}
    values = Float64[]
    for token in split(replace(raw_value, ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Could not parse Float64 token '$cleaned' from '$raw_value'.")
        isfinite(value) || error("Non-finite Float64 token '$cleaned' from '$raw_value'.")
        push!(values, value)
    end
    return values
end

function _dynamic_control_opt_volatilization_model()
    mode = Symbol(
        lowercase(
            replace(
                strip(get(ENV, "DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_MODE", "off")),
                '-' => '_',
            ),
        ),
    )
    mode in (:off, :none, :disabled) && return NoVolatilizationModel()
    gas_rate = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_RATE_H_INV",
        0.02,
    )
    reference_temperature = _script_env_float(
        "DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_REFERENCE_T_C",
        20.0,
    )
    temperature_q10 = _dynamic_control_opt_env_optional_positive_float(
        "DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_TEMPERATURE_Q10",
    )
    sugar_multiplier = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_SUGAR_MULTIPLIER_PER_G_L_H",
        0.02,
    )
    if mode in (:first_pass, :white_wine_first_pass, :aroma_stripping)
        return white_wine_first_pass_volatilization_model(
            gas_exchange_rate_h_inv = gas_rate,
            temperature_reference_C = reference_temperature,
            temperature_q10 = temperature_q10 === nothing ? 2.0 : temperature_q10,
            sugar_stripping_multiplier_per_g_L_h = sugar_multiplier,
        )
    elseif mode == :custom
        raw_coefficients = strip(
            get(
                ENV,
                "DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_COEFFICIENTS",
                "0.20,0.15,0.20,0.10,0.05,0.35",
            ),
        )
        coefficients = _dynamic_control_opt_parse_float_vector(raw_coefficients)
        return VaporLiquidVolatilizationModel(
            aroma_partition_coefficients = coefficients,
            gas_exchange_rate_h_inv = gas_rate,
            temperature_reference_C = reference_temperature,
            temperature_q10 = temperature_q10 === nothing ? 1.0 : temperature_q10,
            sugar_stripping_multiplier_per_g_L_h = sugar_multiplier,
            metadata = Dict{String, Any}("model_status" => "custom_env_configured"),
        )
    end
    error("Unsupported DFBA_DYNAMIC_CONTROL_OPT_VOLATILIZATION_MODE: $(String(mode))")
end

function _dynamic_control_candidate_schedules(
    n_temperature_values::Integer,
    n_addition_values::Integer;
    candidate_set::AbstractString = "smoke",
    max_candidates = nothing,
    horizon_h::Real,
    control_interval_h::Real,
    temperature_min_C::Real,
    temperature_max_C::Real,
)::Vector{NamedTuple}
    count = Int(n_temperature_values)
    addition_count = Int(n_addition_values)
    count > 0 || error("Temperature value count must be positive.")
    addition_count >= 0 || error("Addition value count must be nonnegative.")
    normalized_set = Symbol(lowercase(replace(strip(String(candidate_set)), '-' => '_')))
    if normalized_set in (
        :first_pass,
        :atlas,
        :white_wine_168h_atlas,
        :horizon_frontier,
        :extended_horizon_frontier,
        :drytime_frontier,
        :horizon_fda_frontier,
        :extended_horizon_fda_frontier,
        :drytime_fda_frontier,
        :horizon_fda_soft_frontier,
        :extended_horizon_fda_soft_frontier,
        :drytime_fda_soft_frontier,
    )
        profile_set = if normalized_set == :first_pass
            :white_wine_first_pass
        elseif normalized_set in (:horizon_frontier, :extended_horizon_frontier, :drytime_frontier)
            :horizon_frontier
        elseif normalized_set in (
            :horizon_fda_frontier,
            :extended_horizon_fda_frontier,
            :drytime_fda_frontier,
        )
            :horizon_fda_frontier
        elseif normalized_set in (
            :horizon_fda_soft_frontier,
            :extended_horizon_fda_soft_frontier,
            :drytime_fda_soft_frontier,
        )
            :horizon_fda_soft_frontier
        else
            :white_wine_168h_atlas
        end
        designs = dynamic_control_candidate_designs(
            horizon_h = horizon_h,
            control_interval_h = control_interval_h,
            temperature_min_C = temperature_min_C,
            temperature_max_C = temperature_max_C,
            temperature_profile_set = profile_set,
            nutrient_strategy_set = profile_set,
            max_candidates = max_candidates,
        )
        return [
            (
                candidate_id = design.candidate_id,
                profile_id = design.profile_id,
                nutrient_strategy_id = design.nutrient_strategy_id,
                temperature_values_C = design.temperature_values_C,
                fda_doses_g_L = design.fda_doses_g_L,
                organic_doses_g_L = design.organic_doses_g_L,
            ) for design in designs
        ]
    elseif normalized_set in (
        :productivity_hot,
        :hot_productivity,
        :thermal_productivity,
        :productivity_stress,
        :hot_stress,
        :stress_productivity,
        :drytime_probe,
        :drytime_probe_springferm_only,
    )
        stress_mode = normalized_set in (:productivity_stress, :hot_stress, :stress_productivity)
        drytime_probe_mode =
            normalized_set in (:drytime_probe, :drytime_probe_springferm_only)
        drytime_springferm_only_mode = normalized_set == :drytime_probe_springferm_only
        clamp_temperature(value) = min(
            max(Float64(value), Float64(temperature_min_C)),
            Float64(temperature_max_C),
        )
        flat(value) = fill(clamp_temperature(value), count)
        linear(start_value, stop_value) = count == 1 ?
            [clamp_temperature((Float64(start_value) + Float64(stop_value)) / 2)] :
            [
                clamp_temperature(
                    Float64(start_value) +
                    (Float64(stop_value) - Float64(start_value)) * (i - 1) / (count - 1),
                ) for i in 1:count
            ]
        prefix_profile(prefix_count, early_value, late_value) = vcat(
            fill(clamp_temperature(early_value), min(count, prefix_count)),
            fill(clamp_temperature(late_value), max(0, count - min(count, prefix_count))),
        )
        cool_warm_late = vcat(
            fill(clamp_temperature(18.0), min(count, 2)),
            fill(clamp_temperature(22.0), max(0, count - 4)),
            fill(clamp_temperature(24.0), max(0, min(2, count - min(count, 2)))),
        )
        length(cool_warm_late) == count || (cool_warm_late = linear(18.0, 24.0))

        springferm_early_1p0_stress_strategy = (
            nutrient_strategy_id = "springferm_early_1p0_stress",
            fda_doses_g_L = zeros(addition_count),
            organic_doses_g_L =
                addition_count == 0 ? Float64[] : vcat([1.0], zeros(addition_count - 1)),
        )
        nutrient_strategies = drytime_springferm_only_mode ? [
            springferm_early_1p0_stress_strategy,
        ] : drytime_probe_mode ? [
            (
                nutrient_strategy_id = "none",
                fda_doses_g_L = zeros(addition_count),
                organic_doses_g_L = zeros(addition_count),
            ),
            springferm_early_1p0_stress_strategy,
        ] : stress_mode ? [
            (
                nutrient_strategy_id = "none",
                fda_doses_g_L = zeros(addition_count),
                organic_doses_g_L = zeros(addition_count),
            ),
            (
                nutrient_strategy_id = "fda_early_3p0_limit",
                fda_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([3.0], zeros(addition_count - 1)),
                organic_doses_g_L = zeros(addition_count),
            ),
            (
                nutrient_strategy_id = "springferm_early_1p0_stress",
                fda_doses_g_L = zeros(addition_count),
                organic_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([1.0], zeros(addition_count - 1)),
            ),
            (
                nutrient_strategy_id = "mixed_early_fda2p0_org0p5_stress",
                fda_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([2.0], zeros(addition_count - 1)),
                organic_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([0.5], zeros(addition_count - 1)),
            ),
        ] : [
            (
                nutrient_strategy_id = "none",
                fda_doses_g_L = zeros(addition_count),
                organic_doses_g_L = zeros(addition_count),
            ),
            (
                nutrient_strategy_id = "fda_early_1p0",
                fda_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([1.0], zeros(addition_count - 1)),
                organic_doses_g_L = zeros(addition_count),
            ),
            (
                nutrient_strategy_id = "fda_early_2p0",
                fda_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([2.0], zeros(addition_count - 1)),
                organic_doses_g_L = zeros(addition_count),
            ),
            (
                nutrient_strategy_id = "springferm_early_0p2",
                fda_doses_g_L = zeros(addition_count),
                organic_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([0.2], zeros(addition_count - 1)),
            ),
            (
                nutrient_strategy_id = "springferm_early_0p4",
                fda_doses_g_L = zeros(addition_count),
                organic_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([0.4], zeros(addition_count - 1)),
            ),
            (
                nutrient_strategy_id = "mixed_early_fda0p5_org0p1",
                fda_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([0.5], zeros(addition_count - 1)),
                organic_doses_g_L =
                    addition_count == 0 ? Float64[] : vcat([0.1], zeros(addition_count - 1)),
            ),
        ]
        profiles = drytime_probe_mode ? [
            (profile_id = "flat25", temperature_values_C = flat(25.0)),
        ] : stress_mode ? [
            (profile_id = "flat25", temperature_values_C = flat(25.0)),
            (profile_id = "ramp20_to25", temperature_values_C = linear(20.0, 25.0)),
            (
                profile_id = "warm25_until72_cool18",
                temperature_values_C = prefix_profile(6, 25.0, 18.0),
            ),
        ] : [
            (profile_id = "flat22", temperature_values_C = flat(22.0)),
            (profile_id = "flat25", temperature_values_C = flat(25.0)),
            (profile_id = "ramp20_to25", temperature_values_C = linear(20.0, 25.0)),
            (
                profile_id = "warm25_until72_cool18",
                temperature_values_C = prefix_profile(6, 25.0, 18.0),
            ),
            (
                profile_id = "warm24_cool18_late",
                temperature_values_C = prefix_profile(max(1, count - 3), 24.0, 18.0),
            ),
            (profile_id = "cool18_warm24_late", temperature_values_C = cool_warm_late),
        ]
        limit = max_candidates === nothing ? typemax(Int) : Int(max_candidates)
        candidates = NamedTuple[]
        for profile in profiles
            for strategy in nutrient_strategies
                push!(
                    candidates,
                    (
                        candidate_id = "$(profile.profile_id)__$(strategy.nutrient_strategy_id)",
                        profile_id = profile.profile_id,
                        nutrient_strategy_id = strategy.nutrient_strategy_id,
                        temperature_values_C = profile.temperature_values_C,
                        fda_doses_g_L = strategy.fda_doses_g_L,
                        organic_doses_g_L = strategy.organic_doses_g_L,
                    ),
                )
                length(candidates) >= limit && return candidates
            end
        end
        return candidates
    elseif normalized_set != :smoke
        error("Unsupported DFBA_DYNAMIC_CONTROL_OPT_CANDIDATE_SET: $candidate_set")
    end

    flat20 = fill(20.0, count)
    cool_then_warm = count == 1 ? [20.0] : vcat([18.0], fill(22.0, count - 1))
    low_cool_then_warm = count == 1 ? [18.0] : vcat(fill(18.0, min(2, count)), fill(22.0, max(0, count - 2)))
    fda_early = zeros(addition_count)
    org_early = zeros(addition_count)
    mixed_early = zeros(addition_count)
    if addition_count > 0
        fda_early[1] = 1.0
        org_early[1] = 0.2
        mixed_early[1] = 0.5
    end
    mixed_org = zeros(addition_count)
    if addition_count > 0
        mixed_org[1] = 0.1
    end

    smoke_candidates = [
        (
            candidate_id = "flat20_no_addition",
            profile_id = "flat20",
            nutrient_strategy_id = "none",
            temperature_values_C = flat20,
            fda_doses_g_L = zeros(addition_count),
            organic_doses_g_L = zeros(addition_count),
        ),
        (
            candidate_id = "cool18_warm22_no_addition",
            profile_id = "cool18_warm22",
            nutrient_strategy_id = "none",
            temperature_values_C = cool_then_warm,
            fda_doses_g_L = zeros(addition_count),
            organic_doses_g_L = zeros(addition_count),
        ),
        (
            candidate_id = "cool18_warm22_fda_early",
            profile_id = "cool18_warm22",
            nutrient_strategy_id = "fda_early_1p0",
            temperature_values_C = cool_then_warm,
            fda_doses_g_L = fda_early,
            organic_doses_g_L = zeros(addition_count),
        ),
        (
            candidate_id = "cool18_warm22_springferm_early",
            profile_id = "cool18_warm22",
            nutrient_strategy_id = "springferm_early_0p2",
            temperature_values_C = cool_then_warm,
            fda_doses_g_L = zeros(addition_count),
            organic_doses_g_L = org_early,
        ),
        (
            candidate_id = "cool18_warm22_mixed_early",
            profile_id = "cool18x2_warm22",
            nutrient_strategy_id = "mixed_early_fda0p5_org0p1",
            temperature_values_C = low_cool_then_warm,
            fda_doses_g_L = mixed_early,
            organic_doses_g_L = mixed_org,
        ),
    ]
    limit = max_candidates === nothing ? length(smoke_candidates) : Int(max_candidates)
    return smoke_candidates[1:min(limit, length(smoke_candidates))]
end

function _dynamic_control_opt_row(candidate, evaluation::DynamicControlObjectiveResult)
    summary = evaluation.summary
    terms = evaluation.terms
    state_names = String.(get(evaluation.simulation.metadata, "state_names", FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES))
    final_state(name) = begin
        index = findfirst(==(String(name)), state_names)
        index === nothing ? NaN : Float64(evaluation.simulation.states[index, end])
    end
    return (
        candidate_id = String(candidate.candidate_id),
        profile_id = String(candidate.profile_id),
        nutrient_strategy_id = String(candidate.nutrient_strategy_id),
        objective_value = evaluation.objective_value,
        feasible = evaluation.feasible,
        status = evaluation.status,
        retcode = string(get(summary, "retcode", missing)),
        termination_reason = string(get(summary, "termination_reason", missing)),
        final_time = Float64(get(summary, "final_time", NaN)),
        final_glucose = Float64(get(summary, "final_glucose", NaN)),
        final_fructose = Float64(get(summary, "final_fructose", NaN)),
        final_total_sugar = Float64(get(summary, "final_total_sugar", NaN)),
        sugar_consumed = Float64(get(summary, "sugar_consumed", NaN)),
        final_ethanol = Float64(get(summary, "final_ethanol", NaN)),
        ethanol_produced = Float64(get(summary, "ethanol_produced", NaN)),
        final_nitrogen = Float64(get(summary, "final_nitrogen", NaN)),
        min_state_value = Float64(get(summary, "min_state_value", NaN)),
        rhs_call_count = Int(get(summary, "rhs_call_count", 0)),
        total_lp_solve_count = Int(get(summary, "total_lp_solve_count", 0)),
        terminal_sugar_gate_g_L = Float64(get(evaluation.metadata, "terminal_sugar_gate_g_L", NaN)),
        terminal_sugar_feasibility_mode =
            string(get(evaluation.metadata, "terminal_sugar_feasibility_mode", missing)),
        terminal_sugar_gate_pass = Bool(get(evaluation.metadata, "terminal_sugar_gate_pass", false)),
        time_to_terminal_sugar_gate_h =
            Float64(get(evaluation.metadata, "time_to_terminal_sugar_gate_h", Inf)),
        productivity_sugar_excess_auc_g_L_h =
            Float64(get(evaluation.metadata, "productivity_sugar_excess_auc_g_L_h", NaN)),
        productivity_sugar_excess_auc_normalized =
            Float64(get(evaluation.metadata, "productivity_sugar_excess_auc_normalized", NaN)),
        aroma_desirability_score = Float64(get(evaluation.metadata, "aroma_desirability_score", NaN)),
        final_phenylethanol_g_L = final_state("phenylethanol"),
        final_isoamyl_alcohol_g_L = final_state("isoamyl_alcohol"),
        final_isobutanol_g_L = final_state("isobutanol"),
        final_methionol_g_L = final_state("methionol"),
        final_tyrosol_g_L = final_state("tyrosol"),
        final_ethyl_acetate_g_L = final_state("ethyl_acetate"),
        thermal_energy_proxy_unweighted =
            Float64(get(evaluation.metadata, "thermal_energy_proxy_unweighted", NaN)),
        cooling_energy_proxy_unweighted =
            Float64(get(evaluation.metadata, "cooling_energy_proxy_unweighted", NaN)),
        residual_sugar_penalty = terms["residual_sugar_penalty"],
        productivity_sugar_excess_auc_penalty =
            terms["productivity_sugar_excess_auc_penalty"],
        fermentation_time_penalty = terms["fermentation_time_penalty"],
        ethanol_reward_term = terms["ethanol_reward"],
        aroma_desirability_penalty = terms["aroma_desirability_penalty"],
        thermal_energy_proxy_term = terms["thermal_energy_proxy"],
        cooling_energy_proxy_term = terms["cooling_energy_proxy"],
        fda_total_dose_penalty = terms["fda_total_dose_penalty"],
        organic_total_dose_penalty = terms["organic_total_dose_penalty"],
        nutrient_pulse_penalty = terms["nutrient_pulse_penalty"],
        temperature_smoothness_term = terms["temperature_smoothness"],
        temperature_move_term = terms["temperature_move"],
        negative_state_penalty = terms["negative_state_penalty"],
        incomplete_horizon_penalty = terms["incomplete_horizon_penalty"],
        failure_penalty = terms["failure_penalty"],
        fda_total_product_g_L =
            sum((event.total_product_g_L for event in evaluation.schedule.fda_events); init = 0.0),
        organic_total_product_g_L =
            sum((event.total_product_g_L for event in evaluation.schedule.organic_events); init = 0.0),
        exception_message = string(get(evaluation.metadata, "exception_message", "")),
        temperature_values_C = join(string.(evaluation.schedule.temperature_values_C), ","),
        fda_doses_g_L = join(string.(candidate.fda_doses_g_L), ","),
        organic_doses_g_L = join(string.(candidate.organic_doses_g_L), ","),
    )
end

function _dynamic_control_opt_failed_evaluation(
    candidate,
    err;
    weights::DynamicControlObjectiveWeights,
    horizon_h::Real,
    control_interval_h::Real,
    temperature_transition_width_h::Real,
    temperature_min_C::Real,
    temperature_max_C::Real,
    addition_transition_width_h::Real,
    organic_composition::OrganicNutrientComposition,
    volatilization_model,
    y0::AbstractVector,
    saveat,
    reconstruct_fluxes::Bool,
    stop_on_sugar_depletion::Bool,
    sugar_depletion_tol::Real,
)
    schedule = dynamic_control_schedule_from_values(
        candidate.temperature_values_C;
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        fda_doses_g_L = candidate.fda_doses_g_L,
        organic_doses_g_L = candidate.organic_doses_g_L,
        addition_transition_width_h = addition_transition_width_h,
        organic_composition = organic_composition,
        volatilization_model = volatilization_model,
    )
    state_vector = Float64.(y0)
    exception_message = sprint(showerror, err)
    simulation = SimulationResult(
        [0.0],
        reshape(state_vector, :, 1);
        metadata = Dict{String, Any}(
            "retcode" => "Failure",
            "termination_reason" => "exception",
            "termination_time" => 0.0,
            "state_names" => FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES,
            "min_state_value" => minimum(state_vector),
            "has_negative_saved_states" => any(state_vector .< 0.0),
            "sugar_depletion_tol" => Float64(sugar_depletion_tol),
            "simulation_elapsed_seconds" => 0.0,
            "ode_solve_elapsed_seconds" => 0.0,
            "rhs_elapsed_seconds" => 0.0,
            "rhs_call_count" => 0,
            "rhs_lp_solve_count" => 0,
            "flux_reconstruction_solve_count" => 0,
            "total_lp_solve_count" => 0,
            "reconstruct_fluxes" => reconstruct_fluxes,
            "dynamic_control_schedule_enabled" => true,
            "dynamic_control_policy" => "smooth_temperature_nutrient_schedule",
            "dynamic_control_fda_total_product_g_L" =>
                sum((event.total_product_g_L for event in schedule.fda_events); init = 0.0),
            "dynamic_control_organic_total_product_g_L" =>
                sum((event.total_product_g_L for event in schedule.organic_events); init = 0.0),
            "dynamic_control_volatilization_enabled" =>
                !(volatilization_model isa NoVolatilizationModel),
            "exception_message" => exception_message,
        ),
    )
    summary = summarize_simulation(simulation)
    terms = dynamic_control_objective_terms(
        simulation,
        summary,
        schedule;
        weights = weights,
        horizon_h = horizon_h,
    )
    objective_value = dynamic_control_objective_value(terms)
    terminal_gate_pass =
        Float64(get(summary, "final_total_sugar", Inf)) <= weights.terminal_sugar_gate_g_L + 1.0e-12
    sugar_excess_auc = dynamic_control_sugar_excess_auc(
        simulation;
        threshold_g_L = weights.terminal_sugar_gate_g_L,
    )
    metadata = Dict{String, Any}(
        "objective_value" => objective_value,
        "objective_status" => "failed_exception",
        "objective_feasible" => false,
        "exception_message" => exception_message,
        "horizon_h" => Float64(horizon_h),
        "saveat" => saveat,
        "reconstruct_fluxes" => reconstruct_fluxes,
        "stop_on_sugar_depletion" => stop_on_sugar_depletion,
        "sugar_depletion_tol" => Float64(sugar_depletion_tol),
        "terminal_sugar_gate_g_L" => weights.terminal_sugar_gate_g_L,
        "terminal_sugar_feasibility_mode" => String(weights.terminal_sugar_feasibility_mode),
        "terminal_sugar_gate_pass" => terminal_gate_pass,
        "time_to_terminal_sugar_gate_h" => Inf,
        "productivity_sugar_excess_auc_g_L_h" => sugar_excess_auc,
        "productivity_sugar_excess_auc_normalized" =>
            sugar_excess_auc / (Float64(horizon_h) * weights.productivity_sugar_excess_scale_g_L),
        "aroma_desirability_score" => aroma_desirability_score(simulation, weights.aroma_windows),
        "thermal_energy_proxy_unweighted" => dynamic_control_thermal_energy_proxy(
            schedule;
            ambient_temperature_C = weights.ambient_temperature_C,
            temperature_scale_C = weights.temperature_energy_scale_C,
        ),
        "cooling_energy_proxy_unweighted" => dynamic_control_energy_proxy(
            simulation,
            schedule;
            ambient_temperature_C = weights.ambient_temperature_C,
            fermentation_heat_weight = weights.fermentation_heat_weight,
            cold_setpoint_weight = weights.cold_setpoint_weight,
            downward_temperature_move_weight = weights.downward_temperature_move_weight,
        ),
    )
    return DynamicControlObjectiveResult(
        objective_value,
        false,
        "failed_exception",
        terms,
        Dict{String, Any}(summary),
        schedule,
        simulation,
        metadata,
    )
end

function _dynamic_control_opt_add_pareto_columns!(table::DataFrame)
    if nrow(table) == 0
        table[!, "nutrient_total_product_g_L"] = Float64[]
        table[!, "pareto_candidate"] = Bool[]
        return table
    end

    table[!, "nutrient_total_product_g_L"] =
        Float64.(table.fda_total_product_g_L) .+ Float64.(table.organic_total_product_g_L)
    pareto = trues(nrow(table))
    productivity_column = "productivity_sugar_excess_auc_normalized" in names(table) ?
        :productivity_sugar_excess_auc_normalized :
        :final_total_sugar
    energy_column = "thermal_energy_proxy_unweighted" in names(table) ?
        :thermal_energy_proxy_unweighted :
        :cooling_energy_proxy_unweighted
    metrics = [
        productivity_column,
        :negative_aroma_desirability_score,
        energy_column,
        :nutrient_total_product_g_L,
    ]
    table[!, "negative_aroma_desirability_score"] =
        -Float64.(table.aroma_desirability_score)

    for i in 1:nrow(table)
        if !Bool(table.feasible[i])
            pareto[i] = false
            continue
        end
        for j in 1:nrow(table)
            i == j && continue
            Bool(table.feasible[j]) || continue
            all(Float64(table[j, metric]) <= Float64(table[i, metric]) + 1.0e-12 for metric in metrics) ||
                continue
            any(Float64(table[j, metric]) < Float64(table[i, metric]) - 1.0e-12 for metric in metrics) ||
                continue
            pareto[i] = false
            break
        end
    end
    table[!, "pareto_candidate"] = pareto
    return table
end

function _dynamic_control_opt_safe_path_id(value::AbstractString)::String
    cleaned = replace(strip(String(value)), r"[^A-Za-z0-9_.-]" => "_")
    return isempty(cleaned) ? "candidate" : cleaned
end

function _dynamic_control_opt_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _dynamic_control_opt_toml_normalize_real(value)
    elseif value isa Tuple
        return _dynamic_control_opt_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _dynamic_control_opt_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _dynamic_control_opt_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _dynamic_control_opt_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _dynamic_control_opt_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _dynamic_control_opt_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end

println("dynamic_control_objective_init: loading_reduced_model")
flush(stdout)
model = load_reduced_model(paths_config)
println("dynamic_control_objective_init: loading_reaction_map")
flush(stdout)
reaction_map = load_reaction_map(reaction_map_config)
println("dynamic_control_objective_init: validating_reaction_map")
flush(stdout)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)
println("dynamic_control_objective_init: reaction_map_ok")
flush(stdout)

horizon_h = _script_env_float("DFBA_DYNAMIC_CONTROL_OPT_HORIZON_HOURS", 48.0)
control_interval_h = _script_env_float("DFBA_DYNAMIC_CONTROL_OPT_INTERVAL_HOURS", 12.0)
temperature_transition_width_h =
    _script_env_float("DFBA_DYNAMIC_CONTROL_OPT_TEMPERATURE_WIDTH_HOURS", 1.0)
addition_transition_width_h =
    _script_env_float("DFBA_DYNAMIC_CONTROL_OPT_ADDITION_WIDTH_HOURS", 0.5)
temperature_min_C = _script_env_float("DFBA_DYNAMIC_CONTROL_OPT_T_MIN_C", 15.0)
temperature_max_C = _script_env_float("DFBA_DYNAMIC_CONTROL_OPT_T_MAX_C", 25.0)
saveat = _script_env_float("DFBA_DYNAMIC_CONTROL_OPT_SAVEAT_HOURS", 1.0)
reconstruct_fluxes = _script_env_bool("DFBA_DYNAMIC_CONTROL_OPT_RECONSTRUCT_FLUXES", false)
overwrite = _script_env_bool("DFBA_DYNAMIC_CONTROL_OPT_EXPORT_OVERWRITE", true)
stop_on_sugar_depletion =
    _script_env_bool("DFBA_DYNAMIC_CONTROL_OPT_STOP_ON_SUGAR_DEPLETION", true)
sugar_depletion_tol = _dynamic_control_opt_env_nonnegative_float(
    "DFBA_DYNAMIC_CONTROL_OPT_SUGAR_DEPLETION_TOL",
    1.0e-6,
)
phase_proxy_mode =
    strip(get(ENV, "DFBA_DYNAMIC_CONTROL_OPT_PHASE_PROXY_MODE", "total_molecular_weight"))
turnover_threshold = _script_env_float("DFBA_DYNAMIC_CONTROL_OPT_TURNOVER_THRESHOLD", 0.001)
progress_interval_seconds = _dynamic_control_opt_env_nonnegative_float(
    "DFBA_DYNAMIC_CONTROL_OPT_PROGRESS_INTERVAL_SECONDS",
    0.0,
)
max_rhs_calls = _dynamic_control_opt_env_optional_int("DFBA_DYNAMIC_CONTROL_OPT_MAX_RHS_CALLS")
max_walltime_seconds =
    _dynamic_control_opt_env_optional_positive_float("DFBA_DYNAMIC_CONTROL_OPT_MAX_WALLTIME_SECONDS")
candidate_set = strip(get(ENV, "DFBA_DYNAMIC_CONTROL_OPT_CANDIDATE_SET", "smoke"))
max_candidates = _dynamic_control_opt_env_optional_int("DFBA_DYNAMIC_CONTROL_OPT_MAX_CANDIDATES")
selection_count =
    _dynamic_control_opt_env_optional_int("DFBA_DYNAMIC_CONTROL_OPT_SELECTION_COUNT")
selection_criteria = DynamicControlSelectionCriteria(
    final_total_sugar_max_g_L = _dynamic_control_opt_env_nonnegative_or_inf_float(
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_FINAL_SUGAR_MAX_G_L",
        5.0,
    ),
    aroma_desirability_min_score = _dynamic_control_opt_env_unit_interval_float(
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MIN_AROMA_SCORE",
        0.0,
    ),
    cooling_energy_proxy_max = _dynamic_control_opt_env_nonnegative_or_inf_float(
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MAX_ENERGY_PROXY",
        Inf,
    ),
    nutrient_total_product_max_g_L = _dynamic_control_opt_env_nonnegative_or_inf_float(
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MAX_NUTRIENT_G_L",
        Inf,
    ),
    max_negative_state_deficit = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_SELECTION_MAX_NEGATIVE_STATE_DEFICIT",
        1.0e-8,
    ),
    shortlist_count = selection_count === nothing ? 5 : selection_count,
    prefer_pareto = _script_env_bool("DFBA_DYNAMIC_CONTROL_OPT_SELECTION_PREFER_PARETO", true),
    require_feasible = _script_env_bool("DFBA_DYNAMIC_CONTROL_OPT_SELECTION_REQUIRE_FEASIBLE", true),
)
write_plots = _script_env_bool("DFBA_DYNAMIC_CONTROL_OPT_WRITE_PLOTS", true)
write_partial_csv = _script_env_bool("DFBA_DYNAMIC_CONTROL_OPT_WRITE_PARTIAL_CSV", true)
plot_candidate_count = _dynamic_control_opt_env_optional_int(
    "DFBA_DYNAMIC_CONTROL_OPT_PLOT_CANDIDATE_COUNT",
)
algorithm_config = _script_ode_algorithm_config("DFBA_DYNAMIC_CONTROL_OPT_ALGORITHM")
optimizer_backend, solver_label =
    _resolve_solver_backend(get(ENV, "DFBA_DYNAMIC_CONTROL_OPT_SOLVER_BACKEND", "HiGHS"))
tolerance_config = (
    ode_abstol = _script_env_float(
        "DFBA_DYNAMIC_CONTROL_OPT_ODE_ABSTOL",
        DEFAULT_SCRIPT_ODE_ABSTOL,
    ),
    ode_reltol = _script_env_float(
        "DFBA_DYNAMIC_CONTROL_OPT_ODE_RELTOL",
        DEFAULT_SCRIPT_ODE_RELTOL,
    ),
    lp_atol = _script_env_float("DFBA_DYNAMIC_CONTROL_OPT_LP_ATOL", DEFAULT_SCRIPT_LP_ATOL),
)
weights = DynamicControlObjectiveWeights(
    residual_sugar_target_g_L = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_RESIDUAL_SUGAR_TARGET_G_L",
        5.0,
    ),
    residual_sugar_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_RESIDUAL_SUGAR_WEIGHT",
        0.0,
    ),
    terminal_sugar_gate_g_L = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_TERMINAL_SUGAR_GATE_G_L",
        5.0,
    ),
    terminal_sugar_feasibility_mode =
        strip(get(ENV, "DFBA_DYNAMIC_CONTROL_OPT_TERMINAL_SUGAR_FEASIBILITY_MODE", "strict_dryness")),
    productivity_sugar_excess_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_PRODUCTIVITY_SUGAR_EXCESS_WEIGHT",
        1.0,
    ),
    productivity_sugar_excess_scale_g_L = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_PRODUCTIVITY_SUGAR_EXCESS_SCALE_G_L",
        150.0,
    ),
    fermentation_time_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_FERMENTATION_TIME_WEIGHT",
        0.0,
    ),
    ethanol_reward_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_ETHANOL_REWARD_WEIGHT",
        0.0,
    ),
    aroma_desirability_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_AROMA_DESIRABILITY_WEIGHT",
        10.0,
    ),
    cooling_energy_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_COOLING_ENERGY_WEIGHT",
        0.0,
    ),
    thermal_energy_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_THERMAL_ENERGY_WEIGHT",
        0.1,
    ),
    temperature_energy_scale_C = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_TEMPERATURE_ENERGY_SCALE_C",
        5.0,
    ),
    fda_total_dose_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_FDA_TOTAL_DOSE_WEIGHT",
        0.5,
    ),
    organic_total_dose_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_ORG_TOTAL_DOSE_WEIGHT",
        0.5,
    ),
    nutrient_pulse_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_NUTRIENT_PULSE_WEIGHT",
        0.1,
    ),
    temperature_smoothness_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_TEMPERATURE_SMOOTHNESS_WEIGHT",
        0.0,
    ),
    negative_state_tolerance = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_NEGATIVE_STATE_TOL",
        1.0e-9,
    ),
    negative_state_penalty_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_NEGATIVE_STATE_PENALTY_WEIGHT",
        1.0e8,
    ),
    incomplete_horizon_penalty_weight = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_INCOMPLETE_HORIZON_PENALTY_WEIGHT",
        1.0e6,
    ),
    failure_penalty = _dynamic_control_opt_env_nonnegative_float(
        "DFBA_DYNAMIC_CONTROL_OPT_FAILURE_PENALTY",
        1.0e9,
    ),
)

println("dynamic_control_objective_init: building_parameters")
flush(stdout)
params = default_zenteno_parameters(
    phase_proxy_mode = phase_proxy_mode,
    TURNOVER_THRESHOLD = turnover_threshold,
)
initial_state_config = _script_initial_state_config(params)
temperature_value_count = dynamic_temperature_control_value_count(
    horizon_h = horizon_h,
    control_interval_h = control_interval_h,
)
addition_value_count = length(collect(control_interval_h:control_interval_h:(horizon_h - 1.0e-9)))
println(
    "dynamic_control_objective_init: building_candidates " *
    "temperature_value_count=$(temperature_value_count) " *
    "addition_value_count=$(addition_value_count) candidate_set=$(candidate_set)",
)
flush(stdout)
candidates = _dynamic_control_candidate_schedules(
    temperature_value_count,
    addition_value_count;
    candidate_set = candidate_set,
    max_candidates = max_candidates,
    horizon_h = horizon_h,
    control_interval_h = control_interval_h,
    temperature_min_C = temperature_min_C,
    temperature_max_C = temperature_max_C,
)
println("dynamic_control_objective_init: candidate_count=$(length(candidates))")
flush(stdout)
organic_composition = springferm_xtrem_organic_composition()
volatilization_model = _dynamic_control_opt_volatilization_model()
output_dir = _script_output_dir(
    project_root,
    "DFBA_DYNAMIC_CONTROL_OPT_OUTPUT_DIR",
    joinpath("results", "dynamic_control_objective_smoke_latest"),
)
mkpath(output_dir)
candidate_path = joinpath(output_dir, "dynamic_control_objective_candidates.csv")
partial_candidate_path =
    joinpath(output_dir, "dynamic_control_objective_candidates_partial.csv")
shortlist_path = joinpath(output_dir, "dynamic_control_objective_shortlist.csv")
metadata_path = joinpath(output_dir, "dynamic_control_objective_metadata.toml")
if !overwrite
    target_paths = (candidate_path, partial_candidate_path, shortlist_path, metadata_path)
    existing_targets = [path for path in target_paths if isfile(path)]
    isempty(existing_targets) || error(
        "Dynamic control objective target file(s) already exist and overwrite=false: " *
        join(sort(existing_targets), ", "),
    )
end

rows = NamedTuple[]
evaluations = Dict{String, DynamicControlObjectiveResult}()
start_time = time()
for (candidate_index, candidate) in enumerate(candidates)
    println(
        "dynamic_control_objective_candidate_start: $(candidate.candidate_id) " *
        "candidate_number=$(candidate_index) of $(length(candidates))",
    )
    flush(stdout)
    common_kwargs = (
        weights = weights,
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        fda_doses_g_L = candidate.fda_doses_g_L,
        organic_doses_g_L = candidate.organic_doses_g_L,
        addition_transition_width_h = addition_transition_width_h,
        organic_composition = organic_composition,
        volatilization_model = volatilization_model,
        y0 = initial_state_config.y0,
        params = params,
        lp_atol = tolerance_config.lp_atol,
        ode_abstol = tolerance_config.ode_abstol,
        ode_reltol = tolerance_config.ode_reltol,
        saveat = saveat,
        algorithm = algorithm_config.algorithm,
        reconstruct_fluxes = reconstruct_fluxes,
        stop_on_sugar_depletion = stop_on_sugar_depletion,
        sugar_depletion_tol = sugar_depletion_tol,
        progress_interval_seconds = progress_interval_seconds,
        max_rhs_calls = max_rhs_calls,
        max_walltime_seconds = max_walltime_seconds,
    )
    evaluation = try
        optimizer_backend === nothing ?
        evaluate_dynamic_control_objective(
            model,
            reaction_map,
            candidate.temperature_values_C;
            common_kwargs...,
        ) :
        evaluate_dynamic_control_objective(
            model,
            reaction_map,
            candidate.temperature_values_C;
            optimizer = optimizer_backend,
            common_kwargs...,
        )
    catch err
        message = sprint(showerror, err)
        println(
            "dynamic_control_objective_candidate_failed: $(candidate.candidate_id) " *
            "status=exception error=$(message)",
        )
        flush(stdout)
        _dynamic_control_opt_failed_evaluation(
            candidate,
            err;
            weights = weights,
            horizon_h = horizon_h,
            control_interval_h = control_interval_h,
            temperature_transition_width_h = temperature_transition_width_h,
            temperature_min_C = temperature_min_C,
            temperature_max_C = temperature_max_C,
            addition_transition_width_h = addition_transition_width_h,
            organic_composition = organic_composition,
            volatilization_model = volatilization_model,
            y0 = initial_state_config.y0,
            saveat = saveat,
            reconstruct_fluxes = reconstruct_fluxes,
            stop_on_sugar_depletion = stop_on_sugar_depletion,
            sugar_depletion_tol = sugar_depletion_tol,
        )
    end
    evaluations[String(candidate.candidate_id)] = evaluation
    push!(rows, _dynamic_control_opt_row(candidate, evaluation))
    if write_partial_csv
        CSV.write(partial_candidate_path, DataFrame(rows))
    end
    final_sugar_for_log = get(evaluation.summary, "final_total_sugar", missing)
    println(
        "dynamic_control_objective_candidate_done: $(candidate.candidate_id) " *
        "objective=$(evaluation.objective_value) feasible=$(evaluation.feasible) " *
        "final_sugar=$(final_sugar_for_log)",
    )
    flush(stdout)
end
elapsed_seconds = time() - start_time

candidate_table = DataFrame(rows)
_dynamic_control_opt_add_pareto_columns!(candidate_table)
dynamic_control_apply_selection_gates!(candidate_table; criteria = selection_criteria)
scalar_best_index = nrow(candidate_table) == 0 ? nothing :
    argmin(Float64.(candidate_table.objective_value))
scalar_best_row = scalar_best_index === nothing ? nothing : copy(candidate_table[scalar_best_index, :])
sort!(
    candidate_table,
    [:selected_for_review, :gate_pass, :feasible, :pareto_candidate, :objective_value],
    rev = [true, true, true, true, false],
)
CSV.write(candidate_path, candidate_table)
shortlist_table = candidate_table[candidate_table.selected_for_review .== true, :]
CSV.write(shortlist_path, shortlist_table)

plot_paths = Dict{String, Any}()
if write_plots
    plot_root = joinpath(output_dir, "plots")
    plot_paths["pareto"] = write_dynamic_control_pareto_plots(
        candidate_table,
        joinpath(plot_root, "pareto");
        overwrite = overwrite,
    )
    selected_ids = String.(shortlist_table.candidate_id)
    max_plot_count = plot_candidate_count === nothing ?
        length(selected_ids) :
        min(Int(plot_candidate_count), length(selected_ids))
    candidate_plot_paths = Dict{String, Any}()
    for candidate_id in selected_ids[1:max_plot_count]
        haskey(evaluations, candidate_id) || continue
        candidate_plot_paths[candidate_id] = write_dynamic_control_candidate_plots(
            evaluations[candidate_id],
            joinpath(plot_root, "candidates", _dynamic_control_opt_safe_path_id(candidate_id));
            candidate_id = candidate_id,
            horizon_h = horizon_h,
            overwrite = overwrite,
        )
    end
    plot_paths["candidates"] = candidate_plot_paths
end

best_row = scalar_best_row
pareto_candidate_ids = nrow(candidate_table) == 0 ? String[] :
    String.(candidate_table[candidate_table.pareto_candidate .== true, :candidate_id])
shortlist_candidate_ids = nrow(shortlist_table) == 0 ? String[] : String.(shortlist_table.candidate_id)
metadata = Dict{String, Any}(
    "script" => "main_dynamic_control_objective_smoke.jl",
    "objective_type" => DYNAMIC_CONTROL_OBJECTIVE_TYPE,
    "solver_label" => solver_label,
    "algorithm_label" => algorithm_config.algorithm_label,
    "horizon_h" => horizon_h,
    "control_interval_h" => control_interval_h,
    "temperature_value_count" => temperature_value_count,
    "addition_value_count" => addition_value_count,
    "temperature_transition_width_h" => temperature_transition_width_h,
    "addition_transition_width_h" => addition_transition_width_h,
    "temperature_min_C" => temperature_min_C,
    "temperature_max_C" => temperature_max_C,
    "candidate_count" => length(candidates),
    "candidate_set" => candidate_set,
    "max_candidates" => max_candidates,
    "candidate_ids" => [candidate.candidate_id for candidate in candidates],
    "profile_ids" => unique([candidate.profile_id for candidate in candidates]),
    "nutrient_strategy_ids" => unique([candidate.nutrient_strategy_id for candidate in candidates]),
    "pareto_candidate_ids" => pareto_candidate_ids,
    "shortlist_candidate_ids" => shortlist_candidate_ids,
    "gate_pass_count" => nrow(candidate_table) == 0 ? 0 : count(Bool, candidate_table.gate_pass),
    "selected_for_review_count" => nrow(shortlist_table),
    "output_dir" => output_dir,
    "candidate_table" => candidate_path,
    "partial_candidate_table" => partial_candidate_path,
    "shortlist_table" => shortlist_path,
    "write_plots" => write_plots,
    "write_partial_csv" => write_partial_csv,
    "plot_candidate_count" => plot_candidate_count,
    "plot_paths" => plot_paths,
    "elapsed_seconds" => elapsed_seconds,
    "saveat" => saveat,
    "reconstruct_fluxes" => reconstruct_fluxes,
    "stop_on_sugar_depletion" => stop_on_sugar_depletion,
    "sugar_depletion_tol" => sugar_depletion_tol,
    "phase_proxy_mode" => phase_proxy_mode,
    "turnover_threshold" => turnover_threshold,
    "ode_abstol" => tolerance_config.ode_abstol,
    "ode_reltol" => tolerance_config.ode_reltol,
    "lp_atol" => tolerance_config.lp_atol,
    "progress_interval_seconds" => progress_interval_seconds,
    "max_rhs_calls" => max_rhs_calls,
    "max_walltime_seconds" => max_walltime_seconds,
    "fda_product_basis" => "FDA solution 10% w/w",
    "fda_solution_nitrogen_fraction_gN_per_g" => FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G,
    "fda_solution_oiv_equivalent_limit_g_L" => FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L,
    "organic_product_basis" => organic_composition.metadata,
    "volatilization_enabled" => !(volatilization_model isa NoVolatilizationModel),
    "terminal_sugar_feasibility_mode" => String(weights.terminal_sugar_feasibility_mode),
    "volatilization_model" =>
        volatilization_model isa NoVolatilizationModel ?
        Dict{String, Any}("mode" => "off") :
        Dict{String, Any}(
            "mode" => "enabled",
            "gas_exchange_rate_h_inv" => volatilization_model.gas_exchange_rate_h_inv,
            "aroma_partition_coefficients" =>
                volatilization_model.aroma_partition_coefficients,
            "temperature_reference_C" => volatilization_model.temperature_reference_C,
            "temperature_q10" => volatilization_model.temperature_q10,
            "sugar_stripping_multiplier_per_g_L_h" =>
                volatilization_model.sugar_stripping_multiplier_per_g_L_h,
            "metadata" => volatilization_model.metadata,
        ),
    "initial_conditions" => initial_state_config.metadata,
    "selection_criteria" => Dict{String, Any}(
        "final_total_sugar_max_g_L" => selection_criteria.final_total_sugar_max_g_L,
        "aroma_desirability_min_score" => selection_criteria.aroma_desirability_min_score,
        "cooling_energy_proxy_max" => selection_criteria.cooling_energy_proxy_max,
        "nutrient_total_product_max_g_L" =>
            selection_criteria.nutrient_total_product_max_g_L,
        "max_negative_state_deficit" => selection_criteria.max_negative_state_deficit,
        "shortlist_count" => selection_criteria.shortlist_count,
        "prefer_pareto" => selection_criteria.prefer_pareto,
        "require_feasible" => selection_criteria.require_feasible,
    ),
)
if best_row !== nothing
    metadata["best_candidate_id"] = best_row.candidate_id
    metadata["best_objective_value"] = best_row.objective_value
    metadata["best_feasible"] = best_row.feasible
    metadata["best_temperature_values_C"] = best_row.temperature_values_C
    metadata["best_fda_doses_g_L"] = best_row.fda_doses_g_L
    metadata["best_organic_doses_g_L"] = best_row.organic_doses_g_L
end
open(metadata_path, "w") do io
    TOML.print(io, _dynamic_control_opt_toml_normalize(metadata))
end

println("Dynamic control objective smoke")
println("output_dir: $output_dir")
println("candidate_csv: $candidate_path")
println("partial_candidate_csv: $partial_candidate_path")
println("shortlist_csv: $shortlist_path")
println("metadata_toml: $metadata_path")
println("solver_label: $solver_label")
println("algorithm_label: $(algorithm_config.algorithm_label)")
println("horizon_h: $horizon_h")
println("control_interval_h: $control_interval_h")
println("candidate_set: $candidate_set")
println("candidate_count: $(length(candidates))")
println("gate_pass_count: $(metadata["gate_pass_count"])")
println("selected_for_review_count: $(metadata["selected_for_review_count"])")
println("shortlist_candidate_ids: $(join(shortlist_candidate_ids, ","))")
println("write_plots: $write_plots")
println("volatilization_enabled: $(!(volatilization_model isa NoVolatilizationModel))")
println("terminal_sugar_feasibility_mode: $(weights.terminal_sugar_feasibility_mode)")
println("elapsed_seconds: $elapsed_seconds")
if best_row !== nothing
    println("best_candidate_id: $(best_row.candidate_id)")
    println("best_objective_value: $(best_row.objective_value)")
    println("best_feasible: $(best_row.feasible)")
    println("best_final_total_sugar: $(best_row.final_total_sugar)")
    println("best_terminal_sugar_gate_pass: $(best_row.terminal_sugar_gate_pass)")
    println("best_time_to_terminal_sugar_gate_h: $(best_row.time_to_terminal_sugar_gate_h)")
    println("best_productivity_sugar_excess_auc_normalized: $(best_row.productivity_sugar_excess_auc_normalized)")
    println("best_sugar_consumed: $(best_row.sugar_consumed)")
    println("best_aroma_desirability_score: $(best_row.aroma_desirability_score)")
    println("best_thermal_energy_proxy_unweighted: $(best_row.thermal_energy_proxy_unweighted)")
    println("best_cooling_energy_proxy_unweighted: $(best_row.cooling_energy_proxy_unweighted)")
    println("best_temperature_values_C: $(best_row.temperature_values_C)")
    println("best_fda_doses_g_L: $(best_row.fda_doses_g_L)")
    println("best_organic_doses_g_L: $(best_row.organic_doses_g_L)")
end
