param(
    [string]$Repo = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path,
    [string]$Root = "C:\mpcc_runs",
    [string]$LinearSolver = "ma97",
    [string]$HslLib = "C:\Users\ctorrealba\CoinHSL.v2023\bin\libhsl.dll",
    [switch]$TailFromInitial,
    [string]$InitialPrefixCandidatePath = "",
    [string]$TailArtifactDir = "logs\mpcc_72h_2h4nfe_coarse_dense_seed_20260519_221645\artifacts",
    [string]$StartAtLabel = "",
    [string]$ResidualMaxRhs = "1e-6",
    [string]$TrustRegionStates = "core",
    [string]$TrustRegionRelDelta = "0.01",
    [string]$TrustRegionWeight = "1000.0",
    [string]$ObjectiveStateWeight = "1.0",
    [string]$ObjectiveBiomassWeight = "0.0",
    [string]$ObjectiveBiomassTerminalWeight = "0.0",
    [switch]$DisablePrefixHandoff,
    [switch]$ContinueAfterFailedRun,
    [switch]$EnableFeasibilityProbe,
    [int]$ProbeMaxIter = 70,
    [string]$ProbeWall = "1800",
    [double]$ProbeStructuralRatioStop = 5.0
)

$ErrorActionPreference = "Continue"
Set-Location $Repo

$env:OMP_NUM_THREADS = "1"
$env:OPENBLAS_NUM_THREADS = "1"
$env:MKL_NUM_THREADS = "1"
$env:JULIA_NUM_THREADS = "1"

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$sequenceRoot = Join-Path $Root "global_trust_seqref_tight_sequence_$stamp"
New-Item -ItemType Directory -Force -Path $sequenceRoot | Out-Null

$statusPath = Join-Path $sequenceRoot "sequence_status.txt"
$summaryPath = Join-Path $sequenceRoot "sequence_summary.csv"

"timestamp,phase,hours,artifact_dir,prefix_candidate_path,run_root,out,log,exit_code,pre_solve_guard_passed,solver_status,primal_status,candidate_residual_feasible,candidate_trajectory_ready,max_rhs,max_collocation,max_continuity,max_initial_condition,max_mass,max_stationarity,max_comp_l,max_comp_u,max_state_relative_rmse,final_total_sugar_difference,structural_ratio,recommended_next_action" |
    Set-Content -Path $summaryPath -Encoding UTF8

function Write-SeqStatus {
    param([string]$Message)

    $line = "$(Get-Date -Format o) | $Message"
    Add-Content -Path $statusPath -Value $line -Encoding UTF8
    Write-Host $line
}

function Get-LastLogValue {
    param(
        [string[]]$Lines,
        [string]$Key
    )

    $prefix = "${Key}:"
    $match = $Lines | Where-Object { $_ -like "$prefix*" } | Select-Object -Last 1
    if ($null -eq $match) {
        return "missing"
    }
    return (($match -replace "^$([regex]::Escape($prefix))\s*", "").Trim())
}

function Convert-LogDouble {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value) -or $Value -eq "missing") {
        return $null
    }
    $parsed = 0.0
    if ([double]::TryParse(
            $Value,
            [System.Globalization.NumberStyles]::Float,
            [System.Globalization.CultureInfo]::InvariantCulture,
            [ref]$parsed
        )) {
        return $parsed
    }
    return $null
}

function Get-StructuralRatio {
    param(
        [string[]]$Lines,
        [double]$Threshold
    )

    if ($Threshold -le 0.0) {
        return $null
    }
    $values = @(
        Convert-LogDouble (Get-LastLogValue $Lines "max_collocation_integration_residual"),
        Convert-LogDouble (Get-LastLogValue $Lines "max_continuity_residual"),
        Convert-LogDouble (Get-LastLogValue $Lines "max_initial_condition_residual")
    ) | Where-Object { $null -ne $_ }
    if ($values.Count -eq 0) {
        return $null
    }
    return (($values | Measure-Object -Maximum).Maximum / $Threshold)
}

function Add-SeqSummary {
    param(
        [string]$Phase,
        [object]$Run,
        [string]$PrefixCandidatePath,
        [string]$RunRoot,
        [string]$Out,
        [string]$Log,
        [int]$ExitCode
    )

    $lines = if (Test-Path $Log) { Get-Content $Log } else { @() }
    $maxCollocation = Get-LastLogValue $lines "max_collocation_integration_residual"
    $maxContinuity = Get-LastLogValue $lines "max_continuity_residual"
    $maxInitialCondition = Get-LastLogValue $lines "max_initial_condition_residual"
    $residualRhsThreshold = [double]::Parse(
        $ResidualMaxRhs,
        [System.Globalization.NumberStyles]::Float,
        [System.Globalization.CultureInfo]::InvariantCulture
    )
    $structuralValues = @(
        (Convert-LogDouble $maxCollocation),
        (Convert-LogDouble $maxContinuity),
        (Convert-LogDouble $maxInitialCondition)
    ) | Where-Object { $null -ne $_ }
    $structuralRatio = $null
    if ($residualRhsThreshold -gt 0.0 -and $structuralValues.Count -gt 0) {
        $structuralRatio =
            (($structuralValues | Measure-Object -Maximum).Maximum / $residualRhsThreshold)
    }
    $summary = [pscustomobject]@{
        Lines = $lines
        PreSolveGuard = Get-LastLogValue $lines "pre_solve_guard_passed"
        Solver = Get-LastLogValue $lines "solver_status"
        Primal = Get-LastLogValue $lines "primal_status"
        Residual = Get-LastLogValue $lines "candidate_residual_feasible"
        Trajectory = Get-LastLogValue $lines "candidate_trajectory_ready"
        MaxRhs = Get-LastLogValue $lines "max_rhs_residual"
        MaxCollocation = $maxCollocation
        MaxContinuity = $maxContinuity
        MaxInitialCondition = $maxInitialCondition
        MaxMass = Get-LastLogValue $lines "max_mass_balance_residual"
        MaxStationarity = Get-LastLogValue $lines "max_stationarity_residual"
        MaxCompL = Get-LastLogValue $lines "max_lower_complementarity_residual"
        MaxCompU = Get-LastLogValue $lines "max_upper_complementarity_residual"
        StateRmse = Get-LastLogValue $lines "max_state_relative_rmse"
        FinalSugar = Get-LastLogValue $lines "final_total_sugar_difference"
        StructuralRatio = if ($null -eq $structuralRatio) { "missing" } else { $structuralRatio.ToString("G17", [System.Globalization.CultureInfo]::InvariantCulture) }
        Next = Get-LastLogValue $lines "recommended_next_action"
    }

    $row = @(
        (Get-Date -Format o), $Phase, $Run.Hours, $Run.ArtifactDir, $PrefixCandidatePath, $RunRoot, $Out, $Log, $ExitCode,
        $summary.PreSolveGuard,
        $summary.Solver, $summary.Primal, $summary.Residual, $summary.Trajectory,
        $summary.MaxRhs, $summary.MaxCollocation, $summary.MaxContinuity, $summary.MaxInitialCondition,
        $summary.MaxMass, $summary.MaxStationarity, $summary.MaxCompL, $summary.MaxCompU,
        $summary.StateRmse, $summary.FinalSugar, $summary.StructuralRatio, $summary.Next
    ) | ForEach-Object { '"' + (($_ -as [string]) -replace '"', '""') + '"' }
    Add-Content -Path $summaryPath -Value ($row -join ',') -Encoding UTF8
    return $summary
}

$runs = @(
    [pscustomobject]@{
        Label = "g16_from_g12"
        Hours = "16.0"
        Windows = "8"
        MaxIter = "2400"
        Wall = "7200"
        ArtifactDir = "logs\mpcc_24h_2h4nfe_coarse_ma97_seed_20260521_082748\artifacts"
        PrefixCandidatePath = "C:\mpcc_runs\g12_trust_seqref_tight_20260522_225735\a\global_candidate_values\global_candidate_values.jls"
    },
    [pscustomobject]@{
        Label = "g20_from_g16"
        Hours = "20.0"
        Windows = "10"
        MaxIter = "3000"
        Wall = "9000"
        ArtifactDir = "logs\mpcc_24h_2h4nfe_coarse_ma97_seed_20260521_082748\artifacts"
        PrefixCandidatePath = ""
    },
    [pscustomobject]@{
        Label = "g24_from_g20"
        Hours = "24.0"
        Windows = "12"
        MaxIter = "3600"
        Wall = "10800"
        ArtifactDir = "logs\mpcc_24h_2h4nfe_coarse_ma97_seed_20260521_082748\artifacts"
        PrefixCandidatePath = ""
    },
    [pscustomobject]@{
        Label = "g36_from_g24"
        Hours = "36.0"
        Windows = "18"
        MaxIter = "4200"
        Wall = "14400"
        ArtifactDir = "logs\mpcc_72h_2h4nfe_coarse_dense_seed_20260519_221645\artifacts"
        PrefixCandidatePath = ""
    },
    [pscustomobject]@{
        Label = "g48_from_g36"
        Hours = "48.0"
        Windows = "24"
        MaxIter = "5400"
        Wall = "21600"
        ArtifactDir = "logs\mpcc_72h_2h4nfe_coarse_dense_seed_20260519_221645\artifacts"
        PrefixCandidatePath = ""
    },
    [pscustomobject]@{
        Label = "g60_from_g48"
        Hours = "60.0"
        Windows = "30"
        MaxIter = "6400"
        Wall = "28800"
        ArtifactDir = "logs\mpcc_72h_2h4nfe_coarse_dense_seed_20260519_221645\artifacts"
        PrefixCandidatePath = ""
    },
    [pscustomobject]@{
        Label = "g72_from_g60"
        Hours = "72.0"
        Windows = "36"
        MaxIter = "7200"
        Wall = "43200"
        ArtifactDir = "logs\mpcc_72h_2h4nfe_coarse_dense_seed_20260519_221645\artifacts"
        PrefixCandidatePath = ""
    }
)

if ($TailFromInitial) {
    $runs = @(
        [pscustomobject]@{
            Label = "g52_from_initial"
            Hours = "52.0"
            Windows = "26"
            MaxIter = "1350"
            Wall = "14400"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = $InitialPrefixCandidatePath
        },
        [pscustomobject]@{
            Label = "g54_from_g52"
            Hours = "54.0"
            Windows = "27"
            MaxIter = "1450"
            Wall = "14400"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        },
        [pscustomobject]@{
            Label = "g56_from_g54"
            Hours = "56.0"
            Windows = "28"
            MaxIter = "1600"
            Wall = "18000"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        },
        [pscustomobject]@{
            Label = "g58_from_g56"
            Hours = "58.0"
            Windows = "29"
            MaxIter = "1700"
            Wall = "19800"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        },
        [pscustomobject]@{
            Label = "g60_from_g58"
            Hours = "60.0"
            Windows = "30"
            MaxIter = "1800"
            Wall = "21600"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        },
        [pscustomobject]@{
            Label = "g62_from_g60"
            Hours = "62.0"
            Windows = "31"
            MaxIter = "1900"
            Wall = "23400"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        },
        [pscustomobject]@{
            Label = "g64_from_g62"
            Hours = "64.0"
            Windows = "32"
            MaxIter = "2000"
            Wall = "25200"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        },
        [pscustomobject]@{
            Label = "g66_from_g64"
            Hours = "66.0"
            Windows = "33"
            MaxIter = "2100"
            Wall = "27000"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        },
        [pscustomobject]@{
            Label = "g68_from_g66"
            Hours = "68.0"
            Windows = "34"
            MaxIter = "2200"
            Wall = "28800"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        },
        [pscustomobject]@{
            Label = "g70_from_g68"
            Hours = "70.0"
            Windows = "35"
            MaxIter = "2300"
            Wall = "36000"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        },
        [pscustomobject]@{
            Label = "g72_from_g70"
            Hours = "72.0"
            Windows = "36"
            MaxIter = "2400"
            Wall = "43200"
            ArtifactDir = $TailArtifactDir
            PrefixCandidatePath = ""
        }
    )
}

Write-SeqStatus "sequence_start root=$sequenceRoot"
if (![string]::IsNullOrWhiteSpace($StartAtLabel)) {
    $filteredRuns = @()
    $seenStart = $false
    foreach ($run in $runs) {
        if ($run.Label -eq $StartAtLabel) {
            $seenStart = $true
        }
        if ($seenStart) {
            $filteredRuns += $run
        }
    }
    if (!$seenStart) {
        throw "Unknown StartAtLabel '$StartAtLabel'"
    }
    $runs = $filteredRuns
    Write-SeqStatus "sequence_start_at label=$StartAtLabel initial_prefix=$InitialPrefixCandidatePath"
}

$previousCandidatePath = if (![string]::IsNullOrWhiteSpace($StartAtLabel) -and
    ![string]::IsNullOrWhiteSpace($InitialPrefixCandidatePath)) {
    $InitialPrefixCandidatePath
} else {
    $null
}

foreach ($run in $runs) {
    $runStamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $runRoot = Join-Path $sequenceRoot "$($run.Label)_$runStamp"
    $out = Join-Path $runRoot "a"
    $log = Join-Path $runRoot "run.log"
    New-Item -ItemType Directory -Force -Path $runRoot | Out-Null
    New-Item -ItemType Directory -Force -Path $out | Out-Null

    $prefixCandidatePath = $run.PrefixCandidatePath
    if (!$DisablePrefixHandoff -and
        [string]::IsNullOrWhiteSpace($prefixCandidatePath) -and
        ![string]::IsNullOrWhiteSpace($previousCandidatePath)) {
        $prefixCandidatePath = $previousCandidatePath
    }
    if (![string]::IsNullOrWhiteSpace($prefixCandidatePath) -and !(Test-Path $prefixCandidatePath)) {
        Write-SeqStatus "sequence_stop label=$($run.Label) reason=missing_prefix_candidate path=$prefixCandidatePath"
        break
    }

    $prefixLabel = if ([string]::IsNullOrWhiteSpace($prefixCandidatePath)) { "missing" } else { $prefixCandidatePath }
    Write-SeqStatus "run_start label=$($run.Label) hours=$($run.Hours) prefix=$prefixLabel out=$out"

    $env:MPCC_GLOBAL_POLISH_PROFILE = "custom"
    $env:MPCC_GLOBAL_POLISH_SOURCE = "artifacts"
    $env:MPCC_GLOBAL_POLISH_ARTIFACT_DIR = $run.ArtifactDir
    if ([string]::IsNullOrWhiteSpace($prefixCandidatePath)) {
        Remove-Item Env:\MPCC_GLOBAL_POLISH_PREFIX_CANDIDATE_PATH -ErrorAction SilentlyContinue
    } else {
        $env:MPCC_GLOBAL_POLISH_PREFIX_CANDIDATE_PATH = $prefixCandidatePath
    }
    $env:MPCC_GLOBAL_POLISH_PREFER_DENSE_START_ARTIFACT = "0"
    $env:MPCC_GLOBAL_POLISH_SANITIZE_DENSE_START_DUALS = "1"
    $env:MPCC_GLOBAL_POLISH_DENSE_START_KKT_REFRESH_POLICY = "fixed_flux_dual_fit"
    $env:MPCC_GLOBAL_POLISH_TARGET_HOURS = $run.Hours
    $env:MPCC_GLOBAL_POLISH_WINDOW_HOURS = "2.0"
    $env:MPCC_GLOBAL_POLISH_NFE = "4"
    $env:MPCC_GLOBAL_POLISH_MAX_WINDOWS = $run.Windows
    $env:MPCC_GLOBAL_POLISH_ALLOW_LONG = "1"
    $env:MPCC_GLOBAL_POLISH_SOURCE_COMPLETE_REQUIRED = "1"
    $env:MPCC_GLOBAL_POLISH_SOURCE_REQUIRE_PREFLIGHT = "1"
    $env:MPCC_GLOBAL_POLISH_REQUIRE_PREFLIGHT = "0"
    $env:MPCC_GLOBAL_POLISH_CONTINUE_ON_ERROR = "1"
    $env:MPCC_GLOBAL_POLISH_PROGRESS = "1"
    $env:MPCC_GLOBAL_POLISH_SILENT = "0"
    $env:MPCC_GLOBAL_POLISH_MAX_ITER = $run.MaxIter
    $env:MPCC_IPOPT_MAX_WALL_TIME_SECONDS = $run.Wall
    $env:MPCC_IPOPT_LINEAR_SOLVER = $LinearSolver
    if (![string]::IsNullOrWhiteSpace($HslLib)) {
        $env:MPCC_IPOPT_HSLLIB = $HslLib
    }
    $env:MPCC_REDUCED_MPCC_IPOPT_PROFILE = "feasibility_handoff"
    $env:MPCC_COMPLEMENTARITY_MODE = "scholtes"
    $env:MPCC_COMPLEMENTARITY_TAU = "1e-4"
    $env:MPCC_GLOBAL_POLISH_OBJECTIVE_MODE = "de_oliveira_tracking"
    $env:MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_REFERENCE = "sequential_reference"
    $env:MPCC_GLOBAL_POLISH_OBJECTIVE_RHO = "0.1"
    $env:MPCC_GLOBAL_POLISH_OBJECTIVE_STATE_WEIGHT = $ObjectiveStateWeight
    $env:MPCC_GLOBAL_POLISH_OBJECTIVE_BIOMASS_WEIGHT = $ObjectiveBiomassWeight
    $env:MPCC_GLOBAL_POLISH_OBJECTIVE_BIOMASS_TERMINAL_WEIGHT = $ObjectiveBiomassTerminalWeight
    $env:MPCC_GLOBAL_POLISH_OBJECTIVE_FLUX_WEIGHT = "0.0"
    $env:MPCC_GLOBAL_POLISH_OBJECTIVE_DERIVATIVE_WEIGHT = "0.0"
    $env:MPCC_GLOBAL_POLISH_TRUST_REGION_ENABLED = "1"
    $env:MPCC_GLOBAL_POLISH_TRUST_REGION_STATE_REFERENCE = "sequential_reference"
    $env:MPCC_GLOBAL_POLISH_TRUST_REGION_STATES = $TrustRegionStates
    $env:MPCC_GLOBAL_POLISH_TRUST_REGION_ABS_DELTA = "0.0"
    $env:MPCC_GLOBAL_POLISH_TRUST_REGION_REL_DELTA = $TrustRegionRelDelta
    $env:MPCC_GLOBAL_POLISH_TRUST_REGION_WEIGHT = $TrustRegionWeight
    $env:MPCC_GLOBAL_POLISH_OUTPUT_DIR = $out
    $env:MPCC_GLOBAL_POLISH_OUTPUT_OVERWRITE = "1"
    $env:MPCC_RESIDUAL_MAX_RHS = $ResidualMaxRhs
    $env:MPCC_RESIDUAL_MAX_MASS = "5e-6"
    $env:MPCC_RESIDUAL_MAX_LOWER_BOUND = "1e-6"
    $env:MPCC_RESIDUAL_MAX_UPPER_BOUND = "1e-6"
    $env:MPCC_RESIDUAL_MAX_STATIONARITY = "1e-5"
    $env:MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY = "2e-4"
    $env:MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY = "2e-4"
    $env:MPCC_IPOPT_PRINT_LEVEL = "5"
    $env:MPCC_IPOPT_PRINT_FREQUENCY_ITER = "10"
    $env:MPCC_IPOPT_PRINT_FREQUENCY_TIME = "10"

    $fullMaxIter = $env:MPCC_GLOBAL_POLISH_MAX_ITER
    $fullWall = $env:MPCC_IPOPT_MAX_WALL_TIME_SECONDS

    if ($EnableFeasibilityProbe) {
        $probeOut = Join-Path $runRoot "probe"
        $probeLog = Join-Path $runRoot "probe.log"
        New-Item -ItemType Directory -Force -Path $probeOut | Out-Null

        $env:MPCC_GLOBAL_POLISH_OUTPUT_DIR = $probeOut
        $env:MPCC_GLOBAL_POLISH_MAX_ITER = "$ProbeMaxIter"
        $env:MPCC_IPOPT_MAX_WALL_TIME_SECONDS = "$ProbeWall"
        $env:MPCC_GLOBAL_POLISH_REQUIRE_PREFLIGHT = "1"
        Write-SeqStatus "probe_start label=$($run.Label) max_iter=$ProbeMaxIter wall=$ProbeWall out=$probeOut"

        & julia --project=. .\scripts\main_reduced_mpcc_global_polish_smoke.jl 2>&1 |
            Tee-Object -FilePath $probeLog
        $probeExitCode = $LASTEXITCODE
        $probeSummary = Add-SeqSummary "probe" $run $prefixCandidatePath $runRoot $probeOut $probeLog $probeExitCode
        Write-SeqStatus "probe_done label=$($run.Label) exit=$probeExitCode pre_solve=$($probeSummary.PreSolveGuard) solver=$($probeSummary.Solver) primal=$($probeSummary.Primal) residual=$($probeSummary.Residual) structural_ratio=$($probeSummary.StructuralRatio) log=$probeLog"

        $probeRatio = Convert-LogDouble $probeSummary.StructuralRatio
        if ($null -eq $probeRatio) {
            if ($ContinueAfterFailedRun) {
                Write-SeqStatus "probe_reject_continue label=$($run.Label) reason=missing_structural_ratio"
                continue
            } else {
                Write-SeqStatus "sequence_stop label=$($run.Label) reason=missing_structural_ratio"
                break
            }
        }
        if ($null -ne $probeRatio -and $probeRatio -gt $ProbeStructuralRatioStop) {
            if ($ContinueAfterFailedRun) {
                Write-SeqStatus "probe_reject_continue label=$($run.Label) reason=structural_ratio_exceeded ratio=$($probeSummary.StructuralRatio) limit=$ProbeStructuralRatioStop"
                continue
            } else {
                Write-SeqStatus "sequence_stop label=$($run.Label) reason=probe_structural_ratio_exceeded ratio=$($probeSummary.StructuralRatio) limit=$ProbeStructuralRatioStop"
                break
            }
        }
        if (!($probeSummary.PreSolveGuard -eq "true") -and !($probeSummary.Residual -eq "true")) {
            if ($ContinueAfterFailedRun) {
                Write-SeqStatus "probe_reject_continue label=$($run.Label) reason=probe_candidate_not_residual_feasible pre_solve=$($probeSummary.PreSolveGuard) residual=$($probeSummary.Residual) dominant_or_next=$($probeSummary.Next)"
                continue
            } else {
                Write-SeqStatus "sequence_stop label=$($run.Label) reason=probe_candidate_not_residual_feasible pre_solve=$($probeSummary.PreSolveGuard) residual=$($probeSummary.Residual) dominant_or_next=$($probeSummary.Next)"
                break
            }
        }

        $env:MPCC_GLOBAL_POLISH_OUTPUT_DIR = $out
        $env:MPCC_GLOBAL_POLISH_MAX_ITER = $fullMaxIter
        $env:MPCC_IPOPT_MAX_WALL_TIME_SECONDS = $fullWall
        $env:MPCC_GLOBAL_POLISH_REQUIRE_PREFLIGHT = "0"
        Write-SeqStatus "probe_accept label=$($run.Label) ratio=$($probeSummary.StructuralRatio) limit=$ProbeStructuralRatioStop"
    }

    & julia --project=. .\scripts\main_reduced_mpcc_global_polish_smoke.jl 2>&1 |
        Tee-Object -FilePath $log
    $exitCode = $LASTEXITCODE

    $summary = Add-SeqSummary "full" $run $prefixCandidatePath $runRoot $out $log $exitCode

    Write-SeqStatus "run_done label=$($run.Label) exit=$exitCode solver=$($summary.Solver) primal=$($summary.Primal) residual=$($summary.Residual) trajectory=$($summary.Trajectory) structural_ratio=$($summary.StructuralRatio) log=$log"
    if (!($summary.Residual -eq "true")) {
        if ($ContinueAfterFailedRun) {
            Write-SeqStatus "sequence_continue label=$($run.Label) reason=candidate_not_residual_feasible"
        } else {
            Write-SeqStatus "sequence_stop label=$($run.Label) reason=candidate_not_residual_feasible"
            break
        }
    }
    $candidatePath = Join-Path $out "global_candidate_values\global_candidate_values.jls"
    if (!(Test-Path $candidatePath)) {
        if ($ContinueAfterFailedRun -and $DisablePrefixHandoff) {
            Write-SeqStatus "sequence_continue label=$($run.Label) reason=missing_output_candidate path=$candidatePath"
            continue
        } else {
            Write-SeqStatus "sequence_stop label=$($run.Label) reason=missing_output_candidate path=$candidatePath"
            break
        }
    }
    $previousCandidatePath = if ($DisablePrefixHandoff) { $null } else { $candidatePath }
}

Write-SeqStatus "sequence_done root=$sequenceRoot summary=$summaryPath"
