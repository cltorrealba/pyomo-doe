using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_WINDOW_PROFILE = "smoke"
const DEFAULT_MPCC_WINDOW_IPOPT_MAX_ITER = 100
const MPCC_WINDOW_COARSE_MODE_ENV = "MPCC_WINDOW_COARSE_MODE"
const MPCC_WINDOW_TAU_STAGE_MAX_ITERS_ENV = "MPCC_TAU_STAGE_MAX_ITERS"
const MPCC_TAU_FINAL_RETRY_MAX_ITER_ENV = "MPCC_TAU_FINAL_RETRY_MAX_ITER"
const MPCC_RESIDUAL_MAX_RHS_ENV = "MPCC_RESIDUAL_MAX_RHS"
const MPCC_RESIDUAL_MAX_MASS_ENV = "MPCC_RESIDUAL_MAX_MASS"
const MPCC_RESIDUAL_MAX_BOUND_ENV = "MPCC_RESIDUAL_MAX_BOUND"
const MPCC_RESIDUAL_MAX_LOWER_BOUND_ENV = "MPCC_RESIDUAL_MAX_LOWER_BOUND"
const MPCC_RESIDUAL_MAX_UPPER_BOUND_ENV = "MPCC_RESIDUAL_MAX_UPPER_BOUND"
const MPCC_RESIDUAL_MAX_STATIONARITY_ENV = "MPCC_RESIDUAL_MAX_STATIONARITY"
const MPCC_RESIDUAL_MAX_COMPLEMENTARITY_ENV = "MPCC_RESIDUAL_MAX_COMPLEMENTARITY"
const MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY_ENV =
    "MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY"
const MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY_ENV =
    "MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY"
const MPCC_WINDOW_WRITE_OUTPUTS_ENV = "MPCC_WINDOW_WRITE_OUTPUTS"
const MPCC_WINDOW_OUTPUT_DIR_ENV = "MPCC_WINDOW_OUTPUT_DIR"
const MPCC_WINDOW_OUTPUT_OVERWRITE_ENV = "MPCC_WINDOW_OUTPUT_OVERWRITE"

function _mpcc_window_profile()
    raw = strip(get(ENV, "MPCC_WINDOW_PROFILE", DEFAULT_MPCC_WINDOW_PROFILE))
    normalized = lowercase(raw)
    normalized = normalized == "twomh_four_nfe" ? "2h4nfe" : normalized
    normalized in ("smoke", "focused", "2h4nfe", "custom") ||
        error("Environment variable MPCC_WINDOW_PROFILE must be one of: smoke, focused, 2h4nfe, twomh_four_nfe, custom. Got: $raw")
    return normalized
end

function _mpcc_window_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (window_hours = "0.25", n_windows = 2, nfe_per_window = 1, max_windows = 2)
    elseif profile == "focused"
        return (window_hours = "0.5", n_windows = 2, nfe_per_window = 1, max_windows = 2)
    elseif profile == "2h4nfe"
        return (window_hours = "2.0", n_windows = 1, nfe_per_window = 4, max_windows = 36)
    else
        return (window_hours = "0.25", n_windows = 2, nfe_per_window = 1, max_windows = 2)
    end
end

function _mpcc_window_env_positive_float(name::AbstractString, default_value::AbstractString)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_window_env_nonnegative_float(name::AbstractString, default_value::AbstractString)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $value")
    return value
end

function _mpcc_window_env_positive_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_window_script_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_window_script_progress_line(row, row_index::Int, n_requested::Int)
    value(name) = _mpcc_window_script_value(get(row, name, missing))
    return "window_progress: $row_index/$n_requested | " *
           "$(value("window_id")) | status=$(value("window_status")) | " *
           "tspan=($(value("t0")),$(value("tfinal"))) | " *
           "solver=$(value("solver_status")) | primal=$(value("primal_status")) | " *
           "solve_s=$(value("solve_elapsed_seconds")) | " *
           "residual_feasible=$(value("candidate_residual_feasible")) | " *
           "allows_continuation=$(value("candidate_allows_continuation")) | " *
           "reason=$(value("continuation_acceptance_reason")) | " *
           "accepted_tau=$(value("tau_continuation_selected_tau")) | " *
           "coarse_fallback=$(value("tau_continuation_coarse_tau_fallback_applied")) | " *
           "blocking_stage=$(value("tau_continuation_blocking_stage")) | " *
           "blocking_reason=$(value("tau_continuation_blocking_reason")) | " *
           "final_retry=$(value("tau_continuation_final_retry_performed")) | " *
           "final_retry_count=$(value("tau_continuation_final_retry_count")) | " *
           "max_rhs=$(value("max_rhs_residual")) | " *
           "max_mass=$(value("max_mass_balance_residual")) | " *
           "max_stationarity=$(value("max_stationarity_residual")) | " *
           "max_comp_l=$(value("max_lower_complementarity_residual")) | " *
           "max_comp_u=$(value("max_upper_complementarity_residual")) | " *
           "max_state_abs=$(value("max_state_abs_difference")) | " *
           "max_state_rel_rmse=$(value("max_state_relative_rmse")) | " *
           "drift_gate=$(value("continuation_state_drift_gate_pass")) | " *
           "drift_blocks=$(value("continuation_state_drift_blocks_continuation")) | " *
           "state_seed=$(value("window_initial_state_propagation_policy")) | " *
           "primary_y0=$(value("window_initial_state_primary_source")) | " *
           "retry=$(value("window_initial_state_retry_applied")) | " *
           "retry_source=$(value("window_initial_state_retry_source")) | " *
           "next_y0=$(value("next_initial_state_source")) | " *
           "action=$(value("next_recommended_action"))"
end

function _mpcc_window_script_tau_stage_progress_line(event)
    value(name) = _mpcc_window_script_value(get(event, name, missing))
    return "tau_stage_progress: $(value("window_id")) | " *
           "attempt=$(value("window_attempt")) | " *
           "event=$(value("event")) | " *
           "stage=$(value("stage_index"))/$(value("stage_count")) | " *
           "tau=$(value("tau")) | " *
           "max_iter=$(value("stage_ipopt_max_iter")) | " *
           "solver=$(value("solver_status")) | primal=$(value("primal_status")) | " *
           "solve_s=$(value("solve_elapsed_seconds")) | " *
           "residual_feasible=$(value("residual_feasible")) | " *
           "tau_gate=$(value("complementarity_tau_gate_pass")) | " *
           "advance=$(value("stage_advance_allowed")) | " *
           "advance_reason=$(value("stage_advance_reason")) | " *
           "final_retry=$(value("final_retry_performed")) | " *
           "max_rhs=$(value("max_rhs_residual")) | " *
           "max_mass=$(value("max_mass_balance_residual")) | " *
           "max_stationarity=$(value("max_stationarity_residual")) | " *
           "max_comp_l=$(value("max_lower_complementarity_residual")) | " *
           "max_comp_u=$(value("max_upper_complementarity_residual")) | " *
           "dominant=$(value("dominant_residual"))"
end

function _mpcc_window_env_optional_nonnegative_float(
    name::AbstractString,
    default_value::Real,
)::Float64
    raw = get(ENV, String(name), nothing)
    raw === nothing && return Float64(default_value)
    stripped = strip(raw)
    isempty(stripped) && return Float64(default_value)
    value = tryparse(Float64, stripped)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $value")
    return value
end

function _mpcc_window_residual_thresholds_from_env()
    defaults = default_reduced_dcdfba_mpcc_residual_thresholds()
    max_bound = _mpcc_window_env_optional_nonnegative_float(
        MPCC_RESIDUAL_MAX_BOUND_ENV,
        defaults.max_lower_bound_violation,
    )
    max_complementarity = _mpcc_window_env_optional_nonnegative_float(
        MPCC_RESIDUAL_MAX_COMPLEMENTARITY_ENV,
        defaults.max_lower_complementarity_residual,
    )

    return default_reduced_dcdfba_mpcc_residual_thresholds(
        max_rhs_residual = _mpcc_window_env_optional_nonnegative_float(
            MPCC_RESIDUAL_MAX_RHS_ENV,
            defaults.max_rhs_residual,
        ),
        max_mass_balance_residual = _mpcc_window_env_optional_nonnegative_float(
            MPCC_RESIDUAL_MAX_MASS_ENV,
            defaults.max_mass_balance_residual,
        ),
        max_lower_bound_violation = _mpcc_window_env_optional_nonnegative_float(
            MPCC_RESIDUAL_MAX_LOWER_BOUND_ENV,
            max_bound,
        ),
        max_upper_bound_violation = _mpcc_window_env_optional_nonnegative_float(
            MPCC_RESIDUAL_MAX_UPPER_BOUND_ENV,
            max_bound,
        ),
        max_stationarity_residual = _mpcc_window_env_optional_nonnegative_float(
            MPCC_RESIDUAL_MAX_STATIONARITY_ENV,
            defaults.max_stationarity_residual,
        ),
        max_lower_complementarity_residual = _mpcc_window_env_optional_nonnegative_float(
            MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY_ENV,
            max_complementarity,
        ),
        max_upper_complementarity_residual = _mpcc_window_env_optional_nonnegative_float(
            MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY_ENV,
            max_complementarity,
        ),
    )
end

function _mpcc_window_validate_grid!(n_windows::Int, max_windows::Int, allow_long::Bool)
    if n_windows > max_windows && !allow_long
        error(
            "Requested MPCC windowed continuation has $n_windows windows, above " *
            "MPCC_WINDOW_MAX_WINDOWS=$max_windows. Set MPCC_WINDOW_ALLOW_LONG=1 " *
            "only for deliberate longer local diagnostics.",
        )
    end
    return nothing
end

profile = _mpcc_window_profile()
defaults = _mpcc_window_profile_defaults(profile)
window_hours = _mpcc_window_env_positive_float("MPCC_WINDOW_HOURS", defaults.window_hours)
n_windows = _mpcc_window_env_positive_int("MPCC_WINDOW_COUNT", defaults.n_windows)
nfe_per_window = _mpcc_window_env_positive_int("MPCC_WINDOW_NFE", defaults.nfe_per_window)
max_windows = _mpcc_window_env_positive_int("MPCC_WINDOW_MAX_WINDOWS", defaults.max_windows)
allow_long = _script_env_bool("MPCC_WINDOW_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_WINDOW_CONTINUE_ON_ERROR", true)
require_pre_solve_ready = _script_env_bool("MPCC_WINDOW_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_WINDOW_SILENT", true)
coarse_mode = _script_env_bool(MPCC_WINDOW_COARSE_MODE_ENV, false)
write_outputs = _script_env_bool(MPCC_WINDOW_WRITE_OUTPUTS_ENV, false)
output_overwrite = _script_env_bool(MPCC_WINDOW_OUTPUT_OVERWRITE_ENV, true)
output_dir = normpath(strip(get(
    ENV,
    MPCC_WINDOW_OUTPUT_DIR_ENV,
    joinpath(project_root, "outputs", "reduced_mpcc_windowed_continuation"),
)))
ipopt_max_iter =
    _mpcc_window_env_positive_int("MPCC_WINDOW_IPOPT_MAX_ITER", DEFAULT_MPCC_WINDOW_IPOPT_MAX_ITER)
linear_solver =
    strip(get(ENV, "MPCC_IPOPT_LINEAR_SOLVER", profile == "2h4nfe" ? "spral" : "mumps"))
complementarity_mode = reduced_mpcc_complementarity_mode_from_env("scholtes")
complementarity_tau = reduced_mpcc_complementarity_tau_from_env()
complementarity_tau_gate_tol = reduced_mpcc_complementarity_tau_gate_tol_from_env()
tau_schedule =
    _script_env_bool("MPCC_WINDOW_USE_TAU_CONTINUATION", profile == "2h4nfe") ?
    (
        coarse_mode ?
        [1.0e-2, 1.0e-4] :
        reduced_mpcc_tau_schedule_from_env()
    ) : nothing
tau_schedule_label = tau_schedule === nothing ? "disabled" : join(tau_schedule, ",")
tau_stage_max_iters =
    tau_schedule === nothing ? nothing :
    (
        coarse_mode ?
        Union{Nothing, Int}[500, 800] :
        reduced_mpcc_tau_stage_max_iters_from_env()
    )
tau_stage_max_iters_label =
    tau_stage_max_iters === nothing ? "default" :
    join((value === nothing ? "default" : string(value) for value in tau_stage_max_iters), ",")
tau_final_retry_max_iter =
    tau_schedule === nothing || coarse_mode ? nothing :
    reduced_mpcc_tau_final_retry_max_iter_from_env()
tau_final_retry_max_iter_label =
    tau_final_retry_max_iter === nothing ? "disabled" : string(tau_final_retry_max_iter)
allow_coarse_tau_fallback =
    _script_env_bool("MPCC_WINDOW_COARSE_ACCEPT_BEST_STAGE", coarse_mode)
propagate_flux_dual_starts =
    _script_env_bool("MPCC_WINDOW_PROPAGATE_FLUX_DUAL_STARTS", false)
initial_state_propagation_policy =
    strip(get(ENV, "MPCC_WINDOW_INITIAL_STATE_PROPAGATION", "candidate"))
residual_thresholds = _mpcc_window_residual_thresholds_from_env()
continuation_acceptance_policy =
    strip(get(ENV, "MPCC_WINDOW_CONTINUATION_POLICY", "residual_feasible"))
continuation_state_abs_difference_threshold =
    _mpcc_window_env_nonnegative_float("MPCC_WINDOW_STATE_ABS_DIFF_THRESHOLD", "1e-4")
continuation_state_relative_rmse_threshold =
    _mpcc_window_env_nonnegative_float("MPCC_WINDOW_STATE_REL_RMSE_THRESHOLD", "0.02")
phase_proxy_mode = strip(get(
    ENV,
    "DFBA_PHASE_PROXY_MODE",
    get(ENV, "MPCC_REDUCED_DCDFBA_PHASE_PROXY_MODE", "total_molecular_weight"),
))
turnover_threshold = _script_env_float("DFBA_TURNOVER_THRESHOLD", 0.001)
params = default_zenteno_parameters(
    phase_proxy_mode = phase_proxy_mode,
    TURNOVER_THRESHOLD = turnover_threshold,
)
initial_state_config = _script_initial_state_config(params)

_mpcc_window_validate_grid!(n_windows, max_windows, allow_long)

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

result = run_reduced_dcdfba_mpcc_windowed_continuation(
    model,
    reaction_map;
    window_hours = window_hours,
    n_windows = n_windows,
    nfe_per_window = nfe_per_window,
    degree = 3,
    y0 = initial_state_config.y0,
    params = params,
    ipopt_max_iter = ipopt_max_iter,
    linear_solver = linear_solver,
    complementarity_mode = complementarity_mode,
    complementarity_tau = complementarity_tau,
    complementarity_tau_gate_tol = complementarity_tau_gate_tol,
    residual_thresholds = residual_thresholds,
    tau_schedule = tau_schedule,
    tau_stage_max_iters = tau_stage_max_iters,
    tau_final_retry_max_iter = tau_final_retry_max_iter,
    allow_coarse_tau_fallback = allow_coarse_tau_fallback,
    propagate_flux_dual_starts = propagate_flux_dual_starts,
    initial_state_propagation_policy = initial_state_propagation_policy,
    require_pre_solve_ready = require_pre_solve_ready,
    continuation_acceptance_policy = continuation_acceptance_policy,
    continuation_state_abs_difference_threshold =
        continuation_state_abs_difference_threshold,
    continuation_state_relative_rmse_threshold =
        continuation_state_relative_rmse_threshold,
    window_callback = (row, row_index, n_requested) -> begin
        println(_mpcc_window_script_progress_line(row, row_index, n_requested))
        flush(stdout)
    end,
    tau_stage_callback = event -> begin
        println(_mpcc_window_script_tau_stage_progress_line(event))
        flush(stdout)
    end,
    silent = silent,
    continue_on_error = continue_on_error,
)
merge!(result.metadata, initial_state_config.metadata)
result.metadata["phase_proxy_mode"] = phase_proxy_mode
result.metadata["turnover_threshold"] = params.TURNOVER_THRESHOLD

output_paths = Dict{String, String}()
if write_outputs
    output_paths = write_reduced_dcdfba_mpcc_windowed_report(
        result,
        output_dir;
        overwrite = output_overwrite,
    )
end

println("Reduced MPCC windowed continuation diagnostics")
println("profile: $profile")
println("window_hours: $window_hours")
println("n_windows: $n_windows")
println("nfe_per_window: $nfe_per_window")
println("phase_proxy_mode: $phase_proxy_mode")
println("turnover_threshold: $(params.TURNOVER_THRESHOLD)")
println("initial_condition_policy: $(initial_state_config.metadata["initial_condition_policy"])")
println("initial_yan_policy: $(initial_state_config.metadata["initial_yan_policy"])")
println("initial_yan_target_mgN_L: $(_mpcc_window_script_value(get(initial_state_config.metadata, "initial_yan_target_mgN_L", missing)))")
println("initial_glucose_g_L: $(initial_state_config.metadata["initial_glucose_g_L"])")
println("initial_fructose_g_L: $(initial_state_config.metadata["initial_fructose_g_L"])")
println("initial_total_sugar_g_L: $(initial_state_config.metadata["initial_total_sugar_g_L"])")
println("initial_free_nitrogen_gN_L: $(initial_state_config.metadata["initial_free_nitrogen_gN_L"])")
println("initial_total_yan_equivalent_mgN_L: $(initial_state_config.metadata["initial_total_yan_equivalent_mgN_L"])")
println("ipopt_max_iter: $ipopt_max_iter")
println("ipopt_max_wall_time_seconds: $(result.metadata["ipopt_max_wall_time_seconds"])")
println("coarse_mode: $coarse_mode")
println("linear_solver: $linear_solver")
println("ipopt_warm_start_init_point: $(result.metadata["ipopt_warm_start_init_point"])")
println("complementarity_mode: $complementarity_mode")
println("complementarity_tau: $complementarity_tau")
println("complementarity_tau_gate_tol: $complementarity_tau_gate_tol")
println("tau_schedule: $tau_schedule_label")
println("tau_stage_max_iters: $tau_stage_max_iters_label")
println("tau_final_retry_max_iter: $tau_final_retry_max_iter_label")
println("allow_coarse_tau_fallback: $allow_coarse_tau_fallback")
println("propagate_flux_dual_starts: $propagate_flux_dual_starts")
println("initial_state_propagation_policy: $(result.metadata["window_initial_state_propagation_policy"])")
println("residual_max_rhs: $(residual_thresholds.max_rhs_residual)")
println("residual_max_mass: $(residual_thresholds.max_mass_balance_residual)")
println("residual_max_lower_bound: $(residual_thresholds.max_lower_bound_violation)")
println("residual_max_upper_bound: $(residual_thresholds.max_upper_bound_violation)")
println("residual_max_stationarity: $(residual_thresholds.max_stationarity_residual)")
println("residual_max_lower_complementarity: $(residual_thresholds.max_lower_complementarity_residual)")
println("residual_max_upper_complementarity: $(residual_thresholds.max_upper_complementarity_residual)")
println("continuation_acceptance_policy: $continuation_acceptance_policy")
println("continuation_state_abs_difference_threshold: $continuation_state_abs_difference_threshold")
println("continuation_state_relative_rmse_threshold: $continuation_state_relative_rmse_threshold")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("outputs_written: $(result.metadata["outputs_written"])")
println("output_dir: $(_mpcc_window_script_value(get(result.metadata, "output_dir", missing)))")
println("diagnostic_output_dir: $(_mpcc_window_script_value(get(result.metadata, "diagnostic_output_dir", missing)))")
println("plot_output_dir: $(_mpcc_window_script_value(get(result.metadata, "plot_output_dir", missing)))")
println("windowed_continuation_is_scientific_simulation: $(result.metadata["windowed_continuation_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(result.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(result.metadata["scientific_baseline"])")
println("first_mpcc_target: $(result.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(result.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(result.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(result.metadata["hsl_required"])")
println("ma57_required: $(result.metadata["ma57_required"])")
println("indices_reacciones_used: $(result.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(result.metadata["r0001_used_as_oxygen"])")
println("n_requested_windows: $(result.metadata["n_requested_windows"])")
println("n_completed_windows: $(result.metadata["n_completed_windows"])")
println("n_failed_windows: $(result.metadata["n_failed_windows"])")
println("continuation_completed: $(result.metadata["continuation_completed"])")
println("first_failed_window_id: $(_mpcc_window_script_value(result.metadata["first_failed_window_id"]))")
println("metadata_continuation_acceptance_policy: $(result.metadata["continuation_acceptance_policy"])")
println("continuation_state_drift_gate_enabled: $(result.metadata["continuation_state_drift_gate_enabled"])")
println("continuation_policy_rejected_window_count: $(result.metadata["continuation_policy_rejected_window_count"])")
println("iteration_limit_policy_accepted_window_count: $(result.metadata["iteration_limit_policy_accepted_window_count"])")
println("cross_window_flux_dual_start_enabled: $(result.metadata["cross_window_flux_dual_start_enabled"])")
println("cross_window_flux_dual_start_applied_window_count: $(result.metadata["cross_window_flux_dual_start_applied_window_count"])")
println("tau_continuation_polish_failed_window_count: $(result.metadata["tau_continuation_polish_failed_window_count"])")
println("tau_continuation_final_retry_window_count: $(result.metadata["tau_continuation_final_retry_window_count"])")
println("tau_continuation_coarse_tau_fallback_window_count: $(result.metadata["tau_continuation_coarse_tau_fallback_window_count"])")
println("all_completed_windows_residual_feasible: $(result.metadata["all_completed_windows_residual_feasible"])")
println("all_completed_windows_trajectory_ready: $(result.metadata["all_completed_windows_trajectory_ready"])")
println("total_horizon_reached: $(_mpcc_window_script_value(result.metadata["total_horizon_reached"]))")
println("sequential_reference_available: $(result.metadata["sequential_reference_available"])")
println("boundary_candidate_available: $(result.metadata["boundary_candidate_available"])")
println("global_state_metrics_available: $(result.metadata["global_state_metrics_available"])")
println("global_max_state_abs_difference: $(_mpcc_window_script_value(result.metadata["global_max_state_abs_difference"]))")
println("global_max_state_relative_rmse: $(_mpcc_window_script_value(result.metadata["global_max_state_relative_rmse"]))")
println("global_final_biomass_difference: $(_mpcc_window_script_value(result.metadata["global_final_biomass_difference"]))")
println("global_final_total_sugar_difference: $(_mpcc_window_script_value(result.metadata["global_final_total_sugar_difference"]))")

if !isempty(output_paths)
    println("output_paths:")
    for key in sort(collect(keys(output_paths)))
        println("  $key: $(output_paths[key])")
    end
end

println("window_table:")
for row in eachrow(result.window_table)
    println(
        "  $(row["window_id"]) | status=$(_mpcc_window_script_value(row["window_status"])) | " *
        "tspan=($(_mpcc_window_script_value(row["t0"])),$(_mpcc_window_script_value(row["tfinal"]))) | " *
        "nfe=$(_mpcc_window_script_value(row["nfe"])) | solver=$(_mpcc_window_script_value(row["solver_status"])) | " *
        "primal=$(_mpcc_window_script_value(row["primal_status"])) | solve_s=$(_mpcc_window_script_value(row["solve_elapsed_seconds"])) | " *
        "residual_feasible=$(_mpcc_window_script_value(row["candidate_residual_feasible"])) | " *
        "allows_continuation=$(_mpcc_window_script_value(row["candidate_allows_continuation"])) | " *
        "policy=$(_mpcc_window_script_value(row["continuation_acceptance_policy"])) | " *
        "reason=$(_mpcc_window_script_value(row["continuation_acceptance_reason"])) | " *
        "accepted_tau=$(_mpcc_window_script_value(row["tau_continuation_selected_tau"])) | " *
        "attempted_final_tau=$(_mpcc_window_script_value(row["tau_continuation_attempted_final_tau"])) | " *
        "coarse_fallback=$(_mpcc_window_script_value(row["tau_continuation_coarse_tau_fallback_applied"])) | " *
        "residual_source=$(_mpcc_window_script_value(row["candidate_residual_feasible_source"])) | " *
        "polish_failed=$(_mpcc_window_script_value(row["tau_continuation_polish_failed"])) | " *
        "final_retry=$(_mpcc_window_script_value(row["tau_continuation_final_retry_performed"])) | " *
        "final_retry_count=$(_mpcc_window_script_value(row["tau_continuation_final_retry_count"])) | " *
        "blocking_stage=$(_mpcc_window_script_value(row["tau_continuation_blocking_stage"])) | " *
        "blocking_reason=$(_mpcc_window_script_value(row["tau_continuation_blocking_reason"])) | " *
        "solver_call=$(_mpcc_window_script_value(row["solver_call_performed"])) | " *
        "pre_guard=$(_mpcc_window_script_value(row["pre_solve_guard_required"])) | " *
        "pre_guard_pass=$(_mpcc_window_script_value(row["pre_solve_guard_passed"])) | " *
        "pre_guard_component=$(_mpcc_window_script_value(row["pre_solve_guard_failure_component"])) | " *
        "pre_residuals_ok=$(_mpcc_window_script_value(row["pre_solve_residual_thresholds_satisfied"])) | " *
        "pre_scaling_ok=$(_mpcc_window_script_value(row["pre_solve_scaling_plan_ready_for_guarded_solve_attempt"])) | " *
        "pre_blocking_warnings=$(_mpcc_window_script_value(row["pre_solve_scaling_blocking_warning_count"])) | " *
        "pre_review_warnings=$(_mpcc_window_script_value(row["pre_solve_scaling_review_warning_count"])) | " *
        "pre_first_warning=$(_mpcc_window_script_value(row["pre_solve_first_warning"])) | " *
        "guard_blocked=$(_mpcc_window_script_value(row["guarded_solve_attempt_blocked"])) | " *
        "dominant_residual=$(_mpcc_window_script_value(row["dominant_residual"])) | " *
        "drift_gate=$(_mpcc_window_script_value(row["continuation_state_drift_gate_pass"])) | " *
        "drift_blocks=$(_mpcc_window_script_value(row["continuation_state_drift_blocks_continuation"])) | " *
        "iter_limit_policy=$(_mpcc_window_script_value(row["iteration_limit_policy_accepted"])) | " *
        "trajectory_ready=$(_mpcc_window_script_value(row["candidate_trajectory_ready"])) | " *
        "max_state_abs=$(_mpcc_window_script_value(row["max_state_abs_difference"])) | " *
        "max_state_rel_rmse=$(_mpcc_window_script_value(row["max_state_relative_rmse"])) | " *
        "max_rhs=$(_mpcc_window_script_value(row["max_rhs_residual"])) | " *
        "max_mass=$(_mpcc_window_script_value(row["max_mass_balance_residual"])) | " *
        "max_bound_l=$(_mpcc_window_script_value(row["max_lower_bound_violation"])) | " *
        "max_bound_u=$(_mpcc_window_script_value(row["max_upper_bound_violation"])) | " *
        "max_stationarity=$(_mpcc_window_script_value(row["max_stationarity_residual"])) | " *
        "max_comp_l=$(_mpcc_window_script_value(row["max_lower_complementarity_residual"])) | " *
        "max_comp_u=$(_mpcc_window_script_value(row["max_upper_complementarity_residual"])) | " *
        "flux_dual_seed=$(_mpcc_window_script_value(row["cross_window_flux_dual_start_applied"])) | " *
        "state_seed=$(_mpcc_window_script_value(row["window_initial_state_propagation_policy"])) | " *
        "primary_y0=$(_mpcc_window_script_value(row["window_initial_state_primary_source"])) | " *
        "retry=$(_mpcc_window_script_value(row["window_initial_state_retry_applied"])) | " *
        "retry_source=$(_mpcc_window_script_value(row["window_initial_state_retry_source"])) | " *
        "next_y0=$(_mpcc_window_script_value(row["next_initial_state_source"])) | " *
        "error_type=$(_mpcc_window_script_value(row["error_type"])) | " *
        "error_message=$(_mpcc_window_script_value(row["error_message"])) | " *
        "action=$(_mpcc_window_script_value(row["next_recommended_action"]))",
    )
end

println("interpretation_note: $(result.metadata["interpretation_note"])")
