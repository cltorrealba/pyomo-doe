import OrdinaryDiffEq

const DEFAULT_SCRIPT_ALGORITHM = "Tsit5"
const DEFAULT_SCRIPT_ODE_ABSTOL = 1.0e-8
const DEFAULT_SCRIPT_ODE_RELTOL = 1.0e-8
const DEFAULT_SCRIPT_LP_ATOL = 1.0e-8

function _script_env_bool(name::AbstractString, default::Bool)::Bool
    raw_value = lowercase(strip(get(ENV, String(name), string(default))))
    if raw_value in ("1", "true", "yes", "y", "on")
        return true
    elseif raw_value in ("0", "false", "no", "n", "off")
        return false
    else
        error("Environment variable $name must be a boolean value, got: $raw_value")
    end
end

function _script_env_float(name::AbstractString, default::Float64)::Float64
    raw_value = strip(get(ENV, String(name), string(default)))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 || error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _script_env_optional_nonnegative_float(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _script_ode_algorithm_config(env_name::AbstractString = "DFBA_ALGORITHM")
    raw_value = strip(get(ENV, String(env_name), DEFAULT_SCRIPT_ALGORITHM))
    normalized = lowercase(raw_value)
    if normalized in ("default", "tsit5")
        return (algorithm = OrdinaryDiffEq.Tsit5(), algorithm_label = "Tsit5")
    elseif normalized == "rodas5p"
        return (
            algorithm = OrdinaryDiffEq.Rodas5P(autodiff = OrdinaryDiffEq.AutoFiniteDiff()),
            algorithm_label = "Rodas5P",
        )
    else
        error("Environment variable $env_name must be one of: Tsit5, default, Rodas5P. Got: $raw_value")
    end
end

function _script_tolerance_config()
    return (
        ode_abstol = _script_env_float("DFBA_ODE_ABSTOL", DEFAULT_SCRIPT_ODE_ABSTOL),
        ode_reltol = _script_env_float("DFBA_ODE_RELTOL", DEFAULT_SCRIPT_ODE_RELTOL),
        lp_atol = _script_env_float("DFBA_LP_ATOL", DEFAULT_SCRIPT_LP_ATOL),
    )
end

function _script_output_dir(project_root::AbstractString, env_name::AbstractString, default_relative::AbstractString)
    raw_value = strip(get(ENV, String(env_name), default_relative))
    isempty(raw_value) && error("Environment variable $env_name must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _script_env_optional_float_vector(name::AbstractString; nonnegative::Bool = false)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    tokens = split(replace(raw_value, ';' => ','), ',')
    values = Float64[]
    for token in tokens
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Environment variable $name contains a non-Float64 token: $cleaned")
        isfinite(value) || error("Environment variable $name contains a non-finite value: $cleaned")
        nonnegative && value < 0.0 &&
            error("Environment variable $name must contain only nonnegative values, got: $cleaned")
        push!(values, value)
    end
    isempty(values) && return nothing
    return values
end

function _script_dynamic_control_schedule_config()
    horizon_h = _script_env_float("DFBA_DYNAMIC_CONTROL_HORIZON_HOURS", 168.0)
    control_interval_h = _script_env_float("DFBA_DYNAMIC_CONTROL_INTERVAL_HOURS", 12.0)
    sample_dt_h = _script_env_float("DFBA_DYNAMIC_CONTROL_SAMPLE_DT_HOURS", 0.25)
    temperature_transition_width_h = _script_env_float("DFBA_DYNAMIC_TEMPERATURE_WIDTH_HOURS", 1.0)
    addition_transition_width_h = _script_env_float("DFBA_DYNAMIC_ADDITION_WIDTH_HOURS", 0.5)
    temperature_min_C = _script_env_float("DFBA_DYNAMIC_T_MIN_C", 15.0)
    temperature_max_C = _script_env_float("DFBA_DYNAMIC_T_MAX_C", 25.0)
    fda_total_limit_g_L = _script_env_float(
        "DFBA_DYNAMIC_FDA_TOTAL_LIMIT_G_L",
        FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L,
    )

    temperature_values_C = _script_env_optional_float_vector("DFBA_DYNAMIC_TEMPERATURE_VALUES_C")
    fda_doses_g_L = _script_env_optional_float_vector("DFBA_DYNAMIC_FDA_DOSES_G_L"; nonnegative = true)
    organic_doses_g_L = _script_env_optional_float_vector("DFBA_DYNAMIC_ORG_DOSES_G_L"; nonnegative = true)

    schedule = reference_dynamic_control_schedule(
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        temperature_values_C = temperature_values_C,
        temperature_transition_width_h = temperature_transition_width_h,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        fda_doses_g_L = fda_doses_g_L,
        organic_doses_g_L = organic_doses_g_L,
        addition_transition_width_h = addition_transition_width_h,
        fda_total_limit_g_L = fda_total_limit_g_L,
    )

    return (
        schedule = schedule,
        horizon_h = horizon_h,
        control_interval_h = control_interval_h,
        sample_dt_h = sample_dt_h,
        temperature_values_C = temperature_values_C,
        fda_doses_g_L = fda_doses_g_L,
        organic_doses_g_L = organic_doses_g_L,
        metadata = Dict{String, Any}(
            "dynamic_control_horizon_h" => horizon_h,
            "dynamic_control_interval_h" => control_interval_h,
            "dynamic_control_sample_dt_h" => sample_dt_h,
            "dynamic_temperature_transition_width_h" => temperature_transition_width_h,
            "dynamic_addition_transition_width_h" => addition_transition_width_h,
            "dynamic_temperature_min_C" => temperature_min_C,
            "dynamic_temperature_max_C" => temperature_max_C,
            "dynamic_fda_total_limit_g_L" => fda_total_limit_g_L,
            "dynamic_temperature_values_from_env" => temperature_values_C !== nothing,
            "dynamic_fda_doses_from_env" => fda_doses_g_L !== nothing,
            "dynamic_org_doses_from_env" => organic_doses_g_L !== nothing,
        ),
    )
end

function _script_initial_state_config(params::ZentenoKineticParameters)
    y0 = zenteno_state_to_vector(default_zenteno_initial_state())
    initial_glucose = y0[3]
    initial_fructose = y0[4]
    glucose_override = _script_env_optional_nonnegative_float("DFBA_INITIAL_GLUCOSE_G_L")
    fructose_override = _script_env_optional_nonnegative_float("DFBA_INITIAL_FRUCTOSE_G_L")
    if glucose_override !== nothing
        y0[3] = glucose_override
    end
    if fructose_override !== nothing
        y0[4] = fructose_override
    end
    sugar_policy =
        glucose_override === nothing && fructose_override === nothing ? "default" : "env_override"
    sugar_metadata = Dict{String, Any}(
        "initial_sugar_policy" => sugar_policy,
        "initial_glucose_previous_g_L" => initial_glucose,
        "initial_fructose_previous_g_L" => initial_fructose,
        "initial_glucose_g_L" => y0[3],
        "initial_fructose_g_L" => y0[4],
        "initial_total_sugar_g_L" => y0[3] + y0[4],
        "initial_glucose_delta_g_L" => y0[3] - initial_glucose,
        "initial_fructose_delta_g_L" => y0[4] - initial_fructose,
    )

    policy = lowercase(strip(get(ENV, "DFBA_INITIAL_YAN_POLICY", "default")))
    target_mgn_l = _script_env_optional_nonnegative_float("DFBA_INITIAL_YAN_MGN_L")
    if target_mgn_l === nothing && policy == "default"
        initial_condition_policy =
            sugar_policy == "default" ? "default_zenteno_initial_state" : "custom_initial_sugars_from_env"
        return (
            y0 = y0,
            metadata = merge(
                sugar_metadata,
                Dict{String, Any}(
                    "initial_condition_policy" => initial_condition_policy,
                    "initial_yan_policy" => "default",
                    "initial_yan_target_mgN_L" => missing,
                    "initial_free_nitrogen_gN_L" => y0[2],
                    "initial_amino_acid_nitrogen_equivalent_gN_L" => sum(y0[9:13]) * params.MW_N,
                    "initial_total_yan_equivalent_mgN_L" => 1000.0 * (y0[2] + sum(y0[9:13]) * params.MW_N),
                ),
            ),
        )
    end

    if policy == "default" && target_mgn_l !== nothing
        policy = "ammonium_balance"
    end
    policy == "ammonium_balance" || error(
        "DFBA_INITIAL_YAN_POLICY must be default or ammonium_balance. Got: $policy",
    )
    target_mgn_l === nothing && error(
        "DFBA_INITIAL_YAN_MGN_L is required when DFBA_INITIAL_YAN_POLICY=ammonium_balance.",
    )

    amino_acid_n_gn_l = sum(y0[9:13]) * params.MW_N
    target_gn_l = target_mgn_l / 1000.0
    adjusted_free_n_gn_l = target_gn_l - amino_acid_n_gn_l
    adjusted_free_n_gn_l >= 0.0 || error(
        "DFBA_INITIAL_YAN_MGN_L=$(target_mgn_l) mgN/L is below the current amino-acid " *
        "nitrogen equivalent $(1000.0 * amino_acid_n_gn_l) mgN/L, so ammonium_balance " *
        "would require negative free nitrogen.",
    )

    previous_free_n_gn_l = y0[2]
    y0[2] = adjusted_free_n_gn_l
    total_yan_gn_l = y0[2] + amino_acid_n_gn_l
    initial_condition_policy =
        sugar_policy == "default" ? "yan_ammonium_balance_from_default_amino_acids" :
        "yan_ammonium_balance_and_custom_initial_sugars"
    return (
        y0 = y0,
        metadata = merge(
            sugar_metadata,
            Dict{String, Any}(
                "initial_condition_policy" => initial_condition_policy,
                "initial_yan_policy" => policy,
                "initial_yan_target_mgN_L" => target_mgn_l,
                "initial_free_nitrogen_previous_gN_L" => previous_free_n_gn_l,
                "initial_free_nitrogen_gN_L" => y0[2],
                "initial_free_nitrogen_delta_gN_L" => y0[2] - previous_free_n_gn_l,
                "initial_amino_acid_nitrogen_equivalent_gN_L" => amino_acid_n_gn_l,
                "initial_amino_acid_nitrogen_equivalent_mgN_L" => 1000.0 * amino_acid_n_gn_l,
                "initial_total_yan_equivalent_gN_L" => total_yan_gn_l,
                "initial_total_yan_equivalent_mgN_L" => 1000.0 * total_yan_gn_l,
            ),
        ),
    )
end
