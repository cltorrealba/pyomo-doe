using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")
dfvb_paths_config = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")
output_dir = joinpath(project_root, "results", "dfvb_matlab_comparison", "latest")

full_model = load_full_model(full_paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(full_model, reaction_map)
reaction_report.ok || error(
    "Full reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

artifacts = load_dfvb_artifacts(
    dfvb_paths_config;
    load_alpha_trajectories = false,
    load_active_alpha_trajectories = false,
    load_state_trajectories = true,
)
validation = validate_dfvb_artifacts(artifacts)
validation.ok || error("DFVB artifact validation failed: $(join(validation.errors, "; "))")

tfinal = _script_env_float("DFVB_MATLAB_COMPARE_TFINAL_HOURS", 0.25)
saveat = _script_env_float("DFVB_MATLAB_COMPARE_SAVEAT_HOURS", 0.25)
alignment_policy = strip(get(ENV, "DFVB_MATLAB_COMPARE_ALIGNMENT", "linear_interpolation_to_julia_times"))

comparison = compare_dfvb_to_matlab_baseline(
    full_model,
    reaction_map,
    artifacts;
    tspan = (0.0, tfinal),
    saveat = saveat,
    algorithm = OrdinaryDiffEq.Tsit5(),
    use_active_alpha = true,
    reconstruct_alphas = true,
    reconstruct_fluxes = false,
    alignment_policy = alignment_policy,
)
report_paths = export_dfvb_matlab_comparison(comparison, output_dir; overwrite = true)
plot_paths = write_dfvb_matlab_comparison_plots(comparison, output_dir; overwrite = true)

function _dfvb_matlab_script_sorted_paths(paths::Dict{String, String})
    return [key => paths[key] for key in sort(collect(keys(paths)))]
end

function _dfvb_matlab_script_summary_value(comparison::DFVBMatlabComparisonResult, source::AbstractString, column::AbstractString)
    row_index = findfirst(==(String(source)), String.(comparison.summary_table[!, "source"]))
    row_index === nothing && error("Missing comparison summary source $(String(source)).")
    return comparison.summary_table[row_index, column]
end

function _dfvb_matlab_script_rmse(comparison::DFVBMatlabComparisonResult, state_name::AbstractString)
    row_index = findfirst(==(String(state_name)), String.(comparison.state_metrics[!, "state_name"]))
    row_index === nothing && error("Missing comparison metric state $(String(state_name)).")
    return comparison.state_metrics[row_index, "rmse"]
end

println("Julia-vs-MATLAB DFVB trajectory comparison report")
println("output_dir: $output_dir")
println("artifact_id: $(artifacts.paths.artifact_id)")
println("artifact_validation_ok: $(validation.ok)")
println("alignment_policy: $(comparison.metadata["alignment_policy"])")
println("julia_retcode: $(comparison.metadata["julia_retcode"])")
println("julia_final_biomass: $(_dfvb_matlab_script_summary_value(comparison, "julia_dfvb", "final_biomass"))")
println("julia_final_glucose: $(_dfvb_matlab_script_summary_value(comparison, "julia_dfvb", "final_glucose"))")
println("julia_final_fructose: $(_dfvb_matlab_script_summary_value(comparison, "julia_dfvb", "final_fructose"))")
println("julia_final_ethanol: $(_dfvb_matlab_script_summary_value(comparison, "julia_dfvb", "final_ethanol"))")
println("julia_final_oxygen: $(_dfvb_matlab_script_summary_value(comparison, "julia_dfvb", "final_oxygen"))")
println("matlab_aligned_final_biomass: $(_dfvb_matlab_script_summary_value(comparison, "matlab_dfvb_baseline", "final_biomass"))")
println("matlab_aligned_final_glucose: $(_dfvb_matlab_script_summary_value(comparison, "matlab_dfvb_baseline", "final_glucose"))")
println("matlab_aligned_final_fructose: $(_dfvb_matlab_script_summary_value(comparison, "matlab_dfvb_baseline", "final_fructose"))")
println("matlab_aligned_final_ethanol: $(_dfvb_matlab_script_summary_value(comparison, "matlab_dfvb_baseline", "final_ethanol"))")
println("matlab_aligned_final_oxygen: $(_dfvb_matlab_script_summary_value(comparison, "matlab_dfvb_baseline", "final_oxygen"))")
println("key_state_rmse:")
for state_name in ("biomass", "glucose", "fructose", "ethanol", "oxygen")
    println("  $state_name: $(_dfvb_matlab_script_rmse(comparison, state_name))")
end
println("csv_toml_files:")
for (key, path) in _dfvb_matlab_script_sorted_paths(report_paths)
    println("  $key: $path")
end
println("svg_files:")
for (key, path) in _dfvb_matlab_script_sorted_paths(plot_paths)
    println("  $key: $path")
end
println("alpha_comparison_included: $(comparison.metadata["alpha_comparison_included"])")
println("flux_comparison_included: $(comparison.metadata["flux_comparison_included"])")
println("oxygen_policy_note: $(comparison.metadata["oxygen_policy_note"])")
println("exchange_partition_note: $(comparison.metadata["exchange_partition_note"])")
println("r0001_used_as_oxygen: $(comparison.metadata["r0001_used_as_oxygen"])")
println("oxygen_reaction_id: $(comparison.metadata["oxygen_reaction_id"])")
println("interpretation_note: $(comparison.metadata["interpretation_note"])")
