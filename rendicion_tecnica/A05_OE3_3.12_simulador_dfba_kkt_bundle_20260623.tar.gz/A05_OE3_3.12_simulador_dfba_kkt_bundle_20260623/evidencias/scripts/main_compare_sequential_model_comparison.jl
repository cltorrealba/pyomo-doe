using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")
full_reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")
dfvb_paths_config = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")
output_dir = joinpath(project_root, "results", "sequential_model_comparison", "latest")

reduced_model = load_reduced_model(reduced_paths_config)
full_model = load_full_model(full_paths_config)
reduced_reaction_map = load_reaction_map(reduced_reaction_map_config)
full_reaction_map = load_reaction_map(full_reaction_map_config)
artifacts = load_dfvb_artifacts(
    dfvb_paths_config;
    load_alpha_trajectories = false,
    load_active_alpha_trajectories = false,
    load_state_trajectories = true,
)
validation = validate_dfvb_artifacts(artifacts)
validation.ok || error("DFVB artifact validation failed: $(join(validation.errors, "; "))")

tfinal = _script_env_float("SEQ_MODEL_COMPARE_TFINAL_HOURS", 0.25)
saveat = _script_env_float("SEQ_MODEL_COMPARE_SAVEAT_HOURS", 0.25)
alignment_policy =
    strip(get(ENV, "SEQ_MODEL_COMPARE_ALIGNMENT", "linear_interpolation_to_reference_times"))

comparison = compare_sequential_models(
    reduced_model,
    reduced_reaction_map,
    full_model,
    full_reaction_map,
    artifacts;
    tspan = (0.0, tfinal),
    saveat = saveat,
    algorithm = OrdinaryDiffEq.Tsit5(),
    reconstruct_fluxes = false,
    reconstruct_alphas = false,
    alignment_policy = alignment_policy,
)

report_paths = export_sequential_model_comparison(comparison, output_dir; overwrite = true)
plot_paths = write_sequential_model_comparison_plots(comparison, output_dir; overwrite = true)

function _seq_model_script_sorted_paths(paths::Dict{String, String})
    return [key => paths[key] for key in sort(collect(keys(paths)))]
end

function _seq_model_script_summary_row(comparison::SequentialModelComparisonResult, source::AbstractString)
    row_index = findfirst(==(String(source)), String.(comparison.summary_table[!, "source"]))
    row_index === nothing && error("Missing consolidated comparison summary source $(String(source)).")
    return comparison.summary_table[row_index, :]
end

function _seq_model_script_state_row(comparison::SequentialModelComparisonResult, state_name::AbstractString)
    row_index = findfirst(==(String(state_name)), String.(comparison.state_metrics_table[!, "state_name"]))
    row_index === nothing && error("Missing consolidated comparison metric state $(String(state_name)).")
    return comparison.state_metrics_table[row_index, :]
end

function _seq_model_script_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

println("Consolidated sequential DFBA/DFVB comparison report")
println("output_dir: $output_dir")
println("artifact_id: $(artifacts.paths.artifact_id)")
println("artifact_validation_ok: $(validation.ok)")
println("sources: $(join(String.(comparison.metadata["sources"]), ", "))")
println("algorithm_label: $(comparison.metadata["algorithm_label"])")
println("tspan: $(comparison.metadata["tspan"])")
println("saveat: $(comparison.metadata["saveat"])")
println("alignment_policy: $(comparison.metadata["alignment_policy"])")

println("source_retcodes:")
for source in ("reduced_dfba", "full_dfba", "julia_dfvb", "matlab_dfvb_baseline")
    row = _seq_model_script_summary_row(comparison, source)
    println("  $source: $(row["retcode"])")
end

println("final_state_summary:")
for source in ("reduced_dfba", "full_dfba", "julia_dfvb", "matlab_dfvb_baseline")
    row = _seq_model_script_summary_row(comparison, source)
    println(
        "  $source | final_biomass=$(_seq_model_script_value(row["final_biomass"])) | " *
        "final_total_sugar=$(_seq_model_script_value(row["final_total_sugar"])) | " *
        "final_ethanol=$(_seq_model_script_value(row["final_ethanol"])) | " *
        "final_oxygen=$(_seq_model_script_value(row["final_oxygen"]))",
    )
end

println("selected_rmse:")
for state_name in ("biomass", "glucose", "fructose", "ethanol", "oxygen")
    row = _seq_model_script_state_row(comparison, state_name)
    println(
        "  $state_name | rmse_reduced_vs_full=$(_seq_model_script_value(row["rmse_reduced_vs_full"])) | " *
        "rmse_julia_dfvb_vs_full=$(_seq_model_script_value(row["rmse_julia_dfvb_vs_full"])) | " *
        "rmse_julia_dfvb_vs_matlab=$(_seq_model_script_value(row["rmse_julia_dfvb_vs_matlab"])) | " *
        "relative_rmse_julia_dfvb_vs_matlab=$(_seq_model_script_value(row["relative_rmse_julia_dfvb_vs_matlab"]))",
    )
end

println("written_csv_toml_files:")
for (key, path) in _seq_model_script_sorted_paths(report_paths)
    println("  $key = $path")
end

println("written_svg_files:")
for (key, path) in _seq_model_script_sorted_paths(plot_paths)
    println("  $key = $path")
end

println("flux_comparison_included: $(comparison.metadata["flux_comparison_included"])")
println("alpha_comparison_included: $(comparison.metadata["alpha_comparison_included"])")
println("r0001_used_as_oxygen: $(comparison.metadata["r0001_used_as_oxygen"])")
println("oxygen_reaction_id: $(comparison.metadata["oxygen_reaction_id"])")
println("oxygen_policy_note: $(comparison.metadata["oxygen_policy_note"])")
println("carbohydrate_policy_note: $(comparison.metadata["carbohydrate_policy_note"])")
println("interpretation_note: $(comparison.metadata["interpretation_note"])")
