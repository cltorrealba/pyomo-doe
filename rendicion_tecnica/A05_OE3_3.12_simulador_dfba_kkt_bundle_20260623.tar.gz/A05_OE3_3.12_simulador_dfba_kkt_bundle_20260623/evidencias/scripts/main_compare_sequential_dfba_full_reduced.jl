using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")
full_reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")
output_dir = joinpath(project_root, "results", "sequential_dfba_comparison", "latest")

function _seq_script_env_bool_or_default(name::AbstractString, default::Bool)::Bool
    haskey(ENV, String(name)) || return default
    return _script_env_bool(name, default)
end

function _seq_script_env_optional_float(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw = strip(ENV[key])
    isempty(raw) && return nothing
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $key must be a floating-point number, got \"$raw\".")
    isfinite(value) && value > 0.0 || error("Environment variable $key must be finite and positive, got $value.")
    return value
end

function _seq_script_env_nonnegative_float(name::AbstractString, default::Real)
    key = String(name)
    raw = haskey(ENV, key) ? strip(ENV[key]) : string(Float64(default))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $key must be a floating-point number, got \"$raw\".")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $key must be finite and nonnegative, got $value.")
    return value
end

function _seq_script_env_optional_int(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw = strip(ENV[key])
    isempty(raw) && return nothing
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $key must be an integer, got \"$raw\".")
    value > 0 || error("Environment variable $key must be positive, got $value.")
    return value
end

reduced_model = load_reduced_model(reduced_paths_config)
full_model = load_full_model(full_paths_config)
reduced_reaction_map = load_reaction_map(reduced_reaction_map_config)
full_reaction_map = load_reaction_map(full_reaction_map_config)

tfinal = _script_env_float("DFBA_SEQ_COMPARE_TFINAL_HOURS", 0.25)
saveat = _script_env_float("DFBA_SEQ_COMPARE_SAVEAT_HOURS", 0.25)
reconstruct_fluxes = _script_env_bool("DFBA_SEQ_COMPARE_RECONSTRUCT_FLUXES", false)
allow_long_full = _script_env_bool("DFBA_SEQ_COMPARE_ALLOW_LONG_FULL", false)
allow_dense_output = _script_env_bool("DFBA_SEQ_COMPARE_ALLOW_DENSE_OUTPUT", false)

runtime_policy = SequentialDFBARuntimePolicy(
    allow_long_full = allow_long_full,
    allow_dense_output = allow_dense_output,
)
long_run_requested = tfinal > runtime_policy.manual_tfinal_hours
adaptive = _seq_script_env_bool_or_default(
    "DFBA_SEQ_COMPARE_ADAPTIVE",
    !(allow_long_full && long_run_requested),
)
dt = _seq_script_env_optional_float("DFBA_SEQ_COMPARE_DT_HOURS")
if !adaptive && dt === nothing
    dt = saveat
end
progress_interval_seconds = _seq_script_env_nonnegative_float(
    "DFBA_SEQ_COMPARE_PROGRESS_SECONDS",
    long_run_requested ? 30.0 : 0.0,
)
max_rhs_calls = _seq_script_env_optional_int("DFBA_SEQ_COMPARE_MAX_RHS_CALLS")
max_walltime_seconds = _seq_script_env_optional_float("DFBA_SEQ_COMPARE_MAX_WALLTIME_SECONDS")

comparison = compare_sequential_dfba_full_reduced(
    reduced_model,
    reduced_reaction_map,
    full_model,
    full_reaction_map;
    tspan = (0.0, tfinal),
    saveat = saveat,
    algorithm = OrdinaryDiffEq.Tsit5(),
    reconstruct_fluxes = reconstruct_fluxes,
    adaptive = adaptive,
    dt = dt,
    progress_interval_seconds = progress_interval_seconds,
    max_rhs_calls = max_rhs_calls,
    max_walltime_seconds = max_walltime_seconds,
    runtime_policy = runtime_policy,
)

report_paths = export_sequential_dfba_comparison(comparison, output_dir; overwrite = true)
plot_paths = write_sequential_dfba_comparison_plots(comparison, output_dir; overwrite = true)

function _seq_script_row(table, model_scope::AbstractString)
    row_index = findfirst(==(String(model_scope)), String.(table[!, "model_scope"]))
    row_index === nothing && error("Missing comparison summary row for model_scope $(String(model_scope)).")
    return table[row_index, :]
end

function _seq_script_state_row(table, state_name::AbstractString)
    row_index = findfirst(==(String(state_name)), String.(table[!, "state_name"]))
    row_index === nothing && error("Missing state metrics row for $(String(state_name)).")
    return table[row_index, :]
end

function _seq_script_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

summary = comparison.summary_table
metrics = comparison.state_metrics_table
reduced_row = _seq_script_row(summary, "reduced")
full_row = _seq_script_row(summary, "full")

println("Full-vs-reduced sequential DFBA comparison report")
println("output_dir: $output_dir")
println("algorithm_label: $(comparison.metadata["algorithm_label"])")
println("tspan: $(comparison.metadata["tspan"])")
println("saveat: $(comparison.metadata["saveat"])")
println("reconstruct_fluxes: $(comparison.metadata["reconstruct_fluxes"])")
println("adaptive: $(comparison.metadata["adaptive"])")
println("dt: $(_seq_script_value(comparison.metadata["dt"]))")
println("progress_interval_seconds: $(comparison.metadata["progress_interval_seconds"])")
println("max_rhs_calls: $(_seq_script_value(comparison.metadata["max_rhs_calls"]))")
println("max_walltime_seconds: $(_seq_script_value(comparison.metadata["max_walltime_seconds"]))")
println("flux_comparison_included: $(comparison.metadata["flux_comparison_included"])")
println("runtime_policy_label: $(comparison.metadata["runtime_policy_label"])")
println("runtime_policy_allow_long_full: $(comparison.metadata["runtime_policy_allow_long_full"])")
println("runtime_policy_allow_dense_output: $(comparison.metadata["runtime_policy_allow_dense_output"])")
println("runtime_policy_hard_tfinal_hours: $(comparison.metadata["runtime_policy_hard_tfinal_hours"])")
println("estimated_saved_points: $(comparison.metadata["estimated_saved_points"])")
println("reduced_retcode: $(reduced_row["retcode"])")
println("full_retcode: $(full_row["retcode"])")

println("final_state_summary:")
for (scope, row) in (("reduced", reduced_row), ("full", full_row))
    println(
        "  $scope | final_biomass=$(row["final_biomass"]) | " *
        "final_total_sugar=$(row["final_total_sugar"]) | final_ethanol=$(row["final_ethanol"])",
    )
end

println("selected_final_differences:")
for state_name in ("biomass", "glucose", "fructose", "ethanol", "oxygen")
    row = _seq_script_state_row(metrics, state_name)
    println(
        "  $state_name | final_difference_full_minus_reduced=" *
        "$(_seq_script_value(row["final_difference_full_minus_reduced"]))",
    )
end

println("selected_rmse:")
for state_name in ("biomass", "glucose", "fructose", "ethanol", "oxygen")
    row = _seq_script_state_row(metrics, state_name)
    println(
        "  $state_name | rmse=$(_seq_script_value(row["rmse"])) | " *
        "relative_rmse=$(_seq_script_value(row["relative_rmse"]))",
    )
end

println("runtime_counters:")
for (scope, row) in (("reduced", reduced_row), ("full", full_row))
    println(
        "  $scope | simulation_elapsed_seconds=$(row["simulation_elapsed_seconds"]) | " *
        "rhs_call_count=$(row["rhs_call_count"]) | total_lp_solve_count=$(row["total_lp_solve_count"])",
    )
end

println("written_csv_toml_files:")
for key in sort(collect(keys(report_paths)))
    println("  $key = $(report_paths[key])")
end

println("written_svg_files:")
for key in sort(collect(keys(plot_paths)))
    println("  $key = $(plot_paths[key])")
end

println("oxygen_note: $(comparison.metadata["oxygen_mapping_note"])")
println("carbohydrate_note: $(comparison.metadata["carbohydrate_mapping_note"])")
println("runtime_policy_note: $(comparison.metadata["runtime_policy_note"])")
println("interpretation_note: $(comparison.metadata["interpretation_note"])")
