using CSV
using DataFrames
using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

function _preview_schedule_table(samples::Vector)::DataFrame
    return DataFrame(samples)
end

project_root = normpath(joinpath(@__DIR__, ".."))
dynamic_control_config = _script_dynamic_control_schedule_config()
schedule = dynamic_control_config.schedule
horizon_h = dynamic_control_config.horizon_h
control_interval_h = dynamic_control_config.control_interval_h
sample_dt_h = dynamic_control_config.sample_dt_h

samples = sample_dynamic_control_schedule(schedule; start_h = 0.0, stop_h = horizon_h, dt_h = sample_dt_h)
output_dir = _script_output_dir(
    project_root,
    "DFBA_DYNAMIC_CONTROL_OUTPUT_DIR",
    joinpath("outputs", "dynamic_control_preview"),
)
mkpath(output_dir)
schedule_path = joinpath(output_dir, "dynamic_control_schedule.csv")
summary_path = joinpath(output_dir, "dynamic_control_summary.csv")

CSV.write(schedule_path, _preview_schedule_table(samples))
CSV.write(
    summary_path,
    DataFrame(
        key = [
            "horizon_h",
            "control_interval_h",
            "sample_dt_h",
            "temperature_transition_count",
            "temperature_min_C",
            "temperature_max_C",
            "temperature_transition_width_h",
            "fda_event_count",
            "organic_event_count",
            "fda_total_product_g_L",
            "organic_total_product_g_L",
            "fda_total_limit_g_L",
            "dynamic_control_penalty",
        ],
        value = [
            horizon_h,
            control_interval_h,
            sample_dt_h,
            length(schedule.temperature_transition_times_h),
            schedule.temperature_min_C,
            schedule.temperature_max_C,
            schedule.temperature_transition_width_h,
            length(schedule.fda_events),
            length(schedule.organic_events),
            sum((event.total_product_g_L for event in schedule.fda_events); init = 0.0),
            sum((event.total_product_g_L for event in schedule.organic_events); init = 0.0),
            schedule.fda_total_limit_g_L,
            dynamic_control_penalty(schedule),
        ],
    ),
)

println("Dynamic control schedule preview")
println("schedule_csv: $schedule_path")
println("summary_csv: $summary_path")
println("horizon_h: $horizon_h")
println("control_interval_h: $control_interval_h")
println("sample_dt_h: $sample_dt_h")
println("temperature_transition_count: $(length(schedule.temperature_transition_times_h))")
println("fda_total_product_g_L: $(sum((event.total_product_g_L for event in schedule.fda_events); init = 0.0))")
println("organic_total_product_g_L: $(sum((event.total_product_g_L for event in schedule.organic_events); init = 0.0))")
println("dynamic_control_penalty: $(dynamic_control_penalty(schedule))")
