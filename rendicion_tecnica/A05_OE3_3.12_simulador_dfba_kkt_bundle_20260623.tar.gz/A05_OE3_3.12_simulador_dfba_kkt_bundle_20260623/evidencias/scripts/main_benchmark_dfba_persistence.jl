using FermentationDFBA
import OrdinaryDiffEq

const DEFAULT_DFBA_PERSISTENCE_BENCHMARK_OUTPUT_DIR =
    joinpath("results", "benchmarks", "dfba_persistence_latest")
const DEFAULT_DFBA_PERSISTENCE_BENCHMARK_72H_OUTPUT_DIR =
    joinpath("results", "benchmarks", "dfba_persistence_72h_latest")
const DFBA_PERSISTENCE_BENCHMARK_SCENARIO_CONTRACT = (
    "full_dfba_cold",
    "full_dfba_persistent",
    "reduced_dfba_persistent",
)

project_root = normpath(joinpath(@__DIR__, ".."))
full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
full_reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _dfba_persistence_env_float(name::AbstractString, default::Float64)::Float64
    raw_value = strip(get(ENV, String(name), string(default)))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 || error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _dfba_persistence_env_nonnegative_float(name::AbstractString, default::Float64)::Float64
    raw_value = strip(get(ENV, String(name), string(default)))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _dfba_persistence_env_optional_float(name::AbstractString)
    raw_value = strip(get(ENV, String(name), ""))
    isempty(raw_value) && return nothing
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 || error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _dfba_persistence_env_optional_int(name::AbstractString)
    raw_value = strip(get(ENV, String(name), ""))
    isempty(raw_value) && return nothing
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $raw_value")
    return value
end

function _dfba_persistence_env_bool(name::AbstractString, default::Bool)::Bool
    raw_value = lowercase(strip(get(ENV, String(name), string(default))))
    raw_value in ("1", "true", "yes", "y") && return true
    raw_value in ("0", "false", "no", "n") && return false
    error("Environment variable $name must parse as Bool, got: $raw_value")
end

function _dfba_persistence_benchmark_profile()::String
    profile = lowercase(strip(get(ENV, "DFBA_PERSISTENCE_BENCH_PROFILE", "short")))
    isempty(profile) && error("Environment variable DFBA_PERSISTENCE_BENCH_PROFILE must not be empty.")
    return profile
end

function _dfba_persistence_is_72h_profile(benchmark_profile::AbstractString)::Bool
    return lowercase(strip(String(benchmark_profile))) in ("72h", "long_72h")
end

function _dfba_persistence_ode_algorithm_config(is_72h_profile::Bool)
    default_algorithm = "Tsit5"
    raw_value = strip(get(ENV, "DFBA_PERSISTENCE_BENCH_ALGORITHM", default_algorithm))
    normalized = lowercase(raw_value)
    if normalized in ("default", "tsit5")
        return (algorithm = OrdinaryDiffEq.Tsit5(), algorithm_label = "Tsit5")
    elseif normalized == "rodas5p"
        return (
            algorithm = OrdinaryDiffEq.Rodas5P(autodiff = OrdinaryDiffEq.AutoFiniteDiff()),
            algorithm_label = "Rodas5P",
        )
    else
        error("Environment variable DFBA_PERSISTENCE_BENCH_ALGORITHM must be one of: Tsit5, default, Rodas5P. Got: $raw_value")
    end
end

function _dfba_persistence_output_dir(project_root::AbstractString, benchmark_profile::AbstractString)
    default_output_dir = _dfba_persistence_is_72h_profile(benchmark_profile) ?
        DEFAULT_DFBA_PERSISTENCE_BENCHMARK_72H_OUTPUT_DIR :
        DEFAULT_DFBA_PERSISTENCE_BENCHMARK_OUTPUT_DIR
    raw_value = strip(get(ENV, "DFBA_PERSISTENCE_BENCH_OUTPUT_DIR", default_output_dir))
    isempty(raw_value) && error("Environment variable DFBA_PERSISTENCE_BENCH_OUTPUT_DIR must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _dfba_persistence_summary_row(table, scenario_id::AbstractString)
    row_index = findfirst(==(String(scenario_id)), String.(table[!, "scenario_id"]))
    row_index === nothing && error("Missing DFBA persistence benchmark scenario $(String(scenario_id)).")
    return table[row_index, :]
end

function _dfba_persistence_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _dfba_persistence_sorted_paths(paths::Dict{String, String})
    return [key => paths[key] for key in sort(collect(keys(paths)))]
end

benchmark_profile = _dfba_persistence_benchmark_profile()
is_72h_profile = _dfba_persistence_is_72h_profile(benchmark_profile)
algorithm_config = _dfba_persistence_ode_algorithm_config(is_72h_profile)
default_tfinal = is_72h_profile ? 72.0 : 0.25
default_saveat = is_72h_profile ? 1.0 : 0.25

tfinal = _dfba_persistence_env_float("DFBA_PERSISTENCE_BENCH_TFINAL_HOURS", default_tfinal)
saveat = _dfba_persistence_env_float("DFBA_PERSISTENCE_BENCH_SAVEAT_HOURS", default_saveat)
lp_atol = _dfba_persistence_env_float("DFBA_PERSISTENCE_BENCH_LP_ATOL", 1.0e-8)
ode_abstol = _dfba_persistence_env_float("DFBA_PERSISTENCE_BENCH_ODE_ABSTOL", 1.0e-8)
ode_reltol = _dfba_persistence_env_float("DFBA_PERSISTENCE_BENCH_ODE_RELTOL", 1.0e-8)
trajectory_match_atol = _dfba_persistence_env_nonnegative_float(
    "DFBA_PERSISTENCE_BENCH_TRAJECTORY_MATCH_ATOL",
    1.0e-5,
)
fba_variant = lowercase(strip(get(ENV, "DFBA_PERSISTENCE_BENCH_FBA_VARIANT", "fba")))
default_quadratic_penalty = fba_variant == "qpfba" ? 1.0e-5 : 1.0e-8
quadratic_penalty = _dfba_persistence_env_float(
    "DFBA_PERSISTENCE_BENCH_QUADRATIC_PENALTY",
    default_quadratic_penalty,
)
l1_penalty = fba_variant == "l1pfba" ?
    _dfba_persistence_env_float("DFBA_PERSISTENCE_BENCH_L1_PENALTY", 1.0e-6) :
    0.0
full_persistent_max_abs_state_tolerance = _dfba_persistence_env_nonnegative_float(
    "DFBA_PERSISTENCE_BENCH_FULL_PERSISTENT_MAX_ABS_STATE_TOL",
    is_72h_profile ? 1.0e-4 : trajectory_match_atol,
)
full_persistent_state_rmse_tolerance = _dfba_persistence_env_nonnegative_float(
    "DFBA_PERSISTENCE_BENCH_FULL_PERSISTENT_STATE_RMSE_TOL",
    is_72h_profile ? 1.0e-5 : trajectory_match_atol,
)
full_persistent_final_state_tolerance = _dfba_persistence_env_nonnegative_float(
    "DFBA_PERSISTENCE_BENCH_FULL_PERSISTENT_FINAL_STATE_TOL",
    is_72h_profile ? 1.0e-4 : trajectory_match_atol,
)
reduced_similarity_max_abs_state_tolerance = _dfba_persistence_env_nonnegative_float(
    "DFBA_PERSISTENCE_BENCH_REDUCED_MAX_ABS_STATE_TOL",
    is_72h_profile ? 1.0e-2 : 1.0e-2,
)
reduced_similarity_state_rmse_tolerance = _dfba_persistence_env_nonnegative_float(
    "DFBA_PERSISTENCE_BENCH_REDUCED_STATE_RMSE_TOL",
    is_72h_profile ? 1.0e-3 : 1.0e-3,
)
reduced_similarity_final_state_tolerance = _dfba_persistence_env_nonnegative_float(
    "DFBA_PERSISTENCE_BENCH_REDUCED_FINAL_STATE_TOL",
    is_72h_profile ? 1.0e-2 : 1.0e-2,
)
reconstruct_fluxes = _dfba_persistence_env_bool("DFBA_PERSISTENCE_BENCH_RECONSTRUCT_FLUXES", false)
adaptive = _dfba_persistence_env_bool("DFBA_PERSISTENCE_BENCH_ADAPTIVE", !is_72h_profile)
dt = _dfba_persistence_env_optional_float("DFBA_PERSISTENCE_BENCH_DT_HOURS")
if !adaptive && dt === nothing
    dt = saveat
end
persistent_primal_start = _dfba_persistence_env_bool("DFBA_PERSISTENCE_BENCH_PRIMAL_START", true)
persistent_basis_warm_start = _dfba_persistence_env_bool("DFBA_PERSISTENCE_BENCH_BASIS_WARM_START", false)
lp_reuse_highs_solver = strip(get(ENV, "DFBA_PERSISTENCE_BENCH_HIGHS_SOLVER", "simplex"))
lp_simplex_strategy = strip(get(ENV, "DFBA_PERSISTENCE_BENCH_SIMPLEX_STRATEGY", "default"))
progress_interval_seconds = _dfba_persistence_env_nonnegative_float(
    "DFBA_PERSISTENCE_BENCH_PROGRESS_INTERVAL_SECONDS",
    is_72h_profile ? 60.0 : 0.0,
)
max_rhs_calls = _dfba_persistence_env_optional_int("DFBA_PERSISTENCE_BENCH_MAX_RHS_CALLS")
max_walltime_seconds = _dfba_persistence_env_optional_float("DFBA_PERSISTENCE_BENCH_MAX_WALLTIME_SECONDS")
output_dir = _dfba_persistence_output_dir(project_root, benchmark_profile)

full_model = load_full_model(full_paths_config)
full_reaction_map = load_reaction_map(full_reaction_map_config)
full_reaction_report = validate_reaction_map(full_model, full_reaction_map)
full_reaction_report.ok || error(
    "Full reaction map validation failed. Missing reactions: $(full_reaction_report.missing_required_reactions)",
)

reduced_model = load_reduced_model(reduced_paths_config)
reduced_reaction_map = load_reaction_map(reduced_reaction_map_config)
reduced_reaction_report = validate_reaction_map(reduced_model, reduced_reaction_map)
reduced_reaction_report.ok || error(
    "Reduced reaction map validation failed. Missing reactions: $(reduced_reaction_report.missing_required_reactions)",
)

benchmark = benchmark_dfba_persistence(
    full_model,
    full_reaction_map,
    reduced_model,
    reduced_reaction_map;
    tspan = (0.0, tfinal),
    saveat = saveat,
    lp_atol = lp_atol,
    ode_abstol = ode_abstol,
    ode_reltol = ode_reltol,
    algorithm = algorithm_config.algorithm,
    algorithm_label = algorithm_config.algorithm_label,
    adaptive = adaptive,
    dt = dt,
    fba_variant = fba_variant,
    quadratic_penalty = quadratic_penalty,
    l1_penalty = l1_penalty,
    reconstruct_fluxes = reconstruct_fluxes,
    persistent_primal_start = persistent_primal_start,
    persistent_basis_warm_start = persistent_basis_warm_start,
    lp_reuse_highs_solver = lp_reuse_highs_solver,
    lp_simplex_strategy = lp_simplex_strategy,
    trajectory_match_atol = trajectory_match_atol,
    benchmark_profile = benchmark_profile,
    full_persistent_max_abs_state_tolerance = full_persistent_max_abs_state_tolerance,
    full_persistent_state_rmse_tolerance = full_persistent_state_rmse_tolerance,
    full_persistent_final_state_tolerance = full_persistent_final_state_tolerance,
    reduced_similarity_max_abs_state_tolerance = reduced_similarity_max_abs_state_tolerance,
    reduced_similarity_state_rmse_tolerance = reduced_similarity_state_rmse_tolerance,
    reduced_similarity_final_state_tolerance = reduced_similarity_final_state_tolerance,
    progress_interval_seconds = progress_interval_seconds,
    max_rhs_calls = max_rhs_calls,
    max_walltime_seconds = max_walltime_seconds,
)
paths = export_dfba_persistence_benchmark(benchmark, output_dir; overwrite = true)
plot_paths = write_dfba_persistence_benchmark_plots(benchmark, output_dir; overwrite = true)

println("DFBA full-vs-reduced persistence benchmark")
println("output_dir: $output_dir")
println("benchmark_name: $(benchmark.metadata["benchmark_name"])")
println("benchmark_profile: $(benchmark.metadata["benchmark_profile"])")
println("baseline_scenario_id: $(benchmark.metadata["baseline_scenario_id"])")
println("scientific_model_baseline: $(benchmark.metadata["scientific_model_baseline"])")
println("performance_reference_scenario: $(benchmark.metadata["performance_reference_scenario"])")
println("full_persistent_candidate_scenario: $(benchmark.metadata["full_persistent_candidate_scenario"])")
println("reduced_persistent_candidate_scenario: $(benchmark.metadata["reduced_persistent_candidate_scenario"])")
println("tspan: 0.0 to $tfinal h")
println("saveat: $saveat h")
println("algorithm_label: $(benchmark.metadata["algorithm_label"])")
println("adaptive: $(benchmark.metadata["adaptive"])")
println("dt: $(get(benchmark.metadata, "dt", nothing))")
println("fba_variant: $(benchmark.metadata["fba_variant"])")
println("quadratic_penalty: $(benchmark.metadata["quadratic_penalty"])")
println("l1_penalty: $(benchmark.metadata["l1_penalty"])")
println("lp_atol: $lp_atol")
println("ode_abstol: $ode_abstol")
println("ode_reltol: $ode_reltol")
println("trajectory_match_atol: $trajectory_match_atol")
println("full_persistent_max_abs_state_tolerance: $(benchmark.metadata["full_persistent_max_abs_state_tolerance"])")
println("full_persistent_state_rmse_tolerance: $(benchmark.metadata["full_persistent_state_rmse_tolerance"])")
println("full_persistent_final_state_tolerance: $(benchmark.metadata["full_persistent_final_state_tolerance"])")
println("reduced_similarity_max_abs_state_tolerance: $(benchmark.metadata["reduced_similarity_max_abs_state_tolerance"])")
println("reduced_similarity_state_rmse_tolerance: $(benchmark.metadata["reduced_similarity_state_rmse_tolerance"])")
println("reduced_similarity_final_state_tolerance: $(benchmark.metadata["reduced_similarity_final_state_tolerance"])")
println("progress_interval_seconds: $(benchmark.metadata["progress_interval_seconds"])")
println("max_rhs_calls: $(get(benchmark.metadata, "max_rhs_calls", nothing))")
println("max_walltime_seconds: $(get(benchmark.metadata, "max_walltime_seconds", nothing))")
println("reconstruct_fluxes: $reconstruct_fluxes")
println("persistent_primal_start: $(benchmark.metadata["persistent_primal_start"])")
println("persistent_basis_warm_start: $(benchmark.metadata["persistent_basis_warm_start"])")
println("lp_reuse_highs_solver: $(benchmark.metadata["lp_reuse_highs_solver"])")
println("lp_simplex_strategy: $(benchmark.metadata["lp_simplex_strategy"])")
println("gurobi_required: $(benchmark.metadata["gurobi_required"])")
println("ipopt_required: $(benchmark.metadata["ipopt_required"])")
println("hsl_required: $(benchmark.metadata["hsl_required"])")

println("scenario_summary:")
println(
    "  scenario_id | retcode | rhs_call_count | total_lp_solve_count | " *
    "benchmark_elapsed_seconds | final_biomass | final_total_sugar | final_ethanol | " *
    "max_abs_state_difference_vs_full_cold | state_rmse_vs_full_cold | " *
    "runtime_speedup_vs_full_cold | qpfba_persistent_fallback_count | l1_penalty | " *
    "acceptance_required | acceptance_passed_vs_full_cold",
)
for scenario_id in benchmark.metadata["scenario_ids"]
    row = _dfba_persistence_summary_row(benchmark.summary_table, scenario_id)
    println(
        "  $scenario_id | $(_dfba_persistence_value(row["retcode"])) | " *
        "$(_dfba_persistence_value(row["rhs_call_count"])) | " *
        "$(_dfba_persistence_value(row["total_lp_solve_count"])) | " *
        "$(_dfba_persistence_value(row["benchmark_elapsed_seconds"])) | " *
        "$(_dfba_persistence_value(row["final_biomass"])) | " *
        "$(_dfba_persistence_value(row["final_total_sugar"])) | " *
        "$(_dfba_persistence_value(row["final_ethanol"])) | " *
        "$(_dfba_persistence_value(row["max_abs_state_difference_vs_full_cold"])) | " *
        "$(_dfba_persistence_value(row["state_rmse_vs_full_cold"])) | " *
        "$(_dfba_persistence_value(row["runtime_speedup_vs_full_cold"])) | " *
        "$(_dfba_persistence_value(row["qpfba_persistent_fallback_count"])) | " *
        "$(_dfba_persistence_value(row["l1_penalty"])) | " *
        "$(_dfba_persistence_value(row["acceptance_required"])) | " *
        "$(_dfba_persistence_value(row["acceptance_passed_vs_full_cold"]))",
    )
end

println("written_files:")
for (key, path) in _dfba_persistence_sorted_paths(paths)
    println("  $key = $path")
end
println("written_svg_files:")
for (key, path) in _dfba_persistence_sorted_paths(plot_paths)
    println("  $key = $path")
end
println("matlab_role_note: $(benchmark.metadata["matlab_role_note"])")
println("dfvb_reduction_role_note: $(benchmark.metadata["dfvb_reduction_role_note"])")
println("mpcc_scope_note: $(benchmark.metadata["mpcc_scope_note"])")
println("r0001_used_as_oxygen: $(benchmark.metadata["r0001_used_as_oxygen"])")
println("oxygen_reaction_id: $(benchmark.metadata["oxygen_reaction_id"])")
