using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_MESH_PROFILE = "smoke"
const DEFAULT_MPCC_MESH_IPOPT_MAX_ITER = 100

function _mpcc_mesh_profile()
    raw = strip(get(ENV, "MPCC_MESH_PROFILE", DEFAULT_MPCC_MESH_PROFILE))
    normalized = lowercase(raw)
    normalized in ("smoke", "focused", "custom") ||
        error("Environment variable MPCC_MESH_PROFILE must be one of: smoke, focused, custom. Got: $raw")
    return normalized
end

function _mpcc_mesh_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (horizons = "0.5", nfe_values = "1,2", max_scenarios = 2)
    elseif profile == "focused"
        return (horizons = "0.5,1.0", nfe_values = "1,2,4", max_scenarios = 6)
    else
        return (horizons = "0.5", nfe_values = "1,2", max_scenarios = 2)
    end
end

function _mpcc_mesh_env_float_list(name::AbstractString, default_value::AbstractString)::Vector{Float64}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && error("Environment variable $name contains a non-Float64 value: $stripped")
        isfinite(value) && value > 0.0 ||
            error("Environment variable $name values must be finite and positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_mesh_env_int_list(name::AbstractString, default_value::AbstractString)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Int, stripped)
        value === nothing && error("Environment variable $name contains a non-Int value: $stripped")
        value > 0 || error("Environment variable $name values must be positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    length(unique(values)) >= 2 ||
        error("Environment variable $name must contain at least two distinct finite-element counts.")
    return sort(unique(values))
end

function _mpcc_mesh_env_positive_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_mesh_script_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_mesh_validate_grid!(
    horizons::Vector{Float64},
    nfe_values::Vector{Int},
    max_scenarios::Int,
    allow_large_grid::Bool,
)
    n_scenarios = length(horizons) * length(nfe_values)
    if n_scenarios > max_scenarios && !allow_large_grid
        error(
            "Requested MPCC mesh refinement sensitivity has $n_scenarios scenarios, above " *
            "MPCC_MESH_MAX_SCENARIOS=$max_scenarios. Set MPCC_MESH_ALLOW_LARGE_GRID=1 " *
            "only for deliberate longer local diagnostics.",
        )
    end
    return nothing
end

profile = _mpcc_mesh_profile()
defaults = _mpcc_mesh_profile_defaults(profile)
horizons = _mpcc_mesh_env_float_list("MPCC_MESH_HORIZONS_HOURS", defaults.horizons)
nfe_values = _mpcc_mesh_env_int_list("MPCC_MESH_NFE_VALUES", defaults.nfe_values)
max_scenarios = _mpcc_mesh_env_positive_int("MPCC_MESH_MAX_SCENARIOS", defaults.max_scenarios)
allow_large_grid = _script_env_bool("MPCC_MESH_ALLOW_LARGE_GRID", false)
continue_on_error = _script_env_bool("MPCC_MESH_CONTINUE_ON_ERROR", true)
require_pre_solve_ready = _script_env_bool("MPCC_MESH_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_MESH_SILENT", true)
ipopt_max_iter = _mpcc_mesh_env_positive_int("MPCC_MESH_IPOPT_MAX_ITER", DEFAULT_MPCC_MESH_IPOPT_MAX_ITER)

_mpcc_mesh_validate_grid!(horizons, nfe_values, max_scenarios, allow_large_grid)

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

sensitivity = sweep_reduced_dcdfba_mpcc_mesh_refinement(
    model,
    reaction_map;
    horizons = horizons,
    nfe_values = nfe_values,
    degree = 3,
    ipopt_max_iter = ipopt_max_iter,
    require_pre_solve_ready = require_pre_solve_ready,
    silent = silent,
    continue_on_error = continue_on_error,
)

println("Reduced MPCC mesh refinement sensitivity")
println("profile: $profile")
println("horizons_hours: $(join(horizons, ","))")
println("nfe_values: $(join(nfe_values, ","))")
println("ipopt_max_iter: $ipopt_max_iter")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("outputs_written: $(sensitivity.metadata["outputs_written"])")
println("mesh_sensitivity_is_scientific_simulation: $(sensitivity.metadata["mesh_sensitivity_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(sensitivity.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(sensitivity.metadata["scientific_baseline"])")
println("first_mpcc_target: $(sensitivity.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(sensitivity.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(sensitivity.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(sensitivity.metadata["hsl_required"])")
println("ma57_required: $(sensitivity.metadata["ma57_required"])")
println("indices_reacciones_used: $(sensitivity.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(sensitivity.metadata["r0001_used_as_oxygen"])")
println("n_rows: $(sensitivity.metadata["n_rows"])")
println("n_completed_rows: $(sensitivity.metadata["n_completed_rows"])")
println("n_failed_rows: $(sensitivity.metadata["n_failed_rows"])")
println("residual_feasible_row_count: $(sensitivity.metadata["residual_feasible_row_count"])")
println("trajectory_ready_row_count: $(sensitivity.metadata["trajectory_ready_row_count"])")
println("mesh_trajectory_ready_improvement_count: $(sensitivity.metadata["mesh_trajectory_ready_improvement_count"])")
println("mesh_state_relative_rmse_improvement_count: $(sensitivity.metadata["mesh_state_relative_rmse_improvement_count"])")
println("best_row_mesh_case_id: $(_mpcc_mesh_script_value(sensitivity.metadata["best_row_mesh_case_id"]))")
println("best_row_horizon: $(_mpcc_mesh_script_value(sensitivity.metadata["best_row_horizon"]))")
println("best_row_nfe: $(_mpcc_mesh_script_value(sensitivity.metadata["best_row_nfe"]))")
println("best_row_max_state_relative_rmse: $(_mpcc_mesh_script_value(sensitivity.metadata["best_row_max_state_relative_rmse"]))")

println("mesh_table:")
for row in eachrow(sensitivity.mesh_table)
    println(
        "  $(row["mesh_case_id"]) | horizon=$(_mpcc_mesh_script_value(row["horizon"])) | " *
        "nfe=$(_mpcc_mesh_script_value(row["nfe"])) | solver=$(_mpcc_mesh_script_value(row["solver_status"])) | " *
        "primal=$(_mpcc_mesh_script_value(row["primal_status"])) | solve_s=$(_mpcc_mesh_script_value(row["solve_elapsed_seconds"])) | " *
        "residual_feasible=$(_mpcc_mesh_script_value(row["candidate_residual_feasible"])) | " *
        "trajectory_ready=$(_mpcc_mesh_script_value(row["candidate_trajectory_ready"])) | " *
        "ready_improved=$(_mpcc_mesh_script_value(row["trajectory_ready_improved_vs_coarser_nfe"])) | " *
        "rmse_improved=$(_mpcc_mesh_script_value(row["state_relative_rmse_improved_vs_coarser_nfe"])) | " *
        "max_state_abs=$(_mpcc_mesh_script_value(row["max_state_abs_difference"])) | " *
        "max_state_rel_rmse=$(_mpcc_mesh_script_value(row["max_state_relative_rmse"])) | " *
        "max_rhs=$(_mpcc_mesh_script_value(row["max_rhs_residual"])) | " *
        "max_mass=$(_mpcc_mesh_script_value(row["max_mass_balance_residual"])) | " *
        "max_comp_l=$(_mpcc_mesh_script_value(row["max_lower_complementarity_residual"])) | " *
        "max_comp_u=$(_mpcc_mesh_script_value(row["max_upper_complementarity_residual"])) | " *
        "action=$(_mpcc_mesh_script_value(row["next_recommended_action"]))",
    )
end

println("first_trajectory_ready_nfe_by_horizon:")
for key in sort(collect(keys(sensitivity.metadata["first_trajectory_ready_nfe_by_horizon"])))
    value = sensitivity.metadata["first_trajectory_ready_nfe_by_horizon"][key]
    println("  $key => $(_mpcc_mesh_script_value(value))")
end

println("best_state_match_nfe_by_horizon:")
for key in sort(collect(keys(sensitivity.metadata["best_state_match_nfe_by_horizon"])))
    value = sensitivity.metadata["best_state_match_nfe_by_horizon"][key]
    println("  $key => $(_mpcc_mesh_script_value(value))")
end

println("interpretation_note: $(sensitivity.metadata["interpretation_note"])")
