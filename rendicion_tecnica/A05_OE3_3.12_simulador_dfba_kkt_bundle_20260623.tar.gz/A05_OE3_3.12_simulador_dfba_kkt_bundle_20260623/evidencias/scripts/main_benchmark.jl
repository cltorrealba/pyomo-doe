using FermentationDFBA
using CSV
using DataFrames
using TOML
import OrdinaryDiffEq

include(joinpath(@__DIR__, "solver_backend_helpers.jl"))

const BENCHMARK_NAME = "sequential_reduced_dfba"
const DEFAULT_BENCHMARK_OUTPUT_DIR = joinpath("results", "benchmarks", "reduced_dfba_latest")
const DEFAULT_BENCHMARK_SOLVER_BACKEND = "HiGHS"
const DEFAULT_BENCHMARK_ALGORITHM = "Rodas5P"
const DEFAULT_BENCHMARK_ODE_ABSTOL = 1.0e-8
const DEFAULT_BENCHMARK_ODE_RELTOL = 1.0e-8
const DEFAULT_BENCHMARK_LP_ATOL = 1.0e-8
const BENCHMARK_SUMMARY_COLUMNS = [
    "scenario_id",
    "model_id",
    "solver_label",
    "algorithm_label",
    "tspan_start",
    "tspan_end",
    "saveat",
    "ode_abstol",
    "ode_reltol",
    "lp_atol",
    "reconstruct_fluxes",
    "retcode",
    "termination_reason",
    "final_time",
    "n_saved_points",
    "n_states",
    "n_fluxes",
    "final_biomass",
    "final_glucose",
    "final_fructose",
    "final_total_sugar",
    "sugar_consumed",
    "final_ethanol",
    "ethanol_produced",
    "mode_count_growth",
    "mode_count_turnover",
    "mode_count_sugar_depleted",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "min_state_value",
    "has_negative_saved_states",
    "simulation_elapsed_seconds",
    "ode_solve_elapsed_seconds",
    "rhs_elapsed_seconds",
    "history_reconstruction_elapsed_seconds",
    "scenario_elapsed_seconds",
    "rhs_call_count",
    "rhs_lp_solve_count",
    "flux_reconstruction_solve_count",
    "total_lp_solve_count",
    "oxygen_derivative_policy",
    "carbohydrate_derivative_policy",
]

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _env_float(name::AbstractString, default::Float64)
    raw_value = strip(get(ENV, String(name), string(default)))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 || error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _benchmark_output_dir(project_root::AbstractString)
    raw_value = strip(get(ENV, "DFBA_BENCH_OUTPUT_DIR", DEFAULT_BENCHMARK_OUTPUT_DIR))
    isempty(raw_value) && error("Environment variable DFBA_BENCH_OUTPUT_DIR must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _env_enabled_one(name::AbstractString)::Bool
    raw_value = strip(get(ENV, String(name), "0"))
    raw_value in ("", "0") && return false
    raw_value == "1" && return true
    error("Environment variable $name must be unset, 0, or 1. Got: $raw_value")
end

function _benchmark_backend_labels()
    raw_value = get(ENV, "DFBA_BENCH_SOLVER_BACKENDS", DEFAULT_BENCHMARK_SOLVER_BACKEND)
    return _parse_solver_backend_list(raw_value)
end

function _benchmark_backend_configs(backend_values::AbstractVector{<:AbstractString})
    configs = []
    for backend in backend_values
        optimizer_backend, solver_label = _resolve_solver_backend(backend)
        backend_id = lowercase(solver_label)
        push!(
            configs,
            (backend_id = backend_id, solver_label = solver_label, optimizer = optimizer_backend),
        )
    end
    return configs
end

function _benchmark_algorithm_config()
    raw_value = strip(get(ENV, "DFBA_BENCH_ALGORITHM", DEFAULT_BENCHMARK_ALGORITHM))
    normalized = lowercase(raw_value)
    if normalized in ("default", "rodas5p")
        return (
            algorithm = OrdinaryDiffEq.Rodas5P(autodiff = OrdinaryDiffEq.AutoFiniteDiff()),
            algorithm_label = "Rodas5P",
        )
    elseif normalized == "tsit5"
        return (algorithm = OrdinaryDiffEq.Tsit5(), algorithm_label = "Tsit5")
    else
        error("DFBA_BENCH_ALGORITHM must be one of: Rodas5P, default, Tsit5. Got: $raw_value")
    end
end

function _benchmark_tolerance_config()
    return (
        ode_abstol = _env_float("DFBA_BENCH_ODE_ABSTOL", DEFAULT_BENCHMARK_ODE_ABSTOL),
        ode_reltol = _env_float("DFBA_BENCH_ODE_RELTOL", DEFAULT_BENCHMARK_ODE_RELTOL),
        lp_atol = _env_float("DFBA_BENCH_LP_ATOL", DEFAULT_BENCHMARK_LP_ATOL),
    )
end

function _guard_gurobi_rodas5p_benchmark(
    backend_values::AbstractVector{<:AbstractString},
    algorithm_label::AbstractString,
    allow_gurobi_rodas5p::Bool,
)
    if "Gurobi" in String.(backend_values) && String(algorithm_label) == "Rodas5P" && !allow_gurobi_rodas5p
        error(
            "Gurobi benchmark with Rodas5P is disabled by default because local tests indicate this path " *
            "can hang or take too long in the LP-in-the-loop workflow. Run local Gurobi comparisons with " *
            "DFBA_BENCH_ALGORITHM=Tsit5. To deliberately override this guard, set " *
            "DFBA_BENCH_ALLOW_GUROBI_RODAS5P=1.",
        )
    end
    return nothing
end

function _benchmark_scenarios()
    value = lowercase(strip(get(ENV, "DFBA_BENCH_RECONSTRUCT", "both")))
    if value == "both"
        return [
            (scenario_id = "reconstruct_true", reconstruct_fluxes = true),
            (scenario_id = "reconstruct_false", reconstruct_fluxes = false),
        ]
    elseif value == "true"
        return [(scenario_id = "reconstruct_true", reconstruct_fluxes = true)]
    elseif value == "false"
        return [(scenario_id = "reconstruct_false", reconstruct_fluxes = false)]
    else
        error("DFBA_BENCH_RECONSTRUCT must be one of: both, true, false. Got: $value")
    end
end

function _mode_count(summary::Dict{String, Any}, mode::Symbol)::Int
    counts = get(summary, "mode_counts", Dict{Symbol, Int}())
    counts isa AbstractDict || return 0
    return get(counts, mode, get(counts, String(mode), 0))
end

function _table_scalar(value)
    if value === nothing || value === missing
        return missing
    elseif value isa Symbol
        return String(value)
    else
        return value
    end
end

function _benchmark_row(
    scenario,
    model_id::AbstractString,
    tspan::Tuple{Float64, Float64},
    saveat::Float64,
    algorithm_label::AbstractString,
    ode_abstol::Float64,
    ode_reltol::Float64,
    lp_atol::Float64,
    summary::Dict{String, Any},
    scenario_elapsed_seconds::Float64,
)::Dict{String, Any}
    return Dict{String, Any}(
        "scenario_id" => scenario.scenario_id,
        "model_id" => String(model_id),
        "solver_label" => scenario.solver_label,
        "algorithm_label" => String(algorithm_label),
        "tspan_start" => tspan[1],
        "tspan_end" => tspan[2],
        "saveat" => saveat,
        "ode_abstol" => ode_abstol,
        "ode_reltol" => ode_reltol,
        "lp_atol" => lp_atol,
        "reconstruct_fluxes" => scenario.reconstruct_fluxes,
        "retcode" => get(summary, "retcode", missing),
        "termination_reason" => get(summary, "termination_reason", missing),
        "final_time" => get(summary, "final_time", missing),
        "n_saved_points" => get(summary, "n_saved_points", missing),
        "n_states" => get(summary, "n_states", missing),
        "n_fluxes" => get(summary, "n_fluxes", missing),
        "final_biomass" => get(summary, "final_biomass", missing),
        "final_glucose" => get(summary, "final_glucose", missing),
        "final_fructose" => get(summary, "final_fructose", missing),
        "final_total_sugar" => get(summary, "final_total_sugar", missing),
        "sugar_consumed" => get(summary, "sugar_consumed", missing),
        "final_ethanol" => get(summary, "final_ethanol", missing),
        "ethanol_produced" => get(summary, "ethanol_produced", missing),
        "mode_count_growth" => _mode_count(summary, :growth),
        "mode_count_turnover" => _mode_count(summary, :turnover),
        "mode_count_sugar_depleted" => _mode_count(summary, :sugar_depleted),
        "max_mass_balance_residual" => get(summary, "max_mass_balance_residual", missing),
        "max_lower_bound_violation" => get(summary, "max_lower_bound_violation", missing),
        "max_upper_bound_violation" => get(summary, "max_upper_bound_violation", missing),
        "min_state_value" => get(summary, "min_state_value", missing),
        "has_negative_saved_states" => get(summary, "has_negative_saved_states", missing),
        "simulation_elapsed_seconds" => get(summary, "simulation_elapsed_seconds", missing),
        "ode_solve_elapsed_seconds" => get(summary, "ode_solve_elapsed_seconds", missing),
        "rhs_elapsed_seconds" => get(summary, "rhs_elapsed_seconds", missing),
        "history_reconstruction_elapsed_seconds" =>
            get(summary, "history_reconstruction_elapsed_seconds", missing),
        "scenario_elapsed_seconds" => scenario_elapsed_seconds,
        "rhs_call_count" => get(summary, "rhs_call_count", missing),
        "rhs_lp_solve_count" => get(summary, "rhs_lp_solve_count", missing),
        "flux_reconstruction_solve_count" => get(summary, "flux_reconstruction_solve_count", missing),
        "total_lp_solve_count" => get(summary, "total_lp_solve_count", missing),
        "oxygen_derivative_policy" => get(summary, "oxygen_derivative_policy", missing),
        "carbohydrate_derivative_policy" => get(summary, "carbohydrate_derivative_policy", missing),
    )
end

function _benchmark_summary_table(rows::Vector{Dict{String, Any}})::DataFrame
    return DataFrame(
        (
            column => [_table_scalar(get(row, column, missing)) for row in rows] for
            column in BENCHMARK_SUMMARY_COLUMNS
        )...,
    )
end

function _toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return value
    elseif value isa Tuple
        return _toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end

function _write_benchmark_metadata(
    path::AbstractString;
    tfinal::Float64,
    saveat::Float64,
    algorithm_label::AbstractString,
    ode_abstol::Float64,
    ode_reltol::Float64,
    lp_atol::Float64,
    allow_gurobi_rodas5p::Bool,
    selected_solver_backends::AbstractVector,
    actual_solver_labels::AbstractVector,
    scenario_ids::AbstractVector,
)
    metadata = Dict{String, Any}(
        "benchmark_name" => BENCHMARK_NAME,
        "created_by_script" => "scripts/main_benchmark.jl",
        "tfinal_hours" => tfinal,
        "saveat_hours" => saveat,
        "algorithm_label" => String(algorithm_label),
        "selected_algorithms" => [String(algorithm_label)],
        "default_algorithm_label" => DEFAULT_BENCHMARK_ALGORITHM,
        "ode_abstol" => ode_abstol,
        "ode_reltol" => ode_reltol,
        "lp_atol" => lp_atol,
        "allow_gurobi_rodas5p" => allow_gurobi_rodas5p,
        "scenario_ids" => String.(scenario_ids),
        "selected_solver_backends" => String.(selected_solver_backends),
        "solver_labels" => String.(actual_solver_labels),
        "solver_label" => join(actual_solver_labels, ","),
        "optional_solver_backend_note" =>
            "Gurobi is optional, user-provided, and not required for default benchmarks.",
        "notes" => [
            "Plotting-free benchmark for sequential reduced DFBA.",
            "Default scenarios compare reconstruct_fluxes=true and reconstruct_fluxes=false.",
            "reconstruct_fluxes=false skips saved-state flux and diagnostic reconstruction.",
            "Optional backend comparisons run only when requested with DFBA_BENCH_SOLVER_BACKENDS.",
            "DFBA_BENCH_ALGORITHM selects the ODE algorithm used for every scenario.",
            "Benchmark rows include algorithm_label, ode_abstol, ode_reltol, and lp_atol for reproducible comparisons.",
            "Tsit5 is an explicit non-stiff Runge-Kutta method and is recommended for local Gurobi comparisons.",
            "Gurobi with Rodas5P is guarded by default because local benchmarks can hang or take too long.",
            "Gurobi is loaded only when explicitly requested.",
            "HiGHS remains the default solver.",
        ],
    )
    open(path, "w") do io
        TOML.print(io, _toml_normalize(metadata))
    end
    return path
end

tfinal = _env_float("DFBA_BENCH_TFINAL_HOURS", 2.0)
saveat = _env_float("DFBA_BENCH_SAVEAT_HOURS", 1.0)
tspan = (0.0, tfinal)
output_dir = _benchmark_output_dir(project_root)
backend_values = _benchmark_backend_labels()
algorithm_config = _benchmark_algorithm_config()
tolerance_config = _benchmark_tolerance_config()
allow_gurobi_rodas5p = _env_enabled_one("DFBA_BENCH_ALLOW_GUROBI_RODAS5P")
_guard_gurobi_rodas5p_benchmark(backend_values, algorithm_config.algorithm_label, allow_gurobi_rodas5p)
backend_configs = _benchmark_backend_configs(backend_values)
reconstruction_scenarios = _benchmark_scenarios()
scenarios = [
    (
        scenario_id = "$(backend.backend_id)_$(reconstruction.scenario_id)",
        reconstruct_fluxes = reconstruction.reconstruct_fluxes,
        solver_label = backend.solver_label,
        optimizer = backend.optimizer,
    ) for backend in backend_configs for reconstruction in reconstruction_scenarios
]

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

rows = Dict{String, Any}[]
println("Sequential reduced DFBA benchmark")
println("model_id: $(model.model_id)")
println("solver_backends: $(join([backend.solver_label for backend in backend_configs], ","))")
println("algorithm: $(algorithm_config.algorithm_label)")
println("ode_abstol: $(tolerance_config.ode_abstol)")
println("ode_reltol: $(tolerance_config.ode_reltol)")
println("lp_atol: $(tolerance_config.lp_atol)")
println("tspan: $(tspan[1]) to $(tspan[2]) h")
println("saveat: $saveat h")
println("output_dir: $output_dir")
println("scenario_count: $(length(scenarios))")

for scenario in scenarios
    println("running_scenario: $(scenario.scenario_id)")
    result = nothing
    scenario_kwargs = (
        tspan = tspan,
        saveat = saveat,
        reconstruct_fluxes = scenario.reconstruct_fluxes,
        algorithm = algorithm_config.algorithm,
        ode_abstol = tolerance_config.ode_abstol,
        ode_reltol = tolerance_config.ode_reltol,
        lp_atol = tolerance_config.lp_atol,
    )
    scenario_elapsed_seconds = @elapsed begin
        result = scenario.optimizer === nothing ?
            simulate_reduced_dfba(model, reaction_map; scenario_kwargs...) :
            simulate_reduced_dfba(model, reaction_map; optimizer = scenario.optimizer, scenario_kwargs...)
    end
    result.metadata["solver_label"] = scenario.solver_label
    summary = summarize_simulation(result)
    push!(
        rows,
        _benchmark_row(
            scenario,
            model.model_id,
            tspan,
            saveat,
            algorithm_config.algorithm_label,
            tolerance_config.ode_abstol,
            tolerance_config.ode_reltol,
            tolerance_config.lp_atol,
            summary,
            scenario_elapsed_seconds,
        ),
    )
end

mkpath(output_dir)
summary_path = joinpath(output_dir, "benchmark_summary.csv")
metadata_path = joinpath(output_dir, "benchmark_metadata.toml")
CSV.write(summary_path, _benchmark_summary_table(rows))
_write_benchmark_metadata(
    metadata_path;
    tfinal = tfinal,
    saveat = saveat,
    algorithm_label = algorithm_config.algorithm_label,
    ode_abstol = tolerance_config.ode_abstol,
    ode_reltol = tolerance_config.ode_reltol,
    lp_atol = tolerance_config.lp_atol,
    allow_gurobi_rodas5p = allow_gurobi_rodas5p,
    selected_solver_backends = [backend.solver_label for backend in backend_configs],
    actual_solver_labels = unique([scenario.solver_label for scenario in scenarios]),
    scenario_ids = [scenario.scenario_id for scenario in scenarios],
)

println("written_files:")
println("  benchmark_summary = $summary_path")
println("  benchmark_metadata = $metadata_path")
println("scenario_summary:")
println(
    "  scenario_id | solver_label | algorithm_label | reconstruct_fluxes | retcode | final_time | final_biomass | " *
    "final_total_sugar | final_ethanol | simulation_elapsed_seconds | rhs_call_count | " *
    "total_lp_solve_count | flux_reconstruction_solve_count",
)
for row in rows
    println(
        "  $(row["scenario_id"]) | $(row["solver_label"]) | $(row["algorithm_label"]) | " *
        "$(row["reconstruct_fluxes"]) | " *
        "$(row["retcode"]) | $(row["final_time"]) | $(row["final_biomass"]) | " *
        "$(row["final_total_sugar"]) | $(row["final_ethanol"]) | " *
        "$(row["simulation_elapsed_seconds"]) | $(row["rhs_call_count"]) | " *
        "$(row["total_lp_solve_count"]) | $(row["flux_reconstruction_solve_count"])",
    )
end
println("interpretation:")
println("  reconstruct_fluxes=false skips saved-state flux reconstruction and diagnostic histories.")
println("  Compare benchmark rows only when algorithm_label, ode_abstol, ode_reltol, lp_atol, and reconstruct_fluxes match.")
println("  Use DFBA_BENCH_ALGORITHM=Tsit5 for local Gurobi comparisons.")
println("  Optional Gurobi benchmarks run only when DFBA_BENCH_SOLVER_BACKENDS requests Gurobi.")
println("  HiGHS remains the default solver.")
