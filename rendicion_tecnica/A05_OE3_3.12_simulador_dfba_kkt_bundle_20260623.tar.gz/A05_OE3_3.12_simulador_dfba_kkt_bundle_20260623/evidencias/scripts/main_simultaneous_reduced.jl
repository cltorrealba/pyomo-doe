using FermentationDFBA

println("Simultaneous reduced KKT/MPCC simulation is not implemented yet.")
println("This script is a placeholder for a later direct-collocation commit.")
