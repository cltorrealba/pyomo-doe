using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_WINDOWED_TOL_PROFILE = "smoke"
const DEFAULT_MPCC_WINDOWED_TOL_IPOPT_MAX_ITER = 100

function _mpcc_windowed_tol_profile()
    raw = strip(get(ENV, "MPCC_WINDOWED_TOL_PROFILE", DEFAULT_MPCC_WINDOWED_TOL_PROFILE))
    normalized = lowercase(raw)
    normalized in ("smoke", "pilot", "72h", "custom") ||
        error(
            "Environment variable MPCC_WINDOWED_TOL_PROFILE must be one of: " *
            "smoke, pilot, 72h, custom. Got: $raw",
        )
    return normalized
end

function _mpcc_windowed_tol_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizon = "0.5",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 1,
            mass_thresholds = "1e-6,5e-6",
            max_cases = 2,
        )
    elseif profile == "pilot"
        return (
            target_horizon = "4.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 8,
            mass_thresholds = "1e-6,2e-6,5e-6",
            max_cases = 3,
        )
    elseif profile == "72h"
        return (
            target_horizon = "72.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 144,
            mass_thresholds = "1e-6,2e-6,5e-6,1e-5",
            max_cases = 4,
        )
    else
        return (
            target_horizon = "0.5",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 1,
            mass_thresholds = "1e-6,5e-6",
            max_cases = 2,
        )
    end
end

function _mpcc_windowed_tol_env_positive_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_windowed_tol_env_positive_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_windowed_tol_env_float_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Float64}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && error("Environment variable $name contains a non-Float64 value: $stripped")
        isfinite(value) && value > 0.0 ||
            error("Environment variable $name values must be finite and positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    length(unique(values)) == length(values) || error("Environment variable $name values must be unique.")
    issorted(values) || error("Environment variable $name values must be sorted ascending.")
    return values
end

function _mpcc_windowed_tol_n_windows(target_horizon::Float64, window_hours::Float64)::Int
    raw = target_horizon / window_hours
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || error(
        "MPCC_WINDOWED_TOL_TARGET_HOURS=$target_horizon is not an integer " *
        "multiple of MPCC_WINDOWED_TOL_WINDOW_HOURS=$window_hours.",
    )
    return n_windows
end

function _mpcc_windowed_tol_validate_workload!(
    n_windows::Int,
    max_windows::Int,
    n_cases::Int,
    max_cases::Int,
    allow_long::Bool,
    allow_large::Bool,
)
    if n_windows > max_windows && !allow_long
        error(
            "Requested MPCC windowed tolerance sensitivity has $n_windows windows per case, " *
            "above MPCC_WINDOWED_TOL_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_WINDOWED_TOL_ALLOW_LONG=1 only for deliberate longer diagnostics.",
        )
    end
    if n_cases > max_cases && !allow_large
        error(
            "Requested MPCC windowed tolerance sensitivity has $n_cases threshold cases, " *
            "above MPCC_WINDOWED_TOL_MAX_CASES=$max_cases. Set " *
            "MPCC_WINDOWED_TOL_ALLOW_LARGE=1 only for deliberate larger sweeps.",
        )
    end
    return nothing
end

function _mpcc_windowed_tol_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_windowed_tol_case_progress(row, row_index, n_cases)
    println(
        "progress_tolerance_case: $row_index/$n_cases | " *
        "id=$(row["tolerance_case_id"]) | " *
        "mass_threshold=$(_mpcc_windowed_tol_value(row["max_mass_balance_residual_threshold"])) | " *
        "status=$(_mpcc_windowed_tol_value(row["case_status"])) | " *
        "horizon=$(_mpcc_windowed_tol_value(row["horizon_reached"])) | " *
        "light=$(_mpcc_windowed_tol_value(row["attempt_traffic_light"])) | " *
        "mass_ratio=$(_mpcc_windowed_tol_value(row["max_mass_balance_ratio"]))",
    )
end

profile = _mpcc_windowed_tol_profile()
defaults = _mpcc_windowed_tol_profile_defaults(profile)
target_horizon =
    _mpcc_windowed_tol_env_positive_float(
        "MPCC_WINDOWED_TOL_TARGET_HOURS",
        defaults.target_horizon,
    )
window_hours =
    _mpcc_windowed_tol_env_positive_float(
        "MPCC_WINDOWED_TOL_WINDOW_HOURS",
        defaults.window_hours,
    )
nfe_per_window =
    _mpcc_windowed_tol_env_positive_int(
        "MPCC_WINDOWED_TOL_NFE",
        defaults.nfe_per_window,
    )
max_windows =
    _mpcc_windowed_tol_env_positive_int(
        "MPCC_WINDOWED_TOL_MAX_WINDOWS",
        defaults.max_windows,
    )
mass_thresholds =
    _mpcc_windowed_tol_env_float_list(
        "MPCC_WINDOWED_TOL_MASS_THRESHOLDS",
        defaults.mass_thresholds,
    )
max_cases = _mpcc_windowed_tol_env_positive_int("MPCC_WINDOWED_TOL_MAX_CASES", defaults.max_cases)
allow_long = _script_env_bool("MPCC_WINDOWED_TOL_ALLOW_LONG", false)
allow_large = _script_env_bool("MPCC_WINDOWED_TOL_ALLOW_LARGE", false)
continue_on_error = _script_env_bool("MPCC_WINDOWED_TOL_CONTINUE_ON_ERROR", true)
require_pre_solve_ready = _script_env_bool("MPCC_WINDOWED_TOL_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_WINDOWED_TOL_SILENT", true)
progress = _script_env_bool("MPCC_WINDOWED_TOL_PROGRESS", profile in ("72h", "pilot"))
ipopt_max_iter =
    _mpcc_windowed_tol_env_positive_int(
        "MPCC_WINDOWED_TOL_IPOPT_MAX_ITER",
        DEFAULT_MPCC_WINDOWED_TOL_IPOPT_MAX_ITER,
    )

n_windows = _mpcc_windowed_tol_n_windows(target_horizon, window_hours)
_mpcc_windowed_tol_validate_workload!(
    n_windows,
    max_windows,
    length(mass_thresholds),
    max_cases,
    allow_long,
    allow_large,
)

println("Reduced MPCC windowed tolerance sensitivity")
println("profile: $profile")
println("target_horizon: $target_horizon")
println("window_hours: $window_hours")
println("n_windows_per_case: $n_windows")
println("nfe_per_window: $nfe_per_window")
println("mass_thresholds: $(join(mass_thresholds, ","))")
println("ipopt_max_iter: $ipopt_max_iter")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("progress: $progress")

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

sensitivity = sweep_reduced_dcdfba_mpcc_windowed_tolerances(
    model,
    reaction_map;
    max_mass_balance_residual_values = mass_thresholds,
    target_horizon = target_horizon,
    window_hours = window_hours,
    nfe_per_window = nfe_per_window,
    degree = 3,
    ipopt_max_iter = ipopt_max_iter,
    require_pre_solve_ready = require_pre_solve_ready,
    silent = silent,
    continue_on_error = continue_on_error,
    case_callback = progress ? _mpcc_windowed_tol_case_progress : nothing,
)

println("outputs_written: $(sensitivity.metadata["outputs_written"])")
println("sensitivity_is_scientific_simulation: $(sensitivity.metadata["sensitivity_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(sensitivity.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(sensitivity.metadata["scientific_baseline"])")
println("first_mpcc_target: $(sensitivity.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(sensitivity.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(sensitivity.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(sensitivity.metadata["hsl_required"])")
println("ma57_required: $(sensitivity.metadata["ma57_required"])")
println("indices_reacciones_used: $(sensitivity.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(sensitivity.metadata["r0001_used_as_oxygen"])")
println("n_cases: $(sensitivity.metadata["n_cases"])")
println("n_completed_cases: $(sensitivity.metadata["n_completed_cases"])")
println("n_failed_cases: $(sensitivity.metadata["n_failed_cases"])")
println("green_count: $(sensitivity.metadata["green_count"])")
println("yellow_count: $(sensitivity.metadata["yellow_count"])")
println("red_count: $(sensitivity.metadata["red_count"])")
println("strictest_horizon_reached: $(_mpcc_windowed_tol_value(sensitivity.metadata["strictest_horizon_reached"]))")
println("best_tolerance_case_id: $(_mpcc_windowed_tol_value(sensitivity.metadata["best_tolerance_case_id"]))")
println("best_mass_threshold: $(_mpcc_windowed_tol_value(sensitivity.metadata["best_max_mass_balance_residual_threshold"]))")
println("best_horizon_reached: $(_mpcc_windowed_tol_value(sensitivity.metadata["best_horizon_reached"]))")
println("best_target_completed: $(_mpcc_windowed_tol_value(sensitivity.metadata["best_target_completed"]))")
println("best_attempt_traffic_light: $(_mpcc_windowed_tol_value(sensitivity.metadata["best_attempt_traffic_light"]))")
println("best_max_mass_balance_ratio: $(_mpcc_windowed_tol_value(sensitivity.metadata["best_max_mass_balance_ratio"]))")
println("first_horizon_extension_case_id: $(_mpcc_windowed_tol_value(sensitivity.metadata["first_horizon_extension_case_id"]))")
println("first_horizon_extension_threshold: $(_mpcc_windowed_tol_value(sensitivity.metadata["first_horizon_extension_threshold"]))")
println("first_target_completed_case_id: $(_mpcc_windowed_tol_value(sensitivity.metadata["first_target_completed_case_id"]))")
println("first_target_completed_threshold: $(_mpcc_windowed_tol_value(sensitivity.metadata["first_target_completed_threshold"]))")
println("horizon_extended_by_relaxation: $(sensitivity.metadata["horizon_extended_by_relaxation"])")
println("target_recovered_by_relaxation: $(sensitivity.metadata["target_recovered_by_relaxation"])")
println("total_solve_elapsed_seconds: $(sensitivity.metadata["total_solve_elapsed_seconds"])")
println("recommended_next_action: $(sensitivity.metadata["recommended_next_action"])")

println("tolerance_sensitivity_table:")
for row in eachrow(sensitivity.sensitivity_table)
    println(
        "  $(row["tolerance_case_id"]) | " *
        "mass_threshold=$(_mpcc_windowed_tol_value(row["max_mass_balance_residual_threshold"])) | " *
        "status=$(_mpcc_windowed_tol_value(row["case_status"])) | " *
        "horizon=$(_mpcc_windowed_tol_value(row["horizon_reached"])) | " *
        "gain_strict=$(_mpcc_windowed_tol_value(row["horizon_gain_vs_strictest"])) | " *
        "target_done=$(_mpcc_windowed_tol_value(row["target_completed"])) | " *
        "light=$(_mpcc_windowed_tol_value(row["attempt_traffic_light"])) | " *
        "global_light=$(_mpcc_windowed_tol_value(row["global_traffic_light"])) | " *
        "windows=$(row["n_completed_windows"])/$(row["n_requested_windows"]) | " *
        "first_red=$(_mpcc_windowed_tol_value(row["first_red_window_id"])) | " *
        "first_not_residual=$(_mpcc_windowed_tol_value(row["first_not_residual_feasible_window_id"])) | " *
        "max_mass=$(_mpcc_windowed_tol_value(row["max_mass_balance_residual"])) | " *
        "mass_ratio=$(_mpcc_windowed_tol_value(row["max_mass_balance_ratio"])) | " *
        "state_rel_rmse=$(_mpcc_windowed_tol_value(row["global_max_state_relative_rmse"])) | " *
        "solve_s=$(_mpcc_windowed_tol_value(row["total_solve_elapsed_seconds"])) | " *
        "blocking=$(_mpcc_windowed_tol_value(row["blocking_reasons"]))",
    )
end

println("interpretation_note: $(sensitivity.metadata["interpretation_note"])")
