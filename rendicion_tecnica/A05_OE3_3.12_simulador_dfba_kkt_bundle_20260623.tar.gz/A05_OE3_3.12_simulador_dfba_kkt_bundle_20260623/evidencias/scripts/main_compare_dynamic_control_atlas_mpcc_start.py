#!/usr/bin/env python3
"""Compare sequential atlas policies against MPCC fixed-control starts."""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path


ATTEMPT_CSV = "reduced_mpcc_fixed_control_policy_solve_attempt.csv"
RESIDUAL_CSV = "reduced_mpcc_fixed_control_policy_residual_locations.csv"
COMPLEMENTARITY_CSV = "reduced_mpcc_fixed_control_policy_complementarity_locations.csv"
REPAIR_TRACE_CSV = "reduced_mpcc_fixed_control_policy_repair_trace.csv"
START_SCHEDULE_CSV = "reduced_mpcc_dynamic_control_start_schedule.csv"
DECISION_SPEC_CSV = "reduced_mpcc_dynamic_control_decision_spec.csv"
METADATA_TOML = "reduced_mpcc_fixed_control_policy_solve_attempt.toml"


def _read_rows(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _read_one(path: Path) -> dict[str, str]:
    rows = _read_rows(path)
    return rows[0] if rows else {}


def _read_metadata_values(path: Path, wanted_keys: set[str]) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    current_table = ""
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            current_table = line.strip("[]")
            continue
        if current_table:
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key in wanted_keys:
            values[key] = value.strip().strip('"')
    return values


def _as_float(value: object, default: float = math.nan) -> float:
    try:
        out = float(str(value))
    except (TypeError, ValueError):
        return default
    return out if math.isfinite(out) else default


def _format_float(value: object) -> str:
    parsed = _as_float(value)
    if not math.isfinite(parsed):
        return ""
    return f"{parsed:.12g}"


def _parse_case_spec(text: str) -> tuple[str, Path]:
    if "=" in text:
        label, raw = text.split("=", 1)
        return label.strip(), Path(raw.strip())
    path = Path(text)
    return path.name, path


def _resolve_case_dir(path: Path) -> Path:
    if (path / ATTEMPT_CSV).is_file():
        return path
    if (path / "case" / ATTEMPT_CSV).is_file():
        return path / "case"
    raise FileNotFoundError(f"Cannot find {ATTEMPT_CSV} under {path}")


def _index_by(rows: list[dict[str, str]], key: str) -> dict[str, dict[str, str]]:
    indexed: dict[str, dict[str, str]] = {}
    for row in rows:
        value = row.get(key, "").strip()
        if value:
            indexed[value] = row
    return indexed


def _top_location(path: Path, prefix: str) -> dict[str, str]:
    row = _read_one(path)
    return {f"{prefix}_{key}": value for key, value in row.items()}


def _schedule_summary(path: Path) -> dict[str, str]:
    rows = _read_rows(path)
    if not rows:
        return {}
    temps = [_as_float(row.get("temperature_C")) for row in rows]
    fda_cumulative = [_as_float(row.get("fda_product_cumulative_g_L")) for row in rows]
    fda_rates = [_as_float(row.get("fda_product_rate_g_L_h")) for row in rows]
    organic_cumulative = [_as_float(row.get("organic_product_cumulative_g_L")) for row in rows]
    return {
        "schedule_time_start_h": _format_float(rows[0].get("time_h")),
        "schedule_time_end_h": _format_float(rows[-1].get("time_h")),
        "schedule_temperature_min_C": _format_float(min(temps)),
        "schedule_temperature_max_C": _format_float(max(temps)),
        "schedule_fda_final_g_L": _format_float(fda_cumulative[-1]),
        "schedule_fda_peak_rate_g_L_h": _format_float(max(fda_rates)),
        "schedule_organic_final_g_L": _format_float(organic_cumulative[-1]),
    }


def _decision_summary(path: Path) -> dict[str, str]:
    rows = _read_rows(path)
    if not rows:
        return {}
    out: dict[str, str] = {}
    for family in ("temperature", "fda", "organic"):
        family_rows = [row for row in rows if row.get("family") == family]
        free_rows = [row for row in family_rows if row.get("free", "").lower() == "true"]
        starts = [_as_float(row.get("start_value"), 0.0) for row in family_rows]
        out[f"decision_{family}_slot_count"] = str(len(family_rows))
        out[f"decision_{family}_free_count"] = str(len(free_rows))
        out[f"decision_{family}_start_sum"] = _format_float(sum(starts))
        out[f"decision_{family}_start_min"] = _format_float(min(starts) if starts else 0.0)
        out[f"decision_{family}_start_max"] = _format_float(max(starts) if starts else 0.0)
    return out


def _repair_summary(path: Path) -> dict[str, str]:
    rows = _read_rows(path)
    if not rows:
        return {}
    accepted = [row for row in rows if row.get("accepted", "").lower() == "true"]
    last = rows[-1]
    best_score = min((_as_float(row.get("score")) for row in rows), default=math.nan)
    return {
        "repair_trace_rows": str(len(rows)),
        "repair_accepted_trials": str(len(accepted)),
        "repair_final_score": _format_float(last.get("score")),
        "repair_final_max_residual": _format_float(last.get("max_residual")),
        "repair_best_score": _format_float(best_score),
        "repair_last_accepted_damping": accepted[-1].get("damping_factor", "") if accepted else "",
    }


def _build_row(
    label: str,
    case_dir: Path,
    atlas_by_id: dict[str, dict[str, str]],
    selection_by_id: dict[str, dict[str, str]],
) -> dict[str, str]:
    attempt = _read_one(case_dir / ATTEMPT_CSV)
    metadata = _read_metadata_values(
        case_dir / METADATA_TOML,
        {
            "nfe",
            "degree",
            "mesh_min_element_length_h",
            "mesh_max_element_length_h",
            "solve_horizon_h",
            "sequential_elapsed_seconds",
        },
    )
    candidate_id = attempt.get("candidate_id", "")
    atlas = atlas_by_id.get(candidate_id, {})
    selection = selection_by_id.get(candidate_id, {})
    atlas_horizon = _as_float(atlas.get("final_time"))
    solve_horizon = _as_float(attempt.get("solve_horizon_h") or metadata.get("solve_horizon_h"))
    selected_total_sugar = _as_float(attempt.get("selected_candidate_terminal_total_sugar_g_L"))
    atlas_total_sugar = _as_float(atlas.get("final_total_sugar"))
    horizon_match = (
        math.isfinite(atlas_horizon)
        and math.isfinite(solve_horizon)
        and abs(atlas_horizon - solve_horizon) < 1.0e-9
    )
    if horizon_match and math.isfinite(selected_total_sugar) and math.isfinite(atlas_total_sugar):
        total_sugar_delta = selected_total_sugar - atlas_total_sugar
    else:
        total_sugar_delta = math.nan

    row: dict[str, str] = {
        "label": label,
        "case_dir": str(case_dir),
        "case_id": attempt.get("case_id", ""),
        "candidate_id": candidate_id,
        "atlas_horizon_h": _format_float(atlas.get("final_time")),
        "mpcc_solve_horizon_h": _format_float(
            attempt.get("solve_horizon_h") or metadata.get("solve_horizon_h")
        ),
        "horizon_match": str(horizon_match).lower(),
        "mpcc_nfe": metadata.get("nfe") or attempt.get("grid_nfe", ""),
        "mpcc_element_length_h": metadata.get("mesh_max_element_length_h")
        or attempt.get("grid_element_length_h", ""),
        "mpcc_degree": metadata.get("degree", ""),
        "mpcc_sequential_elapsed_seconds": _format_float(
            metadata.get("sequential_elapsed_seconds")
        ),
        "atlas_retcode": atlas.get("retcode", ""),
        "atlas_status": atlas.get("status", ""),
        "atlas_final_glucose_g_L": _format_float(atlas.get("final_glucose")),
        "atlas_final_fructose_g_L": _format_float(atlas.get("final_fructose")),
        "atlas_final_total_sugar_g_L": _format_float(atlas.get("final_total_sugar")),
        "atlas_final_isoamyl_alcohol_g_L": _format_float(atlas.get("final_isoamyl_alcohol_g_L")),
        "atlas_rhs_call_count": atlas.get("rhs_call_count", ""),
        "selection_policy_ready": selection.get("control_policy_ready", ""),
        "selection_reason": selection.get("policy_reason", ""),
        "solver_call_performed": attempt.get("solver_call_performed", ""),
        "solver_status": attempt.get("solver_status", ""),
        "selected_candidate_source": attempt.get("selected_candidate_source", ""),
        "selected_candidate_residual_feasible": attempt.get(
            "selected_candidate_residual_feasible", ""
        ),
        "selected_candidate_trajectory_ready": attempt.get(
            "selected_candidate_trajectory_ready", ""
        ),
        "mpcc_terminal_glucose_g_L": _format_float(
            attempt.get("selected_candidate_terminal_glucose_g_L")
        ),
        "mpcc_terminal_fructose_g_L": _format_float(
            attempt.get("selected_candidate_terminal_fructose_g_L")
        ),
        "mpcc_terminal_total_sugar_g_L": _format_float(selected_total_sugar),
        "mpcc_terminal_isoamyl_alcohol_g_L": _format_float(
            attempt.get("selected_candidate_terminal_isoamyl_alcohol_g_L")
        ),
        "terminal_total_sugar_delta_vs_atlas_g_L": _format_float(total_sugar_delta),
        "max_rhs_residual": _format_float(attempt.get("max_rhs_residual")),
        "max_collocation_integration_residual": _format_float(
            attempt.get("max_collocation_integration_residual")
        ),
        "max_continuity_residual": _format_float(attempt.get("max_continuity_residual")),
        "max_mass_balance_residual": _format_float(attempt.get("max_mass_balance_residual")),
        "max_lower_complementarity_residual": _format_float(
            attempt.get("max_lower_complementarity_residual")
        ),
        "dominant_residual": attempt.get("dominant_residual", ""),
        "collocation_repair_initial_score": _format_float(
            attempt.get("collocation_consistent_state_start_initial_score")
        ),
        "collocation_repair_final_score": _format_float(
            attempt.get("collocation_consistent_state_start_final_score")
        ),
        "collocation_repair_best_score": _format_float(
            attempt.get("collocation_consistent_state_start_best_score")
        ),
        "collocation_repair_stopped_by_monotone_guard": attempt.get(
            "collocation_consistent_state_start_stopped_by_monotone_guard", ""
        ),
    }
    row.update(_top_location(case_dir / RESIDUAL_CSV, "top_residual"))
    row.update(_top_location(case_dir / COMPLEMENTARITY_CSV, "top_complementarity"))
    row.update(_schedule_summary(case_dir / START_SCHEDULE_CSV))
    row.update(_decision_summary(case_dir / DECISION_SPEC_CSV))
    row.update(_repair_summary(case_dir / REPAIR_TRACE_CSV))
    return row


def _write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def _write_markdown(path: Path, rows: list[dict[str, str]]) -> None:
    lines = [
        "# Atlas vs MPCC Start Quality",
        "",
        "| case | h | nfe | atlas sugar | MPCC sugar | delta | colloc | top residual | schedule |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |",
    ]
    for row in rows:
        residual_label = (
            f"{row.get('top_residual_state_name', '')} "
            f"@ {row.get('top_residual_time_h', '')} h"
        ).strip()
        schedule_label = (
            f"T {row.get('schedule_temperature_min_C', '')}-"
            f"{row.get('schedule_temperature_max_C', '')} C; "
            f"FDA {row.get('schedule_fda_final_g_L', '')} g/L"
        )
        lines.append(
            "| "
            + " | ".join(
                [
                    row.get("label", ""),
                    row.get("mpcc_solve_horizon_h", ""),
                    row.get("mpcc_nfe", ""),
                    row.get("atlas_final_total_sugar_g_L", ""),
                    row.get("mpcc_terminal_total_sugar_g_L", ""),
                    row.get("terminal_total_sugar_delta_vs_atlas_g_L", ""),
                    row.get("max_collocation_integration_residual", ""),
                    residual_label,
                    schedule_label,
                ]
            )
            + " |"
        )
    lines.extend(
        [
            "",
            "Rows with `horizon_match=false` are horizon-ladder diagnostics; their terminal sugar is not directly comparable to the 336 h atlas terminal sugar.",
            "",
        ]
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cases", nargs="+", help="Case paths, optionally label=/path.")
    parser.add_argument("--atlas-csv", type=Path, required=True)
    parser.add_argument("--selection-csv", type=Path, required=True)
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("repro/generated/dynamic_control_atlas_mpcc_start_quality"),
    )
    args = parser.parse_args()

    atlas_by_id = _index_by(_read_rows(args.atlas_csv), "candidate_id")
    selection_by_id = _index_by(_read_rows(args.selection_csv), "candidate_id")
    rows = [
        _build_row(label, _resolve_case_dir(raw).resolve(), atlas_by_id, selection_by_id)
        for label, raw in (_parse_case_spec(text) for text in args.cases)
    ]

    out_dir = args.out_dir.resolve()
    csv_path = out_dir / "atlas_mpcc_start_quality.csv"
    md_path = out_dir / "atlas_mpcc_start_quality.md"
    _write_csv(csv_path, rows)
    _write_markdown(md_path, rows)
    print(f"summary_csv={csv_path}")
    print(f"summary_md={md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
