using FermentationDFBA

S = [
    1.0 -1.0 0.0
   -1.0  1.0 0.0
]
toy_model = MetabolicModel(
    S,
    [0.0, 0.0, 0.0],
    [1000.0, 1000.0, 1000.0],
    ["r_forward", "r_reverse", "r_4048"],
    ["met_a", "met_b"];
    model_id = "toy_model",
)

balanced_flux = [1.0, 1.0, 0.0]
unbalanced_flux = [1.0, 0.0, 0.0]

@assert check_mass_balance(toy_model, balanced_flux) == 0.0
@assert is_mass_balanced(toy_model, balanced_flux)
@assert !is_mass_balanced(toy_model, unbalanced_flux)
@assert validate_reduced_model_dimensions(toy_model).ok

reaction_map = ReactionMap(
    core = Dict(
        "forward" => "r_forward",
        "oxygen_exchange" => "r_1992",
        "carbohydrate_exchange" => "r_4048",
    ),
    disabled_reactions = Dict(
        "oxygen_exchange" => "r_1992",
    ),
)
report = validate_reaction_map(toy_model, reaction_map)
@assert report.ok
@assert report.found_required_reactions["forward"] == "r_forward"
@assert report.found_required_reactions["carbohydrate_exchange"] == "r_4048"
@assert haskey(report.disabled_reactions, "oxygen_exchange")

println("Sanity check passed.")
