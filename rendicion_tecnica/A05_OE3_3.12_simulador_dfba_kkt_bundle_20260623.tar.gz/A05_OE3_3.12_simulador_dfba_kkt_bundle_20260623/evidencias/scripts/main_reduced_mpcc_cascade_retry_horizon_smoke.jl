using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_CASCADE_RETRY_HORIZON_PROFILE = "smoke"
const DEFAULT_MPCC_CASCADE_RETRY_HORIZON_SOURCE_MAX_ITER = 100

function _mpcc_cascade_retry_horizon_profile()
    raw = strip(
        get(
            ENV,
            "MPCC_CASCADE_RETRY_HORIZON_PROFILE",
            DEFAULT_MPCC_CASCADE_RETRY_HORIZON_PROFILE,
        ),
    )
    normalized = lowercase(raw)
    normalized in ("smoke", "focused", "72h", "custom") ||
        error("Environment variable MPCC_CASCADE_RETRY_HORIZON_PROFILE must be one of: smoke, focused, 72h, custom. Got: $raw")
    return normalized
end

function _mpcc_cascade_retry_horizon_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizons = "1.0",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 1,
            max_windows = 2,
            retry_max_windows = 2,
            retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            mass_threshold = "5e-6",
        )
    elseif profile == "focused"
        return (
            target_horizons = "1.0,1.5",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 2,
            max_windows = 3,
            retry_max_windows = 2,
            retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            mass_threshold = "5e-6",
        )
    elseif profile == "72h"
        return (
            target_horizons = "1.0,2.0,4.0,8.0,16.0,32.0,72.0",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 7,
            max_windows = 144,
            retry_max_windows = 4,
            retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            mass_threshold = "5e-6",
        )
    else
        return (
            target_horizons = "1.0",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 1,
            max_windows = 2,
            retry_max_windows = 2,
            retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            mass_threshold = "5e-6",
        )
    end
end

function _mpcc_cascade_retry_horizon_env_float_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Float64}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && error("Environment variable $name contains invalid Float64 token: $stripped")
        isfinite(value) && value > 0.0 ||
            error("Environment variable $name values must be finite and positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_cascade_retry_horizon_env_positive_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_cascade_retry_horizon_env_positive_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_cascade_retry_horizon_env_nonnegative_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value >= 0 || error("Environment variable $name must be nonnegative, got: $value")
    return value
end

function _mpcc_cascade_retry_horizon_parse_int_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        parsed = tryparse(Int, stripped)
        parsed === nothing && error("Environment variable $name has invalid Int token: $stripped")
        parsed > 0 || error("Environment variable $name values must be positive, got: $parsed")
        push!(values, parsed)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_cascade_retry_horizon_validate_size!(
    target_horizons::Vector{Float64},
    window_hours::Float64,
    max_cases::Int,
    max_windows::Int,
    allow_large::Bool,
    allow_long::Bool,
)
    if length(target_horizons) > max_cases && !allow_large
        error(
            "Requested MPCC cascade retry horizon smoke has $(length(target_horizons)) cases, above " *
            "MPCC_CASCADE_RETRY_HORIZON_MAX_CASES=$max_cases. Set " *
            "MPCC_CASCADE_RETRY_HORIZON_ALLOW_LARGE=1 only for deliberate diagnostics.",
        )
    end
    requested_windows = maximum(round(Int, target / window_hours) for target in target_horizons)
    for target in target_horizons
        raw = target / window_hours
        isapprox(raw, round(Int, raw); atol = 1.0e-10, rtol = 1.0e-10) ||
            error("Each target horizon must be an integer multiple of window_hours. Got target=$target, window=$window_hours.")
    end
    if requested_windows > max_windows && !allow_long
        error(
            "Requested MPCC cascade retry horizon smoke has up to $requested_windows windows, above " *
            "MPCC_CASCADE_RETRY_HORIZON_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_CASCADE_RETRY_HORIZON_ALLOW_LONG=1 only for deliberate longer diagnostics.",
        )
    end
    return nothing
end

function _mpcc_cascade_retry_horizon_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_cascade_retry_horizon_progress_callback(progress::Bool)
    progress || return nothing
    return function (row, row_index, total)
        println(
            "progress_case: $row_index/$total | " *
            "id=$(_mpcc_cascade_retry_horizon_value(row["cascade_horizon_case_id"])) | " *
            "target=$(_mpcc_cascade_retry_horizon_value(row["target_horizon"])) | " *
            "base=$(_mpcc_cascade_retry_horizon_value(row["base_attempt_traffic_light"])) | " *
            "rebuilt=$(_mpcc_cascade_retry_horizon_value(row["rebuilt_attempt_traffic_light"])) | " *
            "cascade=$(_mpcc_cascade_retry_horizon_value(row["cascade_rebuild_applied"])) | " *
            "downstream=$(_mpcc_cascade_retry_horizon_value(row["n_downstream_windows_resolved"]))",
        )
    end
end

profile = _mpcc_cascade_retry_horizon_profile()
defaults = _mpcc_cascade_retry_horizon_profile_defaults(profile)
target_horizons = _mpcc_cascade_retry_horizon_env_float_list(
    "MPCC_CASCADE_RETRY_HORIZON_TARGET_HOURS",
    defaults.target_horizons,
)
window_hours = _mpcc_cascade_retry_horizon_env_positive_float(
    "MPCC_CASCADE_RETRY_HORIZON_WINDOW_HOURS",
    defaults.window_hours,
)
nfe_per_window = _mpcc_cascade_retry_horizon_env_positive_int(
    "MPCC_CASCADE_RETRY_HORIZON_NFE",
    defaults.nfe,
)
max_cases = _mpcc_cascade_retry_horizon_env_positive_int(
    "MPCC_CASCADE_RETRY_HORIZON_MAX_CASES",
    defaults.max_cases,
)
max_windows = _mpcc_cascade_retry_horizon_env_positive_int(
    "MPCC_CASCADE_RETRY_HORIZON_MAX_WINDOWS",
    defaults.max_windows,
)
retry_max_windows = _mpcc_cascade_retry_horizon_env_nonnegative_int(
    "MPCC_CASCADE_RETRY_HORIZON_MAX_RETRY_WINDOWS",
    defaults.retry_max_windows,
)
retry_max_iters = _mpcc_cascade_retry_horizon_parse_int_list(
    "MPCC_CASCADE_RETRY_HORIZON_MAX_ITERS",
    defaults.retry_max_iters,
)
cascade_max_iter = _mpcc_cascade_retry_horizon_env_positive_int(
    "MPCC_CASCADE_RETRY_HORIZON_CASCADE_MAX_ITER",
    defaults.cascade_max_iter,
)
mass_threshold = _mpcc_cascade_retry_horizon_env_positive_float(
    "MPCC_CASCADE_RETRY_HORIZON_MASS_THRESHOLD",
    defaults.mass_threshold,
)
source_ipopt_max_iter = _mpcc_cascade_retry_horizon_env_positive_int(
    "MPCC_CASCADE_RETRY_HORIZON_SOURCE_MAX_ITER",
    DEFAULT_MPCC_CASCADE_RETRY_HORIZON_SOURCE_MAX_ITER,
)
selection_policy =
    strip(get(ENV, "MPCC_CASCADE_RETRY_HORIZON_SELECTION_POLICY", "iteration_limit_or_not_ready"))
replacement_policy =
    strip(get(ENV, "MPCC_CASCADE_RETRY_HORIZON_REPLACEMENT_POLICY", "green_or_trajectory_ready"))
allow_large = _script_env_bool("MPCC_CASCADE_RETRY_HORIZON_ALLOW_LARGE", false)
allow_long = _script_env_bool("MPCC_CASCADE_RETRY_HORIZON_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_CASCADE_RETRY_HORIZON_CONTINUE_ON_ERROR", true)
require_pre_solve_ready =
    _script_env_bool("MPCC_CASCADE_RETRY_HORIZON_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_CASCADE_RETRY_HORIZON_SILENT", true)
progress = _script_env_bool("MPCC_CASCADE_RETRY_HORIZON_PROGRESS", profile != "smoke")
stop_after_first_non_green =
    _script_env_bool("MPCC_CASCADE_RETRY_HORIZON_STOP_AFTER_FIRST_NON_GREEN", false)

_mpcc_cascade_retry_horizon_validate_size!(
    target_horizons,
    window_hours,
    max_cases,
    max_windows,
    allow_large,
    allow_long,
)

println("Reduced MPCC cascade retry horizon smoke")
println("profile: $profile")
println("target_horizons: $(join(target_horizons, ","))")
println("window_hours: $window_hours")
println("nfe_per_window: $nfe_per_window")
println("mass_threshold: $mass_threshold")
println("source_ipopt_max_iter: $source_ipopt_max_iter")
println("retry_max_windows: $retry_max_windows")
println("retry_max_iters: $(join(retry_max_iters, ","))")
println("cascade_max_iter: $cascade_max_iter")
println("selection_policy: $selection_policy")
println("replacement_policy: $replacement_policy")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("stop_after_first_non_green: $stop_after_first_non_green")
println("progress: $progress")

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

base_residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds(
    max_rhs_residual = base_residual_thresholds.max_rhs_residual,
    max_mass_balance_residual = mass_threshold,
    max_lower_bound_violation = base_residual_thresholds.max_lower_bound_violation,
    max_upper_bound_violation = base_residual_thresholds.max_upper_bound_violation,
    max_stationarity_residual = base_residual_thresholds.max_stationarity_residual,
    max_lower_complementarity_residual =
        base_residual_thresholds.max_lower_complementarity_residual,
    max_upper_complementarity_residual =
        base_residual_thresholds.max_upper_complementarity_residual,
)
viability_thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
    residual_thresholds = residual_thresholds,
)

smoke = smoke_reduced_dcdfba_mpcc_cascade_retry_horizons(
    model,
    reaction_map;
    target_horizons = target_horizons,
    window_hours = window_hours,
    nfe_per_window = nfe_per_window,
    degree = 3,
    source_ipopt_max_iter = source_ipopt_max_iter,
    retry_ipopt_max_iter_values = retry_max_iters,
    cascade_ipopt_max_iter = cascade_max_iter,
    retry_selection_policy = selection_policy,
    retry_max_windows = retry_max_windows,
    replacement_acceptance_policy = replacement_policy,
    require_pre_solve_ready = require_pre_solve_ready,
    residual_thresholds = residual_thresholds,
    viability_thresholds = viability_thresholds,
    silent = silent,
    continue_on_error = continue_on_error,
    stop_after_first_non_green = stop_after_first_non_green,
    case_callback = _mpcc_cascade_retry_horizon_progress_callback(progress),
)

println("outputs_written: $(smoke.metadata["outputs_written"])")
println("smoke_is_scientific_simulation: $(smoke.metadata["smoke_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(smoke.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(smoke.metadata["scientific_baseline"])")
println("first_mpcc_target: $(smoke.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(smoke.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(smoke.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(smoke.metadata["hsl_required"])")
println("ma57_required: $(smoke.metadata["ma57_required"])")
println("indices_reacciones_used: $(smoke.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(smoke.metadata["r0001_used_as_oxygen"])")
println("n_requested_cases: $(smoke.metadata["n_requested_cases"])")
println("n_cases: $(smoke.metadata["n_cases"])")
println("n_completed_cases: $(smoke.metadata["n_completed_cases"])")
println("n_failed_cases: $(smoke.metadata["n_failed_cases"])")
println("cascade_rebuild_applied_count: $(smoke.metadata["cascade_rebuild_applied_count"])")
println("retry_replacement_applied_count: $(smoke.metadata["retry_replacement_applied_count"])")
println("nonterminal_replacement_count: $(smoke.metadata["nonterminal_replacement_count"])")
println("downstream_resolve_case_count: $(smoke.metadata["downstream_resolve_case_count"])")
println("green_rebuilt_count: $(smoke.metadata["green_rebuilt_count"])")
println("yellow_rebuilt_count: $(smoke.metadata["yellow_rebuilt_count"])")
println("red_rebuilt_count: $(smoke.metadata["red_rebuilt_count"])")
println("viability_recovered_count: $(smoke.metadata["viability_recovered_count"])")
println("target_recovered_count: $(smoke.metadata["target_recovered_count"])")
println("max_base_horizon_reached: $(_mpcc_cascade_retry_horizon_value(smoke.metadata["max_base_horizon_reached"]))")
println("max_rebuilt_horizon_reached: $(_mpcc_cascade_retry_horizon_value(smoke.metadata["max_rebuilt_horizon_reached"]))")
println("best_green_case_id: $(_mpcc_cascade_retry_horizon_value(smoke.metadata["best_green_case_id"]))")
println("best_green_target_horizon: $(_mpcc_cascade_retry_horizon_value(smoke.metadata["best_green_target_horizon"]))")
println("best_green_rebuilt_horizon_reached: $(_mpcc_cascade_retry_horizon_value(smoke.metadata["best_green_rebuilt_horizon_reached"]))")
println("first_non_green_case_id: $(_mpcc_cascade_retry_horizon_value(smoke.metadata["first_non_green_case_id"]))")
println("first_nonterminal_cascade_case_id: $(_mpcc_cascade_retry_horizon_value(smoke.metadata["first_nonterminal_cascade_case_id"]))")
println("first_nonterminal_cascade_target_horizon: $(_mpcc_cascade_retry_horizon_value(smoke.metadata["first_nonterminal_cascade_target_horizon"]))")
println("recommended_next_action: $(smoke.metadata["recommended_next_action"])")

println("cascade_horizon_table:")
for row in eachrow(smoke.cascade_horizon_table)
    println(
        "  $(row["cascade_horizon_case_id"]) | target=$(_mpcc_cascade_retry_horizon_value(row["target_horizon"])) | " *
        "base=$(_mpcc_cascade_retry_horizon_value(row["base_attempt_traffic_light"])) | " *
        "rebuilt=$(_mpcc_cascade_retry_horizon_value(row["rebuilt_attempt_traffic_light"])) | " *
        "base_reached=$(_mpcc_cascade_retry_horizon_value(row["base_horizon_reached"])) | " *
        "rebuilt_reached=$(_mpcc_cascade_retry_horizon_value(row["rebuilt_horizon_reached"])) | " *
        "cascade=$(_mpcc_cascade_retry_horizon_value(row["cascade_rebuild_applied"])) | " *
        "replacement_window=$(_mpcc_cascade_retry_horizon_value(row["cascade_replacement_window_index"])) | " *
        "replacement_iter=$(_mpcc_cascade_retry_horizon_value(row["cascade_replacement_retry_ipopt_max_iter"])) | " *
        "downstream_req=$(_mpcc_cascade_retry_horizon_value(row["n_downstream_windows_requested"])) | " *
        "downstream_ok=$(_mpcc_cascade_retry_horizon_value(row["n_downstream_windows_resolved"])) | " *
        "nonterminal=$(_mpcc_cascade_retry_horizon_value(row["nonterminal_replacement_applied"])) | " *
        "viability_recovered=$(_mpcc_cascade_retry_horizon_value(row["viability_recovered_by_cascade"])) | " *
        "action=$(_mpcc_cascade_retry_horizon_value(row["recommended_next_action"]))",
    )
end

println("interpretation_note: $(smoke.metadata["interpretation_note"])")
