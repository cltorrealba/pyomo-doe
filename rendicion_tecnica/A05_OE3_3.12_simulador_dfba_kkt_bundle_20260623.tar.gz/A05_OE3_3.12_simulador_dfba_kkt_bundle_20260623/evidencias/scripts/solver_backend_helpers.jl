const _DFBA_GUROBI_PACKAGE_PATH_ENV = "DFBA_GUROBI_PACKAGE_PATH"

function _resolve_solver_backend(backend::AbstractString)
    canonical_backend = _canonical_solver_backend_label(backend)

    if canonical_backend == "HiGHS"
        return nothing, "HiGHS"
    elseif canonical_backend == "Gurobi"
        return _resolve_gurobi_solver_backend()
    else
        error("Unsupported solver backend: $backend. Supported backends: HiGHS, Gurobi.")
    end
end

function _parse_solver_backend_list(raw::AbstractString)::Vector{String}
    isempty(strip(raw)) && error(
        "Solver backend list must include at least one backend. Supported backends: HiGHS, Gurobi.",
    )

    backend_labels = String[]
    seen = Set{String}()
    for value in split(raw, ",")
        stripped = strip(value)
        isempty(stripped) && error(
            "Solver backend list contains an empty entry. Supported backends: HiGHS, Gurobi.",
        )

        canonical = _canonical_solver_backend_label(stripped)
        canonical in seen && error("Duplicate solver backend requested: $canonical")
        push!(seen, canonical)
        push!(backend_labels, canonical)
    end
    return backend_labels
end

function _canonical_solver_backend_label(backend::AbstractString)::String
    normalized = lowercase(strip(backend))
    if normalized == "highs"
        return "HiGHS"
    elseif normalized == "gurobi"
        return "Gurobi"
    else
        error("Unsupported solver backend: $backend. Supported backends: HiGHS, Gurobi.")
    end
end

function _resolve_gurobi_solver_backend()
    optimizer, active_import_error = _try_import_gurobi_optimizer()
    active_import_error === nothing && return optimizer, "Gurobi"

    raw_package_path = strip(get(ENV, _DFBA_GUROBI_PACKAGE_PATH_ENV, ""))
    if isempty(raw_package_path)
        _throw_gurobi_backend_error(
            "Gurobi backend requested, but Gurobi.jl could not be loaded from the active environment " *
            "and $_DFBA_GUROBI_PACKAGE_PATH_ENV is not set. Set $_DFBA_GUROBI_PACKAGE_PATH_ENV to a " *
            "local Gurobi.jl checkout or use HiGHS.",
            active_import_error = active_import_error,
        )
    end

    local_package_path = _validated_gurobi_package_path(raw_package_path, active_import_error)
    return _resolve_gurobi_solver_backend_from_package_path(local_package_path, active_import_error)
end

function _try_import_gurobi_optimizer()
    try
        optimizer = _with_suppressed_solver_backend_output() do
            @eval import Gurobi
            gurobi_env = Base.invokelatest(
                Gurobi.Env,
                Dict{String,Any}("OutputFlag" => 0),
            )
            () -> Base.invokelatest(Gurobi.Optimizer, gurobi_env)
        end
        return optimizer, nothing
    catch err
        return nothing, err
    end
end

function _validated_gurobi_package_path(path_value::AbstractString, active_import_error)
    local_package_path = normpath(expanduser(String(path_value)))
    if !isdir(local_package_path)
        _throw_gurobi_backend_error(
            "Gurobi backend requested, but $_DFBA_GUROBI_PACKAGE_PATH_ENV does not exist or is not a directory.",
            active_import_error = active_import_error,
            local_package_path = local_package_path,
        )
    end

    project_path = joinpath(local_package_path, "Project.toml")
    if !isfile(project_path)
        _throw_gurobi_backend_error(
            "Gurobi backend requested, but $_DFBA_GUROBI_PACKAGE_PATH_ENV does not contain Project.toml.",
            active_import_error = active_import_error,
            local_package_path = local_package_path,
        )
    end

    source_path = joinpath(local_package_path, "src", "Gurobi.jl")
    if !isfile(source_path)
        _throw_gurobi_backend_error(
            "Gurobi backend requested, but $_DFBA_GUROBI_PACKAGE_PATH_ENV does not contain src/Gurobi.jl.",
            active_import_error = active_import_error,
            local_package_path = local_package_path,
        )
    end

    return local_package_path
end

function _resolve_gurobi_solver_backend_from_package_path(
    local_package_path::AbstractString,
    active_import_error,
)
    previous_project = Base.active_project()
    tmp_root = mktempdir()
    tmp_gurobi_path = joinpath(tmp_root, "Gurobi.jl")
    try
        cp(local_package_path, tmp_gurobi_path; force = true)
        @eval import Pkg
        _with_suppressed_solver_backend_output() do
            Base.invokelatest(Pkg.activate; temp = true)
            Base.invokelatest(Pkg.develop; path = tmp_gurobi_path)
            Base.invokelatest(Pkg.build, "Gurobi")
        end

        optimizer, temp_import_error = _try_import_gurobi_optimizer()
        if temp_import_error !== nothing
            _throw_gurobi_backend_error(
                "Gurobi backend requested, but Gurobi.jl could not be loaded from the temporary package copy.",
                active_import_error = active_import_error,
                local_package_path = local_package_path,
                local_import_error = temp_import_error,
            )
        end
        return optimizer, "Gurobi"
    catch err
        _throw_gurobi_backend_error(
            "Gurobi backend requested, but local Gurobi.jl package-path loading failed.",
            active_import_error = active_import_error,
            local_package_path = local_package_path,
            local_import_error = err,
        )
    finally
        _restore_active_project(previous_project)
        isdir(tmp_root) && rm(tmp_root; recursive = true, force = true)
    end
end

function _restore_active_project(previous_project)
    previous_project === nothing && return nothing
    isfile(previous_project) || return nothing
    isdefined(@__MODULE__, :Pkg) || return nothing

    try
        _with_suppressed_solver_backend_output() do
            Base.invokelatest(Pkg.activate, dirname(previous_project))
        end
    catch
        return nothing
    end
    return nothing
end

function _with_suppressed_solver_backend_output(f::Function)
    return redirect_stdout(devnull) do
        redirect_stderr(devnull) do
            f()
        end
    end
end

function _throw_gurobi_backend_error(
    message::AbstractString;
    active_import_error = nothing,
    local_package_path = nothing,
    local_import_error = nothing,
)
    details = String[
        String(message),
        "HiGHS is the default alternative and does not require Gurobi.",
        "Do not add Gurobi.jl to Project.toml for normal execution.",
    ]
    local_package_path !== nothing && push!(
        details,
        "$_DFBA_GUROBI_PACKAGE_PATH_ENV = $(String(local_package_path))",
    )
    active_import_error !== nothing && push!(
        details,
        "Active-environment import error: $(sprint(showerror, active_import_error))",
    )
    local_import_error !== nothing && push!(
        details,
        "Local package-path error: $(sprint(showerror, local_import_error))",
    )
    error(join(details, " "))
end
