using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_WINDOWED_DRIFT_PROFILE = "smoke"
const DEFAULT_MPCC_WINDOWED_DRIFT_IPOPT_MAX_ITER = 100

function _mpcc_windowed_drift_profile()
    raw = strip(get(ENV, "MPCC_WINDOWED_DRIFT_PROFILE", DEFAULT_MPCC_WINDOWED_DRIFT_PROFILE))
    normalized = lowercase(raw)
    normalized = normalized == "twomh_four_nfe" ? "2h4nfe" : normalized
    normalized in ("smoke", "focused", "2h4nfe", "8h", "72h", "custom") ||
        error(
            "Environment variable MPCC_WINDOWED_DRIFT_PROFILE must be one of: " *
            "smoke, focused, 2h4nfe, twomh_four_nfe, 8h, 72h, custom. Got: $raw",
        )
    return normalized
end

function _mpcc_windowed_drift_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizon = "0.5",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 1,
            mass_threshold = "5e-6",
        )
    elseif profile == "focused"
        return (
            target_horizon = "2.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 4,
            mass_threshold = "5e-6",
        )
    elseif profile == "2h4nfe"
        return (
            target_horizon = "2.0",
            window_hours = "2.0",
            nfe_per_window = 4,
            max_windows = 1,
            mass_threshold = "5e-6",
        )
    elseif profile == "8h"
        return (
            target_horizon = "8.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 16,
            mass_threshold = "5e-6",
        )
    elseif profile == "72h"
        return (
            target_horizon = "72.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 144,
            mass_threshold = "5e-6",
        )
    else
        return (
            target_horizon = "8.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 16,
            mass_threshold = "5e-6",
        )
    end
end

function _mpcc_windowed_drift_env_positive_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_windowed_drift_env_nonnegative_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $value")
    return value
end

function _mpcc_windowed_drift_env_positive_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_windowed_drift_n_windows(target_horizon::Float64, window_hours::Float64)::Int
    raw = target_horizon / window_hours
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || error(
        "MPCC_WINDOWED_DRIFT_TARGET_HOURS=$target_horizon is not an integer " *
        "multiple of MPCC_WINDOWED_DRIFT_WINDOW_HOURS=$window_hours.",
    )
    return n_windows
end

function _mpcc_windowed_drift_validate_grid!(
    n_windows::Int,
    max_windows::Int,
    allow_long::Bool,
)
    if n_windows > max_windows && !allow_long
        error(
            "Requested MPCC windowed drift diagnostic has $n_windows windows, above " *
            "MPCC_WINDOWED_DRIFT_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_WINDOWED_DRIFT_ALLOW_LONG=1 only for deliberate longer diagnostics.",
        )
    end
    return nothing
end

function _mpcc_windowed_drift_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_windowed_drift_progress_callback(progress::Bool)
    progress || return nothing
    return function (row, row_index, n_requested_windows)
        println(
            "progress_window: $row_index/$n_requested_windows | " *
            "id=$(_mpcc_windowed_drift_value(row["window_id"])) | " *
            "status=$(_mpcc_windowed_drift_value(row["window_status"])) | " *
            "tfinal=$(_mpcc_windowed_drift_value(row["tfinal"])) | " *
            "solver=$(_mpcc_windowed_drift_value(row["solver_status"])) | " *
            "trajectory_ready=$(_mpcc_windowed_drift_value(row["candidate_trajectory_ready"])) | " *
            "allows_continuation=$(_mpcc_windowed_drift_value(row["candidate_allows_continuation"])) | " *
            "state_rel_rmse=$(_mpcc_windowed_drift_value(row["max_state_relative_rmse"]))",
        )
    end
end

profile = _mpcc_windowed_drift_profile()
defaults = _mpcc_windowed_drift_profile_defaults(profile)
target_horizon =
    _mpcc_windowed_drift_env_positive_float(
        "MPCC_WINDOWED_DRIFT_TARGET_HOURS",
        defaults.target_horizon,
    )
window_hours =
    _mpcc_windowed_drift_env_positive_float(
        "MPCC_WINDOWED_DRIFT_WINDOW_HOURS",
        defaults.window_hours,
    )
nfe_per_window =
    _mpcc_windowed_drift_env_positive_int(
        "MPCC_WINDOWED_DRIFT_NFE",
        defaults.nfe_per_window,
    )
max_windows =
    _mpcc_windowed_drift_env_positive_int(
        "MPCC_WINDOWED_DRIFT_MAX_WINDOWS",
        defaults.max_windows,
    )
mass_threshold =
    _mpcc_windowed_drift_env_positive_float(
        "MPCC_WINDOWED_DRIFT_MASS_THRESHOLD",
        defaults.mass_threshold,
    )
allow_long = _script_env_bool("MPCC_WINDOWED_DRIFT_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_WINDOWED_DRIFT_CONTINUE_ON_ERROR", true)
require_pre_solve_ready = _script_env_bool("MPCC_WINDOWED_DRIFT_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_WINDOWED_DRIFT_SILENT", true)
progress = _script_env_bool("MPCC_WINDOWED_DRIFT_PROGRESS", profile in ("8h", "72h"))
ipopt_max_iter =
    _mpcc_windowed_drift_env_positive_int(
        "MPCC_WINDOWED_DRIFT_IPOPT_MAX_ITER",
        DEFAULT_MPCC_WINDOWED_DRIFT_IPOPT_MAX_ITER,
    )
linear_solver = strip(get(ENV, "MPCC_IPOPT_LINEAR_SOLVER", "mumps"))
ipopt_profile = reduced_mpcc_ipopt_profile_name_from_env()
complementarity_mode = reduced_mpcc_complementarity_mode_from_env("scholtes")
complementarity_tau = reduced_mpcc_complementarity_tau_from_env()
complementarity_tau_gate_tol = reduced_mpcc_complementarity_tau_gate_tol_from_env()
tau_schedule =
    _script_env_bool("MPCC_WINDOWED_DRIFT_USE_TAU_CONTINUATION", profile == "2h4nfe") ?
    reduced_mpcc_tau_schedule_from_env() : nothing
tau_schedule_label = tau_schedule === nothing ? "disabled" : join(tau_schedule, ",")
continuation_acceptance_policy =
    strip(get(ENV, "MPCC_WINDOWED_DRIFT_CONTINUATION_POLICY", "residual_feasible"))
continuation_state_abs_difference_threshold =
    _mpcc_windowed_drift_env_nonnegative_float(
        "MPCC_WINDOWED_DRIFT_STATE_ABS_DIFF_THRESHOLD",
        "1e-4",
    )
continuation_state_relative_rmse_threshold =
    _mpcc_windowed_drift_env_nonnegative_float(
        "MPCC_WINDOWED_DRIFT_STATE_REL_RMSE_THRESHOLD",
        "0.02",
    )

n_windows = _mpcc_windowed_drift_n_windows(target_horizon, window_hours)
_mpcc_windowed_drift_validate_grid!(n_windows, max_windows, allow_long)

println("Reduced MPCC windowed drift diagnostics")
println("profile: $profile")
println("target_horizon: $target_horizon")
println("window_hours: $window_hours")
println("n_windows: $n_windows")
println("nfe_per_window: $nfe_per_window")
println("mass_threshold: $mass_threshold")
println("ipopt_max_iter: $ipopt_max_iter")
println("linear_solver: $linear_solver")
println("ipopt_profile: $ipopt_profile")
println("complementarity_mode: $complementarity_mode")
println("complementarity_tau: $complementarity_tau")
println("complementarity_tau_gate_tol: $(_mpcc_windowed_drift_value(complementarity_tau_gate_tol))")
println("tau_schedule: $tau_schedule_label")
println("continuation_acceptance_policy: $continuation_acceptance_policy")
println("continuation_state_abs_difference_threshold: $continuation_state_abs_difference_threshold")
println("continuation_state_relative_rmse_threshold: $continuation_state_relative_rmse_threshold")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("progress: $progress")

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

diagnostic = diagnose_reduced_dcdfba_mpcc_windowed_drift(
    model,
    reaction_map;
    max_mass_balance_residual = mass_threshold,
    target_horizon = target_horizon,
    window_hours = window_hours,
    nfe_per_window = nfe_per_window,
    degree = 3,
    ipopt_max_iter = ipopt_max_iter,
    linear_solver = linear_solver,
    ipopt_profile = ipopt_profile,
    complementarity_mode = complementarity_mode,
    complementarity_tau = complementarity_tau,
    complementarity_tau_gate_tol = complementarity_tau_gate_tol,
    tau_schedule = tau_schedule,
    require_pre_solve_ready = require_pre_solve_ready,
    continuation_acceptance_policy = continuation_acceptance_policy,
    continuation_state_abs_difference_threshold =
        continuation_state_abs_difference_threshold,
    continuation_state_relative_rmse_threshold =
        continuation_state_relative_rmse_threshold,
    silent = silent,
    continue_on_error = continue_on_error,
    window_callback = _mpcc_windowed_drift_progress_callback(progress),
)

println("outputs_written: $(diagnostic.metadata["outputs_written"])")
println("drift_diagnostic_is_scientific_simulation: $(diagnostic.metadata["drift_diagnostic_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(diagnostic.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(diagnostic.metadata["scientific_baseline"])")
println("first_mpcc_target: $(diagnostic.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(diagnostic.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(diagnostic.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(diagnostic.metadata["hsl_required"])")
println("ma57_required: $(diagnostic.metadata["ma57_required"])")
println("indices_reacciones_used: $(diagnostic.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(diagnostic.metadata["r0001_used_as_oxygen"])")
println("horizon_reached: $(_mpcc_windowed_drift_value(diagnostic.metadata["horizon_reached"]))")
println("target_completed: $(_mpcc_windowed_drift_value(diagnostic.metadata["target_completed"]))")
println("attempt_traffic_light: $(_mpcc_windowed_drift_value(diagnostic.metadata["attempt_traffic_light"]))")
println("n_completed_windows: $(_mpcc_windowed_drift_value(diagnostic.metadata["n_completed_windows"]))")
println("continuation_completed: $(_mpcc_windowed_drift_value(diagnostic.metadata["continuation_completed"]))")
println("all_completed_windows_trajectory_ready: $(_mpcc_windowed_drift_value(diagnostic.metadata["all_completed_windows_trajectory_ready"]))")
println("threshold_max_state_abs_difference: $(diagnostic.metadata["threshold_max_state_abs_difference"])")
println("threshold_max_state_relative_rmse: $(diagnostic.metadata["threshold_max_state_relative_rmse"])")
println("first_state_drift_window_id: $(_mpcc_windowed_drift_value(diagnostic.metadata["first_state_drift_window_id"]))")
println("first_state_drift_window_index: $(_mpcc_windowed_drift_value(diagnostic.metadata["first_state_drift_window_index"]))")
println("first_not_trajectory_ready_window_id: $(_mpcc_windowed_drift_value(diagnostic.metadata["first_not_trajectory_ready_window_id"]))")
println("first_not_trajectory_ready_window_index: $(_mpcc_windowed_drift_value(diagnostic.metadata["first_not_trajectory_ready_window_index"]))")
println("first_iteration_limit_window_id: $(_mpcc_windowed_drift_value(diagnostic.metadata["first_iteration_limit_window_id"]))")
println("dominant_global_abs_state: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_global_abs_state"]))")
println("dominant_global_abs_difference: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_global_abs_difference"]))")
println("dominant_global_abs_ratio: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_global_abs_ratio"]))")
println("dominant_global_relative_state: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_global_relative_state"]))")
println("dominant_global_relative_rmse: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_global_relative_rmse"]))")
println("dominant_global_relative_ratio: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_global_relative_ratio"]))")
println("dominant_global_final_state: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_global_final_state"]))")
println("dominant_global_final_difference: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_global_final_difference"]))")
println("dominant_timepoint_window_id: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_timepoint_window_id"]))")
println("dominant_timepoint_time: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_timepoint_time"]))")
println("dominant_timepoint_state: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_timepoint_state"]))")
println("dominant_timepoint_abs_difference: $(_mpcc_windowed_drift_value(diagnostic.metadata["dominant_timepoint_abs_difference"]))")
println("drift_pattern: $(diagnostic.metadata["drift_pattern"])")
println("drift_coincides_with_iteration_limit: $(diagnostic.metadata["drift_coincides_with_iteration_limit"])")
println("recommended_next_action: $(diagnostic.metadata["recommended_next_action"])")

println("window_drift_table:")
for row in eachrow(diagnostic.window_drift_table)
    println(
        "  $(row["window_id"]) | t=($(_mpcc_windowed_drift_value(row["t0"])),$(_mpcc_windowed_drift_value(row["tfinal"]))) | " *
        "solver=$(_mpcc_windowed_drift_value(row["solver_status"])) | " *
        "ready=$(_mpcc_windowed_drift_value(row["trajectory_ready"])) | " *
        "light=$(_mpcc_windowed_drift_value(row["traffic_light"])) | " *
        "state_pass=$(_mpcc_windowed_drift_value(row["state_drift_pass"])) | " *
        "rel_rmse=$(_mpcc_windowed_drift_value(row["max_state_relative_rmse"])) | " *
        "rel_ratio=$(_mpcc_windowed_drift_value(row["max_state_relative_ratio"])) | " *
        "dom_rel=$(_mpcc_windowed_drift_value(row["dominant_relative_state"])) | " *
        "dom_abs=$(_mpcc_windowed_drift_value(row["dominant_abs_state"])) | " *
        "final_dom=$(_mpcc_windowed_drift_value(row["dominant_final_state"])) | " *
        "blocking=$(_mpcc_windowed_drift_value(row["blocking_reasons"]))",
    )
end

println("top_global_state_drift:")
global_rows = [
    row for row in eachrow(diagnostic.state_drift_table) if
    String(row["scope"]) == "global"
]
global_order = sortperm(
    [Float64(row["relative_rmse_ratio"]) for row in global_rows];
    rev = true,
)
for index in first(global_order, min(8, length(global_order)))
    row = global_rows[index]
    println(
        "  $(row["state_name"]) | rel_rmse=$(_mpcc_windowed_drift_value(row["relative_rmse"])) | " *
        "rel_ratio=$(_mpcc_windowed_drift_value(row["relative_rmse_ratio"])) | " *
        "max_abs=$(_mpcc_windowed_drift_value(row["max_abs_difference"])) | " *
        "abs_ratio=$(_mpcc_windowed_drift_value(row["max_abs_ratio"])) | " *
        "final_diff=$(_mpcc_windowed_drift_value(row["final_difference_mpcc_minus_sequential"]))",
    )
end

println("top_timepoint_drift:")
time_rows = collect(eachrow(diagnostic.timepoint_drift_table))
time_order = sortperm([Float64(row["abs_difference"]) for row in time_rows]; rev = true)
for index in first(time_order, min(8, length(time_order)))
    row = time_rows[index]
    println(
        "  $(row["scope"]) | window=$(_mpcc_windowed_drift_value(row["window_id"])) | " *
        "time=$(_mpcc_windowed_drift_value(row["time"])) | state=$(row["state_name"]) | " *
        "diff=$(_mpcc_windowed_drift_value(row["difference_mpcc_minus_sequential"])) | " *
        "abs=$(_mpcc_windowed_drift_value(row["abs_difference"])) | " *
        "ratio=$(_mpcc_windowed_drift_value(row["abs_difference_ratio"]))",
    )
end

println("interpretation_note: $(diagnostic.metadata["interpretation_note"])")
