using FermentationDFBA
using DataFrames

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")
output_dir = joinpath(project_root, "results", "dfvb_baseline", "latest")

artifacts = load_dfvb_artifacts(
    paths_config;
    load_alpha_trajectories = true,
    load_active_alpha_trajectories = true,
    load_state_trajectories = true,
)
validation = validate_dfvb_artifacts(artifacts)
validation.ok || error("DFVB baseline report artifact validation failed: $(join(validation.errors, "; "))")

report = build_dfvb_baseline_report(artifacts)
report_paths = export_dfvb_baseline_report(report, output_dir; overwrite = true)
plot_paths = write_dfvb_baseline_report_plots(report, output_dir; overwrite = true)

function _dfvb_baseline_script_final_state(report::DFVBBaselineReport, state_name::AbstractString)
    state_name in names(report.state_timeseries) ||
        error("DFVB baseline report state table is missing state $(String(state_name)).")
    return report.state_timeseries[end, state_name]
end

function _dfvb_baseline_script_sorted_paths(paths::Dict{String, String})
    return [key => paths[key] for key in sort(collect(keys(paths)))]
end

println("MATLAB DFVB baseline trajectory report")
println("output_dir: $output_dir")
println("artifact_id: $(report.metadata["artifact_id"])")
println("state_time_points: $(report.metadata["n_time_points"])")
println("state_time_range: $(report.metadata["state_time_start"]) to $(report.metadata["state_time_end"])")
println("n_states: $(report.metadata["n_states"])")
println("n_active_alphas: $(report.metadata["n_active_alphas"])")
println("n_full_alphas: $(report.metadata["n_full_alphas"])")
println("final_biomass: $(_dfvb_baseline_script_final_state(report, "biomass"))")
println("final_glucose: $(_dfvb_baseline_script_final_state(report, "glucose"))")
println("final_fructose: $(_dfvb_baseline_script_final_state(report, "fructose"))")
println("final_ethanol: $(_dfvb_baseline_script_final_state(report, "ethanol"))")
println("final_oxygen: $(_dfvb_baseline_script_final_state(report, "oxygen"))")
println("csv_toml_files:")
for (key, path) in _dfvb_baseline_script_sorted_paths(report_paths)
    println("  $key: $path")
end
println("svg_files:")
for (key, path) in _dfvb_baseline_script_sorted_paths(plot_paths)
    println("  $key: $path")
end
println("alpha_mapping_note: $(report.metadata["alpha_mapping_note"])")
println("oxygen_policy_note: $(report.metadata["oxygen_policy_note"])")
println("exchange_partition_note: $(report.metadata["exchange_partition_note"])")
println("r0001_used_as_oxygen: $(report.metadata["r0001_used_as_oxygen"])")
println("oxygen_reaction_id: $(report.metadata["oxygen_reaction_id"])")
println("active_alpha_timeseries_exported: $(report.metadata["active_alpha_timeseries_exported"])")
println("full_alpha_timeseries_exported: $(report.metadata["full_alpha_timeseries_exported"])")
println("julia_simulation_run: $(report.metadata["julia_simulation_run"])")
println("lp_solve_run: $(report.metadata["lp_solve_run"])")
println("interpretation_note: $(report.metadata["interpretation_note"])")
println("validation_warning_count: $(length(validation.warnings))")
for warning_message in validation.warnings
    println("  warning: $warning_message")
end
