using FermentationDFBA

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

state = default_zenteno_initial_state()
y = [
    state.biomass,
    state.nitrogen,
    state.glucose,
    state.fructose,
    state.ethanol,
    state.oxygen,
    state.protein,
    state.carbohydrate,
    state.amino_acids...,
    state.aromas...,
]
result = compute_dfba_rhs(model, reaction_map, y)
context = DFBAContext(model, reaction_map)
du = similar(y)
dfba_rhs!(du, y, context, 0.0)
wrapper_matches =
    length(du) == length(result.dy) &&
    all(isapprox(du[i], result.dy[i]; rtol = 1.0e-7, atol = 1.0e-9) for i in eachindex(result.dy))

println("Sequential reduced DFBA RHS report")
println("This script performs one RHS evaluation only and does not integrate the ODE system yet.")
println("model_id: $(model.model_id)")
println("mode: $(result.mode)")
println("solver_status: $(result.fba.status)")
println("objective_value: $(result.fba.objective_value)")
println("objective_type: $(result.metadata["objective_type"])")
println("n_objective_terms: $(result.metadata["n_objective_terms"])")
println("dfba_rhs! wrapper matches compute_dfba_rhs: $wrapper_matches")

println("selected_fluxes:")
for rxn_id in ("r_2111", "r_1714", "r_1709", "r_1761", "r_4047", "r_4048")
    println("  $rxn_id = $(result.fluxes_by_rxn[rxn_id])")
end

println("diagnostics:")
println("  mass_balance_residual: $(result.fba.mass_balance_residual)")
println("  max_lower_bound_violation: $(result.fba.max_lower_bound_violation)")
println("  max_upper_bound_violation: $(result.fba.max_upper_bound_violation)")
println("  oxygen_derivative_policy: $(result.metadata["oxygen_derivative_policy"])")
println("  carbohydrate_derivative_policy: $(result.metadata["carbohydrate_derivative_policy"])")
println("  indices_reacciones_used: $(result.metadata["indices_reacciones_used"])")

state_names = [
    "biomass",
    "nitrogen",
    "glucose",
    "fructose",
    "ethanol",
    "oxygen",
    "protein",
    "carbohydrate",
    "phenylalanine",
    "leucine",
    "valine",
    "methionine",
    "tyrosine",
    "phenylethanol",
    "isoamyl_alcohol",
    "isobutanol",
    "methionol",
    "tyrosol",
    "ethyl_acetate",
]

println("state_derivatives:")
for (i, name) in enumerate(state_names)
    println("  dy[$i] $name = $(result.dy[i])")
end
