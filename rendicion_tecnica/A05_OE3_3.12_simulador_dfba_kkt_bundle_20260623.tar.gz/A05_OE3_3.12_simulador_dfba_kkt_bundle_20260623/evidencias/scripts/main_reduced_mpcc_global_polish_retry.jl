using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_GLOBAL_POLISH_RETRY_PROFILE = "smoke"

function _mpcc_global_polish_retry_profile()
    raw = strip(
        get(
            ENV,
            "MPCC_GLOBAL_POLISH_RETRY_PROFILE",
            DEFAULT_MPCC_GLOBAL_POLISH_RETRY_PROFILE,
        ),
    )
    normalized = lowercase(raw)
    normalized in ("smoke", "focused", "grid", "72h", "custom") ||
        error("Environment variable MPCC_GLOBAL_POLISH_RETRY_PROFILE must be one of: smoke, focused, grid, 72h, custom. Got: $raw")
    return normalized
end

function _mpcc_global_polish_retry_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizons = "1.5",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 1,
            max_windows = 3,
            max_retry_attempts = 2,
            source_max_iter = 100,
            source_retry_max_windows = 1,
            source_retry_max_iters = "200,300",
            cascade_max_iter = 300,
            base_global_max_iter = 500,
            retry_global_max_iters = "1000",
            mass_threshold = "5e-6",
        )
    elseif profile == "focused"
        return (
            target_horizons = "1.5,3.0",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 2,
            max_windows = 6,
            max_retry_attempts = 4,
            source_max_iter = 100,
            source_retry_max_windows = 2,
            source_retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            base_global_max_iter = 500,
            retry_global_max_iters = "1000",
            mass_threshold = "5e-6",
        )
    elseif profile == "grid"
        return (
            target_horizons = "0.5,1.0,1.5,2.0,3.0,4.0",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 6,
            max_windows = 8,
            max_retry_attempts = 8,
            source_max_iter = 100,
            source_retry_max_windows = 2,
            source_retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            base_global_max_iter = 500,
            retry_global_max_iters = "1000",
            mass_threshold = "5e-6",
        )
    elseif profile == "72h"
        return (
            target_horizons = "1.5,3.0,4.0,8.0,16.0,32.0,72.0",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 7,
            max_windows = 144,
            max_retry_attempts = 14,
            source_max_iter = 100,
            source_retry_max_windows = 4,
            source_retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            base_global_max_iter = 500,
            retry_global_max_iters = "1000",
            mass_threshold = "5e-6",
        )
    else
        return (
            target_horizons = "1.5",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 1,
            max_windows = 3,
            max_retry_attempts = 2,
            source_max_iter = 100,
            source_retry_max_windows = 1,
            source_retry_max_iters = "200,300",
            cascade_max_iter = 300,
            base_global_max_iter = 500,
            retry_global_max_iters = "1000",
            mass_threshold = "5e-6",
        )
    end
end

function _mpcc_global_polish_retry_env_float_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Float64}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && error("Environment variable $name contains invalid Float64 token: $stripped")
        isfinite(value) && value > 0.0 ||
            error("Environment variable $name values must be finite and positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_global_polish_retry_env_positive_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_global_polish_retry_env_positive_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_global_polish_retry_env_nonnegative_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value >= 0 || error("Environment variable $name must be nonnegative, got: $value")
    return value
end

function _mpcc_global_polish_retry_env_optional_nonnegative_int(
    name::AbstractString,
)
    raw = strip(get(ENV, String(name), ""))
    isempty(raw) && return nothing
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int when set, got: $raw")
    value >= 0 || error("Environment variable $name must be nonnegative, got: $value")
    return value
end

function _mpcc_global_polish_retry_env_optional_positive_int(
    name::AbstractString,
)
    raw = strip(get(ENV, String(name), ""))
    isempty(raw) && return nothing
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int when set, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_global_polish_retry_env_optional_nonnegative_float(
    name::AbstractString,
)
    raw = strip(get(ENV, String(name), ""))
    isempty(raw) && return nothing
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64 when set, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $value")
    return value
end

function _mpcc_global_polish_retry_parse_int_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        parsed = tryparse(Int, stripped)
        parsed === nothing && error("Environment variable $name has invalid Int token: $stripped")
        parsed > 0 || error("Environment variable $name values must be positive, got: $parsed")
        push!(values, parsed)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_global_polish_retry_source_mode(default_value::AbstractString)::String
    raw = strip(get(ENV, "MPCC_GLOBAL_POLISH_RETRY_SOURCE", String(default_value)))
    normalized = lowercase(raw)
    normalized in ("cascade", "windowed") ||
        error("Environment variable MPCC_GLOBAL_POLISH_RETRY_SOURCE must be cascade or windowed. Got: $raw")
    return normalized
end

function _mpcc_global_polish_retry_validate_size!(
    target_horizons::Vector{Float64},
    window_hours::Float64,
    max_cases::Int,
    max_windows::Int,
    max_retry_attempts::Int,
    retry_global_max_iters::Vector{Int},
    allow_large::Bool,
    allow_long::Bool,
)
    if length(target_horizons) > max_cases && !allow_large
        error(
            "Requested MPCC global polish retry has $(length(target_horizons)) base cases, above " *
            "MPCC_GLOBAL_POLISH_RETRY_MAX_CASES=$max_cases. Set " *
            "MPCC_GLOBAL_POLISH_RETRY_ALLOW_LARGE=1 only for deliberate diagnostics.",
        )
    end
    for target in target_horizons
        raw = target / window_hours
        isapprox(raw, round(Int, raw); atol = 1.0e-10, rtol = 1.0e-10) ||
            error("Each target horizon must be an integer multiple of window_hours. Got target=$target, window=$window_hours.")
    end
    requested_windows = maximum(round(Int, target / window_hours) for target in target_horizons)
    if requested_windows > max_windows && !allow_long
        error(
            "Requested MPCC global polish retry has up to $requested_windows windows, above " *
            "MPCC_GLOBAL_POLISH_RETRY_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_GLOBAL_POLISH_RETRY_ALLOW_LONG=1 only for deliberate longer diagnostics.",
        )
    end
    requested_attempt_upper_bound = length(target_horizons) * length(retry_global_max_iters)
    if requested_attempt_upper_bound > max_retry_attempts && !allow_large
        error(
            "Requested MPCC global polish retry may run up to $requested_attempt_upper_bound retry attempts, above " *
            "MPCC_GLOBAL_POLISH_RETRY_MAX_RETRY_ATTEMPTS=$max_retry_attempts. Set " *
            "MPCC_GLOBAL_POLISH_RETRY_ALLOW_LARGE=1 only for deliberate diagnostics.",
        )
    end
    return nothing
end

function _mpcc_global_polish_retry_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_global_polish_retry_base_progress_callback(progress::Bool)
    progress || return nothing
    return function (row, row_index, total)
        println(
            "base_progress_case: $row_index/$total | " *
            "id=$(_mpcc_global_polish_retry_value(row["global_polish_case_id"])) | " *
            "target=$(_mpcc_global_polish_retry_value(row["target_horizon"])) | " *
            "global_light=$(_mpcc_global_polish_retry_value(row["global_polish_traffic_light"])) | " *
            "solver=$(_mpcc_global_polish_retry_value(row["solver_status"])) | " *
            "profile=$(_mpcc_global_polish_retry_value(row["ipopt_profile"])) | " *
            "ready=$(_mpcc_global_polish_retry_value(row["candidate_trajectory_ready"]))",
        )
    end
end

function _mpcc_global_polish_retry_progress_callback(progress::Bool)
    progress || return nothing
    return function (row, retry_index, retryable_count)
        println(
            "retry_progress_case: $retry_index | retryable_cases=$retryable_count | " *
            "id=$(_mpcc_global_polish_retry_value(row["global_polish_retry_case_id"])) | " *
            "base=$(_mpcc_global_polish_retry_value(row["base_global_polish_case_id"])) | " *
            "target=$(_mpcc_global_polish_retry_value(row["target_horizon"])) | " *
            "retry_iter=$(_mpcc_global_polish_retry_value(row["retry_ipopt_max_iter"])) | " *
            "retry_light=$(_mpcc_global_polish_retry_value(row["retry_global_polish_traffic_light"])) | " *
            "solver=$(_mpcc_global_polish_retry_value(row["retry_solver_status"])) | " *
            "ready=$(_mpcc_global_polish_retry_value(row["retry_candidate_trajectory_ready"]))",
        )
    end
end

profile = _mpcc_global_polish_retry_profile()
defaults = _mpcc_global_polish_retry_profile_defaults(profile)
target_horizons = _mpcc_global_polish_retry_env_float_list(
    "MPCC_GLOBAL_POLISH_RETRY_TARGET_HOURS",
    defaults.target_horizons,
)
source_mode = _mpcc_global_polish_retry_source_mode(defaults.source_mode)
window_hours = _mpcc_global_polish_retry_env_positive_float(
    "MPCC_GLOBAL_POLISH_RETRY_WINDOW_HOURS",
    defaults.window_hours,
)
nfe_per_window = _mpcc_global_polish_retry_env_positive_int(
    "MPCC_GLOBAL_POLISH_RETRY_NFE",
    defaults.nfe,
)
max_cases = _mpcc_global_polish_retry_env_positive_int(
    "MPCC_GLOBAL_POLISH_RETRY_MAX_CASES",
    defaults.max_cases,
)
max_windows = _mpcc_global_polish_retry_env_positive_int(
    "MPCC_GLOBAL_POLISH_RETRY_MAX_WINDOWS",
    defaults.max_windows,
)
max_retry_attempts = _mpcc_global_polish_retry_env_positive_int(
    "MPCC_GLOBAL_POLISH_RETRY_MAX_RETRY_ATTEMPTS",
    defaults.max_retry_attempts,
)
source_max_iter = _mpcc_global_polish_retry_env_positive_int(
    "MPCC_GLOBAL_POLISH_RETRY_SOURCE_MAX_ITER",
    defaults.source_max_iter,
)
source_retry_max_windows = _mpcc_global_polish_retry_env_nonnegative_int(
    "MPCC_GLOBAL_POLISH_RETRY_SOURCE_MAX_RETRY_WINDOWS",
    defaults.source_retry_max_windows,
)
source_retry_max_iters = _mpcc_global_polish_retry_parse_int_list(
    "MPCC_GLOBAL_POLISH_RETRY_SOURCE_RETRY_MAX_ITERS",
    defaults.source_retry_max_iters,
)
cascade_max_iter = _mpcc_global_polish_retry_env_positive_int(
    "MPCC_GLOBAL_POLISH_RETRY_CASCADE_MAX_ITER",
    defaults.cascade_max_iter,
)
base_global_max_iter = _mpcc_global_polish_retry_env_positive_int(
    "MPCC_GLOBAL_POLISH_RETRY_BASE_GLOBAL_MAX_ITER",
    defaults.base_global_max_iter,
)
retry_global_max_iters = _mpcc_global_polish_retry_parse_int_list(
    "MPCC_GLOBAL_POLISH_RETRY_GLOBAL_MAX_ITERS",
    defaults.retry_global_max_iters,
)
ipopt_profile = reduced_mpcc_ipopt_profile_name_from_env()
mass_threshold = _mpcc_global_polish_retry_env_positive_float(
    "MPCC_GLOBAL_POLISH_RETRY_MASS_THRESHOLD",
    defaults.mass_threshold,
)
selection_policy =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_RETRY_SELECTION_POLICY", "iteration_limit_or_not_ready"))
replacement_policy =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_RETRY_REPLACEMENT_POLICY", "green_or_trajectory_ready"))
retry_policy = strip(
    get(ENV, "MPCC_GLOBAL_POLISH_RETRY_POLICY", "residual_feasible_iteration_limit"),
)
allow_large = _script_env_bool("MPCC_GLOBAL_POLISH_RETRY_ALLOW_LARGE", false)
allow_long = _script_env_bool("MPCC_GLOBAL_POLISH_RETRY_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_GLOBAL_POLISH_RETRY_CONTINUE_ON_ERROR", true)
source_require_pre_solve_ready =
    _script_env_bool("MPCC_GLOBAL_POLISH_RETRY_SOURCE_REQUIRE_PREFLIGHT", true)
base_global_require_pre_solve_ready =
    _script_env_bool("MPCC_GLOBAL_POLISH_RETRY_BASE_GLOBAL_REQUIRE_PREFLIGHT", false)
retry_require_pre_solve_ready =
    _script_env_bool("MPCC_GLOBAL_POLISH_RETRY_REQUIRE_PREFLIGHT", false)
silent = _script_env_bool("MPCC_GLOBAL_POLISH_RETRY_SILENT", true)
progress = _script_env_bool("MPCC_GLOBAL_POLISH_RETRY_PROGRESS", profile != "smoke")
stop_on_green = _script_env_bool("MPCC_GLOBAL_POLISH_RETRY_STOP_ON_GREEN", true)
retry_ipopt_print_level = _mpcc_global_polish_retry_env_optional_nonnegative_int(
    "MPCC_GLOBAL_POLISH_RETRY_IPOPT_PRINT_LEVEL",
)
retry_ipopt_print_frequency_iter =
    _mpcc_global_polish_retry_env_optional_positive_int(
        "MPCC_GLOBAL_POLISH_RETRY_IPOPT_PRINT_FREQUENCY_ITER",
    )
retry_ipopt_print_frequency_time =
    _mpcc_global_polish_retry_env_optional_nonnegative_float(
        "MPCC_GLOBAL_POLISH_RETRY_IPOPT_PRINT_FREQUENCY_TIME",
    )
retry_silent =
    retry_ipopt_print_level !== nothing && retry_ipopt_print_level > 0 ? false : silent

_mpcc_global_polish_retry_validate_size!(
    target_horizons,
    window_hours,
    max_cases,
    max_windows,
    max_retry_attempts,
    retry_global_max_iters,
    allow_large,
    allow_long,
)

println("Reduced MPCC global polish iteration-limit retry")
println("profile: $profile")
println("source_mode: $source_mode")
println("target_horizons: $(join(target_horizons, ","))")
println("window_hours: $window_hours")
println("nfe_per_window: $nfe_per_window")
println("mass_threshold: $mass_threshold")
println("source_ipopt_max_iter: $source_max_iter")
println("source_retry_max_windows: $source_retry_max_windows")
println("source_retry_max_iters: $(join(source_retry_max_iters, ","))")
println("cascade_max_iter: $cascade_max_iter")
println("base_global_ipopt_max_iter: $base_global_max_iter")
println("retry_global_ipopt_max_iters: $(join(retry_global_max_iters, ","))")
println("ipopt_profile: $ipopt_profile")
println("retry_policy: $retry_policy")
println("selection_policy: $selection_policy")
println("replacement_policy: $replacement_policy")
println("source_require_pre_solve_ready: $source_require_pre_solve_ready")
println("base_global_require_pre_solve_ready: $base_global_require_pre_solve_ready")
println("retry_require_pre_solve_ready: $retry_require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("stop_on_green: $stop_on_green")
println("progress: $progress")
println("retry_ipopt_print_level: $retry_ipopt_print_level")
println("retry_ipopt_print_frequency_iter: $(_mpcc_global_polish_retry_value(retry_ipopt_print_frequency_iter))")
println("retry_ipopt_print_frequency_time: $(_mpcc_global_polish_retry_value(retry_ipopt_print_frequency_time))")
println("retry_silent: $retry_silent")

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

base_residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds(
    max_rhs_residual = base_residual_thresholds.max_rhs_residual,
    max_mass_balance_residual = mass_threshold,
    max_lower_bound_violation = base_residual_thresholds.max_lower_bound_violation,
    max_upper_bound_violation = base_residual_thresholds.max_upper_bound_violation,
    max_stationarity_residual = base_residual_thresholds.max_stationarity_residual,
    max_lower_complementarity_residual =
        base_residual_thresholds.max_lower_complementarity_residual,
    max_upper_complementarity_residual =
        base_residual_thresholds.max_upper_complementarity_residual,
)
viability_thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
    residual_thresholds = residual_thresholds,
)

base_sweep = sweep_reduced_dcdfba_mpcc_global_polish_horizons(
    model,
    reaction_map;
    target_horizons = target_horizons,
    source_mode = source_mode,
    window_hours = window_hours,
    nfe_per_window = nfe_per_window,
    degree = 3,
    source_ipopt_max_iter = source_max_iter,
    retry_ipopt_max_iter_values = source_retry_max_iters,
    retry_selection_policy = selection_policy,
    retry_max_windows = source_retry_max_windows,
    cascade_ipopt_max_iter = cascade_max_iter,
    replacement_acceptance_policy = replacement_policy,
    global_ipopt_max_iter = base_global_max_iter,
    ipopt_profile = ipopt_profile,
    source_require_pre_solve_ready = source_require_pre_solve_ready,
    global_require_pre_solve_ready = base_global_require_pre_solve_ready,
    residual_thresholds = residual_thresholds,
    viability_thresholds = viability_thresholds,
    silent = silent,
    continue_on_error = continue_on_error,
    stop_after_first_non_green = false,
    case_callback = _mpcc_global_polish_retry_base_progress_callback(progress),
)

retry = retry_reduced_dcdfba_mpcc_global_polish_iteration_limits(
    base_sweep;
    retry_ipopt_max_iter_values = retry_global_max_iters,
    retry_policy = retry_policy,
    stop_on_green = stop_on_green,
    continue_on_error = continue_on_error,
    retry_callback = _mpcc_global_polish_retry_progress_callback(progress),
    retry_runner = function (base_result, retry_ipopt_max_iter, _, _)
        retry_optimizer = reduced_mpcc_ipopt_optimizer(
            profile = ipopt_profile,
            print_level = retry_ipopt_print_level,
            max_iter = retry_ipopt_max_iter,
            print_frequency_iter = retry_ipopt_print_frequency_iter,
            print_frequency_time = retry_ipopt_print_frequency_time,
        )
        return polish_reduced_dcdfba_mpcc_windowed_candidate(
            model,
            reaction_map,
            base_result.source_continuation;
            residual_thresholds = residual_thresholds,
            optimizer = retry_optimizer,
            ipopt_max_iter = retry_ipopt_max_iter,
            ipopt_profile = ipopt_profile,
            require_pre_solve_ready = retry_require_pre_solve_ready,
            silent = retry_silent,
        )
    end,
)

println("outputs_written: $(retry.metadata["outputs_written"])")
println("retry_is_scientific_simulation: $(retry.metadata["retry_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(retry.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(retry.metadata["scientific_baseline"])")
println("first_mpcc_target: $(retry.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(retry.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(retry.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(retry.metadata["hsl_required"])")
println("ma57_required: $(retry.metadata["ma57_required"])")
println("indices_reacciones_used: $(retry.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(retry.metadata["r0001_used_as_oxygen"])")
println("base_n_cases: $(retry.metadata["base_n_cases"])")
println("base_green_count: $(retry.metadata["base_green_count"])")
println("base_yellow_count: $(retry.metadata["base_yellow_count"])")
println("base_red_count: $(retry.metadata["base_red_count"])")
println("base_best_green_target_horizon: $(_mpcc_global_polish_retry_value(retry.metadata["base_best_green_target_horizon"]))")
println("retryable_case_count: $(retry.metadata["retryable_case_count"])")
println("retried_case_count: $(retry.metadata["retried_case_count"])")
println("retry_attempt_count: $(retry.metadata["retry_attempt_count"])")
println("retry_completed_count: $(retry.metadata["retry_completed_count"])")
println("retry_failed_count: $(retry.metadata["retry_failed_count"])")
println("retry_green_count: $(retry.metadata["retry_green_count"])")
println("retry_yellow_count: $(retry.metadata["retry_yellow_count"])")
println("retry_red_count: $(retry.metadata["retry_red_count"])")
println("recovered_case_count: $(retry.metadata["recovered_case_count"])")
println("unrecovered_case_count: $(retry.metadata["unrecovered_case_count"])")
println("all_retryable_cases_recovered: $(retry.metadata["all_retryable_cases_recovered"])")
println("best_recovered_case_id: $(_mpcc_global_polish_retry_value(retry.metadata["best_recovered_case_id"]))")
println("best_recovered_target_horizon: $(_mpcc_global_polish_retry_value(retry.metadata["best_recovered_target_horizon"]))")
println("best_recovered_retry_ipopt_max_iter: $(_mpcc_global_polish_retry_value(retry.metadata["best_recovered_retry_ipopt_max_iter"]))")
println("total_base_solve_elapsed_seconds: $(_mpcc_global_polish_retry_value(retry.metadata["total_base_solve_elapsed_seconds"]))")
println("total_retry_solve_elapsed_seconds: $(retry.metadata["total_retry_solve_elapsed_seconds"])")
println("recommended_next_action: $(retry.metadata["recommended_next_action"])")

println("base_global_polish_table:")
for row in eachrow(base_sweep.global_polish_table)
    println(
        "  $(row["global_polish_case_id"]) | target=$(_mpcc_global_polish_retry_value(row["target_horizon"])) | " *
        "global_light=$(_mpcc_global_polish_retry_value(row["global_polish_traffic_light"])) | " *
        "solver=$(_mpcc_global_polish_retry_value(row["solver_status"])) | " *
        "profile=$(_mpcc_global_polish_retry_value(row["ipopt_profile"])) | " *
        "ready=$(_mpcc_global_polish_retry_value(row["candidate_trajectory_ready"])) | " *
        "residual_feasible=$(_mpcc_global_polish_retry_value(row["candidate_residual_feasible"])) | " *
        "global_horizon=$(_mpcc_global_polish_retry_value(row["global_horizon"])) | " *
        "global_nfe=$(_mpcc_global_polish_retry_value(row["global_nfe"])) | " *
        "dof=$(_mpcc_global_polish_retry_value(row["nlp_structure_dof_balance"])) | " *
        "fixed=$(_mpcc_global_polish_retry_value(row["nlp_structure_fixed_variable_count"])) | " *
        "dof_risk=$(_mpcc_global_polish_retry_value(row["nlp_structure_too_few_degrees_of_freedom_risk"])) | " *
        "mass_resid=$(_mpcc_global_polish_retry_value(row["max_mass_balance_residual"])) | " *
        "state_rmse=$(_mpcc_global_polish_retry_value(row["max_state_relative_rmse"])) | " *
        "solve_s=$(_mpcc_global_polish_retry_value(row["solve_elapsed_seconds"]))",
    )
end

println("global_polish_retry_table:")
for row in eachrow(retry.retry_table)
    println(
        "  $(row["global_polish_retry_case_id"]) | base=$(_mpcc_global_polish_retry_value(row["base_global_polish_case_id"])) | " *
        "target=$(_mpcc_global_polish_retry_value(row["target_horizon"])) | " *
        "base_light=$(_mpcc_global_polish_retry_value(row["base_global_polish_traffic_light"])) | " *
        "retry_iter=$(_mpcc_global_polish_retry_value(row["retry_ipopt_max_iter"])) | " *
        "retry_light=$(_mpcc_global_polish_retry_value(row["retry_global_polish_traffic_light"])) | " *
        "recovered=$(_mpcc_global_polish_retry_value(row["retry_recovered"])) | " *
        "solver=$(_mpcc_global_polish_retry_value(row["retry_solver_status"])) | " *
        "profile=$ipopt_profile | " *
        "ready=$(_mpcc_global_polish_retry_value(row["retry_candidate_trajectory_ready"])) | " *
        "mass_resid=$(_mpcc_global_polish_retry_value(row["retry_max_mass_balance_residual"])) | " *
        "state_rmse=$(_mpcc_global_polish_retry_value(row["retry_max_state_relative_rmse"])) | " *
        "solve_s=$(_mpcc_global_polish_retry_value(row["retry_solve_elapsed_seconds"]))",
    )
end

println("interpretation_note: $(retry.metadata["interpretation_note"])")
