using CSV
using DataFrames
using Dates
using TOML

const POLICY_SELECTION_SCRIPT = "main_dynamic_control_policy_selection.jl"

project_root = normpath(joinpath(@__DIR__, ".."))

function _policy_env_bool(name::AbstractString, default::Bool)::Bool
    raw_value = lowercase(strip(get(ENV, String(name), string(default))))
    if raw_value in ("1", "true", "yes", "y", "on")
        return true
    elseif raw_value in ("0", "false", "no", "n", "off")
        return false
    end
    error("Environment variable $name must be boolean, got: $raw_value")
end

function _policy_env_positive_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _policy_env_nonnegative_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _policy_env_path(name::AbstractString, default_relative::AbstractString)::String
    raw_value = strip(get(ENV, String(name), default_relative))
    isempty(raw_value) && error("Environment variable $name must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _policy_optional_env_path(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _policy_optional_env_positive_float(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _policy_split_ids(raw_value::AbstractString)::Vector{String}
    ids = String[]
    for token in split(replace(raw_value, ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        push!(ids, cleaned)
    end
    return unique(ids)
end

function _policy_env_selected_ids(name::AbstractString)::Vector{String}
    key = String(name)
    haskey(ENV, key) || return String[]
    return _policy_split_ids(ENV[key])
end

function _policy_default_metadata_path(candidate_path::AbstractString)
    candidate_dir = dirname(candidate_path)
    default_path = joinpath(candidate_dir, "dynamic_control_objective_metadata.toml")
    return isfile(default_path) ? default_path : nothing
end

function _policy_load_metadata(metadata_path)
    metadata_path === nothing && return Dict{String, Any}()
    isfile(metadata_path) || error("Metadata TOML does not exist: $metadata_path")
    return TOML.parsefile(metadata_path)
end

function _policy_require_columns(table::DataFrame, columns::Vector{Symbol})
    names_set = Set(Symbol.(names(table)))
    missing_columns = [String(column) for column in columns if !(column in names_set)]
    isempty(missing_columns) || error(
        "Candidate table is missing required column(s): " * join(missing_columns, ", "),
    )
    return nothing
end

function _policy_row_value(row::DataFrameRow, column::Symbol, default = missing)
    return column in propertynames(row) ? row[column] : default
end

function _policy_bool(value)::Bool
    if value isa Bool
        return value
    elseif value isa Missing
        return false
    end
    raw = lowercase(strip(string(value)))
    raw in ("1", "true", "yes", "y") && return true
    raw in ("0", "false", "no", "n") && return false
    return false
end

function _policy_float(value, default::Float64 = NaN)::Float64
    value isa Missing && return default
    value isa Real && return Float64(value)
    parsed = tryparse(Float64, strip(string(value)))
    return parsed === nothing ? default : parsed
end

function _policy_candidate_index(table::DataFrame)::Dict{String, Int}
    ids = String.(table.candidate_id)
    length(unique(ids)) == length(ids) || error("Candidate IDs must be unique in policy input.")
    return Dict(id => i for (i, id) in enumerate(ids))
end

function _policy_scalar_best_id(table::DataFrame)::String
    feasible_indices = [
        i for i in 1:nrow(table) if _policy_bool(table.feasible[i]) &&
        (!(:gate_pass in propertynames(table)) || _policy_bool(table.gate_pass[i]))
    ]
    isempty(feasible_indices) && error("No feasible/gated candidates available for scalar best.")
    best_index = feasible_indices[argmin(Float64.(table.objective_value[feasible_indices]))]
    return String(table.candidate_id[best_index])
end

function _policy_auto_selected_ids(
    table::DataFrame;
    count::Int,
    include_scalar_best::Bool,
)::Vector{String}
    selected = String[]
    if :selected_for_review in propertynames(table)
        review_indices = [i for i in 1:nrow(table) if _policy_bool(table.selected_for_review[i])]
        sort!(
            review_indices;
            by = i -> :selection_rank in propertynames(table) ?
                      max(1, Int(_policy_float(table.selection_rank[i], 1.0e9))) :
                      i,
        )
        for i in review_indices
            push!(selected, String(table.candidate_id[i]))
            length(selected) >= count && break
        end
    end
    if include_scalar_best
        scalar_best = _policy_scalar_best_id(table)
        if !(scalar_best in selected)
            if length(selected) >= count
                selected[end] = scalar_best
            else
                push!(selected, scalar_best)
            end
        end
    end
    if isempty(selected)
        ranked_indices = sortperm(Float64.(table.objective_value))
        for i in ranked_indices
            _policy_bool(table.feasible[i]) || continue
            push!(selected, String(table.candidate_id[i]))
            length(selected) >= count && break
        end
    end
    return unique(selected)
end

function _policy_format(value; digits::Int = 3)::String
    float_value = _policy_float(value)
    isfinite(float_value) || return string(value)
    return string(round(float_value; digits = digits))
end

function _policy_role(candidate_id::AbstractString, row::DataFrameRow, scalar_best_id::AbstractString)::String
    if candidate_id == scalar_best_id
        return "scalar_objective_fda_comparator"
    elseif occursin("springferm_early_0p4", candidate_id)
        return "pareto_springferm_early_high_sugar_reduction"
    elseif occursin("springferm_split_0p1_0p1", candidate_id)
        return "pareto_springferm_split_aroma_low_nutrient"
    elseif occursin("mixed", candidate_id)
        return "pareto_mixed_fda_organic"
    elseif occursin("fda", candidate_id)
        return "fda_comparator"
    end
    selection_basis = string(_policy_row_value(row, :selection_basis, "selected_policy"))
    return "selected_" * replace(selection_basis, ' ' => '_')
end

function _policy_reason(candidate_id::AbstractString, row::DataFrameRow, scalar_best_id::AbstractString)::String
    final_sugar = _policy_format(_policy_row_value(row, :final_total_sugar))
    aroma = _policy_format(_policy_row_value(row, :aroma_desirability_score); digits = 4)
    nutrient = _policy_format(_policy_row_value(row, :nutrient_total_product_g_L))
    objective = _policy_format(_policy_row_value(row, :objective_value))
    if candidate_id == scalar_best_id
        return "Scalar-objective comparator; objective=$(objective), final sugar=$(final_sugar) g/L, aroma=$(aroma), nutrient=$(nutrient) g/L."
    elseif occursin("springferm_early_0p4", candidate_id)
        return "Best gated Pareto shortlist sugar-reduction policy; final sugar=$(final_sugar) g/L, aroma=$(aroma), nutrient=$(nutrient) g/L."
    elseif occursin("springferm_split_0p1_0p1", candidate_id)
        return "Gated Pareto low-nutrient split-organic policy with stronger aroma score; final sugar=$(final_sugar) g/L, aroma=$(aroma), nutrient=$(nutrient) g/L."
    end
    return "Selected gated policy; final sugar=$(final_sugar) g/L, aroma=$(aroma), nutrient=$(nutrient) g/L."
end

function _policy_ready(row::DataFrameRow; horizon_h::Float64, state_tol::Float64)::Bool
    feasible = _policy_bool(_policy_row_value(row, :feasible))
    accepted = lowercase(string(_policy_row_value(row, :status, ""))) == "accepted"
    gate_pass = _policy_bool(_policy_row_value(row, :gate_pass))
    final_time = _policy_float(_policy_row_value(row, :final_time))
    min_state = _policy_float(_policy_row_value(row, :min_state_value), 0.0)
    return feasible && accepted && gate_pass && final_time >= horizon_h - 1.0e-8 &&
           min_state >= -state_tol
end

function _policy_toml_normalize(value)
    if value isa Missing || value === nothing
        return "missing"
    elseif value isa Bool
        return value
    elseif value isa Integer
        return Int(value)
    elseif value isa Real
        return _policy_toml_normalize_real(value)
    elseif value isa AbstractString
        return value
    elseif value isa AbstractVector || value isa Tuple
        return [_policy_toml_normalize(item) for item in value]
    elseif value isa AbstractDict
        normalized = Dict{String, Any}()
        for key in sort!(collect(keys(value)); by = string)
            normalized[string(key)] = _policy_toml_normalize(value[key])
        end
        return normalized
    end
    return string(value)
end

function _policy_toml_normalize_real(value::Real)
    float_value = Float64(value)
    isfinite(float_value) && return float_value
    if isnan(float_value)
        return "NaN"
    elseif float_value == Inf
        return "Inf"
    elseif float_value == -Inf
        return "-Inf"
    end
    return string(value)
end

candidate_path = _policy_env_path(
    "DFBA_DYNAMIC_CONTROL_POLICY_CANDIDATES_CSV",
    joinpath("results", "dynamic_control_objective_smoke_latest", "dynamic_control_objective_candidates.csv"),
)
isfile(candidate_path) || error("Candidate CSV does not exist: $candidate_path")

metadata_path = _policy_optional_env_path("DFBA_DYNAMIC_CONTROL_POLICY_METADATA_TOML")
metadata_path = metadata_path === nothing ? _policy_default_metadata_path(candidate_path) : metadata_path
metadata = _policy_load_metadata(metadata_path)
output_dir = _policy_env_path(
    "DFBA_DYNAMIC_CONTROL_POLICY_OUTPUT_DIR",
    joinpath("results", "dynamic_control_policy_selection_latest"),
)
overwrite = _policy_env_bool("DFBA_DYNAMIC_CONTROL_POLICY_OVERWRITE", true)
selected_count = _policy_env_positive_int("DFBA_DYNAMIC_CONTROL_POLICY_COUNT", 3)
include_scalar_best =
    _policy_env_bool("DFBA_DYNAMIC_CONTROL_POLICY_INCLUDE_SCALAR_BEST", true)
state_tol = _policy_env_nonnegative_float("DFBA_DYNAMIC_CONTROL_POLICY_STATE_TOL", 1.0e-8)

table = DataFrame(CSV.File(candidate_path))
_policy_require_columns(
    table,
    [
        :candidate_id,
        :objective_value,
        :feasible,
        :status,
        :final_time,
        :final_total_sugar,
        :aroma_desirability_score,
        :nutrient_total_product_g_L,
        :min_state_value,
        :gate_pass,
        :temperature_values_C,
        :fda_doses_g_L,
        :organic_doses_g_L,
    ],
)

explicit_ids = _policy_env_selected_ids("DFBA_DYNAMIC_CONTROL_POLICY_SELECTED_IDS")
selected_ids =
    isempty(explicit_ids) ?
    _policy_auto_selected_ids(table; count = selected_count, include_scalar_best = include_scalar_best) :
    explicit_ids
isempty(selected_ids) && error("No dynamic-control policy IDs were selected.")

id_to_index = _policy_candidate_index(table)
missing_ids = [id for id in selected_ids if !haskey(id_to_index, id)]
isempty(missing_ids) || error("Selected candidate IDs were not found: " * join(missing_ids, ", "))

scalar_best_id = get(metadata, "best_candidate_id", "")
scalar_best_id = isempty(string(scalar_best_id)) ? _policy_scalar_best_id(table) : string(scalar_best_id)
ready_horizon_override = _policy_optional_env_positive_float(
    "DFBA_DYNAMIC_CONTROL_POLICY_READY_HORIZON_H",
)
horizon_h = ready_horizon_override !== nothing ? ready_horizon_override :
            haskey(metadata, "horizon_h") ? Float64(metadata["horizon_h"]) :
            haskey(metadata, "dynamic_control_horizon_h") ? Float64(metadata["dynamic_control_horizon_h"]) :
            maximum(Float64.(table.final_time))

selected_indices = [id_to_index[id] for id in selected_ids]
selection = table[selected_indices, :]
roles = String[]
reasons = String[]
ready_flags = Bool[]
mpcc_ready_flags = Bool[]
mpcc_blockers = String[]
for row in eachrow(selection)
    candidate_id = String(row.candidate_id)
    push!(roles, _policy_role(candidate_id, row, scalar_best_id))
    push!(reasons, _policy_reason(candidate_id, row, scalar_best_id))
    ready = _policy_ready(row; horizon_h = horizon_h, state_tol = state_tol)
    push!(ready_flags, ready)
    push!(mpcc_ready_flags, false)
    push!(
        mpcc_blockers,
        "Selection only; run main_reduced_mpcc_fixed_control_policy_preflight.jl to build the fixed-control reduced MPCC preflight.",
    )
end

selection[!, :policy_rank] = collect(1:nrow(selection))
selection[!, :policy_role] = roles
selection[!, :policy_reason] = reasons
selection[!, :control_policy_ready] = ready_flags
selection[!, :mpcc_fixed_control_replay_ready] = mpcc_ready_flags
selection[!, :mpcc_fixed_control_replay_blocker] = mpcc_blockers

mkpath(output_dir)
selection_path = joinpath(output_dir, "dynamic_control_policy_selection.csv")
metadata_out_path = joinpath(output_dir, "dynamic_control_policy_selection.toml")
if !overwrite
    existing_targets = [path for path in (selection_path, metadata_out_path) if isfile(path)]
    isempty(existing_targets) || error(
        "Policy selection output file(s) already exist and overwrite=false: " *
        join(existing_targets, ", "),
    )
end

CSV.write(selection_path, selection)

policy_metadata = Dict{String, Any}()
for row in eachrow(selection)
    candidate_id = String(row.candidate_id)
    policy_metadata[candidate_id] = Dict{String, Any}(
        "policy_rank" => Int(row.policy_rank),
        "policy_role" => String(row.policy_role),
        "policy_reason" => String(row.policy_reason),
        "control_policy_ready" => Bool(row.control_policy_ready),
        "mpcc_fixed_control_replay_ready" => Bool(row.mpcc_fixed_control_replay_ready),
        "final_time_h" => _policy_float(row.final_time),
        "final_total_sugar_g_L" => _policy_float(row.final_total_sugar),
        "aroma_desirability_score" => _policy_float(row.aroma_desirability_score),
        "nutrient_total_product_g_L" => _policy_float(row.nutrient_total_product_g_L),
        "temperature_values_C" => String(row.temperature_values_C),
        "fda_doses_g_L" => String(row.fda_doses_g_L),
        "organic_doses_g_L" => String(row.organic_doses_g_L),
    )
end

out_metadata = Dict{String, Any}(
    "script" => POLICY_SELECTION_SCRIPT,
    "created_at" => Dates.format(Dates.now(), dateformat"yyyy-mm-ddTHH:MM:SS"),
    "input_candidates_csv" => candidate_path,
    "input_metadata_toml" => metadata_path === nothing ? "missing" : metadata_path,
    "output_dir" => output_dir,
    "selection_csv" => selection_path,
    "selection_toml" => metadata_out_path,
    "selection_source" => isempty(explicit_ids) ? "auto_from_shortlist_plus_scalar_best" : "explicit_env",
    "selected_candidate_ids" => String.(selection.candidate_id),
    "selected_policy_count" => nrow(selection),
    "source_candidate_count" => nrow(table),
    "source_gate_pass_count" =>
        :gate_pass in propertynames(table) ? count(_policy_bool, table.gate_pass) : "missing",
    "source_best_candidate_id" => scalar_best_id,
    "horizon_h" => horizon_h,
    "ready_horizon_override_h" =>
        ready_horizon_override === nothing ? "missing" : ready_horizon_override,
    "state_tolerance" => state_tol,
    "all_control_policies_ready" => all(ready_flags),
    "mpcc_fixed_control_replay" => Dict{String, Any}(
        "status" => "selection_ready_for_reduced_mpcc_fixed_control_preflight",
        "solves_run" => false,
        "mpcc_fixed_control_replay_ready" => false,
        "dynamic_control_schedule_support_detected" => true,
        "blocker" =>
            "Policy selection does not build MPCC problems; run the fixed-control preflight script next.",
        "next_required_code_change" =>
            "Run scripts/main_reduced_mpcc_fixed_control_policy_preflight.jl, then promote healthy fixed-policy preflights to guarded smoke solves before freeing controls.",
    ),
    "policies" => policy_metadata,
)

open(metadata_out_path, "w") do io
    TOML.print(io, _policy_toml_normalize(out_metadata))
end

println("Dynamic control policy selection")
println("candidate_csv: $candidate_path")
println("metadata_toml: $(metadata_path === nothing ? "missing" : metadata_path)")
println("output_dir: $output_dir")
println("selection_csv: $selection_path")
println("selection_toml: $metadata_out_path")
println("selection_source: $(out_metadata["selection_source"])")
println("selected_policy_count: $(nrow(selection))")
println("all_control_policies_ready: $(all(ready_flags))")
println("mpcc_fixed_control_replay_status: $(out_metadata["mpcc_fixed_control_replay"]["status"])")
println("selected_policies:")
for row in eachrow(selection)
    println(
        "  $(row.policy_rank). $(row.candidate_id) | role=$(row.policy_role) | " *
        "ready=$(row.control_policy_ready) | final_sugar=$(row.final_total_sugar) | " *
        "aroma=$(row.aroma_desirability_score) | nutrient=$(row.nutrient_total_product_g_L)",
    )
end
