#!/usr/bin/env python3
"""Summarize staged dynamic-control MPCC Slurm runs.

The script is intentionally lightweight: it only reads CSV/TOML-ish text
artifacts already produced by Slurm jobs and writes a compact CSV/Markdown
summary. It does not run Julia or solve anything.
"""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path
from typing import Iterable


SUMMARY_COLUMNS = [
    "run_root",
    "job_id",
    "partition",
    "node",
    "case_id",
    "candidate_id",
    "solve_hours",
    "nfe",
    "ipopt_max_iter",
    "solver_status",
    "primal_status",
    "selected_candidate_source",
    "selected_candidate_residual_feasible",
    "selected_candidate_trajectory_ready",
    "post_solve_candidate_accepted",
    "candidate_diagnostics_start_jls_requested",
    "candidate_diagnostics_start_jls_loaded",
    "flux_dual_start_jls_requested",
    "flux_dual_start_jls_loaded",
    "cross_window_flux_dual_start_applied",
    "full_candidate_start_seed_applied",
    "full_candidate_start_seed_apply_dynamic_controls",
    "full_candidate_start_seed_dynamic_controls_applied",
    "full_candidate_start_seed_dynamic_controls_policy",
    "full_candidate_start_seed_dynamic_controls_skip_reason",
    "mpcc_solve_started",
    "mpcc_solve_returned",
    "terminal_total_sugar_g_L",
    "terminal_isoamyl_alcohol_g_L",
    "max_rhs_residual",
    "max_collocation_residual",
    "max_continuity_residual",
    "max_mass_balance_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "complementarity_tau",
    "complementarity_tau_gate_pass",
    "final_complementarity_flux_projection_enabled",
    "final_complementarity_flux_projection_applied",
    "active_complementarity_flux_projection_guard_accepted",
    "final_selective_dual_fit_enabled",
    "final_selective_dual_fit_applied",
    "selective_dual_fit_accepted",
    "selective_dual_fit_budget_fraction",
    "selective_dual_fit_effective_budget_tau",
    "selective_dual_fit_element_count",
    "selective_dual_fit_collocation_points",
    "selective_dual_fit_max_stationarity_after",
    "selective_dual_fit_max_lower_complementarity_after",
    "bound_dual_complementarity_clip_enabled",
    "bound_dual_complementarity_clip_applied",
    "bound_dual_complementarity_clip_effective_complementarity_budget_tau",
    "bound_dual_complementarity_clip_max_lower_complementarity_residual_after",
    "top_complementarity_type",
    "top_complementarity_reaction_id",
    "top_complementarity_time_h",
    "top_complementarity_abs_product",
    "temperature_max_abs_delta_vs_start_C",
    "fda_sum_delta_vs_start_g_L",
    "organic_sum_delta_vs_start_g_L",
    "free_temperature_count",
    "free_fda_count",
    "free_organic_count",
    "objective_integrated_sugar_weight",
    "objective_direct_temperature_reward_weight",
    "objective_direct_fda_reward_weight",
    "objective_direct_organic_reward_weight",
    "reference_regularization_weight",
    "rhs_controls_coupled",
    "dynamic_bounds_controls_coupled",
    "dominant_residual",
]


def _read_single_row_csv(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    with path.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        return {}
    return {key: (value if value is not None else "") for key, value in rows[0].items()}


def _read_key_value_text(path: Path) -> dict[str, str]:
    output: dict[str, str] = {}
    if not path.is_file():
        return output
    for line in path.read_text(errors="replace").splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        output[key.strip()] = value.strip()
    return output


def _read_first_csv_row(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    with path.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        return {}
    return {key: (value if value is not None else "") for key, value in rows[0].items()}


def _read_slurm_log_flags(run_root: Path) -> dict[str, str]:
    flags = {
        "candidate_diagnostics_start_jls_loaded_from_log": "",
        "mpcc_solve_started": "",
        "mpcc_solve_returned": "",
    }
    texts = []
    for path in sorted(run_root.glob("slurm-*.out")):
        texts.append(path.read_text(errors="replace"))
    if not texts:
        return flags
    text = "\n".join(texts)
    flags["candidate_diagnostics_start_jls_loaded_from_log"] = str(
        "after_candidate_diagnostics_start_deserialize" in text,
    ).lower()
    flags["mpcc_solve_started"] = str("before_mpcc_solve_attempt" in text).lower()
    flags["mpcc_solve_returned"] = str("after_mpcc_solve_attempt" in text).lower()
    return flags


def _safe_float(value: str | None) -> float:
    if value is None:
        return math.nan
    text = str(value).strip()
    if not text:
        return math.nan
    try:
        return float(text)
    except ValueError:
        return math.nan


def _safe_str(row: dict[str, str], key: str, default: str = "") -> str:
    value = row.get(key, default)
    return default if value is None else str(value)


def _fmt(value: str | float, digits: int = 6) -> str:
    number = _safe_float(str(value))
    if math.isfinite(number):
        return f"{number:.{digits}g}"
    return str(value)


def _summarize_run(run_root: Path) -> dict[str, str]:
    case_dir = run_root / "case"
    attempt = _read_single_row_csv(case_dir / "reduced_mpcc_fixed_control_policy_solve_attempt.csv")
    top_complementarity = _read_first_csv_row(
        case_dir / "reduced_mpcc_fixed_control_policy_complementarity_locations.csv",
    )
    metadata = _read_key_value_text(run_root / "dynamic_control_liberated_mpcc_pilot_metadata.txt")
    log_flags = _read_slurm_log_flags(run_root)
    row: dict[str, str] = {column: "" for column in SUMMARY_COLUMNS}
    row["run_root"] = str(run_root)
    row["job_id"] = metadata.get("slurm_job_id", "")
    row["partition"] = metadata.get("slurm_partition", "")
    row["node"] = metadata.get("slurm_nodelist", "")
    row["case_id"] = _safe_str(attempt, "case_id", metadata.get("case_id", ""))
    row["candidate_id"] = _safe_str(attempt, "candidate_id", metadata.get("candidate_id", ""))
    row["solve_hours"] = _safe_str(attempt, "solve_horizon_h", metadata.get("solve_hours", ""))
    row["nfe"] = _safe_str(attempt, "grid_nfe", metadata.get("nfe", ""))
    row["ipopt_max_iter"] = _safe_str(attempt, "ipopt_max_iter", metadata.get("max_iter", ""))
    row["solver_status"] = _safe_str(attempt, "solver_status")
    row["primal_status"] = _safe_str(attempt, "primal_status")
    row["selected_candidate_source"] = _safe_str(attempt, "selected_candidate_source")
    row["selected_candidate_residual_feasible"] = _safe_str(
        attempt,
        "selected_candidate_residual_feasible",
    )
    row["selected_candidate_trajectory_ready"] = _safe_str(
        attempt,
        "selected_candidate_trajectory_ready",
    )
    row["post_solve_candidate_accepted"] = _safe_str(attempt, "post_solve_candidate_accepted")
    row["candidate_diagnostics_start_jls_requested"] = _safe_str(
        attempt,
        "candidate_diagnostics_start_jls_requested",
        str(bool(metadata.get("candidate_diagnostics_start_jls", ""))).lower(),
    )
    row["candidate_diagnostics_start_jls_loaded"] = _safe_str(
        attempt,
        "candidate_diagnostics_start_jls_loaded",
        log_flags.get("candidate_diagnostics_start_jls_loaded_from_log", ""),
    )
    row["flux_dual_start_jls_requested"] = _safe_str(
        attempt,
        "flux_dual_start_jls_requested",
    )
    row["flux_dual_start_jls_loaded"] = _safe_str(
        attempt,
        "flux_dual_start_jls_loaded",
    )
    row["cross_window_flux_dual_start_applied"] = _safe_str(
        attempt,
        "cross_window_flux_dual_start_applied",
    )
    row["full_candidate_start_seed_applied"] = _safe_str(
        attempt,
        "full_candidate_start_seed_applied",
    )
    row["full_candidate_start_seed_apply_dynamic_controls"] = _safe_str(
        attempt,
        "full_candidate_start_seed_apply_dynamic_controls",
    )
    row["full_candidate_start_seed_dynamic_controls_applied"] = _safe_str(
        attempt,
        "full_candidate_start_seed_dynamic_controls_applied",
    )
    row["full_candidate_start_seed_dynamic_controls_policy"] = _safe_str(
        attempt,
        "full_candidate_start_seed_dynamic_controls_policy",
    )
    row["full_candidate_start_seed_dynamic_controls_skip_reason"] = _safe_str(
        attempt,
        "full_candidate_start_seed_dynamic_controls_skip_reason",
    )
    row["mpcc_solve_started"] = log_flags.get("mpcc_solve_started", "")
    row["mpcc_solve_returned"] = log_flags.get("mpcc_solve_returned", "")
    row["terminal_total_sugar_g_L"] = _safe_str(
        attempt,
        "selected_candidate_terminal_total_sugar_g_L",
    )
    row["terminal_isoamyl_alcohol_g_L"] = _safe_str(
        attempt,
        "selected_candidate_terminal_isoamyl_alcohol_g_L",
    )
    row["max_rhs_residual"] = _safe_str(attempt, "max_rhs_residual")
    row["max_collocation_residual"] = _safe_str(
        attempt,
        "max_collocation_integration_residual",
    )
    row["max_continuity_residual"] = _safe_str(attempt, "max_continuity_residual")
    row["max_mass_balance_residual"] = _safe_str(attempt, "max_mass_balance_residual")
    row["max_lower_complementarity_residual"] = _safe_str(
        attempt,
        "max_lower_complementarity_residual",
    )
    row["max_upper_complementarity_residual"] = _safe_str(
        attempt,
        "max_upper_complementarity_residual",
    )
    row["complementarity_tau"] = _safe_str(attempt, "complementarity_tau")
    row["complementarity_tau_gate_pass"] = _safe_str(attempt, "complementarity_tau_gate_pass")
    row["final_complementarity_flux_projection_enabled"] = _safe_str(
        attempt,
        "collocation_consistent_state_start_final_complementarity_flux_projection_enabled",
    )
    row["final_complementarity_flux_projection_applied"] = _safe_str(
        attempt,
        "collocation_consistent_state_start_last_final_complementarity_flux_projection_applied",
    )
    row["active_complementarity_flux_projection_guard_accepted"] = _safe_str(
        attempt,
        "active_complementarity_flux_projection_guard_accepted",
    )
    row["final_selective_dual_fit_enabled"] = _safe_str(
        attempt,
        "collocation_consistent_state_start_final_selective_dual_fit_enabled",
    )
    row["final_selective_dual_fit_applied"] = _safe_str(
        attempt,
        "collocation_consistent_state_start_last_final_selective_dual_fit_applied",
        _safe_str(attempt, "selective_fixed_flux_stationarity_dual_fit_applied"),
    )
    row["selective_dual_fit_accepted"] = _safe_str(
        attempt,
        "selective_fixed_flux_stationarity_dual_fit_accepted",
    )
    row["selective_dual_fit_budget_fraction"] = _safe_str(
        attempt,
        "selective_fixed_flux_stationarity_dual_fit_complementarity_budget_fraction",
        metadata.get("fixed_flux_dual_fit_complementarity_budget_fraction", ""),
    )
    row["selective_dual_fit_effective_budget_tau"] = _safe_str(
        attempt,
        "selective_fixed_flux_stationarity_dual_fit_effective_complementarity_budget_tau",
    )
    if not row["selective_dual_fit_effective_budget_tau"]:
        tau = _safe_float(row["complementarity_tau"])
        budget_fraction = _safe_float(row["selective_dual_fit_budget_fraction"])
        if math.isfinite(tau) and math.isfinite(budget_fraction):
            row["selective_dual_fit_effective_budget_tau"] = str(tau * budget_fraction)
    row["selective_dual_fit_element_count"] = _safe_str(
        attempt,
        "selective_fixed_flux_stationarity_dual_fit_element_count",
    )
    row["selective_dual_fit_collocation_points"] = _safe_str(
        attempt,
        "selective_fixed_flux_stationarity_dual_fit_collocation_points",
    )
    row["selective_dual_fit_max_stationarity_after"] = _safe_str(
        attempt,
        "selective_fixed_flux_stationarity_dual_fit_max_stationarity_residual_after",
    )
    row["selective_dual_fit_max_lower_complementarity_after"] = _safe_str(
        attempt,
        "selective_fixed_flux_stationarity_dual_fit_max_lower_complementarity_residual_after",
    )
    row["bound_dual_complementarity_clip_enabled"] = _safe_str(
        attempt,
        "bound_dual_complementarity_clip_enabled",
    )
    row["bound_dual_complementarity_clip_applied"] = _safe_str(
        attempt,
        "bound_dual_complementarity_clip_applied",
    )
    row["bound_dual_complementarity_clip_effective_complementarity_budget_tau"] = _safe_str(
        attempt,
        "bound_dual_complementarity_clip_effective_complementarity_budget_tau",
    )
    row["bound_dual_complementarity_clip_max_lower_complementarity_residual_after"] = _safe_str(
        attempt,
        "bound_dual_complementarity_clip_max_lower_complementarity_residual_after",
    )
    row["top_complementarity_type"] = _safe_str(top_complementarity, "residual_type")
    row["top_complementarity_reaction_id"] = _safe_str(top_complementarity, "reaction_id")
    row["top_complementarity_time_h"] = _safe_str(top_complementarity, "time_h")
    row["top_complementarity_abs_product"] = _safe_str(top_complementarity, "abs_product")
    row["temperature_max_abs_delta_vs_start_C"] = _safe_str(
        attempt,
        "post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve",
    )
    row["fda_sum_delta_vs_start_g_L"] = _safe_str(
        attempt,
        "post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve",
    )
    row["organic_sum_delta_vs_start_g_L"] = _safe_str(
        attempt,
        "post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve",
    )
    row["free_temperature_count"] = _safe_str(attempt, "free_temperature_count")
    row["free_fda_count"] = _safe_str(attempt, "free_fda_count")
    row["free_organic_count"] = _safe_str(attempt, "free_organic_count")
    row["objective_integrated_sugar_weight"] = _safe_str(
        attempt,
        "dynamic_control_objective_integrated_sugar_weight",
        metadata.get("dynamic_control_objective_integrated_sugar_weight", ""),
    )
    row["objective_direct_temperature_reward_weight"] = _safe_str(
        attempt,
        "dynamic_control_objective_direct_temperature_reward_weight",
        metadata.get("dynamic_control_objective_direct_temperature_reward_weight", ""),
    )
    row["objective_direct_fda_reward_weight"] = _safe_str(
        attempt,
        "dynamic_control_objective_direct_fda_reward_weight",
        metadata.get("dynamic_control_objective_direct_fda_reward_weight", ""),
    )
    row["objective_direct_organic_reward_weight"] = _safe_str(
        attempt,
        "dynamic_control_objective_direct_organic_reward_weight",
        metadata.get("dynamic_control_objective_direct_organic_reward_weight", ""),
    )
    row["reference_regularization_weight"] = _safe_str(
        attempt,
        "dynamic_control_reference_regularization_weight",
        metadata.get("dynamic_control_reference_regularization_weight", ""),
    )
    row["rhs_controls_coupled"] = _safe_str(attempt, "rhs_residual_uses_control_decision_variables")
    row["dynamic_bounds_controls_coupled"] = _safe_str(
        attempt,
        "dynamic_flux_bounds_use_control_decision_variables",
    )
    row["dominant_residual"] = _safe_str(attempt, "dominant_residual")
    return row


def _write_csv(rows: list[dict[str, str]], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=SUMMARY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def _markdown_table(rows: Iterable[dict[str, str]]) -> str:
    columns = [
        "case_id",
        "job_id",
        "solver_status",
        "selected_candidate_residual_feasible",
        "selected_candidate_trajectory_ready",
        "full_candidate_start_seed_applied",
        "full_candidate_start_seed_apply_dynamic_controls",
        "full_candidate_start_seed_dynamic_controls_applied",
        "full_candidate_start_seed_dynamic_controls_policy",
        "candidate_diagnostics_start_jls_loaded",
        "cross_window_flux_dual_start_applied",
        "mpcc_solve_started",
        "mpcc_solve_returned",
        "terminal_total_sugar_g_L",
        "terminal_isoamyl_alcohol_g_L",
        "max_collocation_residual",
        "max_lower_complementarity_residual",
        "complementarity_tau",
        "top_complementarity_reaction_id",
        "top_complementarity_time_h",
        "final_complementarity_flux_projection_applied",
        "final_selective_dual_fit_applied",
        "selective_dual_fit_accepted",
        "selective_dual_fit_budget_fraction",
        "selective_dual_fit_effective_budget_tau",
        "selective_dual_fit_element_count",
        "selective_dual_fit_max_lower_complementarity_after",
        "bound_dual_complementarity_clip_applied",
        "temperature_max_abs_delta_vs_start_C",
        "fda_sum_delta_vs_start_g_L",
        "organic_sum_delta_vs_start_g_L",
    ]
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in rows:
        values = []
        for column in columns:
            value = row.get(column, "")
            if any(token in column for token in ("sugar", "isoamyl", "residual", "delta", "budget")):
                value = _fmt(value)
            values.append(value)
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def _write_markdown(rows: list[dict[str, str]], output_path: Path) -> None:
    ready = [
        row for row in rows
        if row.get("selected_candidate_residual_feasible") == "true"
        and row.get("selected_candidate_trajectory_ready") == "true"
    ]
    residual_sane = [
        row for row in rows
        if row.get("selected_candidate_residual_feasible") == "true"
    ]
    text = "\n".join(
        [
            "# Dynamic-Control Staged Multistart Summary",
            "",
            f"Run count: {len(rows)}",
            f"Residual-feasible count: {len(residual_sane)}",
            f"Trajectory-ready count: {len(ready)}",
            "",
            _markdown_table(rows),
            "",
        ],
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(text)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_roots", nargs="+", type=Path)
    parser.add_argument("--output-csv", type=Path, default=None)
    parser.add_argument("--output-md", type=Path, default=None)
    args = parser.parse_args()

    rows = [_summarize_run(path) for path in args.run_roots]
    if args.output_csv is not None:
        _write_csv(rows, args.output_csv)
    if args.output_md is not None:
        _write_markdown(rows, args.output_md)
    if args.output_csv is None and args.output_md is None:
        print(_markdown_table(rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
