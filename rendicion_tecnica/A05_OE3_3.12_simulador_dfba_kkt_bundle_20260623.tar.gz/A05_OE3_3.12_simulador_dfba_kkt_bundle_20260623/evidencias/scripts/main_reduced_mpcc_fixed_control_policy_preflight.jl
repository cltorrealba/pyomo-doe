using CSV
using DataFrames
using Dates
using FermentationDFBA
using TOML

include(joinpath(@__DIR__, "solver_backend_helpers.jl"))

const FIXED_CONTROL_PREFLIGHT_SCRIPT = "main_reduced_mpcc_fixed_control_policy_preflight.jl"

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _fixed_control_env_bool(name::AbstractString, default::Bool)::Bool
    raw_value = lowercase(strip(get(ENV, String(name), string(default))))
    if raw_value in ("1", "true", "yes", "y", "on")
        return true
    elseif raw_value in ("0", "false", "no", "n", "off")
        return false
    end
    error("Environment variable $name must be boolean, got: $raw_value")
end

function _fixed_control_env_positive_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _fixed_control_env_positive_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _fixed_control_env_path(name::AbstractString, default_relative::AbstractString)::String
    raw_value = strip(get(ENV, String(name), default_relative))
    isempty(raw_value) && error("Environment variable $name must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _fixed_control_parse_float_vector(raw_value)::Vector{Float64}
    raw_value isa Missing && return Float64[]
    values = Float64[]
    for token in split(replace(string(raw_value), ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Could not parse Float64 token '$cleaned' from '$raw_value'.")
        isfinite(value) || error("Non-finite Float64 token '$cleaned' from '$raw_value'.")
        push!(values, value)
    end
    return values
end

function _fixed_control_toml_normalize(value)
    if value isa Missing || value === nothing
        return "missing"
    elseif value isa Bool
        return value
    elseif value isa Integer
        return Int(value)
    elseif value isa Real
        return _fixed_control_toml_real(value)
    elseif value isa AbstractString
        return value
    elseif value isa AbstractVector || value isa Tuple
        return [_fixed_control_toml_normalize(item) for item in value]
    elseif value isa AbstractDict
        normalized = Dict{String, Any}()
        for key in sort!(collect(keys(value)); by = string)
            normalized[string(key)] = _fixed_control_toml_normalize(value[key])
        end
        return normalized
    end
    return string(value)
end

function _fixed_control_toml_real(value::Real)
    float_value = Float64(value)
    isfinite(float_value) && return float_value
    isnan(float_value) && return "NaN"
    float_value == Inf && return "Inf"
    float_value == -Inf && return "-Inf"
    return string(value)
end

function _fixed_control_required_columns(table::DataFrame)
    required = [
        :candidate_id,
        :temperature_values_C,
        :fda_doses_g_L,
        :organic_doses_g_L,
        :control_policy_ready,
    ]
    names_set = Set(Symbol.(names(table)))
    missing_columns = [String(column) for column in required if !(column in names_set)]
    isempty(missing_columns) || error(
        "Fixed-control policy selection CSV is missing column(s): " *
        join(missing_columns, ", "),
    )
    return nothing
end

function _fixed_control_bool(value)::Bool
    value isa Bool && return value
    value isa Missing && return false
    raw = lowercase(strip(string(value)))
    raw in ("1", "true", "yes", "y") && return true
    raw in ("0", "false", "no", "n") && return false
    return false
end

function _fixed_control_schedule_from_row(
    row::DataFrameRow;
    schedule_horizon_h::Real,
    control_interval_h::Real,
    temperature_width_h::Real,
    addition_width_h::Real,
)
    return reference_dynamic_control_schedule(
        horizon_h = schedule_horizon_h,
        control_interval_h = control_interval_h,
        temperature_values_C = _fixed_control_parse_float_vector(row.temperature_values_C),
        temperature_transition_width_h = temperature_width_h,
        fda_doses_g_L = _fixed_control_parse_float_vector(row.fda_doses_g_L),
        organic_doses_g_L = _fixed_control_parse_float_vector(row.organic_doses_g_L),
        addition_transition_width_h = addition_width_h,
    )
end

function _fixed_control_preflight_row(candidate_id::AbstractString, problem)
    metadata = problem.metadata
    return (
        candidate_id = String(candidate_id),
        preflight_status = "built",
        solver_call_performed = Bool(get(metadata, "solver_call_performed", false)),
        mpcc_fixed_control_replay_ready =
            Bool(get(metadata, "mpcc_fixed_control_replay_ready", false)),
        dynamic_control_schedule_enabled =
            Bool(get(metadata, "dynamic_control_schedule_enabled", false)),
        dynamic_control_fda_total_product_g_L =
            Float64(get(metadata, "dynamic_control_fda_total_product_g_L", NaN)),
        dynamic_control_organic_total_product_g_L =
            Float64(get(metadata, "dynamic_control_organic_total_product_g_L", NaN)),
        rhs_residuals_included = Bool(get(metadata, "rhs_residuals_included", false)),
        dynamic_flux_bounds_applied = Bool(get(metadata, "dynamic_flux_bounds_applied", false)),
        grid_tspan = string(get(metadata, "grid_tspan", "missing")),
        grid_nfe = Int(get(metadata, "grid_nfe", 0)),
        collocation_degree = Int(get(metadata, "collocation_degree", 0)),
        nlp_structure_total_variables =
            Int(get(metadata, "nlp_structure_total_variables", 0)),
        nlp_structure_total_constraints =
            Int(get(metadata, "nlp_structure_total_constraints", 0)),
        nlp_structure_too_few_degrees_of_freedom_risk =
            Bool(get(metadata, "nlp_structure_too_few_degrees_of_freedom_risk", true)),
        default_start_initializers_applied =
            Bool(get(metadata, "default_start_initializers_applied", false)),
        dynamic_flux_lp_starts_applied =
            Bool(get(metadata, "dynamic_flux_lp_starts_applied", false)),
        rhs_consistent_derivative_starts_applied =
            Bool(get(metadata, "rhs_consistent_derivative_starts_applied", false)),
    )
end

policy_selection_csv = _fixed_control_env_path(
    "MPCC_FIXED_CONTROL_POLICY_SELECTION_CSV",
    joinpath("results", "dynamic_control_policy_selection_latest", "dynamic_control_policy_selection.csv"),
)
isfile(policy_selection_csv) || error("Policy selection CSV does not exist: $policy_selection_csv")

output_dir = _fixed_control_env_path(
    "MPCC_FIXED_CONTROL_OUTPUT_DIR",
    joinpath("results", "reduced_mpcc_fixed_control_policy_preflight_latest"),
)
overwrite = _fixed_control_env_bool("MPCC_FIXED_CONTROL_OVERWRITE", true)
max_policies = _fixed_control_env_positive_int("MPCC_FIXED_CONTROL_MAX_POLICIES", 3)
preflight_horizon_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_PREFLIGHT_HOURS", 24.0)
nfe = _fixed_control_env_positive_int("MPCC_FIXED_CONTROL_NFE", 2)
degree = _fixed_control_env_positive_int("MPCC_FIXED_CONTROL_DEGREE", 3)
schedule_horizon_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_SCHEDULE_HOURS", 168.0)
control_interval_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_INTERVAL_HOURS", 12.0)
temperature_width_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_TEMPERATURE_WIDTH_HOURS", 1.0)
addition_width_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_ADDITION_WIDTH_HOURS", 0.5)
apply_default_start_initializers =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_APPLY_DEFAULT_START_INITIALIZERS", true)
linear_solver = strip(get(ENV, "MPCC_FIXED_CONTROL_LINEAR_SOLVER", ipopt_linear_solver_from_env()))

mkpath(output_dir)
preflight_path = joinpath(output_dir, "reduced_mpcc_fixed_control_policy_preflight.csv")
metadata_path = joinpath(output_dir, "reduced_mpcc_fixed_control_policy_preflight.toml")
if !overwrite
    existing_targets = [path for path in (preflight_path, metadata_path) if isfile(path)]
    isempty(existing_targets) || error(
        "Fixed-control preflight output file(s) already exist and overwrite=false: " *
        join(existing_targets, ", "),
    )
end

policy_table = DataFrame(CSV.File(policy_selection_csv))
_fixed_control_required_columns(policy_table)
ready_table = policy_table[_fixed_control_bool.(policy_table.control_policy_ready), :]
nrow(ready_table) > 0 || error("No control_policy_ready=true policies in $policy_selection_csv")
if nrow(ready_table) > max_policies
    ready_table = ready_table[1:max_policies, :]
end

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

rows = NamedTuple[]
policy_metadata = Dict{String, Any}()
for row in eachrow(ready_table)
    candidate_id = String(row.candidate_id)
    schedule = _fixed_control_schedule_from_row(
        row;
        schedule_horizon_h = schedule_horizon_h,
        control_interval_h = control_interval_h,
        temperature_width_h = temperature_width_h,
        addition_width_h = addition_width_h,
    )
    problem = build_reduced_dcdfba_mpcc_smoke_problem(
        model,
        reaction_map;
        tspan = (0.0, preflight_horizon_h),
        nfe = nfe,
        degree = degree,
        include_rhs = true,
        use_dynamic_bounds = true,
        dynamic_control_schedule = schedule,
        apply_default_start_initializers = apply_default_start_initializers,
        ipopt_max_iter = 0,
        linear_solver = linear_solver,
    )
    push!(rows, _fixed_control_preflight_row(candidate_id, problem))
    policy_metadata[candidate_id] = Dict{String, Any}(
        "mpcc_fixed_control_replay_ready" =>
            Bool(get(problem.metadata, "mpcc_fixed_control_replay_ready", false)),
        "solver_call_performed" => Bool(get(problem.metadata, "solver_call_performed", false)),
        "dynamic_control_fda_total_product_g_L" =>
            get(problem.metadata, "dynamic_control_fda_total_product_g_L", missing),
        "dynamic_control_organic_total_product_g_L" =>
            get(problem.metadata, "dynamic_control_organic_total_product_g_L", missing),
        "nlp_structure_total_variables" =>
            get(problem.metadata, "nlp_structure_total_variables", missing),
        "nlp_structure_total_constraints" =>
            get(problem.metadata, "nlp_structure_total_constraints", missing),
        "nlp_structure_too_few_degrees_of_freedom_risk" =>
            get(problem.metadata, "nlp_structure_too_few_degrees_of_freedom_risk", missing),
    )
end

preflight_table = DataFrame(rows)
CSV.write(preflight_path, preflight_table)

metadata = Dict{String, Any}(
    "script" => FIXED_CONTROL_PREFLIGHT_SCRIPT,
    "created_at" => Dates.format(Dates.now(), dateformat"yyyy-mm-ddTHH:MM:SS"),
    "policy_selection_csv" => policy_selection_csv,
    "output_dir" => output_dir,
    "preflight_csv" => preflight_path,
    "metadata_toml" => metadata_path,
    "policy_count" => nrow(preflight_table),
    "candidate_ids" => String.(preflight_table.candidate_id),
    "preflight_horizon_h" => preflight_horizon_h,
    "nfe" => nfe,
    "degree" => degree,
    "schedule_horizon_h" => schedule_horizon_h,
    "control_interval_h" => control_interval_h,
    "temperature_width_h" => temperature_width_h,
    "addition_width_h" => addition_width_h,
    "apply_default_start_initializers" => apply_default_start_initializers,
    "linear_solver" => linear_solver,
    "solver_call_performed" => false,
    "preflight_is_scientific_simulation" => false,
    "all_mpcc_fixed_control_replay_ready" =>
        all(Bool.(preflight_table.mpcc_fixed_control_replay_ready)),
    "policies" => policy_metadata,
)
open(metadata_path, "w") do io
    TOML.print(io, _fixed_control_toml_normalize(metadata))
end

println("Reduced MPCC fixed-control policy preflight")
println("policy_selection_csv: $policy_selection_csv")
println("output_dir: $output_dir")
println("preflight_csv: $preflight_path")
println("metadata_toml: $metadata_path")
println("policy_count: $(nrow(preflight_table))")
println("preflight_horizon_h: $preflight_horizon_h")
println("nfe: $nfe")
println("degree: $degree")
println("apply_default_start_initializers: $apply_default_start_initializers")
println("solver_call_performed: false")
println("all_mpcc_fixed_control_replay_ready: $(metadata["all_mpcc_fixed_control_replay_ready"])")
println("policies:")
for row in eachrow(preflight_table)
    println(
        "  $(row.candidate_id) | ready=$(row.mpcc_fixed_control_replay_ready) | " *
        "vars=$(row.nlp_structure_total_variables) | constraints=$(row.nlp_structure_total_constraints)",
    )
end
