#!/usr/bin/env python3
"""Summarize fixed-control MPCC projection ladder artifacts.

The script scans MPCC run directories for
``reduced_mpcc_fixed_control_policy_solve_attempt.csv`` files and writes a
compact h48/h96/h168 audit.  It is intentionally lightweight so it can be run
on a login node: it only reads existing CSV artifacts.
"""

from __future__ import annotations

import argparse
import csv
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


RESIDUAL_COLUMNS = (
    "max_rhs_residual",
    "max_collocation_integration_residual",
    "max_continuity_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
)


@dataclass(frozen=True)
class Attempt:
    horizon_h: float
    max_residual: float
    dominant_metric: str
    case_dir: Path
    row: dict[str, str]
    top_location: dict[str, str]


def _parse_float(value: str | None, default: float = math.nan) -> float:
    if value is None or value == "":
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _last_csv_row(path: Path) -> dict[str, str] | None:
    with path.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    return rows[-1] if rows else None


def _top_residual_location(case_dir: Path) -> dict[str, str]:
    path = case_dir / "reduced_mpcc_fixed_control_policy_residual_locations.csv"
    if not path.exists():
        return {}
    with path.open(newline="") as handle:
        return next(csv.DictReader(handle), {})


def _attempt_from_csv(path: Path, horizons: set[float]) -> Attempt | None:
    row = _last_csv_row(path)
    if row is None:
        return None
    horizon_h = _parse_float(row.get("solve_horizon_h"))
    if horizon_h not in horizons:
        return None
    residual_values = {
        column: abs(_parse_float(row.get(column), 0.0)) for column in RESIDUAL_COLUMNS
    }
    dominant_metric, max_residual = max(
        residual_values.items(),
        key=lambda item: item[1],
    )
    return Attempt(
        horizon_h=horizon_h,
        max_residual=max_residual,
        dominant_metric=dominant_metric,
        case_dir=path.parent,
        row=row,
        top_location=_top_residual_location(path.parent),
    )


def _scan_attempts(runs_root: Path, horizons: set[float]) -> list[Attempt]:
    attempts: list[Attempt] = []
    for path in runs_root.rglob("reduced_mpcc_fixed_control_policy_solve_attempt.csv"):
        attempt = _attempt_from_csv(path, horizons)
        if attempt is not None:
            attempts.append(attempt)
    return attempts


def _bool_text(row: dict[str, str], key: str) -> str:
    return (row.get(key) or "").lower()


def _residual_feasible(attempt: Attempt) -> bool:
    value = _bool_text(attempt.row, "selected_candidate_residual_feasible")
    if value == "":
        value = _bool_text(attempt.row, "candidate_residual_feasible")
    return value == "true"


def _trajectory_ready(attempt: Attempt) -> bool:
    value = _bool_text(attempt.row, "selected_candidate_trajectory_ready")
    if value == "":
        value = _bool_text(attempt.row, "candidate_trajectory_extraction_ready")
    return value == "true"


def _pick_best(attempts: Iterable[Attempt], *, require_ready: bool = False) -> Attempt | None:
    candidates = [
        attempt
        for attempt in attempts
        if _residual_feasible(attempt)
        and (not require_ready or _trajectory_ready(attempt))
    ]
    if not candidates:
        return None
    return min(candidates, key=lambda attempt: attempt.max_residual)


def _summary_rows(attempts: list[Attempt], horizons: list[float]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    by_horizon = {
        horizon: [attempt for attempt in attempts if attempt.horizon_h == horizon]
        for horizon in horizons
    }
    for horizon in horizons:
        horizon_attempts = by_horizon[horizon]
        picks = (
            ("best_residual_feasible", _pick_best(horizon_attempts)),
            ("best_trajectory_ready", _pick_best(horizon_attempts, require_ready=True)),
        )
        for label, attempt in picks:
            if attempt is None:
                rows.append(
                    {
                        "selection": label,
                        "solve_horizon_h": f"{horizon:g}",
                        "available": "false",
                    },
                )
                continue
            row = attempt.row
            top = attempt.top_location
            rows.append(
                {
                    "selection": label,
                    "solve_horizon_h": f"{attempt.horizon_h:g}",
                    "available": "true",
                    "case_id": row.get("case_id", ""),
                    "case_dir": str(attempt.case_dir),
                    "grid_nfe": row.get("grid_nfe", ""),
                    "solver_status": row.get("solver_status", ""),
                    "primal_status": row.get("primal_status", ""),
                    "selected_candidate_source": row.get("selected_candidate_source", ""),
                    "selected_candidate_residual_feasible": row.get(
                        "selected_candidate_residual_feasible",
                        row.get("candidate_residual_feasible", ""),
                    ),
                    "selected_candidate_trajectory_ready": row.get(
                        "selected_candidate_trajectory_ready",
                        row.get("candidate_trajectory_extraction_ready", ""),
                    ),
                    "max_residual": f"{attempt.max_residual:.16g}",
                    "dominant_metric": attempt.dominant_metric,
                    "top_residual_type": top.get("residual_type", ""),
                    "top_state_name": top.get("state_name", ""),
                    "top_element_index": top.get("element_index", ""),
                    "top_time_h": top.get("time_h", ""),
                    "top_abs_residual": top.get("abs_residual", ""),
                    "terminal_total_sugar_g_L": row.get(
                        "selected_candidate_terminal_total_sugar_g_L",
                        "",
                    ),
                    "candidate_selection_reason": row.get("candidate_selection_reason", ""),
                    "post_solve_candidate_rejection_reason": row.get(
                        "post_solve_candidate_rejection_reason",
                        "",
                    ),
                },
            )
    return rows


def _write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _write_markdown(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = (
        "selection",
        "solve_horizon_h",
        "case_id",
        "selected_candidate_source",
        "solver_status",
        "selected_candidate_residual_feasible",
        "selected_candidate_trajectory_ready",
        "max_residual",
        "dominant_metric",
        "top_state_name",
        "top_element_index",
        "top_time_h",
    )
    with path.open("w") as handle:
        handle.write("# Fixed-control projection ladder audit\n\n")
        handle.write(
            "This report is generated from existing "
            "`reduced_mpcc_fixed_control_policy_solve_attempt.csv` artifacts.\n\n",
        )
        handle.write("| " + " | ".join(columns) + " |\n")
        handle.write("| " + " | ".join("---" for _ in columns) + " |\n")
        for row in rows:
            handle.write("| " + " | ".join(row.get(column, "") for column in columns) + " |\n")


def _parse_horizons(raw: str) -> list[float]:
    return [float(part.strip()) for part in raw.split(",") if part.strip()]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--runs-root",
        type=Path,
        default=Path.home() / "mpcc_runs",
        help="Root directory containing MPCC run artifacts.",
    )
    parser.add_argument(
        "--horizons",
        default="48,96,168",
        help="Comma-separated solve horizons to summarize.",
    )
    parser.add_argument("--out-csv", type=Path, required=True)
    parser.add_argument("--out-md", type=Path, required=True)
    args = parser.parse_args()

    horizons = _parse_horizons(args.horizons)
    attempts = _scan_attempts(args.runs_root, set(horizons))
    rows = _summary_rows(attempts, horizons)
    _write_csv(args.out_csv, rows)
    _write_markdown(args.out_md, rows)
    print(f"attempts_scanned={len(attempts)}")
    print(f"summary_rows={len(rows)}")
    print(f"out_csv={args.out_csv}")
    print(f"out_md={args.out_md}")


if __name__ == "__main__":
    main()
