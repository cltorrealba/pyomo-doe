using CSV
using DataFrames
using FermentationDFBA

include(joinpath(@__DIR__, "solver_backend_helpers.jl"))
include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _write_script_labeled_summary!(
    summary_path::AbstractString,
    solver_label::AbstractString,
    algorithm_label::AbstractString,
)
    summary_table = DataFrame(CSV.File(summary_path))
    summary_table[!, "solver_label"] = fill(String(solver_label), nrow(summary_table))
    summary_table[!, "algorithm_label"] = fill(String(algorithm_label), nrow(summary_table))
    CSV.write(summary_path, summary_table)
    return summary_path
end

function _dfba_export_env_nonnegative_float(name::AbstractString, default::Real)
    key = String(name)
    raw = haskey(ENV, key) ? strip(ENV[key]) : string(Float64(default))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $key must parse as Float64, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $key must be finite and nonnegative, got: $value")
    return value
end

function _dfba_export_env_optional_float(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw = strip(ENV[key])
    isempty(raw) && return nothing
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $key must parse as Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $key must be finite and positive, got: $value")
    return value
end

function _dfba_export_env_optional_int(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw = strip(ENV[key])
    isempty(raw) && return nothing
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $key must parse as Int, got: $raw")
    value > 0 || error("Environment variable $key must be positive, got: $value")
    return value
end

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

tfinal = _script_env_float("DFBA_TFINAL_HOURS", 2.0)
saveat = _script_env_float("DFBA_SAVEAT_HOURS", 1.0)
reconstruct_fluxes = _script_env_bool("DFBA_RECONSTRUCT_FLUXES", true)
lp_reuse = _script_env_bool("DFBA_LP_REUSE", false)
lp_primal_start = _script_env_bool("DFBA_LP_PRIMAL_START", false)
lp_basis_warm_start = _script_env_bool("DFBA_LP_BASIS_WARM_START", false)
allow_experimental_lp_reuse = _script_env_bool("DFBA_ALLOW_EXPERIMENTAL_LP_REUSE", false)
lp_reuse_highs_solver = strip(get(ENV, "DFBA_LP_REUSE_HIGHS_SOLVER", "simplex"))
lp_simplex_strategy = strip(get(ENV, "DFBA_LP_SIMPLEX_STRATEGY", lp_basis_warm_start ? "primal" : "default"))
overwrite = _script_env_bool("DFBA_EXPORT_OVERWRITE", true)
output_dir = _script_output_dir(project_root, "DFBA_OUTPUT_DIR", joinpath("results", "reduced_dfba_latest"))
phase_proxy_mode = strip(get(ENV, "DFBA_PHASE_PROXY_MODE", "total_molecular_weight"))
turnover_threshold = _script_env_float("DFBA_TURNOVER_THRESHOLD", 0.001)
algorithm_config = _script_ode_algorithm_config("DFBA_ALGORITHM")
tolerance_config = _script_tolerance_config()
progress_interval_seconds = _dfba_export_env_nonnegative_float("DFBA_PROGRESS_INTERVAL_SECONDS", 0.0)
max_rhs_calls = _dfba_export_env_optional_int("DFBA_MAX_RHS_CALLS")
max_walltime_seconds = _dfba_export_env_optional_float("DFBA_MAX_WALLTIME_SECONDS")
optimizer_backend, solver_label = _resolve_solver_backend(get(ENV, "DFBA_SOLVER_BACKEND", "HiGHS"))
if lp_reuse && solver_label != "HiGHS"
    error("DFBA_LP_REUSE currently supports HiGHS only; use DFBA_SOLVER_BACKEND=HiGHS.")
end
params = default_zenteno_parameters(
    phase_proxy_mode = phase_proxy_mode,
    TURNOVER_THRESHOLD = turnover_threshold,
)
initial_state_config = _script_initial_state_config(params)
start_time = time()
simulation_kwargs = (
    y0 = initial_state_config.y0,
    tspan = (0.0, tfinal),
    params = params,
    saveat = saveat,
    reconstruct_fluxes = reconstruct_fluxes,
    lp_reuse = lp_reuse,
    lp_primal_start = lp_primal_start,
    lp_reuse_highs_solver = lp_reuse_highs_solver,
    lp_basis_warm_start = lp_basis_warm_start,
    lp_simplex_strategy = lp_simplex_strategy,
    allow_experimental_lp_reuse = allow_experimental_lp_reuse,
    algorithm = algorithm_config.algorithm,
    ode_abstol = tolerance_config.ode_abstol,
    ode_reltol = tolerance_config.ode_reltol,
    lp_atol = tolerance_config.lp_atol,
    progress_interval_seconds = progress_interval_seconds,
    max_rhs_calls = max_rhs_calls,
    max_walltime_seconds = max_walltime_seconds,
)
result = optimizer_backend === nothing ?
    simulate_reduced_dfba(model, reaction_map; simulation_kwargs...) :
    simulate_reduced_dfba(model, reaction_map; optimizer = optimizer_backend, simulation_kwargs...)
elapsed_seconds = time() - start_time
result.metadata["solver_label"] = solver_label
result.metadata["script_algorithm_label"] = algorithm_config.algorithm_label
result.metadata["phase_proxy_mode"] = String(params.phase_proxy_mode)
result.metadata["turnover_threshold"] = params.TURNOVER_THRESHOLD
merge!(result.metadata, initial_state_config.metadata)
paths = export_simulation_result(
    result,
    output_dir;
    model_id = model.model_id,
    elapsed_seconds = elapsed_seconds,
    overwrite = overwrite,
)
_write_script_labeled_summary!(paths["summary"], solver_label, algorithm_config.algorithm_label)
summary = summarize_simulation(result)

println("Sequential reduced DFBA export report")
println("output_dir: $output_dir")
println("solver_label: $solver_label")
println("algorithm_label: $(algorithm_config.algorithm_label)")
println("phase_proxy_mode: $(params.phase_proxy_mode)")
println("turnover_threshold: $(params.TURNOVER_THRESHOLD)")
println("initial_condition_policy: $(result.metadata["initial_condition_policy"])")
println("initial_sugar_policy: $(result.metadata["initial_sugar_policy"])")
println("initial_glucose_g_L: $(result.metadata["initial_glucose_g_L"])")
println("initial_fructose_g_L: $(result.metadata["initial_fructose_g_L"])")
println("initial_total_sugar_g_L: $(result.metadata["initial_total_sugar_g_L"])")
println("initial_yan_policy: $(result.metadata["initial_yan_policy"])")
println("initial_yan_target_mgN_L: $(result.metadata["initial_yan_target_mgN_L"])")
println("initial_free_nitrogen_gN_L: $(result.metadata["initial_free_nitrogen_gN_L"])")
println("initial_amino_acid_nitrogen_equivalent_mgN_L: $(result.metadata["initial_amino_acid_nitrogen_equivalent_mgN_L"])")
println("initial_total_yan_equivalent_mgN_L: $(result.metadata["initial_total_yan_equivalent_mgN_L"])")
println("ode_abstol: $(tolerance_config.ode_abstol)")
println("ode_reltol: $(tolerance_config.ode_reltol)")
println("lp_atol: $(tolerance_config.lp_atol)")
println("progress_interval_seconds: $progress_interval_seconds")
println("max_rhs_calls: $(max_rhs_calls === nothing ? "missing" : string(max_rhs_calls))")
println("max_walltime_seconds: $(max_walltime_seconds === nothing ? "missing" : string(max_walltime_seconds))")
println("tspan: 0.0 to $tfinal h")
println("saveat: $saveat h")
println("overwrite: $overwrite")
println("elapsed_seconds: $elapsed_seconds")
println("saved_time_points: $(summary["n_saved_points"])")
println("retcode: $(summary["retcode"])")
println("termination_reason: $(summary["termination_reason"])")
println("final_time: $(summary["final_time"])")
println("final_biomass: $(summary["final_biomass"])")
println("final_total_sugar: $(summary["final_total_sugar"])")
println("sugar_consumed: $(summary["sugar_consumed"])")
println("final_ethanol: $(summary["final_ethanol"])")
println("ethanol_produced: $(summary["ethanol_produced"])")
println("oxygen_derivative_policy: $(summary["oxygen_derivative_policy"])")
println("carbohydrate_derivative_policy: $(summary["carbohydrate_derivative_policy"])")
println("reconstruct_fluxes: $(summary["reconstruct_fluxes"])")
println("lp_reuse: $(summary["lp_reuse"])")
println("lp_primal_start: $(summary["lp_primal_start"])")
println("lp_basis_warm_start: $(summary["lp_basis_warm_start"])")
println("lp_reuse_highs_solver: $(summary["lp_reuse_highs_solver"])")
println("lp_simplex_strategy: $(summary["lp_simplex_strategy"])")
println("lp_reuse_strategy: $(summary["lp_reuse_strategy"])")
println("lp_warm_start_strategy: $(summary["lp_warm_start_strategy"])")
println("allow_experimental_lp_reuse: $(summary["allow_experimental_lp_reuse"])")
println("experimental_lp_reuse: $(summary["experimental_lp_reuse"])")
println("trajectory_equivalence_checked: $(summary["trajectory_equivalence_checked"])")
println("trajectory_equivalence_passed: $(summary["trajectory_equivalence_passed"])")
println("scientific_output_equivalent: $(summary["scientific_output_equivalent"])")
println("lp_reuse_validity_note: $(summary["lp_reuse_validity_note"])")
println("simulation_elapsed_seconds: $(summary["simulation_elapsed_seconds"])")
println("ode_solve_elapsed_seconds: $(summary["ode_solve_elapsed_seconds"])")
println("rhs_elapsed_seconds: $(summary["rhs_elapsed_seconds"])")
println("history_reconstruction_elapsed_seconds: $(summary["history_reconstruction_elapsed_seconds"])")
println("rhs_call_count: $(summary["rhs_call_count"])")
println("rhs_lp_solve_count: $(summary["rhs_lp_solve_count"])")
println("flux_reconstruction_solve_count: $(summary["flux_reconstruction_solve_count"])")
println("total_lp_solve_count: $(summary["total_lp_solve_count"])")
println("lp_reuse_build_elapsed_seconds: $(summary["lp_reuse_build_elapsed_seconds"])")
println("lp_reuse_update_elapsed_seconds: $(summary["lp_reuse_update_elapsed_seconds"])")
println("lp_reuse_solve_elapsed_seconds: $(summary["lp_reuse_solve_elapsed_seconds"])")
println("lp_reuse_warm_start_applied_count: $(summary["lp_reuse_warm_start_applied_count"])")
println("lp_reuse_basis_warm_start_applied_count: $(summary["lp_reuse_basis_warm_start_applied_count"])")
println("lp_reuse_basis_warm_start_failed_count: $(summary["lp_reuse_basis_warm_start_failed_count"])")
println("lp_reuse_basis_capture_count: $(summary["lp_reuse_basis_capture_count"])")
println("lp_reuse_simplex_iterations: $(summary["lp_reuse_simplex_iterations"])")
println("written_files:")
for key in sort(collect(keys(paths)))
    println("  $key = $(paths[key])")
end
