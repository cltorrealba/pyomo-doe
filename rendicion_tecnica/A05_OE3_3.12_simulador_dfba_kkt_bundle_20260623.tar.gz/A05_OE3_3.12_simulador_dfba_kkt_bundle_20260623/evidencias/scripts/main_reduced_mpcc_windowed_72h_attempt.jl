using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_WINDOWED_ATTEMPT_PROFILE = "smoke"
const DEFAULT_MPCC_WINDOWED_ATTEMPT_IPOPT_MAX_ITER = 100

function _mpcc_windowed_attempt_profile()
    raw = strip(get(ENV, "MPCC_WINDOWED_ATTEMPT_PROFILE", DEFAULT_MPCC_WINDOWED_ATTEMPT_PROFILE))
    normalized = lowercase(raw)
    normalized = normalized == "twomh_four_nfe" ? "2h4nfe" : normalized
    normalized in ("smoke", "pilot", "72h", "2h4nfe", "custom") ||
        error(
            "Environment variable MPCC_WINDOWED_ATTEMPT_PROFILE must be one of: " *
            "smoke, pilot, 72h, 2h4nfe, twomh_four_nfe, custom. Got: $raw",
        )
    return normalized
end

function _mpcc_windowed_attempt_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizon = "0.5",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 1,
        )
    elseif profile == "pilot"
        return (
            target_horizon = "2.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 4,
        )
    elseif profile == "72h"
        return (
            target_horizon = "72.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 144,
        )
    elseif profile == "2h4nfe"
        return (
            target_horizon = "72.0",
            window_hours = "2.0",
            nfe_per_window = 4,
            max_windows = 36,
        )
    else
        return (
            target_horizon = "0.5",
            window_hours = "0.25",
            nfe_per_window = 1,
            max_windows = 2,
        )
    end
end

function _mpcc_windowed_attempt_env_positive_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_windowed_attempt_env_nonnegative_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $value")
    return value
end

function _mpcc_windowed_attempt_env_positive_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_windowed_attempt_env_positive_int_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Int, stripped)
        value === nothing && error("Environment variable $name contains a non-Int value: $stripped")
        value > 0 || error("Environment variable $name values must be positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one Int.")
    return values
end

function _mpcc_windowed_attempt_n_windows(
    target_horizon::Float64,
    window_hours::Float64,
)::Int
    raw = target_horizon / window_hours
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || error(
        "MPCC_WINDOWED_ATTEMPT_TARGET_HOURS=$target_horizon is not an integer " *
        "multiple of MPCC_WINDOWED_ATTEMPT_WINDOW_HOURS=$window_hours.",
    )
    return n_windows
end

function _mpcc_windowed_attempt_validate_grid!(
    n_windows::Int,
    max_windows::Int,
    allow_long::Bool,
)
    if n_windows > max_windows && !allow_long
        error(
            "Requested MPCC windowed simulation attempt has $n_windows windows, above " *
            "MPCC_WINDOWED_ATTEMPT_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_WINDOWED_ATTEMPT_ALLOW_LONG=1 only for deliberate longer diagnostics.",
        )
    end
    return nothing
end

function _mpcc_windowed_attempt_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_windowed_attempt_progress_callback(progress::Bool)
    progress || return nothing
    return function (row, row_index, n_requested_windows)
        println(
            "progress_window: $row_index/$n_requested_windows | " *
            "id=$(_mpcc_windowed_attempt_value(row["window_id"])) | " *
            "status=$(_mpcc_windowed_attempt_value(row["window_status"])) | " *
            "tfinal=$(_mpcc_windowed_attempt_value(row["tfinal"])) | " *
            "solver=$(_mpcc_windowed_attempt_value(row["solver_status"])) | " *
            "residual_feasible=$(_mpcc_windowed_attempt_value(row["candidate_residual_feasible"])) | " *
            "allows_continuation=$(_mpcc_windowed_attempt_value(row["candidate_allows_continuation"])) | " *
            "solve_s=$(_mpcc_windowed_attempt_value(row["solve_elapsed_seconds"]))",
        )
    end
end

profile = _mpcc_windowed_attempt_profile()
defaults = _mpcc_windowed_attempt_profile_defaults(profile)
target_horizon =
    _mpcc_windowed_attempt_env_positive_float(
        "MPCC_WINDOWED_ATTEMPT_TARGET_HOURS",
        defaults.target_horizon,
    )
window_hours =
    _mpcc_windowed_attempt_env_positive_float(
        "MPCC_WINDOWED_ATTEMPT_WINDOW_HOURS",
        defaults.window_hours,
    )
nfe_per_window =
    _mpcc_windowed_attempt_env_positive_int(
        "MPCC_WINDOWED_ATTEMPT_NFE",
        defaults.nfe_per_window,
    )
max_windows =
    _mpcc_windowed_attempt_env_positive_int(
        "MPCC_WINDOWED_ATTEMPT_MAX_WINDOWS",
        defaults.max_windows,
    )
allow_long = _script_env_bool("MPCC_WINDOWED_ATTEMPT_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_WINDOWED_ATTEMPT_CONTINUE_ON_ERROR", true)
require_pre_solve_ready = _script_env_bool("MPCC_WINDOWED_ATTEMPT_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_WINDOWED_ATTEMPT_SILENT", true)
progress = _script_env_bool("MPCC_WINDOWED_ATTEMPT_PROGRESS", profile == "72h")
retry_on_failure = _script_env_bool("MPCC_WINDOWED_ATTEMPT_RETRY_ON_FAILURE", false)
retry_max_iter_values =
    _mpcc_windowed_attempt_env_positive_int_list(
        "MPCC_WINDOWED_ATTEMPT_RETRY_MAX_ITERS",
        "200,300,500",
    )
ipopt_max_iter =
    _mpcc_windowed_attempt_env_positive_int(
        "MPCC_WINDOWED_ATTEMPT_IPOPT_MAX_ITER",
        DEFAULT_MPCC_WINDOWED_ATTEMPT_IPOPT_MAX_ITER,
    )
linear_solver =
    strip(get(ENV, "MPCC_IPOPT_LINEAR_SOLVER", profile == "2h4nfe" ? "spral" : "mumps"))
ipopt_profile = reduced_mpcc_ipopt_profile_name_from_env()
complementarity_mode = reduced_mpcc_complementarity_mode_from_env("scholtes")
complementarity_tau = reduced_mpcc_complementarity_tau_from_env()
complementarity_tau_gate_tol = reduced_mpcc_complementarity_tau_gate_tol_from_env()
tau_schedule =
    _script_env_bool("MPCC_WINDOWED_ATTEMPT_USE_TAU_CONTINUATION", profile == "2h4nfe") ?
    reduced_mpcc_tau_schedule_from_env() : nothing
tau_schedule_label = tau_schedule === nothing ? "disabled" : join(tau_schedule, ",")
continuation_acceptance_policy =
    strip(get(ENV, "MPCC_WINDOWED_ATTEMPT_CONTINUATION_POLICY", "residual_feasible"))
continuation_state_relative_rmse_threshold =
    _mpcc_windowed_attempt_env_nonnegative_float(
        "MPCC_WINDOWED_ATTEMPT_STATE_REL_RMSE_THRESHOLD",
        "0.02",
    )

n_windows = _mpcc_windowed_attempt_n_windows(target_horizon, window_hours)
_mpcc_windowed_attempt_validate_grid!(n_windows, max_windows, allow_long)

println("Reduced MPCC windowed target-horizon attempt")
println("profile: $profile")
println("target_horizon: $target_horizon")
println("window_hours: $window_hours")
println("n_windows: $n_windows")
println("nfe_per_window: $nfe_per_window")
println("boundary_dt: $(window_hours / nfe_per_window)")
println("linear_solver: $linear_solver")
println("ipopt_profile: $ipopt_profile")
println("complementarity_mode: $complementarity_mode")
println("complementarity_tau: $complementarity_tau")
println("complementarity_tau_gate_tol: $complementarity_tau_gate_tol")
println("tau_schedule: $tau_schedule_label")
println("ipopt_max_iter: $ipopt_max_iter")
println("continuation_acceptance_policy: $continuation_acceptance_policy")
println("continuation_state_relative_rmse_threshold: $continuation_state_relative_rmse_threshold")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("progress: $progress")
println("retry_on_failure: $retry_on_failure")
println("retry_max_iter_values: $(join(retry_max_iter_values, ","))")

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

result = attempt_reduced_dcdfba_mpcc_windowed_simulation(
    model,
    reaction_map;
    target_horizon = target_horizon,
    window_hours = window_hours,
    nfe_per_window = nfe_per_window,
    degree = 3,
    ipopt_max_iter = ipopt_max_iter,
    linear_solver = linear_solver,
    ipopt_profile = ipopt_profile,
    complementarity_mode = complementarity_mode,
    complementarity_tau = complementarity_tau,
    complementarity_tau_gate_tol = complementarity_tau_gate_tol,
    tau_schedule = tau_schedule,
    require_pre_solve_ready = require_pre_solve_ready,
    continuation_acceptance_policy = continuation_acceptance_policy,
    continuation_state_relative_rmse_threshold =
        continuation_state_relative_rmse_threshold,
    silent = silent,
    continue_on_error = continue_on_error,
    window_callback = _mpcc_windowed_attempt_progress_callback(progress),
)
failure_diagnostics = diagnose_reduced_dcdfba_mpcc_windowed_failure(result, model)
retry_diagnostics =
    retry_on_failure && result.metadata["attempt_traffic_light"] != "green" ?
    diagnose_reduced_dcdfba_mpcc_window_retry(
        result,
        model,
        reaction_map;
        ipopt_max_iter_values = retry_max_iter_values,
        linear_solver = linear_solver,
        ipopt_profile = ipopt_profile,
        complementarity_mode = complementarity_mode,
        complementarity_tau = complementarity_tau,
        tau_schedule = tau_schedule,
        require_pre_solve_ready = require_pre_solve_ready,
        silent = silent,
        continue_on_error = continue_on_error,
    ) :
    nothing

println("outputs_written: $(result.metadata["outputs_written"])")
println("attempt_is_scientific_simulation: $(result.metadata["attempt_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(result.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(result.metadata["scientific_baseline"])")
println("first_mpcc_target: $(result.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(result.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(result.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(result.metadata["hsl_required"])")
println("ma57_required: $(result.metadata["ma57_required"])")
println("indices_reacciones_used: $(result.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(result.metadata["r0001_used_as_oxygen"])")
println("target_completed: $(result.metadata["target_completed"])")
println("attempt_traffic_light: $(result.metadata["attempt_traffic_light"])")
println("attempt_viable: $(result.metadata["attempt_viable"])")
println("horizon_reached: $(_mpcc_windowed_attempt_value(result.metadata["horizon_reached"]))")
println("horizon_gap: $(_mpcc_windowed_attempt_value(result.metadata["horizon_gap"]))")
println("target_completion_fraction: $(_mpcc_windowed_attempt_value(result.metadata["target_completion_fraction"]))")
println("n_requested_windows: $(result.metadata["n_requested_windows"])")
println("n_completed_windows: $(result.metadata["n_completed_windows"])")
println("n_failed_windows: $(result.metadata["n_failed_windows"])")
println("continuation_completed: $(result.metadata["continuation_completed"])")
println("metadata_continuation_acceptance_policy: $(result.metadata["continuation_acceptance_policy"])")
println("continuation_state_drift_gate_enabled: $(result.metadata["continuation_state_drift_gate_enabled"])")
println("continuation_policy_rejected_window_count: $(result.metadata["continuation_policy_rejected_window_count"])")
println("iteration_limit_policy_accepted_window_count: $(result.metadata["iteration_limit_policy_accepted_window_count"])")
println("all_completed_windows_residual_feasible: $(result.metadata["all_completed_windows_residual_feasible"])")
println("all_completed_windows_trajectory_ready: $(result.metadata["all_completed_windows_trajectory_ready"])")
println("global_traffic_light: $(_mpcc_windowed_attempt_value(result.metadata["global_traffic_light"]))")
println("global_viability_class: $(_mpcc_windowed_attempt_value(result.metadata["global_viability_class"]))")
println("window_green_count: $(result.metadata["window_green_count"])")
println("window_yellow_count: $(result.metadata["window_yellow_count"])")
println("window_red_count: $(result.metadata["window_red_count"])")
println("first_non_green_window_id: $(_mpcc_windowed_attempt_value(result.metadata["first_non_green_window_id"]))")
println("first_non_green_window_class: $(_mpcc_windowed_attempt_value(result.metadata["first_non_green_window_class"]))")
println("first_non_green_window_blocking_reasons: $(_mpcc_windowed_attempt_value(result.metadata["first_non_green_window_blocking_reasons"]))")
println("first_red_window_id: $(_mpcc_windowed_attempt_value(result.metadata["first_red_window_id"]))")
println("first_red_window_class: $(_mpcc_windowed_attempt_value(result.metadata["first_red_window_class"]))")
println("first_red_window_blocking_reasons: $(_mpcc_windowed_attempt_value(result.metadata["first_red_window_blocking_reasons"]))")
println("first_not_residual_feasible_window_id: $(_mpcc_windowed_attempt_value(result.metadata["first_not_residual_feasible_window_id"]))")
println("first_not_residual_feasible_window_class: $(_mpcc_windowed_attempt_value(result.metadata["first_not_residual_feasible_window_class"]))")
println("total_solve_elapsed_seconds: $(_mpcc_windowed_attempt_value(result.metadata["total_solve_elapsed_seconds"]))")
println("recommended_next_action: $(result.metadata["recommended_next_action"])")
println("failure_diagnostic_type: $(failure_diagnostics.metadata["diagnostic_type"])")
println("failure_dominant_residual_name: $(_mpcc_windowed_attempt_value(failure_diagnostics.metadata["dominant_residual_name"]))")
println("failure_dominant_residual_ratio: $(_mpcc_windowed_attempt_value(failure_diagnostics.metadata["dominant_residual_ratio"]))")
println("failure_first_red_cause: $(_mpcc_windowed_attempt_value(failure_diagnostics.metadata["first_red_failure_cause"]))")
println("failure_first_not_residual_feasible_window_id: $(_mpcc_windowed_attempt_value(failure_diagnostics.metadata["first_not_residual_feasible_window_id"]))")
println("failure_dominant_mass_balance_candidate_id: $(_mpcc_windowed_attempt_value(failure_diagnostics.metadata["dominant_mass_balance_candidate_id"]))")
println("failure_dominant_mass_balance_metabolite_id: $(_mpcc_windowed_attempt_value(failure_diagnostics.metadata["dominant_mass_balance_metabolite_id"]))")
println("failure_dominant_mass_balance_residual: $(_mpcc_windowed_attempt_value(failure_diagnostics.metadata["dominant_mass_balance_residual"]))")
println("failure_dominant_mass_balance_ratio: $(_mpcc_windowed_attempt_value(failure_diagnostics.metadata["dominant_mass_balance_ratio"]))")
println("failure_recommended_next_action: $(failure_diagnostics.metadata["recommended_next_action"])")
if retry_diagnostics !== nothing
    println("retry_diagnostic_type: $(retry_diagnostics.metadata["retry_diagnostic_type"])")
    println("retry_source_window_id: $(retry_diagnostics.metadata["source_window_id"])")
    println("retry_source_window_index: $(retry_diagnostics.metadata["source_window_index"])")
    println("retry_source_max_mass_balance_ratio: $(_mpcc_windowed_attempt_value(retry_diagnostics.metadata["source_max_mass_balance_ratio"]))")
    println("retry_recovered_residual_feasibility: $(retry_diagnostics.metadata["retry_recovered_residual_feasibility"])")
    println("retry_recovered_green_window: $(retry_diagnostics.metadata["retry_recovered_green_window"])")
    println("retry_best_ipopt_max_iter: $(_mpcc_windowed_attempt_value(retry_diagnostics.metadata["best_retry_ipopt_max_iter"]))")
    println("retry_best_traffic_light: $(_mpcc_windowed_attempt_value(retry_diagnostics.metadata["best_retry_traffic_light"]))")
    println("retry_best_mass_balance_ratio: $(_mpcc_windowed_attempt_value(retry_diagnostics.metadata["best_retry_max_mass_balance_ratio"]))")
    println("retry_total_solve_elapsed_seconds: $(_mpcc_windowed_attempt_value(retry_diagnostics.metadata["total_retry_solve_elapsed_seconds"]))")
    println("retry_recommended_next_action: $(retry_diagnostics.metadata["recommended_next_action"])")
end

println("attempt_table:")
for row in eachrow(result.attempt_table)
    println(
        "  $(row["candidate_id"]) | source=$(_mpcc_windowed_attempt_value(row["source_type"])) | " *
        "light=$(_mpcc_windowed_attempt_value(row["traffic_light"])) | " *
        "class=$(_mpcc_windowed_attempt_value(row["viability_class"])) | " *
        "target_done=$(_mpcc_windowed_attempt_value(row["target_completed"])) | " *
        "attempt_light=$(_mpcc_windowed_attempt_value(row["attempt_traffic_light"])) | " *
        "horizon=$(_mpcc_windowed_attempt_value(row["horizon"])) | " *
        "window_index=$(_mpcc_windowed_attempt_value(row["window_index"])) | " *
        "solver=$(_mpcc_windowed_attempt_value(row["solver_status"])) | " *
        "solve_s=$(_mpcc_windowed_attempt_value(row["solve_elapsed_seconds"])) | " *
        "max_rhs=$(_mpcc_windowed_attempt_value(row["max_rhs_residual"])) | " *
        "max_mass=$(_mpcc_windowed_attempt_value(row["max_mass_balance_residual"])) | " *
        "max_lb=$(_mpcc_windowed_attempt_value(row["max_lower_bound_violation"])) | " *
        "max_ub=$(_mpcc_windowed_attempt_value(row["max_upper_bound_violation"])) | " *
        "max_stat=$(_mpcc_windowed_attempt_value(row["max_stationarity_residual"])) | " *
        "max_comp_l=$(_mpcc_windowed_attempt_value(row["max_lower_complementarity_residual"])) | " *
        "max_comp_u=$(_mpcc_windowed_attempt_value(row["max_upper_complementarity_residual"])) | " *
        "max_state_rel_rmse=$(_mpcc_windowed_attempt_value(row["max_state_relative_rmse"])) | " *
        "global_state_rel_rmse=$(_mpcc_windowed_attempt_value(row["global_max_state_relative_rmse"])) | " *
        "blocking=$(_mpcc_windowed_attempt_value(row["blocking_reasons"]))",
    )
end

if retry_diagnostics !== nothing
    println("retry_table:")
    for row in eachrow(retry_diagnostics.retry_table)
        println(
            "  $(row["retry_case_id"]) | source=$(row["source_window_id"]) | " *
            "max_iter=$(_mpcc_windowed_attempt_value(row["ipopt_max_iter"])) | " *
            "status=$(_mpcc_windowed_attempt_value(row["case_status"])) | " *
            "light=$(_mpcc_windowed_attempt_value(row["traffic_light"])) | " *
            "class=$(_mpcc_windowed_attempt_value(row["viability_class"])) | " *
            "solver=$(_mpcc_windowed_attempt_value(row["solver_status"])) | " *
            "residual_feasible=$(_mpcc_windowed_attempt_value(row["residual_feasible"])) | " *
            "trajectory_ready=$(_mpcc_windowed_attempt_value(row["trajectory_ready"])) | " *
            "mass=$(_mpcc_windowed_attempt_value(row["max_mass_balance_residual"])) | " *
            "mass_ratio=$(_mpcc_windowed_attempt_value(row["max_mass_balance_ratio"])) | " *
            "improvement=$(_mpcc_windowed_attempt_value(row["mass_balance_ratio_improvement"])) | " *
            "solve_s=$(_mpcc_windowed_attempt_value(row["solve_elapsed_seconds"])) | " *
            "blocking=$(_mpcc_windowed_attempt_value(row["blocking_reasons"]))",
        )
    end
end

println("failure_window_summary:")
for row in eachrow(failure_diagnostics.window_summary_table)
    println(
        "  $(row["candidate_id"]) | source=$(_mpcc_windowed_attempt_value(row["source_type"])) | " *
        "light=$(_mpcc_windowed_attempt_value(row["traffic_light"])) | " *
        "cause=$(_mpcc_windowed_attempt_value(row["failure_cause"])) | " *
        "dominant=$(_mpcc_windowed_attempt_value(row["dominant_residual"])) | " *
        "ratio=$(_mpcc_windowed_attempt_value(row["max_residual_ratio"])) | " *
        "mass_ratio=$(_mpcc_windowed_attempt_value(row["max_mass_balance_ratio"])) | " *
        "solver=$(_mpcc_windowed_attempt_value(row["solver_status"])) | " *
        "blocking=$(_mpcc_windowed_attempt_value(row["blocking_reasons"]))",
    )
end

println("top_mass_balance_rows:")
mass_table = failure_diagnostics.mass_balance_table
if size(mass_table, 1) == 0
    println("  missing")
else
    order = sortperm(Float64.(mass_table[!, "abs_mass_balance_residual"]); rev = true)
    for index in first(order, min(5, length(order)))
        row = mass_table[index, :]
        println(
            "  $(row["candidate_id"]) | window=$(_mpcc_windowed_attempt_value(row["window_index"])) | " *
            "e=$(_mpcc_windowed_attempt_value(row["element_index"])) | " *
            "j=$(_mpcc_windowed_attempt_value(row["collocation_index"])) | " *
            "met=$(_mpcc_windowed_attempt_value(row["metabolite_id"])) | " *
            "residual=$(_mpcc_windowed_attempt_value(row["mass_balance_residual"])) | " *
            "ratio=$(_mpcc_windowed_attempt_value(row["ratio"])) | " *
            "attempt_max=$(_mpcc_windowed_attempt_value(row["is_attempt_max"]))",
        )
    end
end

println("interpretation_note: $(result.metadata["interpretation_note"])")
