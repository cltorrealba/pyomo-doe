#!/usr/bin/env python3
"""Summarize reduced MPCC dynamic-control pilot attempt CSV files."""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python < 3.11 fallback.
    tomllib = None


DEFAULT_RUNS = [
    (
        "733504",
        "iter5_reg0p25",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_full168_iter5_20260614_100459",
    ),
    (
        "733591",
        "iter5_reg0p05",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter5_20260614_110944",
    ),
    (
        "733643",
        "iter10_reg0p05",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter10_20260614_115423",
    ),
    (
        "733814",
        "iter12_reg0p05",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter12_20260614_142742",
    ),
    (
        "733880",
        "iter13_reg0p05",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter13_20260614_151836",
    ),
    (
        "733949",
        "iter14_reg0p05",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter14_20260614_160925",
    ),
    (
        "733757",
        "iter15_reg0p05",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter15_20260614_133652",
    ),
    (
        "733690",
        "iter20_reg0p05",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_state_nn_clamp_no_final_comp_flux_feashandoff_reg0p05_full168_iter20_20260614_123553",
    ),
    (
        "734006",
        "reward2_reg0p05_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward2_reg0p05_iter13_20260614_170103",
    ),
    (
        "734064",
        "reward5_reg0p02_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward5_reg0p02_iter13_20260614_175351",
    ),
    (
        "734087",
        "reward5_lownutrientthermal_reg0p05_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward5_lownutrientthermal_reg0p05_iter13_20260614_180840",
    ),
    (
        "734088",
        "reward5_reg0p05_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward5_reg0p05_iter13_20260614_180840",
    ),
    (
        "734100",
        "reward1_scale1mg_reg0p02_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter13_20260614_182020",
    ),
    (
        "734115",
        "reward1_scale1mg_reg0p05_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p05_iter13_20260614_183135",
    ),
    (
        "734122",
        "reward1_scale1mg_reg0p02_iter13_n14",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter13_20260614_183744",
    ),
    (
        "734219",
        "reward1_scale1mg_reg0_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0_iter13_20260614_200452",
    ),
    (
        "734220",
        "reward1_scale1mg_reg0p02_iter14",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_20260614_200452",
    ),
    (
        "734285",
        "reward1_scale1mg_reg0p02_iter14_postsolve_delta",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_20260614_210120",
    ),
    (
        "734311",
        "reward1_scale1mg_reg0p02_iter14_repair12_compflux1",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_reward1_scale1mg_reg0p02_iter14_repair12_compflux1_20260614_212605",
    ),
    (
        "734383",
        "blend_reg0p02_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_blend_reg0p02_iter13_20260614_223100",
    ),
    (
        "734472",
        "blend_reward10_reg0_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_blend_reward10_reg0_iter13_20260614_234937",
    ),
    (
        "734484",
        "blend_integrated_reward2_reg0_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_blend_integrated_reward2_reg0_iter13_20260615_000124",
    ),
    (
        "734561",
        "blend_integrated_reward20_reg0_wide_iter13",
        "/home/cltorrealba/mpcc_runs/dynamic_control_objective_leverage_blend_integrated_reward20_reg0_wide_iter13_20260615_005910",
    ),
]


@dataclass(frozen=True)
class RunSpec:
    job_id: str
    label: str
    root: Path


ATTEMPT_FIELDS = [
    "case_id",
    "solve_horizon_h",
    "ipopt_max_iter",
    "solve_attempt_status",
    "solver_call_performed",
    "solver_status",
    "primal_status",
    "objective_value",
    "solve_elapsed_seconds",
    "solver_reported_solve_time_seconds",
    "residuals_available",
    "residual_thresholds_satisfied",
    "dominant_residual",
    "apply_default_start_initializers",
    "default_start_initializers_applied",
    "default_start_initializers_skip_reason",
    "skip_sequential_simulation_for_candidate_seed",
    "candidate_diagnostics_start_jls_requested",
    "candidate_diagnostics_start_jls_loaded",
    "full_candidate_start_seed_applied",
    "full_candidate_start_seed_dynamic_controls_applied",
    "full_candidate_start_seed_dynamic_controls_skip_reason",
    "candidate_residual_feasible",
    "candidate_iteration_limit_residual_feasible",
    "candidate_trajectory_extraction_ready",
    "candidate_dominant_residual",
    "post_solve_candidate_residual_feasible",
    "selected_candidate_source",
    "selected_candidate_is_post_solve",
    "selected_candidate_is_pre_solve_start",
    "selected_candidate_residual_feasible",
    "selected_candidate_trajectory_ready",
    "selected_candidate_terminal_state_values_available",
    "selected_candidate_terminal_glucose_g_L",
    "selected_candidate_terminal_fructose_g_L",
    "selected_candidate_terminal_total_sugar_g_L",
    "selected_candidate_terminal_isoamyl_alcohol_g_L",
    "post_solve_candidate_dynamic_control_delta_vs_pre_solve_available",
    "post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve",
    "post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve",
    "post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve",
    "max_rhs_residual",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "max_stationarity_residual",
    "max_lower_complementarity_residual",
    "max_upper_complementarity_residual",
    "max_collocation_integration_residual",
    "max_continuity_residual",
    "grid_tspan",
    "grid_nfe",
    "grid_element_length_h",
    "mesh_policy",
    "mesh_min_element_length_h",
    "mesh_max_element_length_h",
    "collocation_degree",
    "nlp_structure_total_variables",
    "nlp_structure_total_constraints",
    "linear_solver",
    "ipopt_profile",
    "ipopt_hessian_approximation",
    "collocation_consistent_state_start_initial_score",
    "collocation_consistent_state_start_final_score",
    "collocation_consistent_state_start_best_score",
    "collocation_consistent_state_start_repair_after_candidate_seed_enabled",
    "collocation_consistent_state_start_repair_after_candidate_seed_applied",
    "collocation_consistent_state_start_repair_after_candidate_seed_policy",
    "collocation_consistent_state_start_repair_after_candidate_seed_elements",
    "collocation_consistent_state_start_feasibility_projection_enabled",
    "collocation_consistent_state_start_feasibility_projection_applied",
    "collocation_consistent_state_start_feasibility_projection_segments_raw",
    "collocation_consistent_state_start_feasibility_projection_ranges",
    "collocation_consistent_state_start_feasibility_projection_segment_count",
    "collocation_consistent_state_start_feasibility_projection_accepted_count",
    "collocation_consistent_state_start_feasibility_projection_trial_count",
    "collocation_consistent_state_start_feasibility_projection_rejected_trial_count",
    "collocation_consistent_state_start_feasibility_projection_guard_score_policy",
    "collocation_consistent_state_start_feasibility_projection_damping_factors",
    "collocation_consistent_state_start_feasibility_projection_refresh_dynamic_flux",
    "collocation_consistent_state_start_feasibility_projection_final_state_refresh",
    "collocation_consistent_state_start_feasibility_projection_final_flux_projection",
    "collocation_consistent_state_start_feasibility_projection_final_state_after_rhs",
    "collocation_consistent_state_start_feasibility_projection_before_max_residual",
    "collocation_consistent_state_start_feasibility_projection_after_max_residual",
    "collocation_consistent_state_start_feasibility_projection_before_collocation_residual",
    "collocation_consistent_state_start_feasibility_projection_after_collocation_residual",
    "collocation_consistent_state_start_feasibility_projection_before_continuity_residual",
    "collocation_consistent_state_start_feasibility_projection_after_continuity_residual",
    "collocation_consistent_state_start_iterations",
    "collocation_consistent_state_start_trial_count",
    "collocation_consistent_state_start_rejected_trial_count",
    "collocation_consistent_state_start_stopped_by_monotone_guard",
    "collocation_consistent_state_start_final_state_after_rhs_guard_accepted",
    "collocation_consistent_state_start_final_state_after_rhs_guard_before_primal_structural_residual",
    "collocation_consistent_state_start_final_state_after_rhs_guard_after_primal_structural_residual",
    "collocation_consistent_state_start_final_complementarity_flux_projection_enabled",
    "collocation_consistent_state_start_last_final_complementarity_flux_projection_applied",
    "active_complementarity_flux_projection_triggered_points",
    "active_complementarity_flux_projection_max_lower_complementarity_after",
    "active_complementarity_flux_projection_max_adjustment",
    "active_complementarity_flux_projection_guard_enabled",
    "active_complementarity_flux_projection_guard_accepted",
    "active_complementarity_flux_projection_guard_before_score",
    "active_complementarity_flux_projection_guard_after_score",
    "fully_simultaneous_controls",
    "control_variable_count",
    "control_free_variable_count",
    "mpcc_dynamic_control_variables_coupled_to_rhs",
    "mpcc_dynamic_control_variables_coupled_to_dynamic_bounds",
    "dynamic_control_objective_terminal_reward_weight",
    "dynamic_control_objective_terminal_state_scale_g_L",
    "dynamic_control_objective_terminal_sugar_weight",
    "dynamic_control_objective_terminal_sugar_scale_g_L",
    "dynamic_control_objective_integrated_sugar_weight",
    "dynamic_control_objective_integrated_sugar_scale_g_L",
    "dynamic_control_objective_integrated_sugar_config_policy",
    "dynamic_control_objective_integrated_sugar_max_g_L",
    "dynamic_control_objective_aroma_reward_policy",
    "dynamic_control_objective_terminal_reward_effective_weight",
    "dynamic_control_objective_integrated_aroma_reward_effective_weight",
    "dynamic_control_objective_integrated_aroma_reward_terms",
    "dynamic_control_objective_integrated_aroma_reward_policy",
    "dynamic_control_objective_terminal_sugar_terms",
    "dynamic_control_objective_integrated_sugar_terms",
    "dynamic_control_objective_integrated_sugar_policy",
    "dynamic_control_objective_integrated_sugar_slack_count",
    "dynamic_control_objective_integrated_sugar_constraint_count",
    "dynamic_control_objective_integrated_sugar_max_slack_start_g_L",
    "dynamic_control_objective_resolved_target_state",
    "dynamic_control_objective_target_state_alias_policy",
    "dynamic_control_objective_target_component_count",
    "dynamic_control_objective_target_component_names",
    "dynamic_control_objective_nutrient_weight",
    "dynamic_control_objective_thermal_energy_weight",
    "dynamic_control_objective_temperature_smoothness_weight",
    "dynamic_control_reference_regularization_weight",
]


CONTROL_SUMMARY_FIELDS = [
    "temperature_max_abs_delta",
    "temperature_post_solve_max_abs_delta",
    "fda_optimized_sum",
    "fda_post_solve_sum",
    "fda_post_solve_sum_delta",
    "organic_optimized_sum",
    "organic_max_abs_delta",
    "organic_post_solve_sum",
    "organic_post_solve_sum_delta",
]


REPAIR_TRACE_SUMMARY_FIELDS = [
    "repair_trace_available",
    "feasibility_projection_trace_trial_count",
    "feasibility_projection_trace_accepted_count",
    "feasibility_projection_trace_rejected_count",
    "feasibility_projection_trace_ranges",
    "feasibility_projection_trace_accepted_damping_factors",
    "feasibility_projection_trace_first_accepted_damping_factor",
    "feasibility_projection_trace_before_max_residual",
    "feasibility_projection_trace_after_accepted_max_residual",
    "feasibility_projection_trace_best_trial_max_residual",
    "feasibility_projection_trace_best_trial_damping_factor",
]


def read_one_row(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        try:
            return dict(next(reader))
        except StopIteration:
            return {}


def read_metadata_toml_values(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    keys = (
        "apply_default_start_initializers",
        "default_start_initializers_applied",
        "default_start_initializers_skip_reason",
        "skip_sequential_simulation_for_candidate_seed",
    )
    if tomllib is not None:
        with path.open("rb") as handle:
            data = tomllib.load(handle)
        return {key: str(data[key]).lower() for key in keys if key in data}

    values: dict[str, str] = {}
    key_set = set(keys)
    with path.open(encoding="utf-8") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line or line.startswith("[") or "=" not in line:
                continue
            key, raw_value = line.split("=", 1)
            key = key.strip()
            if key not in key_set:
                continue
            value = raw_value.strip().strip('"')
            values[key] = value.lower() if value in ("true", "false") else value
    return values


def _is_true(value: str) -> bool:
    return value.strip().lower() == "true"


def _float_or_none(value: str) -> float | None:
    text = value.strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def read_repair_trace_summary(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    with path.open(newline="", encoding="utf-8") as handle:
        rows = [
            row
            for row in csv.DictReader(handle)
            if (row.get("phase") or "").strip() == "feasibility_projection"
        ]
    if not rows:
        return {"repair_trace_available": "true"}

    accepted_rows = [row for row in rows if _is_true(row.get("accepted", ""))]
    rejected_count = len(rows) - len(accepted_rows)
    ranges = []
    for row in rows:
        first = (row.get("first_element") or "").strip()
        last = (row.get("last_element") or "").strip()
        label = f"{first}:{last}" if first and last else ""
        if label and label not in ranges:
            ranges.append(label)

    before_residual = (rows[0].get("previous_max_residual") or "").strip()
    accepted_dampings = [
        (row.get("damping_factor") or "").strip()
        for row in accepted_rows
        if (row.get("damping_factor") or "").strip()
    ]
    after_accepted = ""
    if accepted_rows:
        after_accepted = (accepted_rows[-1].get("max_residual") or "").strip()

    best_row: dict[str, str] | None = None
    best_value: float | None = None
    for row in rows:
        value = _float_or_none(row.get("max_residual") or "")
        if value is None:
            continue
        if best_value is None or value < best_value:
            best_value = value
            best_row = row

    return {
        "repair_trace_available": "true",
        "feasibility_projection_trace_trial_count": str(len(rows)),
        "feasibility_projection_trace_accepted_count": str(len(accepted_rows)),
        "feasibility_projection_trace_rejected_count": str(rejected_count),
        "feasibility_projection_trace_ranges": ",".join(ranges),
        "feasibility_projection_trace_accepted_damping_factors": ",".join(accepted_dampings),
        "feasibility_projection_trace_first_accepted_damping_factor": (
            accepted_dampings[0] if accepted_dampings else ""
        ),
        "feasibility_projection_trace_before_max_residual": before_residual,
        "feasibility_projection_trace_after_accepted_max_residual": after_accepted,
        "feasibility_projection_trace_best_trial_max_residual": (
            "" if best_value is None else repr(best_value)
        ),
        "feasibility_projection_trace_best_trial_damping_factor": (
            "" if best_row is None else (best_row.get("damping_factor") or "").strip()
        ),
    }


def infer_plot_summary_path(root: Path) -> Path:
    return root / "plots" / "optimized_control_summary.csv"


def _label_from_root(root: Path) -> str:
    name = root.name
    for prefix in (
        "dynamic_control_objective_leverage_",
        "dynamic_control_objective_",
    ):
        if name.startswith(prefix):
            name = name[len(prefix) :]
    parts = name.rsplit("_20", 1)
    if len(parts) == 2 and len(parts[1]) >= 12:
        return parts[0]
    return name


def read_active_jobs_tsv(path: Path) -> list[RunSpec]:
    runs: list[RunSpec] = []
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        for row in reader:
            job_id = (row.get("job_id") or "").strip()
            root_text = (row.get("run_root") or "").strip()
            if not job_id or not root_text:
                continue
            variant_id = (row.get("variant_id") or "").strip()
            root = Path(root_text)
            runs.append(RunSpec(job_id, variant_id or _label_from_root(root), root))
    return runs


def parse_run_root(text: str) -> RunSpec:
    chunks = text.split("=", 2)
    if len(chunks) == 3:
        job_id, label, root_text = chunks
        return RunSpec(job_id.strip(), label.strip(), Path(root_text.strip()))
    root = Path(text)
    return RunSpec("", _label_from_root(root), root)


def default_runs() -> list[RunSpec]:
    return [
        RunSpec(job_id, label, Path(root_text))
        for job_id, label, root_text in DEFAULT_RUNS
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "run_roots",
        nargs="*",
        help=(
            "Optional run roots. Use JOB_ID=LABEL=/path/to/run to preserve "
            "Slurm metadata, or pass plain run roots to infer labels."
        ),
    )
    parser.add_argument(
        "--active-jobs-tsv",
        type=Path,
        action="append",
        default=[],
        help="Read run roots from a cluster active-jobs TSV.",
    )
    parser.add_argument(
        "--include-defaults",
        action="store_true",
        help="Include the historical built-in pilots in addition to supplied runs.",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("repro/generated/dynamic_control_objective_pilot_summary.csv"),
        help="Output CSV path.",
    )
    args = parser.parse_args()

    runs: list[RunSpec] = []
    if args.include_defaults or (not args.run_roots and not args.active_jobs_tsv):
        runs.extend(default_runs())
    for tsv_path in args.active_jobs_tsv:
        runs.extend(read_active_jobs_tsv(tsv_path))
    for run_root in args.run_roots:
        runs.append(parse_run_root(run_root))

    rows: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for run in runs:
        root = run.root
        identity = (run.job_id, str(root))
        if identity in seen:
            continue
        seen.add(identity)
        attempt = read_one_row(root / "case" / "reduced_mpcc_fixed_control_policy_solve_attempt.csv")
        metadata_toml = read_metadata_toml_values(
            root / "case" / "reduced_mpcc_fixed_control_policy_solve_attempt.toml"
        )
        repair_trace_summary = read_repair_trace_summary(
            root / "case" / "reduced_mpcc_fixed_control_policy_repair_trace.csv"
        )
        control_summary = read_one_row(infer_plot_summary_path(root))
        workspace_summary = Path(
            "repro/generated"
        ) / f"dynamic_control_objective_leverage_{run.label}_{run.job_id}" / "optimized_control_summary.csv"
        workspace_control_summary = read_one_row(workspace_summary)
        for key, value in workspace_control_summary.items():
            if not control_summary.get(key, ""):
                control_summary[key] = value
        row = {
            "job_id": run.job_id,
            "label": run.label,
            "run_root": str(root),
            "attempt_available": str(bool(attempt)).lower(),
            "control_summary_available": str(bool(control_summary)).lower(),
        }
        for field in ATTEMPT_FIELDS:
            row[field] = metadata_toml.get(field, "") or attempt.get(field, "") or control_summary.get(field, "")
        for field in REPAIR_TRACE_SUMMARY_FIELDS:
            row[field] = repair_trace_summary.get(field, "")
        for field in CONTROL_SUMMARY_FIELDS:
            row[field] = control_summary.get(field, "")
        rows.append(row)

    fieldnames = [
        "job_id",
        "label",
        "attempt_available",
        "control_summary_available",
        *ATTEMPT_FIELDS,
        *REPAIR_TRACE_SUMMARY_FIELDS,
        *CONTROL_SUMMARY_FIELDS,
        "run_root",
    ]
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(f"summary_csv={args.out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
