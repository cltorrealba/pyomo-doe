using FermentationDFBA

const DEFAULT_WARM_START_BENCHMARK_OUTPUT_DIR =
    joinpath("results", "benchmarks", "reduced_dfba_warm_start_latest")

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _warm_bench_env_float(name::AbstractString, default::Float64)::Float64
    raw_value = strip(get(ENV, String(name), string(default)))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 || error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _warm_bench_env_int(name::AbstractString, default::Int)::Int
    raw_value = strip(get(ENV, String(name), string(default)))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $raw_value")
    return value
end

function _warm_bench_output_dir(project_root::AbstractString)
    raw_value = strip(get(ENV, "DFBA_WARM_BENCH_OUTPUT_DIR", DEFAULT_WARM_START_BENCHMARK_OUTPUT_DIR))
    isempty(raw_value) && error("Environment variable DFBA_WARM_BENCH_OUTPUT_DIR must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _warm_bench_summary_row(table, scenario_id::AbstractString)
    row_index = findfirst(==(String(scenario_id)), String.(table[!, "scenario_id"]))
    row_index === nothing && error("Missing warm-start benchmark scenario $(String(scenario_id)).")
    return table[row_index, :]
end

function _warm_bench_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _warm_bench_sorted_paths(paths::Dict{String, String})
    return [key => paths[key] for key in sort(collect(keys(paths)))]
end

n_evaluations = _warm_bench_env_int("DFBA_WARM_BENCH_N_EVALUATIONS", 8)
lp_atol = _warm_bench_env_float("DFBA_WARM_BENCH_LP_ATOL", 1.0e-8)
highs_solver = strip(get(ENV, "DFBA_WARM_BENCH_HIGHS_SOLVER", "simplex"))
highs_simplex_strategy = strip(get(ENV, "DFBA_WARM_BENCH_SIMPLEX_STRATEGY", "default"))
output_dir = _warm_bench_output_dir(project_root)

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

benchmark = benchmark_reduced_dfba_warm_start(
    model,
    reaction_map;
    n_evaluations = n_evaluations,
    highs_solver = highs_solver,
    highs_simplex_strategy = highs_simplex_strategy,
    lp_atol = lp_atol,
)
paths = export_reduced_dfba_warm_start_benchmark(benchmark, output_dir; overwrite = true)

println("Reduced DFBA LP reuse, primal-start, and basis-warm-start benchmark")
println("output_dir: $output_dir")
println("model_id: $(model.model_id)")
println("n_evaluations: $(benchmark.metadata["n_evaluations"])")
println("highs_solver: $(benchmark.metadata["highs_solver"])")
println("highs_simplex_strategy: $(benchmark.metadata["highs_simplex_strategy"])")
println("basis_highs_simplex_strategy: $(benchmark.metadata["basis_highs_simplex_strategy"])")
println("lp_atol: $(benchmark.metadata["lp_atol"])")
println("basis_warm_start_included: $(benchmark.metadata["basis_warm_start_included"])")
println("primal_start_included: $(benchmark.metadata["primal_start_included"])")
println("model_reuse_included: $(benchmark.metadata["model_reuse_included"])")
println("ode_simulation_lp_reuse_guarded: $(benchmark.metadata["ode_simulation_lp_reuse_guarded"])")
println("rhs_equivalence_checked: $(benchmark.metadata["rhs_equivalence_checked"])")
println("trajectory_equivalence_checked: $(benchmark.metadata["trajectory_equivalence_checked"])")
println("trajectory_equivalence_passed: $(benchmark.metadata["trajectory_equivalence_passed"])")
println("experimental_lp_reuse: $(benchmark.metadata["experimental_lp_reuse"])")
println("scientific_output_equivalent: $(benchmark.metadata["scientific_output_equivalent"])")

println("scenario_summary:")
println(
    "  scenario_id | mean_elapsed_seconds | mean_solve_elapsed_seconds | " *
    "total_simplex_iterations | warm_start_applied_count | basis_warm_start_applied_count | " *
    "max_abs_objective_difference_vs_cold | max_abs_flux_difference_vs_cold | " *
    "max_abs_dy_difference_vs_cold",
)
for scenario_id in benchmark.metadata["scenario_ids"]
    row = _warm_bench_summary_row(benchmark.summary_table, scenario_id)
    println(
        "  $scenario_id | $(_warm_bench_value(row["mean_elapsed_seconds"])) | " *
        "$(_warm_bench_value(row["mean_solve_elapsed_seconds"])) | " *
        "$(_warm_bench_value(row["total_simplex_iterations"])) | " *
        "$(_warm_bench_value(row["warm_start_applied_count"])) | " *
        "$(_warm_bench_value(row["basis_warm_start_applied_count"])) | " *
        "$(_warm_bench_value(row["max_abs_objective_difference_vs_cold"])) | " *
        "$(_warm_bench_value(row["max_abs_flux_difference_vs_cold"])) | " *
        "$(_warm_bench_value(row["max_abs_dy_difference_vs_cold"]))",
    )
end

println("written_files:")
for (key, path) in _warm_bench_sorted_paths(paths)
    println("  $key = $path")
end
println("interpretation_note: $(benchmark.metadata["interpretation_note"])")
println("rhs_equivalence_note: $(benchmark.metadata["rhs_equivalence_note"])")
println("basis_warm_start_note: $(benchmark.metadata["basis_warm_start_note"])")
println("r0001_used_as_oxygen: $(benchmark.metadata["r0001_used_as_oxygen"])")
println("oxygen_reaction_id: $(benchmark.metadata["oxygen_reaction_id"])")
