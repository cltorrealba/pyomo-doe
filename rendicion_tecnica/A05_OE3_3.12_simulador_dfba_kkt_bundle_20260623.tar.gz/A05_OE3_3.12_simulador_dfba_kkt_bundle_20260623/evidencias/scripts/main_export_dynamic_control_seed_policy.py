#!/usr/bin/env python3
"""Export a dynamic-control MPCC candidate as a one-row policy-selection CSV.

This is a lightweight bridge for staged continuation: it reads the TOML/CSV
artifacts produced by a Slurm MPCC solve attempt and turns the captured control
vectors into a new policy-selection row that can seed a follow-up run. It does
not run Julia, build a model, or solve anything.
"""

from __future__ import annotations

import argparse
import ast
import csv
from pathlib import Path
from typing import Any


CONTROL_KEYS = {
    "candidate": (
        "candidate_dynamic_control_temperature_C_values",
        "candidate_dynamic_control_fda_g_L_values",
        "candidate_dynamic_control_organic_g_L_values",
    ),
    "post_solve": (
        "post_solve_candidate_dynamic_control_temperature_C_values",
        "post_solve_candidate_dynamic_control_fda_g_L_values",
        "post_solve_candidate_dynamic_control_organic_g_L_values",
    ),
    "pre_solve": (
        "pre_solve_candidate_dynamic_control_temperature_C_values",
        "pre_solve_candidate_dynamic_control_fda_g_L_values",
        "pre_solve_candidate_dynamic_control_organic_g_L_values",
    ),
}


def _read_tomlish_metadata(path: Path) -> dict[str, Any]:
    data: dict[str, Any] = {}
    section = ""
    for raw_line in path.read_text(errors="replace").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("["):
            section = line.strip("[]").strip()
            continue
        if section and section != "result_metadata":
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key.strip()] = _parse_toml_value(value.strip())
    return data


def _parse_toml_value(value: str) -> Any:
    if value in ("true", "false"):
        return value == "true"
    try:
        return ast.literal_eval(value)
    except (SyntaxError, ValueError):
        return value.strip('"')


def _read_single_row_csv(path: Path) -> dict[str, str]:
    with path.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise SystemExit(f"CSV has no rows: {path}")
    return {key: (value if value is not None else "") for key, value in rows[0].items()}


def _read_policy_row(path: Path, candidate_id: str | None) -> tuple[list[str], dict[str, str]]:
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        fieldnames = list(reader.fieldnames or [])
    if not rows:
        raise SystemExit(f"Base policy CSV has no rows: {path}")
    if candidate_id is None:
        return fieldnames, rows[0]
    for row in rows:
        if row.get("candidate_id") == candidate_id:
            return fieldnames, row
    raise SystemExit(f"Base candidate_id '{candidate_id}' not found in {path}")


def _as_float_list(value: Any, key: str) -> list[float]:
    if not isinstance(value, list):
        raise SystemExit(f"Expected TOML array for {key}, got: {value!r}")
    output = []
    for item in value:
        number = float(item)
        if not number == number:
            raise SystemExit(f"Non-finite value in {key}: {item!r}")
        output.append(number)
    return output


def _join(values: list[float]) -> str:
    return ",".join(f"{value:.17g}" for value in values)


def _bool_text(value: bool) -> str:
    return "true" if value else "false"


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "y", "on")


def _resolve_attempt_paths(run_or_toml: Path) -> tuple[Path, Path]:
    if run_or_toml.is_file():
        toml_path = run_or_toml
        attempt_csv = toml_path.with_suffix(".csv")
        return toml_path, attempt_csv
    case_dir = run_or_toml / "case"
    toml_path = case_dir / "reduced_mpcc_fixed_control_policy_solve_attempt.toml"
    attempt_csv = case_dir / "reduced_mpcc_fixed_control_policy_solve_attempt.csv"
    return toml_path, attempt_csv


def _copy_with_seed_controls(
    base_row: dict[str, str],
    *,
    new_candidate_id: str,
    source_label: str,
    temperature_values: list[float],
    fda_values: list[float],
    organic_values: list[float],
    metadata: dict[str, Any],
) -> dict[str, str]:
    row = {key: (value if value is not None else "") for key, value in base_row.items()}
    case_id = str(metadata.get("case_id", "unknown_case"))
    selected_source = str(metadata.get("selected_candidate_source", "unknown_source"))
    row["candidate_id"] = new_candidate_id
    row["profile_id"] = f"mpcc_{source_label}_temperature"
    row["nutrient_strategy_id"] = f"mpcc_{source_label}_nutrients"
    row["temperature_values_C"] = _join(temperature_values)
    row["fda_doses_g_L"] = _join(fda_values)
    row["organic_doses_g_L"] = _join(organic_values)
    row["fda_total_product_g_L"] = f"{sum(fda_values):.17g}"
    row["organic_total_product_g_L"] = f"{sum(organic_values):.17g}"
    row["nutrient_total_product_g_L"] = f"{sum(fda_values) + sum(organic_values):.17g}"
    row["control_policy_ready"] = "true"
    row["mpcc_fixed_control_replay_ready"] = "false"
    row["mpcc_fixed_control_replay_blocker"] = (
        "Exported MPCC control seed; run fixed-control MPCC continuation through Slurm."
    )
    row["policy_role"] = "mpcc_staged_seed"
    row["policy_reason"] = (
        f"Exported {source_label} dynamic controls from case {case_id}; "
        f"selected_candidate_source={selected_source}."
    )
    row["selected_for_review"] = "true"
    row["selection_basis"] = f"mpcc_{source_label}_seed_export"
    row["gate_pass"] = _bool_text(
        _truthy(metadata.get("selected_candidate_residual_feasible", False)),
    )
    return row


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "run_or_toml",
        type=Path,
        help="Run root containing case/..., or reduced_mpcc_fixed_control_policy_solve_attempt.toml",
    )
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--source", choices=sorted(CONTROL_KEYS), default="candidate")
    parser.add_argument("--base-policy-csv", type=Path, default=None)
    parser.add_argument("--base-candidate-id", default=None)
    parser.add_argument("--candidate-id", default=None)
    parser.add_argument("--require-residual-feasible", action="store_true")
    args = parser.parse_args()

    toml_path, attempt_csv = _resolve_attempt_paths(args.run_or_toml)
    if not toml_path.is_file():
        raise SystemExit(f"Missing attempt TOML: {toml_path}")
    if not attempt_csv.is_file():
        raise SystemExit(f"Missing attempt CSV: {attempt_csv}")

    metadata = _read_tomlish_metadata(toml_path)
    attempt = _read_single_row_csv(attempt_csv)
    merged_metadata = {**metadata, **attempt}
    if args.require_residual_feasible and attempt.get("selected_candidate_residual_feasible") != "true":
        raise SystemExit("Selected candidate is not residual-feasible; refusing seed export.")

    temperature_key, fda_key, organic_key = CONTROL_KEYS[args.source]
    temperature_values = _as_float_list(merged_metadata.get(temperature_key), temperature_key)
    fda_values = _as_float_list(merged_metadata.get(fda_key), fda_key)
    organic_values = _as_float_list(merged_metadata.get(organic_key), organic_key)

    base_policy_csv = args.base_policy_csv
    if base_policy_csv is None:
        raw = metadata.get("policy_selection_csv")
        if not raw:
            raise SystemExit("No --base-policy-csv provided and TOML lacks policy_selection_csv.")
        base_policy_csv = Path(str(raw))
    base_candidate_id = args.base_candidate_id or str(metadata.get("selected_candidate_id", ""))
    fieldnames, base_row = _read_policy_row(base_policy_csv, base_candidate_id or None)
    if not fieldnames:
        raise SystemExit(f"Could not read fieldnames from {base_policy_csv}")

    default_candidate_id = (
        f"{metadata.get('case_id', 'mpcc_case')}__{args.source}_control_seed"
    )
    output_row = _copy_with_seed_controls(
        base_row,
        new_candidate_id=args.candidate_id or default_candidate_id,
        source_label=args.source,
        temperature_values=temperature_values,
        fda_values=fda_values,
        organic_values=organic_values,
        metadata=merged_metadata,
    )
    extra_fields = [key for key in output_row if key not in fieldnames]
    all_fieldnames = fieldnames + extra_fields
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=all_fieldnames)
        writer.writeheader()
        writer.writerow(output_row)
    print(f"wrote_policy_csv={args.output_csv}")
    print(f"candidate_id={output_row['candidate_id']}")
    print(f"source={args.source}")
    print(f"temperature_count={len(temperature_values)}")
    print(f"fda_count={len(fda_values)}")
    print(f"organic_count={len(organic_values)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
