using CSV
using DataFrames
using FermentationDFBA
using TOML

include(joinpath(@__DIR__, "solver_backend_helpers.jl"))
include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _dynamic_search_env_nonnegative_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _dynamic_search_env_optional_positive_float(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _dynamic_search_env_positive_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _dynamic_search_env_optional_positive_int(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _dynamic_search_parse_float_vector(raw::AbstractString)::Vector{Float64}
    values = Float64[]
    for token in split(replace(String(raw), ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Could not parse Float64 token: $cleaned")
        isfinite(value) || error("Temperature vector value must be finite, got: $cleaned")
        push!(values, value)
    end
    isempty(values) && error("Temperature vector must contain at least one value.")
    return values
end

function _dynamic_search_env_optional_float_vector(name::AbstractString)
    key = String(name)
    haskey(ENV, key) || return nothing
    raw_value = strip(ENV[key])
    isempty(raw_value) && return nothing
    return _dynamic_search_parse_float_vector(raw_value)
end

function _dynamic_search_toml_normalize(value)
    if value === nothing || value === missing
        return nothing
    elseif value isa Symbol
        return String(value)
    elseif value isa AbstractString
        return String(value)
    elseif value isa Bool
        return value
    elseif value isa Real
        return _dynamic_search_toml_normalize_real(value)
    elseif value isa Tuple
        return _dynamic_search_toml_normalize_array(collect(value))
    elseif value isa AbstractVector
        return _dynamic_search_toml_normalize_array(value)
    elseif value isa AbstractDict
        output = Dict{String, Any}()
        for key in sort(collect(keys(value)))
            normalized_value = _dynamic_search_toml_normalize(value[key])
            normalized_value === nothing && continue
            output[String(key)] = normalized_value
        end
        return output
    else
        return String(value)
    end
end

function _dynamic_search_toml_normalize_real(value::Real)
    if value isa AbstractFloat
        isnan(value) && return "NaN"
        isinf(value) && return value > 0 ? "Inf" : "-Inf"
    end
    return value
end

function _dynamic_search_toml_normalize_array(values)
    output = Any[]
    for value in values
        normalized_value = _dynamic_search_toml_normalize(value)
        normalized_value === nothing && continue
        push!(output, normalized_value)
    end
    return output
end

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

horizon_h = _script_env_float("DFBA_DYNAMIC_SEARCH_HORIZON_HOURS", 24.0)
control_interval_h = _script_env_float("DFBA_DYNAMIC_SEARCH_CONTROL_INTERVAL_HOURS", 12.0)
temperature_transition_width_h = _script_env_float("DFBA_DYNAMIC_SEARCH_TEMPERATURE_WIDTH_HOURS", 1.0)
temperature_min_C = _script_env_float("DFBA_DYNAMIC_SEARCH_T_MIN_C", 15.0)
temperature_max_C = _script_env_float("DFBA_DYNAMIC_SEARCH_T_MAX_C", 25.0)
reference_temperature_C = _script_env_float("DFBA_DYNAMIC_SEARCH_REFERENCE_T_C", 20.0)
fix_initial_temperature = _script_env_bool("DFBA_DYNAMIC_SEARCH_FIX_INITIAL_T", true)
fixed_initial_temperature_C = fix_initial_temperature ?
    _script_env_float("DFBA_DYNAMIC_SEARCH_FIXED_INITIAL_T_C", 20.0) :
    nothing
initial_temperature_values_C =
    _dynamic_search_env_optional_float_vector("DFBA_DYNAMIC_SEARCH_INITIAL_TEMPERATURE_VALUES_C")
initial_step_C = _script_env_float("DFBA_DYNAMIC_SEARCH_INITIAL_STEP_C", 2.0)
min_step_C = _script_env_float("DFBA_DYNAMIC_SEARCH_MIN_STEP_C", 0.5)
step_reduction = _script_env_float("DFBA_DYNAMIC_SEARCH_STEP_REDUCTION", 0.5)
max_evaluations = _dynamic_search_env_positive_int("DFBA_DYNAMIC_SEARCH_MAX_EVALUATIONS", 20)
improvement_tol = _dynamic_search_env_nonnegative_float("DFBA_DYNAMIC_SEARCH_IMPROVEMENT_TOL", 1.0e-8)
saveat = _script_env_float("DFBA_DYNAMIC_SEARCH_SAVEAT_HOURS", 1.0)
reconstruct_fluxes = _script_env_bool("DFBA_DYNAMIC_SEARCH_RECONSTRUCT_FLUXES", false)
overwrite = _script_env_bool("DFBA_DYNAMIC_SEARCH_EXPORT_OVERWRITE", true)
stop_on_sugar_depletion = _script_env_bool("DFBA_DYNAMIC_SEARCH_STOP_ON_SUGAR_DEPLETION", true)
sugar_depletion_tol = _dynamic_search_env_nonnegative_float(
    "DFBA_DYNAMIC_SEARCH_SUGAR_DEPLETION_TOL",
    1.0e-6,
)
phase_proxy_mode = strip(get(ENV, "DFBA_DYNAMIC_SEARCH_PHASE_PROXY_MODE", "total_molecular_weight"))
turnover_threshold = _script_env_float("DFBA_DYNAMIC_SEARCH_TURNOVER_THRESHOLD", 0.001)
progress_interval_seconds = _dynamic_search_env_nonnegative_float(
    "DFBA_DYNAMIC_SEARCH_PROGRESS_INTERVAL_SECONDS",
    0.0,
)
max_rhs_calls = _dynamic_search_env_optional_positive_int("DFBA_DYNAMIC_SEARCH_MAX_RHS_CALLS")
max_walltime_seconds =
    _dynamic_search_env_optional_positive_float("DFBA_DYNAMIC_SEARCH_MAX_WALLTIME_SECONDS")
algorithm_config = _script_ode_algorithm_config("DFBA_DYNAMIC_SEARCH_ALGORITHM")
optimizer_backend, solver_label =
    _resolve_solver_backend(get(ENV, "DFBA_DYNAMIC_SEARCH_SOLVER_BACKEND", "HiGHS"))
tolerance_config = (
    ode_abstol = _script_env_float("DFBA_DYNAMIC_SEARCH_ODE_ABSTOL", DEFAULT_SCRIPT_ODE_ABSTOL),
    ode_reltol = _script_env_float("DFBA_DYNAMIC_SEARCH_ODE_RELTOL", DEFAULT_SCRIPT_ODE_RELTOL),
    lp_atol = _script_env_float("DFBA_DYNAMIC_SEARCH_LP_ATOL", DEFAULT_SCRIPT_LP_ATOL),
)
weights = DynamicTemperatureObjectiveWeights(
    final_total_sugar_weight = _dynamic_search_env_nonnegative_float(
        "DFBA_DYNAMIC_SEARCH_FINAL_SUGAR_WEIGHT",
        1.0,
    ),
    ethanol_reward_weight = _dynamic_search_env_nonnegative_float(
        "DFBA_DYNAMIC_SEARCH_ETHANOL_REWARD_WEIGHT",
        0.0,
    ),
    temperature_smoothness_weight = _dynamic_search_env_nonnegative_float(
        "DFBA_DYNAMIC_SEARCH_TEMPERATURE_SMOOTHNESS_WEIGHT",
        0.0,
    ),
    temperature_move_weight = _dynamic_search_env_nonnegative_float(
        "DFBA_DYNAMIC_SEARCH_TEMPERATURE_MOVE_WEIGHT",
        0.0,
    ),
    reference_temperature_C = reference_temperature_C,
    negative_state_tolerance = _dynamic_search_env_nonnegative_float(
        "DFBA_DYNAMIC_SEARCH_NEGATIVE_STATE_TOL",
        1.0e-9,
    ),
    negative_state_penalty_weight = _dynamic_search_env_nonnegative_float(
        "DFBA_DYNAMIC_SEARCH_NEGATIVE_STATE_PENALTY_WEIGHT",
        1.0e8,
    ),
    incomplete_horizon_penalty_weight = _dynamic_search_env_nonnegative_float(
        "DFBA_DYNAMIC_SEARCH_INCOMPLETE_HORIZON_PENALTY_WEIGHT",
        1.0e6,
    ),
    failure_penalty = _dynamic_search_env_nonnegative_float(
        "DFBA_DYNAMIC_SEARCH_FAILURE_PENALTY",
        1.0e9,
    ),
)

params = default_zenteno_parameters(
    phase_proxy_mode = phase_proxy_mode,
    TURNOVER_THRESHOLD = turnover_threshold,
)
initial_state_config = _script_initial_state_config(params)
output_dir = _script_output_dir(
    project_root,
    "DFBA_DYNAMIC_SEARCH_OUTPUT_DIR",
    joinpath("results", "dynamic_temperature_pattern_search_latest"),
)
mkpath(output_dir)
candidate_path = joinpath(output_dir, "dynamic_temperature_pattern_search_candidates.csv")
metadata_path = joinpath(output_dir, "dynamic_temperature_pattern_search_metadata.toml")
if !overwrite
    existing_targets = [path for path in (candidate_path, metadata_path) if isfile(path)]
    isempty(existing_targets) || error(
        "Dynamic temperature search target file(s) already exist and overwrite=false: " *
        join(sort(existing_targets), ", "),
    )
end

common_kwargs = (
    weights = weights,
    horizon_h = horizon_h,
    control_interval_h = control_interval_h,
    temperature_transition_width_h = temperature_transition_width_h,
    temperature_min_C = temperature_min_C,
    temperature_max_C = temperature_max_C,
    reference_temperature_C = reference_temperature_C,
    fixed_initial_temperature_C = fixed_initial_temperature_C,
    initial_temperature_values_C = initial_temperature_values_C,
    initial_step_C = initial_step_C,
    min_step_C = min_step_C,
    step_reduction = step_reduction,
    max_evaluations = max_evaluations,
    improvement_tol = improvement_tol,
    y0 = initial_state_config.y0,
    params = params,
    lp_atol = tolerance_config.lp_atol,
    ode_abstol = tolerance_config.ode_abstol,
    ode_reltol = tolerance_config.ode_reltol,
    saveat = saveat,
    algorithm = algorithm_config.algorithm,
    reconstruct_fluxes = reconstruct_fluxes,
    stop_on_sugar_depletion = stop_on_sugar_depletion,
    sugar_depletion_tol = sugar_depletion_tol,
    progress_interval_seconds = progress_interval_seconds,
    max_rhs_calls = max_rhs_calls,
    max_walltime_seconds = max_walltime_seconds,
)

start_time = time()
search = optimizer_backend === nothing ?
    optimize_dynamic_temperature_pattern_search(model, reaction_map; common_kwargs...) :
    optimize_dynamic_temperature_pattern_search(
        model,
        reaction_map;
        optimizer = optimizer_backend,
        common_kwargs...,
    )
elapsed_seconds = time() - start_time

CSV.write(candidate_path, search.candidate_table)
metadata = merge(
    copy(search.metadata),
    Dict{String, Any}(
        "script" => "main_dynamic_temperature_pattern_search.jl",
        "solver_label" => solver_label,
        "algorithm_label" => algorithm_config.algorithm_label,
        "output_dir" => output_dir,
        "candidate_table" => candidate_path,
        "elapsed_seconds" => elapsed_seconds,
        "saveat" => saveat,
        "reconstruct_fluxes" => reconstruct_fluxes,
        "stop_on_sugar_depletion" => stop_on_sugar_depletion,
        "sugar_depletion_tol" => sugar_depletion_tol,
        "phase_proxy_mode" => phase_proxy_mode,
        "turnover_threshold" => turnover_threshold,
        "ode_abstol" => tolerance_config.ode_abstol,
        "ode_reltol" => tolerance_config.ode_reltol,
        "lp_atol" => tolerance_config.lp_atol,
        "progress_interval_seconds" => progress_interval_seconds,
        "max_rhs_calls" => max_rhs_calls,
        "max_walltime_seconds" => max_walltime_seconds,
        "weights" => Dict{String, Any}(
            "final_total_sugar_weight" => weights.final_total_sugar_weight,
            "ethanol_reward_weight" => weights.ethanol_reward_weight,
            "temperature_smoothness_weight" => weights.temperature_smoothness_weight,
            "temperature_move_weight" => weights.temperature_move_weight,
            "reference_temperature_C" => weights.reference_temperature_C,
            "negative_state_tolerance" => weights.negative_state_tolerance,
            "negative_state_penalty_weight" => weights.negative_state_penalty_weight,
            "incomplete_horizon_penalty_weight" => weights.incomplete_horizon_penalty_weight,
            "failure_penalty" => weights.failure_penalty,
        ),
        "initial_conditions" => initial_state_config.metadata,
    ),
)
open(metadata_path, "w") do io
    TOML.print(io, _dynamic_search_toml_normalize(metadata))
end

best = search.best_evaluation
println("Dynamic temperature pattern search")
println("output_dir: $output_dir")
println("candidate_csv: $candidate_path")
println("metadata_toml: $metadata_path")
println("solver_label: $solver_label")
println("algorithm_label: $(algorithm_config.algorithm_label)")
println("horizon_h: $horizon_h")
println("control_interval_h: $control_interval_h")
println("unique_evaluations: $(search.metadata["unique_evaluations"])")
println("candidate_rows: $(search.metadata["candidate_rows"])")
println("elapsed_seconds: $elapsed_seconds")
println("best_candidate_id: $(search.metadata["best_candidate_id"])")
println("best_objective_value: $(best.objective_value)")
println("best_feasible: $(best.feasible)")
println("best_final_total_sugar: $(best.summary["final_total_sugar"])")
println("best_sugar_consumed: $(best.summary["sugar_consumed"])")
println("best_final_ethanol: $(best.summary["final_ethanol"])")
println("best_temperature_values_C: $(join(string.(search.metadata["best_temperature_values_C"]), ","))")
