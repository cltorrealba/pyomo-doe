#!/usr/bin/env python3
"""Prepare a lightweight dynamic-control policy selection CSV.

This helper is intentionally dependency-free so it can run on a login node for
CSV preparation without loading Julia packages. Heavy sequential/MPCC work still
belongs in Slurm jobs.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def _truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def _float(value: str | None, default: float = float("nan")) -> float:
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return default


def _split_ids(raw: str) -> list[str]:
    ids: list[str] = []
    for token in raw.replace(";", ",").split(","):
        candidate_id = token.strip()
        if candidate_id and candidate_id not in ids:
            ids.append(candidate_id)
    return ids


def _required_columns(fieldnames: list[str] | None) -> None:
    required = {
        "candidate_id",
        "objective_value",
        "feasible",
        "status",
        "final_time",
        "final_total_sugar",
        "aroma_desirability_score",
        "nutrient_total_product_g_L",
        "min_state_value",
        "gate_pass",
        "temperature_values_C",
        "fda_doses_g_L",
        "organic_doses_g_L",
    }
    available = set(fieldnames or [])
    missing = sorted(required - available)
    if missing:
        raise SystemExit(
            "Candidate CSV is missing required column(s): " + ", ".join(missing)
        )


def _policy_ready(
    row: dict[str, str],
    *,
    ready_horizon_h: float,
    state_tol: float,
    development_ready: bool,
) -> bool:
    horizon_ready = _float(row.get("final_time")) >= ready_horizon_h - 1.0e-8
    state_ready = _float(row.get("min_state_value"), 0.0) >= -state_tol
    if development_ready:
        retcode = str(row.get("retcode", "")).strip().lower()
        termination = str(row.get("termination_reason", "")).strip().lower()
        return (
            horizon_ready
            and state_ready
            and retcode == "success"
            and termination == "completed_tspan"
        )

    return (
        _truthy(row.get("feasible"))
        and str(row.get("status", "")).strip().lower() == "accepted"
        and _truthy(row.get("gate_pass"))
        and horizon_ready
        and state_ready
    )


def _select_rows(rows: list[dict[str, str]], selected_ids: list[str]) -> list[dict[str, str]]:
    by_id = {row["candidate_id"]: row for row in rows}
    missing = [candidate_id for candidate_id in selected_ids if candidate_id not in by_id]
    if missing:
        raise SystemExit("Selected candidate ID(s) were not found: " + ", ".join(missing))
    return [dict(by_id[candidate_id]) for candidate_id in selected_ids]


def _auto_selected_ids(rows: list[dict[str, str]], count: int) -> list[str]:
    review_rows = [
        row for row in rows if _truthy(row.get("selected_for_review")) and _truthy(row.get("feasible"))
    ]
    review_rows.sort(key=lambda row: (_float(row.get("selection_rank"), 1.0e12), row["candidate_id"]))
    if review_rows:
        return [row["candidate_id"] for row in review_rows[:count]]

    feasible_rows = [row for row in rows if _truthy(row.get("feasible"))]
    feasible_rows.sort(key=lambda row: (_float(row.get("objective_value"), 1.0e300), row["candidate_id"]))
    return [row["candidate_id"] for row in feasible_rows[:count]]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidates-csv", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--selected-ids", default="")
    parser.add_argument("--count", type=int, default=1)
    parser.add_argument("--ready-horizon-h", type=float, required=True)
    parser.add_argument("--state-tol", type=float, default=1.0e-8)
    parser.add_argument(
        "--development-ready-ignore-gates",
        action="store_true",
        help=(
            "Mark sequentially completed policies as control-ready even when "
            "objective/gate columns reject them. Use only for development "
            "horizons where dryness is intentionally not required."
        ),
    )
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    candidates_csv = Path(args.candidates_csv).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    selection_csv = output_dir / "dynamic_control_policy_selection.csv"
    metadata_json = output_dir / "dynamic_control_policy_selection_metadata.json"

    if not candidates_csv.is_file():
        raise SystemExit(f"Candidate CSV does not exist: {candidates_csv}")
    output_dir.mkdir(parents=True, exist_ok=True)
    if not args.overwrite:
        existing = [path for path in (selection_csv, metadata_json) if path.exists()]
        if existing:
            raise SystemExit(
                "Policy selection output file(s) already exist: "
                + ", ".join(str(path) for path in existing)
            )

    with candidates_csv.open(newline="") as handle:
        reader = csv.DictReader(handle)
        _required_columns(reader.fieldnames)
        rows = list(reader)

    if not rows:
        raise SystemExit(f"Candidate CSV is empty: {candidates_csv}")

    selected_ids = _split_ids(args.selected_ids)
    if not selected_ids:
        selected_ids = _auto_selected_ids(rows, args.count)
    if not selected_ids:
        raise SystemExit("No candidates were selected.")

    selection = _select_rows(rows, selected_ids)
    for rank, row in enumerate(selection, start=1):
        final_sugar = row.get("final_total_sugar", "missing")
        aroma = row.get("aroma_desirability_score", "missing")
        nutrient = row.get("nutrient_total_product_g_L", "missing")
        ready = _policy_ready(
            row,
            ready_horizon_h=float(args.ready_horizon_h),
            state_tol=float(args.state_tol),
            development_ready=bool(args.development_ready_ignore_gates),
        )
        row["policy_rank"] = str(rank)
        if args.development_ready_ignore_gates:
            row["policy_role"] = "development_reference_policy"
            row["policy_reason"] = (
                "Development policy; sequential simulation completed but "
                "objective/gate acceptance was intentionally ignored; "
                f"final sugar={final_sugar} g/L, aroma={aroma}, nutrient={nutrient} g/L."
            )
        else:
            row["policy_role"] = "extended_neardry_reference_policy"
            row["policy_reason"] = (
                "Extended-horizon near-dry policy; "
                f"final sugar={final_sugar} g/L, aroma={aroma}, nutrient={nutrient} g/L."
            )
        row["control_policy_ready"] = "true" if ready else "false"
        row["mpcc_fixed_control_replay_ready"] = "false"
        row["mpcc_fixed_control_replay_blocker"] = (
            "Selection only; run fixed-control MPCC preflight/solve through Slurm."
        )

    fieldnames = list(rows[0].keys())
    for extra in (
        "policy_rank",
        "policy_role",
        "policy_reason",
        "control_policy_ready",
        "mpcc_fixed_control_replay_ready",
        "mpcc_fixed_control_replay_blocker",
    ):
        if extra not in fieldnames:
            fieldnames.append(extra)

    with selection_csv.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(selection)

    metadata = {
        "script": "main_prepare_dynamic_control_policy_selection.py",
        "input_candidates_csv": str(candidates_csv),
        "output_dir": str(output_dir),
        "selection_csv": str(selection_csv),
        "selected_candidate_ids": selected_ids,
        "ready_horizon_h": float(args.ready_horizon_h),
        "state_tol": float(args.state_tol),
        "development_ready_ignore_gates": bool(args.development_ready_ignore_gates),
        "all_control_policies_ready": all(_truthy(row["control_policy_ready"]) for row in selection),
    }
    metadata_json.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")

    print("Dynamic control policy selection prepared")
    print(f"candidate_csv: {candidates_csv}")
    print(f"selection_csv: {selection_csv}")
    print(f"metadata_json: {metadata_json}")
    print(f"selected_candidate_ids: {','.join(selected_ids)}")
    print(f"all_control_policies_ready: {metadata['all_control_policies_ready']}")


if __name__ == "__main__":
    main()
