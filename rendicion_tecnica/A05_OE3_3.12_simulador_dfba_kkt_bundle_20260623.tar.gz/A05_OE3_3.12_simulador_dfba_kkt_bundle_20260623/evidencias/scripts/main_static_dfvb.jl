using FermentationDFBA
using SparseArrays

project_root = normpath(joinpath(@__DIR__, ".."))
full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
dfvb_paths_config = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")

full_model = load_full_model(full_paths_config)
artifacts = load_dfvb_artifacts(
    dfvb_paths_config;
    load_alpha_trajectories = false,
    load_active_alpha_trajectories = false,
    load_state_trajectories = false,
)
validation = validate_dfvb_artifacts(artifacts)
validation.ok || error("DFVB artifact validation failed: $(join(validation.errors, "; "))")

result = solve_static_dfvb(
    full_model,
    artifacts;
    objective_rxn_id = "r_2111",
    use_active_alpha = true,
)

function _static_dfvb_flux_value(model, result::StaticDFVBResult, reaction_id::AbstractString)
    if !has_reaction(model, reaction_id) || isempty(result.fluxes)
        return "missing"
    end
    return string(result.fluxes[reaction_index(model, reaction_id)])
end

println("Static DFVB LP smoke report")
println("model_id: $(full_model.model_id)")
println("model_dimensions: $(size(full_model.S))")
println("artifact_id: $(artifacts.paths.artifact_id)")
println("artifact_validation_ok: $(validation.ok)")
println("use_active_alpha: $(result.use_active_alpha)")
println("alpha_scope: $(result.metadata["alpha_scope"])")
println("N_active_size: $(size(artifacts.N_active))")
println("N_active_nnz: $(nnz(artifacts.N_active))")
println("alpha_dimension: $(length(result.alpha))")
println("solver_status: $(result.status)")
println("primal_status: $(result.primal_status)")
println("dual_status: $(result.dual_status)")
println("solver_label: $(result.metadata["solver_label"])")
println("objective_reaction: $(result.objective_rxn_id)")
println("objective_reaction_index: $(result.objective_reaction_index)")
println("objective_value: $(result.objective_value)")
println("reconstructed_objective_flux: $(_static_dfvb_flux_value(full_model, result, result.objective_rxn_id))")
println("mass_balance_residual: $(result.mass_balance_residual)")
println("max_lower_bound_violation: $(result.max_lower_bound_violation)")
println("max_upper_bound_violation: $(result.max_upper_bound_violation)")

println("selected_reconstructed_fluxes:")
for reaction_id in ("r_2111", "r_1714", "r_1709", "r_1761", "r_0001", "r_1992", "r_4046", "r_4047", "r_4048")
    println("  $reaction_id = $(_static_dfvb_flux_value(full_model, result, reaction_id))")
end

println("artifact_warnings:")
for warning in validation.warnings
    println("  warning: $warning")
end

println("r0001_used_as_oxygen: $(result.metadata["r0001_used_as_oxygen"])")
println("indices_reacciones_used: $(result.metadata["indices_reacciones_used"])")
println("oxygen_reaction_id: $(result.metadata["oxygen_reaction_id"])")
println("oxygen_mapping_note: $(result.metadata["oxygen_mapping_note"])")
println("exchange_partition_note: $(result.metadata["exchange_partition_note"])")
println("biological_interpretation_note: $(result.metadata["biological_interpretation_note"])")
println("scope_note: Static DFVB LP smoke only; no DFVB RHS or KKT/MPCC is implemented.")
