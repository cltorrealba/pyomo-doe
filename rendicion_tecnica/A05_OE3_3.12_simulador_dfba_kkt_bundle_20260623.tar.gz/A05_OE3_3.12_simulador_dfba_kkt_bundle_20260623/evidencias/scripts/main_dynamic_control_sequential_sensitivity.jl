using CSV
using DataFrames
using Dates
using FermentationDFBA
using TOML

include(joinpath(@__DIR__, "solver_backend_helpers.jl"))
include(joinpath(@__DIR__, "ode_script_helpers.jl"))

const SENSITIVITY_SCRIPT = "main_dynamic_control_sequential_sensitivity.jl"
const SENSITIVITY_OUTPUT_COLUMNS = [
    "case_id",
    "control_type",
    "slot_index",
    "direction",
    "delta_value",
    "status",
    "error",
    "temperature_linf_delta_C",
    "fda_l1_delta_g_L",
    "organic_l1_delta_g_L",
    "retcode",
    "termination_reason",
    "final_time_h",
    "final_glucose_g_L",
    "final_fructose_g_L",
    "final_total_sugar_g_L",
    "sugar_consumed_g_L",
    "final_ethanol_g_L",
    "final_biomass_g_L",
    "final_nitrogen_gN_L",
    "final_isoamyl_alcohol_g_L",
    "final_phenylethanol_g_L",
    "final_isobutanol_g_L",
    "final_methionol_g_L",
    "final_tyrosol_g_L",
    "final_ethyl_acetate_g_L",
    "time_to_sugar_depletion_h",
    "min_state_value",
    "has_negative_saved_states",
    "max_mass_balance_residual",
    "max_lower_bound_violation",
    "max_upper_bound_violation",
    "simulation_elapsed_seconds",
    "ode_solve_elapsed_seconds",
    "rhs_call_count",
    "total_lp_solve_count",
    "delta_final_total_sugar_g_L_vs_baseline",
    "sensitivity_final_total_sugar_g_L_per_unit_delta",
    "delta_sugar_consumed_g_L_vs_baseline",
    "sensitivity_sugar_consumed_g_L_per_unit_delta",
    "delta_final_isoamyl_alcohol_g_L_vs_baseline",
    "sensitivity_final_isoamyl_alcohol_g_L_per_unit_delta",
    "delta_final_phenylethanol_g_L_vs_baseline",
    "sensitivity_final_phenylethanol_g_L_per_unit_delta",
    "delta_final_isobutanol_g_L_vs_baseline",
    "sensitivity_final_isobutanol_g_L_per_unit_delta",
    "delta_final_methionol_g_L_vs_baseline",
    "sensitivity_final_methionol_g_L_per_unit_delta",
    "delta_final_tyrosol_g_L_vs_baseline",
    "sensitivity_final_tyrosol_g_L_per_unit_delta",
    "delta_final_ethyl_acetate_g_L_vs_baseline",
    "sensitivity_final_ethyl_acetate_g_L_per_unit_delta",
    "delta_final_ethanol_g_L_vs_baseline",
    "sensitivity_final_ethanol_g_L_per_unit_delta",
    "delta_final_biomass_g_L_vs_baseline",
    "sensitivity_final_biomass_g_L_per_unit_delta",
]

project_root = normpath(joinpath(@__DIR__, ".."))
script_start_time = time()

function _sens_phase(label::AbstractString)
    println("dynamic_control_sensitivity_phase: $(label) elapsed_seconds=$(round(time() - script_start_time; digits = 3))")
    flush(stdout)
    return nothing
end

function _sens_env_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _sens_env_nonnegative_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _sens_env_path(name::AbstractString, default_path::AbstractString)::String
    raw_value = strip(get(ENV, String(name), default_path))
    isempty(raw_value) && error("Environment variable $name must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _sens_parse_float_vector(raw_value)::Vector{Float64}
    raw_value isa Missing && return Float64[]
    values = Float64[]
    for token in split(replace(string(raw_value), ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Could not parse Float64 token '$cleaned' from '$raw_value'.")
        isfinite(value) || error("Non-finite Float64 token '$cleaned' from '$raw_value'.")
        push!(values, value)
    end
    return values
end

function _sens_parse_indices(name::AbstractString, default_values::Vector{Int})::Vector{Int}
    raw_value = strip(get(ENV, String(name), join(default_values, ",")))
    isempty(raw_value) && return Int[]
    indices = Int[]
    for token in split(replace(raw_value, ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Int, cleaned)
        value === nothing && error("Environment variable $name contains a non-Int token: $cleaned")
        value > 0 || error("Environment variable $name indices must be positive, got: $value")
        value in indices || push!(indices, value)
    end
    return indices
end

function _sens_resized(values::Vector{Float64}, length_required::Int; fill_value::Float64)::Vector{Float64}
    length_required >= 0 || error("Required vector length must be nonnegative.")
    if length(values) >= length_required
        return copy(values[1:length_required])
    end
    output = copy(values)
    append!(output, fill(fill_value, length_required - length(values)))
    return output
end

function _sens_state_names(result)::Vector{String}
    return String.(get(result.metadata, "state_names", FermentationDFBA.DEFAULT_SIMULATION_STATE_NAMES))
end

function _sens_state_value(result, state_name::AbstractString)::Float64
    names = _sens_state_names(result)
    index = findfirst(==(String(state_name)), names)
    index === nothing && return NaN
    return Float64(result.states[index, end])
end

function _sens_bool_string(value)::String
    value isa Bool && return string(value)
    value isa Missing && return "missing"
    return string(value)
end

function _sens_candidate_row(table::DataFrame, candidate_id::AbstractString)
    ids = String.(table.candidate_id)
    matches = findall(==(String(candidate_id)), ids)
    length(matches) == 1 || error(
        "Expected exactly one candidate_id=$(candidate_id) in policy selection CSV, found $(length(matches)).",
    )
    return table[matches[1], :]
end

function _sens_push_case!(
    cases::Vector{Dict{String, Any}},
    case_id::AbstractString,
    control_type::AbstractString,
    slot_index::Int,
    direction::AbstractString,
    delta_value::Float64,
    temperature::Vector{Float64},
    fda::Vector{Float64},
    organic::Vector{Float64},
    max_cases::Int,
)
    length(cases) >= max_cases && return false
    push!(
        cases,
        Dict{String, Any}(
            "case_id" => String(case_id),
            "control_type" => String(control_type),
            "slot_index" => slot_index,
            "direction" => String(direction),
            "delta_value" => delta_value,
            "temperature_values_C" => copy(temperature),
            "fda_doses_g_L" => copy(fda),
            "organic_doses_g_L" => copy(organic),
        ),
    )
    return true
end

function _sens_build_cases(;
    base_temperature::Vector{Float64},
    base_fda::Vector{Float64},
    base_organic::Vector{Float64},
    temperature_indices::Vector{Int},
    fda_indices::Vector{Int},
    organic_indices::Vector{Int},
    temperature_delta_C::Float64,
    fda_delta_g_L::Float64,
    organic_delta_g_L::Float64,
    temperature_min_C::Float64,
    temperature_max_C::Float64,
    max_cases::Int,
)::Vector{Dict{String, Any}}
    cases = Dict{String, Any}[]
    _sens_push_case!(
        cases,
        "baseline",
        "baseline",
        0,
        "none",
        0.0,
        base_temperature,
        base_fda,
        base_organic,
        max_cases,
    )
    for index in temperature_indices
        1 <= index <= length(base_temperature) || continue
        for (direction, signed_delta) in (("plus", temperature_delta_C), ("minus", -temperature_delta_C))
            moved = copy(base_temperature)
            moved[index] = clamp(moved[index] + signed_delta, temperature_min_C, temperature_max_C)
            actual_delta = moved[index] - base_temperature[index]
            iszero(actual_delta) && continue
            _sens_push_case!(
                cases,
                "temperature_$(index)_$(direction)",
                "temperature",
                index,
                direction,
                actual_delta,
                moved,
                base_fda,
                base_organic,
                max_cases,
            ) || return cases
        end
    end
    for index in fda_indices
        1 <= index <= length(base_fda) || continue
        moved = copy(base_fda)
        moved[index] += fda_delta_g_L
        _sens_push_case!(
            cases,
            "fda_$(index)_plus",
            "fda",
            index,
            "plus",
            fda_delta_g_L,
            base_temperature,
            moved,
            base_organic,
            max_cases,
        ) || return cases
    end
    for index in organic_indices
        1 <= index <= length(base_organic) || continue
        moved = copy(base_organic)
        moved[index] += organic_delta_g_L
        _sens_push_case!(
            cases,
            "organic_$(index)_plus",
            "organic",
            index,
            "plus",
            organic_delta_g_L,
            base_temperature,
            base_fda,
            moved,
            max_cases,
        ) || return cases
    end
    return cases
end

function _sens_schedule(case::Dict{String, Any}; config)
    return reference_dynamic_control_schedule(
        horizon_h = config.horizon_h,
        control_interval_h = config.control_interval_h,
        temperature_values_C = case["temperature_values_C"],
        temperature_transition_width_h = config.temperature_transition_width_h,
        temperature_min_C = config.temperature_min_C,
        temperature_max_C = config.temperature_max_C,
        fda_doses_g_L = case["fda_doses_g_L"],
        organic_doses_g_L = case["organic_doses_g_L"],
        addition_transition_width_h = config.addition_transition_width_h,
        fda_total_limit_g_L = config.fda_total_limit_g_L,
    )
end

function _sens_case_row(case::Dict{String, Any}; result = nothing, err = nothing)
    row = Dict{String, Any}(
        "case_id" => case["case_id"],
        "control_type" => case["control_type"],
        "slot_index" => case["slot_index"],
        "direction" => case["direction"],
        "delta_value" => case["delta_value"],
        "status" => err === nothing ? "ok" : "failed",
        "error" => err === nothing ? "" : sprint(showerror, err),
        "temperature_linf_delta_C" => maximum(
            abs.(case["temperature_values_C"] .- case["base_temperature_values_C"]);
            init = 0.0,
        ),
        "fda_l1_delta_g_L" => sum(abs.(case["fda_doses_g_L"] .- case["base_fda_doses_g_L"]); init = 0.0),
        "organic_l1_delta_g_L" => sum(
            abs.(case["organic_doses_g_L"] .- case["base_organic_doses_g_L"]);
            init = 0.0,
        ),
    )
    if result !== nothing
        summary = summarize_simulation(result)
        row["retcode"] = get(summary, "retcode", missing)
        row["termination_reason"] = get(summary, "termination_reason", missing)
        row["final_time_h"] = get(summary, "final_time", missing)
        row["final_glucose_g_L"] = get(summary, "final_glucose", missing)
        row["final_fructose_g_L"] = get(summary, "final_fructose", missing)
        row["final_total_sugar_g_L"] = get(summary, "final_total_sugar", missing)
        row["sugar_consumed_g_L"] = get(summary, "sugar_consumed", missing)
        row["final_ethanol_g_L"] = get(summary, "final_ethanol", missing)
        row["final_biomass_g_L"] = get(summary, "final_biomass", missing)
        row["final_nitrogen_gN_L"] = get(summary, "final_nitrogen", missing)
        row["final_isoamyl_alcohol_g_L"] = _sens_state_value(result, "isoamyl_alcohol")
        row["final_phenylethanol_g_L"] = _sens_state_value(result, "phenylethanol")
        row["final_isobutanol_g_L"] = _sens_state_value(result, "isobutanol")
        row["final_methionol_g_L"] = _sens_state_value(result, "methionol")
        row["final_tyrosol_g_L"] = _sens_state_value(result, "tyrosol")
        row["final_ethyl_acetate_g_L"] = _sens_state_value(result, "ethyl_acetate")
        row["time_to_sugar_depletion_h"] = get(summary, "time_to_sugar_depletion", missing)
        row["min_state_value"] = get(summary, "min_state_value", missing)
        row["has_negative_saved_states"] = _sens_bool_string(get(summary, "has_negative_saved_states", missing))
        row["max_mass_balance_residual"] = get(summary, "max_mass_balance_residual", missing)
        row["max_lower_bound_violation"] = get(summary, "max_lower_bound_violation", missing)
        row["max_upper_bound_violation"] = get(summary, "max_upper_bound_violation", missing)
        row["simulation_elapsed_seconds"] = get(summary, "simulation_elapsed_seconds", missing)
        row["ode_solve_elapsed_seconds"] = get(summary, "ode_solve_elapsed_seconds", missing)
        row["rhs_call_count"] = get(summary, "rhs_call_count", missing)
        row["total_lp_solve_count"] = get(summary, "total_lp_solve_count", missing)
    end
    return row
end

function _sens_add_baseline_deltas!(rows::Vector{Dict{String, Any}})
    baseline_index = findfirst(row -> row["case_id"] == "baseline" && row["status"] == "ok", rows)
    baseline_index === nothing && return rows
    baseline = rows[baseline_index]
    metric_names = [
        "final_total_sugar_g_L",
        "sugar_consumed_g_L",
        "final_isoamyl_alcohol_g_L",
        "final_phenylethanol_g_L",
        "final_isobutanol_g_L",
        "final_methionol_g_L",
        "final_tyrosol_g_L",
        "final_ethyl_acetate_g_L",
        "final_ethanol_g_L",
        "final_biomass_g_L",
    ]
    for row in rows
        for metric in metric_names
            delta_key = "delta_$(metric)_vs_baseline"
            sensitivity_key = "sensitivity_$(metric)_per_unit_delta"
            if row["status"] == "ok" && haskey(row, metric) && haskey(baseline, metric)
                value = Float64(row[metric])
                base = Float64(baseline[metric])
                delta = value - base
                row[delta_key] = delta
                row[sensitivity_key] = iszero(Float64(row["delta_value"])) ? missing : delta / Float64(row["delta_value"])
            else
                row[delta_key] = missing
                row[sensitivity_key] = missing
            end
        end
    end
    return rows
end

function _sens_result_table(rows::Vector{Dict{String, Any}})::DataFrame
    rows_with_deltas = [Dict{String, Any}(row) for row in rows]
    _sens_add_baseline_deltas!(rows_with_deltas)
    result_table = DataFrame(rows_with_deltas)
    ordered_columns = [column for column in SENSITIVITY_OUTPUT_COLUMNS if column in names(result_table)]
    remaining_columns = sort(setdiff(names(result_table), ordered_columns))
    select!(result_table, vcat(ordered_columns, remaining_columns))
    return result_table
end

function _sens_write_result_tables(
    output_dir::AbstractString,
    rows::Vector{Dict{String, Any}};
    suffix::AbstractString = "",
)::String
    result_table = _sens_result_table(rows)
    result_path = joinpath(output_dir, "dynamic_control_sequential_sensitivity$(suffix).csv")
    CSV.write(result_path, result_table; transform = (col, val) -> something(val, missing))

    ranked = filter(row -> row.status == "ok" && row.case_id != "baseline", result_table)
    if nrow(ranked) > 0 && "delta_final_total_sugar_g_L_vs_baseline" in names(ranked)
        ranked[!, :abs_delta_final_total_sugar_g_L_vs_baseline] =
            abs.(Float64.(ranked[!, :delta_final_total_sugar_g_L_vs_baseline]))
        sort!(ranked, :abs_delta_final_total_sugar_g_L_vs_baseline, rev = true)
        CSV.write(
            joinpath(output_dir, "dynamic_control_sequential_sensitivity_ranked$(suffix).csv"),
            ranked;
            transform = (col, val) -> something(val, missing),
        )
    end
    return result_path
end

_sens_phase("before_config")
timestamp = Dates.format(now(), "yyyymmdd_HHMMSS")
default_output_dir = joinpath(homedir(), "mpcc_runs", "dynamic_control_sequential_sensitivity_$(timestamp)")
output_dir = _sens_env_path("MPCC_DYNAMIC_CONTROL_SENSITIVITY_OUTPUT_DIR", default_output_dir)
mkpath(output_dir)

policy_selection_csv = _sens_env_path(
    "MPCC_DYNAMIC_CONTROL_SENSITIVITY_POLICY_SELECTION_CSV",
    joinpath(
        homedir(),
        "mpcc_runs",
        "dynamic_control_mpcc_fixed_replay_20260610_131549",
        "selection",
        "dynamic_control_policy_selection.csv",
    ),
)
candidate_id = strip(get(ENV, "MPCC_DYNAMIC_CONTROL_SENSITIVITY_CANDIDATE_ID", "cool18_warm22__springferm_early_0p4"))
horizon_h = _script_env_float("MPCC_DYNAMIC_CONTROL_SENSITIVITY_HOURS", 168.0)
control_interval_h = _script_env_float("MPCC_DYNAMIC_CONTROL_SENSITIVITY_INTERVAL_HOURS", 12.0)
saveat_h = _script_env_float("MPCC_DYNAMIC_CONTROL_SENSITIVITY_SAVEAT_HOURS", 6.0)
temperature_delta_C = _sens_env_nonnegative_float("MPCC_DYNAMIC_CONTROL_SENSITIVITY_TEMPERATURE_DELTA_C", 0.25)
fda_delta_g_L = _sens_env_nonnegative_float("MPCC_DYNAMIC_CONTROL_SENSITIVITY_FDA_DELTA_G_L", 0.05)
organic_delta_g_L = _sens_env_nonnegative_float("MPCC_DYNAMIC_CONTROL_SENSITIVITY_ORGANIC_DELTA_G_L", 0.02)
temperature_min_C = _script_env_float("DFBA_DYNAMIC_T_MIN_C", 15.0)
temperature_max_C = _script_env_float("DFBA_DYNAMIC_T_MAX_C", 25.0)
temperature_transition_width_h = _script_env_float("DFBA_DYNAMIC_TEMPERATURE_WIDTH_HOURS", 1.0)
addition_transition_width_h = _script_env_float("DFBA_DYNAMIC_ADDITION_WIDTH_HOURS", 0.5)
fda_total_limit_g_L = _script_env_float(
    "DFBA_DYNAMIC_FDA_TOTAL_LIMIT_G_L",
    FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L,
)
max_cases = _sens_env_int("MPCC_DYNAMIC_CONTROL_SENSITIVITY_MAX_CASES", 12)
temperature_indices = _sens_parse_indices("MPCC_DYNAMIC_CONTROL_SENSITIVITY_TEMPERATURE_INDICES", [1, 7, 14])
addition_indices = _sens_parse_indices("MPCC_DYNAMIC_CONTROL_SENSITIVITY_ADDITION_INDICES", [1, 7, 13])
fda_indices = _sens_parse_indices("MPCC_DYNAMIC_CONTROL_SENSITIVITY_FDA_INDICES", addition_indices)
organic_indices =
    _sens_parse_indices("MPCC_DYNAMIC_CONTROL_SENSITIVITY_ORGANIC_INDICES", addition_indices)
reconstruct_fluxes = _script_env_bool("MPCC_DYNAMIC_CONTROL_SENSITIVITY_RECONSTRUCT_FLUXES", false)
lp_reuse = _script_env_bool("MPCC_DYNAMIC_CONTROL_SENSITIVITY_LP_REUSE", false)
lp_primal_start = _script_env_bool("MPCC_DYNAMIC_CONTROL_SENSITIVITY_LP_PRIMAL_START", false)
lp_basis_warm_start = _script_env_bool("MPCC_DYNAMIC_CONTROL_SENSITIVITY_LP_BASIS_WARM_START", false)
allow_experimental_lp_reuse = _script_env_bool("MPCC_DYNAMIC_CONTROL_SENSITIVITY_ALLOW_EXPERIMENTAL_LP_REUSE", false)
lp_reuse_highs_solver = strip(get(ENV, "MPCC_DYNAMIC_CONTROL_SENSITIVITY_LP_REUSE_HIGHS_SOLVER", "simplex"))
lp_simplex_strategy = strip(get(ENV, "MPCC_DYNAMIC_CONTROL_SENSITIVITY_LP_SIMPLEX_STRATEGY", "default"))
phase_proxy_mode = strip(get(ENV, "DFBA_PHASE_PROXY_MODE", "total_molecular_weight"))
turnover_threshold = _script_env_float("DFBA_TURNOVER_THRESHOLD", 0.001)
algorithm_config = _script_ode_algorithm_config("MPCC_DYNAMIC_CONTROL_SENSITIVITY_ALGORITHM")
tolerance_config = _script_tolerance_config()
optimizer_backend, solver_label = _resolve_solver_backend(
    get(ENV, "MPCC_DYNAMIC_CONTROL_SENSITIVITY_SOLVER_BACKEND", "HiGHS"),
)

metadata = Dict{String, Any}(
    "script" => SENSITIVITY_SCRIPT,
    "created_at" => string(now()),
    "policy_selection_csv" => policy_selection_csv,
    "candidate_id" => candidate_id,
    "horizon_h" => horizon_h,
    "control_interval_h" => control_interval_h,
    "saveat_h" => saveat_h,
    "max_cases" => max_cases,
    "temperature_delta_C" => temperature_delta_C,
    "fda_delta_g_L" => fda_delta_g_L,
    "organic_delta_g_L" => organic_delta_g_L,
    "temperature_indices" => temperature_indices,
    "addition_indices" => addition_indices,
    "fda_indices" => fda_indices,
    "organic_indices" => organic_indices,
    "reconstruct_fluxes" => reconstruct_fluxes,
    "solver_label" => solver_label,
    "algorithm_label" => algorithm_config.algorithm_label,
    "cluster_rule" => "Run through Slurm or a compute allocation; do not run full sweeps on login.",
)
open(joinpath(output_dir, "dynamic_control_sequential_sensitivity_metadata.toml"), "w") do io
    TOML.print(io, metadata)
end

_sens_phase("before_model_load")
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")
model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)
_sens_phase("after_model_load")

isfile(policy_selection_csv) || error("Policy selection CSV does not exist: $policy_selection_csv")
selection_table = CSV.read(policy_selection_csv, DataFrame)
row = _sens_candidate_row(selection_table, candidate_id)

temperature_count = max(1, ceil(Int, horizon_h / control_interval_h))
addition_count = max(0, temperature_count - 1)
base_temperature = _sens_resized(
    _sens_parse_float_vector(row.temperature_values_C),
    temperature_count;
    fill_value = 20.0,
)
base_fda = _sens_resized(
    _sens_parse_float_vector(row.fda_doses_g_L),
    addition_count;
    fill_value = 0.0,
)
base_organic = _sens_resized(
    _sens_parse_float_vector(row.organic_doses_g_L),
    addition_count;
    fill_value = 0.0,
)

cases = _sens_build_cases(
    base_temperature = base_temperature,
    base_fda = base_fda,
    base_organic = base_organic,
    temperature_indices = temperature_indices,
    fda_indices = fda_indices,
    organic_indices = organic_indices,
    temperature_delta_C = temperature_delta_C,
    fda_delta_g_L = fda_delta_g_L,
    organic_delta_g_L = organic_delta_g_L,
    temperature_min_C = temperature_min_C,
    temperature_max_C = temperature_max_C,
    max_cases = max_cases,
)
for case in cases
    case["base_temperature_values_C"] = copy(base_temperature)
    case["base_fda_doses_g_L"] = copy(base_fda)
    case["base_organic_doses_g_L"] = copy(base_organic)
end

config = (
    horizon_h = horizon_h,
    control_interval_h = control_interval_h,
    temperature_transition_width_h = temperature_transition_width_h,
    addition_transition_width_h = addition_transition_width_h,
    temperature_min_C = temperature_min_C,
    temperature_max_C = temperature_max_C,
    fda_total_limit_g_L = fda_total_limit_g_L,
)
params = default_zenteno_parameters(
    phase_proxy_mode = phase_proxy_mode,
    TURNOVER_THRESHOLD = turnover_threshold,
)
initial_state_config = _script_initial_state_config(params)

rows = Dict{String, Any}[]
_sens_phase("before_sensitivity_cases")
for (case_number, case) in enumerate(cases)
    println("dynamic_control_sensitivity_case_start: $(case["case_id"]) case_number=$(case_number) of $(length(cases))")
    flush(stdout)
    try
        schedule = _sens_schedule(case; config = config)
        simulation_kwargs = (
            y0 = initial_state_config.y0,
            tspan = (0.0, horizon_h),
            params = params,
            dynamic_control_schedule = schedule,
            saveat = saveat_h,
            reconstruct_fluxes = reconstruct_fluxes,
            lp_reuse = lp_reuse,
            lp_primal_start = lp_primal_start,
            lp_reuse_highs_solver = lp_reuse_highs_solver,
            lp_basis_warm_start = lp_basis_warm_start,
            lp_simplex_strategy = lp_simplex_strategy,
            allow_experimental_lp_reuse = allow_experimental_lp_reuse,
            algorithm = algorithm_config.algorithm,
            ode_abstol = tolerance_config.ode_abstol,
            ode_reltol = tolerance_config.ode_reltol,
            lp_atol = tolerance_config.lp_atol,
        )
        result = optimizer_backend === nothing ?
            simulate_reduced_dfba(model, reaction_map; simulation_kwargs...) :
            simulate_reduced_dfba(model, reaction_map; optimizer = optimizer_backend, simulation_kwargs...)
        result.metadata["solver_label"] = solver_label
        result.metadata["script_algorithm_label"] = algorithm_config.algorithm_label
        result.metadata["phase_proxy_mode"] = String(params.phase_proxy_mode)
        result.metadata["turnover_threshold"] = params.TURNOVER_THRESHOLD
        merge!(result.metadata, initial_state_config.metadata)
        push!(rows, _sens_case_row(case; result = result))
        println("dynamic_control_sensitivity_case_done: $(case["case_id"]) status=ok")
    catch err
        push!(rows, _sens_case_row(case; err = err))
        println("dynamic_control_sensitivity_case_done: $(case["case_id"]) status=failed error=$(sprint(showerror, err))")
    end
    partial_path = _sens_write_result_tables(output_dir, rows; suffix = "_partial")
    println("dynamic_control_sensitivity_partial_csv: $partial_path")
    flush(stdout)
end
result_path = _sens_write_result_tables(output_dir, rows)

_sens_phase("after_sensitivity_cases")
println("dynamic_control_sequential_sensitivity_done: true")
println("output_dir: $output_dir")
println("result_csv: $result_path")
println("case_count: $(length(cases))")
println("ok_case_count: $(count(row -> row["status"] == "ok", rows))")
println("failed_case_count: $(count(row -> row["status"] != "ok", rows))")
