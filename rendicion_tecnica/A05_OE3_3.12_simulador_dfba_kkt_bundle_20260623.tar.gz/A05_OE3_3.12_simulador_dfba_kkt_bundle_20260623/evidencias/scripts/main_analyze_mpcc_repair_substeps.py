#!/usr/bin/env python3
"""Analyze fixed-control MPCC repair substep traces.

This helper is intentionally dependency-free so it can run on the login node
against already-written CSV artifacts. It does not build or solve Julia models.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any


METRIC_COLUMNS = (
    "max_residual",
    "primal_structural_residual",
    "collocation_residual",
    "continuity_residual",
    "rhs_residual",
    "mass_balance_residual",
    "lower_bound_violation",
    "upper_bound_violation",
    "stationarity_residual",
    "lower_complementarity_residual",
    "upper_complementarity_residual",
)

OUTPUT_TRANSITION_COLUMNS = (
    "phase",
    "iteration",
    "trial_index",
    "accepted",
    "from_substep_index",
    "from_substep_label",
    "to_substep_index",
    "to_substep_label",
    "before_severity",
    "after_severity",
    "severity_delta",
    "dominant_after_metric",
    "dominant_after_value",
    "dominant_delta_metric",
    "dominant_metric_delta",
    "diagnostic_category",
    "recommendation",
)

OUTPUT_TRIAL_COLUMNS = (
    "phase",
    "iteration",
    "trial_index",
    "accepted",
    "substep_count",
    "first_substep_label",
    "last_substep_label",
    "first_severity",
    "last_severity",
    "net_severity_delta",
    "worst_substep_label",
    "worst_substep_severity",
    "largest_jump_to_label",
    "largest_jump_delta",
    "diagnostic_category",
    "recommendation",
)


def _float(value: Any, default: float = math.nan) -> float:
    try:
        text = str(value).strip()
    except Exception:
        return default
    if text == "" or text.lower() in {"missing", "nothing", "none", "nan"}:
        return default
    try:
        return float(text)
    except ValueError:
        return default


def _int(value: Any, default: int = 0) -> int:
    number = _float(value)
    if not math.isfinite(number):
        return default
    return int(number)


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def _finite(value: float) -> bool:
    return math.isfinite(value)


def _severity(row: dict[str, str]) -> float:
    structural = _float(row.get("primal_structural_residual"))
    if _finite(structural):
        return abs(structural)
    max_residual = _float(row.get("max_residual"))
    if _finite(max_residual):
        return abs(max_residual)
    values = [abs(_float(row.get(column))) for column in METRIC_COLUMNS]
    finite_values = [value for value in values if _finite(value)]
    return max(finite_values) if finite_values else math.nan


def _dominant_metric(row: dict[str, str]) -> tuple[str, float]:
    best_metric = ""
    best_value = math.nan
    for column in METRIC_COLUMNS:
        value = abs(_float(row.get(column)))
        if _finite(value) and (not _finite(best_value) or value > best_value):
            best_metric = column
            best_value = value
    return best_metric, best_value


def _dominant_delta(
    before: dict[str, str],
    after: dict[str, str],
) -> tuple[str, float]:
    best_metric = ""
    best_delta = math.nan
    for column in METRIC_COLUMNS:
        before_value = abs(_float(before.get(column)))
        after_value = abs(_float(after.get(column)))
        if not (_finite(before_value) and _finite(after_value)):
            continue
        delta = after_value - before_value
        if not _finite(best_delta) or delta > best_delta:
            best_metric = column
            best_delta = delta
    return best_metric, best_delta


def _category(label: str, metric: str) -> str:
    key = f"{label} {metric}".lower()
    if "lower_bound" in key or "upper_bound" in key or "mass_balance" in key:
        return "flux_bound_projection"
    if "dynamic_flux" in key or "flux_projection" in key or "mass_balanced" in key:
        return "flux_bound_projection"
    if "state_after_rhs" in key:
        return "state_after_rhs_refresh"
    if "rhs" in key:
        return "rhs_derivative_refresh"
    if "state_update" in key or "final_state" in key:
        return "state_refresh"
    if "stationarity" in key or "complementarity" in key or "dual" in key:
        return "kkt_dual_refresh"
    return "unclassified"


def _recommendation(category: str) -> str:
    if category == "state_refresh":
        return "Damp or segment terminal state refresh before adding more mesh or objective pressure."
    if category == "state_after_rhs_refresh":
        return "Guard or disable terminal state-after-RHS refresh; prioritize derivative-consistent terminal states."
    if category == "flux_bound_projection":
        return "Target terminal flux/bound projection, relaxed dynamic-bound handling, or flux LP refresh policy."
    if category == "rhs_derivative_refresh":
        return "Target terminal RHS derivative consistency before freeing controls."
    if category == "kkt_dual_refresh":
        return "Inspect dual/complementarity refresh; preserve primal start while fitting KKT multipliers."
    return "Inspect the substep trace manually; no dominant mechanism was classified."


def _read_rows(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        raise SystemExit(f"Substep trace CSV does not exist: {path}")
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        required = {"phase", "iteration", "trial_index", "substep_index", "substep_label"}
        missing = sorted(required - set(reader.fieldnames or []))
        if missing:
            raise SystemExit(
                "Substep trace CSV is missing required column(s): " + ", ".join(missing)
            )
        return rows


def _group_key(row: dict[str, str]) -> tuple[str, int, int]:
    return (
        str(row.get("phase", "")),
        _int(row.get("iteration")),
        _int(row.get("trial_index")),
    )


def _sorted_group(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    return sorted(rows, key=lambda row: _int(row.get("substep_index")))


def _transition_row(
    before: dict[str, str],
    after: dict[str, str],
) -> dict[str, Any]:
    before_severity = _severity(before)
    after_severity = _severity(after)
    dominant_after_metric, dominant_after_value = _dominant_metric(after)
    dominant_delta_metric, dominant_metric_delta = _dominant_delta(before, after)
    category = _category(str(after.get("substep_label", "")), dominant_delta_metric)
    return {
        "phase": after.get("phase", ""),
        "iteration": _int(after.get("iteration")),
        "trial_index": _int(after.get("trial_index")),
        "accepted": after.get("accepted", ""),
        "from_substep_index": _int(before.get("substep_index")),
        "from_substep_label": before.get("substep_label", ""),
        "to_substep_index": _int(after.get("substep_index")),
        "to_substep_label": after.get("substep_label", ""),
        "before_severity": before_severity,
        "after_severity": after_severity,
        "severity_delta": after_severity - before_severity
        if _finite(before_severity) and _finite(after_severity)
        else math.nan,
        "dominant_after_metric": dominant_after_metric,
        "dominant_after_value": dominant_after_value,
        "dominant_delta_metric": dominant_delta_metric,
        "dominant_metric_delta": dominant_metric_delta,
        "diagnostic_category": category,
        "recommendation": _recommendation(category),
    }


def _transition_sort_key(row: dict[str, Any]) -> tuple[float, int]:
    delta = _float(row.get("severity_delta"))
    metric_delta = _float(row.get("dominant_metric_delta"))
    score = max(
        delta if _finite(delta) else -math.inf,
        metric_delta if _finite(metric_delta) else -math.inf,
    )
    return (score, 1 if _truthy(row.get("accepted")) else 0)


def _write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: tuple[str, ...]) -> None:
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _json_safe(value: Any) -> Any:
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_safe(item) for item in value]
    return value


def analyze(rows: list[dict[str, str]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    groups: dict[tuple[str, int, int], list[dict[str, str]]] = {}
    for row in rows:
        groups.setdefault(_group_key(row), []).append(row)

    transition_rows: list[dict[str, Any]] = []
    trial_rows: list[dict[str, Any]] = []
    for key in sorted(groups):
        group = _sorted_group(groups[key])
        if not group:
            continue
        transitions = [
            _transition_row(before, after)
            for before, after in zip(group, group[1:])
        ]
        transition_rows.extend(transitions)
        first_row = group[0]
        last_row = group[-1]
        first_severity = _severity(first_row)
        last_severity = _severity(last_row)
        worst_row = max(group, key=_severity)
        worst_severity = _severity(worst_row)
        largest_jump = max(
            transitions,
            key=lambda row: _float(row.get("severity_delta"), -math.inf),
            default={},
        )
        category = str(largest_jump.get("diagnostic_category", "unclassified"))
        trial_rows.append(
            {
                "phase": first_row.get("phase", ""),
                "iteration": _int(first_row.get("iteration")),
                "trial_index": _int(first_row.get("trial_index")),
                "accepted": first_row.get("accepted", ""),
                "substep_count": len(group),
                "first_substep_label": first_row.get("substep_label", ""),
                "last_substep_label": last_row.get("substep_label", ""),
                "first_severity": first_severity,
                "last_severity": last_severity,
                "net_severity_delta": last_severity - first_severity
                if _finite(first_severity) and _finite(last_severity)
                else math.nan,
                "worst_substep_label": worst_row.get("substep_label", ""),
                "worst_substep_severity": worst_severity,
                "largest_jump_to_label": largest_jump.get("to_substep_label", ""),
                "largest_jump_delta": largest_jump.get("severity_delta", math.nan),
                "diagnostic_category": category,
                "recommendation": _recommendation(category),
            }
        )

    transition_rows.sort(key=_transition_sort_key, reverse=True)
    trial_rows.sort(
        key=lambda row: _float(row.get("largest_jump_delta"), -math.inf),
        reverse=True,
    )
    top_transition = transition_rows[0] if transition_rows else {}
    top_trial = trial_rows[0] if trial_rows else {}
    category = str(top_transition.get("diagnostic_category", "unclassified"))
    summary = {
        "substep_row_count": len(rows),
        "trial_count": len(groups),
        "transition_count": len(transition_rows),
        "top_transition": top_transition,
        "top_trial": top_trial,
        "dominant_diagnostic_category": category,
        "recommendation": _recommendation(category),
    }
    return transition_rows, trial_rows, summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--substeps-csv", required=True)
    parser.add_argument("--output-dir", default="")
    parser.add_argument("--prefix", default="repair_substep_analysis")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    substeps_csv = Path(args.substeps_csv).expanduser().resolve()
    output_dir = (
        Path(args.output_dir).expanduser().resolve()
        if args.output_dir
        else substeps_csv.parent
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    transition_csv = output_dir / f"{args.prefix}_transitions.csv"
    trial_csv = output_dir / f"{args.prefix}_trials.csv"
    summary_json = output_dir / f"{args.prefix}.json"
    summary_txt = output_dir / f"{args.prefix}.txt"
    if not args.overwrite:
        existing = [
            path
            for path in (transition_csv, trial_csv, summary_json, summary_txt)
            if path.exists()
        ]
        if existing:
            raise SystemExit(
                "Analysis output file(s) already exist: "
                + ", ".join(str(path) for path in existing)
            )

    rows = _read_rows(substeps_csv)
    transitions, trials, summary = analyze(rows)

    _write_csv(transition_csv, transitions, OUTPUT_TRANSITION_COLUMNS)
    _write_csv(trial_csv, trials, OUTPUT_TRIAL_COLUMNS)
    summary_json.write_text(json.dumps(_json_safe(summary), indent=2, sort_keys=True) + "\n")

    top = summary.get("top_transition", {})
    text_lines = [
        "MPCC repair substep analysis",
        f"substeps_csv: {substeps_csv}",
        f"transition_csv: {transition_csv}",
        f"trial_csv: {trial_csv}",
        f"summary_json: {summary_json}",
        f"substep_row_count: {summary['substep_row_count']}",
        f"trial_count: {summary['trial_count']}",
        f"transition_count: {summary['transition_count']}",
        f"dominant_diagnostic_category: {summary['dominant_diagnostic_category']}",
        f"recommendation: {summary['recommendation']}",
        "top_transition: "
        + (
            "none"
            if not top
            else (
                f"phase={top.get('phase')} trial={top.get('trial_index')} "
                f"to={top.get('to_substep_label')} "
                f"severity_delta={top.get('severity_delta')} "
                f"dominant_delta_metric={top.get('dominant_delta_metric')}"
            )
        ),
    ]
    summary_txt.write_text("\n".join(text_lines) + "\n")

    for line in text_lines:
        print(line)


if __name__ == "__main__":
    main()
