using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_SWEEP_PROFILE = "smoke"
const DEFAULT_MPCC_SWEEP_IPOPT_MAX_ITER = 100

function _mpcc_sweep_profile()
    raw = strip(get(ENV, "MPCC_SWEEP_PROFILE", DEFAULT_MPCC_SWEEP_PROFILE))
    normalized = lowercase(raw)
    normalized in ("smoke", "escalation", "custom") ||
        error("Environment variable MPCC_SWEEP_PROFILE must be one of: smoke, escalation, custom. Got: $raw")
    return normalized
end

function _mpcc_sweep_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (horizons = "0.25", nfe_values = "1", max_scenarios = 1)
    elseif profile == "escalation"
        return (horizons = "0.25,0.5", nfe_values = "1,2", max_scenarios = 4)
    else
        return (horizons = "0.25", nfe_values = "1", max_scenarios = 1)
    end
end

function _mpcc_sweep_env_float_list(name::AbstractString, default_value::AbstractString)::Vector{Float64}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && error("Environment variable $name contains a non-Float64 value: $stripped")
        isfinite(value) && value > 0.0 ||
            error("Environment variable $name values must be finite and positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_sweep_env_int_list(name::AbstractString, default_value::AbstractString)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Int, stripped)
        value === nothing && error("Environment variable $name contains a non-Int value: $stripped")
        value > 0 || error("Environment variable $name values must be positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_sweep_env_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_sweep_script_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_sweep_validate_grid!(
    horizons::Vector{Float64},
    nfe_values::Vector{Int},
    max_scenarios::Int,
    allow_large_grid::Bool,
)
    n_scenarios = length(horizons) * length(nfe_values)
    if n_scenarios > max_scenarios && !allow_large_grid
        error(
            "Requested MPCC sweep has $n_scenarios scenarios, above MPCC_SWEEP_MAX_SCENARIOS=$max_scenarios. " *
            "Set MPCC_SWEEP_ALLOW_LARGE_GRID=1 only for deliberate longer local diagnostics.",
        )
    end
    return nothing
end

profile = _mpcc_sweep_profile()
defaults = _mpcc_sweep_profile_defaults(profile)
horizons = _mpcc_sweep_env_float_list("MPCC_SWEEP_HORIZONS_HOURS", defaults.horizons)
nfe_values = _mpcc_sweep_env_int_list("MPCC_SWEEP_NFE_VALUES", defaults.nfe_values)
max_scenarios = _mpcc_sweep_env_int("MPCC_SWEEP_MAX_SCENARIOS", defaults.max_scenarios)
allow_large_grid = _script_env_bool("MPCC_SWEEP_ALLOW_LARGE_GRID", false)
continue_on_error = _script_env_bool("MPCC_SWEEP_CONTINUE_ON_ERROR", true)
require_pre_solve_ready = _script_env_bool("MPCC_SWEEP_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_SWEEP_SILENT", true)
ipopt_max_iter = _mpcc_sweep_env_int("MPCC_SWEEP_IPOPT_MAX_ITER", DEFAULT_MPCC_SWEEP_IPOPT_MAX_ITER)

_mpcc_sweep_validate_grid!(horizons, nfe_values, max_scenarios, allow_large_grid)

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

sweep = sweep_reduced_dcdfba_mpcc_solve_attempts(
    model,
    reaction_map;
    horizons = horizons,
    nfe_values = nfe_values,
    degree = 3,
    ipopt_max_iter = ipopt_max_iter,
    require_pre_solve_ready = require_pre_solve_ready,
    silent = silent,
    continue_on_error = continue_on_error,
)

println("Reduced MPCC solve-attempt horizon/nfe sweep")
println("profile: $profile")
println("horizons_hours: $(join(horizons, ","))")
println("nfe_values: $(join(nfe_values, ","))")
println("ipopt_max_iter: $ipopt_max_iter")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("outputs_written: $(sweep.metadata["outputs_written"])")
println("sweep_is_scientific_simulation: $(sweep.metadata["sweep_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(sweep.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(sweep.metadata["scientific_baseline"])")
println("first_mpcc_target: $(sweep.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(sweep.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(sweep.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(sweep.metadata["hsl_required"])")
println("ma57_required: $(sweep.metadata["ma57_required"])")
println("indices_reacciones_used: $(sweep.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(sweep.metadata["r0001_used_as_oxygen"])")
println("n_scenarios: $(sweep.metadata["n_scenarios"])")
println("n_completed_scenarios: $(sweep.metadata["n_completed_scenarios"])")
println("n_failed_scenarios: $(sweep.metadata["n_failed_scenarios"])")
println("residual_feasible_scenario_count: $(sweep.metadata["residual_feasible_scenario_count"])")
println("iteration_limit_residual_feasible_scenario_count: $(sweep.metadata["iteration_limit_residual_feasible_scenario_count"])")
println("trajectory_ready_scenario_count: $(sweep.metadata["trajectory_ready_scenario_count"])")
println("best_state_match_scenario_id: $(_mpcc_sweep_script_value(sweep.metadata["best_state_match_scenario_id"]))")
println("best_state_match_max_state_relative_rmse: $(_mpcc_sweep_script_value(sweep.metadata["best_state_match_max_state_relative_rmse"]))")

println("scenario_table:")
for row in eachrow(sweep.scenario_table)
    println(
        "  $(row["scenario_id"]) | status=$(_mpcc_sweep_script_value(row["scenario_status"])) | " *
        "horizon=$(_mpcc_sweep_script_value(row["horizon"])) | nfe=$(_mpcc_sweep_script_value(row["nfe"])) | " *
        "solver=$(_mpcc_sweep_script_value(row["solver_status"])) | primal=$(_mpcc_sweep_script_value(row["primal_status"])) | " *
        "solve_s=$(_mpcc_sweep_script_value(row["solve_elapsed_seconds"])) | " *
        "residual_feasible=$(_mpcc_sweep_script_value(row["candidate_residual_feasible"])) | " *
        "trajectory_ready=$(_mpcc_sweep_script_value(row["candidate_trajectory_ready"])) | " *
        "max_state_abs=$(_mpcc_sweep_script_value(row["max_state_abs_difference"])) | " *
        "max_state_rel_rmse=$(_mpcc_sweep_script_value(row["max_state_relative_rmse"])) | " *
        "max_rhs=$(_mpcc_sweep_script_value(row["max_rhs_residual"])) | " *
        "max_mass=$(_mpcc_sweep_script_value(row["max_mass_balance_residual"])) | " *
        "max_comp_l=$(_mpcc_sweep_script_value(row["max_lower_complementarity_residual"])) | " *
        "max_comp_u=$(_mpcc_sweep_script_value(row["max_upper_complementarity_residual"])) | " *
        "action=$(_mpcc_sweep_script_value(row["next_recommended_action"]))",
    )
end

println("interpretation_note: $(sweep.metadata["interpretation_note"])")
