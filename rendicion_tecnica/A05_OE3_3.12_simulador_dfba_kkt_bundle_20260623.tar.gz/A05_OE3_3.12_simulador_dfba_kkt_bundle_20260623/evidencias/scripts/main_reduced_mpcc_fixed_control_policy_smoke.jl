using CSV
using DataFrames
using Dates
using FermentationDFBA
using TOML

include(joinpath(@__DIR__, "solver_backend_helpers.jl"))
include(joinpath(@__DIR__, "ode_script_helpers.jl"))

const FIXED_CONTROL_SMOKE_SCRIPT = "main_reduced_mpcc_fixed_control_policy_smoke.jl"

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

function _fixed_control_env_bool(name::AbstractString, default::Bool)::Bool
    raw_value = lowercase(strip(get(ENV, String(name), string(default))))
    if raw_value in ("1", "true", "yes", "y", "on")
        return true
    elseif raw_value in ("0", "false", "no", "n", "off")
        return false
    end
    error("Environment variable $name must be boolean, got: $raw_value")
end

function _fixed_control_env_nonnegative_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value >= 0 || error("Environment variable $name must be nonnegative, got: $value")
    return value
end

function _fixed_control_env_positive_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _fixed_control_env_positive_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _fixed_control_env_nonnegative_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _fixed_control_env_path(name::AbstractString, default_relative::AbstractString)::String
    raw_value = strip(get(ENV, String(name), default_relative))
    isempty(raw_value) && error("Environment variable $name must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _fixed_control_parse_float_vector(raw_value)::Vector{Float64}
    raw_value isa Missing && return Float64[]
    values = Float64[]
    for token in split(replace(string(raw_value), ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Could not parse Float64 token '$cleaned' from '$raw_value'.")
        isfinite(value) || error("Non-finite Float64 token '$cleaned' from '$raw_value'.")
        push!(values, value)
    end
    return values
end

function _fixed_control_toml_normalize(value)
    if value isa Missing || value === nothing
        return "missing"
    elseif value isa Bool
        return value
    elseif value isa Integer
        return Int(value)
    elseif value isa Real
        return _fixed_control_toml_real(value)
    elseif value isa AbstractString
        return value
    elseif value isa AbstractVector || value isa Tuple
        return [_fixed_control_toml_normalize(item) for item in value]
    elseif value isa AbstractDict
        normalized = Dict{String, Any}()
        for key in sort!(collect(keys(value)); by = string)
            normalized[string(key)] = _fixed_control_toml_normalize(value[key])
        end
        return normalized
    end
    return string(value)
end

function _fixed_control_toml_real(value::Real)
    float_value = Float64(value)
    isfinite(float_value) && return float_value
    isnan(float_value) && return "NaN"
    float_value == Inf && return "Inf"
    float_value == -Inf && return "-Inf"
    return string(value)
end

function _fixed_control_required_columns(table::DataFrame)
    required = [
        :candidate_id,
        :temperature_values_C,
        :fda_doses_g_L,
        :organic_doses_g_L,
        :control_policy_ready,
    ]
    names_set = Set(Symbol.(names(table)))
    missing_columns = [String(column) for column in required if !(column in names_set)]
    isempty(missing_columns) || error(
        "Fixed-control policy selection CSV is missing column(s): " *
        join(missing_columns, ", "),
    )
    return nothing
end

function _fixed_control_bool(value)::Bool
    value isa Bool && return value
    value isa Missing && return false
    raw = lowercase(strip(string(value)))
    raw in ("1", "true", "yes", "y") && return true
    raw in ("0", "false", "no", "n") && return false
    return false
end

function _fixed_control_float(value)::Float64
    value isa Missing && return NaN
    parsed = tryparse(Float64, string(value))
    parsed === nothing && return NaN
    return parsed
end

function _fixed_control_int(value; default::Int = 0)::Int
    value isa Missing && return default
    parsed = tryparse(Int, string(value))
    parsed === nothing && return default
    return parsed
end

function _fixed_control_string_or_missing(value)
    value isa Missing && return missing
    value === nothing && return missing
    return string(value)
end

function _fixed_control_schedule_from_row(
    row::DataFrameRow;
    schedule_horizon_h::Real,
    control_interval_h::Real,
    temperature_width_h::Real,
    addition_width_h::Real,
)
    return reference_dynamic_control_schedule(
        horizon_h = schedule_horizon_h,
        control_interval_h = control_interval_h,
        temperature_values_C = _fixed_control_parse_float_vector(row.temperature_values_C),
        temperature_transition_width_h = temperature_width_h,
        fda_doses_g_L = _fixed_control_parse_float_vector(row.fda_doses_g_L),
        organic_doses_g_L = _fixed_control_parse_float_vector(row.organic_doses_g_L),
        addition_transition_width_h = addition_width_h,
    )
end

function _fixed_control_selected_policy(table::DataFrame, candidate_id::AbstractString)
    ready_table = table[_fixed_control_bool.(table.control_policy_ready), :]
    nrow(ready_table) > 0 || error("No control_policy_ready=true policies in selection CSV.")
    selected_id = strip(String(candidate_id))
    if isempty(selected_id)
        return ready_table[1, :]
    end
    matches = findall(==(selected_id), String.(ready_table.candidate_id))
    isempty(matches) && error(
        "Requested MPCC_FIXED_CONTROL_CANDIDATE_ID is not control_policy_ready=true: " *
        selected_id,
    )
    return ready_table[first(matches), :]
end

function _fixed_control_smoke_row(candidate_id::AbstractString, result)
    metadata = result.metadata
    return (
        candidate_id = String(candidate_id),
        smoke_status = "solver_called",
        solver_call_performed = Bool(get(metadata, "solver_call_performed", false)),
        solver_status = string(result.status),
        primal_status = string(result.primal_status),
        solver_name = result.solver_name,
        solver_result_count = _fixed_control_int(get(metadata, "solver_result_count", 0)),
        objective_value = Float64(result.objective_value),
        solve_elapsed_seconds = Float64(result.solve_elapsed_seconds),
        solver_reported_solve_time_seconds =
            _fixed_control_float(get(metadata, "solver_reported_solve_time_seconds", NaN)),
        max_mass_balance_residual = Float64(result.max_mass_balance_residual),
        max_lower_bound_violation = Float64(result.max_lower_bound_violation),
        max_upper_bound_violation = Float64(result.max_upper_bound_violation),
        max_stationarity_residual = Float64(result.max_stationarity_residual),
        max_lower_complementarity_residual =
            Float64(result.max_lower_complementarity_residual),
        max_upper_complementarity_residual =
            Float64(result.max_upper_complementarity_residual),
        max_complementarity_tau_violation =
            _fixed_control_float(get(metadata, "max_complementarity_tau_violation", NaN)),
        complementarity_tau_gate_pass =
            Bool(get(metadata, "complementarity_tau_gate_pass", false)),
        complementarity_mode = string(get(metadata, "complementarity_mode", "missing")),
        complementarity_tau = string(get(metadata, "complementarity_tau", "missing")),
        mpcc_fixed_control_replay_ready =
            Bool(get(metadata, "mpcc_fixed_control_replay_ready", false)),
        dynamic_control_schedule_enabled =
            Bool(get(metadata, "dynamic_control_schedule_enabled", false)),
        dynamic_control_fda_total_product_g_L =
            _fixed_control_float(get(metadata, "dynamic_control_fda_total_product_g_L", NaN)),
        dynamic_control_organic_total_product_g_L = _fixed_control_float(
            get(metadata, "dynamic_control_organic_total_product_g_L", NaN),
        ),
        rhs_residuals_included = Bool(get(metadata, "rhs_residuals_included", false)),
        dynamic_flux_bounds_applied =
            Bool(get(metadata, "dynamic_flux_bounds_applied", false)),
        sequential_initialization_built =
            Bool(get(metadata, "sequential_initialization_built", false)),
        sequential_initialization_time_points =
            _fixed_control_int(get(metadata, "sequential_initialization_time_points", 0)),
        sequential_initialization_time_end =
            _fixed_control_float(get(metadata, "sequential_initialization_time_end", NaN)),
        sequential_initialization_flux_reaction_count =
            _fixed_control_int(get(metadata, "sequential_initialization_flux_reaction_count", 0)),
        collocation_consistent_state_start_applied =
            Bool(get(metadata, "collocation_consistent_state_start_applied", false)),
        collocation_consistent_state_start_final_max_residual =
            _fixed_control_float(
                get(metadata, "collocation_consistent_state_start_final_max_residual", NaN),
            ),
        grid_tspan = string(get(metadata, "grid_tspan", "missing")),
        grid_nfe = _fixed_control_int(get(metadata, "grid_nfe", 0)),
        collocation_degree = _fixed_control_int(get(metadata, "collocation_degree", 0)),
        nlp_structure_total_variables =
            _fixed_control_int(get(metadata, "nlp_structure_total_variables", 0)),
        nlp_structure_total_constraints =
            _fixed_control_int(get(metadata, "nlp_structure_total_constraints", 0)),
        linear_solver = string(get(metadata, "linear_solver", "missing")),
        hsl_required = Bool(get(metadata, "hsl_required", false)),
        hsl_library_configured = Bool(get(metadata, "hsl_library_configured", false)),
        hsl_library_path =
            _fixed_control_string_or_missing(get(metadata, "hsl_library_path", missing)),
        ipopt_hessian_approximation =
            string(get(metadata, "ipopt_hessian_approximation", "missing")),
        smoke_result_is_scientific_simulation =
            Bool(get(metadata, "smoke_result_is_scientific_simulation", true)),
    )
end

policy_selection_csv = _fixed_control_env_path(
    "MPCC_FIXED_CONTROL_POLICY_SELECTION_CSV",
    joinpath("results", "dynamic_control_policy_selection_latest", "dynamic_control_policy_selection.csv"),
)
isfile(policy_selection_csv) || error("Policy selection CSV does not exist: $policy_selection_csv")

output_dir = _fixed_control_env_path(
    "MPCC_FIXED_CONTROL_OUTPUT_DIR",
    joinpath("results", "reduced_mpcc_fixed_control_policy_smoke_latest"),
)
overwrite = _fixed_control_env_bool("MPCC_FIXED_CONTROL_OVERWRITE", true)
candidate_id = strip(get(ENV, "MPCC_FIXED_CONTROL_CANDIDATE_ID", ""))
smoke_horizon_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_SMOKE_HOURS", 24.0)
nfe = _fixed_control_env_positive_int("MPCC_FIXED_CONTROL_NFE", 2)
degree = _fixed_control_env_positive_int("MPCC_FIXED_CONTROL_DEGREE", 3)
ipopt_max_iter = _fixed_control_env_nonnegative_int("MPCC_FIXED_CONTROL_MAX_ITER", 5)
schedule_horizon_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_SCHEDULE_HOURS", 168.0)
control_interval_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_INTERVAL_HOURS", 12.0)
temperature_width_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_TEMPERATURE_WIDTH_HOURS", 1.0)
addition_width_h = _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_ADDITION_WIDTH_HOURS", 0.5)
sequential_saveat_h =
    _fixed_control_env_positive_float("MPCC_FIXED_CONTROL_SEQUENTIAL_SAVEAT_HOURS", 0.25)
sequential_reconstruct_fluxes =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_SEQUENTIAL_RECONSTRUCT_FLUXES", true)
sequential_stop_on_sugar_depletion =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_SEQUENTIAL_STOP_ON_SUGAR_DEPLETION", false)
complementarity_mode = strip(get(ENV, "MPCC_FIXED_CONTROL_COMPLEMENTARITY_MODE", "scholtes"))
complementarity_tau =
    _fixed_control_env_nonnegative_float("MPCC_FIXED_CONTROL_COMPLEMENTARITY_TAU", 20.0)
collocation_consistent_state_starts =
    _fixed_control_env_bool("MPCC_FIXED_CONTROL_COLLOCATION_CONSISTENT_STATE_STARTS", true)
linear_solver = strip(get(ENV, "MPCC_FIXED_CONTROL_LINEAR_SOLVER", ipopt_linear_solver_from_env()))
silent = _fixed_control_env_bool("MPCC_FIXED_CONTROL_SILENT", false)

mkpath(output_dir)
smoke_path = joinpath(output_dir, "reduced_mpcc_fixed_control_policy_smoke.csv")
metadata_path = joinpath(output_dir, "reduced_mpcc_fixed_control_policy_smoke.toml")
if !overwrite
    existing_targets = [path for path in (smoke_path, metadata_path) if isfile(path)]
    isempty(existing_targets) || error(
        "Fixed-control smoke output file(s) already exist and overwrite=false: " *
        join(existing_targets, ", "),
    )
end

policy_table = DataFrame(CSV.File(policy_selection_csv))
_fixed_control_required_columns(policy_table)
selected_row = _fixed_control_selected_policy(policy_table, candidate_id)
selected_candidate_id = String(selected_row.candidate_id)
schedule = _fixed_control_schedule_from_row(
    selected_row;
    schedule_horizon_h = schedule_horizon_h,
    control_interval_h = control_interval_h,
    temperature_width_h = temperature_width_h,
    addition_width_h = addition_width_h,
)

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

params = default_zenteno_parameters()
initial_state_config = _script_initial_state_config(params)
algorithm_config = _script_ode_algorithm_config("MPCC_FIXED_CONTROL_SEQUENTIAL_ALGORITHM")
sequential_start_time = time()
sequential_result = simulate_reduced_dfba(
    model,
    reaction_map;
    y0 = initial_state_config.y0,
    tspan = (0.0, smoke_horizon_h),
    params = params,
    dynamic_control_schedule = schedule,
    silent = true,
    saveat = sequential_saveat_h,
    algorithm = algorithm_config.algorithm,
    reconstruct_fluxes = sequential_reconstruct_fluxes,
    stop_on_sugar_depletion = sequential_stop_on_sugar_depletion,
    model_scope = "reduced",
)
sequential_elapsed_seconds = time() - sequential_start_time
sequential_retcode = string(get(sequential_result.metadata, "retcode", missing))

result = solve_reduced_dcdfba_mpcc_smoke(
    model,
    reaction_map;
    tspan = (0.0, smoke_horizon_h),
    nfe = nfe,
    degree = degree,
    params = params,
    include_rhs = true,
    use_dynamic_bounds = true,
    dynamic_control_schedule = schedule,
    sequential_initialization = sequential_result,
    collocation_consistent_state_starts = collocation_consistent_state_starts,
    ipopt_max_iter = ipopt_max_iter,
    linear_solver = linear_solver,
    complementarity_mode = complementarity_mode,
    complementarity_tau = complementarity_tau,
    silent = silent,
)

smoke_table = DataFrame([_fixed_control_smoke_row(selected_candidate_id, result)])
CSV.write(smoke_path, smoke_table)

metadata = Dict{String, Any}(
    "script" => FIXED_CONTROL_SMOKE_SCRIPT,
    "created_at" => Dates.format(Dates.now(), dateformat"yyyy-mm-ddTHH:MM:SS"),
    "policy_selection_csv" => policy_selection_csv,
    "output_dir" => output_dir,
    "smoke_csv" => smoke_path,
    "metadata_toml" => metadata_path,
    "selected_candidate_id" => selected_candidate_id,
    "smoke_horizon_h" => smoke_horizon_h,
    "nfe" => nfe,
    "degree" => degree,
    "ipopt_max_iter" => ipopt_max_iter,
    "schedule_horizon_h" => schedule_horizon_h,
    "control_interval_h" => control_interval_h,
    "temperature_width_h" => temperature_width_h,
    "addition_width_h" => addition_width_h,
    "sequential_saveat_h" => sequential_saveat_h,
    "sequential_reconstruct_fluxes" => sequential_reconstruct_fluxes,
    "sequential_stop_on_sugar_depletion" => sequential_stop_on_sugar_depletion,
    "sequential_algorithm_label" => algorithm_config.algorithm_label,
    "sequential_elapsed_seconds" => sequential_elapsed_seconds,
    "sequential_time_points" => length(sequential_result.time),
    "sequential_time_start" => first(sequential_result.time),
    "sequential_time_end" => last(sequential_result.time),
    "sequential_retcode" => sequential_retcode,
    "sequential_metadata" => sequential_result.metadata,
    "initial_state_metadata" => initial_state_config.metadata,
    "complementarity_mode" => complementarity_mode,
    "complementarity_tau" => complementarity_tau,
    "collocation_consistent_state_starts" => collocation_consistent_state_starts,
    "linear_solver" => linear_solver,
    "silent" => silent,
    "solver_call_performed" => true,
    "smoke_result_is_scientific_simulation" => false,
    "solver_status" => string(result.status),
    "primal_status" => string(result.primal_status),
    "solver_name" => result.solver_name,
    "result_metadata" => result.metadata,
)
open(metadata_path, "w") do io
    TOML.print(io, _fixed_control_toml_normalize(metadata))
end

println("Reduced MPCC fixed-control policy smoke")
println("policy_selection_csv: $policy_selection_csv")
println("output_dir: $output_dir")
println("smoke_csv: $smoke_path")
println("metadata_toml: $metadata_path")
println("selected_candidate_id: $selected_candidate_id")
println("smoke_horizon_h: $smoke_horizon_h")
println("nfe: $nfe")
println("degree: $degree")
println("ipopt_max_iter: $ipopt_max_iter")
println("sequential_saveat_h: $sequential_saveat_h")
println("sequential_algorithm_label: $(algorithm_config.algorithm_label)")
println("sequential_reconstruct_fluxes: $sequential_reconstruct_fluxes")
println("sequential_stop_on_sugar_depletion: $sequential_stop_on_sugar_depletion")
println("sequential_elapsed_seconds: $sequential_elapsed_seconds")
println("sequential_time_points: $(length(sequential_result.time))")
println("sequential_time_end: $(last(sequential_result.time))")
println("sequential_retcode: $sequential_retcode")
println("complementarity_mode: $complementarity_mode")
println("complementarity_tau: $complementarity_tau")
println("collocation_consistent_state_starts: $collocation_consistent_state_starts")
println("linear_solver: $linear_solver")
println("silent: $silent")
println("solver_call_performed: true")
println("solver_status: $(result.status)")
println("primal_status: $(result.primal_status)")
println("solver_name: $(result.solver_name)")
println("objective_value: $(result.objective_value)")
println("solve_elapsed_seconds: $(result.solve_elapsed_seconds)")
println("max_mass_balance_residual: $(result.max_mass_balance_residual)")
println("max_lower_bound_violation: $(result.max_lower_bound_violation)")
println("max_upper_bound_violation: $(result.max_upper_bound_violation)")
println("max_stationarity_residual: $(result.max_stationarity_residual)")
println("max_lower_complementarity_residual: $(result.max_lower_complementarity_residual)")
println("max_upper_complementarity_residual: $(result.max_upper_complementarity_residual)")
