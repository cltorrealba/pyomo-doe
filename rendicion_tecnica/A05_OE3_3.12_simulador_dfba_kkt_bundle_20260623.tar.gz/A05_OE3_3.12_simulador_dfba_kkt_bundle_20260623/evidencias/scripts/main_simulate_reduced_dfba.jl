using FermentationDFBA

include(joinpath(@__DIR__, "solver_backend_helpers.jl"))
include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)
reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

tfinal = _script_env_float("DFBA_TFINAL_HOURS", 2.0)
saveat = _script_env_float("DFBA_SAVEAT_HOURS", 1.0)
reconstruct_fluxes = _script_env_bool("DFBA_RECONSTRUCT_FLUXES", true)
lp_reuse = _script_env_bool("DFBA_LP_REUSE", false)
lp_primal_start = _script_env_bool("DFBA_LP_PRIMAL_START", false)
lp_basis_warm_start = _script_env_bool("DFBA_LP_BASIS_WARM_START", false)
allow_experimental_lp_reuse = _script_env_bool("DFBA_ALLOW_EXPERIMENTAL_LP_REUSE", false)
lp_reuse_highs_solver = strip(get(ENV, "DFBA_LP_REUSE_HIGHS_SOLVER", "simplex"))
lp_simplex_strategy = strip(get(ENV, "DFBA_LP_SIMPLEX_STRATEGY", lp_basis_warm_start ? "primal" : "default"))
phase_proxy_mode = strip(get(ENV, "DFBA_PHASE_PROXY_MODE", "total_molecular_weight"))
turnover_threshold = _script_env_float("DFBA_TURNOVER_THRESHOLD", 0.001)
algorithm_config = _script_ode_algorithm_config("DFBA_ALGORITHM")
tolerance_config = _script_tolerance_config()
optimizer_backend, solver_label = _resolve_solver_backend(get(ENV, "DFBA_SOLVER_BACKEND", "HiGHS"))
if lp_reuse && solver_label != "HiGHS"
    error("DFBA_LP_REUSE currently supports HiGHS only; use DFBA_SOLVER_BACKEND=HiGHS.")
end
params = default_zenteno_parameters(
    phase_proxy_mode = phase_proxy_mode,
    TURNOVER_THRESHOLD = turnover_threshold,
)
initial_state_config = _script_initial_state_config(params)

simulation_kwargs = (
    y0 = initial_state_config.y0,
    tspan = (0.0, tfinal),
    params = params,
    saveat = saveat,
    reconstruct_fluxes = reconstruct_fluxes,
    lp_reuse = lp_reuse,
    lp_primal_start = lp_primal_start,
    lp_reuse_highs_solver = lp_reuse_highs_solver,
    lp_basis_warm_start = lp_basis_warm_start,
    lp_simplex_strategy = lp_simplex_strategy,
    allow_experimental_lp_reuse = allow_experimental_lp_reuse,
    algorithm = algorithm_config.algorithm,
    ode_abstol = tolerance_config.ode_abstol,
    ode_reltol = tolerance_config.ode_reltol,
    lp_atol = tolerance_config.lp_atol,
)

result = optimizer_backend === nothing ?
    simulate_reduced_dfba(model, reaction_map; simulation_kwargs...) :
    simulate_reduced_dfba(model, reaction_map; optimizer = optimizer_backend, simulation_kwargs...)
result.metadata["solver_label"] = solver_label
result.metadata["script_algorithm_label"] = algorithm_config.algorithm_label
result.metadata["phase_proxy_mode"] = String(params.phase_proxy_mode)
result.metadata["turnover_threshold"] = params.TURNOVER_THRESHOLD
merge!(result.metadata, initial_state_config.metadata)
summary = summarize_simulation(result)

println("Sequential reduced DFBA simulation report")
println("model_id: $(model.model_id)")
println("model_scope: $(summary["model_scope"])")
println("solver_label: $solver_label")
println("algorithm_label: $(algorithm_config.algorithm_label)")
println("phase_proxy_mode: $(params.phase_proxy_mode)")
println("turnover_threshold: $(params.TURNOVER_THRESHOLD)")
println("initial_condition_policy: $(result.metadata["initial_condition_policy"])")
println("initial_sugar_policy: $(result.metadata["initial_sugar_policy"])")
println("initial_glucose_g_L: $(result.metadata["initial_glucose_g_L"])")
println("initial_fructose_g_L: $(result.metadata["initial_fructose_g_L"])")
println("initial_total_sugar_g_L: $(result.metadata["initial_total_sugar_g_L"])")
println("initial_yan_policy: $(result.metadata["initial_yan_policy"])")
println("initial_yan_target_mgN_L: $(result.metadata["initial_yan_target_mgN_L"])")
println("initial_free_nitrogen_gN_L: $(result.metadata["initial_free_nitrogen_gN_L"])")
println("initial_amino_acid_nitrogen_equivalent_mgN_L: $(result.metadata["initial_amino_acid_nitrogen_equivalent_mgN_L"])")
println("initial_total_yan_equivalent_mgN_L: $(result.metadata["initial_total_yan_equivalent_mgN_L"])")
println("ode_abstol: $(tolerance_config.ode_abstol)")
println("ode_reltol: $(tolerance_config.ode_reltol)")
println("lp_atol: $(tolerance_config.lp_atol)")
println("smoke_tspan: $(summary["initial_time"]) to $(summary["final_time"]) h")
println("smoke_note: default horizon is 2 h; set DFBA_TFINAL_HOURS for longer manual runs.")
println("saved_time_points: $(summary["n_saved_points"])")
println("retcode: $(summary["retcode"])")
println("termination_reason: $(summary["termination_reason"])")
println("final_time: $(summary["final_time"])")
println("final_biomass: $(summary["final_biomass"])")
println("final_glucose: $(summary["final_glucose"])")
println("final_fructose: $(summary["final_fructose"])")
println("final_total_sugar: $(summary["final_total_sugar"])")
println("sugar_consumed: $(summary["sugar_consumed"])")
println("final_ethanol: $(summary["final_ethanol"])")
println("ethanol_produced: $(summary["ethanol_produced"])")
println("time_to_sugar_depletion: $(summary["time_to_sugar_depletion"])")
println("mode_counts: $(summary["mode_counts"])")
println("max_mass_balance_residual: $(summary["max_mass_balance_residual"])")
println("max_lower_bound_violation: $(summary["max_lower_bound_violation"])")
println("max_upper_bound_violation: $(summary["max_upper_bound_violation"])")
println("min_state_value: $(summary["min_state_value"])")
println("has_negative_saved_states: $(summary["has_negative_saved_states"])")
println("oxygen_derivative_policy: $(summary["oxygen_derivative_policy"])")
println("carbohydrate_derivative_policy: $(summary["carbohydrate_derivative_policy"])")
println("reconstruct_fluxes: $(summary["reconstruct_fluxes"])")
println("lp_reuse: $(summary["lp_reuse"])")
println("lp_primal_start: $(summary["lp_primal_start"])")
println("lp_basis_warm_start: $(summary["lp_basis_warm_start"])")
println("lp_reuse_highs_solver: $(summary["lp_reuse_highs_solver"])")
println("lp_simplex_strategy: $(summary["lp_simplex_strategy"])")
println("lp_reuse_strategy: $(summary["lp_reuse_strategy"])")
println("lp_warm_start_strategy: $(summary["lp_warm_start_strategy"])")
println("allow_experimental_lp_reuse: $(summary["allow_experimental_lp_reuse"])")
println("experimental_lp_reuse: $(summary["experimental_lp_reuse"])")
println("trajectory_equivalence_checked: $(summary["trajectory_equivalence_checked"])")
println("trajectory_equivalence_passed: $(summary["trajectory_equivalence_passed"])")
println("scientific_output_equivalent: $(summary["scientific_output_equivalent"])")
println("lp_reuse_validity_note: $(summary["lp_reuse_validity_note"])")
println("simulation_elapsed_seconds: $(summary["simulation_elapsed_seconds"])")
println("ode_solve_elapsed_seconds: $(summary["ode_solve_elapsed_seconds"])")
println("rhs_elapsed_seconds: $(summary["rhs_elapsed_seconds"])")
println("history_reconstruction_elapsed_seconds: $(summary["history_reconstruction_elapsed_seconds"])")
println("rhs_call_count: $(summary["rhs_call_count"])")
println("rhs_lp_solve_count: $(summary["rhs_lp_solve_count"])")
println("flux_reconstruction_solve_count: $(summary["flux_reconstruction_solve_count"])")
println("total_lp_solve_count: $(summary["total_lp_solve_count"])")
println("lp_reuse_build_elapsed_seconds: $(summary["lp_reuse_build_elapsed_seconds"])")
println("lp_reuse_update_elapsed_seconds: $(summary["lp_reuse_update_elapsed_seconds"])")
println("lp_reuse_solve_elapsed_seconds: $(summary["lp_reuse_solve_elapsed_seconds"])")
println("lp_reuse_warm_start_applied_count: $(summary["lp_reuse_warm_start_applied_count"])")
println("lp_reuse_basis_warm_start_applied_count: $(summary["lp_reuse_basis_warm_start_applied_count"])")
println("lp_reuse_basis_warm_start_failed_count: $(summary["lp_reuse_basis_warm_start_failed_count"])")
println("lp_reuse_basis_capture_count: $(summary["lp_reuse_basis_capture_count"])")
println("lp_reuse_simplex_iterations: $(summary["lp_reuse_simplex_iterations"])")
