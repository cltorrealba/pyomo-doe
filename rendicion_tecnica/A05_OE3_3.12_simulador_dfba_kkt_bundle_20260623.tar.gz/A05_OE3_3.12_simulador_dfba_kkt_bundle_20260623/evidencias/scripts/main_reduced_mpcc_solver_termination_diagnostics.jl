using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_SOLVER_TERM_PROFILE = "smoke"
const DEFAULT_MPCC_SOLVER_TERM_IPOPT_MAX_ITER = 100

function _mpcc_solver_term_profile()
    raw = strip(get(ENV, "MPCC_SOLVER_TERM_PROFILE", DEFAULT_MPCC_SOLVER_TERM_PROFILE))
    normalized = lowercase(raw)
    normalized in ("smoke", "focused", "8h", "72h", "custom") ||
        error(
            "Environment variable MPCC_SOLVER_TERM_PROFILE must be one of: " *
            "smoke, focused, 8h, 72h, custom. Got: $raw",
        )
    return normalized
end

function _mpcc_solver_term_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizon = "0.5",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 1,
            mass_threshold = "5e-6",
            retry_max_windows = 1,
            retry_max_iters = "200",
        )
    elseif profile == "focused"
        return (
            target_horizon = "2.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 4,
            mass_threshold = "5e-6",
            retry_max_windows = 2,
            retry_max_iters = "200,300",
        )
    elseif profile == "8h"
        return (
            target_horizon = "8.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 16,
            mass_threshold = "5e-6",
            retry_max_windows = 3,
            retry_max_iters = "200,300",
        )
    elseif profile == "72h"
        return (
            target_horizon = "72.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 144,
            mass_threshold = "5e-6",
            retry_max_windows = 4,
            retry_max_iters = "200,300",
        )
    else
        return (
            target_horizon = "8.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 16,
            mass_threshold = "5e-6",
            retry_max_windows = 3,
            retry_max_iters = "200,300",
        )
    end
end

function _mpcc_solver_term_env_positive_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_solver_term_env_positive_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_solver_term_env_nonnegative_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value >= 0 || error("Environment variable $name must be nonnegative, got: $value")
    return value
end

function _mpcc_solver_term_parse_int_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, ",")
        parsed = tryparse(Int, strip(token))
        parsed === nothing && error("Environment variable $name has invalid Int token: $token")
        parsed > 0 || error("Environment variable $name values must be positive, got: $parsed")
        push!(values, parsed)
    end
    length(unique(values)) == length(values) ||
        error("Environment variable $name values must be unique.")
    return values
end

function _mpcc_solver_term_n_windows(target_horizon::Float64, window_hours::Float64)::Int
    raw = target_horizon / window_hours
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || error(
        "MPCC_SOLVER_TERM_TARGET_HOURS=$target_horizon is not an integer " *
        "multiple of MPCC_SOLVER_TERM_WINDOW_HOURS=$window_hours.",
    )
    return n_windows
end

function _mpcc_solver_term_validate_grid!(
    n_windows::Int,
    max_windows::Int,
    allow_long::Bool,
)
    if n_windows > max_windows && !allow_long
        error(
            "Requested MPCC solver-termination diagnostic has $n_windows windows, above " *
            "MPCC_SOLVER_TERM_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_SOLVER_TERM_ALLOW_LONG=1 only for deliberate longer diagnostics.",
        )
    end
    return nothing
end

function _mpcc_solver_term_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_solver_term_progress_callback(progress::Bool)
    progress || return nothing
    return function (row, row_index, n_requested_windows)
        println(
            "progress_window: $row_index/$n_requested_windows | " *
            "id=$(_mpcc_solver_term_value(row["window_id"])) | " *
            "status=$(_mpcc_solver_term_value(row["window_status"])) | " *
            "tfinal=$(_mpcc_solver_term_value(row["tfinal"])) | " *
            "solver=$(_mpcc_solver_term_value(row["solver_status"])) | " *
            "trajectory_ready=$(_mpcc_solver_term_value(row["candidate_trajectory_ready"])) | " *
            "allows_continuation=$(_mpcc_solver_term_value(row["candidate_allows_continuation"]))",
        )
    end
end

function _mpcc_solver_term_print_termination_table(table; max_rows::Int = 8)
    println("termination_table:")
    for (index, row) in enumerate(eachrow(table))
        index > max_rows && break
        println(
            "  $(row["window_id"]) | phase=$(_mpcc_solver_term_value(row["phase"])) | " *
            "solver=$(_mpcc_solver_term_value(row["solver_status"])) | " *
            "ready=$(_mpcc_solver_term_value(row["trajectory_ready"])) | " *
            "residual_feasible=$(_mpcc_solver_term_value(row["residual_feasible"])) | " *
            "blocker=$(_mpcc_solver_term_value(row["termination_blocker"])) | " *
            "dominant=$(_mpcc_solver_term_value(row["dominant_residual"])) | " *
            "max_ratio=$(_mpcc_solver_term_value(row["max_residual_ratio"]))",
        )
    end
end

function _mpcc_solver_term_print_transition_table(table; max_rows::Int = 8)
    println("transition_table:")
    for (index, row) in enumerate(eachrow(table))
        index > max_rows && break
        println(
            "  $(row["window_id"]) | source_solver=$(_mpcc_solver_term_value(row["source_solver_status"])) | " *
            "best_retry=$(_mpcc_solver_term_value(row["best_retry_case_id"])) | " *
            "best_solver=$(_mpcc_solver_term_value(row["best_retry_solver_status"])) | " *
            "recovered_ready=$(_mpcc_solver_term_value(row["recovered_trajectory_ready"])) | " *
            "recovered_green=$(_mpcc_solver_term_value(row["recovered_green"])) | " *
            "ratio_delta=$(_mpcc_solver_term_value(row["residual_ratio_delta"])) | " *
            "action=$(_mpcc_solver_term_value(row["recommended_next_action"]))",
        )
    end
end

function _mpcc_solver_term_print_residual_gate_table(table; max_rows::Int = 12)
    println("residual_gate_table:")
    printed = 0
    for row in eachrow(table)
        row["is_dominant"] === true || continue
        printed += 1
        printed > max_rows && break
        println(
            "  $(row["window_id"]) | phase=$(_mpcc_solver_term_value(row["phase"])) | " *
            "residual=$(_mpcc_solver_term_value(row["residual_name"])) | " *
            "value=$(_mpcc_solver_term_value(row["value"])) | " *
            "threshold=$(_mpcc_solver_term_value(row["threshold"])) | " *
            "ratio=$(_mpcc_solver_term_value(row["ratio"])) | " *
            "pass=$(_mpcc_solver_term_value(row["within_threshold"]))",
        )
    end
end

profile = _mpcc_solver_term_profile()
defaults = _mpcc_solver_term_profile_defaults(profile)
target_horizon =
    _mpcc_solver_term_env_positive_float(
        "MPCC_SOLVER_TERM_TARGET_HOURS",
        defaults.target_horizon,
    )
window_hours =
    _mpcc_solver_term_env_positive_float(
        "MPCC_SOLVER_TERM_WINDOW_HOURS",
        defaults.window_hours,
    )
nfe_per_window =
    _mpcc_solver_term_env_positive_int(
        "MPCC_SOLVER_TERM_NFE",
        defaults.nfe_per_window,
    )
max_windows =
    _mpcc_solver_term_env_positive_int(
        "MPCC_SOLVER_TERM_MAX_WINDOWS",
        defaults.max_windows,
    )
mass_threshold =
    _mpcc_solver_term_env_positive_float(
        "MPCC_SOLVER_TERM_MASS_THRESHOLD",
        defaults.mass_threshold,
    )
retry_max_windows =
    _mpcc_solver_term_env_nonnegative_int(
        "MPCC_SOLVER_TERM_MAX_RETRY_WINDOWS",
        defaults.retry_max_windows,
    )
retry_max_iters =
    _mpcc_solver_term_parse_int_list(
        "MPCC_SOLVER_TERM_MAX_ITERS",
        defaults.retry_max_iters,
    )
selection_policy =
    strip(get(ENV, "MPCC_SOLVER_TERM_SELECTION_POLICY", "iteration_limit_or_not_ready"))
allow_long = _script_env_bool("MPCC_SOLVER_TERM_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_SOLVER_TERM_CONTINUE_ON_ERROR", true)
require_pre_solve_ready = _script_env_bool("MPCC_SOLVER_TERM_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_SOLVER_TERM_SILENT", true)
progress = _script_env_bool("MPCC_SOLVER_TERM_PROGRESS", profile in ("8h", "72h"))
ipopt_max_iter =
    _mpcc_solver_term_env_positive_int(
        "MPCC_SOLVER_TERM_IPOPT_MAX_ITER",
        DEFAULT_MPCC_SOLVER_TERM_IPOPT_MAX_ITER,
    )

n_windows = _mpcc_solver_term_n_windows(target_horizon, window_hours)
_mpcc_solver_term_validate_grid!(n_windows, max_windows, allow_long)

println("Reduced MPCC solver termination diagnostics")
println("profile: $profile")
println("target_horizon: $target_horizon")
println("window_hours: $window_hours")
println("n_windows: $n_windows")
println("nfe_per_window: $nfe_per_window")
println("mass_threshold: $mass_threshold")
println("source_ipopt_max_iter: $ipopt_max_iter")
println("retry_max_windows: $retry_max_windows")
println("retry_max_iters: $(join(retry_max_iters, ","))")
println("selection_policy: $selection_policy")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("progress: $progress")

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

base_residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds(
    max_rhs_residual = base_residual_thresholds.max_rhs_residual,
    max_mass_balance_residual = mass_threshold,
    max_lower_bound_violation = base_residual_thresholds.max_lower_bound_violation,
    max_upper_bound_violation = base_residual_thresholds.max_upper_bound_violation,
    max_stationarity_residual = base_residual_thresholds.max_stationarity_residual,
    max_lower_complementarity_residual =
        base_residual_thresholds.max_lower_complementarity_residual,
    max_upper_complementarity_residual =
        base_residual_thresholds.max_upper_complementarity_residual,
)
viability_thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
    residual_thresholds = residual_thresholds,
)

retry_aware = attempt_reduced_dcdfba_mpcc_windowed_simulation_with_retries(
    model,
    reaction_map;
    target_horizon = target_horizon,
    window_hours = window_hours,
    nfe_per_window = nfe_per_window,
    degree = 3,
    ipopt_max_iter = ipopt_max_iter,
    require_pre_solve_ready = require_pre_solve_ready,
    residual_thresholds = residual_thresholds,
    viability_thresholds = viability_thresholds,
    retry_selection_policy = selection_policy,
    retry_max_windows = retry_max_windows,
    retry_ipopt_max_iter_values = retry_max_iters,
    silent = silent,
    continue_on_error = continue_on_error,
    window_callback = _mpcc_solver_term_progress_callback(progress),
)

diagnostic = diagnose_reduced_dcdfba_mpcc_solver_termination(retry_aware)

println("outputs_written: $(diagnostic.metadata["outputs_written"])")
println("solver_termination_diagnostic_is_scientific_simulation: $(diagnostic.metadata["solver_termination_diagnostic_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(diagnostic.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(diagnostic.metadata["scientific_baseline"])")
println("first_mpcc_target: $(diagnostic.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(diagnostic.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(diagnostic.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(diagnostic.metadata["hsl_required"])")
println("ma57_required: $(diagnostic.metadata["ma57_required"])")
println("indices_reacciones_used: $(diagnostic.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(diagnostic.metadata["r0001_used_as_oxygen"])")
println("source_kind: $(diagnostic.metadata["source_kind"])")
println("n_windows_analyzed: $(diagnostic.metadata["n_windows_analyzed"])")
println("n_retry_rows_analyzed: $(diagnostic.metadata["n_retry_rows_analyzed"])")
println("iteration_limit_count: $(diagnostic.metadata["iteration_limit_count"])")
println("iteration_limit_residual_feasible_count: $(diagnostic.metadata["iteration_limit_residual_feasible_count"])")
println("residual_threshold_failure_count: $(diagnostic.metadata["residual_threshold_failure_count"])")
println("trajectory_ready_count: $(diagnostic.metadata["trajectory_ready_count"])")
println("retry_recovered_trajectory_ready_count: $(diagnostic.metadata["retry_recovered_trajectory_ready_count"])")
println("retry_recovered_green_count: $(diagnostic.metadata["retry_recovered_green_count"])")
println("dominant_termination_blocker: $(diagnostic.metadata["dominant_termination_blocker"])")
println("dominant_residual: $(diagnostic.metadata["dominant_residual"])")
println("first_blocked_window_id: $(_mpcc_solver_term_value(diagnostic.metadata["first_blocked_window_id"]))")
println("first_blocked_window_index: $(_mpcc_solver_term_value(diagnostic.metadata["first_blocked_window_index"]))")
println("recommended_next_action: $(diagnostic.metadata["recommended_next_action"])")

_mpcc_solver_term_print_termination_table(diagnostic.termination_table)
_mpcc_solver_term_print_transition_table(diagnostic.transition_table)
_mpcc_solver_term_print_residual_gate_table(diagnostic.residual_gate_table)

println("interpretation_note: $(diagnostic.metadata["interpretation_note"])")
