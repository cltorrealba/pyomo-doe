#!/usr/bin/env python3
"""Diagnose local leverage of the reduced MPCC dynamic-control objective."""

from __future__ import annotations

import argparse
import ast
import csv
import math
import re
from pathlib import Path


METADATA_KEYS = {
    "case_id",
    "selected_candidate_source",
    "selected_candidate_residual_feasible",
    "selected_candidate_trajectory_ready",
    "selected_candidate_terminal_state_values_available",
    "selected_candidate_terminal_glucose_g_L",
    "selected_candidate_terminal_fructose_g_L",
    "selected_candidate_terminal_total_sugar_g_L",
    "selected_candidate_terminal_isoamyl_alcohol_g_L",
    "post_solve_candidate_residual_feasible",
    "post_solve_candidate_rejection_reason",
    "base_objective_mode",
    "base_objective_description",
    "dynamic_control_objective_requested_target_state",
    "dynamic_control_objective_resolved_target_state",
    "dynamic_control_objective_target_state_alias_policy",
    "dynamic_control_objective_terminal_reward_weight",
    "dynamic_control_objective_terminal_state_scale_g_L",
    "dynamic_control_objective_terminal_sugar_weight",
    "dynamic_control_objective_terminal_sugar_scale_g_L",
    "dynamic_control_objective_integrated_sugar_weight",
    "dynamic_control_objective_integrated_sugar_scale_g_L",
    "dynamic_control_objective_integrated_sugar_config_policy",
    "dynamic_control_objective_integrated_sugar_max_g_L",
    "dynamic_control_objective_aroma_reward_policy",
    "dynamic_control_objective_terminal_reward_effective_weight",
    "dynamic_control_objective_integrated_aroma_reward_effective_weight",
    "dynamic_control_objective_integrated_aroma_reward_terms",
    "dynamic_control_objective_integrated_aroma_reward_policy",
    "dynamic_control_objective_terminal_sugar_terms",
    "dynamic_control_objective_integrated_sugar_terms",
    "dynamic_control_objective_integrated_sugar_policy",
    "dynamic_control_objective_integrated_sugar_slack_count",
    "dynamic_control_objective_integrated_sugar_constraint_count",
    "dynamic_control_objective_integrated_sugar_max_slack_start_g_L",
    "dynamic_control_objective_nutrient_weight",
    "dynamic_control_objective_fda_weight",
    "dynamic_control_objective_organic_weight",
    "dynamic_control_objective_nutrient_scale_g_L",
    "dynamic_control_objective_thermal_energy_weight",
    "dynamic_control_objective_ambient_temperature_C",
    "dynamic_control_objective_temperature_scale_C",
    "dynamic_control_objective_temperature_smoothness_weight",
    "dynamic_control_objective_temperature_smoothness_scale_C",
    "dynamic_control_objective_aroma_deficit_weight",
    "dynamic_control_objective_aroma_deficit_target_g_L",
    "dynamic_control_objective_aroma_deficit_scale_g_L",
    "dynamic_control_objective_aroma_deficit_terms",
    "dynamic_control_objective_aroma_deficit_constraint_built",
    "dynamic_control_objective_aroma_deficit_slack_start_g_L",
    "dynamic_control_objective_terminal_sugar_excess_weight",
    "dynamic_control_objective_terminal_sugar_max_g_L",
    "dynamic_control_objective_terminal_sugar_excess_scale_g_L",
    "dynamic_control_objective_terminal_sugar_excess_terms",
    "dynamic_control_objective_terminal_sugar_excess_constraint_built",
    "dynamic_control_objective_terminal_sugar_excess_slack_start_g_L",
    "dynamic_control_objective_component_values_available",
    "dynamic_control_objective_base_value_estimate",
    "dynamic_control_objective_terminal_reward_value_estimate",
    "dynamic_control_objective_terminal_sugar_value_estimate",
    "dynamic_control_objective_integrated_sugar_value_estimate",
    "dynamic_control_objective_aroma_deficit_slack_value_g_L",
    "dynamic_control_objective_final_target_state_value_g_L",
    "dynamic_control_objective_aroma_deficit_required_g_L",
    "dynamic_control_objective_aroma_deficit_slack_minus_required_g_L",
    "dynamic_control_objective_aroma_deficit_constraint_violation_g_L",
    "dynamic_control_objective_aroma_deficit_value_estimate",
    "dynamic_control_objective_terminal_sugar_excess_slack_value_g_L",
    "dynamic_control_objective_final_total_sugar_value_g_L",
    "dynamic_control_objective_terminal_sugar_excess_required_g_L",
    "dynamic_control_objective_terminal_sugar_excess_slack_minus_required_g_L",
    "dynamic_control_objective_terminal_sugar_excess_constraint_violation_g_L",
    "dynamic_control_objective_terminal_sugar_excess_value_estimate",
    "dynamic_control_objective_nutrient_value_estimate",
    "dynamic_control_objective_thermal_energy_value_estimate",
    "dynamic_control_objective_temperature_smoothness_value_estimate",
    "dynamic_control_objective_dynamic_value_estimate",
    "dynamic_control_objective_reconstructed_total_value_estimate",
    "dynamic_control_reference_regularization_weight",
    "post_solve_candidate_dynamic_control_delta_vs_pre_solve_available",
    "post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve",
    "post_solve_candidate_dynamic_control_fda_g_L_sum_delta_vs_pre_solve",
    "post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve",
}


def _literal_value(raw: str):
    text = raw.strip()
    if text.startswith('"') and text.endswith('"'):
        return text[1:-1]
    if text in {"true", "false"}:
        return text == "true"
    if text == "missing":
        return ""
    if text == "NaN":
        return math.nan
    if text in {"Inf", "+Inf"}:
        return math.inf
    if text == "-Inf":
        return -math.inf
    try:
        return ast.literal_eval(text)
    except (SyntaxError, ValueError):
        try:
            return float(text)
        except ValueError:
            return text


def read_metadata(path: Path) -> dict[str, object]:
    values: dict[str, object] = {}
    current_table = ""
    assignment = re.compile(r"^([A-Za-z0-9_]+)\s*=\s*(.*)$")
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("["):
            current_table = stripped.strip("[]")
            continue
        if current_table not in {"", "candidate_metadata", "result_metadata"}:
            continue
        match = assignment.match(stripped)
        if match and match.group(1) in METADATA_KEYS:
            values[match.group(1)] = _literal_value(match.group(2))
    return values


def read_spec(path: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            parsed: dict[str, object] = dict(row)
            parsed["slot_index"] = int(float(row["slot_index"]))
            for key in ("time_h", "start_value", "lower_bound", "upper_bound", "trust_region"):
                parsed[key] = float(row[key])
            parsed["free"] = str(row.get("free", "")).lower() == "true"
            rows.append(parsed)
    return rows


def _float(metadata: dict[str, object], key: str, default: float) -> float:
    value = metadata.get(key, default)
    try:
        out = float(value)
    except (TypeError, ValueError):
        return default
    return out if math.isfinite(out) else default


def _family_rows(rows: list[dict[str, object]], family: str) -> list[dict[str, object]]:
    return [row for row in rows if row["family"] == family]


def _smoothness_gradient(temperatures: list[float], weight: float, scale: float) -> list[float]:
    count = len(temperatures)
    if count <= 1 or weight == 0.0:
        return [0.0 for _ in temperatures]
    coefficient = weight / (count - 1) / (scale * scale)
    gradients = [0.0 for _ in temperatures]
    for index in range(1, count):
        diff = temperatures[index] - temperatures[index - 1]
        gradients[index] += 2.0 * coefficient * diff
        gradients[index - 1] -= 2.0 * coefficient * diff
    return gradients


def build_diagnostics(case_dir: Path) -> tuple[list[dict[str, object]], list[str]]:
    metadata_path = case_dir / "reduced_mpcc_fixed_control_policy_solve_attempt.toml"
    spec_path = case_dir / "reduced_mpcc_dynamic_control_decision_spec.csv"
    metadata = read_metadata(metadata_path)
    rows = read_spec(spec_path)

    terminal_weight = _float(
        metadata,
        "dynamic_control_objective_terminal_reward_effective_weight",
        _float(metadata, "dynamic_control_objective_terminal_reward_weight", 1.0),
    )
    terminal_scale = _float(metadata, "dynamic_control_objective_terminal_state_scale_g_L", 0.1)
    terminal_coefficient = terminal_weight / terminal_scale
    integrated_sugar_weight = _float(
        metadata,
        "dynamic_control_objective_integrated_sugar_weight",
        0.0,
    )
    integrated_sugar_scale = _float(
        metadata,
        "dynamic_control_objective_integrated_sugar_scale_g_L",
        100.0,
    )
    integrated_sugar_policy = metadata.get(
        "dynamic_control_objective_integrated_sugar_policy",
        "",
    )
    integrated_sugar_max = _float(
        metadata,
        "dynamic_control_objective_integrated_sugar_max_g_L",
        5.0,
    )
    integrated_sugar_coefficient = integrated_sugar_weight / (
        integrated_sugar_scale * integrated_sugar_scale
    )
    nutrient_weight = _float(metadata, "dynamic_control_objective_nutrient_weight", 0.2)
    fda_weight = _float(metadata, "dynamic_control_objective_fda_weight", 1.0)
    organic_weight = _float(metadata, "dynamic_control_objective_organic_weight", 1.0)
    nutrient_scale = _float(metadata, "dynamic_control_objective_nutrient_scale_g_L", 1.0)
    thermal_weight = _float(metadata, "dynamic_control_objective_thermal_energy_weight", 0.05)
    ambient = _float(metadata, "dynamic_control_objective_ambient_temperature_C", 20.0)
    temperature_scale = _float(metadata, "dynamic_control_objective_temperature_scale_C", 10.0)
    smoothness_weight = _float(
        metadata,
        "dynamic_control_objective_temperature_smoothness_weight",
        0.05,
    )
    smoothness_scale = _float(
        metadata,
        "dynamic_control_objective_temperature_smoothness_scale_C",
        5.0,
    )
    aroma_deficit_weight = _float(
        metadata,
        "dynamic_control_objective_aroma_deficit_weight",
        0.0,
    )
    aroma_deficit_scale = _float(
        metadata,
        "dynamic_control_objective_aroma_deficit_scale_g_L",
        1.0e-4,
    )
    terminal_sugar_excess_weight = _float(
        metadata,
        "dynamic_control_objective_terminal_sugar_excess_weight",
        0.0,
    )
    terminal_sugar_excess_scale = _float(
        metadata,
        "dynamic_control_objective_terminal_sugar_excess_scale_g_L",
        5.0,
    )
    reference_weight = _float(metadata, "dynamic_control_reference_regularization_weight", 0.0)

    diagnostics: list[dict[str, object]] = []
    for key in sorted(METADATA_KEYS):
        if key in metadata:
            diagnostics.append(
                {
                    "section": "metadata",
                    "metric": key,
                    "family": "",
                    "slot_index": "",
                    "time_h": "",
                    "value": metadata[key],
                    "unit": "",
                    "note": "",
                }
            )

    diagnostics.append(
        {
            "section": "objective_scale",
            "metric": "terminal_reward_coefficient",
            "family": "target_state",
            "slot_index": "",
            "time_h": "",
            "value": terminal_coefficient,
            "unit": "objective_per_g_L_target",
            "note": "coefficient on -terminal target state",
        }
    )
    diagnostics.append(
        {
            "section": "objective_scale",
            "metric": "integrated_sugar_or_excess_quadratic_coefficient",
            "family": "sugar",
            "slot_index": "",
            "time_h": "",
            "value": integrated_sugar_coefficient,
            "unit": "objective_per_g_L_squared",
            "note": "coefficient on time-averaged sugar or sugar-excess slack, depending on policy",
        }
    )
    diagnostics.append(
        {
            "section": "objective_scale",
            "metric": "aroma_deficit_quadratic_coefficient",
            "family": "target_state",
            "slot_index": "",
            "time_h": "",
            "value": aroma_deficit_weight / (aroma_deficit_scale * aroma_deficit_scale),
            "unit": "objective_per_g_L_deficit_squared",
            "note": "coefficient on squared positive deficit to provisional target",
        }
    )
    diagnostics.append(
        {
            "section": "objective_scale",
            "metric": "terminal_sugar_excess_quadratic_coefficient",
            "family": "total_sugar",
            "slot_index": "",
            "time_h": "",
            "value": terminal_sugar_excess_weight
            / (terminal_sugar_excess_scale * terminal_sugar_excess_scale),
            "unit": "objective_per_g_L_excess_squared",
            "note": "coefficient on squared terminal sugar slack",
        }
    )

    for family in ("temperature", "fda", "organic"):
        family_rows = _family_rows(rows, family)
        if not family_rows:
            continue
        starts = [float(row["start_value"]) for row in family_rows]
        lows = [float(row["lower_bound"]) for row in family_rows]
        highs = [float(row["upper_bound"]) for row in family_rows]
        trusts = [float(row["trust_region"]) for row in family_rows]
        at_lower = sum(abs(start - low) <= 1.0e-12 for start, low in zip(starts, lows))
        at_upper = sum(abs(start - high) <= 1.0e-12 for start, high in zip(starts, highs))
        diagnostics.extend(
            [
                {
                    "section": "control_grid",
                    "metric": "slot_count",
                    "family": family,
                    "slot_index": "",
                    "time_h": "",
                    "value": len(family_rows),
                    "unit": "count",
                    "note": "",
                },
                {
                    "section": "control_grid",
                    "metric": "start_sum",
                    "family": family,
                    "slot_index": "",
                    "time_h": "",
                    "value": sum(starts),
                    "unit": family_rows[0]["unit"],
                    "note": "",
                },
                {
                    "section": "control_grid",
                    "metric": "start_at_lower_bound_count",
                    "family": family,
                    "slot_index": "",
                    "time_h": "",
                    "value": at_lower,
                    "unit": "count",
                    "note": "",
                },
                {
                    "section": "control_grid",
                    "metric": "start_at_upper_bound_count",
                    "family": family,
                    "slot_index": "",
                    "time_h": "",
                    "value": at_upper,
                    "unit": "count",
                    "note": "",
                },
                {
                    "section": "control_grid",
                    "metric": "trust_region_mean",
                    "family": family,
                    "slot_index": "",
                    "time_h": "",
                    "value": sum(trusts) / len(trusts),
                    "unit": family_rows[0]["unit"],
                    "note": "",
                },
            ]
        )

    temperatures = [float(row["start_value"]) for row in _family_rows(rows, "temperature")]
    smoothness_gradients = _smoothness_gradient(temperatures, smoothness_weight, smoothness_scale)
    temperature_count = max(1, len(temperatures))

    for row in rows:
        family = str(row["family"])
        start = float(row["start_value"])
        trust = float(row["trust_region"])
        slot_index = int(row["slot_index"])
        time_h = float(row["time_h"])
        objective_gradient = 0.0
        full_trust_direct_cost = 0.0
        note = ""
        if family == "temperature":
            thermal_gradient = (
                2.0
                * thermal_weight
                * (start - ambient)
                / temperature_count
                / (temperature_scale * temperature_scale)
            )
            smoothness_gradient = smoothness_gradients[slot_index - 1]
            objective_gradient = thermal_gradient + smoothness_gradient
            shifted = start + trust
            thermal_delta = thermal_weight / temperature_count * (
                ((shifted - ambient) / temperature_scale) ** 2
                - ((start - ambient) / temperature_scale) ** 2
            )
            full_trust_direct_cost = thermal_delta + reference_weight
            note = "terminal reward sensitivity is not included in local direct cost"
        elif family == "fda":
            objective_gradient = nutrient_weight * fda_weight / nutrient_scale
            full_trust_direct_cost = objective_gradient * trust + reference_weight
            note = "nutrient penalty is one-sided at zero starts because lower bound is active"
        elif family == "organic":
            objective_gradient = nutrient_weight * organic_weight / nutrient_scale
            full_trust_direct_cost = objective_gradient * trust + reference_weight
            note = "nutrient penalty plus reference regularization at full trust"
        required_target_gain = (
            full_trust_direct_cost / terminal_coefficient
            if terminal_coefficient > 0.0
            else math.nan
        )
        diagnostics.extend(
            [
                {
                    "section": "local_objective",
                    "metric": "direct_gradient_at_reference",
                    "family": family,
                    "slot_index": slot_index,
                    "time_h": time_h,
                    "value": objective_gradient,
                    "unit": "objective_per_control_unit",
                    "note": note,
                },
                {
                    "section": "local_objective",
                    "metric": "direct_cost_at_positive_full_trust",
                    "family": family,
                    "slot_index": slot_index,
                    "time_h": time_h,
                    "value": full_trust_direct_cost,
                    "unit": "objective",
                    "note": "includes reference regularization cost at one trust-region unit",
                },
                {
                    "section": "local_objective",
                    "metric": "target_gain_needed_to_offset_full_trust",
                    "family": family,
                    "slot_index": slot_index,
                    "time_h": time_h,
                    "value": required_target_gain,
                    "unit": "g_L_target_state",
                    "note": "minimum final target-state increase needed to pay direct costs",
                },
            ]
        )

    notes: list[str] = []
    alias_policy = str(metadata.get("dynamic_control_objective_target_state_alias_policy", ""))
    reward_policy = str(metadata.get("dynamic_control_objective_aroma_reward_policy", ""))
    if reward_policy == "terminal_plus_integrated_flux":
        integrated_weight = _float(
            metadata,
            "dynamic_control_objective_integrated_aroma_reward_effective_weight",
            0.0,
        )
        notes.append(
            "Integrated gross aroma-production reward is active with effective "
            f"weight {integrated_weight}."
        )
    if integrated_sugar_weight > 0.0:
        notes.append(
            "Integrated sugar-progress penalty is active with weight "
            f"{integrated_sugar_weight}, scale {integrated_sugar_scale} g/L, "
            f"policy {integrated_sugar_policy}, and dry threshold "
            f"{integrated_sugar_max} g/L."
        )
    if aroma_deficit_weight > 0.0:
        notes.append(
            "Aroma deficit slack is active with target "
            f"{metadata.get('dynamic_control_objective_aroma_deficit_target_g_L', 'missing')} g/L "
            f"and scale {aroma_deficit_scale} g/L."
        )
    if terminal_sugar_excess_weight > 0.0:
        notes.append(
            "Terminal sugar excess slack is active with max "
            f"{metadata.get('dynamic_control_objective_terminal_sugar_max_g_L', 'missing')} g/L "
            f"and scale {terminal_sugar_excess_scale} g/L."
        )
    if alias_policy == "available_reduced_aroma_linear_blend":
        notes.append("White-wine aroma blend target is active over available reduced aroma states.")
    elif alias_policy and alias_policy != "exact_state_name":
        resolved_target = metadata.get("dynamic_control_objective_resolved_target_state", "unknown")
        requested_target = metadata.get(
            "dynamic_control_objective_requested_target_state",
            "requested target",
        )
        notes.append(
            "Target alias is active: "
            f"{requested_target} is optimized through {resolved_target}."
        )
    fda_rows = _family_rows(rows, "fda")
    if fda_rows and all(abs(float(row["start_value"]) - float(row["lower_bound"])) < 1.0e-12 for row in fda_rows):
        notes.append("All FDA starts are at their lower bound, so added FDA must overcome a bound-active nutrient penalty.")
    if metadata.get("post_solve_candidate_dynamic_control_delta_vs_pre_solve_available") is True:
        temp_move = _float(
            metadata,
            "post_solve_candidate_dynamic_control_temperature_C_max_abs_delta_vs_pre_solve",
            0.0,
        )
        organic_move = abs(
            _float(
                metadata,
                "post_solve_candidate_dynamic_control_organic_g_L_sum_delta_vs_pre_solve",
                0.0,
            )
        )
        accepted = metadata.get("post_solve_candidate_residual_feasible") is True
        candidate_label = "Accepted" if accepted else "Rejected"
        notes.append(
            f"{candidate_label} post-solve control movement is tiny: "
            f"max temperature {temp_move:.6g} C and organic sum {organic_move:.6g} g/L."
        )
    return diagnostics, notes


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["section", "metric", "family", "slot_index", "time_h", "value", "unit", "note"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path: Path, rows: list[dict[str, object]], notes: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    terminal = [row for row in rows if row["metric"] == "terminal_reward_coefficient"]
    integrated_sugar = [
        row
        for row in rows
        if row["metric"] == "integrated_sugar_or_excess_quadratic_coefficient"
    ]
    aroma_deficit = [
        row for row in rows if row["metric"] == "aroma_deficit_quadratic_coefficient"
    ]
    sugar_excess = [
        row for row in rows if row["metric"] == "terminal_sugar_excess_quadratic_coefficient"
    ]
    target_offsets = [
        row for row in rows if row["metric"] == "target_gain_needed_to_offset_full_trust"
    ]
    representative: dict[str, object] = {}
    for family in ("temperature", "fda", "organic"):
        for row in target_offsets:
            if row["family"] == family:
                representative[family] = row["value"]
                break
    lines = [
        "# Dynamic-control objective leverage diagnostic",
        "",
        f"- effective terminal reward coefficient: {terminal[0]['value'] if terminal else 'missing'} objective/(g/L target)",
    ]
    if integrated_sugar:
        lines.append(
            "- integrated sugar or excess-slack quadratic coefficient: "
            f"{integrated_sugar[0]['value']} objective/(g/L)^2"
        )
    if aroma_deficit:
        lines.append(
            "- aroma deficit quadratic coefficient: "
            f"{aroma_deficit[0]['value']} objective/(g/L deficit)^2"
        )
    if sugar_excess:
        lines.append(
            "- terminal sugar excess quadratic coefficient: "
            f"{sugar_excess[0]['value']} objective/(g/L excess)^2"
        )
    for family, value in representative.items():
        lines.append(
            f"- representative {family} full-trust target gain needed: {value} g/L target"
        )
    for note in notes:
        lines.append(f"- {note}")
    lines.append("")
    lines.append("Detailed diagnostics are in the sibling CSV.")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case_dir", type=Path)
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=None,
        help="Defaults to case_dir/objective_diagnostics.",
    )
    args = parser.parse_args()

    case_dir = args.case_dir.resolve()
    out_dir = (args.out_dir or (case_dir / "objective_diagnostics")).resolve()
    rows, notes = build_diagnostics(case_dir)
    csv_path = out_dir / "dynamic_control_objective_leverage_diagnostics.csv"
    md_path = out_dir / "dynamic_control_objective_leverage_diagnostics.md"
    write_csv(csv_path, rows)
    write_markdown(md_path, rows, notes)
    print(f"diagnostic_csv={csv_path}")
    print(f"diagnostic_md={md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
