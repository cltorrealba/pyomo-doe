using FermentationDFBA

include("ode_script_helpers.jl")

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_RHS_ENV = "MPCC_RESIDUAL_MAX_RHS"
const MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_MASS_ENV = "MPCC_RESIDUAL_MAX_MASS"
const MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_BOUND_ENV = "MPCC_RESIDUAL_MAX_BOUND"
const MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_LOWER_BOUND_ENV =
    "MPCC_RESIDUAL_MAX_LOWER_BOUND"
const MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_UPPER_BOUND_ENV =
    "MPCC_RESIDUAL_MAX_UPPER_BOUND"
const MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_STATIONARITY_ENV =
    "MPCC_RESIDUAL_MAX_STATIONARITY"
const MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_COMPLEMENTARITY_ENV =
    "MPCC_RESIDUAL_MAX_COMPLEMENTARITY"
const MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_LOWER_COMPLEMENTARITY_ENV =
    "MPCC_RESIDUAL_MAX_LOWER_COMPLEMENTARITY"
const MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_UPPER_COMPLEMENTARITY_ENV =
    "MPCC_RESIDUAL_MAX_UPPER_COMPLEMENTARITY"

function _selective_refinement_env_int(name::AbstractString, default::Int)::Int
    raw_value = strip(get(ENV, String(name), string(default)))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $raw_value")
    return value
end

function _selective_refinement_env_optional_int(name::AbstractString)
    raw_value = strip(get(ENV, String(name), ""))
    isempty(raw_value) && return nothing
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $raw_value")
    return value
end

function _selective_refinement_env_window_ids(name::AbstractString)::Vector{String}
    raw_value = strip(get(ENV, String(name), ""))
    isempty(raw_value) && return String[]
    return [strip(item) for item in split(raw_value, ",") if !isempty(strip(item))]
end

function _selective_refinement_env_optional_nonnegative_float(
    name::AbstractString,
    default_value::Real,
)::Float64
    raw = get(ENV, String(name), nothing)
    raw === nothing && return Float64(default_value)
    stripped = strip(raw)
    isempty(stripped) && return Float64(default_value)
    value = tryparse(Float64, stripped)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $value")
    return value
end

function _selective_refinement_residual_thresholds_from_env()
    defaults = default_reduced_dcdfba_mpcc_residual_thresholds()
    max_bound = _selective_refinement_env_optional_nonnegative_float(
        MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_BOUND_ENV,
        defaults.max_lower_bound_violation,
    )
    max_complementarity = _selective_refinement_env_optional_nonnegative_float(
        MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_COMPLEMENTARITY_ENV,
        defaults.max_lower_complementarity_residual,
    )
    return default_reduced_dcdfba_mpcc_residual_thresholds(
        max_rhs_residual = _selective_refinement_env_optional_nonnegative_float(
            MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_RHS_ENV,
            defaults.max_rhs_residual,
        ),
        max_mass_balance_residual = _selective_refinement_env_optional_nonnegative_float(
            MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_MASS_ENV,
            defaults.max_mass_balance_residual,
        ),
        max_lower_bound_violation = _selective_refinement_env_optional_nonnegative_float(
            MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_LOWER_BOUND_ENV,
            max_bound,
        ),
        max_upper_bound_violation = _selective_refinement_env_optional_nonnegative_float(
            MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_UPPER_BOUND_ENV,
            max_bound,
        ),
        max_stationarity_residual = _selective_refinement_env_optional_nonnegative_float(
            MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_STATIONARITY_ENV,
            defaults.max_stationarity_residual,
        ),
        max_lower_complementarity_residual =
            _selective_refinement_env_optional_nonnegative_float(
                MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_LOWER_COMPLEMENTARITY_ENV,
                max_complementarity,
            ),
        max_upper_complementarity_residual =
            _selective_refinement_env_optional_nonnegative_float(
                MPCC_SELECTIVE_REFINEMENT_RESIDUAL_MAX_UPPER_COMPLEMENTARITY_ENV,
                max_complementarity,
            ),
    )
end

function _selective_refinement_progress_line(row, row_index::Int, n_requested::Int)
    value(name) = row isa Dict ? get(row, name, missing) : row[name]
    printable(name) = value(name) === missing ? "missing" : string(value(name))
    return "selective_refinement_progress: $row_index/$n_requested | " *
           "$(printable("window_id")) | solver=$(printable("solver_status")) | " *
           "primal=$(printable("primal_status")) | solve_s=$(printable("solve_elapsed_seconds")) | " *
           "residual_feasible=$(printable("candidate_residual_feasible")) | " *
           "trajectory_ready=$(printable("candidate_trajectory_ready")) | " *
           "accepted_tau=$(printable("tau_continuation_selected_tau")) | " *
           "coarse_fallback=$(printable("tau_continuation_coarse_tau_fallback_applied")) | " *
           "max_state_abs=$(printable("max_state_abs_difference")) | " *
           "max_state_rel_rmse=$(printable("max_state_relative_rmse")) | " *
           "dominant=$(printable("dominant_residual"))"
end

function _selective_refinement_tau_progress_line(event)
    value(name) = get(event, name, missing)
    printable(name) = value(name) === missing ? "missing" : string(value(name))
    return "selective_refinement_tau: $(printable("window_id")) | " *
           "stage=$(printable("stage_index"))/$(printable("stage_count")) | " *
           "tau=$(printable("tau")) | max_iter=$(printable("stage_ipopt_max_iter")) | " *
           "solver=$(printable("solver_status")) | primal=$(printable("primal_status")) | " *
           "solve_s=$(printable("solve_elapsed_seconds")) | " *
           "residual_feasible=$(printable("residual_feasible")) | " *
           "tau_gate=$(printable("complementarity_tau_gate_pass")) | " *
           "advance=$(printable("stage_advance_allowed")) | " *
           "dominant=$(printable("dominant_residual"))"
end

artifact_dir_raw = strip(get(ENV, "MPCC_SELECTIVE_REFINEMENT_ARTIFACT_DIR", get(ARGS, 1, "")))
isempty(artifact_dir_raw) && error(
    "Set MPCC_SELECTIVE_REFINEMENT_ARTIFACT_DIR or pass the artifact directory as the first argument.",
)
artifact_dir = isabspath(artifact_dir_raw) ?
    normpath(artifact_dir_raw) :
    normpath(joinpath(project_root, artifact_dir_raw))

refinement_dir_raw = strip(get(ENV, "MPCC_SELECTIVE_REFINEMENT_DIAGNOSTIC_DIR", ""))
refinement_dir = isempty(refinement_dir_raw) ? nothing :
    (isabspath(refinement_dir_raw) ? normpath(refinement_dir_raw) : normpath(joinpath(project_root, refinement_dir_raw)))
output_dir = _script_output_dir(
    project_root,
    "MPCC_SELECTIVE_REFINEMENT_OUTPUT_DIR",
    joinpath(artifact_dir, "selective_refinement"),
)
overwrite = _script_env_bool("MPCC_SELECTIVE_REFINEMENT_OUTPUT_OVERWRITE", true)
top_n = _selective_refinement_env_int("MPCC_SELECTIVE_REFINEMENT_TOP_N", 4)
window_ids = _selective_refinement_env_window_ids("MPCC_SELECTIVE_REFINEMENT_WINDOW_IDS")
only_coarse = _script_env_bool("MPCC_SELECTIVE_REFINEMENT_ONLY_COARSE", true)
minimum_priority = strip(get(ENV, "MPCC_SELECTIVE_REFINEMENT_MIN_PRIORITY", "high"))
ipopt_max_iter = _selective_refinement_env_optional_int("MPCC_SELECTIVE_REFINEMENT_IPOPT_MAX_ITER")
linear_solver = strip(get(ENV, "MPCC_IPOPT_LINEAR_SOLVER", "mumps"))
ipopt_profile = reduced_mpcc_ipopt_profile_name_from_env()
complementarity_mode = reduced_mpcc_complementarity_mode_from_env("scholtes")
complementarity_tau = reduced_mpcc_complementarity_tau_from_env()
complementarity_tau_gate_tol = reduced_mpcc_complementarity_tau_gate_tol_from_env()
tau_schedule = reduced_mpcc_tau_schedule_from_env()
tau_stage_max_iters = reduced_mpcc_tau_stage_max_iters_from_env()
tau_final_retry_max_iter = reduced_mpcc_tau_final_retry_max_iter_from_env()
allow_coarse_tau_fallback = _script_env_bool("MPCC_SELECTIVE_REFINEMENT_ALLOW_COARSE_FALLBACK", false)
require_preflight = _script_env_bool("MPCC_SELECTIVE_REFINEMENT_REQUIRE_PREFLIGHT", true)
continue_on_error = _script_env_bool("MPCC_SELECTIVE_REFINEMENT_CONTINUE_ON_ERROR", true)
silent = _script_env_bool("MPCC_SELECTIVE_REFINEMENT_SILENT", true)
residual_thresholds = _selective_refinement_residual_thresholds_from_env()

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

result = run_reduced_dcdfba_mpcc_windowed_selective_refinement_artifacts(
    model,
    reaction_map,
    artifact_dir;
    refinement_dir = refinement_dir,
    top_n = top_n,
    window_ids = window_ids,
    only_coarse_tau_fallback = only_coarse,
    minimum_priority = minimum_priority,
    ipopt_max_iter = ipopt_max_iter,
    linear_solver = linear_solver,
    ipopt_profile = ipopt_profile,
    complementarity_mode = complementarity_mode,
    complementarity_tau = complementarity_tau,
    complementarity_tau_gate_tol = complementarity_tau_gate_tol,
    tau_schedule = tau_schedule,
    tau_stage_max_iters = tau_stage_max_iters,
    tau_final_retry_max_iter = tau_final_retry_max_iter,
    allow_coarse_tau_fallback = allow_coarse_tau_fallback,
    require_pre_solve_ready = require_preflight,
    residual_thresholds = residual_thresholds,
    silent = silent,
    continue_on_error = continue_on_error,
    window_callback = (row, row_index, n_requested) -> begin
        println(_selective_refinement_progress_line(row, row_index, n_requested))
        flush(stdout)
    end,
    tau_stage_callback = event -> begin
        println(_selective_refinement_tau_progress_line(event))
        flush(stdout)
    end,
)

paths = export_reduced_dcdfba_mpcc_windowed_selective_refinement(
    result,
    output_dir;
    overwrite = overwrite,
)

println("Reduced MPCC windowed selective refinement")
println("artifact_dir: $(artifact_dir)")
println("output_dir: $(output_dir)")
println("n_selected_windows: $(result.metadata["n_selected_windows"])")
println("top_n: $(result.metadata["top_n"])")
println("requested_window_ids: $(join(result.metadata["requested_window_ids"], ","))")
println("only_coarse_tau_fallback: $(result.metadata["only_coarse_tau_fallback"])")
println("minimum_priority: $(result.metadata["minimum_priority"])")
println("ipopt_max_iter: $(result.metadata["ipopt_max_iter"])")
println("linear_solver: $(result.metadata["linear_solver"])")
println("tau_schedule: $(result.metadata["tau_schedule"])")
println("tau_stage_max_iters: $(result.metadata["tau_stage_max_iters"])")
println("tau_final_retry_max_iter: $(result.metadata["tau_final_retry_max_iter"])")
println("allow_coarse_tau_fallback: $(result.metadata["allow_coarse_tau_fallback"])")
println("residual_max_rhs: $(residual_thresholds.max_rhs_residual)")
println("residual_max_mass: $(residual_thresholds.max_mass_balance_residual)")
println("residual_max_lower_bound: $(residual_thresholds.max_lower_bound_violation)")
println("residual_max_upper_bound: $(residual_thresholds.max_upper_bound_violation)")
println("residual_max_stationarity: $(residual_thresholds.max_stationarity_residual)")
println("residual_max_lower_complementarity: $(residual_thresholds.max_lower_complementarity_residual)")
println("residual_max_upper_complementarity: $(residual_thresholds.max_upper_complementarity_residual)")
println("outputs_written: true")
for key in sort(collect(keys(paths)))
    println("output_$(key): $(paths[key])")
end
haskey(paths, "refined_aligned_timeseries") &&
    println("refined_aligned_timeseries: $(paths["refined_aligned_timeseries"])")

println("before_after_table:")
for row in eachrow(result.before_after_table)
    println(
        "  $(row["window_id"]) | original_tau=$(row["original_tau"]) | refined_tau=$(row["refined_tau"]) | " *
        "original_solver=$(row["original_solver_status"]) | refined_solver=$(row["refined_solver_status"]) | " *
        "original_abs=$(row["original_max_state_abs_difference"]) | refined_abs=$(row["refined_max_state_abs_difference"]) | " *
        "original_rel=$(row["original_max_state_relative_rmse"]) | refined_rel=$(row["refined_max_state_relative_rmse"]) | " *
        "followup=$(row["recommended_followup"])",
    )
end
