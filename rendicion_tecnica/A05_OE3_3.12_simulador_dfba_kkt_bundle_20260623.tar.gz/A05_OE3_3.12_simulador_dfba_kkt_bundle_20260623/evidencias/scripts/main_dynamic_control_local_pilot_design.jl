using CSV
using DataFrames
using Dates
using FermentationDFBA
using TOML

const DYNAMIC_CONTROL_LOCAL_PILOT_SCRIPT = "main_dynamic_control_local_pilot_design.jl"

project_root = normpath(joinpath(@__DIR__, ".."))

function _pilot_env_bool(name::AbstractString, default::Bool)::Bool
    raw_value = lowercase(strip(get(ENV, String(name), string(default))))
    if raw_value in ("1", "true", "yes", "y", "on")
        return true
    elseif raw_value in ("0", "false", "no", "n", "off")
        return false
    end
    error("Environment variable $name must be boolean, got: $raw_value")
end

function _pilot_env_positive_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _pilot_env_nonnegative_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _pilot_env_positive_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _pilot_env_nonnegative_or_inf_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    ((isfinite(value) && value >= 0.0) || value == Inf) ||
        error("Environment variable $name must be nonnegative or Inf, got: $raw_value")
    return value
end

function _pilot_env_path(name::AbstractString, default_relative::AbstractString)::String
    raw_value = strip(get(ENV, String(name), default_relative))
    isempty(raw_value) && error("Environment variable $name must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _pilot_parse_float_vector(raw_value)::Vector{Float64}
    raw_value isa Missing && return Float64[]
    values = Float64[]
    for token in split(replace(string(raw_value), ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Could not parse Float64 token '$cleaned' from '$raw_value'.")
        isfinite(value) || error("Non-finite Float64 token '$cleaned' from '$raw_value'.")
        push!(values, value)
    end
    return values
end

function _pilot_vector_string(values::AbstractVector)::String
    return join(string.(Float64.(values)), ",")
end

function _pilot_bool(value)::Bool
    value isa Bool && return value
    value isa Missing && return false
    raw = lowercase(strip(string(value)))
    raw in ("1", "true", "yes", "y") && return true
    raw in ("0", "false", "no", "n") && return false
    return false
end

function _pilot_required_columns(table::DataFrame)
    required = [
        :candidate_id,
        :temperature_values_C,
        :fda_doses_g_L,
        :organic_doses_g_L,
        :control_policy_ready,
    ]
    names_set = Set(Symbol.(names(table)))
    missing_columns = [String(column) for column in required if !(column in names_set)]
    isempty(missing_columns) || error(
        "Dynamic-control local pilot input CSV is missing column(s): " *
        join(missing_columns, ", "),
    )
    return nothing
end

function _pilot_selected_policy(table::DataFrame, candidate_id::AbstractString)
    cleaned_id = strip(candidate_id)
    if !isempty(cleaned_id)
        matches = findall(==(cleaned_id), String.(table.candidate_id))
        length(matches) == 1 || error(
            "Expected exactly one base candidate_id=$cleaned_id, found $(length(matches)).",
        )
        return table[matches[1], :]
    end
    ready_indices = findall(_pilot_bool, table.control_policy_ready)
    !isempty(ready_indices) || error("No control_policy_ready=true policies in pilot input CSV.")
    return table[ready_indices[1], :]
end

function _pilot_safe_token(raw::AbstractString)::String
    token = replace(String(raw), "." => "p", "-" => "m")
    token = replace(token, r"[^A-Za-z0-9_]+" => "_")
    return token
end

function _pilot_addition_count(horizon_h::Real, control_interval_h::Real)::Int
    transition_count = max(0, ceil(Int, Float64(horizon_h) / Float64(control_interval_h)) - 1)
    return transition_count
end

function _pilot_temperature_count(horizon_h::Real, control_interval_h::Real)::Int
    return _pilot_addition_count(horizon_h, control_interval_h) + 1
end

function _pilot_toml_normalize(value)
    if value isa Missing || value === nothing
        return "missing"
    elseif value isa Bool
        return value
    elseif value isa Integer
        return Int(value)
    elseif value isa Real
        float_value = Float64(value)
        isfinite(float_value) && return float_value
        isnan(float_value) && return "NaN"
        float_value == Inf && return "Inf"
        float_value == -Inf && return "-Inf"
        return string(value)
    elseif value isa AbstractString
        return value
    elseif value isa AbstractVector || value isa Tuple
        return [_pilot_toml_normalize(item) for item in value]
    elseif value isa AbstractDict
        normalized = Dict{String, Any}()
        for key in sort!(collect(keys(value)); by = string)
            normalized[string(key)] = _pilot_toml_normalize(value[key])
        end
        return normalized
    end
    return string(value)
end

function _pilot_row_dict(base_row::DataFrameRow, base_columns::Vector{String})::Dict{String, Any}
    row = Dict{String, Any}()
    for column in base_columns
        row[column] = base_row[Symbol(column)]
    end
    return row
end

function _pilot_set_if_present!(row::Dict{String, Any}, key::AbstractString, value)
    haskey(row, String(key)) && (row[String(key)] = value)
    return row
end

function _pilot_control_move_metrics(
    base_temperature::AbstractVector,
    base_fda::AbstractVector,
    base_organic::AbstractVector,
    temperature::AbstractVector,
    fda::AbstractVector,
    organic::AbstractVector,
)
    return (
        temperature_linf_delta_C =
            maximum(abs.(Float64.(temperature) .- Float64.(base_temperature)); init = 0.0),
        fda_l1_delta_g_L = sum(abs.(Float64.(fda) .- Float64.(base_fda)); init = 0.0),
        organic_l1_delta_g_L =
            sum(abs.(Float64.(organic) .- Float64.(base_organic)); init = 0.0),
    )
end

function _pilot_append_candidate!(
    rows::Vector{Dict{String, Any}},
    seen::Set{String},
    base_row::DataFrameRow,
    base_columns::Vector{String};
    base_candidate_id::AbstractString,
    suffix::AbstractString,
    move_type::AbstractString,
    move_description::AbstractString,
    profile_id::AbstractString,
    nutrient_strategy_id::AbstractString,
    temperature_values::AbstractVector,
    fda_doses::AbstractVector,
    organic_doses::AbstractVector,
    base_temperature_values::AbstractVector,
    base_fda_doses::AbstractVector,
    base_organic_doses::AbstractVector,
    temperature_min_C::Real,
    temperature_max_C::Real,
    fda_total_limit_g_L::Real,
    organic_total_limit_g_L::Real,
)
    candidate_id = "$(base_candidate_id)__pilot_$(_pilot_safe_token(suffix))"
    candidate_id in seen && return false
    temperature = Float64.(temperature_values)
    fda = Float64.(fda_doses)
    organic = Float64.(organic_doses)
    all(value -> isfinite(value) && Float64(temperature_min_C) <= value <= Float64(temperature_max_C), temperature) ||
        return false
    all(value -> isfinite(value) && value >= 0.0, fda) || return false
    all(value -> isfinite(value) && value >= 0.0, organic) || return false
    sum(fda; init = 0.0) <= Float64(fda_total_limit_g_L) + 1.0e-12 || return false
    sum(organic; init = 0.0) <= Float64(organic_total_limit_g_L) + 1.0e-12 || return false

    metrics = _pilot_control_move_metrics(
        base_temperature_values,
        base_fda_doses,
        base_organic_doses,
        temperature,
        fda,
        organic,
    )
    row = _pilot_row_dict(base_row, base_columns)
    row["candidate_id"] = candidate_id
    _pilot_set_if_present!(row, "profile_id", profile_id)
    _pilot_set_if_present!(row, "nutrient_strategy_id", nutrient_strategy_id)
    row["temperature_values_C"] = _pilot_vector_string(temperature)
    row["fda_doses_g_L"] = _pilot_vector_string(fda)
    row["organic_doses_g_L"] = _pilot_vector_string(organic)
    row["control_policy_ready"] = true
    _pilot_set_if_present!(row, "mpcc_fixed_control_replay_ready", false)
    _pilot_set_if_present!(
        row,
        "mpcc_fixed_control_replay_blocker",
        "Local pilot candidate generated; run fixed-control MPCC solve-attempt.",
    )
    _pilot_set_if_present!(row, "fda_total_product_g_L", sum(fda; init = 0.0))
    _pilot_set_if_present!(row, "organic_total_product_g_L", sum(organic; init = 0.0))
    _pilot_set_if_present!(
        row,
        "nutrient_total_product_g_L",
        sum(fda; init = 0.0) + sum(organic; init = 0.0),
    )
    _pilot_set_if_present!(row, "selected_for_review", true)
    _pilot_set_if_present!(row, "gate_pass", true)
    _pilot_set_if_present!(row, "selection_basis", "local_pilot_trust_region")

    row["pilot_base_candidate_id"] = String(base_candidate_id)
    row["pilot_move_id"] = String(suffix)
    row["pilot_move_type"] = String(move_type)
    row["pilot_move_description"] = String(move_description)
    row["pilot_profile_id"] = String(profile_id)
    row["pilot_nutrient_strategy_id"] = String(nutrient_strategy_id)
    row["pilot_total_fda_product_g_L"] = sum(fda; init = 0.0)
    row["pilot_total_organic_product_g_L"] = sum(organic; init = 0.0)
    row["pilot_total_nutrient_product_g_L"] = sum(fda; init = 0.0) + sum(organic; init = 0.0)
    row["pilot_temperature_linf_delta_C"] = metrics.temperature_linf_delta_C
    row["pilot_fda_l1_delta_g_L"] = metrics.fda_l1_delta_g_L
    row["pilot_organic_l1_delta_g_L"] = metrics.organic_l1_delta_g_L
    row["pilot_ready_for_fixed_mpcc"] = true
    row["pilot_fixed_mpcc_status"] = "not_run"
    push!(rows, row)
    push!(seen, candidate_id)
    return true
end

base_policy_csv = _pilot_env_path(
    "MPCC_DYNAMIC_CONTROL_PILOT_BASE_SELECTION_CSV",
    joinpath("results", "dynamic_control_policy_selection_latest", "dynamic_control_policy_selection.csv"),
)
isfile(base_policy_csv) || error("Base policy selection CSV does not exist: $base_policy_csv")

output_dir = _pilot_env_path(
    "MPCC_DYNAMIC_CONTROL_PILOT_OUTPUT_DIR",
    joinpath("results", "dynamic_control_local_pilot_latest"),
)
overwrite = _pilot_env_bool("MPCC_DYNAMIC_CONTROL_PILOT_OVERWRITE", true)
base_candidate_id = strip(get(ENV, "MPCC_DYNAMIC_CONTROL_PILOT_BASE_CANDIDATE_ID", ""))
schedule_horizon_h =
    _pilot_env_positive_float("MPCC_DYNAMIC_CONTROL_PILOT_SCHEDULE_HOURS", 168.0)
control_interval_h =
    _pilot_env_positive_float("MPCC_DYNAMIC_CONTROL_PILOT_INTERVAL_HOURS", 12.0)
temperature_min_C = _pilot_env_positive_float("MPCC_DYNAMIC_CONTROL_PILOT_T_MIN_C", 15.0)
temperature_max_C = _pilot_env_positive_float("MPCC_DYNAMIC_CONTROL_PILOT_T_MAX_C", 25.0)
temperature_step_C =
    _pilot_env_nonnegative_float("MPCC_DYNAMIC_CONTROL_PILOT_TEMPERATURE_STEP_C", 0.5)
organic_step_g_L =
    _pilot_env_nonnegative_float("MPCC_DYNAMIC_CONTROL_PILOT_ORGANIC_STEP_G_L", 0.05)
fda_step_g_L = _pilot_env_nonnegative_float("MPCC_DYNAMIC_CONTROL_PILOT_FDA_STEP_G_L", 0.25)
fda_total_limit_g_L =
    _pilot_env_nonnegative_or_inf_float("MPCC_DYNAMIC_CONTROL_PILOT_FDA_TOTAL_LIMIT_G_L", FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L)
organic_total_limit_g_L =
    _pilot_env_nonnegative_or_inf_float("MPCC_DYNAMIC_CONTROL_PILOT_ORGANIC_TOTAL_LIMIT_G_L", Inf)
temperature_slot_count =
    _pilot_env_positive_int("MPCC_DYNAMIC_CONTROL_PILOT_TEMPERATURE_SLOT_COUNT", 2)
addition_slot_count = _pilot_env_positive_int("MPCC_DYNAMIC_CONTROL_PILOT_ADDITION_SLOT_COUNT", 1)
max_candidates = _pilot_env_positive_int("MPCC_DYNAMIC_CONTROL_PILOT_MAX_CANDIDATES", 9)
allow_not_ready = _pilot_env_bool("MPCC_DYNAMIC_CONTROL_PILOT_ALLOW_NOT_READY", false)
include_nutrient_equivalent_swap =
    _pilot_env_bool("MPCC_DYNAMIC_CONTROL_PILOT_INCLUDE_NUTRIENT_EQUIVALENT_SWAP", true)

mkpath(output_dir)
candidate_path = joinpath(output_dir, "dynamic_control_local_pilot_candidates.csv")
runlist_path = joinpath(output_dir, "dynamic_control_local_pilot_runlist.txt")
metadata_path = joinpath(output_dir, "dynamic_control_local_pilot_metadata.toml")
if !overwrite
    existing_targets = [path for path in (candidate_path, runlist_path, metadata_path) if isfile(path)]
    isempty(existing_targets) || error(
        "Dynamic-control local pilot output file(s) already exist and overwrite=false: " *
        join(existing_targets, ", "),
    )
end

policy_table = DataFrame(CSV.File(base_policy_csv))
_pilot_required_columns(policy_table)
base_row = _pilot_selected_policy(policy_table, base_candidate_id)
resolved_base_candidate_id = String(base_row.candidate_id)
base_ready = _pilot_bool(base_row.control_policy_ready)
base_ready || allow_not_ready ||
    error("Base candidate $resolved_base_candidate_id has control_policy_ready=false.")

base_temperature = _pilot_parse_float_vector(base_row.temperature_values_C)
base_fda = _pilot_parse_float_vector(base_row.fda_doses_g_L)
base_organic = _pilot_parse_float_vector(base_row.organic_doses_g_L)
expected_temperature_count = _pilot_temperature_count(schedule_horizon_h, control_interval_h)
expected_addition_count = _pilot_addition_count(schedule_horizon_h, control_interval_h)
length(base_temperature) == expected_temperature_count || error(
    "Base temperature vector length $(length(base_temperature)) does not match expected " *
    "$expected_temperature_count for schedule_horizon_h=$schedule_horizon_h and interval=$control_interval_h.",
)
length(base_fda) == expected_addition_count || error(
    "Base FDA dose vector length $(length(base_fda)) does not match expected $expected_addition_count.",
)
length(base_organic) == expected_addition_count || error(
    "Base organic dose vector length $(length(base_organic)) does not match expected $expected_addition_count.",
)

base_columns = String.(names(policy_table))
rows = Dict{String, Any}[]
seen = Set{String}()
organic_composition = springferm_xtrem_organic_composition()
fda_n_fraction = FDA_SOLUTION_NITROGEN_FRACTION_GN_PER_G
organic_n_fraction = organic_composition.nitrogen_fraction_gN_per_g

function _try_append!(; kwargs...)
    length(rows) >= max_candidates && return false
    return _pilot_append_candidate!(
        rows,
        seen,
        base_row,
        base_columns;
        base_candidate_id = resolved_base_candidate_id,
        temperature_min_C = temperature_min_C,
        temperature_max_C = temperature_max_C,
        fda_total_limit_g_L = fda_total_limit_g_L,
        organic_total_limit_g_L = organic_total_limit_g_L,
        base_temperature_values = base_temperature,
        base_fda_doses = base_fda,
        base_organic_doses = base_organic,
        kwargs...,
    )
end

_try_append!(
    suffix = "base",
    move_type = "base_policy",
    move_description = "Unchanged fixed-control policy, included as local-pilot reference.",
    profile_id = "local_pilot_base",
    nutrient_strategy_id = "local_pilot_base",
    temperature_values = base_temperature,
    fda_doses = base_fda,
    organic_doses = base_organic,
)

for slot in 1:min(temperature_slot_count, length(base_temperature))
    temperature_step_C > 0.0 || break
    plus_temperature = copy(base_temperature)
    plus_temperature[slot] += temperature_step_C
    _try_append!(
        suffix = "T$(slot)_plus_$(temperature_step_C)C",
        move_type = "temperature_plus",
        move_description = "Increase temperature control slot $slot by $(temperature_step_C) C.",
        profile_id = "local_pilot_temperature_plus",
        nutrient_strategy_id = "local_pilot_nutrient_base",
        temperature_values = plus_temperature,
        fda_doses = base_fda,
        organic_doses = base_organic,
    )

    minus_temperature = copy(base_temperature)
    minus_temperature[slot] -= temperature_step_C
    _try_append!(
        suffix = "T$(slot)_minus_$(temperature_step_C)C",
        move_type = "temperature_minus",
        move_description = "Decrease temperature control slot $slot by $(temperature_step_C) C.",
        profile_id = "local_pilot_temperature_minus",
        nutrient_strategy_id = "local_pilot_nutrient_base",
        temperature_values = minus_temperature,
        fda_doses = base_fda,
        organic_doses = base_organic,
    )
end

for slot in 1:min(addition_slot_count, length(base_fda))
    if organic_step_g_L > 0.0
        organic_plus = copy(base_organic)
        organic_plus[slot] += organic_step_g_L
        _try_append!(
            suffix = "org$(slot)_plus_$(organic_step_g_L)gL",
            move_type = "organic_plus",
            move_description = "Increase organic nutrient dose slot $slot by $(organic_step_g_L) g/L.",
            profile_id = "local_pilot_temperature_base",
            nutrient_strategy_id = "local_pilot_organic_plus",
            temperature_values = base_temperature,
            fda_doses = base_fda,
            organic_doses = organic_plus,
        )

        organic_minus = copy(base_organic)
        organic_minus[slot] -= organic_step_g_L
        _try_append!(
            suffix = "org$(slot)_minus_$(organic_step_g_L)gL",
            move_type = "organic_minus",
            move_description = "Decrease organic nutrient dose slot $slot by $(organic_step_g_L) g/L.",
            profile_id = "local_pilot_temperature_base",
            nutrient_strategy_id = "local_pilot_organic_minus",
            temperature_values = base_temperature,
            fda_doses = base_fda,
            organic_doses = organic_minus,
        )
    end

    if fda_step_g_L > 0.0
        fda_plus = copy(base_fda)
        fda_plus[slot] += fda_step_g_L
        _try_append!(
            suffix = "fda$(slot)_plus_$(fda_step_g_L)gL",
            move_type = "fda_plus",
            move_description = "Increase FDA solution dose slot $slot by $(fda_step_g_L) g/L.",
            profile_id = "local_pilot_temperature_base",
            nutrient_strategy_id = "local_pilot_fda_plus",
            temperature_values = base_temperature,
            fda_doses = fda_plus,
            organic_doses = base_organic,
        )
    end

    if include_nutrient_equivalent_swap &&
       organic_step_g_L > 0.0 &&
       fda_n_fraction > 0.0 &&
       organic_n_fraction > 0.0
        equivalent_fda_step = organic_step_g_L * organic_n_fraction / fda_n_fraction
        swap_fda = copy(base_fda)
        swap_organic = copy(base_organic)
        swap_organic[slot] -= organic_step_g_L
        swap_fda[slot] += equivalent_fda_step
        _try_append!(
            suffix = "org$(slot)_to_fda_yaneq",
            move_type = "organic_to_fda_yan_equivalent",
            move_description =
                "Move $(organic_step_g_L) g/L organic nutrient in slot $slot to an FDA YAN-equivalent dose.",
            profile_id = "local_pilot_temperature_base",
            nutrient_strategy_id = "local_pilot_org_to_fda_yaneq",
            temperature_values = base_temperature,
            fda_doses = swap_fda,
            organic_doses = swap_organic,
        )
    end
end

candidate_table = DataFrame(rows)
extra_columns = [
    "pilot_base_candidate_id",
    "pilot_move_id",
    "pilot_move_type",
    "pilot_move_description",
    "pilot_profile_id",
    "pilot_nutrient_strategy_id",
    "pilot_total_fda_product_g_L",
    "pilot_total_organic_product_g_L",
    "pilot_total_nutrient_product_g_L",
    "pilot_temperature_linf_delta_C",
    "pilot_fda_l1_delta_g_L",
    "pilot_organic_l1_delta_g_L",
    "pilot_ready_for_fixed_mpcc",
    "pilot_fixed_mpcc_status",
]
ordered_columns = vcat(base_columns, [column for column in extra_columns if !(column in base_columns)])
select!(candidate_table, ordered_columns)
CSV.write(candidate_path, candidate_table)

open(runlist_path, "w") do io
    for candidate_id in candidate_table.candidate_id
        println(io, candidate_id)
    end
end

metadata = Dict{String, Any}(
    "script" => DYNAMIC_CONTROL_LOCAL_PILOT_SCRIPT,
    "created_at" => Dates.format(Dates.now(), dateformat"yyyy-mm-ddTHH:MM:SS"),
    "base_policy_selection_csv" => base_policy_csv,
    "output_dir" => output_dir,
    "candidate_csv" => candidate_path,
    "runlist_txt" => runlist_path,
    "metadata_toml" => metadata_path,
    "base_candidate_id" => resolved_base_candidate_id,
    "base_control_policy_ready" => base_ready,
    "pilot_control_liberation_mode" => "outer_loop_local_policy_trust_region",
    "fully_simultaneous_controls" => false,
    "fixed_control_mpcc_required_next" => true,
    "schedule_horizon_h" => schedule_horizon_h,
    "control_interval_h" => control_interval_h,
    "temperature_min_C" => temperature_min_C,
    "temperature_max_C" => temperature_max_C,
    "temperature_step_C" => temperature_step_C,
    "organic_step_g_L" => organic_step_g_L,
    "fda_step_g_L" => fda_step_g_L,
    "fda_total_limit_g_L" => fda_total_limit_g_L,
    "organic_total_limit_g_L" => organic_total_limit_g_L,
    "fda_solution_nitrogen_fraction_gN_per_g" => fda_n_fraction,
    "springferm_xtrem_organic_nitrogen_fraction_gN_per_g" => organic_n_fraction,
    "temperature_slot_count" => min(temperature_slot_count, length(base_temperature)),
    "addition_slot_count" => min(addition_slot_count, length(base_fda)),
    "max_candidates" => max_candidates,
    "candidate_count" => nrow(candidate_table),
    "candidate_ids" => String.(candidate_table.candidate_id),
    "method_note" =>
        "First freed-control pilot: perturb smooth 12 h-grid policy values and evaluate each candidate with the sane fixed-control MPCC start construction before implementing embedded JuMP control variables.",
)
open(metadata_path, "w") do io
    TOML.print(io, _pilot_toml_normalize(metadata))
end

println("Dynamic control local pilot design")
println("base_policy_selection_csv: $base_policy_csv")
println("output_dir: $output_dir")
println("candidate_csv: $candidate_path")
println("runlist_txt: $runlist_path")
println("metadata_toml: $metadata_path")
println("base_candidate_id: $resolved_base_candidate_id")
println("pilot_control_liberation_mode: $(metadata["pilot_control_liberation_mode"])")
println("fully_simultaneous_controls: false")
println("candidate_count: $(nrow(candidate_table))")
println("fixed_control_mpcc_required_next: true")
println("candidate_ids:")
for row in eachrow(candidate_table)
    println("  $(row.candidate_id) | move=$(row.pilot_move_id) | type=$(row.pilot_move_type)")
end
