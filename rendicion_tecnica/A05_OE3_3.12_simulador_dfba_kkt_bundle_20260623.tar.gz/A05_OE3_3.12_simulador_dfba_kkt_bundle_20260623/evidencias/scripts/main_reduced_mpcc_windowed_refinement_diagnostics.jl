using CSV
using DataFrames
using FermentationDFBA

include("ode_script_helpers.jl")

project_root = normpath(joinpath(@__DIR__, ".."))

function _refinement_env_int(name::AbstractString, default::Int)::Int
    raw_value = strip(get(ENV, String(name), string(default)))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $raw_value")
    return value
end

artifact_dir_raw = strip(get(ENV, "MPCC_WINDOW_ARTIFACT_DIR", get(ARGS, 1, "")))
isempty(artifact_dir_raw) && error(
    "Set MPCC_WINDOW_ARTIFACT_DIR or pass the windowed artifact directory as the first argument.",
)
artifact_dir = isabspath(artifact_dir_raw) ?
    normpath(artifact_dir_raw) :
    normpath(joinpath(project_root, artifact_dir_raw))

output_dir = _script_output_dir(
    project_root,
    "MPCC_REFINEMENT_OUTPUT_DIR",
    joinpath(artifact_dir, "refinement_diagnostics"),
)
overwrite = _script_env_bool("MPCC_REFINEMENT_OUTPUT_OVERWRITE", true)
top_n = _refinement_env_int("MPCC_REFINEMENT_TOP_N", 12)
boundary_threshold = _script_env_float("MPCC_REFINEMENT_BOUNDARY_REL_JUMP", 2.0e-2)
rmse_threshold = _script_env_float("MPCC_REFINEMENT_WINDOW_REL_RMSE", 5.0e-2)
abs_threshold = _script_env_float("MPCC_REFINEMENT_WINDOW_ABS_DIFF", 1.0e-1)

result = diagnose_reduced_dcdfba_mpcc_windowed_refinement_artifacts(
    artifact_dir;
    output_dir = output_dir,
    overwrite = overwrite,
    boundary_relative_jump_threshold = boundary_threshold,
    window_relative_rmse_threshold = rmse_threshold,
    window_abs_difference_threshold = abs_threshold,
)

println("Reduced MPCC windowed selective-refinement diagnostics")
println("artifact_dir: $(artifact_dir)")
println("output_dir: $(output_dir)")
println("diagnostic_type: $(result.metadata["diagnostic_type"])")
println("mpcc_rerun_performed: $(result.metadata["mpcc_rerun_performed"])")
println("n_windows: $(result.metadata["n_windows"])")
println("n_states: $(result.metadata["n_states"])")
println("high_priority_window_count: $(result.metadata["high_priority_window_count"])")
println("medium_priority_window_count: $(result.metadata["medium_priority_window_count"])")
println("coarse_tau_fallback_window_count: $(result.metadata["coarse_tau_fallback_window_count"])")
println("max_refinement_score: $(result.metadata["max_refinement_score"])")
println("max_boundary_relative_jump: $(result.metadata["max_boundary_relative_jump"])")
println("max_window_state_abs_difference: $(result.metadata["max_window_state_abs_difference"])")
println("outputs_written: true")
println("window_refinement_candidates: $(joinpath(output_dir, "window_refinement_candidates.csv"))")
println("state_window_errors: $(joinpath(output_dir, "state_window_errors.csv"))")
println("boundary_jumps: $(joinpath(output_dir, "boundary_jumps.csv"))")
println("window_refinement_score_plot: $(joinpath(output_dir, "window_refinement_score.svg"))")

println("top_refinement_windows:")
for row in eachrow(first(result.window_refinement_candidates, min(top_n, nrow(result.window_refinement_candidates))))
    println(
        "  $(row["window_id"]) | rank=$(row["refinement_rank"]) | tspan=($(row["t0"]),$(row["tfinal"])) | " *
        "priority=$(row["refinement_priority"]) | score=$(round(Float64(row["refinement_score"]); digits = 3)) | " *
        "tau=$(row["accepted_tau"]) | coarse=$(row["coarse_tau_fallback"]) | solver=$(row["solver_status"]) | " *
        "dominant_state=$(row["dominant_abs_state"]) | boundary_state=$(row["dominant_boundary_state"]) | " *
        "action=$(row["recommended_action"]) | reasons=$(row["refinement_reasons"])",
    )
end
