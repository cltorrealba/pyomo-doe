using FermentationDFBA

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

model = load_reduced_model(paths_config)
dimension_report = validate_reduced_model_dimensions(model)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)

core_roles = Set(keys(reaction_map.core))
found_core = Dict(
    role => rxn_id for (role, rxn_id) in reaction_report.found_required_reactions if role in core_roles
)

println("Reduced model load report")
println("model_id: $(model.model_id)")
println("metabolites: $(length(model.met_ids))")
println("reactions: $(length(model.rxn_ids))")
println("lower_bounds: $(length(model.lb))")
println("upper_bounds: $(length(model.ub))")
println("dimension_validation: $(dimension_report.ok ? "ok" : "failed")")

println("found_core_reactions:")
for (role, rxn_id) in sort(collect(found_core))
    println("  $role = $rxn_id")
end

println("disabled_reactions:")
for (role, rxn_id) in sort(collect(reaction_report.disabled_reactions))
    display_id = isempty(rxn_id) ? "missing" : rxn_id
    reason = get(reaction_map.disabled_reaction_reasons, role, "No reason provided.")
    println("  $role = $display_id ($reason)")
end

if isempty(reaction_report.missing_required_reactions)
    println("missing_required_reactions: none")
else
    println("missing_required_reactions:")
    for (role, rxn_id) in sort(collect(reaction_report.missing_required_reactions))
        display_id = isempty(rxn_id) ? "missing" : rxn_id
        println("  $role = $display_id")
    end
end
