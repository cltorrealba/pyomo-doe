using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_WINDOWED_72H_RUNNER_PROFILE = "smoke"
const DEFAULT_MPCC_WINDOWED_72H_RUNNER_IPOPT_MAX_ITER = 100

function _mpcc_windowed_72h_runner_profile()
    raw = strip(
        get(
            ENV,
            "MPCC_WINDOWED_72H_RUNNER_PROFILE",
            DEFAULT_MPCC_WINDOWED_72H_RUNNER_PROFILE,
        ),
    )
    normalized = lowercase(raw)
    normalized = normalized == "twomh_four_nfe" ? "2h4nfe" : normalized
    normalized in ("smoke", "pilot", "72h", "2h4nfe", "custom") ||
        error(
            "Environment variable MPCC_WINDOWED_72H_RUNNER_PROFILE must be one of: " *
            "smoke, pilot, 72h, 2h4nfe, twomh_four_nfe, custom. Got: $raw",
        )
    return normalized
end

function _mpcc_windowed_72h_runner_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizon = "0.25",
            window_hours = "0.25",
            nfe_per_window = 1,
            max_windows = 1,
        )
    elseif profile == "pilot"
        return (
            target_horizon = "4.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 8,
        )
    elseif profile == "72h"
        return (
            target_horizon = "72.0",
            window_hours = "0.5",
            nfe_per_window = 2,
            max_windows = 144,
        )
    elseif profile == "2h4nfe"
        return (
            target_horizon = "72.0",
            window_hours = "2.0",
            nfe_per_window = 4,
            max_windows = 36,
        )
    else
        return (
            target_horizon = "0.5",
            window_hours = "0.25",
            nfe_per_window = 1,
            max_windows = 2,
        )
    end
end

function _mpcc_windowed_72h_runner_env_positive_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_windowed_72h_runner_env_nonnegative_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $value")
    return value
end

function _mpcc_windowed_72h_runner_env_positive_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_windowed_72h_runner_n_windows(
    target_horizon::Float64,
    window_hours::Float64,
)::Int
    raw = target_horizon / window_hours
    n_windows = round(Int, raw)
    isapprox(raw, n_windows; atol = 1.0e-10, rtol = 1.0e-10) || error(
        "MPCC_WINDOWED_72H_RUNNER_TARGET_HOURS=$target_horizon is not an integer " *
        "multiple of MPCC_WINDOWED_72H_RUNNER_WINDOW_HOURS=$window_hours.",
    )
    return n_windows
end

function _mpcc_windowed_72h_runner_validate_grid!(
    n_windows::Int,
    max_windows::Int,
    allow_long::Bool,
)
    if n_windows > max_windows && !allow_long
        error(
            "Requested reduced MPCC 72h windowed runner has $n_windows windows, above " *
            "MPCC_WINDOWED_72H_RUNNER_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_WINDOWED_72H_RUNNER_ALLOW_LONG=1 only for deliberate longer runs.",
        )
    end
    return nothing
end

function _mpcc_windowed_72h_runner_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_windowed_72h_runner_progress_callback(progress::Bool)
    progress || return nothing
    return function (row, row_index, n_requested_windows)
        println(
            "progress_window: $row_index/$n_requested_windows | " *
            "id=$(_mpcc_windowed_72h_runner_value(row["window_id"])) | " *
            "status=$(_mpcc_windowed_72h_runner_value(row["window_status"])) | " *
            "tfinal=$(_mpcc_windowed_72h_runner_value(row["tfinal"])) | " *
            "solver=$(_mpcc_windowed_72h_runner_value(row["solver_status"])) | " *
            "residual_feasible=$(_mpcc_windowed_72h_runner_value(row["candidate_residual_feasible"])) | " *
            "allows_continuation=$(_mpcc_windowed_72h_runner_value(row["candidate_allows_continuation"])) | " *
            "solve_s=$(_mpcc_windowed_72h_runner_value(row["solve_elapsed_seconds"]))",
        )
    end
end

profile = _mpcc_windowed_72h_runner_profile()
defaults = _mpcc_windowed_72h_runner_profile_defaults(profile)
target_horizon =
    _mpcc_windowed_72h_runner_env_positive_float(
        "MPCC_WINDOWED_72H_RUNNER_TARGET_HOURS",
        defaults.target_horizon,
    )
window_hours =
    _mpcc_windowed_72h_runner_env_positive_float(
        "MPCC_WINDOWED_72H_RUNNER_WINDOW_HOURS",
        defaults.window_hours,
    )
nfe_per_window =
    _mpcc_windowed_72h_runner_env_positive_int(
        "MPCC_WINDOWED_72H_RUNNER_NFE",
        defaults.nfe_per_window,
    )
max_windows =
    _mpcc_windowed_72h_runner_env_positive_int(
        "MPCC_WINDOWED_72H_RUNNER_MAX_WINDOWS",
        defaults.max_windows,
    )
allow_long = _script_env_bool("MPCC_WINDOWED_72H_RUNNER_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_WINDOWED_72H_RUNNER_CONTINUE_ON_ERROR", true)
require_pre_solve_ready = _script_env_bool("MPCC_WINDOWED_72H_RUNNER_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_WINDOWED_72H_RUNNER_SILENT", true)
progress = _script_env_bool("MPCC_WINDOWED_72H_RUNNER_PROGRESS", profile == "72h")
linear_solver =
    strip(get(ENV, "MPCC_IPOPT_LINEAR_SOLVER", profile == "2h4nfe" ? "spral" : "mumps"))
ipopt_profile = reduced_mpcc_ipopt_profile_name_from_env()
complementarity_mode = reduced_mpcc_complementarity_mode_from_env("scholtes")
complementarity_tau = reduced_mpcc_complementarity_tau_from_env()
complementarity_tau_gate_tol = reduced_mpcc_complementarity_tau_gate_tol_from_env()
tau_schedule =
    _script_env_bool("MPCC_WINDOWED_72H_RUNNER_USE_TAU_CONTINUATION", profile == "2h4nfe") ?
    reduced_mpcc_tau_schedule_from_env() : nothing
tau_schedule_label = tau_schedule === nothing ? "disabled" : join(tau_schedule, ",")
ipopt_max_iter =
    _mpcc_windowed_72h_runner_env_positive_int(
        "MPCC_WINDOWED_72H_RUNNER_IPOPT_MAX_ITER",
        DEFAULT_MPCC_WINDOWED_72H_RUNNER_IPOPT_MAX_ITER,
    )
continuation_acceptance_policy =
    strip(get(ENV, "MPCC_WINDOWED_72H_RUNNER_CONTINUATION_POLICY", "residual_feasible"))
continuation_state_relative_rmse_threshold =
    _mpcc_windowed_72h_runner_env_nonnegative_float(
        "MPCC_WINDOWED_72H_RUNNER_STATE_REL_RMSE_THRESHOLD",
        "0.02",
    )

n_windows = _mpcc_windowed_72h_runner_n_windows(target_horizon, window_hours)
_mpcc_windowed_72h_runner_validate_grid!(n_windows, max_windows, allow_long)

println("Reduced MPCC 72h windowed simulation runner")
println("profile: $profile")
println("target_horizon: $target_horizon")
println("window_hours: $window_hours")
println("n_windows: $n_windows")
println("nfe_per_window: $nfe_per_window")
println("boundary_dt: $(window_hours / nfe_per_window)")
println("linear_solver: $linear_solver")
println("ipopt_profile_env: MPCC_REDUCED_MPCC_IPOPT_PROFILE")
println("ipopt_profile: $ipopt_profile")
println("complementarity_mode: $complementarity_mode")
println("complementarity_tau: $complementarity_tau")
println("complementarity_tau_gate_tol: $complementarity_tau_gate_tol")
println("tau_schedule: $tau_schedule_label")
println("ipopt_max_iter: $ipopt_max_iter")
println("continuation_acceptance_policy: $continuation_acceptance_policy")
println("continuation_state_relative_rmse_threshold: $continuation_state_relative_rmse_threshold")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("progress: $progress")

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

result = run_reduced_dcdfba_mpcc_windowed_72h_simulation(
    model,
    reaction_map;
    target_horizon = target_horizon,
    window_hours = window_hours,
    nfe_per_window = nfe_per_window,
    degree = 3,
    linear_solver = linear_solver,
    ipopt_profile = ipopt_profile,
    complementarity_mode = complementarity_mode,
    complementarity_tau = complementarity_tau,
    complementarity_tau_gate_tol = complementarity_tau_gate_tol,
    tau_schedule = tau_schedule,
    ipopt_max_iter = ipopt_max_iter,
    require_pre_solve_ready = require_pre_solve_ready,
    continuation_acceptance_policy = continuation_acceptance_policy,
    continuation_state_relative_rmse_threshold =
        continuation_state_relative_rmse_threshold,
    silent = silent,
    continue_on_error = continue_on_error,
    window_callback = _mpcc_windowed_72h_runner_progress_callback(progress),
)

metadata = result.metadata
println("outputs_written: $(metadata["outputs_written"])")
println("runner_is_scientific_simulation: $(metadata["runner_is_scientific_simulation"])")
println("runner_is_validated_simulation: $(metadata["runner_is_validated_simulation"])")
println("solved_trajectory_claimed: $(metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(metadata["scientific_baseline"])")
println("first_mpcc_target: $(metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(metadata["hsl_required"])")
println("ma57_required: $(metadata["ma57_required"])")
println("indices_reacciones_used: $(metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(metadata["r0001_used_as_oxygen"])")
println("global_monolithic_mpcc_solve_attempted: $(metadata["global_monolithic_mpcc_solve_attempted"])")
println("global_polish_deferred: $(metadata["global_polish_deferred"])")
println("global_polish_deferred_reason: $(metadata["global_polish_deferred_reason"])")
println("target_is_72h: $(metadata["target_is_72h"])")
println("target_completed: $(metadata["target_completed"])")
println("runner_traffic_light: $(metadata["runner_traffic_light"])")
println("runner_status: $(metadata["runner_status"])")
println("runner_viable: $(metadata["runner_viable"])")
println("candidate_ready_for_review: $(metadata["candidate_ready_for_review"])")
println("horizon_reached: $(_mpcc_windowed_72h_runner_value(metadata["horizon_reached"]))")
println("horizon_gap: $(_mpcc_windowed_72h_runner_value(metadata["horizon_gap"]))")
println("target_completion_fraction: $(_mpcc_windowed_72h_runner_value(metadata["target_completion_fraction"]))")
println("n_requested_windows: $(metadata["n_requested_windows"])")
println("n_completed_windows: $(metadata["n_completed_windows"])")
println("n_failed_windows: $(metadata["n_failed_windows"])")
println("boundary_candidate_available: $(metadata["boundary_candidate_available"])")
println("sequential_reference_available: $(metadata["sequential_reference_available"])")
println("global_state_metrics_available: $(metadata["global_state_metrics_available"])")
println("global_max_state_relative_rmse: $(_mpcc_windowed_72h_runner_value(metadata["global_max_state_relative_rmse"]))")
println("metadata_continuation_acceptance_policy: $(metadata["continuation_acceptance_policy"])")
println("continuation_state_drift_gate_enabled: $(metadata["continuation_state_drift_gate_enabled"])")
println("window_green_count: $(metadata["window_green_count"])")
println("window_yellow_count: $(metadata["window_yellow_count"])")
println("window_red_count: $(metadata["window_red_count"])")
println("first_non_green_window_id: $(_mpcc_windowed_72h_runner_value(metadata["first_non_green_window_id"]))")
println("first_red_window_id: $(_mpcc_windowed_72h_runner_value(metadata["first_red_window_id"]))")
println("first_not_residual_feasible_window_id: $(_mpcc_windowed_72h_runner_value(metadata["first_not_residual_feasible_window_id"]))")
println("total_solve_elapsed_seconds: $(_mpcc_windowed_72h_runner_value(metadata["total_solve_elapsed_seconds"]))")
println("recommended_next_action: $(metadata["recommended_next_action"])")

println("runner_table:")
for row in eachrow(result.runner_table)
    println(
        "  $(row["runner_id"]) | target=$(_mpcc_windowed_72h_runner_value(row["target_horizon"])) | " *
        "target_72h=$(_mpcc_windowed_72h_runner_value(row["target_is_72h"])) | " *
        "light=$(_mpcc_windowed_72h_runner_value(row["runner_traffic_light"])) | " *
        "status=$(_mpcc_windowed_72h_runner_value(row["runner_status"])) | " *
        "ready=$(_mpcc_windowed_72h_runner_value(row["candidate_ready_for_review"])) | " *
        "horizon=$(_mpcc_windowed_72h_runner_value(row["horizon_reached"])) | " *
        "gap=$(_mpcc_windowed_72h_runner_value(row["horizon_gap"])) | " *
        "windows=$(_mpcc_windowed_72h_runner_value(row["n_completed_windows"]))/" *
        "$(_mpcc_windowed_72h_runner_value(row["n_requested_windows"])) | " *
        "state_rmse=$(_mpcc_windowed_72h_runner_value(row["global_max_state_relative_rmse"])) | " *
        "solve_s=$(_mpcc_windowed_72h_runner_value(row["total_solve_elapsed_seconds"])) | " *
        "action=$(_mpcc_windowed_72h_runner_value(row["recommended_next_action"]))",
    )
end

println("window_table:")
for row in eachrow(result.attempt_result.continuation_result.window_table)
    println(
        "  $(row["window_id"]) | index=$(_mpcc_windowed_72h_runner_value(row["window_index"])) | " *
        "status=$(_mpcc_windowed_72h_runner_value(row["window_status"])) | " *
        "tfinal=$(_mpcc_windowed_72h_runner_value(row["tfinal"])) | " *
        "solver=$(_mpcc_windowed_72h_runner_value(row["solver_status"])) | " *
        "residual_feasible=$(_mpcc_windowed_72h_runner_value(row["candidate_residual_feasible"])) | " *
        "trajectory_ready=$(_mpcc_windowed_72h_runner_value(row["candidate_trajectory_ready"])) | " *
        "allows_continuation=$(_mpcc_windowed_72h_runner_value(row["candidate_allows_continuation"])) | " *
        "mass=$(_mpcc_windowed_72h_runner_value(row["max_mass_balance_residual"])) | " *
        "state_rmse=$(_mpcc_windowed_72h_runner_value(row["max_state_relative_rmse"])) | " *
        "solve_s=$(_mpcc_windowed_72h_runner_value(row["solve_elapsed_seconds"])) | " *
        "reason=$(_mpcc_windowed_72h_runner_value(row["continuation_acceptance_reason"]))",
    )
end

println("interpretation_note: $(metadata["interpretation_note"])")
