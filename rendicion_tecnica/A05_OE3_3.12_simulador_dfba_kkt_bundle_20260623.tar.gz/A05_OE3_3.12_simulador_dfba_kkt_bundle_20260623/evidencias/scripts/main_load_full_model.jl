using FermentationDFBA

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")

paths = load_full_model_paths(paths_config)
file_report = validate_model_files(paths)
model = load_full_model(paths)
dimension_report = validate_full_model_dimensions(model)

println("Full model load report")
println("model_id: $(model.model_id)")
println("metabolites: $(length(model.met_ids))")
println("reactions: $(length(model.rxn_ids))")
println("lower_bounds: $(length(model.lb))")
println("upper_bounds: $(length(model.ub))")
println("file_validation: $(file_report.ok ? "ok" : "failed")")
println("dimension_validation: $(dimension_report.ok ? "ok" : "failed")")
println("first_metabolite_id: $(first(model.met_ids))")
println("last_metabolite_id: $(last(model.met_ids))")
println("first_reaction_id: $(first(model.rxn_ids))")
println("last_reaction_id: $(last(model.rxn_ids))")

println("key_reactions:")
for rxn_id in ("r_2111", "r_1714", "r_1709", "r_1761", "r_1992", "r_4046", "r_4047", "r_4048")
    println("  $rxn_id = $(has_reaction(model, rxn_id))")
end

oxygen_index = reaction_index(model, "r_1992")
carbohydrate_index = reaction_index(model, "r_4048")
println("oxygen_bounds_r_1992:")
println("  lb = $(model.lb[oxygen_index])")
println("  ub = $(model.ub[oxygen_index])")
println("carbohydrate_bounds_r_4048:")
println("  lb = $(model.lb[carbohydrate_index])")
println("  ub = $(model.ub[carbohydrate_index])")
println("oxygen_mapping_note: r_1992 is present and closed by bounds; r_0001 is not used as oxygen.")
