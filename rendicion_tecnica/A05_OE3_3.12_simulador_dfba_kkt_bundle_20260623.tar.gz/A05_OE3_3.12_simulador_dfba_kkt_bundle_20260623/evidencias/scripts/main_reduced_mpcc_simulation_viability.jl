using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_VIABILITY_SOURCE = "windowed"
const DEFAULT_MPCC_VIABILITY_IPOPT_MAX_ITER = 100

function _mpcc_viability_source()
    raw = strip(get(ENV, "MPCC_VIABILITY_SOURCE", DEFAULT_MPCC_VIABILITY_SOURCE))
    normalized = lowercase(raw)
    normalized in ("sweep", "mesh", "windowed") ||
        error("Environment variable MPCC_VIABILITY_SOURCE must be one of: sweep, mesh, windowed. Got: $raw")
    return normalized
end

function _mpcc_viability_env_positive_float(name::AbstractString, default_value::Real)::Float64
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_viability_env_positive_int(name::AbstractString, default_value::Int)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_viability_env_int_list(name::AbstractString, default_value::AbstractString)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Int, stripped)
        value === nothing && error("Environment variable $name contains a non-Int value: $stripped")
        value > 0 || error("Environment variable $name values must be positive, got: $value")
        push!(values, value)
    end
    length(unique(values)) >= 2 ||
        error("Environment variable $name must contain at least two distinct finite-element counts.")
    return sort(unique(values))
end

function _mpcc_viability_script_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

source = _mpcc_viability_source()
ipopt_max_iter =
    _mpcc_viability_env_positive_int("MPCC_VIABILITY_IPOPT_MAX_ITER", DEFAULT_MPCC_VIABILITY_IPOPT_MAX_ITER)
require_pre_solve_ready = _script_env_bool("MPCC_VIABILITY_REQUIRE_PREFLIGHT", true)
silent = _script_env_bool("MPCC_VIABILITY_SILENT", true)
continue_on_error = _script_env_bool("MPCC_VIABILITY_CONTINUE_ON_ERROR", true)

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

source_result = if source == "sweep"
    horizon = _mpcc_viability_env_positive_float("MPCC_VIABILITY_HORIZON_HOURS", 0.5)
    nfe = _mpcc_viability_env_positive_int("MPCC_VIABILITY_NFE", 1)
    sweep_reduced_dcdfba_mpcc_solve_attempts(
        model,
        reaction_map;
        horizons = [horizon],
        nfe_values = [nfe],
        degree = 3,
        ipopt_max_iter = ipopt_max_iter,
        require_pre_solve_ready = require_pre_solve_ready,
        silent = silent,
        continue_on_error = continue_on_error,
    )
elseif source == "mesh"
    horizon = _mpcc_viability_env_positive_float("MPCC_VIABILITY_HORIZON_HOURS", 0.5)
    nfe_values = _mpcc_viability_env_int_list("MPCC_VIABILITY_MESH_NFE_VALUES", "1,2")
    sweep_reduced_dcdfba_mpcc_mesh_refinement(
        model,
        reaction_map;
        horizons = [horizon],
        nfe_values = nfe_values,
        degree = 3,
        ipopt_max_iter = ipopt_max_iter,
        require_pre_solve_ready = require_pre_solve_ready,
        silent = silent,
        continue_on_error = continue_on_error,
    )
else
    window_hours = _mpcc_viability_env_positive_float("MPCC_VIABILITY_WINDOW_HOURS", 0.25)
    n_windows = _mpcc_viability_env_positive_int("MPCC_VIABILITY_WINDOW_COUNT", 2)
    nfe_per_window = _mpcc_viability_env_positive_int("MPCC_VIABILITY_WINDOW_NFE", 1)
    max_windows = _mpcc_viability_env_positive_int("MPCC_VIABILITY_MAX_WINDOWS", 2)
    allow_long = _script_env_bool("MPCC_VIABILITY_ALLOW_LONG", false)
    if n_windows > max_windows && !allow_long
        error(
            "Requested MPCC viability windowed source has $n_windows windows, above " *
            "MPCC_VIABILITY_MAX_WINDOWS=$max_windows. Set MPCC_VIABILITY_ALLOW_LONG=1 " *
            "only for deliberate longer local diagnostics.",
        )
    end
    run_reduced_dcdfba_mpcc_windowed_continuation(
        model,
        reaction_map;
        window_hours = window_hours,
        n_windows = n_windows,
        nfe_per_window = nfe_per_window,
        degree = 3,
        ipopt_max_iter = ipopt_max_iter,
        require_pre_solve_ready = require_pre_solve_ready,
        silent = silent,
        continue_on_error = continue_on_error,
    )
end

report = assess_reduced_dcdfba_mpcc_simulation_viability(source_result)

println("Reduced MPCC simulation viability semaphore")
println("source: $source")
println("ipopt_max_iter: $ipopt_max_iter")
println("require_pre_solve_ready: $require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("outputs_written: $(report.metadata["outputs_written"])")
println("viability_report_is_scientific_simulation: $(report.metadata["viability_report_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(report.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(report.metadata["scientific_baseline"])")
println("first_mpcc_target: $(report.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(report.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(report.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(report.metadata["hsl_required"])")
println("ma57_required: $(report.metadata["ma57_required"])")
println("indices_reacciones_used: $(report.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(report.metadata["r0001_used_as_oxygen"])")
println("overall_traffic_light: $(report.metadata["overall_traffic_light"])")
println("overall_simulation_viable: $(report.metadata["overall_simulation_viable"])")
println("simulation_viable_candidate_count: $(report.metadata["simulation_viable_candidate_count"])")
println("green_count: $(report.metadata["green_count"])")
println("yellow_count: $(report.metadata["yellow_count"])")
println("red_count: $(report.metadata["red_count"])")
println("hard_red_count: $(report.metadata["hard_red_count"])")
println("best_candidate_id: $(_mpcc_viability_script_value(report.metadata["best_candidate_id"]))")
println("best_candidate_traffic_light: $(_mpcc_viability_script_value(report.metadata["best_candidate_traffic_light"]))")
println("best_candidate_viability_class: $(_mpcc_viability_script_value(report.metadata["best_candidate_viability_class"]))")
println("recommended_next_action: $(report.metadata["recommended_next_action"])")
println("threshold_max_state_abs_difference: $(report.metadata["threshold_max_state_abs_difference"])")
println("threshold_max_state_relative_rmse: $(report.metadata["threshold_max_state_relative_rmse"])")
println("threshold_max_global_state_abs_difference: $(report.metadata["threshold_max_global_state_abs_difference"])")
println("threshold_max_global_state_relative_rmse: $(report.metadata["threshold_max_global_state_relative_rmse"])")

println("viability_table:")
for row in eachrow(report.viability_table)
    println(
        "  $(row["candidate_id"]) | source=$(row["source_type"]) | light=$(row["traffic_light"]) | " *
        "class=$(row["viability_class"]) | viable=$(row["simulation_viable"]) | " *
        "trajectory_ready=$(row["trajectory_ready"]) | residual_feasible=$(row["residual_feasible"]) | " *
        "state_pass=$(row["state_drift_pass"]) | global_state_pass=$(row["global_state_drift_pass"]) | " *
        "solver=$(_mpcc_viability_script_value(row["solver_status"])) | " *
        "max_state_abs=$(_mpcc_viability_script_value(row["max_state_abs_difference"])) | " *
        "max_state_rel_rmse=$(_mpcc_viability_script_value(row["max_state_relative_rmse"])) | " *
        "global_state_abs=$(_mpcc_viability_script_value(row["global_max_state_abs_difference"])) | " *
        "global_state_rel_rmse=$(_mpcc_viability_script_value(row["global_max_state_relative_rmse"])) | " *
        "blocking=$(row["blocking_reasons"])",
    )
end

println("interpretation_note: $(report.metadata["interpretation_note"])")
