using FermentationDFBA

const STATIC_FBA_COMPARISON_DIAGNOSTIC_TOLERANCE = 1.0e-6

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")
full_reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")
output_dir = joinpath(project_root, "results", "static_fba_comparison", "latest")

reduced_model = load_reduced_model(reduced_paths_config)
full_model = load_full_model(full_paths_config)
reduced_reaction_map = load_reaction_map(reduced_reaction_map_config)
full_reaction_map = load_reaction_map(full_reaction_map_config)

comparison = compare_static_fba_full_reduced(
    reduced_model,
    reduced_reaction_map,
    full_model,
    full_reaction_map;
    atol = STATIC_FBA_COMPARISON_DIAGNOSTIC_TOLERANCE,
)

report_paths = export_static_fba_comparison(comparison, output_dir; overwrite = true)
plot_paths = write_static_fba_comparison_plots(comparison, output_dir; overwrite = true)

function _script_table_value(value)
    if value === missing || value === nothing
        return "missing"
    elseif value isa AbstractFloat
        return string(value)
    else
        return string(value)
    end
end

println("Full-vs-reduced static FBA comparison report")
println("output_dir: $output_dir")
println("reduced_objective: $(comparison.reduced_result.objective_value)")
println("full_objective: $(comparison.full_result.objective_value)")
println("reduced_mass_balance_residual: $(comparison.reduced_result.mass_balance_residual)")
println("full_mass_balance_residual: $(comparison.full_result.mass_balance_residual)")
println("reduced_max_lower_bound_violation: $(comparison.reduced_result.max_lower_bound_violation)")
println("full_max_lower_bound_violation: $(comparison.full_result.max_lower_bound_violation)")
println("reduced_max_upper_bound_violation: $(comparison.reduced_result.max_upper_bound_violation)")
println("full_max_upper_bound_violation: $(comparison.full_result.max_upper_bound_violation)")

println("selected_flux_comparison:")
println("  reaction_id | role | reduced_flux | full_flux | absolute_difference | relative_difference | notes")
selected_fluxes = comparison.selected_flux_table
for i in axes(selected_fluxes, 1)
    println(
        "  $(selected_fluxes[i, "reaction_id"]) | " *
        "$(selected_fluxes[i, "role"]) | " *
        "$(_script_table_value(selected_fluxes[i, "reduced_flux"])) | " *
        "$(_script_table_value(selected_fluxes[i, "full_flux"])) | " *
        "$(_script_table_value(selected_fluxes[i, "absolute_difference"])) | " *
        "$(_script_table_value(selected_fluxes[i, "relative_difference"])) | " *
        "$(selected_fluxes[i, "notes"])",
    )
end

println("written_csv_toml_files:")
for key in sort(collect(keys(report_paths)))
    println("  $key = $(report_paths[key])")
end

println("written_svg_files:")
for key in sort(collect(keys(plot_paths)))
    println("  $key = $(plot_paths[key])")
end

println("oxygen_note: $(comparison.metadata["oxygen_mapping_note"])")
println("carbohydrate_note: $(comparison.metadata["carbohydrate_mapping_note"])")
println("interpretation_note: $(comparison.metadata["interpretation_note"])")
