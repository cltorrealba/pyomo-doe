using FermentationDFBA
using SparseArrays

project_root = normpath(joinpath(@__DIR__, ".."))
full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")
dfvb_paths_config = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")

full_model = load_full_model(full_paths_config)
reaction_map = load_reaction_map(reaction_map_config)
artifacts = load_dfvb_artifacts(
    dfvb_paths_config;
    load_alpha_trajectories = false,
    load_active_alpha_trajectories = false,
    load_state_trajectories = false,
)
validation = validate_dfvb_artifacts(artifacts)
validation.ok || error("DFVB artifact validation failed: $(join(validation.errors, "; "))")

growth_y = zenteno_state_to_vector(default_zenteno_initial_state())
turnover_state = ZentenoState(
    0.5,
    0.0,
    110.0,
    110.0,
    0.0,
    0.0,
    0.23,
    0.185,
    zeros(5),
    zeros(6),
)
turnover_y = zenteno_state_to_vector(turnover_state)

function _dynamic_dfvb_flux_value(model, result::StaticDFVBResult, reaction_id::AbstractString)
    if !has_reaction(model, reaction_id) || isempty(result.fluxes)
        return "missing"
    end
    return string(result.fluxes[reaction_index(model, reaction_id)])
end

function _dynamic_dfvb_report(label::AbstractString, result::StaticDFVBResult)
    println("Dynamic DFVB LP smoke report [$label]")
    println("mode: $(result.metadata["dynamic_mode"])")
    println("solver_status: $(result.status)")
    println("primal_status: $(result.primal_status)")
    println("dual_status: $(result.dual_status)")
    println("solver_label: $(result.metadata["solver_label"])")
    println("objective_value: $(result.objective_value)")
    println("objective_type: $(result.metadata["objective_type"])")
    println("objective_term_count: $(result.metadata["n_objective_terms"])")
    println("dynamic_lb_update_count: $(result.metadata["dynamic_lb_update_count"])")
    println("dynamic_ub_update_count: $(result.metadata["dynamic_ub_update_count"])")
    println("dynamic_objective_term_count: $(result.metadata["dynamic_objective_term_count"])")
    println("objective_reaction_ids: $(join(result.metadata["dynamic_objective_reaction_ids"], ", "))")
    println("biomass_flux_r_2111: $(_dynamic_dfvb_flux_value(full_model, result, "r_2111"))")
    println("atp_maintenance_flux_r_4046: $(_dynamic_dfvb_flux_value(full_model, result, "r_4046"))")
    println("protein_flux_r_4047: $(_dynamic_dfvb_flux_value(full_model, result, "r_4047"))")
    println("glucose_flux_r_1714: $(_dynamic_dfvb_flux_value(full_model, result, "r_1714"))")
    println("fructose_flux_r_1709: $(_dynamic_dfvb_flux_value(full_model, result, "r_1709"))")
    println("ethanol_flux_r_1761: $(_dynamic_dfvb_flux_value(full_model, result, "r_1761"))")
    println("oxygen_flux_r_1992: $(_dynamic_dfvb_flux_value(full_model, result, "r_1992"))")
    println("mass_balance_residual: $(result.mass_balance_residual)")
    println("max_lower_bound_violation: $(result.max_lower_bound_violation)")
    println("max_upper_bound_violation: $(result.max_upper_bound_violation)")
    println("alpha_dimension: $(length(result.alpha))")
    println("N_active_size: $(size(artifacts.N_active))")
    println("N_active_nnz: $(nnz(artifacts.N_active))")
    println("r0001_used_as_oxygen: $(result.metadata["r0001_used_as_oxygen"])")
    println("indices_reacciones_used: $(result.metadata["indices_reacciones_used"])")
    println("oxygen_reaction_id: $(result.metadata["oxygen_reaction_id"])")
    println("carbohydrate_derivative_policy: $(result.metadata["carbohydrate_derivative_policy"])")
    println("biological_interpretation_note: $(result.metadata["biological_interpretation_note"])")
end

growth_result = solve_dynamic_dfvb_lp(
    full_model,
    reaction_map,
    artifacts,
    growth_y;
    use_active_alpha = true,
)
turnover_result = solve_dynamic_dfvb_lp(
    full_model,
    reaction_map,
    artifacts,
    turnover_y;
    use_active_alpha = true,
)

println("Dynamic DFVB LP smoke")
println("model_id: $(full_model.model_id)")
println("model_dimensions: $(size(full_model.S))")
println("artifact_id: $(artifacts.paths.artifact_id)")
println("artifact_validation_ok: $(validation.ok)")
println("scope_note: Dynamic DFVB LP smoke only; no DFVB RHS, ODE simulation, or KKT/MPCC is implemented.")
_dynamic_dfvb_report("growth", growth_result)
_dynamic_dfvb_report("turnover", turnover_result)
