using FermentationDFBA

project_root = normpath(joinpath(@__DIR__, ".."))
full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")
dfvb_paths_config = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")

full_model = load_full_model(full_paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(full_model, reaction_map)
reaction_report.ok || error("Full reaction-map validation failed.")

artifacts = load_dfvb_artifacts(
    dfvb_paths_config;
    load_alpha_trajectories = false,
    load_active_alpha_trajectories = false,
    load_state_trajectories = false,
)
validation = validate_dfvb_artifacts(artifacts)
validation.ok || error("DFVB artifact validation failed: $(join(validation.errors, "; "))")

growth_state = default_zenteno_initial_state()
turnover_state = ZentenoState(
    0.5,
    0.0,
    110.0,
    110.0,
    0.0,
    0.0,
    0.23,
    0.185,
    zeros(5),
    zeros(6),
)

function _sequential_dfvb_report(label::AbstractString, result::DFVBRHSResult)
    println("Sequential DFVB RHS smoke report [$label]")
    println("mode: $(result.mode)")
    println("solver_status: $(result.dfvb.status)")
    println("weighted_objective_value: $(result.dfvb.objective_value)")
    println("biomass_flux_r_2111: $(result.fluxes_by_rxn["r_2111"])")
    println("alpha_dimension: $(length(result.alpha))")
    println("dy[1]: $(result.dy[1])")
    println("dy[2]: $(result.dy[2])")
    println("dy[3]: $(result.dy[3])")
    println("dy[4]: $(result.dy[4])")
    println("dy[5]: $(result.dy[5])")
    println("dy[6]: $(result.dy[6])")
    println("dy[8]: $(result.dy[8])")
    println("oxygen_flux_r_1992: $(result.fluxes_by_rxn["r_1992"])")
    println("r_0001_flux: $(result.fluxes_by_rxn["r_0001"])")
    println("mass_balance_residual: $(result.dfvb.mass_balance_residual)")
    println("max_lower_bound_violation: $(result.dfvb.max_lower_bound_violation)")
    println("max_upper_bound_violation: $(result.dfvb.max_upper_bound_violation)")
    println("oxygen_derivative_policy: $(result.metadata["oxygen_derivative_policy"])")
    println("oxygen_policy_note: $(result.metadata["oxygen_policy_note"])")
    println("carbohydrate_derivative_policy: $(result.metadata["carbohydrate_derivative_policy"])")
    println("r0001_used_as_oxygen: $(result.metadata["r0001_used_as_oxygen"])")
    println("indices_reacciones_used: $(result.metadata["indices_reacciones_used"])")
    println("biological_interpretation_note: $(result.metadata["biological_interpretation_note"])")
end

growth_result = compute_dfvb_rhs(
    full_model,
    reaction_map,
    artifacts,
    zenteno_state_to_vector(growth_state);
    use_active_alpha = true,
)
turnover_result = compute_dfvb_rhs(
    full_model,
    reaction_map,
    artifacts,
    zenteno_state_to_vector(turnover_state);
    use_active_alpha = true,
)

println("Sequential DFVB RHS smoke")
println("model_id: $(full_model.model_id)")
println("model_dimensions: $(size(full_model.S))")
println("artifact_id: $(artifacts.paths.artifact_id)")
println("artifact_validation_ok: $(validation.ok)")
println("use_active_alpha: true")
println("scope_note: One-step DFVB RHS smoke only; use scripts/main_simulate_dfvb.jl for the short DFVB ODE smoke path.")
_sequential_dfvb_report("growth", growth_result)
_sequential_dfvb_report("turnover", turnover_result)
