#!/usr/bin/env python3
"""Select active finite-element bands for fixed-control MPCC projection.

The input is a residual-location CSV emitted by
main_reduced_mpcc_fixed_control_policy_solve_attempt.jl. The output is a small
CSV of candidate contiguous element ranges, ordered by their worst residual.
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ElementResidual:
    element: int
    state_name: str
    residual_type: str
    abs_residual: float
    time_h: float | None


@dataclass(frozen=True)
class ProjectionBand:
    rank: int
    strategy: str
    first_element: int
    last_element: int
    center_element: int
    support_first_element: int
    support_last_element: int
    support_element_count: int
    dominant_state_name: str
    dominant_residual_type: str
    max_abs_residual: float
    mean_abs_residual: float

    @property
    def segment(self) -> str:
        return f"{self.first_element}:{self.last_element}"


DEFAULT_TYPES = frozenset({"collocation_integration", "continuity"})


def _parse_positive_int(value: str) -> int:
    parsed = int(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return parsed


def _parse_nonnegative_int(value: str) -> int:
    parsed = int(value)
    if parsed < 0:
        raise argparse.ArgumentTypeError("must be nonnegative")
    return parsed


def _float_or_none(raw: str | None) -> float | None:
    if raw is None or raw == "":
        return None
    try:
        value = float(raw)
    except ValueError:
        return None
    if math.isnan(value):
        return None
    return value


def read_element_residuals(path: Path, residual_types: set[str]) -> dict[int, ElementResidual]:
    best_by_element: dict[int, ElementResidual] = {}
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        required = {"residual_type", "element_index", "state_name", "abs_residual"}
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError(f"{path} is missing required columns: {', '.join(sorted(missing))}")

        for row in reader:
            residual_type = (row.get("residual_type") or "").strip()
            if residual_types and residual_type not in residual_types:
                continue
            try:
                element = int(float(row.get("element_index") or "nan"))
                abs_residual = abs(float(row.get("abs_residual") or "nan"))
            except ValueError:
                continue
            if not math.isfinite(abs_residual):
                continue
            state_name = (row.get("state_name") or "").strip() or "unknown"
            current = ElementResidual(
                element=element,
                state_name=state_name,
                residual_type=residual_type,
                abs_residual=abs_residual,
                time_h=_float_or_none(row.get("time_h")),
            )
            previous = best_by_element.get(element)
            if previous is None or current.abs_residual > previous.abs_residual:
                best_by_element[element] = current
    return best_by_element


def _clamp_range(first: int, last: int, min_element: int, max_element: int | None) -> tuple[int, int]:
    first = max(min_element, first)
    if max_element is not None:
        last = min(max_element, last)
    if last < first:
        last = first
    return first, last


def _dominant_for_support(
    support: list[int], best_by_element: dict[int, ElementResidual]
) -> tuple[ElementResidual, float]:
    residuals = [best_by_element[element] for element in support]
    dominant = max(residuals, key=lambda item: item.abs_residual)
    mean_abs = sum(item.abs_residual for item in residuals) / len(residuals)
    return dominant, mean_abs


def _make_band(
    strategy: str,
    first_element: int,
    last_element: int,
    support: list[int],
    best_by_element: dict[int, ElementResidual],
    min_element: int,
    max_element: int | None,
) -> ProjectionBand:
    first_element, last_element = _clamp_range(first_element, last_element, min_element, max_element)
    dominant, mean_abs = _dominant_for_support(support, best_by_element)
    return ProjectionBand(
        rank=0,
        strategy=strategy,
        first_element=first_element,
        last_element=last_element,
        center_element=dominant.element,
        support_first_element=min(support),
        support_last_element=max(support),
        support_element_count=len(support),
        dominant_state_name=dominant.state_name,
        dominant_residual_type=dominant.residual_type,
        max_abs_residual=dominant.abs_residual,
        mean_abs_residual=mean_abs,
    )


def propose_bands(
    best_by_element: dict[int, ElementResidual],
    *,
    max_bands: int,
    half_width: int,
    cluster_threshold_fraction: float,
    cluster_gap: int,
    cluster_padding: int,
    max_overlap_fraction: float,
    min_element: int,
    max_element: int | None,
) -> list[ProjectionBand]:
    if not best_by_element:
        return []

    sorted_residuals = sorted(best_by_element.values(), key=lambda item: item.abs_residual, reverse=True)
    top_abs = sorted_residuals[0].abs_residual
    threshold = top_abs * cluster_threshold_fraction
    active_elements = sorted(item.element for item in sorted_residuals if item.abs_residual >= threshold)

    bands: list[ProjectionBand] = []
    if active_elements:
        cluster: list[int] = [active_elements[0]]
        for element in active_elements[1:]:
            if element - cluster[-1] <= cluster_gap:
                cluster.append(element)
            else:
                bands.append(
                    _make_band(
                        "threshold_cluster",
                        min(cluster) - cluster_padding,
                        max(cluster) + cluster_padding,
                        cluster,
                        best_by_element,
                        min_element,
                        max_element,
                    )
                )
                cluster = [element]
        bands.append(
            _make_band(
                "threshold_cluster",
                min(cluster) - cluster_padding,
                max(cluster) + cluster_padding,
                cluster,
                best_by_element,
                min_element,
                max_element,
            )
        )

    for item in sorted_residuals:
        bands.append(
            _make_band(
                "peak_centered",
                item.element - half_width,
                item.element + half_width,
                [item.element],
                best_by_element,
                min_element,
                max_element,
            )
        )

    deduped: dict[tuple[int, int], ProjectionBand] = {}
    for band in bands:
        key = (band.first_element, band.last_element)
        existing = deduped.get(key)
        if existing is None or band.max_abs_residual > existing.max_abs_residual:
            deduped[key] = band

    ordered = sorted(
        deduped.values(),
        key=lambda band: (
            -band.max_abs_residual,
            -band.support_element_count,
            band.first_element,
            band.last_element,
        ),
    )
    selected: list[ProjectionBand] = []
    for band in ordered:
        if len(selected) >= max_bands:
            break
        band_length = band.last_element - band.first_element + 1
        too_overlapped = False
        for previous in selected:
            overlap = max(
                0,
                min(band.last_element, previous.last_element)
                - max(band.first_element, previous.first_element)
                + 1,
            )
            previous_length = previous.last_element - previous.first_element + 1
            denominator = max(1, min(band_length, previous_length))
            if overlap / denominator > max_overlap_fraction:
                too_overlapped = True
                break
        if not too_overlapped:
            selected.append(band)

    if len(selected) < max_bands:
        for band in ordered:
            if len(selected) >= max_bands:
                break
            key = (band.first_element, band.last_element)
            if all((previous.first_element, previous.last_element) != key for previous in selected):
                selected.append(band)

    ranked: list[ProjectionBand] = []
    for rank, band in enumerate(selected, start=1):
        ranked.append(
            ProjectionBand(
                rank=rank,
                strategy=band.strategy,
                first_element=band.first_element,
                last_element=band.last_element,
                center_element=band.center_element,
                support_first_element=band.support_first_element,
                support_last_element=band.support_last_element,
                support_element_count=band.support_element_count,
                dominant_state_name=band.dominant_state_name,
                dominant_residual_type=band.dominant_residual_type,
                max_abs_residual=band.max_abs_residual,
                mean_abs_residual=band.mean_abs_residual,
            )
        )
    return ranked


def write_bands(path: Path | None, bands: list[ProjectionBand]) -> None:
    fieldnames = [
        "rank",
        "segment",
        "strategy",
        "first_element",
        "last_element",
        "center_element",
        "support_first_element",
        "support_last_element",
        "support_element_count",
        "dominant_state_name",
        "dominant_residual_type",
        "max_abs_residual",
        "mean_abs_residual",
    ]
    if path is None:
        handle = sys.stdout
        close = False
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        handle = path.open("w", newline="")
        close = True
    try:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for band in bands:
            writer.writerow(
                {
                    "rank": band.rank,
                    "segment": band.segment,
                    "strategy": band.strategy,
                    "first_element": band.first_element,
                    "last_element": band.last_element,
                    "center_element": band.center_element,
                    "support_first_element": band.support_first_element,
                    "support_last_element": band.support_last_element,
                    "support_element_count": band.support_element_count,
                    "dominant_state_name": band.dominant_state_name,
                    "dominant_residual_type": band.dominant_residual_type,
                    "max_abs_residual": f"{band.max_abs_residual:.17g}",
                    "mean_abs_residual": f"{band.mean_abs_residual:.17g}",
                }
            )
    finally:
        if close:
            handle.close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--residual-locations", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-bands", type=_parse_positive_int, default=4)
    parser.add_argument("--half-width", type=_parse_nonnegative_int, default=8)
    parser.add_argument("--cluster-threshold-fraction", type=float, default=0.75)
    parser.add_argument("--cluster-gap", type=_parse_nonnegative_int, default=4)
    parser.add_argument("--cluster-padding", type=_parse_nonnegative_int, default=2)
    parser.add_argument("--max-overlap-fraction", type=float, default=0.5)
    parser.add_argument("--min-element", type=int, default=1)
    parser.add_argument("--max-element", type=int)
    parser.add_argument(
        "--residual-types",
        default=",".join(sorted(DEFAULT_TYPES)),
        help="Comma-separated residual types to consider; use empty for all.",
    )
    args = parser.parse_args(argv)

    if args.cluster_threshold_fraction <= 0.0 or args.cluster_threshold_fraction > 1.0:
        parser.error("--cluster-threshold-fraction must be in (0, 1]")
    if args.max_overlap_fraction < 0.0 or args.max_overlap_fraction > 1.0:
        parser.error("--max-overlap-fraction must be in [0, 1]")
    residual_types = {item.strip() for item in args.residual_types.split(",") if item.strip()}
    best_by_element = read_element_residuals(args.residual_locations, residual_types)
    bands = propose_bands(
        best_by_element,
        max_bands=args.max_bands,
        half_width=args.half_width,
        cluster_threshold_fraction=args.cluster_threshold_fraction,
        cluster_gap=args.cluster_gap,
        cluster_padding=args.cluster_padding,
        max_overlap_fraction=args.max_overlap_fraction,
        min_element=args.min_element,
        max_element=args.max_element,
    )
    if not bands:
        print(f"ERROR: no usable residual locations found in {args.residual_locations}", file=sys.stderr)
        return 2
    write_bands(args.output, bands)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
