using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
full_paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")
dfvb_paths_config = joinpath(project_root, "config", "dfvb_artifact_paths.example.toml")

full_model = load_full_model(full_paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(full_model, reaction_map)
reaction_report.ok || error(
    "Full reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

artifacts = load_dfvb_artifacts(
    dfvb_paths_config;
    load_alpha_trajectories = false,
    load_active_alpha_trajectories = false,
    load_state_trajectories = false,
)
validation = validate_dfvb_artifacts(artifacts)
validation.ok || error("DFVB artifact validation failed: $(join(validation.errors, "; "))")

tfinal = _script_env_float("DFVB_TFINAL_HOURS", 0.25)
saveat = _script_env_float("DFVB_SAVEAT_HOURS", 0.25)
reconstruct_fluxes = _script_env_bool("DFVB_RECONSTRUCT_FLUXES", false)
reconstruct_alphas = _script_env_bool("DFVB_RECONSTRUCT_ALPHAS", true)

result = simulate_dfvb(
    full_model,
    reaction_map,
    artifacts;
    tspan = (0.0, tfinal),
    saveat = saveat,
    algorithm = OrdinaryDiffEq.Tsit5(),
    use_active_alpha = true,
    reconstruct_fluxes = reconstruct_fluxes,
    reconstruct_alphas = reconstruct_alphas,
)
summary = summarize_simulation(result)

println("Sequential DFVB short simulation report")
println("Short sequential DFVB ODE smoke only; not KKT/MPCC.")
println("model_id: $(full_model.model_id)")
println("artifact_id: $(artifacts.paths.artifact_id)")
println("artifact_validation_ok: $(validation.ok)")
println("model_scope: $(summary["model_scope"])")
println("simulation_type: $(result.metadata["simulation_type"])")
println("algorithm: $(summary["algorithm"])")
println("smoke_tspan: $(summary["initial_time"]) to $(summary["final_time"]) h")
println("saved_time_points: $(summary["n_saved_points"])")
println("retcode: $(summary["retcode"])")
println("termination_reason: $(summary["termination_reason"])")
println("final_time: $(summary["final_time"])")
println("final_biomass: $(summary["final_biomass"])")
println("final_glucose: $(summary["final_glucose"])")
println("final_fructose: $(summary["final_fructose"])")
println("final_ethanol: $(summary["final_ethanol"])")
println("final_oxygen: $(summary["final_oxygen"])")
println("alpha_scope: $(summary["alpha_scope"])")
println("n_alphas: $(summary["n_alphas"])")
println("reconstruct_alphas: $(result.metadata["reconstruct_alphas"])")
println("reconstruct_fluxes: $(summary["reconstruct_fluxes"])")
println("rhs_call_count: $(summary["rhs_call_count"])")
println("rhs_lp_solve_count: $(summary["rhs_lp_solve_count"])")
println("alpha_reconstruction_solve_count: $(result.metadata["alpha_reconstruction_solve_count"])")
println("flux_reconstruction_solve_count: $(summary["flux_reconstruction_solve_count"])")
println("total_lp_solve_count: $(summary["total_lp_solve_count"])")
println("oxygen_derivative_policy: $(summary["oxygen_derivative_policy"])")
println("r0001_used_as_oxygen: $(result.metadata["r0001_used_as_oxygen"])")
println("indices_reacciones_used: $(result.metadata["indices_reacciones_used"])")
println("carbohydrate_derivative_policy: $(summary["carbohydrate_derivative_policy"])")
println("biological_interpretation_note: $(result.metadata["biological_interpretation_note"])")
