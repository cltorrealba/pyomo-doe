using CSV
using DataFrames
using Dates
using FermentationDFBA
using TOML

const DYNAMIC_CONTROL_LIBERATED_SPEC_SCRIPT = "main_dynamic_control_liberated_spec.jl"

project_root = normpath(joinpath(@__DIR__, ".."))

function _lib_env_bool(name::AbstractString, default::Bool)::Bool
    raw_value = lowercase(strip(get(ENV, String(name), string(default))))
    raw_value in ("1", "true", "yes", "y", "on") && return true
    raw_value in ("0", "false", "no", "n", "off") && return false
    error("Environment variable $name must be boolean, got: $raw_value")
end

function _lib_env_positive_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _lib_env_nonnegative_int(name::AbstractString, default::Integer)::Int
    raw_value = strip(get(ENV, String(name), string(Int(default))))
    value = tryparse(Int, raw_value)
    value === nothing && error("Environment variable $name must parse as Int, got: $raw_value")
    value >= 0 || error("Environment variable $name must be nonnegative, got: $value")
    return value
end

function _lib_env_positive_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $raw_value")
    return value
end

function _lib_env_nonnegative_float(name::AbstractString, default::Real)::Float64
    raw_value = strip(get(ENV, String(name), string(Float64(default))))
    value = tryparse(Float64, raw_value)
    value === nothing && error("Environment variable $name must parse as Float64, got: $raw_value")
    isfinite(value) && value >= 0.0 ||
        error("Environment variable $name must be finite and nonnegative, got: $raw_value")
    return value
end

function _lib_env_path(name::AbstractString, default_relative::AbstractString)::String
    raw_value = strip(get(ENV, String(name), default_relative))
    isempty(raw_value) && error("Environment variable $name must not be empty.")
    return isabspath(raw_value) ? normpath(raw_value) : normpath(joinpath(project_root, raw_value))
end

function _lib_parse_float_vector(raw_value)::Vector{Float64}
    raw_value isa Missing && return Float64[]
    values = Float64[]
    for token in split(replace(string(raw_value), ';' => ','), ',')
        cleaned = strip(token)
        isempty(cleaned) && continue
        value = tryparse(Float64, cleaned)
        value === nothing && error("Could not parse Float64 token '$cleaned' from '$raw_value'.")
        isfinite(value) || error("Non-finite Float64 token '$cleaned' from '$raw_value'.")
        push!(values, value)
    end
    return values
end

function _lib_parse_indexed_float_offsets(
    raw_value;
    max_count::Int,
    label::AbstractString,
)::Vector{Float64}
    max_count >= 0 || error("$label offset slot count must be nonnegative.")
    offsets = zeros(Float64, max_count)
    cleaned = strip(replace(string(raw_value), ';' => ','))
    normalized = lowercase(cleaned)
    (isempty(cleaned) || normalized in ("none", "0", "zero", "zeros", "off")) && return offsets

    seen = Set{Int}()
    for token in split(cleaned, ',')
        stripped = strip(token)
        isempty(stripped) && continue
        separator = occursin("=", stripped) ? "=" : occursin(":", stripped) ? ":" : ""
        isempty(separator) && error(
            "$label start offset token must look like slot=value, got '$stripped' from '$cleaned'.",
        )
        parts = split(stripped, separator; limit = 2)
        length(parts) == 2 || error(
            "$label start offset token must look like slot=value, got '$stripped' from '$cleaned'.",
        )
        index = _lib_parse_positive_int_token(parts[1], cleaned)
        1 <= index <= max_count || error(
            "$label start offset slot $index is outside 1:$max_count.",
        )
        index in seen && error("$label start offset slot $index is duplicated in '$cleaned'.")
        value = tryparse(Float64, strip(parts[2]))
        value === nothing && error(
            "Could not parse $label start offset value '$(strip(parts[2]))' from '$cleaned'.",
        )
        isfinite(value) || error("$label start offset at slot $index must be finite.")
        offsets[index] = value
        push!(seen, index)
    end
    return offsets
end

function _lib_apply_start_offsets(
    values::Vector{Float64},
    offsets::Vector{Float64};
    lower::Real,
    upper::Real,
    label::AbstractString,
)::Vector{Float64}
    length(values) == length(offsets) || error("$label value/offset lengths do not match.")
    lower_value = Float64(lower)
    upper_value = Float64(upper)
    lower_value <= upper_value || error("$label offset bounds must satisfy lower <= upper.")
    output = copy(values)
    for index in eachindex(output)
        proposed = output[index] + offsets[index]
        isfinite(proposed) || error("$label start offset at slot $index produced non-finite value.")
        output[index] = clamp(proposed, lower_value, upper_value)
    end
    return output
end

function _lib_resized(values::Vector{Float64}, length_required::Int; fill_value::Float64)::Vector{Float64}
    length_required >= 0 || error("Required vector length must be nonnegative.")
    if length(values) >= length_required
        return copy(values[1:length_required])
    end
    output = copy(values)
    append!(output, fill(fill_value, length_required - length(values)))
    return output
end

function _lib_bool(value)::Bool
    value isa Bool && return value
    value isa Missing && return false
    raw = lowercase(strip(string(value)))
    raw in ("1", "true", "yes", "y") && return true
    raw in ("0", "false", "no", "n") && return false
    return false
end

function _lib_required_columns(table::DataFrame)
    required = [
        :candidate_id,
        :temperature_values_C,
        :fda_doses_g_L,
        :organic_doses_g_L,
        :control_policy_ready,
    ]
    names_set = Set(Symbol.(names(table)))
    missing_columns = [String(column) for column in required if !(column in names_set)]
    isempty(missing_columns) || error(
        "Dynamic-control liberated-spec input CSV is missing column(s): " *
        join(missing_columns, ", "),
    )
    return nothing
end

function _lib_selected_policy(table::DataFrame, candidate_id::AbstractString)
    cleaned_id = strip(candidate_id)
    if !isempty(cleaned_id)
        matches = findall(==(cleaned_id), String.(table.candidate_id))
        length(matches) == 1 || error(
            "Expected exactly one base candidate_id=$cleaned_id, found $(length(matches)).",
        )
        _lib_bool(table.control_policy_ready[matches[1]]) || error(
            "Requested base candidate_id=$cleaned_id is not control_policy_ready=true.",
        )
        return table[matches[1], :]
    end
    ready_indices = findall(_lib_bool, table.control_policy_ready)
    !isempty(ready_indices) || error("No control_policy_ready=true policies in input CSV.")
    return table[ready_indices[1], :]
end

function _lib_first_indices(count::Int, requested_count::Int)::Vector{Int}
    count <= 0 && return Int[]
    requested_count <= 0 && return Int[]
    return collect(1:min(count, requested_count))
end

function _lib_parse_positive_int_token(token::AbstractString, raw_value::AbstractString)::Int
    value = tryparse(Int, strip(token))
    value === nothing && error("Could not parse Int token '$token' from '$raw_value'.")
    value > 0 || error("Liberation index token '$token' from '$raw_value' must be positive.")
    return value
end

function _lib_parse_liberation_indices(
    raw_value;
    max_count::Int,
    label::AbstractString,
)::Union{Nothing, Vector{Int}}
    cleaned = strip(replace(string(raw_value), ';' => ','))
    normalized = lowercase(cleaned)
    isempty(cleaned) && return nothing
    normalized in ("none", "locked", "0") && return Int[]
    normalized in ("all", "*", "full") && return collect(1:max_count)

    indices = Int[]
    for token in split(cleaned, ',')
        stripped = strip(token)
        isempty(stripped) && continue
        range_separator = occursin(":", stripped) ? ":" : occursin("-", stripped) ? "-" : ""
        if !isempty(range_separator)
            bounds = split(stripped, range_separator)
            length(bounds) == 2 || error(
                "$label liberation index range must look like 2:5 or 2-5; got: $raw_value",
            )
            first_index = _lib_parse_positive_int_token(bounds[1], cleaned)
            last_index = _lib_parse_positive_int_token(bounds[2], cleaned)
            first_index <= last_index || error(
                "$label liberation index range must be increasing; got: $raw_value",
            )
            append!(indices, first_index:last_index)
        else
            push!(indices, _lib_parse_positive_int_token(stripped, cleaned))
        end
    end
    unique_indices = sort!(unique!(indices))
    all(index -> 1 <= index <= max_count, unique_indices) || error(
        "$label liberation indices must be in 1:$max_count, got: $raw_value",
    )
    return unique_indices
end

function _lib_liberation_indices(
    explicit_raw_value;
    max_count::Int,
    requested_count::Int,
    label::AbstractString,
)::Vector{Int}
    explicit_indices = _lib_parse_liberation_indices(
        explicit_raw_value;
        max_count = max_count,
        label = label,
    )
    explicit_indices !== nothing && return explicit_indices
    return _lib_first_indices(max_count, requested_count)
end

function _lib_toml_normalize(value)
    if value isa AbstractDict
        return Dict(String(key) => _lib_toml_normalize(val) for (key, val) in value)
    elseif value isa AbstractVector
        return [_lib_toml_normalize(item) for item in value]
    elseif value isa Symbol
        return String(value)
    elseif value isa Missing
        return "missing"
    else
        return value
    end
end

policy_selection_csv = _lib_env_path(
    "MPCC_DYNAMIC_CONTROL_LIBERATION_BASE_SELECTION_CSV",
    joinpath("results", "dynamic_control_policy_selection_latest", "dynamic_control_policy_selection.csv"),
)
isfile(policy_selection_csv) || error("Policy selection CSV does not exist: $policy_selection_csv")

output_dir = _lib_env_path(
    "MPCC_DYNAMIC_CONTROL_LIBERATION_OUTPUT_DIR",
    joinpath("results", "dynamic_control_liberated_spec_latest"),
)
overwrite = _lib_env_bool("MPCC_DYNAMIC_CONTROL_LIBERATION_OVERWRITE", true)
base_candidate_id = strip(get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_BASE_CANDIDATE_ID", ""))
schedule_horizon_h =
    _lib_env_positive_float("MPCC_DYNAMIC_CONTROL_LIBERATION_SCHEDULE_HOURS", 168.0)
control_interval_h =
    _lib_env_positive_float("MPCC_DYNAMIC_CONTROL_LIBERATION_INTERVAL_HOURS", 12.0)
temperature_width_h =
    _lib_env_positive_float("MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_WIDTH_HOURS", 1.0)
addition_width_h =
    _lib_env_positive_float("MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_WIDTH_HOURS", 0.5)
temperature_min_C =
    _lib_env_positive_float("MPCC_DYNAMIC_CONTROL_LIBERATION_T_MIN_C", 15.0)
temperature_max_C =
    _lib_env_positive_float("MPCC_DYNAMIC_CONTROL_LIBERATION_T_MAX_C", 25.0)
temperature_max_C > temperature_min_C || error("Temperature max must be greater than min.")
temperature_slot_count =
    _lib_env_nonnegative_int("MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_SLOT_COUNT", 2)
addition_slot_count =
    _lib_env_nonnegative_int("MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_SLOT_COUNT", 1)
temperature_indices_raw = get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_INDICES", "")
addition_indices_raw = get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_ADDITION_INDICES", "")
temperature_start_offsets_raw =
    get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_START_OFFSETS_C", "")
fda_start_offsets_raw =
    get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_START_OFFSETS_G_L", "")
organic_start_offsets_raw =
    get(ENV, "MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_START_OFFSETS_G_L", "")
temperature_trust_C =
    _lib_env_nonnegative_float("MPCC_DYNAMIC_CONTROL_LIBERATION_TEMPERATURE_TRUST_C", 0.5)
fda_trust_g_L =
    _lib_env_nonnegative_float("MPCC_DYNAMIC_CONTROL_LIBERATION_FDA_TRUST_G_L", 0.25)
organic_trust_g_L =
    _lib_env_nonnegative_float("MPCC_DYNAMIC_CONTROL_LIBERATION_ORGANIC_TRUST_G_L", 0.05)
sample_dt_h =
    _lib_env_positive_float("MPCC_DYNAMIC_CONTROL_LIBERATION_SAMPLE_DT_HOURS", 1.0)

mkpath(output_dir)
spec_csv = joinpath(output_dir, "dynamic_control_liberated_decision_spec.csv")
schedule_csv = joinpath(output_dir, "dynamic_control_liberated_start_schedule.csv")
metadata_toml = joinpath(output_dir, "dynamic_control_liberated_metadata.toml")
if !overwrite
    existing_targets = [path for path in (spec_csv, schedule_csv, metadata_toml) if isfile(path)]
    isempty(existing_targets) || error(
        "Dynamic-control liberated-spec output file(s) already exist and overwrite=false: " *
        join(existing_targets, ", "),
    )
end

policy_table = DataFrame(CSV.File(policy_selection_csv))
_lib_required_columns(policy_table)
selected_row = _lib_selected_policy(policy_table, base_candidate_id)
selected_candidate_id = String(selected_row.candidate_id)
source_temperature_values_C = _lib_parse_float_vector(selected_row.temperature_values_C)
source_fda_doses_g_L = _lib_parse_float_vector(selected_row.fda_doses_g_L)
source_organic_doses_g_L = _lib_parse_float_vector(selected_row.organic_doses_g_L)
temperature_count = max(1, ceil(Int, schedule_horizon_h / control_interval_h))
addition_count = max(0, temperature_count - 1)
temperature_values_C = _lib_resized(
    source_temperature_values_C,
    temperature_count;
    fill_value = 20.0,
)
fda_doses_g_L = _lib_resized(
    source_fda_doses_g_L,
    addition_count;
    fill_value = 0.0,
)
organic_doses_g_L = _lib_resized(
    source_organic_doses_g_L,
    addition_count;
    fill_value = 0.0,
)
temperature_start_offsets_C = _lib_parse_indexed_float_offsets(
    temperature_start_offsets_raw;
    max_count = temperature_count,
    label = "temperature",
)
fda_start_offsets_g_L = _lib_parse_indexed_float_offsets(
    fda_start_offsets_raw;
    max_count = addition_count,
    label = "FDA",
)
organic_start_offsets_g_L = _lib_parse_indexed_float_offsets(
    organic_start_offsets_raw;
    max_count = addition_count,
    label = "organic",
)
temperature_values_C = _lib_apply_start_offsets(
    temperature_values_C,
    temperature_start_offsets_C;
    lower = temperature_min_C,
    upper = temperature_max_C,
    label = "temperature",
)
fda_doses_g_L = _lib_apply_start_offsets(
    fda_doses_g_L,
    fda_start_offsets_g_L;
    lower = 0.0,
    upper = FDA_SOLUTION_OIV_EQUIVALENT_LIMIT_G_L,
    label = "FDA",
)
organic_doses_g_L = _lib_apply_start_offsets(
    organic_doses_g_L,
    organic_start_offsets_g_L;
    lower = 0.0,
    upper = Inf,
    label = "organic",
)

base_schedule = dynamic_control_schedule_from_values(
    temperature_values_C;
    horizon_h = schedule_horizon_h,
    control_interval_h = control_interval_h,
    temperature_transition_width_h = temperature_width_h,
    temperature_min_C = temperature_min_C,
    temperature_max_C = temperature_max_C,
    fda_doses_g_L = fda_doses_g_L,
    organic_doses_g_L = organic_doses_g_L,
    addition_transition_width_h = addition_width_h,
    organic_composition = springferm_xtrem_organic_composition(),
)
temperature_free_indices = _lib_liberation_indices(
    temperature_indices_raw;
    max_count = length(base_schedule.temperature_values_C),
    requested_count = temperature_slot_count,
    label = "temperature",
)
addition_free_indices = _lib_liberation_indices(
    addition_indices_raw;
    max_count = length(fda_doses_g_L),
    requested_count = addition_slot_count,
    label = "nutrient addition",
)
spec = dynamic_control_decision_spec(
    base_schedule;
    horizon_h = schedule_horizon_h,
    control_interval_h = control_interval_h,
    temperature_free_indices = temperature_free_indices,
    addition_free_indices = addition_free_indices,
    temperature_trust_region_C = temperature_trust_C,
    fda_trust_region_g_L = fda_trust_g_L,
    organic_trust_region_g_L = organic_trust_g_L,
    metadata = Dict{String, Any}(
        "base_candidate_id" => selected_candidate_id,
        "control_liberation_mode" => "embedded_mpcc_control_decision_spec",
        "fully_simultaneous_controls" => false,
        "mpcc_embedding_ready" => false,
        "mpcc_fixed_control_sane_required" => true,
    ),
)

CSV.write(spec_csv, dynamic_control_decision_table(spec))
start_schedule = dynamic_control_schedule_from_decision_spec(spec)
CSV.write(
    schedule_csv,
    DataFrame(
        sample_dynamic_control_schedule(
            start_schedule;
            start_h = 0.0,
            stop_h = schedule_horizon_h,
            dt_h = sample_dt_h,
        ),
    ),
)

metadata = Dict{String, Any}(
    "script" => DYNAMIC_CONTROL_LIBERATED_SPEC_SCRIPT,
    "created_at" => Dates.format(Dates.now(), dateformat"yyyy-mm-ddTHH:MM:SS"),
    "policy_selection_csv" => policy_selection_csv,
    "output_dir" => output_dir,
    "spec_csv" => spec_csv,
    "start_schedule_csv" => schedule_csv,
    "metadata_toml" => metadata_toml,
    "selected_candidate_id" => selected_candidate_id,
    "schedule_horizon_h" => schedule_horizon_h,
    "control_interval_h" => control_interval_h,
    "temperature_width_h" => temperature_width_h,
    "addition_width_h" => addition_width_h,
    "temperature_min_C" => temperature_min_C,
    "temperature_max_C" => temperature_max_C,
    "source_temperature_value_count" => length(source_temperature_values_C),
    "source_fda_dose_count" => length(source_fda_doses_g_L),
    "source_organic_dose_count" => length(source_organic_doses_g_L),
    "temperature_value_count" => length(temperature_values_C),
    "addition_dose_count" => length(fda_doses_g_L),
    "temperature_trust_C" => temperature_trust_C,
    "fda_trust_g_L" => fda_trust_g_L,
    "organic_trust_g_L" => organic_trust_g_L,
    "temperature_indices_raw" => temperature_indices_raw,
    "addition_indices_raw" => addition_indices_raw,
    "temperature_start_offsets_raw" => temperature_start_offsets_raw,
    "fda_start_offsets_raw" => fda_start_offsets_raw,
    "organic_start_offsets_raw" => organic_start_offsets_raw,
    "temperature_start_offsets_C" => temperature_start_offsets_C,
    "fda_start_offsets_g_L" => fda_start_offsets_g_L,
    "organic_start_offsets_g_L" => organic_start_offsets_g_L,
    "temperature_free_indices" => temperature_free_indices,
    "addition_free_indices" => addition_free_indices,
    "control_liberation_mode" => "embedded_mpcc_control_decision_spec",
    "fully_simultaneous_controls" => false,
    "mpcc_embedding_ready" => false,
    "mpcc_fixed_control_sane_required" => true,
    "fixed_control_guarded_candidate_selection_required" => true,
    "next_technical_step" =>
        "wire DynamicControlDecisionSpec variables into reduced MPCC RHS and dynamic bounds",
)
open(metadata_toml, "w") do io
    TOML.print(io, _lib_toml_normalize(metadata))
end

println("Dynamic-control liberated decision spec")
println("policy_selection_csv: $policy_selection_csv")
println("output_dir: $output_dir")
println("spec_csv: $spec_csv")
println("start_schedule_csv: $schedule_csv")
println("metadata_toml: $metadata_toml")
println("selected_candidate_id: $selected_candidate_id")
println("control_liberation_mode: embedded_mpcc_control_decision_spec")
println("fully_simultaneous_controls: false")
println("mpcc_embedding_ready: false")
println("source_temperature_value_count: $(length(source_temperature_values_C))")
println("source_fda_dose_count: $(length(source_fda_doses_g_L))")
println("source_organic_dose_count: $(length(source_organic_doses_g_L))")
println("temperature_value_count: $(length(temperature_values_C))")
println("addition_dose_count: $(length(fda_doses_g_L))")
println("temperature_free_indices: $(join(temperature_free_indices, ","))")
println("addition_free_indices: $(join(addition_free_indices, ","))")
println("temperature_indices_raw: $temperature_indices_raw")
println("addition_indices_raw: $addition_indices_raw")
println("temperature_start_offsets_C: $(join(temperature_start_offsets_C, ","))")
println("fda_start_offsets_g_L: $(join(fda_start_offsets_g_L, ","))")
println("organic_start_offsets_g_L: $(join(organic_start_offsets_g_L, ","))")
println("temperature_trust_C: $temperature_trust_C")
println("fda_trust_g_L: $fda_trust_g_L")
println("organic_trust_g_L: $organic_trust_g_L")
