using FermentationDFBA

include(joinpath(@__DIR__, "ode_script_helpers.jl"))

project_root = normpath(joinpath(@__DIR__, ".."))
reduced_paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reduced_reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

const DEFAULT_MPCC_GLOBAL_POLISH_SWEEP_PROFILE = "smoke"
const DEFAULT_MPCC_GLOBAL_POLISH_SWEEP_SOURCE_MAX_ITER = 100

function _mpcc_global_polish_sweep_profile()
    raw = strip(
        get(
            ENV,
            "MPCC_GLOBAL_POLISH_SWEEP_PROFILE",
            DEFAULT_MPCC_GLOBAL_POLISH_SWEEP_PROFILE,
        ),
    )
    normalized = lowercase(raw)
    normalized in ("smoke", "focused", "grid", "72h", "custom") ||
        error("Environment variable MPCC_GLOBAL_POLISH_SWEEP_PROFILE must be one of: smoke, focused, grid, 72h, custom. Got: $raw")
    return normalized
end

function _mpcc_global_polish_sweep_profile_defaults(profile::AbstractString)
    if profile == "smoke"
        return (
            target_horizons = "0.5",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 1,
            max_windows = 1,
            source_max_iter = 100,
            retry_max_windows = 1,
            retry_max_iters = "200,300",
            cascade_max_iter = 300,
            global_max_iter = 300,
            mass_threshold = "5e-6",
        )
    elseif profile == "focused"
        return (
            target_horizons = "0.5,1.0",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 2,
            max_windows = 2,
            source_max_iter = 100,
            retry_max_windows = 2,
            retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            global_max_iter = 500,
            mass_threshold = "5e-6",
        )
    elseif profile == "grid"
        return (
            target_horizons = "0.5,1.0,1.5,2.0,3.0,4.0",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 6,
            max_windows = 8,
            source_max_iter = 100,
            retry_max_windows = 2,
            retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            global_max_iter = 500,
            mass_threshold = "5e-6",
        )
    elseif profile == "72h"
        return (
            target_horizons = "0.5,1.0,2.0,4.0,8.0,16.0,32.0,72.0",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 8,
            max_windows = 144,
            source_max_iter = 100,
            retry_max_windows = 4,
            retry_max_iters = "200,300,500",
            cascade_max_iter = 500,
            global_max_iter = 500,
            mass_threshold = "5e-6",
        )
    else
        return (
            target_horizons = "0.5",
            source_mode = "cascade",
            window_hours = "0.5",
            nfe = 2,
            max_cases = 1,
            max_windows = 1,
            source_max_iter = 100,
            retry_max_windows = 1,
            retry_max_iters = "200,300",
            cascade_max_iter = 300,
            global_max_iter = 300,
            mass_threshold = "5e-6",
        )
    end
end

function _mpcc_global_polish_sweep_env_float_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Float64}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Float64[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        value = tryparse(Float64, stripped)
        value === nothing && error("Environment variable $name contains invalid Float64 token: $stripped")
        isfinite(value) && value > 0.0 ||
            error("Environment variable $name values must be finite and positive, got: $value")
        push!(values, value)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_global_polish_sweep_env_positive_float(
    name::AbstractString,
    default_value::AbstractString,
)::Float64
    raw = strip(get(ENV, String(name), String(default_value)))
    value = tryparse(Float64, raw)
    value === nothing && error("Environment variable $name must be a Float64, got: $raw")
    isfinite(value) && value > 0.0 ||
        error("Environment variable $name must be finite and positive, got: $value")
    return value
end

function _mpcc_global_polish_sweep_env_positive_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value > 0 || error("Environment variable $name must be positive, got: $value")
    return value
end

function _mpcc_global_polish_sweep_env_nonnegative_int(
    name::AbstractString,
    default_value::Int,
)::Int
    raw = strip(get(ENV, String(name), string(default_value)))
    value = tryparse(Int, raw)
    value === nothing && error("Environment variable $name must be an Int, got: $raw")
    value >= 0 || error("Environment variable $name must be nonnegative, got: $value")
    return value
end

function _mpcc_global_polish_sweep_parse_int_list(
    name::AbstractString,
    default_value::AbstractString,
)::Vector{Int}
    raw = strip(get(ENV, String(name), String(default_value)))
    isempty(raw) && error("Environment variable $name must not be empty.")
    values = Int[]
    for token in split(raw, [',', ';'])
        stripped = strip(token)
        isempty(stripped) && continue
        parsed = tryparse(Int, stripped)
        parsed === nothing && error("Environment variable $name has invalid Int token: $stripped")
        parsed > 0 || error("Environment variable $name values must be positive, got: $parsed")
        push!(values, parsed)
    end
    isempty(values) && error("Environment variable $name must contain at least one value.")
    return values
end

function _mpcc_global_polish_sweep_source_mode(default_value::AbstractString)::String
    raw = strip(get(ENV, "MPCC_GLOBAL_POLISH_SWEEP_SOURCE", String(default_value)))
    normalized = lowercase(raw)
    normalized in ("cascade", "windowed") ||
        error("Environment variable MPCC_GLOBAL_POLISH_SWEEP_SOURCE must be cascade or windowed. Got: $raw")
    return normalized
end

function _mpcc_global_polish_sweep_validate_size!(
    target_horizons::Vector{Float64},
    window_hours::Float64,
    max_cases::Int,
    max_windows::Int,
    allow_large::Bool,
    allow_long::Bool,
)
    if length(target_horizons) > max_cases && !allow_large
        error(
            "Requested MPCC global polish sweep has $(length(target_horizons)) cases, above " *
            "MPCC_GLOBAL_POLISH_SWEEP_MAX_CASES=$max_cases. Set " *
            "MPCC_GLOBAL_POLISH_SWEEP_ALLOW_LARGE=1 only for deliberate diagnostics.",
        )
    end
    for target in target_horizons
        raw = target / window_hours
        isapprox(raw, round(Int, raw); atol = 1.0e-10, rtol = 1.0e-10) ||
            error("Each target horizon must be an integer multiple of window_hours. Got target=$target, window=$window_hours.")
    end
    requested_windows = maximum(round(Int, target / window_hours) for target in target_horizons)
    if requested_windows > max_windows && !allow_long
        error(
            "Requested MPCC global polish sweep has up to $requested_windows windows, above " *
            "MPCC_GLOBAL_POLISH_SWEEP_MAX_WINDOWS=$max_windows. Set " *
            "MPCC_GLOBAL_POLISH_SWEEP_ALLOW_LONG=1 only for deliberate longer diagnostics.",
        )
    end
    return nothing
end

function _mpcc_global_polish_sweep_value(value)
    if value === missing || value === nothing
        return "missing"
    else
        return string(value)
    end
end

function _mpcc_global_polish_sweep_progress_callback(progress::Bool)
    progress || return nothing
    return function (row, row_index, total)
        println(
            "progress_case: $row_index/$total | " *
            "id=$(_mpcc_global_polish_sweep_value(row["global_polish_case_id"])) | " *
            "target=$(_mpcc_global_polish_sweep_value(row["target_horizon"])) | " *
            "source=$(_mpcc_global_polish_sweep_value(row["source_mode"])) | " *
            "global_light=$(_mpcc_global_polish_sweep_value(row["global_polish_traffic_light"])) | " *
            "solver=$(_mpcc_global_polish_sweep_value(row["solver_status"])) | " *
            "profile=$(_mpcc_global_polish_sweep_value(row["ipopt_profile"])) | " *
            "ready=$(_mpcc_global_polish_sweep_value(row["candidate_trajectory_ready"]))",
        )
    end
end

profile = _mpcc_global_polish_sweep_profile()
defaults = _mpcc_global_polish_sweep_profile_defaults(profile)
target_horizons = _mpcc_global_polish_sweep_env_float_list(
    "MPCC_GLOBAL_POLISH_SWEEP_TARGET_HOURS",
    defaults.target_horizons,
)
source_mode = _mpcc_global_polish_sweep_source_mode(defaults.source_mode)
window_hours = _mpcc_global_polish_sweep_env_positive_float(
    "MPCC_GLOBAL_POLISH_SWEEP_WINDOW_HOURS",
    defaults.window_hours,
)
nfe_per_window = _mpcc_global_polish_sweep_env_positive_int(
    "MPCC_GLOBAL_POLISH_SWEEP_NFE",
    defaults.nfe,
)
max_cases = _mpcc_global_polish_sweep_env_positive_int(
    "MPCC_GLOBAL_POLISH_SWEEP_MAX_CASES",
    defaults.max_cases,
)
max_windows = _mpcc_global_polish_sweep_env_positive_int(
    "MPCC_GLOBAL_POLISH_SWEEP_MAX_WINDOWS",
    defaults.max_windows,
)
source_max_iter = _mpcc_global_polish_sweep_env_positive_int(
    "MPCC_GLOBAL_POLISH_SWEEP_SOURCE_MAX_ITER",
    defaults.source_max_iter,
)
retry_max_windows = _mpcc_global_polish_sweep_env_nonnegative_int(
    "MPCC_GLOBAL_POLISH_SWEEP_MAX_RETRY_WINDOWS",
    defaults.retry_max_windows,
)
retry_max_iters = _mpcc_global_polish_sweep_parse_int_list(
    "MPCC_GLOBAL_POLISH_SWEEP_RETRY_MAX_ITERS",
    defaults.retry_max_iters,
)
cascade_max_iter = _mpcc_global_polish_sweep_env_positive_int(
    "MPCC_GLOBAL_POLISH_SWEEP_CASCADE_MAX_ITER",
    defaults.cascade_max_iter,
)
global_max_iter = _mpcc_global_polish_sweep_env_positive_int(
    "MPCC_GLOBAL_POLISH_SWEEP_GLOBAL_MAX_ITER",
    defaults.global_max_iter,
)
ipopt_profile = reduced_mpcc_ipopt_profile_name_from_env()
mass_threshold = _mpcc_global_polish_sweep_env_positive_float(
    "MPCC_GLOBAL_POLISH_SWEEP_MASS_THRESHOLD",
    defaults.mass_threshold,
)
selection_policy =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_SWEEP_SELECTION_POLICY", "iteration_limit_or_not_ready"))
replacement_policy =
    strip(get(ENV, "MPCC_GLOBAL_POLISH_SWEEP_REPLACEMENT_POLICY", "green_or_trajectory_ready"))
allow_large = _script_env_bool("MPCC_GLOBAL_POLISH_SWEEP_ALLOW_LARGE", false)
allow_long = _script_env_bool("MPCC_GLOBAL_POLISH_SWEEP_ALLOW_LONG", false)
continue_on_error = _script_env_bool("MPCC_GLOBAL_POLISH_SWEEP_CONTINUE_ON_ERROR", true)
source_require_pre_solve_ready =
    _script_env_bool("MPCC_GLOBAL_POLISH_SWEEP_SOURCE_REQUIRE_PREFLIGHT", true)
global_require_pre_solve_ready =
    _script_env_bool("MPCC_GLOBAL_POLISH_SWEEP_GLOBAL_REQUIRE_PREFLIGHT", false)
silent = _script_env_bool("MPCC_GLOBAL_POLISH_SWEEP_SILENT", true)
progress = _script_env_bool("MPCC_GLOBAL_POLISH_SWEEP_PROGRESS", profile != "smoke")
stop_after_first_non_green =
    _script_env_bool("MPCC_GLOBAL_POLISH_SWEEP_STOP_AFTER_FIRST_NON_GREEN", false)

_mpcc_global_polish_sweep_validate_size!(
    target_horizons,
    window_hours,
    max_cases,
    max_windows,
    allow_large,
    allow_long,
)

println("Reduced MPCC global polish horizon sweep")
println("profile: $profile")
println("source_mode: $source_mode")
println("target_horizons: $(join(target_horizons, ","))")
println("window_hours: $window_hours")
println("nfe_per_window: $nfe_per_window")
println("mass_threshold: $mass_threshold")
println("source_ipopt_max_iter: $source_max_iter")
println("retry_max_windows: $retry_max_windows")
println("retry_max_iters: $(join(retry_max_iters, ","))")
println("cascade_max_iter: $cascade_max_iter")
println("global_ipopt_max_iter: $global_max_iter")
println("ipopt_profile: $ipopt_profile")
println("selection_policy: $selection_policy")
println("replacement_policy: $replacement_policy")
println("source_require_pre_solve_ready: $source_require_pre_solve_ready")
println("global_require_pre_solve_ready: $global_require_pre_solve_ready")
println("continue_on_error: $continue_on_error")
println("stop_after_first_non_green: $stop_after_first_non_green")
println("progress: $progress")

model = load_reduced_model(reduced_paths_config)
reaction_map = load_reaction_map(reduced_reaction_map_config)

base_residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds()
residual_thresholds = default_reduced_dcdfba_mpcc_residual_thresholds(
    max_rhs_residual = base_residual_thresholds.max_rhs_residual,
    max_mass_balance_residual = mass_threshold,
    max_lower_bound_violation = base_residual_thresholds.max_lower_bound_violation,
    max_upper_bound_violation = base_residual_thresholds.max_upper_bound_violation,
    max_stationarity_residual = base_residual_thresholds.max_stationarity_residual,
    max_lower_complementarity_residual =
        base_residual_thresholds.max_lower_complementarity_residual,
    max_upper_complementarity_residual =
        base_residual_thresholds.max_upper_complementarity_residual,
)
viability_thresholds = default_reduced_dcdfba_mpcc_simulation_viability_thresholds(
    residual_thresholds = residual_thresholds,
)

sweep = sweep_reduced_dcdfba_mpcc_global_polish_horizons(
    model,
    reaction_map;
    target_horizons = target_horizons,
    source_mode = source_mode,
    window_hours = window_hours,
    nfe_per_window = nfe_per_window,
    degree = 3,
    source_ipopt_max_iter = source_max_iter,
    retry_ipopt_max_iter_values = retry_max_iters,
    retry_selection_policy = selection_policy,
    retry_max_windows = retry_max_windows,
    cascade_ipopt_max_iter = cascade_max_iter,
    replacement_acceptance_policy = replacement_policy,
    global_ipopt_max_iter = global_max_iter,
    ipopt_profile = ipopt_profile,
    source_require_pre_solve_ready = source_require_pre_solve_ready,
    global_require_pre_solve_ready = global_require_pre_solve_ready,
    residual_thresholds = residual_thresholds,
    viability_thresholds = viability_thresholds,
    silent = silent,
    continue_on_error = continue_on_error,
    stop_after_first_non_green = stop_after_first_non_green,
    case_callback = _mpcc_global_polish_sweep_progress_callback(progress),
)

println("outputs_written: $(sweep.metadata["outputs_written"])")
println("sweep_is_scientific_simulation: $(sweep.metadata["sweep_is_scientific_simulation"])")
println("solved_trajectory_claimed: $(sweep.metadata["solved_trajectory_claimed"])")
println("scientific_baseline: $(sweep.metadata["scientific_baseline"])")
println("first_mpcc_target: $(sweep.metadata["first_mpcc_target"])")
println("full_model_kkt_deferred: $(sweep.metadata["full_model_kkt_deferred"])")
println("dfvb_kkt_deferred: $(sweep.metadata["dfvb_kkt_deferred"])")
println("hsl_required: $(sweep.metadata["hsl_required"])")
println("ma57_required: $(sweep.metadata["ma57_required"])")
println("indices_reacciones_used: $(sweep.metadata["indices_reacciones_used"])")
println("r0001_used_as_oxygen: $(sweep.metadata["r0001_used_as_oxygen"])")
println("n_requested_cases: $(sweep.metadata["n_requested_cases"])")
println("n_cases: $(sweep.metadata["n_cases"])")
println("n_completed_cases: $(sweep.metadata["n_completed_cases"])")
println("n_failed_cases: $(sweep.metadata["n_failed_cases"])")
println("green_count: $(sweep.metadata["green_count"])")
println("yellow_count: $(sweep.metadata["yellow_count"])")
println("red_count: $(sweep.metadata["red_count"])")
println("global_polish_viable_count: $(sweep.metadata["global_polish_viable_count"])")
println("target_completed_count: $(sweep.metadata["target_completed_count"])")
println("residual_feasible_count: $(sweep.metadata["residual_feasible_count"])")
println("trajectory_ready_count: $(sweep.metadata["trajectory_ready_count"])")
println("nlp_structure_dof_risk_count: $(sweep.metadata["nlp_structure_dof_risk_count"])")
println("nlp_structure_min_dof_balance: $(_mpcc_global_polish_sweep_value(sweep.metadata["nlp_structure_min_dof_balance"]))")
println("best_green_case_id: $(_mpcc_global_polish_sweep_value(sweep.metadata["best_green_case_id"]))")
println("best_green_target_horizon: $(_mpcc_global_polish_sweep_value(sweep.metadata["best_green_target_horizon"]))")
println("best_green_global_horizon: $(_mpcc_global_polish_sweep_value(sweep.metadata["best_green_global_horizon"]))")
println("max_horizon_reached: $(_mpcc_global_polish_sweep_value(sweep.metadata["max_horizon_reached"]))")
println("first_non_green_case_id: $(_mpcc_global_polish_sweep_value(sweep.metadata["first_non_green_case_id"]))")
println("first_non_green_target_horizon: $(_mpcc_global_polish_sweep_value(sweep.metadata["first_non_green_target_horizon"]))")
println("total_solve_elapsed_seconds: $(sweep.metadata["total_solve_elapsed_seconds"])")
println("recommended_next_action: $(sweep.metadata["recommended_next_action"])")

println("global_polish_table:")
for row in eachrow(sweep.global_polish_table)
    println(
        "  $(row["global_polish_case_id"]) | target=$(_mpcc_global_polish_sweep_value(row["target_horizon"])) | " *
        "source=$(_mpcc_global_polish_sweep_value(row["source_mode"])) | " *
        "global_light=$(_mpcc_global_polish_sweep_value(row["global_polish_traffic_light"])) | " *
        "solver=$(_mpcc_global_polish_sweep_value(row["solver_status"])) | " *
        "profile=$(_mpcc_global_polish_sweep_value(row["ipopt_profile"])) | " *
        "acceptable=$(_mpcc_global_polish_sweep_value(row["acceptable_solver_status"])) | " *
        "almost=$(_mpcc_global_polish_sweep_value(row["almost_locally_solved_accepted"])) | " *
        "ready=$(_mpcc_global_polish_sweep_value(row["candidate_trajectory_ready"])) | " *
        "residual_feasible=$(_mpcc_global_polish_sweep_value(row["candidate_residual_feasible"])) | " *
        "global_horizon=$(_mpcc_global_polish_sweep_value(row["global_horizon"])) | " *
        "global_nfe=$(_mpcc_global_polish_sweep_value(row["global_nfe"])) | " *
        "dof=$(_mpcc_global_polish_sweep_value(row["nlp_structure_dof_balance"])) | " *
        "fixed=$(_mpcc_global_polish_sweep_value(row["nlp_structure_fixed_variable_count"])) | " *
        "dof_risk=$(_mpcc_global_polish_sweep_value(row["nlp_structure_too_few_degrees_of_freedom_risk"])) | " *
        "mass_resid=$(_mpcc_global_polish_sweep_value(row["max_mass_balance_residual"])) | " *
        "state_rmse=$(_mpcc_global_polish_sweep_value(row["max_state_relative_rmse"])) | " *
        "solve_s=$(_mpcc_global_polish_sweep_value(row["solve_elapsed_seconds"])) | " *
        "action=$(_mpcc_global_polish_sweep_value(row["recommended_next_action"]))",
    )
end

println("interpretation_note: $(sweep.metadata["interpretation_note"])")
