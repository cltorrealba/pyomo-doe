using FermentationDFBA

project_root = normpath(joinpath(@__DIR__, ".."))
default_export_dir = joinpath(project_root, "results", "reduced_dfba_latest")

function _env_bool(name::AbstractString, default::Bool)
    value = lowercase(strip(get(ENV, String(name), string(default))))
    return value in ("1", "true", "yes", "y", "on")
end

export_dir = normpath(get(ENV, "DFBA_PLOT_EXPORT_DIR", default_export_dir))
output_dir = normpath(get(ENV, "DFBA_PLOT_OUTPUT_DIR", joinpath(export_dir, "plots")))
overwrite = _env_bool("DFBA_PLOT_OVERWRITE", true)

paths = write_exported_trajectory_plots(export_dir; output_dir = output_dir, overwrite = overwrite)

println("Reduced DFBA trajectory plot report")
println("export_dir: $export_dir")
println("output_dir: $output_dir")
println("overwrite: $overwrite")
println("written_files:")
for key in sort(collect(keys(paths)))
    println("  $key = $(paths[key])")
end
