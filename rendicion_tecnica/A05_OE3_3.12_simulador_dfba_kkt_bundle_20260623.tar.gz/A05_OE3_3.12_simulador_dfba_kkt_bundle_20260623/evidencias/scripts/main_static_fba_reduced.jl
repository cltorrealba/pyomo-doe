using FermentationDFBA
import MathOptInterface as MOI

const DIAGNOSTIC_TOLERANCE = 1.0e-6

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "reduced_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_reduced.example.toml")

model = load_reduced_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)

reaction_report.ok || error(
    "Reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

objective_rxn_id = reaction_map.core["biomass_growth"]
result = solve_fba(model; objective_rxn_id = objective_rxn_id, sense = :max, atol = DIAGNOSTIC_TOLERANCE)

result.status == MOI.OPTIMAL || error("Static FBA solve did not terminate as optimal. Status: $(result.status)")
result.mass_balance_residual <= DIAGNOSTIC_TOLERANCE || error(
    "Mass-balance residual $(result.mass_balance_residual) exceeds tolerance $DIAGNOSTIC_TOLERANCE",
)
result.max_lower_bound_violation <= DIAGNOSTIC_TOLERANCE || error(
    "Lower-bound violation $(result.max_lower_bound_violation) exceeds tolerance $DIAGNOSTIC_TOLERANCE",
)
result.max_upper_bound_violation <= DIAGNOSTIC_TOLERANCE || error(
    "Upper-bound violation $(result.max_upper_bound_violation) exceeds tolerance $DIAGNOSTIC_TOLERANCE",
)

println("Reduced static FBA report")
println("model_id: $(model.model_id)")
println("metabolites: $(length(model.met_ids))")
println("reactions: $(length(model.rxn_ids))")
println("objective_reaction_id: $(result.objective_rxn_id)")
println("objective_value: $(result.objective_value)")
println("solver_status: $(result.status)")
println("mass_balance_residual: $(result.mass_balance_residual)")
println("max_lower_bound_violation: $(result.max_lower_bound_violation)")
println("max_upper_bound_violation: $(result.max_upper_bound_violation)")

println("selected_fluxes:")
for rxn_id in ("r_2111", "r_1714", "r_1709", "r_1761", "r_4046", "r_4047", "r_4048")
    index = reaction_index(model, rxn_id)
    println("  $rxn_id = $(result.fluxes[index])")
end

oxygen_id = get(reaction_report.disabled_reactions, "oxygen_exchange", "r_1992")
println("disabled_reactions_not_used:")
println("  oxygen_exchange = $oxygen_id")
println("active_carbohydrate_pseudoreaction:")
println("  carbohydrate_exchange = $(reaction_map.core["carbohydrate_exchange"])")
println("Static FBA uses reaction IDs from rxn_list.csv and does not use Indices_reacciones.csv.")
