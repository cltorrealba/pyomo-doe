using FermentationDFBA
import MathOptInterface as MOI

const FULL_STATIC_FBA_DIAGNOSTIC_TOLERANCE = 1.0e-6

project_root = normpath(joinpath(@__DIR__, ".."))
paths_config = joinpath(project_root, "config", "full_model_paths.example.toml")
reaction_map_config = joinpath(project_root, "config", "reaction_map_full.example.toml")

model = load_full_model(paths_config)
reaction_map = load_reaction_map(reaction_map_config)
reaction_report = validate_reaction_map(model, reaction_map)

reaction_report.ok || error(
    "Full reaction map validation failed. Missing reactions: $(reaction_report.missing_required_reactions)",
)

objective_rxn_id = reaction_map.core["biomass_growth"]
result = solve_fba(
    model;
    objective_rxn_id = objective_rxn_id,
    sense = :max,
    atol = FULL_STATIC_FBA_DIAGNOSTIC_TOLERANCE,
)

result.status == MOI.OPTIMAL || error("Full static FBA solve did not terminate as optimal. Status: $(result.status)")
result.objective_value > 0.0 || error("Full static FBA objective value must be positive.")
result.mass_balance_residual <= FULL_STATIC_FBA_DIAGNOSTIC_TOLERANCE || error(
    "Mass-balance residual $(result.mass_balance_residual) exceeds tolerance $FULL_STATIC_FBA_DIAGNOSTIC_TOLERANCE",
)
result.max_lower_bound_violation <= FULL_STATIC_FBA_DIAGNOSTIC_TOLERANCE || error(
    "Lower-bound violation $(result.max_lower_bound_violation) exceeds tolerance $FULL_STATIC_FBA_DIAGNOSTIC_TOLERANCE",
)
result.max_upper_bound_violation <= FULL_STATIC_FBA_DIAGNOSTIC_TOLERANCE || error(
    "Upper-bound violation $(result.max_upper_bound_violation) exceeds tolerance $FULL_STATIC_FBA_DIAGNOSTIC_TOLERANCE",
)

oxygen_flux = result.fluxes[reaction_index(model, "r_1992")]
abs(oxygen_flux) <= FULL_STATIC_FBA_DIAGNOSTIC_TOLERANCE || error(
    "Full static FBA oxygen flux r_1992 must be approximately zero, got $oxygen_flux",
)

println("Full static FBA report")
println("model_id: $(model.model_id)")
println("metabolites: $(length(model.met_ids))")
println("reactions: $(length(model.rxn_ids))")
println("objective_reaction_id: $(result.objective_rxn_id)")
println("objective_value: $(result.objective_value)")
println("solver_status: $(result.status)")
println("mass_balance_residual: $(result.mass_balance_residual)")
println("max_lower_bound_violation: $(result.max_lower_bound_violation)")
println("max_upper_bound_violation: $(result.max_upper_bound_violation)")

println("selected_fluxes:")
for rxn_id in ("r_2111", "r_1714", "r_1709", "r_1761", "r_1992", "r_4046", "r_4047", "r_4048")
    index = reaction_index(model, rxn_id)
    println("  $rxn_id = $(result.fluxes[index])")
end

oxygen_index = reaction_index(model, "r_1992")
println("oxygen_bounds_r_1992:")
println("  lb = $(model.lb[oxygen_index])")
println("  ub = $(model.ub[oxygen_index])")
println("oxygen_mapping_note: r_1992 is present and closed by bounds; r_0001 is not used as oxygen.")
